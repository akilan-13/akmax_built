<?php

namespace App\Jobs;

use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use App\Models\WebhookDispatchModel;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $dispatchSno;
    public $tries = 5;

    public function __construct(int $dispatchSno)
    {
        $this->dispatchSno = $dispatchSno;
        $this->onQueue('webhooks');
    }

    public function backoff(): array
    {
        return [
            60,           // 1 min
            2 * 60,       // 2 mins
            5 * 60,       // 5 mins
            15 * 60,      // 15 mins
            60 * 60       // 1 hour
        ];
    }

    // public function backoff(): array
    // {
    //     $base = 60; // 1 minute
    //     return array_map(fn($i) => $base * (2 ** $i), range(0, 4));
    // }

    public function handle()
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if (!$dispatch || $dispatch->status === 2) return;

        $hook = $dispatch->webhook;
        if (!$hook) {
            $dispatch->update(['status' => 3, 'last_response' => 'No webhook configured']);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return;
        }

        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );
            \Log::info("Webhook headers : " . json_encode($headers));
       try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);
            \Log::info("Webhook dispatch response : " . $response->body());

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
               broadcast(new WebhookDispatchedEvent($dispatch)); // broadcast success
            } else {
                // Don't broadcast raw 500s to frontend
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                
                broadcast(new WebhookDispatchedEvent($dispatch)); // broadcast failed
                 \Log::info("Webhook failed. Will retry automatically: ".$response);
            }

        } catch (\Throwable $e) {
            // Log the error for debugging but don't broadcast raw errors
             \Log::info("Webhook error: ".$e->getMessage());
            \Log::error("Webhook failed [{$dispatch->sno}]: ".$e->getMessage());

            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
        }

        broadcast(new WebhookDispatchedEvent($dispatch));
    }

    public function failed(\Throwable $exception) // ← prefix with backslash
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if ($dispatch) {
            $dispatch->update(['status' => 3, 'last_response' => $exception->getMessage()]);
            broadcast(new WebhookDispatchedEvent($dispatch));
        }
    }
}
