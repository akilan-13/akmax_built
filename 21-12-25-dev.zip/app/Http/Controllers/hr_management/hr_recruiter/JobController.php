<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\JobQRScannerModel;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\JobRequestModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewSessionModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewCandidateModel;
use App\Models\InterviewOtpModel;

class JobController extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
     $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', '>', 1);
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        if($company_fill != ''){
          if($company_fill == 'egc'){
             $staffData->where('egc_staff.company_type',1);
          }else{
            $staffData->where('egc_staff.company_id', 'LIKE', $company_fill);
          }
            
        }

        if ($entity_fill) {
          $staffData->where('egc_staff.entity_id', $entity_fill);
        }

        
        if ($department_fill) {
            $staffData->where('egc_staff.department_id', $department_fill);
        }

        if ($division_fill) {
            $staffData->where('egc_staff.division_id', $division_fill);
        }

        if ($job_role_fill) {
          $staffData->where('egc_staff.job_role_id', $job_role_fill);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
            }
          }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);
        
        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
            
           $educations = DB::table('egc_staff_education_info')
            ->select('egc_education.education')
            ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
            ->where('egc_staff_education_info.staff_id', $staff->sno) 
            ->where('egc_staff_education_info.status', 0)
            ->pluck('egc_education.education');
            $staff->education=$educations;
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staffData->currentPage(),
                'last_page' => $staffData->lastPage(),
                'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.manage_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }
  
  public function jobApplication($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
     $qrcode=$request->qr;
     $decodeQr = base64_decode($qrcode);

      if($decodeQr == 'EGCJOBQR'){
        $scanTracked = session('job_scan_tracked_' . $decodeId);
        if (!$scanTracked) {
            // Save the scan details if not tracked already
            $this->saveScanDetails($decodeId, $request);
    
            // Set a session flag to indicate that the scan has been tracked for this event
            session(['job_scan_tracked_' . $decodeId => true]);
        }
      }

     
     $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$decodeId)->first();

     $other_db = DB::connection('mysql_secondary');
     
   
    //   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('applicant')
      ->get();
      // return  $users_with_call_log_count ;
    $feedback_submitted =false;
    $customers =[];
    return view('content.hr_management.hr_recruiter.job_application.job_application_form',compact('feedback_submitted','customers','jobRequest'));
  }

  public function generateQrJob($id, Request $request)
  {
      // Encode sno in base64 (shorter than Crypt)
      $encodedId = base64_encode($id);
      $encodedcode = base64_encode('EGCJOBQR');
  
      
      $qrContent = url("/job_application/{$encodedId}?qr={$encodedcode}");
      // 'https://erp.elysium.community/job_application_qr';
  
      // Generate QR as base64 image
      $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=300x300";
      $qrImageData = @file_get_contents($qrServerUrl);
      $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
      // Save scan details
      
  
      return response()->json([
          'status'    => $qrBase64 ? 200 : 500,
          'qr_base64' => $qrBase64,
          'link'      => $qrContent,
      ]);
  }
    
  private function saveScanDetails($job_request_id,Request $request)
  {
      // Get the user's IP address
      $ipAddress = $request->ip();
  
      // Get latitude and longitude if provided by frontend (JavaScript geolocation)
      $latitude = $request->input('latitude', null);
      $longitude = $request->input('longitude', null);
  
      // Get area from IP address (you can use any IP geolocation API)
      // $area = $this->getAreaByIp($ipAddress);
      $area="";
      // Get device information (User-Agent string)
      $deviceInfo = $request->header('User-Agent');
      $isMobile = preg_match('/Mobile|Android|iP(hone|od|ad)|IEMobile|BlackBerry|Opera Mini/i', $deviceInfo);
              
      $deviceType = $isMobile ? 'Mobile' : 'Desktop';
  
      // Insert the scan data into the database
      JobQRScannerModel::create([
          'job_request_id'      => $job_request_id,
          'ipaddress' => $ipAddress,
          'latitude'   => $latitude,
          'longitude'  => $longitude,
          'area'       => $area,
          'device'=> $deviceType,
      ]);
  }

   public function Interview($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
     $qrcode=$request->qr;
     $decodeQr = base64_decode($qrcode);

      if($decodeQr == 'EGCJOBQR'){
        $scanTracked = session('job_scan_tracked_' . $decodeId);
        if (!$scanTracked) {
            // Save the scan details if not tracked already
            $this->saveScanDetails($decodeId, $request);
    
            // Set a session flag to indicate that the scan has been tracked for this event
            session(['job_scan_tracked_' . $decodeId => true]);
        }
      }

     
     $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$decodeId)->first();

     $other_db = DB::connection('mysql_secondary');
     
   
    //   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('applicant')
      ->get();
      // return  $users_with_call_log_count ;
    $feedback_submitted =false;
    $customers =[];
    return view('content.hr_management.hr_recruiter.job_application.interview_page',compact('feedback_submitted','customers','jobRequest'));
  }
  
    public function startInterview($code)
  {
      [$scheduleSno] = explode('|', base64_decode($code));

      $schedule = InterviewScheduleModel::where('sno', $scheduleSno)
          ->where('status', 1)
          ->firstOrFail();

      return view('content.hr_management.hr_recruiter.job_application.interview_login', compact('code'));
  }

  public function Login(){
        $session = InterviewSessionModel::create([
        'interview_schedule_id' => $scheduleSno,
        'candidate_id' => auth()->id(),
        'session_token' => Str::uuid(),
        'started_at' => now(),
        'status' => 1,
        'created_at' => now(),
        'created_by' => auth()->id()
    ]);

    return redirect('/interview/run/' . $session->session_token);

  }

   public function sendOtp(Request $request)
  {
      $request->validate([
          'full_name' => 'required|string|min:3',
          'mobile'    => 'required|regex:/^[6-9]\d{9}$/',
          'email'     => 'required|email'
      ]);

      DB::beginTransaction();
      // return $request;
      // try {
          // create or get candidate
          $candidate = InterviewCandidateModel::firstOrCreate(
              ['mobile' => $request->mobile],
              [
                  'full_name' => $request->full_name,
                  'email'     => $request->email,
                  'status'    => 1
              ]
          );

          // email mismatch safety
          if ($candidate->email !== $request->email) {
              return response()->json([
                  'message' => 'Email does not match registered mobile number'
              ], 400);
          }

          // invalidate old OTPs
          InterviewOtpModel::where('candidate_id', $candidate->sno)
              ->update(['is_used' => 1]);

          $otp = rand(100000, 999999);

          InterviewOtpModel::create([
              'candidate_id' => $candidate->sno,
              'otp'          => $otp,
              'expires_at'   => now()->addMinutes(5),
              'is_used'      => 0
          ]);

          // TODO: SMS / Email integration
          // sendSms($candidate->mobile, $otp);

          DB::commit();

          return response()->json([
              'status' => true,
              'message' => 'OTP sent successfully'
          ]);

      // } catch (\Throwable $e) {
      //     DB::rollBack();
      //     return response()->json([
      //         'message' => 'Failed to send OTP'
      //     ], 500);
      // }
  }

  public function verifyOtp(Request $request)
{
    $request->validate([
        'mobile' => 'required',
        'otp'    => 'required'
    ]);

    $candidate = InterviewCandidateModel::where('mobile', $request->mobile)->first();

    if (!$candidate) {
        return response()->json(['message' => 'Candidate not found'], 400);
    }

    $otpRow = InterviewOtpModel::where('candidate_id', $candidate->sno)
        ->where('otp', $request->otp)
        ->where('is_used', 0)
        ->where('expires_at', '>', now())
        ->first();

    if (!$otpRow) {
        return response()->json(['message' => 'Invalid or expired OTP'], 400);
    }

    $otpRow->update(['is_used' => 1]);

    $session = EgcInterviewSession::create([
        'interview_schedule_sno' => session('interview_schedule_sno'),
        'candidate_id' => $candidate->sno,
        'session_token' => \Str::uuid(),
        'started_at' => now(),
        'status' => 1,
        'created_at' => now()
    ]);

    return response()->json([
        'status' => true,
        'redirect' => url('/interview/run/' . $session->session_token)
    ]);
}



    public function runInterview($token)
{
    $session = InterviewSessionModel::where('session_token', $token)
        ->where('status', 1)
        ->firstOrFail();

    return view('interview.run', compact('session'));
}


}