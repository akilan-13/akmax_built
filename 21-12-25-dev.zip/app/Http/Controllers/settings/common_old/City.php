<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;



class City extends Controller
{
  protected static $branch_id = 1;
  public function index()
{
    return view('content.settings.common.city.city_list');
}

//here i need to get the country table data by using the state table data

  public function List()
  {
    // Retrieve the category ID from the POST request
    $cat_id = $_GET['id'] ?? '';
    $state_id = $_GET['state_id'] ?? '';



    $City = CityModel::where('status', 0)
      ->where('id', $cat_id)
      ->where('state_id',$state_id)
      ->orderBy('sid', 'desc')
      ->paginate(10);
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $City
    ], 200);
  }

  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'City_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $marketing_subcategory_name       = $request->marketing_subcategory_name;
      $marketing_subcategory_descr        = $request->marketing_subcategory_descr;
      $marketing_category_id           = $request->marketing_category_id;
      $user_id                    = $request->user()->user_id;
      $chk = CityModel::where('marketing_subcategory_name', ucwords($marketing_subcategory_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = CityModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        // if (!$category_check) {

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = "CS-0001/" . $year;
        // } else {

        //   $data = $category_check->job_subcategory_id;
        //   $slice = explode("/", $data);
        //   $result = preg_replace('/[^0-9]/', '', $slice[0]);

        //   $next_number = (int)$result + 1;
        //   $request = sprintf("CS-%04d", $next_number);

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = $request . '/' . $year;
        // }


        $add_category = new CityModel();
        $add_category->marketing_category_id         = $marketing_category_id;
        // $add_category->job_subcategory_id         = $job_subcategory_id;
        $add_category->marketing_subcategory_name       = Ucfirst($marketing_subcategory_name);
        $add_category->markeing_subcategory_descr       = $marketing_subcategory_descr;
        $add_category->branch_id                 = self::$branch_id;
        $add_category->created_by                 = $user_id;
        $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'marketing SubCategory added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job SubCategory!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function edit($id)
  {
    $editCategory = CityModel::select(
      'marketing_subcategory.*',
      'marketing_category.category_name',
      'marketing_category.sno as category_id'
    )
      ->join('marketing_category', 'marketing_subcategory.marketing_category_id', '=', 'marketing_category.sno')
      ->where('marketing_subcategory.sno', $id)
      ->first();

    return response()->json([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editCategory
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'marketing_subcategory_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $marketing_category_id            = $request->marketing_category_id_edit;
      $marketing_subcategory_name       = $request->marketing_subcategory_name;
      $marketing_subcategory_descr       = $request->marketing_subcategory_descr;
      $marketing_category_idd         = $request->marketing_category_id;
      $marketing_subcategory_id         = $request->marketing_subcategory_id;

      $upd_CategoryModel =  CityModel::where('sno', $marketing_subcategory_id)->first();
      // return $upd_JobCategoryModel;

      $chk = CityModel::where('marketing_subcategory_name', ucwords($marketing_subcategory_name))->where('status', '!=', 2)->where('sno', '!=', $marketing_subcategory_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        // return $job_category_id;
        $upd_CategoryModel->marketing_category_id    = $marketing_category_id;
        $upd_CategoryModel->marketing_subcategory_name  = Ucfirst($marketing_subcategory_name);
        $upd_CategoryModel->markeing_subcategory_descr  = $marketing_subcategory_descr;
        $upd_CategoryModel->update();
      }
      if ($upd_CategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'marketing SubCategory Successfully Upadted!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Update the marketing SubCategory!'
        ]);
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CategoryModel =  MarketingKitSubCategoryModel::where('sno', $id)->first();
    $upd_CategoryModel->status  = 2;
    $upd_CategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CategoryModel =  MarketingKitSubCategoryModel::where('sno', $id)->first();
    $upd_CategoryModel->status = $request->input('status', 0);
    $upd_CategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}