<?php

namespace App\Http\Controllers\settings\business;

use App\Http\Controllers\Controller;
use App\Models\JobRoleModel;
use App\Models\DepartmentModel;
use App\Models\CompanyModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ManageEntityModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class BusinessJobRole extends Controller
{

  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $startTime = microtime(true);
    $job_position = JobRoleModel::select(
        'egc_job_role.*',
        'egc_department.department_name',
        'egc_entity.entity_name',
        'egc_company.company_name',
        'egc_entity.entity_short_name',
         'egc_company.company_base_color'
    )
      ->join('egc_department', 'egc_department.sno', '=' , 'egc_job_role.department_id')
      ->join('egc_company', 'egc_job_role.company_id', 'egc_company.sno')
      ->join('egc_entity', 'egc_job_role.entity_id', 'egc_entity.sno')
      ->where('egc_job_role.status', '!=', 2)
      ->where('egc_job_role.company_type', 2);
        if ($search_filter != '') {
          $job_position->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%");
                  
          });
      }
      $job_position =$job_position->orderBy('egc_job_role.sno', 'desc')
      ->paginate($perpage);

   $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $job_position->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'job_role_name' => $item->job_position_name,
                    'department_name' => $item->department_name,
                    'department_id' => $item->department_id,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'entity_short_name' => $item->entity_short_name,
                    'company_base_color' => $item->company_base_color,
                    'per_hour_cost' => $item->per_hour_cost,
                    'job_position_desc' => $item->job_position_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $job_position->currentPage(),
                'last_page' => $job_position->lastPage(),
                'total' => $job_position->total(),
            ]);
        }
      $Department = DepartmentModel::where('egc_department.status',  0)->orderBy('sno', 'asc')
            ->where('egc_department.company_type',2)->get();
      

    // return $job_position;
    $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return view('content.settings.business.job_role.job_role_list',[
      'job_position' => $job_position,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
      'company_list' => $company_list,
      'Department' => $Department
    ]);
  }

  public function list()
  {

    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobRoleModel::where('sub_department_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }
  public function JobPostionList()
  {
    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobRoleModel::
    where('department_id', $dept_id)
    // where('division_id', $dept_id)
    ->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'department_id' => 'required',
       'job_role_name' => 'required_if:erp_job_role_name,new_job_role'

    ]);

     
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $company_id = $request->company_id;
      $entity_id = $request->entity_id;
      $department_id = $request->department_id;
      $division_id = $request->division_id;

      $erp_department_id = $request->erp_department_id;
      $erp_division_id = $request->erp_division_id;
      // If user selected "other", take manual input
      if ($request->erp_job_role_name == 'new_job_role') {
          $job_role_name = $request->job_role_name;
          $erp_job_role_id = $request->erp_job_role_id;
      }
      else {
          $job_role_name = $request->job_role_name_hidden;
          $erp_job_role_id = $request->erp_job_role_name; // sno from ERP
      }

      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;

      // dd($request);

      //  return $request;
      $user_id = $request->user()->user_id;
      $chk = JobRoleModel::where('job_position_name', $job_role_name)->where('company_type', 2)->where('entity_id',$entity_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Job Position has been  already created!',
        ]);
      } else {
        $category_check = JobRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {
            $year = substr(date("y"), -2);
            $job_position_id = "JP-0001/" . $year;
        } else {
            $data = $category_check->job_position_id;
            $slice = explode("/", $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);

            $next_number = (int) $result + 1;
            $job_code_prefix = sprintf("JP-%04d", $next_number);

            $year = substr(date("y"), -2);
            $job_position_id = $job_code_prefix . '/' . $year;
        }

        $add_category = new JobRoleModel();
        $add_category->job_position_id = $job_position_id;
        $add_category->job_position_name = $job_role_name;
        $add_category->department_id = $department_id;
        $add_category->division_id = $division_id;
        $add_category->company_type = 2;
        $add_category->company_id = $company_id;
        $add_category->entity_id = $entity_id;
        $add_category->erp_division_id = $erp_division_id;
        $add_category->erp_department_id = $erp_department_id;
        $add_category->erp_job_role_id = $erp_job_role_id;
        $add_category->per_hour_cost = $per_hour_cost;
        $add_category->job_position_desc = $job_position_desc;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {

          if ($request->erp_job_role_name == 'new_job_role') {
              $this->dispatchWebhooks($add_category, $user_id,'JobRole_Hook');
          }else{
              $this->dispatchWebhooks($add_category, $user_id=1,'Update_JobRole_uuid');
          }
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job position added Successfully!',
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job position!',
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $job_position = JobRoleModel::where('sno', $id)->first();

    // return $job_position;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
    ], 200);
  }


  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_role_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
       $id = $request->edit_id;
      $job_position_name = $request->job_role_name;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;
      $department_id = $request->department_id;

      $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();

      $chk = JobRoleModel::where('job_position_name', $job_position_name)->where('company_type', 2)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_position_name = $job_position_name;
        $upd_CourseCategoryModel->per_hour_cost = $per_hour_cost;
        $upd_CourseCategoryModel->job_position_desc = $job_position_desc;
        $upd_CourseCategoryModel->department_id = $department_id;
        // $upd_CourseCategoryModel->division_id = $division_id;
        $upd_CourseCategoryModel->update();
       if ($upd_CourseCategoryModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Division!'
          ]);
        }
      }
      return redirect()->back();
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel = JobRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }


  // webhook Send
  protected function dispatchWebhooks(JobRoleModel $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast->entity_id)->first();
        if($webhook){
            $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => get_class($broadcast),
              'dispatchable_id' => $broadcast->sno,
              'message_uuid' => $broadcast->sno,
              'payload' => $broadcast->toArray(),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

           // broadcast creation once
            broadcast(new WebhookDispatchedEvent($dispatch));

          // enqueue the job
            try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                if (!$result['success']) {
                    // If fails, dispatch to queue
                    SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
          
  }

    public function AddOldData(Request $request)
    {

      // return $request;
      // Validate incoming request
      $helper = new \App\Helpers\Helpers();
      $validator = Validator::make($request->all(), [
        'staff_company_name' => 'required',
        'staff_entity_name' => 'required',
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id ?? 1;
      
      $company_type=2;
      $company_id=$request->staff_company_name;
      $entity_id=$request->staff_entity_name;

      $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

        if (!$entity_url) {
            return response()->json([
                'status'  => 404,
                'message' => 'Entity URL not found for the given entity ID.',
            ], 200);
        }

        // 🧩 Step 3: Call external API using Http facade
        $verify_key = 'egcsecret2030datagetapierp';
        $api_url = rtrim($entity_url, '/') . '/api/job_role_data_get';

        try {
            $response = Http::get($api_url, ['auth_key' => $verify_key]);

            if (!$response->successful()) {
                return response()->json([
                    'status'  => 500,
                    'message' => 'Failed to fetch Data from entity API.',
                    'error'   => $response->body(),
                ], 200);
            }

            $ErpData = $response->json()['data'] ?? [];
            $filteredErpData = array_filter($ErpData, function($staff) {
                return $staff['external_uuid'] == null;
            });
            $filteredErpData = array_values($filteredErpData);

       


            if (empty($ErpData)) {
                return response()->json([
                    'status'  => 404,
                    'message' => 'No user roles found in API response.',
                ], 200);
            }

            // 🧩 Step 4: Loop and insert roles
            foreach ($ErpData as $staff) {

                $job_role_name = $staff['job_position_name'] ?? null;
                if (!$job_role_name) continue;

                $erp_job_role_id = $staff['sno'] ?? null;
                if (!$erp_job_role_id) continue;

                $erp_division_id = $staff['division_id'] ?? null;
                if (!$erp_division_id) continue;

                $erp_department_id = $staff['department_id'] ?? null;
                if (!$erp_department_id) continue;

                $per_hour_cost = $staff['per_hour_cost'] ?? null;

                $department_id = $helper->get_sno_by_erpId($erp_department_id, 'egc_department', 'erp_department_id',$entity_id);
                $department_id = $department_id ?? 0;

                $division_id = $helper->get_sno_by_erpId($erp_division_id, 'egc_division', 'erp_division_id',$entity_id);
                $division_id = $division_id ?? 0;

                $company_type = 2;

                // 🔍 Check if role already exists
                $chk = JobRoleModel::where('erp_job_role_id', $erp_job_role_id)
                    ->where('entity_id',$entity_id)
                    ->where('status', '!=', 2)
                    ->first();

                if ($chk){
                    $chk->division_name=$division_name;
                    $chk->department_id=$department_id;
                    $chk->division_id=$division_id;
                    $chk->update();
                    $this->dispatchWebhooks($chk, $user_id=1,'Update_JobRole_uuid');
                    continue; 
                }else{
                      $user_id = $request->user()->user_id;
                      $category_check = JobRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                      if (!$category_check) {
                          $year = substr(date("y"), -2);
                          $job_position_id = "JP-0001/" . $year;
                      } else {
                          $data = $category_check->job_position_id;
                          $slice = explode("/", $data);
                          $result = preg_replace('/[^0-9]/', '', $slice[0]);

                          $next_number = (int) $result + 1;
                          $job_code_prefix = sprintf("JP-%04d", $next_number);

                          $year = substr(date("y"), -2);
                          $job_position_id = $job_code_prefix . '/' . $year;
                      }

                      $add_category = new JobRoleModel();
                      $add_category->job_position_id = $job_position_id;
                      $add_category->job_position_name = $job_role_name;
                      $add_category->department_id = $department_id;
                      $add_category->division_id = $division_id;
                      $add_category->company_type = 2;
                      $add_category->company_id = $company_id;
                      $add_category->entity_id = $entity_id;
                      $add_category->erp_division_id = $erp_division_id;
                      $add_category->erp_department_id = $erp_department_id;
                      $add_category->erp_job_role_id = $erp_job_role_id;
                      $add_category->per_hour_cost = $per_hour_cost;
                      $add_category->created_by = $user_id;
                      $add_category->updated_by = $user_id;

                    $add_category->save();

                  

                    if ($add_category) {
                      $this->dispatchWebhooks($add_category, $user_id=1,'Update_JobRole_uuid');
                    }
                }
            }

            return response()->json([
                'status'  => 200,
                'message' => 'Business Job Role imported successfully.',
            ]);

        } catch (\Throwable $e) {
            // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
            return response()->json([
                'status'  => 500,
                'message' => 'Something went wrong while fetching Job Role.',
                'error'   => $e->getMessage(),
            ], 200);
        }
    }

    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }


}
