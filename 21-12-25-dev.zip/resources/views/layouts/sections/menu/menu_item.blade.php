@php
  $currentRouteName = Route::currentRouteName();
  $configData = \App\Helpers\Helpers::appClasses();
  $activeClass = '';
  $menuName = $menu->name ?? $menu->menuName ?? null;

  $active = $configData['layout'] === 'vertical' ? 'active open' : 'active';

  // MENU ACTIVE → If current route starts with menu slug
    if (isset($menu->slug) && str_starts_with($currentRouteName, $menu->slug)) {
        $activeClass = $active;
    }

    // Detect submenu/lastmenu deeper activation
    if (isset($menu->submenu)) {
        foreach ($menu->submenu as $submenu) {
            
            // SUBMENU ACTIVE
            if (isset($submenu->slug) && str_starts_with($currentRouteName, $submenu->slug)) {
                $activeClass = $active;
            }

            // LASTMENU ACTIVE
            if (isset($submenu->submenu)) {
                foreach ($submenu->submenu as $lastmenu) {
                    if ($currentRouteName === ($lastmenu->slug ?? '')) {
                        $activeClass = $active;
                    }
                }
            }
        }
    }

  $hasSubmenu = isset($menu->submenu);
@endphp

<li class="menu-item {{ $activeClass }}">
  <a href="{{ isset($menu->url) ? url($menu->url) : 'javascript:void(0);' }}"
     class="{{ $hasSubmenu ? 'menu-link menu-toggle' : 'menu-link' }}"
     @if(isset($menu->target) && !empty($menu->target)) target="_blank" @endif>

    @isset($menu->icon)
      <i class="{{ $menu->icon }}"></i>
    @endisset

    <div class="fs-7 fw-medium d-flex align-items-center">
      {{ __($menuName) }}
    </div>

    @isset($menu->badge)
      <div class="badge bg-{{ $menu->badge[0] }} rounded-pill ms-auto">
        {{ $menu->badge[1] }}
      </div>
    @endisset
  </a>

  {{-- SUBMENU --}}
  @if ($hasSubmenu)
    <ul class="menu-sub">
      @foreach ($menu->submenu as $submenu)
        @php
          $submenuName = $submenu->name ?? $submenu->submenuName ?? null;
        @endphp

        {{-- Check submenu permission --}}
        @if(auth()->user()->hasPermission($menuName, $submenuName))
          <li class="menu-item {{ str_starts_with($currentRouteName, $submenu->slug ?? '') ? 'active open' : '' }}">
            <a href="{{ isset($submenu->url) ? url($submenu->url) : 'javascript:void(0);' }}"
               class="{{ isset($submenu->submenu) ? 'menu-link menu-toggle' : 'menu-link' }}"
               @if(isset($submenu->target) && !empty($submenu->target)) target="_blank" @endif>

              @isset($submenu->icon)
                <i class="{{ $submenu->icon }}"></i>
              @endisset

              <div class="fs-7 fw-medium">
                {{ __($submenuName) }}
              </div>
            </a>

            {{-- LASTMENU --}}
            @if(isset($submenu->submenu))
              <ul class="menu-sub">
                @foreach ($submenu->submenu as $lastmenu)
                  @php
                    $lastmenuName = $lastmenu->name ?? $lastmenu->lastmenuName ?? null;
                  @endphp

                  {{-- Check lastmenu permission --}}
                  @if(auth()->user()->hasPermission($menuName, $submenuName, $lastmenuName))
                    <li class="menu-item {{ $currentRouteName === ($lastmenu->slug ?? '') ? 'active' : '' }}">
                      <a href="{{ isset($lastmenu->url) ? url($lastmenu->url) : 'javascript:void(0);' }}"
                         class="menu-link"
                         @if(isset($lastmenu->target) && !empty($lastmenu->target)) target="_blank" @endif>

                        @isset($lastmenu->icon)
                          <i class="{{ $lastmenu->icon }}"></i>
                        @endisset

                        <div class="fs-7 fw-medium">
                          {{ __($lastmenuName) }}
                        </div>
                      </a>
                    </li>
                  @endif
                @endforeach
              </ul>
            @endif
          </li>
        @endif
      @endforeach
    </ul>
  @endif
</li>
