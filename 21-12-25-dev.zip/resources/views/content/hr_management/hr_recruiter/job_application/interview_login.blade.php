@extends('layouts/blankLayout')

@section('title', 'EGC Job Application')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

    <style>
body {
    background: radial-gradient(circle at top, #ff8c00 0%, #ab2b22 45%, #8f1f18 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Inter', system-ui, sans-serif;
}

.login-wrapper {
    max-width: 980px;
    width: 100%;
}

.login-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 40px 80px rgba(0,0,0,.25);
    overflow: hidden;
}

.login-left {
    background: linear-gradient(160deg, #ab2b22, #ff8c00);
    color: #fff;
    padding: 70px 55px;
}

.login-left h2 {
    font-weight: 700;
    line-height: 1.2;
}

.login-left p {
    font-size: 15px;
    opacity: .95;
    margin-top: 16px;
}

.login-right {
    padding: 60px 55px;
    background: #fff;
}

.login-box {
    background: #ffffff;
    border-radius: 16px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(0,0,0,.08);
}

.logo {
    max-width: 170px;
    margin-bottom: 20px;
}

.form-control {
    height: 52px;
    border-radius: 12px;
    font-size: 14px;
}

.form-control:focus {
    border-color: #ff8c00;
    box-shadow: 0 0 0 4px rgba(255,140,0,.2);
}

.btn-main {
    height: 52px;
    border-radius: 12px;
    font-weight: 600;
    background: linear-gradient(135deg, #ab2b22, #ff8c00);
    border: none;
    color: #fff;
}

.btn-main:disabled {
    opacity: .7;
}

.link-btn {
    font-size: 13px;
    color: #ab2b22;
    cursor: pointer;
    font-weight: 500;
}

.error-text {
    font-size: 13px;
    color: #d93025;
    margin-top: 8px;
}

.footer-text {
    font-size: 12px;
    color: #888;
    margin-top: 25px;
}

@media (max-width: 768px) {
    .login-left {
        display: none;
    }
    .login-right {
        padding: 30px 20px;
    }
    .login-box {
        padding: 30px 22px;
    }
}
</style>


@section('content')
<div class="login-wrapper container px-3">
    <div class="login-card row g-0">

        <!-- LEFT -->
        <div class="col-md-6 login-left d-flex flex-column justify-content-center">
            <h2>Interview Portal</h2>
            <p>
                Secure interview environment.<br>
                Please ensure camera, microphone and stable internet before proceeding.
            </p>
        </div>

        <!-- RIGHT -->
        <div class="col-md-6 login-right">
            <div class="login-box text-center">

                <img src="{{ asset('assets/common/logo_full.png') }}" class="logo" alt="Logo">

                <h5 class="mb-4 fw-semibold">Candidate Login</h5>

                <!-- LOGIN FORM -->
                <form id="loginForm">
                    @csrf

                    <div class="mb-3 text-start">
                        <label class="form-label">Full Name</label>
                        <input type="text" id="full_name" class="form-control" placeholder="Enter your full name">
                    </div>

                    <div class="mb-3 text-start">
                        <label class="form-label">Mobile Number</label>
                        <input type="text" id="mobile" class="form-control" placeholder="Enter mobile number">
                    </div>

                    <div class="mb-3 text-start">
                        <label class="form-label">Email Address</label>
                        <input type="email" id="email" class="form-control" placeholder="Enter email address">
                    </div>

                    <!-- OTP FIELD -->
                    <div class="mb-3 text-start d-none" id="otpBlock">
                        <label class="form-label">OTP</label>
                        <input type="text" id="otp" class="form-control" placeholder="Enter OTP">
                    </div>

                    <div class="error-text d-none" id="errorMsg"></div>

                    <button type="button" class="btn btn-main w-100 mt-3" id="actionBtn">
                        Send OTP
                    </button>

                    <div class="mt-3">
                        <span class="link-btn" id="resendOtp" style="display:none;">
                            Resend OTP
                        </span>
                    </div>
                </form>


                <div class="footer-text">
                    © {{ date('Y') }} EGC. All rights reserved.
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let otpSent = false;

$('#actionBtn').on('click', function () {
    $('#errorMsg').addClass('d-none').text('');

    const fullName = $('#full_name').val().trim();
    const mobile   = $('#mobile').val().trim();
    const email    = $('#email').val().trim();
    const otp      = $('#otp').val().trim();

    if (!fullName) return showError('Please enter full name');
    if (!mobile || !/^[6-9]\d{9}$/.test(mobile))
        return showError('Please enter valid mobile number');
    if (!email || !/^\S+@\S+\.\S+$/.test(email))
        return showError('Please enter valid email address');

    if (otpSent && !otp)
        return showError('Please enter OTP');

    $('#actionBtn').prop('disabled', true).text('Please wait...');

    $.ajax({
        url: otpSent
            ? '{{ route("interview.verifyOtp") }}'
            : '{{ route("interview.sendOtp") }}',
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',
            full_name: fullName,
            mobile: mobile,
            email: email,
            otp: otp
        },
        success(res) {
            if (!otpSent) {
                otpSent = true;
                $('#otpBlock').removeClass('d-none');
                $('#resendOtp').show();
                $('#actionBtn').prop('disabled', false).text('Verify & Start Interview');
            } else {
                window.location.href = res.redirect;
            }
        },
        error(xhr) {
            showError(xhr.responseJSON?.message || 'Something went wrong');
            $('#actionBtn').prop('disabled', false)
                .text(otpSent ? 'Verify & Start Interview' : 'Send OTP');
        }
    });
});

function showError(msg) {
    $('#errorMsg').removeClass('d-none').text(msg);
}
</script>


@endsection
