@extends('layouts/layoutMaster')

@section('title', 'Manage Entity')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Entity</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                        <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                    <div class="row">
                        <div class="col-lg-4 border-end border-danger">
                            <div class="row">
                                <label class="col-5 fw-semibold fs-6 text-danger">Entity</label>
                                <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                                <label class="col-6 fw-bold fs-6 text-danger">PhD iZone</label>
                            </div>
                        </div>
                        <div class="col-lg-4 border-end border-danger">
                            <div class="row">
                                <label class="col-5 fw-semibold fs-6 text-danger">Company</label>
                                <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                                <label class="col-6 fw-bold fs-6 text-danger">Elysium Techonologies Pvt LTd</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                        <a href="javascript:void(0)" onclick="clearFilter()" 
                        class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                            Clear Filter
                        </a>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 gap-2">
                        <div>
                            <span>Show</span>
                            <br>
                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                                <option value="10">10</option>
                                <option value="25" selected>25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input class="searchQueryInput" type="text" name="searchQueryInput" placeholder="Enter Entity Name/ Mobile No" value="" />
                                <a href="{{url('entity_hub/manage_entity')}}" class="searchQuerySubmit" type="submit" name="searchQuerySubmit">
                                    <svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Entity</th>
                                <th class="min-w-150px">Company</th>
                                <th class="min-w-100px">Contact Person / Mobile</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="text-truncate max-w-175px fw-medium fs-7" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" data-bs-original-title="PhDiZone">PhDiZone</div>
                                        <a href="https://elysiumtechnologies.com/" target="_blank" class="ms-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Website URL"
                                            data-bs-original-title="Website URL">
                                            <i class="mdi mdi-web fs-4 text-dark"></i>
                                        </a>
                                    </div>
                                    <div class="d-block">
                                        <label class="fs-8 text-black fw-semibold">presale@phdizone.com</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex allign-items-center gap-2">
                                        <div>
                                            <div class="d-flex align-items-center">
                                                <div class="text-truncate max-w-175px fw-medium fs-7"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Elysian Intelligence Business Solution">Elysium Technologies
                                                </div>
                                            </div>
                                            <div class="d-block">
                                                <label class="badge bg-warning fs-8 text-black fw-bold">Private Limited
                                                    Company (Pvt Ltd)</label>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <label>Muthumari A</label>
                                    <div class="d-block">
                                        <label class="fs-8 text-black fw-semibold">9894444710</label>
                                    </div>
                                </td>
                                <td>
                                    <label class="switch switch-square">
                                        <input type="checkbox" class="switch-input" checked />
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1 waves-effect waves-light"
                                            data-bs-toggle="modal" data-bs-target="#kt_modal_add_department">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                aria-label="Add Department" data-bs-original-title="Add Department"><i
                                                    class="mdi mdi-file-tree fs-3 text-black"></i></span>
                                        </a>
                                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1 waves-effect waves-light"
                                            data-bs-toggle="modal" data-bs-target="#kt_modal_add_division">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                aria-label="Add Division" data-bs-original-title="Add Division"><i
                                                    class="mdi mdi-graph fs-4 text-black"></i></span>
                                        </a>
                                        <a class="btn btn-icon btn-sm waves-effect waves-light" data-bs-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end" style="width:200px !important">
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_view_entity">
                                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_update_entity">
                                                <span><i
                                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                            </a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_delete_entity">
                                                <span><i
                                                        class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal Filter--->
    <div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Filter</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                    <div class="row mb-3">
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company / Entity Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company / Entity Name">
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                            <select id="dept_name" name="dept_name" class="select3 form-select">
                                <option value="">Select Department Name</option>
                                <option value="1">Production</option>
                                <option value="2">Sales</option>
                                <option value="3">Internal Management</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                            <select id="div_name" name="div_name" class="select3 form-select">
                                <option value="">Select Division Name</option>
                                <option value="1">Pre Sales</option>
                                <option value="2">Post Sales</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                            <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                <option value="all">All</option>
                                <option value="today">Today</option>
                                <option value="week">This Week</option>
                                <option value="monthly">This Month</option>
                                <option value="custom_date">Custom Date</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                        <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                        <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                        <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                    </div>
                </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Filter-->


    <!--begin::Modal - Create Department -->
    <div class="modal fade" id="kt_modal_add_department" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Department</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                            <div class="bg-label-primary border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="entity_display" name="entity_display">Phdizone</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Department Name" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Description" id="department_desc"
                                name="department_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Department</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Department-->


    <!--begin::Modal - Create Division -->
    <div class="modal fade" id="kt_modal_add_division" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Division</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                            <div class="bg-label-primary border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="entity_display" name="entity_display">Elysium Technologies</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                    class="text-danger">*</span></label>
                            <select id="DepartmentDivision" class="select3 form-select ">
                                <option value="">Select Department</option>
                                <option value="">Sales</option>
                                <option value="">Production</option>
                                <option value="">Support</option>
                                <option value="">Management</option>

                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" />
                        </div>

                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Description" id="department_desc"
                                name="department_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Division</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Division-->

    <!--begin::Modal - Update Entity -->
    <div class="modal fade" id="kt_modal_update_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Entity</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                    class="text-danger">*</span></label>
                            <select id="Department" class="select3 form-select ">
                                <option value="">Select Department</option>
                                <option value="" selected>Elysium Technologies Pvt Ltd</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" value="PhDiZone">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID"
                                value="presale@phdizone.com">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL"
                                value="https://phdizone.com/">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CRM URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CRM URL"
                                value="https://dev.erp.elysiumtechnologies.com/">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="location_url" name="location_url"
                                placeholder="Enter Location URL">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                value="Muthumari A">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                value="9944049888">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select id="Countryupdate" class="select3 form-select ">
                                <option value="">Select Country</option>
                                <option value="" selected>India</option>
                                <option value="">USA</option>
                                <option value="">UAE</option>
                                <option value="">Japan</option>

                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select id="Stateupdate" class="select3 form-select ">
                                <option value="">Select State</option>
                                <option value="" selected>Tamil Nadu</option>
                                <option value="">Kerala</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select id="Cityupdate" class="select3 form-select ">
                                <option value="">Select City</option>
                                <option value="" selected>Madurai</option>
                                <option value="">Chennai</option>

                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street"
                                value="Ist &amp; IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar"
                                id="edit_area" name="edit_area">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" value="229"
                                id="edit_door" name="edit_door">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" value="625020"
                                id="edit_pincode" name="edit_pincode">

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                            <input type="text" class="form-control" placeholder="Enter GST No"
                                value="29AAGFV1234M1Z6" id="edit_gst_no" name="edit_gst_no">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                            <input type="text" class="form-control" placeholder="Enter CIN No"
                                value="U67190KA2012LLP012345" id="edit_cin_no" name="edit_cin_no">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" value="AAGFV1234M"
                                id="edit_pan_no" name="edit_pan_no">
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description" id="edit_desc" name="edit_desc">-</textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" value="HDFC" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                value="Anna Nagar" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder"
                                value="phdizone" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No"
                                value="6523145278745" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                value="HDFC0002027" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Update Entity</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Entity-->


    <!--begin::Modal View Entity--->
    <div class="modal fade" id="kt_modal_view_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                        <div class="avatar-stack">
                              <img src="{{ asset('assets/egc_images/newImgs/corporate-building.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/egc_images/newImgs/skyscraper-building.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/egc_images/newImgs/hotel-building.png') }}" alt="user-avatar" class="avatar-img" />
                        </div>
                        <div class="row mb-2">
                            <h3 class="text-black">View Entity</h3>
                        </div>
                    </div>
                </div>

                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="row mb-3">
                        <div class="nav-align-top nav-tabs-shadow mb-3">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                        Company Info
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#legaltax" aria-controls="legaltax" aria-selected="false">
                                        Legal / Tax
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#bankinfo" aria-controls="bankinfo"
                                        aria-selected="false">
                                        Bank Info
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                      <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Entity</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="PhDiZone">PhDiZone
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Company</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Elysium Technologies Pvt Ltd">
                                                   Elysium Technologies Pvt Ltd
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Email ID</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="presale@phdizone.com">presale@phdizone.com</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-6 fw-semibold">Website URL</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <a href="https://phdizone.com/" target="_blank"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="https://eibsglobal.com/">
                                                    <div class="text-truncate max-w-75 text-black fs-7  fw-semibold">
                                                       https://phdizone.com/</div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Contact Person</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Sankar Ganesh">
                                                   Muthumari A</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="legaltax" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="27AABCU9603R1ZV">
                                                    27AABCU9603R1ZV</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="U12345MH2005PTC123456">U12345MH2005PTC123456
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="AABCU9603R">
                                                    AABCU9603R</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="bankinfo" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">HDFC</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">Anna Nagar</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">HDFC0002027</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">Elysium Intelligence Business
                                                Solutions</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">8574854578452</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -View Entity-->

    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">PhDiZone </b>
                        Entity ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-white" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "pageLength": 25,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function () {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
@endsection
