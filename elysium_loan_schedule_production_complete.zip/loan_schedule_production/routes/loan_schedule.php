<?php

use App\Http\Controllers\AccountsFinance\LoanScheduleController;
use App\Http\Controllers\AccountsFinance\LoanReportController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:web', 'throttle:120,1'])
    ->prefix('accounts_finance/loans')
    ->name('accounts_finance.loans.')
    ->group(function () {
        Route::get('/', [LoanScheduleController::class, 'index'])->name('index');
        Route::get('/calendar', [LoanScheduleController::class, 'calendarPage'])->name('calendar');
        Route::get('/reports', [LoanReportController::class, 'index'])->name('reports.index');
        Route::get('/reports/data', [LoanReportController::class, 'data'])->name('reports.data');
        Route::get('/reports/export', [LoanReportController::class, 'export'])->name('reports.export');
        Route::get('/dashboard/data', [LoanScheduleController::class, 'dashboard'])->name('dashboard.data');
        Route::get('/calendar/data', [LoanScheduleController::class, 'calendar'])->name('calendar.data');
        Route::get('/data', [LoanScheduleController::class, 'data'])->name('data');
        Route::get('/lookups', [LoanScheduleController::class, 'lookups'])->name('lookups');
        Route::post('/', [LoanScheduleController::class, 'store'])->name('store');

        Route::get('/{loan}', [LoanScheduleController::class, 'detail'])
            ->whereNumber('loan')
            ->name('show');

        Route::get('/{loan}/data', [LoanScheduleController::class, 'show'])
            ->whereNumber('loan')
            ->name('data.show');

        Route::post('/{loan}/approve', [LoanScheduleController::class, 'approve'])
            ->whereNumber('loan')
            ->name('approve');

        Route::post('/{loan}/return', [LoanScheduleController::class, 'reject'])
            ->whereNumber('loan')
            ->name('return');

        Route::post('/{loan}/payments', [LoanScheduleController::class, 'payment'])
            ->whereNumber('loan')
            ->name('payments.store');

        Route::post('/{loan}/prepay/preview', [LoanScheduleController::class, 'prepayPreview'])
            ->whereNumber('loan')
            ->name('prepay.preview');

        Route::post('/{loan}/prepay', [LoanScheduleController::class, 'prepay'])
            ->whereNumber('loan')
            ->name('prepay');

        Route::post('/{loan}/prepay/approve', [LoanScheduleController::class, 'approvePrepay'])
            ->whereNumber('loan')
            ->name('prepay.approve');

        Route::post('/{loan}/restructure/preview', [LoanScheduleController::class, 'restructurePreview'])
            ->whereNumber('loan')
            ->name('restructure.preview');

        Route::post('/{loan}/restructure', [LoanScheduleController::class, 'restructure'])
            ->whereNumber('loan')
            ->name('restructure');

        Route::post('/{loan}/restructure/approve', [LoanScheduleController::class, 'approveRestructure'])
            ->whereNumber('loan')
            ->name('restructure.approve');

        Route::post('/{loan}/close', [LoanScheduleController::class, 'close'])
            ->whereNumber('loan')
            ->name('close');

        Route::post('/{loan}/renewal', [LoanScheduleController::class, 'renewal'])
            ->whereNumber('loan')
            ->name('renewal');

        Route::post('/{loan}/utilisation', [LoanScheduleController::class, 'utilisation'])
            ->whereNumber('loan')
            ->name('utilisation');

        Route::post('/obligations/{obligation}/snooze', [LoanScheduleController::class, 'snooze'])
            ->whereNumber('obligation')
            ->name('obligations.snooze');
    });
