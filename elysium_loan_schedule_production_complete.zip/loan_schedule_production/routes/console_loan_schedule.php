<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('loan:dispatch-notifications')
    ->dailyAt('08:00')
    ->timezone(config('loan.timezone', 'Asia/Kolkata'))
    ->withoutOverlapping(10)
    ->onOneServer();
