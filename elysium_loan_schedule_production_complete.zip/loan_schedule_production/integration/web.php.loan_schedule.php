<?php

// Add this line once to the existing ERP routes/web.php.
// Do not duplicate the route group itself in routes/web.php.
require_once base_path('routes/loan_schedule.php');
