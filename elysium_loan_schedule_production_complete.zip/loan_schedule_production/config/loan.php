<?php

return [
    'entity_table' => env('EGLS_ENTITY_TABLE', 'egc_entity'),
    'entity_id_column' => env('EGLS_ENTITY_ID_COLUMN', 'sno'),
    'entity_name_column' => env('EGLS_ENTITY_NAME_COLUMN', 'entity_name'),
    'entity_status_column' => env('EGLS_ENTITY_STATUS_COLUMN', 'status'),
    'active_status_value' => env('EGLS_ENTITY_ACTIVE_STATUS', 0),

    // Existing ERP bank/account master. Keep null to disable pay-from lookup until mapped.
    'bank_account_table' => env('EGLS_BANK_ACCOUNT_TABLE', null),
    'bank_account_id_column' => env('EGLS_BANK_ACCOUNT_ID_COLUMN', 'sno'),
    'bank_account_name_column' => env('EGLS_BANK_ACCOUNT_NAME_COLUMN', 'account_name'),
    'bank_account_status_column' => env('EGLS_BANK_ACCOUNT_STATUS_COLUMN', 'status'),
    'bank_account_active_status' => env('EGLS_BANK_ACCOUNT_ACTIVE_STATUS', 0),

    'pagination' => 50,
    'timezone' => 'Asia/Kolkata',

    'loan_types' => [
        'vehicle' => ['label' => 'Vehicle Loan', 'icon' => '🚗'],
        'term' => ['label' => 'Business Term Loan', 'icon' => '📄'],
        'jewel' => ['label' => 'Jewel Loan', 'icon' => '💍'],
        'cc' => ['label' => 'Cash Credit', 'icon' => '🏦'],
    ],

    'status' => [
        'draft', 'pending_approval', 'active', 'closed', 'foreclosed', 'restructured', 'returned',
    ],

    'payment_modes' => ['NACH', 'NEFT/RTGS', 'Cash', 'Cheque'],

    'default_notifications' => [
        'emi' => [7, 1],
        'cc_renewal' => [45, 30, 15],
        'jewel_redemption' => [30, 15, 7],
    ],

    // Optional role-to-email fallbacks used by the notifier until the ERP's
    // existing notification/user resolver is mapped. Comma-separated emails.
    'notification_recipients' => [
        'accounts' => array_values(array_filter(array_map('trim', explode(',', (string) env('EGLS_LOAN_ACCOUNTS_EMAILS', ''))))),
        'finance' => array_values(array_filter(array_map('trim', explode(',', (string) env('EGLS_LOAN_FINANCE_EMAILS', ''))))),
        'sponsor' => array_values(array_filter(array_map('trim', explode(',', (string) env('EGLS_LOAN_SPONSOR_EMAILS', ''))))),
    ],
];
