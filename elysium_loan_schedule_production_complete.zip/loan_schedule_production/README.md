# Elysium ERP — Loan & Schedule Module

Production Laravel 11/MySQL 8 module structure aligned to the supplied Elysium Groups Loan & Schedule PDD and the supplied prototype screenshot.

## UI direction

The UI follows the supplied prototype/screenshot: ERP navy `#1F3864`, finance green `#1E6B4A`, gold `#C9A227`, page `#F4F6F9`, white cards, light borders, compact status chips, tabbed loan detail, action dropdown, and responsive table/calendar layouts.

The supplied PDD requires a borrower-side register for Vehicle, Business Term, Jewel and Cash Credit loans, plus a consolidated month/week/list schedule calendar. The production Blade implementation keeps the ERP's existing Laravel/Bootstrap conventions rather than introducing a new frontend framework.

## File tree

- `app/Http/Controllers/AccountsFinance/LoanScheduleController.php`
- `app/Models/Loan.php`
- `app/Models/LoanLender.php`
- `app/Models/LoanVehicleDetail.php`
- `app/Models/LoanTranche.php`
- `app/Models/LoanJewelPledge.php`
- `app/Models/LoanJewelItem.php`
- `app/Models/LoanCcFacility.php`
- `app/Models/LoanCcUtilisation.php`
- `app/Models/LoanSchedule.php`
- `app/Models/LoanScheduleLine.php`
- `app/Models/LoanObligation.php`
- `app/Models/LoanPayment.php`
- `app/Models/LoanRenewalChecklist.php`
- `app/Models/LoanRenewalChecklistItem.php`
- `app/Models/LoanNotificationRule.php`
- `app/Models/LoanNotification.php`
- `app/Models/LoanDocument.php`
- `app/Models/LoanHoliday.php`
- `app/Models/LoanAuditLog.php`
- `app/Services/Loan/LoanScheduleService.php`
- `app/Services/Loan/LoanAuditService.php`
- `database/migrations/2026_09_09_000000_create_loan_schedule_module_tables.php`
- `database/sql/loan_schedule_module.sql`
- `routes/loan_schedule.php`
- `resources/views/content/accounts_finance/loans/index.blade.php`
- `resources/views/content/accounts_finance/loans/show.blade.php`
- `resources/views/content/accounts_finance/loans/partials/add-loan-modal.blade.php`
- `resources/views/content/accounts_finance/loans/partials/payment-modal.blade.php`
- `resources/css/pages/loan-schedule.css`
- `resources/js/pages/loan-schedule.js`
- `resources/js/pages/loan-detail.js`
- `config/loan.php`

## Main web.php include

Add this once in the existing ERP `routes/web.php`:

```php
require_once base_path('routes/loan_schedule.php');
```

Do not duplicate the route group in two places.

## Vite assets

The Blade files expect these existing ERP vendor bundles:

```text
resources/assets/vendor/libs/select2/select2.js
resources/assets/vendor/libs/select2/select2.scss
resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js
resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss
```

Add the two page assets through the project's normal Vite build:

```text
resources/js/pages/loan-schedule.js
resources/js/pages/loan-detail.js
resources/css/pages/loan-schedule.css
```

## Entity and bank-account master mapping

The PDD says entities and bank accounts come from the existing ERP master. Because the supplied files do not identify the exact production table/column names, these are configurable in `.env` through `config/loan.php`.

```env
EGLS_ENTITY_TABLE=egc_entity
EGLS_ENTITY_ID_COLUMN=sno
EGLS_ENTITY_NAME_COLUMN=entity_name
EGLS_ENTITY_STATUS_COLUMN=status
EGLS_ENTITY_ACTIVE_STATUS=0

EGLS_BANK_ACCOUNT_TABLE=
EGLS_BANK_ACCOUNT_ID_COLUMN=sno
EGLS_BANK_ACCOUNT_NAME_COLUMN=account_name
EGLS_BANK_ACCOUNT_STATUS_COLUMN=status
EGLS_BANK_ACCOUNT_ACTIVE_STATUS=0
```

Set the bank table variables to the actual finance/bank-account master before enabling the Pay From Account selector in production.

## RBAC integration

The PDD specifies Group Admin, Finance Head, Accounts Executive, Entity Manager, Management Viewer and Auditor roles. The controller contains a deliberately isolated authorization hook using the ERP user's `loan_permissions`, `is_finance_head`, `is_accounts_executive` and `loan_entity_scope` attributes.

Map these to the ERP's real permission service before production go-live. Do not expose approval permissions by trusting arbitrary request input.

Expected permission keys used by this module:

```text
add
pay
approve
ack
```

Entity scoping is expected as an array of entity IDs in `loan_entity_scope`.

## Database

The supplied PDD's conceptual model contains these principal tables:

```text
loan_lenders
loans
loan_vehicle_details
loan_tranches
loan_jewel_pledges
loan_jewel_items
loan_cc_facilities
loan_cc_utilisations
loan_schedules
loan_schedule_lines
loan_obligations
loan_payments
loan_renewal_checklists
loan_renewal_checklist_items
loan_notification_rules
loan_notifications
loan_documents
loan_holidays
loan_audit_log
```

Run either the Laravel migration or the supplied SQL script, not both.

```bash
php artisan migrate
```

or execute `database/sql/loan_schedule_module.sql` through the approved deployment migration process.

## Schedule engine behavior

Vehicle and term loans generate a versioned amortisation schedule. Reducing-balance and flat-rate methods are supported. Monthly and quarterly frequency are handled as payment periods. Only the active schedule creates current calendar obligations; superseded future obligations are removed when a new schedule version becomes active.

The PDD requires schedule verification against lender schedules with a ±₹1 per-installment target. The production implementation should be verified against at least 12 real lender schedules during UAT before go-live.

## Calendar

The index Blade includes:

- Month view
- Week view
- List/agenda view
- Entity filter
- Loan type filter
- Status filter
- More-than-three-items expansion per day
- Click-to-detail popover
- Record Payment
- Snooze
- Open Loan

The calendar uses `loan_obligations` rather than reading schedule rows directly so EMIs, interest dues, CC renewals, stock statements and jewel redemptions can share one calendar model.

## Loan Detail

The detail screen includes:

- Overview
- Schedule
- Payments
- Documents
- Audit
- Amount Left to Pay
- Tenure progress
- Approval controls
- Record Payment
- Part-Prepay / Foreclose entry point
- Closure checklist

The supplied screenshot's Audit timeline and Actions dropdown are represented directly in the production detail UI.

## Validation / smoke checklist

1. `php artisan route:list | grep accounts_finance.loans`
2. `php artisan migrate --pretend`
3. Clear and rebuild Vite assets.
4. Open Loan Register.
5. Confirm entity and lender lookups.
6. Create one Vehicle Loan and one Term Loan.
7. Finance Head approves.
8. Verify a versioned schedule is created.
9. Verify future schedule lines appear in the calendar.
10. Record a payment from calendar.
11. Verify obligation becomes Paid / Part Paid.
12. Open Loan Detail and verify Schedule and Audit tabs.
13. Test Month → Week → List switching.
14. Test entity/type/status filters together.
15. Test 390px, 768px and 1366px widths.
16. Test role and entity-scope restrictions.
17. Verify backup, audit retention and deployment process before UAT.

## Deliberate integration points

The supplied PDD states that final entity names, holiday calendar source, exact escalation ladder, optional ICS feed, and SMS/WhatsApp gateway are open design-signoff items. Those should be connected after their production source is confirmed rather than hard-coded into the module.

The module records and reminds; it does not initiate bank transfers or automatic NACH/payment execution.

## Dedicated calendar page

`/accounts_finance/loans/calendar` renders the same Month / Week / List obligation calendar as a first-class ERP page. It reuses the same AJAX endpoint and payment modal, so an obligation can be paid from the calendar without navigating away.

## Reports

`/accounts_finance/loans/reports` adds PDD reports R1–R9 with server-side entity scope and date/type filters. XLSX export uses Laravel-Excel and PDF export uses DomPDF, matching the PDD technology stack. If either package is absent in the ERP, install them before enabling those export buttons.

Expected packages:

```bash
composer require maatwebsite/excel barryvdh/laravel-dompdf
```

## Restructure

Loan Detail now exposes the Restructure action for Vehicle and Business Term Loans. The flow is maker → Finance Head checker, with a pending schedule version, preview of new rate/tenure/EMI, approval activation, and audit logging.

## Notifier

`LoanNotifierService` and `loan:dispatch-notifications` are included. The command is safe to re-run because notification rows use an idempotency key. Go-live should connect its role recipient resolver to the existing ERP user/notification directory. Temporary email fallbacks are configurable via:

```env
EGLS_LOAN_ACCOUNTS_EMAILS=
EGLS_LOAN_FINANCE_EMAILS=
EGLS_LOAN_SPONSOR_EMAILS=
```

Register the daily command in the ERP scheduler (the PDD target is a daily notifier run). An example scheduler file is included as `routes/console_loan_schedule.php`.

## Production architecture alignment

The module remains a Laravel 11 / MySQL 8 in-ERP module: Blade + Bootstrap UI, domain services for schedule/audit/notifier rules, MySQL module tables, and scheduler/queue integration. This follows the PDD's layered-monolith direction rather than introducing a separate application.
