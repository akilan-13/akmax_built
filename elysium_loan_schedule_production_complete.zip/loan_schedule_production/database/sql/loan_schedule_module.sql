-- Elysium Groups ERP — Loan & Schedule Module
-- MySQL 8 / Laravel 11
-- Internal module tables only. ERP entity/user/document masters remain external.

CREATE TABLE IF NOT EXISTS `loan_lenders` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `lender_name` VARCHAR(180) NOT NULL,
  `lender_type` VARCHAR(30) NOT NULL DEFAULT 'bank',
  `branch_name` VARCHAR(180) NULL,
  `contact_person` VARCHAR(150) NULL,
  `phone` VARCHAR(30) NULL,
  `email` VARCHAR(190) NULL,
  `address` TEXT NULL,
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '0 active, 2 deleted',
  `created_by` BIGINT UNSIGNED NULL,
  `updated_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_loan_lenders_status_name` (`status`,`lender_name`),
  KEY `idx_loan_lenders_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loans` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `entity_id` BIGINT NULL,
  `entity_name` VARCHAR(180) NULL COMMENT 'snapshot for fast reporting; master remains ERP core',
  `lender_id` BIGINT UNSIGNED NOT NULL,
  `loan_account_no` VARCHAR(120) NOT NULL,
  `loan_name` VARCHAR(180) NULL,
  `loan_type` VARCHAR(20) NOT NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'draft',
  `sanction_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `disbursed_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `interest_rate` DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
  `interest_type` VARCHAR(30) NOT NULL DEFAULT 'reducing_balance',
  `schedule_method` VARCHAR(30) NULL,
  `frequency` VARCHAR(20) NOT NULL DEFAULT 'monthly',
  `start_date` DATE NULL,
  `tenure_months` INT NULL,
  `emi_amount` DECIMAL(18,2) NULL,
  `maturity_date` DATE NULL,
  `pay_from_account_id` BIGINT NULL,
  `security_details` TEXT NULL,
  `purpose_id` BIGINT NULL,
  `remarks` TEXT NULL,
  `submitted_at` DATETIME NULL,
  `approved_at` DATETIME NULL,
  `approved_by` BIGINT NULL,
  `closed_at` DATETIME NULL,
  `closure_reason` VARCHAR(255) NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_loans_lender_account` (`lender_id`,`loan_account_no`),
  KEY `idx_loans_entity_status` (`entity_id`,`status`),
  KEY `idx_loans_type_status` (`loan_type`,`status`),
  KEY `idx_loans_maturity` (`maturity_date`),
  KEY `idx_loans_next_core` (`status`,`loan_type`,`start_date`),
  CONSTRAINT `fk_loans_lender` FOREIGN KEY (`lender_id`) REFERENCES `loan_lenders` (`sno`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_vehicle_details` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `registration_no` VARCHAR(60) NOT NULL,
  `make_model` VARCHAR(180) NOT NULL,
  `chassis_no` VARCHAR(120) NULL,
  `engine_no` VARCHAR(120) NULL,
  `hypothecated_to_lender` TINYINT(1) NOT NULL DEFAULT 1,
  `insurance_renewal_date` DATE NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_loan_vehicle` (`loan_id`),
  KEY `idx_vehicle_registration` (`registration_no`),
  CONSTRAINT `fk_vehicle_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_tranches` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `tranche_no` INT NOT NULL,
  `disbursed_date` DATE NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `remarks` VARCHAR(255) NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_tranche_no` (`loan_id`,`tranche_no`),
  CONSTRAINT `fk_tranche_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_jewel_pledges` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `pledge_receipt_no` VARCHAR(120) NOT NULL,
  `pledged_at_branch` VARCHAR(180) NULL,
  `interest_pattern` VARCHAR(30) NOT NULL DEFAULT 'monthly',
  `redemption_due_date` DATE NOT NULL,
  `appraised_value` DECIMAL(18,2) NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'active',
  `released_at` DATETIME NULL,
  `released_by` BIGINT NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_loan_jewel_pledge` (`loan_id`),
  KEY `idx_jewel_redemption` (`redemption_due_date`,`status`),
  CONSTRAINT `fk_jewel_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_jewel_items` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pledge_id` BIGINT UNSIGNED NOT NULL,
  `item_description` VARCHAR(255) NOT NULL,
  `gross_weight` DECIMAL(12,3) NULL,
  `net_weight` DECIMAL(12,3) NULL,
  `appraised_value` DECIMAL(18,2) NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_jewel_items_pledge` (`pledge_id`),
  CONSTRAINT `fk_jewel_item_pledge` FOREIGN KEY (`pledge_id`) REFERENCES `loan_jewel_pledges` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_cc_facilities` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `sanctioned_limit` DECIMAL(18,2) NOT NULL,
  `margin_percent` DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
  `drawing_power` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `interest_rate` DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
  `renewal_date` DATE NOT NULL,
  `stock_statement_day` TINYINT UNSIGNED NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'active',
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_cc_loan` (`loan_id`),
  KEY `idx_cc_renewal` (`renewal_date`,`status`),
  CONSTRAINT `fk_cc_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_cc_utilisations` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cc_facility_id` BIGINT UNSIGNED NOT NULL,
  `month_end` DATE NOT NULL,
  `utilised_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `interest_debited` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `drawing_power` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `remarks` VARCHAR(255) NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_cc_month` (`cc_facility_id`,`month_end`),
  CONSTRAINT `fk_cc_util_facility` FOREIGN KEY (`cc_facility_id`) REFERENCES `loan_cc_facilities` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_schedules` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `version_no` INT NOT NULL,
  `label` VARCHAR(180) NOT NULL,
  `method` VARCHAR(40) NOT NULL DEFAULT 'reducing_balance',
  `effective_date` DATE NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `superseded_at` DATETIME NULL,
  `superseded_by` BIGINT NULL,
  `notes` TEXT NULL,
  `created_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_schedule_version` (`loan_id`,`version_no`),
  KEY `idx_schedule_active` (`loan_id`,`is_active`),
  CONSTRAINT `fk_schedule_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_schedule_lines` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `schedule_id` BIGINT UNSIGNED NOT NULL,
  `installment_no` INT NOT NULL,
  `due_date` DATE NOT NULL,
  `emi_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `principal_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `interest_amount` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `closing_balance` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'due',
  `paid_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_schedule_installment` (`schedule_id`,`installment_no`),
  KEY `idx_schedule_due` (`due_date`,`status`),
  CONSTRAINT `fk_schedule_line_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `loan_schedules` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_obligations` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `schedule_line_id` BIGINT UNSIGNED NULL,
  `obligation_type` VARCHAR(40) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `due_date` DATE NOT NULL,
  `display_date` DATE NULL,
  `amount_due` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `amount_paid` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'upcoming',
  `priority` TINYINT NOT NULL DEFAULT 0,
  `pay_from_account_id` BIGINT NULL,
  `snoozed_until` DATETIME NULL,
  `acknowledged_at` DATETIME NULL,
  `acknowledged_by` BIGINT NULL,
  `metadata` JSON NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_obligation_calendar` (`due_date`,`status`,`obligation_type`),
  KEY `idx_obligation_loan` (`loan_id`,`due_date`),
  KEY `idx_obligation_schedule_line` (`schedule_line_id`),
  CONSTRAINT `fk_obligation_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE,
  CONSTRAINT `fk_obligation_schedule_line` FOREIGN KEY (`schedule_line_id`) REFERENCES `loan_schedule_lines` (`sno`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_payments` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `obligation_id` BIGINT UNSIGNED NULL,
  `payment_type` VARCHAR(30) NOT NULL DEFAULT 'installment',
  `payment_date` DATE NOT NULL,
  `amount` DECIMAL(18,2) NOT NULL,
  `penal_interest` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `bounce_charge` DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  `mode` VARCHAR(30) NOT NULL,
  `reference_no` VARCHAR(120) NULL,
  `pay_from_account_id` BIGINT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'posted',
  `reversal_of` BIGINT UNSIGNED NULL,
  `remarks` TEXT NULL,
  `created_by` BIGINT NULL,
  `approved_by` BIGINT NULL,
  `approved_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_payment_loan_date` (`loan_id`,`payment_date`),
  KEY `idx_payment_obligation` (`obligation_id`),
  KEY `idx_payment_status` (`status`),
  CONSTRAINT `fk_payment_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE,
  CONSTRAINT `fk_payment_obligation` FOREIGN KEY (`obligation_id`) REFERENCES `loan_obligations` (`sno`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_reversal` FOREIGN KEY (`reversal_of`) REFERENCES `loan_payments` (`sno`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_renewal_checklists` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `renewal_date` DATE NOT NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'documents_pending',
  `submitted_at` DATETIME NULL,
  `renewed_at` DATETIME NULL,
  `next_renewal_date` DATE NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_renewal_loan` (`loan_id`,`renewal_date`),
  CONSTRAINT `fk_renewal_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_renewal_checklist_items` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `checklist_id` BIGINT UNSIGNED NOT NULL,
  `item_key` VARCHAR(80) NOT NULL,
  `item_label` VARCHAR(180) NOT NULL,
  `is_complete` TINYINT(1) NOT NULL DEFAULT 0,
  `completed_at` DATETIME NULL,
  `completed_by` BIGINT NULL,
  `remarks` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_renewal_item` (`checklist_id`,`item_key`),
  CONSTRAINT `fk_renewal_item_checklist` FOREIGN KEY (`checklist_id`) REFERENCES `loan_renewal_checklists` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_notification_rules` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `obligation_type` VARCHAR(40) NOT NULL,
  `lead_days` INT NOT NULL,
  `channel` VARCHAR(30) NOT NULL DEFAULT 'in_app',
  `recipient_role` VARCHAR(60) NOT NULL DEFAULT 'accounts',
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `entity_id` BIGINT NULL,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_notification_rule_lookup` (`obligation_type`,`enabled`,`entity_id`,`lead_days`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_notifications` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `obligation_id` BIGINT UNSIGNED NOT NULL,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `rule_id` BIGINT UNSIGNED NULL,
  `channel` VARCHAR(30) NOT NULL,
  `recipient_user_id` BIGINT NULL,
  `recipient_address` VARCHAR(255) NULL,
  `scheduled_for` DATETIME NOT NULL,
  `sent_at` DATETIME NULL,
  `delivery_status` VARCHAR(30) NOT NULL DEFAULT 'pending',
  `provider_message_id` VARCHAR(190) NULL,
  `attempts` INT NOT NULL DEFAULT 0,
  `idempotency_key` VARCHAR(190) NOT NULL,
  `error_message` TEXT NULL,
  `acknowledged_at` DATETIME NULL,
  `acknowledged_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_notification_idempotency` (`idempotency_key`),
  KEY `idx_notification_schedule` (`scheduled_for`,`delivery_status`),
  KEY `idx_notification_obligation` (`obligation_id`),
  CONSTRAINT `fk_notification_obligation` FOREIGN KEY (`obligation_id`) REFERENCES `loan_obligations` (`sno`) ON DELETE CASCADE,
  CONSTRAINT `fk_notification_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE,
  CONSTRAINT `fk_notification_rule` FOREIGN KEY (`rule_id`) REFERENCES `loan_notification_rules` (`sno`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_documents` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NOT NULL,
  `document_type` VARCHAR(60) NOT NULL,
  `original_name` VARCHAR(255) NOT NULL,
  `storage_disk` VARCHAR(60) NOT NULL DEFAULT 's3',
  `storage_path` TEXT NOT NULL,
  `mime_type` VARCHAR(120) NULL,
  `file_size` BIGINT UNSIGNED NULL,
  `checksum` CHAR(64) NULL,
  `uploaded_by` BIGINT NULL,
  `created_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  KEY `idx_loan_document_loan_type` (`loan_id`,`document_type`),
  CONSTRAINT `fk_loan_document_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_holidays` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `holiday_date` DATE NOT NULL,
  `holiday_name` VARCHAR(180) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` BIGINT NULL,
  `updated_by` BIGINT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`sno`),
  UNIQUE KEY `uq_loan_holiday_date` (`holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_audit_log` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` BIGINT UNSIGNED NULL,
  `action` VARCHAR(80) NOT NULL,
  `entity_type` VARCHAR(80) NULL,
  `entity_id` BIGINT NULL,
  `user_id` BIGINT NULL,
  `before_json` JSON NULL,
  `after_json` JSON NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(500) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sno`),
  KEY `idx_audit_loan_created` (`loan_id`,`created_at`),
  KEY `idx_audit_user_created` (`user_id`,`created_at`),
  CONSTRAINT `fk_audit_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`sno`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'emi',7,'in_app','accounts',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='emi' AND lead_days=7 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'emi',1,'email','accounts',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='emi' AND lead_days=1 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'cc_renewal',45,'in_app','accounts',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='cc_renewal' AND lead_days=45 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'cc_renewal',30,'email','finance',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='cc_renewal' AND lead_days=30 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'cc_renewal',15,'in_app','finance',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='cc_renewal' AND lead_days=15 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'jewel_redemption',30,'in_app','accounts',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='jewel_redemption' AND lead_days=30 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'jewel_redemption',15,'email','finance',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='jewel_redemption' AND lead_days=15 AND entity_id IS NULL);
INSERT INTO `loan_notification_rules` (`obligation_type`,`lead_days`,`channel`,`recipient_role`,`enabled`,`created_at`,`updated_at`)
SELECT 'jewel_redemption',7,'in_app','finance',1,NOW(),NOW() WHERE NOT EXISTS (SELECT 1 FROM loan_notification_rules WHERE obligation_type='jewel_redemption' AND lead_days=7 AND entity_id IS NULL);
