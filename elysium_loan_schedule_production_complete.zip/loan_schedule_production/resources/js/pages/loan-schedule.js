(function ($) {
    'use strict';

    const root = document.getElementById('loanModuleRoot');
    if (!root) return;

    const urls = window.loanModuleUrls || {};
    const csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    const state = {
        page: 1,
        perPage: 50,
        search: '',
        type: 'all',
        status: 'all',
        entity: 'all',
        calendarDate: new Date(),
        calendarView: 'month',
        calendarType: 'all',
        calendarStatus: 'all',
        calendarEntity: 'all',
        calendarItems: [],
        calendarExpanded: null,
        lookups: { entities: [], lenders: [], banks: [] },
    };

    const $id = (id) => document.getElementById(id);
    const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[m]);
    const inr = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(value || 0));
    const dateOnly = (value) => value ? new Date(`${value}T00:00:00`) : null;
    const fmtDate = (value) => {
        const date = dateOnly(value);
        return date ? new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(date) : '—';
    };
    const isoDate = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const monthLabel = (date) => new Intl.DateTimeFormat('en-GB', { month: 'long', year: 'numeric' }).format(date);
    const typeMeta = (type) => ({ vehicle: ['🚗', 'Vehicle'], term: ['📄', 'Term'], jewel: ['💍', 'Jewel'], cc: ['🏦', 'CC'] }[type] || ['📁', 'Loan']);

    async function api(url, options = {}) {
        const config = { ...options };
        config.headers = Object.assign({ Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, options.headers || {});
        if (csrf) config.headers['X-CSRF-TOKEN'] = csrf;
        const response = await fetch(url, config);
        const data = await response.json().catch(() => ({}));
        if (!response.ok || (data.status !== undefined && Number(data.status) >= 400)) {
            const errors = data.errors || {};
            const first = Object.values(errors).flat()[0];
            throw new Error(first || data.message || 'Request failed.');
        }
        return data;
    }

    function toast(message, type = 'success') {
        const box = $id('loanToast');
        if (!box) return;
        box.className = `toast align-items-center border-0 text-white ${type === 'error' ? 'bg-danger' : type === 'warning' ? 'bg-warning text-dark' : 'bg-success'}`;
        box.querySelector('.toast-body').textContent = message;
        bootstrap.Toast.getOrCreateInstance(box, { delay: 3200 }).show();
    }

    function chip(status) {
        const labels = {
            upcoming: 'Upcoming', today: 'Due Today', overdue: 'Overdue', paid: 'Paid', partial: 'Part Paid',
            pending_approval: 'Pending Approval', active: 'Active', closed: 'Closed', renewal: 'Renewal',
            returned: 'Returned', foreclosed: 'Foreclosed', restructured: 'Restructured',
        };
        const cls = status === 'pending_approval' ? 'pending' : status;
        return `<span class="loan-chip ${esc(cls)}">${esc(labels[status] || status || '—')}</span>`;
    }

    function progress(paid, total) {
        const safeTotal = Number(total || 0);
        const safePaid = Number(paid || 0);
        const pct = safeTotal ? Math.min(100, Math.round((safePaid / safeTotal) * 100)) : 0;
        return `<div class="loan-progress"><span style="width:${pct}%"></span></div><div class="small text-muted mt-1">${safePaid}/${safeTotal} instalments</div>`;
    }

    function filteredCalendarItems() {
        return state.calendarItems.filter((item) => {
            if (state.calendarType !== 'all' && item.loan_type !== state.calendarType) return false;
            if (state.calendarEntity !== 'all' && String(item.entity_id) !== String(state.calendarEntity)) return false;
            if (state.calendarStatus !== 'all' && item.status !== state.calendarStatus) return false;
            return true;
        });
    }

    async function loadLookups() {
        const result = await api(urls.lookups);
        state.lookups = result.data || state.lookups;

        const fill = (id, list, placeholder, preserve = 'all') => {
            const node = $id(id);
            if (!node) return;
            const current = node.value;
            node.innerHTML = '';
            node.appendChild(new Option(placeholder, preserve));
            list.forEach((row) => node.appendChild(new Option(row.name, row.id)));
            if ([...node.options].some((o) => String(o.value) === String(current))) node.value = current;
        };

        fill('loanEntityFilter', state.lookups.entities || [], 'All Entities');
        fill('calendarEntity', state.lookups.entities || [], 'All Entities');
        fill('loanPayAccount', state.lookups.banks || [], 'Select bank account', '');
        fill('paymentAccount', state.lookups.banks || [], 'Select bank account', '');

        const lender = $id('loanLenderSelect');
        if (lender) {
            lender.innerHTML = '<option value="">Select existing lender</option>';
            (state.lookups.lenders || []).forEach((row) => lender.appendChild(new Option(row.name, row.id)));
            if ($.fn.select2) $(lender).select2({ width: '100%', dropdownParent: $('#addLoanModal'), placeholder: 'Select existing lender', allowClear: true });
        }

        const entity = $id('loanEntity');
        if (entity) {
            entity.innerHTML = '<option value="">Select entity</option>';
            (state.lookups.entities || []).forEach((row) => entity.appendChild(new Option(row.name, row.id)));
            if ($.fn.select2) $(entity).select2({ width: '100%', dropdownParent: $('#addLoanModal'), placeholder: 'Select entity', allowClear: true });
        }
    }

    function setFilterUI() {
        document.querySelectorAll('#loanTypeFilters [data-value]').forEach((button) => button.classList.toggle('active', button.dataset.value === state.type));
        document.querySelectorAll('#loanStatusFilters [data-status-value]').forEach((button) => button.classList.toggle('active', button.dataset.statusValue === state.status));
        document.querySelectorAll('#calendarTypeFilters [data-value]').forEach((button) => button.classList.toggle('active', button.dataset.value === state.calendarType));
        document.querySelectorAll('#calendarStatusFilters [data-value]').forEach((button) => button.classList.toggle('active', button.dataset.value === state.calendarStatus));
    }

    function renderLoanRows(items) {
        const body = $id('loanTableBody');
        if (!body) return;

        if (!items.length) {
            body.innerHTML = '<tr><td colspan="10"><div class="loan-empty"><i class="mdi mdi-folder-open-outline"></i><strong>No loans found</strong><span>Try clearing filters or add a new loan.</span></div></td></tr>';
            return;
        }

        body.innerHTML = items.map((item) => {
            const type = typeMeta(item.type);
            return `<tr class="loan-row" data-id="${item.id}" tabindex="0">
                <td><div class="fw-bold text-dark">${esc(item.account_no)}</div><div class="small text-muted">${esc(item.name || '')}</div></td>
                <td><span class="loan-type-mark">${type[0]}</span>${esc(type[1])}</td>
                <td>${esc(item.entity || '—')}</td>
                <td class="fw-semibold">${esc(item.lender || '—')}</td>
                <td class="text-end fw-bold">${inr(item.outstanding)}</td>
                <td class="text-end">${Number(item.emi || 0) > 0 ? inr(item.emi) : '—'}</td>
                <td>${item.next_due ? `<div class="fw-semibold">${fmtDate(item.next_due)}</div>${chip(item.next_status)}` : '<span class="text-muted">No pending due</span>'}</td>
                <td>${progress(item.paid_months, item.total_months)}</td>
                <td>${chip(item.status)}</td>
                <td class="text-end"><button type="button" class="btn btn-sm btn-outline-primary open-loan"><i class="mdi mdi-arrow-top-right"></i></button></td>
            </tr>`;
        }).join('');

        body.querySelectorAll('.loan-row').forEach((row) => {
            row.addEventListener('click', (event) => {
                if (!event.target.closest('.open-loan')) return openLoan(row.dataset.id);
                openLoan(row.dataset.id);
            });
            row.addEventListener('keydown', (event) => {
                if (event.key === 'Enter' || event.key === ' ') openLoan(row.dataset.id);
            });
        });
    }

    function renderPagination(pagination) {
        const node = $id('loanPagination');
        if (!node) return;
        node.innerHTML = `<div class="small text-muted">${pagination.total || 0} records · Page ${pagination.current_page || 1} of ${pagination.last_page || 1}</div>
            <div class="btn-group btn-group-sm">
                <button type="button" class="btn btn-outline-secondary" data-page="${Math.max(1, (pagination.current_page || 1) - 1)}" ${pagination.current_page <= 1 ? 'disabled' : ''}>Previous</button>
                <button type="button" class="btn btn-outline-secondary" data-page="${Math.min(pagination.last_page || 1, (pagination.current_page || 1) + 1)}" ${pagination.current_page >= pagination.last_page ? 'disabled' : ''}>Next</button>
            </div>`;
        node.querySelectorAll('[data-page]').forEach((button) => button.addEventListener('click', () => {
            state.page = Number(button.dataset.page);
            loadLoans();
        }));
    }

    async function loadLoans() {
        $id('loanTableLoading')?.classList.remove('d-none');
        try {
            const query = new URLSearchParams({ page: state.page, per_page: state.perPage, search: state.search, type: state.type, status: state.status, entity: state.entity });
            const result = await api(`${urls.data}?${query.toString()}`);
            renderLoanRows(result.data || []);
            renderPagination(result.pagination || {});
        } catch (error) {
            toast(error.message, 'error');
        } finally {
            $id('loanTableLoading')?.classList.add('d-none');
        }
    }

    async function loadDashboard() {
        try {
            const result = await api(urls.dashboard);
            const data = result.data || {};
            const kpi = data.kpis || {};
            $id('kpiOutstanding').textContent = inr(kpi.outstanding);
            $id('kpiDueWeek').textContent = `${kpi.due_week_count || 0}`;
            $id('kpiDueWeekAmount').textContent = inr(kpi.due_week_amount);
            $id('kpiOverdue').textContent = `${kpi.overdue_count || 0}`;
            $id('kpiOverdueAmount').textContent = inr(kpi.overdue_amount);
            $id('kpiRenewals').textContent = `${kpi.renewals_60_count || 0}`;

            const actions = $id('todayActions');
            const rows = data.today_actions || [];
            actions.innerHTML = rows.length ? rows.map((item) => `<div class="loan-action-item">
                <div class="loan-action-date"><strong>${fmtDate(item.date)}</strong><span>${esc(item.entity || '—')}</span></div>
                <div class="loan-action-main"><div class="fw-bold">${esc(item.title)}</div><div class="small text-muted">${esc(item.lender || '—')} · ${esc(item.account_no || '—')}</div></div>
                <div class="loan-action-amount">${inr(item.amount)}${chip(item.status)}</div>
                <button type="button" class="btn btn-sm btn-outline-success loan-action-pay" data-obligation="${item.id}" data-loan="${item.loan_id}" data-amount="${item.amount}" data-date="${item.date}" data-title="${esc(item.title)}"><i class="mdi mdi-cash-check"></i></button>
            </div>`).join('') : '<div class="loan-empty compact"><i class="mdi mdi-check-circle-outline"></i><strong>Nothing needs attention today.</strong><span>Your payment queue is clear.</span></div>';
            actions.querySelectorAll('.loan-action-pay').forEach((button) => button.addEventListener('click', () => openPayment({ id: button.dataset.obligation, loan_id: button.dataset.loan, amount: button.dataset.amount, date: button.dataset.date, title: button.dataset.title })));

            const exposure = $id('entityExposure');
            const exposureRows = data.entity_exposure || [];
            const max = Math.max(1, ...exposureRows.map((x) => Number(x.outstanding || 0)));
            exposure.innerHTML = exposureRows.length ? exposureRows.map((row) => `<div class="loan-exposure-row"><div class="d-flex justify-content-between gap-2"><span class="fw-semibold">${esc(row.entity)}</span><span class="small text-muted">${inr(row.outstanding)}</span></div><div class="loan-exposure-bar"><span style="width:${Math.round((Number(row.outstanding || 0) / max) * 100)}%"></span></div></div>`).join('') : '<div class="small text-muted">No active loan exposure found.</div>';
        } catch (error) {
            console.warn('Dashboard summary failed:', error);
        }
    }

    function currentMonthRange() {
        if (state.calendarView === 'week') {
            const anchor = new Date(state.calendarDate);
            const mondayOffset = (anchor.getDay() + 6) % 7;
            const monday = new Date(anchor);
            monday.setDate(anchor.getDate() - mondayOffset);
            const sunday = new Date(monday);
            sunday.setDate(monday.getDate() + 6);
            return { from: isoDate(monday), to: isoDate(sunday) };
        }
        const first = new Date(state.calendarDate.getFullYear(), state.calendarDate.getMonth(), 1);
        const last = new Date(state.calendarDate.getFullYear(), state.calendarDate.getMonth() + 1, 0);
        return { from: isoDate(first), to: isoDate(last) };
    }

    async function loadCalendar() {
        $id('calendarLoading')?.classList.remove('d-none');
        try {
            const range = currentMonthRange();
            const query = new URLSearchParams({ from: range.from, to: range.to, loan_type: state.calendarType, status: state.calendarStatus, entity_id: state.calendarEntity === 'all' ? '' : state.calendarEntity });
            const result = await api(`${urls.calendar}?${query.toString()}`);
            state.calendarItems = result.data || [];
            if (state.calendarView === 'month') renderCalendarMonth();
            else if (state.calendarView === 'week') renderCalendarWeek();
            else renderCalendarList();
        } catch (error) {
            toast(error.message, 'error');
        } finally {
            $id('calendarLoading')?.classList.add('d-none');
        }
    }

    function renderCalendarMonth() {
        $id('calendarGridWrap')?.classList.remove('d-none');
        $id('calendarWeekWrap')?.classList.add('d-none');
        $id('agendaWrap')?.classList.add('d-none');

        $id('calendarTitle').textContent = monthLabel(state.calendarDate);
        const visible = filteredCalendarItems();
        const map = {};
        visible.forEach((item) => (map[item.date] ||= []).push(item));
        const y = state.calendarDate.getFullYear();
        const m = state.calendarDate.getMonth();
        const days = new Date(y, m + 1, 0).getDate();
        const start = (new Date(y, m, 1).getDay() + 6) % 7;
        const today = isoDate(new Date());
        const cells = [];
        for (let i = 0; i < start; i++) cells.push(null);
        for (let d = 1; d <= days; d++) cells.push(d);
        while (cells.length % 7) cells.push(null);

        let html = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => `<div class="cal-head">${day}</div>`).join('');
        cells.forEach((day) => {
            if (!day) {
                html += '<div class="cal-day muted"></div>';
                return;
            }
            const date = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const list = map[date] || [];
            const showAll = state.calendarExpanded === date;
            const shown = showAll ? list : list.slice(0, 3);
            html += `<div class="cal-day ${date === today ? 'today' : ''}"><div class="cal-num">${day}</div>
                ${shown.map((item) => `<button type="button" class="loan-obligation ${esc(item.status)}" data-oid="${item.id}" title="${esc(item.title)} · ${esc(item.lender || '')} · ${inr(item.amount)}">${typeMeta(item.loan_type)[0]} <span>${esc(item.title)}</span><b>${Number(item.amount || 0) > 0 ? inr(item.amount) : ''}</b></button>`).join('')}
                ${list.length > 3 && !showAll ? `<button type="button" class="loan-more" data-more="${date}">+${list.length - 3} more</button>` : ''}
            </div>`;
        });

        $id('calendarGrid').innerHTML = html;
        $id('calendarGrid').querySelectorAll('.loan-obligation').forEach((button) => button.addEventListener('click', () => openObligation(button.dataset.oid)));
        $id('calendarGrid').querySelectorAll('[data-more]').forEach((button) => button.addEventListener('click', () => { state.calendarExpanded = button.dataset.more; renderCalendarMonth(); }));
    }

    function renderCalendarWeek() {
        $id('calendarGridWrap')?.classList.add('d-none');
        $id('agendaWrap')?.classList.add('d-none');
        $id('calendarWeekWrap')?.classList.remove('d-none');

        const anchor = new Date(state.calendarDate);
        const offset = (anchor.getDay() + 6) % 7;
        const monday = new Date(anchor);
        monday.setDate(anchor.getDate() - offset);
        const visible = filteredCalendarItems();
        const html = `<div class="loan-week-grid"><div class="loan-week-head">Time</div>${Array.from({ length: 7 }).map((_, i) => { const d = new Date(monday); d.setDate(monday.getDate() + i); return `<div class="loan-week-head">${new Intl.DateTimeFormat('en-GB', { weekday: 'short' }).format(d)}<strong>${d.getDate()}</strong></div>`; }).join('')}
            <div class="loan-week-time">All day</div>
            ${Array.from({ length: 7 }).map((_, i) => { const d = new Date(monday); d.setDate(monday.getDate() + i); const date = isoDate(d); const items = visible.filter((x) => x.date === date); return `<div class="loan-week-cell ${date === isoDate(new Date()) ? 'today' : ''}">${items.map((item) => `<button type="button" class="loan-week-item ${esc(item.status)}" data-oid="${item.id}">${typeMeta(item.loan_type)[0]} <span>${esc(item.title)}</span><strong>${Number(item.amount || 0) ? inr(item.amount) : ''}</strong></button>`).join('') || '<span class="small text-muted">—</span>'}</div>`; }).join('')}</div>`;
        $id('calendarTitle').textContent = `Week of ${fmtDate(isoDate(monday))}`;
        $id('calendarWeekWrap').innerHTML = html;
        $id('calendarWeekWrap').querySelectorAll('[data-oid]').forEach((button) => button.addEventListener('click', () => openObligation(button.dataset.oid)));
    }

    function renderCalendarList() {
        $id('calendarGridWrap')?.classList.add('d-none');
        $id('calendarWeekWrap')?.classList.add('d-none');
        $id('agendaWrap')?.classList.remove('d-none');

        const visible = filteredCalendarItems();
        const groups = {};
        visible.forEach((item) => (groups[item.date] ||= []).push(item));
        const dates = Object.keys(groups).sort();
        $id('calendarTitle').textContent = monthLabel(state.calendarDate);
        $id('agendaWrap').innerHTML = dates.length ? dates.map((date) => `<section class="loan-agenda-group"><div class="loan-agenda-date"><span>${fmtDate(date)}</span>${date === isoDate(new Date()) ? chip('today') : ''}</div>${groups[date].map((item) => `<div class="loan-agenda-item"><div class="loan-agenda-icon">${typeMeta(item.loan_type)[0]}</div><div class="loan-agenda-main"><div class="fw-bold">${esc(item.title)} <span class="small text-muted">· ${esc(item.lender || '')}</span></div><div class="small text-muted">${esc(item.entity || '—')} · ${esc(item.account_no || '—')}</div></div><div class="loan-agenda-amount">${Number(item.amount || 0) ? inr(item.amount) : '—'}</div><div>${chip(item.status)}</div><button type="button" class="btn btn-sm btn-outline-primary" data-oid="${item.id}">Details</button></div>`).join('')}</section>`).join('') : '<div class="loan-empty"><i class="mdi mdi-calendar-blank-outline"></i><strong>Nothing scheduled in this period.</strong><span>Try another month or clear filters.</span></div>';
        $id('agendaWrap').querySelectorAll('[data-oid]').forEach((button) => button.addEventListener('click', () => openObligation(button.dataset.oid)));
    }

    async function openObligation(id) {
        const item = state.calendarItems.find((row) => String(row.id) === String(id));
        if (!item) return;

        const pop = $id('calendarPopover');
        pop.innerHTML = `<div class="loan-popover-arrow"></div><div class="loan-popover-head"><div><strong>${esc(item.title)}</strong><span>${esc(item.lender || '—')} · ${esc(item.account_no || '—')}</span></div>${chip(item.status)}<button type="button" class="btn btn-sm btn-light" id="closeCalendarPopover"><i class="mdi mdi-close"></i></button></div>
            <div class="loan-popover-body"><div class="row g-3"><div class="col-6"><small>Due date</small><strong>${fmtDate(item.date)}</strong></div><div class="col-6 text-end"><small>Amount</small><strong>${Number(item.amount || 0) ? inr(item.amount) : 'No payment amount'}</strong></div><div class="col-12"><small>Entity</small><strong>${esc(item.entity || '—')}</strong></div></div></div>
            <div class="loan-popover-actions"><button type="button" class="btn btn-success btn-sm" id="popoverPay">Record Payment</button><button type="button" class="btn btn-outline-primary btn-sm" id="popoverOpen">Open Loan</button><button type="button" class="btn btn-outline-secondary btn-sm" id="popoverSnooze">Snooze</button></div>`;
        pop.classList.remove('d-none');
        pop.querySelector('#closeCalendarPopover').onclick = closePopover;
        pop.querySelector('#popoverPay').onclick = () => { closePopover(); openPayment(item); };
        pop.querySelector('#popoverOpen').onclick = () => { closePopover(); openLoan(item.loan_id); };
        pop.querySelector('#popoverSnooze').onclick = () => snoozeObligation(item);
    }

    function closePopover() {
        $id('calendarPopover')?.classList.add('d-none');
    }

    async function snoozeObligation(item) {
        const until = prompt('Snooze until (YYYY-MM-DD HH:MM):', `${item.date} 09:00`);
        if (!until) return;
        const reason = prompt('Reason for snoozing:', 'Bank confirmation pending');
        if (!reason) return;
        try {
            await api(urls.snooze.replace(':id', item.id), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ until, reason }) });
            closePopover();
            toast('Reminder snoozed.');
            await loadCalendar();
        } catch (error) { toast(error.message, 'error'); }
    }

    async function openLoan(id) {
        try {
            const result = await api(urls.show.replace(':id', id));
            renderLoanDrawer(result.data);
            const drawer = $id('loanDrawer');
            drawer.classList.add('show');
            drawer.setAttribute('aria-hidden', 'false');
            $id('loanScrim').classList.add('show');
        } catch (error) { toast(error.message, 'error'); }
    }

    function renderLoanDrawer(data) {
        const loan = data.loan;
        const type = typeMeta(loan.type);
        $id('loanDrawerTitle').innerHTML = `${type[0]} ${esc(loan.lender || 'Loan')} <span>${chip(loan.status)}</span>`;
        $id('loanDrawerSub').textContent = `${loan.account_no} · ${loan.entity || '—'}`;

        const activeSchedule = (data.schedules || []).find((x) => x.active);
        const lines = activeSchedule?.lines || [];
        const next = (data.obligations || []).find((x) => ['overdue', 'partial', 'today', 'upcoming'].includes(x.status));

        $id('loanDrawerBody').innerHTML = `<div class="loan-drawer-summary"><div><small>Amount left to pay</small><strong>${inr(loan.outstanding)}</strong></div><div><small>Monthly EMI</small><strong>${Number(loan.emi || 0) ? inr(loan.emi) : '—'}</strong></div><div><small>Next due</small><strong>${next ? fmtDate(next.date) : '—'}</strong></div></div>
            <div class="loan-drawer-tenure"><div class="d-flex justify-content-between"><span>Tenure progress</span><b>${loan.paid_months || 0} / ${loan.total_months || 0}</b></div>${progress(loan.paid_months, loan.total_months)}</div>
            <div class="loan-action-menu"><button type="button" class="btn btn-success" id="drawerPay">Record Payment</button><button type="button" class="btn btn-outline-primary" id="drawerOpenDetail">Open Full Detail</button>${loan.status === 'pending_approval' ? '<button type="button" class="btn btn-outline-success" id="drawerApprove">Approve</button><button type="button" class="btn btn-outline-danger" id="drawerReturn">Return</button>' : ''}</div>
            <div class="loan-drawer-tabs" id="drawerTabs"><button class="active" data-tab="overview">Overview</button><button data-tab="schedule">Schedule</button><button data-tab="payments">Payments</button><button data-tab="audit">Audit</button></div>
            <div id="drawerTabBody"></div>`;

        const renderTab = (tab) => {
            const body = $id('drawerTabBody');
            if (tab === 'overview') {
                body.innerHTML = `<div class="loan-detail-grid"><div><small>Loan A/c</small><strong>${esc(loan.account_no)}</strong></div><div><small>Loan type</small><strong>${esc(type[1])}</strong></div><div><small>Interest</small><strong>${esc(loan.interest_rate ?? '—')}%</strong></div><div><small>Maturity</small><strong>${fmtDate(loan.maturity)}</strong></div><div><small>Sanctioned</small><strong>${inr(loan.sanction_amount)}</strong></div><div><small>Disbursed</small><strong>${inr(loan.disbursed_amount)}</strong></div></div>`;
            } else if (tab === 'schedule') {
                body.innerHTML = lines.length ? `<div class="loan-mini-table"><table><thead><tr><th>#</th><th>Due</th><th class="text-end">EMI</th><th class="text-end">Principal</th><th class="text-end">Interest</th><th class="text-end">Balance</th><th>Status</th></tr></thead><tbody>${lines.slice(0, 12).map((line) => `<tr class="${line.status === 'paid' ? 'paid' : ''}"><td>${line.installment_no}</td><td>${fmtDate(line.due_date)}</td><td class="text-end">${inr(line.emi_amount)}</td><td class="text-end">${inr(line.principal_amount)}</td><td class="text-end">${inr(line.interest_amount)}</td><td class="text-end">${inr(line.closing_balance)}</td><td>${chip(line.status)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="loan-empty compact"><i class="mdi mdi-table-off"></i><strong>No amortisation rows.</strong><span>Jewel and CC facilities use calendar obligations.</span></div>';
            } else if (tab === 'payments') {
                body.innerHTML = (data.payments || []).length ? data.payments.map((payment) => `<div class="loan-payment-row"><div><strong>${inr(payment.amount)}</strong><span>${fmtDate(payment.payment_date)} · ${esc(payment.mode || '—')}</span></div><span>${esc(payment.reference_no || '—')}</span></div>`).join('') : '<div class="loan-empty compact"><i class="mdi mdi-cash-remove"></i><strong>No payments recorded.</strong></div>';
            } else {
                body.innerHTML = (data.audit || []).length ? data.audit.map((audit) => `<div class="loan-audit-item"><span class="loan-audit-dot"></span><div><strong>${esc(audit.action)}</strong><span>${esc(audit.user_id || 'System')} · ${audit.created_at ? new Date(audit.created_at).toLocaleString('en-GB') : '—'}</span></div></div>`).join('') : '<div class="loan-empty compact"><i class="mdi mdi-history"></i><strong>No audit activity.</strong></div>';
            }
        };

        renderTab('overview');
        $id('drawerTabs').querySelectorAll('button').forEach((button) => button.addEventListener('click', () => {
            $id('drawerTabs').querySelectorAll('button').forEach((b) => b.classList.remove('active'));
            button.classList.add('active');
            renderTab(button.dataset.tab);
        }));

        $id('drawerPay').onclick = () => openPayment(next || { loan_id: loan.id, amount: loan.emi, date: loan.next_due, title: 'Loan payment' });
        $id('drawerOpenDetail').onclick = () => { window.location.href = `${window.location.origin}${String(urls.show).replace('/data','').replace(':id', loan.id)}`; };
        $id('drawerApprove')?.addEventListener('click', async () => {
            try { await api(`/accounts_finance/loans/${loan.id}/approve`, { method: 'POST' }); toast('Loan approved.'); closeDrawer(); await refreshAll(); } catch (e) { toast(e.message, 'error'); }
        });
        $id('drawerReturn')?.addEventListener('click', async () => {
            const remarks = prompt('Return reason:'); if (!remarks) return;
            try { await api(`/accounts_finance/loans/${loan.id}/return`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remarks }) }); toast('Loan returned.'); closeDrawer(); await refreshAll(); } catch (e) { toast(e.message, 'error'); }
        });
    }

    function closeDrawer() {
        $id('loanDrawer')?.classList.remove('show');
        $id('loanDrawer')?.setAttribute('aria-hidden', 'true');
        $id('loanScrim')?.classList.remove('show');
    }

    function openPayment(obligation) {
        const modal = bootstrap.Modal.getOrCreateInstance($id('loanPaymentModal'));
        $id('paymentLoanId').value = obligation.loan_id || '';
        $id('paymentObligationId').value = obligation.id || '';
        $id('paymentLoanSummary').textContent = `${obligation.title || 'Loan payment'} · ${obligation.account_no || ''}`;
        $id('paymentAmountDue').textContent = inr(obligation.amount || 0);
        $id('paymentDueDate').textContent = fmtDate(obligation.date);
        $id('paymentRemaining').textContent = inr(Math.max(0, Number(obligation.amount || 0) - Number(obligation.paid || 0)));
        $id('paymentAmount').value = Number(obligation.amount || 0) || '';
        $id('paymentDate').value = isoDate(new Date());
        $id('paymentPayAccountId').value = obligation.pay_from_account_id || '';
        const account = $id('paymentAccount');
        if (account && obligation.pay_from_account_id) account.value = obligation.pay_from_account_id;
        updateShortfall();
        modal.show();
    }

    function updateShortfall() {
        const due = Number($id('paymentAmountDue').textContent.replace(/[^0-9.-]/g, '')) || 0;
        const amount = Number($id('paymentAmount').value || 0);
        const box = $id('paymentShortfall');
        if (amount > 0 && due > amount) {
            box.classList.remove('d-none');
            box.textContent = `Shortfall ${inr(due - amount)} will remain due after this payment.`;
        } else {
            box.classList.add('d-none');
        }
    }

    function initDatePickers(rootNode = document) {
        if (!$.fn.datepicker) return;
        $(rootNode).find('.date-picker').each(function () {
            const $input = $(this);
            if ($input.data('datepicker')) return;
            $input.datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
            });
        });
    }

    function calculateEmi() {
        const form = $id('addLoanForm');
        const principal = Number(form?.querySelector('[name="disbursed_amount"]')?.value || form?.querySelector('[name="sanction_amount"]')?.value || 0);
        const rate = Number(form?.querySelector('[name="interest_rate"]')?.value || 0);
        const months = Number(form?.querySelector('[name="tenure_months"]')?.value || 0);
        const frequency = form?.querySelector('[name="frequency"]')?.value || 'monthly';
        const method = form?.querySelector('[name="interest_type"]')?.value || 'reducing_balance';
        const period = frequency === 'quarterly' ? Math.ceil(months / 3) : months;
        if (!principal || !months) {
            $id('emiPreviewValue').textContent = '₹0';
            $id('emiMaturityValue').textContent = '—';
            return;
        }
        let emi = principal / Math.max(1, period);
        const r = rate / 1200;
        if (method !== 'flat_rate' && r > 0) {
            const f = Math.pow(1 + r, period);
            emi = principal * r * f / (f - 1);
        } else if (method === 'flat_rate') {
            emi = (principal + principal * (rate / 100)) / Math.max(1, period);
        }
        $id('emiPreviewValue').textContent = inr(emi);
        const start = $id('loanStartDate')?.value;
        if (start) {
            const maturity = new Date(`${start}T00:00:00`);
            maturity.setMonth(maturity.getMonth() + period * (frequency === 'quarterly' ? 3 : 1));
            $id('emiMaturityValue').textContent = new Intl.DateTimeFormat('en-GB', { month: '2-digit', year: 'numeric' }).format(maturity);
        }
    }

    function buildReview() {
        const form = $id('addLoanForm');
        if (!form) return;
        const value = (name) => form.querySelector(`[name="${name}"]`)?.value || '—';
        const selectedType = form.querySelector('[name="loan_type"]')?.value || 'vehicle';
        const meta = typeMeta(selectedType);
        $id('loanReview').innerHTML = [
            ['Entity', $id('loanEntity')?.selectedOptions[0]?.textContent || '—'],
            ['Lender', $id('loanLenderSelect')?.selectedOptions[0]?.textContent || value('lender_name')],
            ['Loan A/c', value('loan_account_no')],
            ['Loan Type', `${meta[0]} ${meta[1]}`],
            ['Sanctioned / Limit', inr(value('sanction_amount'))],
            ['Disbursed', inr(value('disbursed_amount') || value('sanction_amount'))],
            ['Interest', `${value('interest_rate')}% · ${value('interest_type').replace('_', ' ')}`],
            ['Start Date', fmtDate(value('start_date'))],
            ['Tenure', `${value('tenure_months')} months · ${value('frequency')}`],
            ['Pay From', $id('loanPayAccount')?.selectedOptions[0]?.textContent || '—'],
        ].map(([label, v]) => `<div class="loan-review-item"><small>${esc(label)}</small><strong>${esc(v)}</strong></div>`).join('');
    }

    function validateStep(step) {
        const form = $id('addLoanForm');
        const panel = form?.querySelector(`[data-wizard-panel="${step}"]`);
        if (!panel) return true;
        let valid = true;
        panel.querySelectorAll('[required]').forEach((input) => {
            if (input.closest('.d-none')) return;
            if (!String(input.value || '').trim()) {
                input.classList.add('is-invalid');
                valid = false;
            } else input.classList.remove('is-invalid');
        });
        const type = form.querySelector('[name="loan_type"]')?.value;
        if (step === 1 && !$id('loanEntity')?.value) { $id('loanEntity')?.classList.add('is-invalid'); valid = false; }
        if (step === 1 && !$id('loanLenderSelect')?.value && !form.querySelector('[name="lender_name"]')?.value.trim()) { $id('loanLenderSelect')?.classList.add('is-invalid'); valid = false; }
        if (step === 2) {
            if (type === 'vehicle') {
                ['registration_no', 'make_model'].forEach((name) => { const input = form.querySelector(`[name="${name}"]`); if (input && !input.value.trim()) { input.classList.add('is-invalid'); valid = false; } });
            }
            if (type === 'jewel' && !form.querySelector('[name="pledge_receipt_no"]')?.value.trim()) valid = false;
            if (type === 'cc' && !form.querySelector('[name="renewal_date"]')?.value.trim()) valid = false;
        }
        if (!valid) toast('Please complete the highlighted fields.', 'warning');
        return valid;
    }

    function wizardStep(step) {
        document.querySelectorAll('#addLoanModal [data-wizard-panel]').forEach((panel) => panel.classList.toggle('active', Number(panel.dataset.wizardPanel) === step));
        document.querySelectorAll('#addLoanModal [data-wizard-step]').forEach((item) => item.classList.toggle('active', Number(item.dataset.wizardStep) === step));
        $id('loanWizardPrev')?.classList.toggle('d-none', step === 1);
        $id('loanWizardNext')?.classList.toggle('d-none', step === 3);
        $id('saveLoan')?.classList.toggle('d-none', step !== 3);
        if (step === 3) buildReview();
        initDatePickers($id('addLoanModal'));
    }

    function toggleTypePanels() {
        const type = $id('loanTypeInput')?.value || 'vehicle';
        document.querySelectorAll('#addLoanModal [data-type-panel]').forEach((panel) => panel.classList.toggle('d-none', panel.dataset.typePanel !== type));
        document.querySelectorAll('#addLoanModal .loan-type-card').forEach((card) => card.classList.toggle('selected', card.dataset.type === type));
        const card = document.querySelector(`#addLoanModal .loan-type-card[data-type="${CSS.escape(type)}"]`);
        if (card) $id('loanTypeHint').textContent = card.dataset.hint || '';
        calculateEmi();
    }

    async function saveLoan() {
        const form = $id('addLoanForm');
        if (!validateStep(1) || !validateStep(2)) return;
        buildReview();
        const button = $id('saveLoan');
        button.disabled = true;
        try {
            const result = await api(urls.store, { method: 'POST', body: new FormData(form) });
            bootstrap.Modal.getInstance($id('addLoanModal'))?.hide();
            form.reset();
            wizardStep(1);
            if ($.fn.select2) $('#loanEntity, #loanLenderSelect, #loanPayAccount').val('').trigger('change');
            toggleTypePanels();
            toast(result.message || 'Loan submitted.');
            await refreshAll();
        } catch (error) {
            toast(error.message, 'error');
        } finally {
            button.disabled = false;
        }
    }

    function addTranche() {
        const wrap = $id('trancheRows');
        const index = wrap.querySelectorAll('.tranche-item').length + 1;
        const row = document.createElement('div');
        row.className = 'tranche-item row g-2 mb-2';
        row.innerHTML = `<div class="col-md-4"><input type="text" class="form-control date-picker" name="tranches[${index}][date]" placeholder="Disbursed date"></div><div class="col-md-4"><input type="number" min="0" step="0.01" class="form-control" name="tranches[${index}][amount]" placeholder="Amount"></div><div class="col-md-3"><input class="form-control" name="tranches[${index}][remarks]" placeholder="Remarks"></div><div class="col-md-1"><button type="button" class="btn btn-outline-danger w-100 remove-tranche"><i class="mdi mdi-delete-outline"></i></button></div>`;
        wrap.appendChild(row);
        initDatePickers(row);
        row.querySelector('.remove-tranche').onclick = () => row.remove();
    }

    function addJewelItem() {
        const wrap = $id('jewelItemRows');
        const index = wrap.querySelectorAll('.jewel-item').length;
        const row = document.createElement('div');
        row.className = 'jewel-item loan-jewel-row row g-2 mb-2';
        row.innerHTML = `<div class="col-md-5"><input class="form-control" name="jewel_items[${index}][description]" placeholder="Item description" required></div><div class="col-md-2"><input type="number" step="0.001" min="0" class="form-control" name="jewel_items[${index}][gross_weight]" placeholder="Gross wt"></div><div class="col-md-2"><input type="number" step="0.001" min="0" class="form-control" name="jewel_items[${index}][net_weight]" placeholder="Net wt"></div><div class="col-md-2"><input type="number" step="0.01" min="0" class="form-control" name="jewel_items[${index}][value]" placeholder="Value"></div><div class="col-md-1"><button type="button" class="btn btn-outline-danger w-100 remove-jewel"><i class="mdi mdi-delete-outline"></i></button></div>`;
        wrap.appendChild(row);
        row.querySelector('.remove-jewel').onclick = () => row.remove();
    }

    async function refreshAll() {
        setFilterUI();
        await Promise.all([loadLoans(), loadDashboard(), loadCalendar()]);
    }

    function bind() {
        document.querySelectorAll('#loanTypeFilters [data-value]').forEach((button) => button.addEventListener('click', () => { state.type = button.dataset.value; state.page = 1; setFilterUI(); loadLoans(); }));
        document.querySelectorAll('#loanStatusFilters [data-status-value]').forEach((button) => button.addEventListener('click', () => { state.status = button.dataset.statusValue; state.page = 1; setFilterUI(); loadLoans(); }));
        document.querySelectorAll('#calendarTypeFilters [data-value]').forEach((button) => button.addEventListener('click', () => { state.calendarType = button.dataset.value; setFilterUI(); loadCalendar(); }));
        document.querySelectorAll('#calendarStatusFilters [data-value]').forEach((button) => button.addEventListener('click', () => { state.calendarStatus = button.dataset.value; setFilterUI(); loadCalendar(); }));
        $id('loanEntityFilter')?.addEventListener('change', (e) => { state.entity = e.target.value; state.page = 1; loadLoans(); });
        $id('calendarEntity')?.addEventListener('change', (e) => { state.calendarEntity = e.target.value; loadCalendar(); });
        let searchTimer;
        $id('loanSearch')?.addEventListener('input', (event) => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { state.search = event.target.value.trim(); state.page = 1; loadLoans(); }, 250); });
        $id('refreshLoanModule')?.addEventListener('click', refreshAll);
        $id('calendarPageRefresh')?.addEventListener('click', loadCalendar);
        $id('viewCalendarToday')?.addEventListener('click', () => { state.calendarDate = new Date(); state.calendarView = 'month'; document.querySelectorAll('[data-calendar-view]').forEach((b) => b.classList.toggle('active', b.dataset.calendarView === 'month')); loadCalendar(); $id('scheduleCalendarCard')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
        $id('calendarToday')?.addEventListener('click', () => { state.calendarDate = new Date(); loadCalendar(); });
        $id('calendarCaptionToday')?.addEventListener('click', () => { state.calendarDate = new Date(); loadCalendar(); });
        $id('calendarPrev')?.addEventListener('click', () => { const step = state.calendarView === 'week' ? 7 : 1; state.calendarDate.setDate(state.calendarDate.getDate() - step); state.calendarExpanded = null; loadCalendar(); });
        $id('calendarNext')?.addEventListener('click', () => { const step = state.calendarView === 'week' ? 7 : 1; state.calendarDate.setDate(state.calendarDate.getDate() + step); state.calendarExpanded = null; loadCalendar(); });
        document.querySelectorAll('[data-calendar-view]').forEach((button) => button.addEventListener('click', () => { state.calendarView = button.dataset.calendarView; document.querySelectorAll('[data-calendar-view]').forEach((b) => b.classList.toggle('active', b === button)); loadCalendar(); }));
        $id('exportCalendar')?.addEventListener('click', () => toast('Calendar export is ready to be wired to the ERP report engine.', 'warning'));
        $id('loanDrawerClose')?.addEventListener('click', closeDrawer);
        $id('loanScrim')?.addEventListener('click', closeDrawer);
        document.addEventListener('click', (event) => { if (!event.target.closest('#calendarPopover') && !event.target.closest('.loan-obligation')) closePopover(); });

        document.querySelectorAll('#addLoanModal .loan-type-card').forEach((card) => card.addEventListener('click', () => { $id('loanTypeInput').value = card.dataset.type; toggleTypePanels(); }));
        $id('loanWizardNext')?.addEventListener('click', () => { const active = Number(document.querySelector('#addLoanModal [data-wizard-panel].active')?.dataset.wizardPanel || 1); if (active < 3 && validateStep(active)) wizardStep(active + 1); });
        $id('loanWizardPrev')?.addEventListener('click', () => { const active = Number(document.querySelector('#addLoanModal [data-wizard-panel].active')?.dataset.wizardPanel || 1); wizardStep(Math.max(1, active - 1)); });
        $id('saveLoan')?.addEventListener('click', saveLoan);
        $id('addTrancheBtn')?.addEventListener('click', addTranche);
        $id('addJewelItemBtn')?.addEventListener('click', addJewelItem);
        $id('loanEntity')?.addEventListener('change', () => { const selected = $id('loanEntity').selectedOptions[0]; $id('loanEntityName').value = selected?.value ? selected.textContent.trim() : ''; });
        ['sanction_amount', 'disbursed_amount', 'interest_rate', 'tenure_months'].forEach((name) => $id('addLoanForm')?.querySelector(`[name="${name}"]`)?.addEventListener('input', calculateEmi));
        $id('loanFrequency')?.addEventListener('change', calculateEmi);
        $id('loanInterestType')?.addEventListener('change', calculateEmi);
        $id('loanStartDate')?.addEventListener('change', calculateEmi);
        $id('paymentAmount')?.addEventListener('input', updateShortfall);
        $id('paymentAccount')?.addEventListener('change', (event) => { $id('paymentPayAccountId').value = event.target.value; });
        $id('loanPaymentForm')?.addEventListener('submit', submitPayment);
        $('#addLoanModal').on('shown.bs.modal', () => { wizardStep(1); initDatePickers($id('addLoanModal')); toggleTypePanels(); });
        $('#loanPaymentModal').on('shown.bs.modal', () => initDatePickers($id('loanPaymentModal')));
    }

    async function submitPayment(event) {
        event.preventDefault();
        const loanId = $id('paymentLoanId').value;
        if (!loanId) return toast('Loan reference is missing.', 'error');
        const button = $id('savePayment');
        button.disabled = true;
        try {
            const result = await api(urls.payment.replace(':id', loanId), { method: 'POST', body: new FormData(event.currentTarget) });
            bootstrap.Modal.getInstance($id('loanPaymentModal'))?.hide();
            toast(result.message || 'Payment recorded.');
            await refreshAll();
            closeDrawer();
        } catch (error) { toast(error.message, 'error'); } finally { button.disabled = false; }
    }

    loadLookups().catch((error) => console.warn('Loan lookups failed:', error));
    bind();
    initDatePickers();
    toggleTypePanels();
    setFilterUI();
    refreshAll();

})(window.jQuery || null);
