(function ($) {
    'use strict';
    const root = document.getElementById('loanDetailRoot');
    if (!root) return;
    const urls = window.loanDetailUrls || {};
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    let data = null;

    const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[m]);
    const inr = (v) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(v || 0));
    const date = (v) => v ? new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(`${v}T00:00:00`)) : '—';
    const type = (v) => ({ vehicle:['🚗','Vehicle Loan'], term:['📄','Business Term Loan'], jewel:['💍','Jewel Loan'], cc:['🏦','Cash Credit'] }[v] || ['📁','Loan']);
    const chip = (v) => `<span class="loan-chip ${esc(v)}">${esc({ active:'Active', pending_approval:'Pending Approval', returned:'Returned', closed:'Closed', overdue:'Overdue', today:'Due Today', upcoming:'Upcoming', paid:'Paid', partial:'Part Paid', foreclosed:'Foreclosed', restructured:'Restructured' }[v] || v || '—')}</span>`;

    async function api(url, options = {}) {
        const config = { ...options, headers: Object.assign({ Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, options.headers || {}) };
        if (csrf) config.headers['X-CSRF-TOKEN'] = csrf;
        const response = await fetch(url, config);
        const result = await response.json().catch(() => ({}));
        if (!response.ok || Number(result.status || 200) >= 400) throw new Error(result.message || 'Request failed.');
        return result;
    }

    function toast(message, kind = 'success') {
        const box = document.getElementById('loanDetailToast');
        box.className = `toast ${kind === 'error' ? 'bg-danger' : 'bg-success'} text-white`;
        box.querySelector('.toast-body').textContent = message;
        bootstrap.Toast.getOrCreateInstance(box, { delay: 3200 }).show();
    }

    function renderHeader() {
        const loan = data.loan;
        const meta = type(loan.type);
        document.getElementById('detailTypeIcon').textContent = meta[0];
        document.getElementById('detailEntity').textContent = loan.entity || 'Unassigned entity';
        document.getElementById('detailTitle').textContent = `${loan.lender || 'Loan'} — ${loan.account_no || ''}`;
        document.getElementById('detailSub').textContent = `${meta[1]} · ${loan.entity || '—'} · ${loan.interest_rate ?? '—'}% per year`;
        document.getElementById('detailStatus').innerHTML = chip(loan.status);
        document.getElementById('detailOutstanding').textContent = inr(loan.outstanding);
        document.getElementById('detailProgressText').textContent = `${loan.paid_months || 0} / ${loan.total_months || 0} months`;
        document.getElementById('detailProgressBar').style.width = `${loan.total_months ? Math.min(100, Math.round((loan.paid_months / loan.total_months) * 100)) : 0}%`;
        document.getElementById('detailMaturity').textContent = `Maturity ${date(loan.maturity)} · Next due ${date(loan.next_due)}`;

        const actions = document.getElementById('detailActionButtons');
        actions.innerHTML = `<div class="dropdown"><button class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown">Actions</button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" data-action="payment"><i class="mdi mdi-cash-check me-2"></i>Record Payment</button></li><li><button class="dropdown-item" data-action="prepay"><i class="mdi mdi-cash-fast me-2"></i>Part-Prepay / Foreclose</button></li><li><button class="dropdown-item" data-action="restructure" disabled><i class="mdi mdi-vector-link me-2"></i>Restructure <span class="small text-muted">Setup next</span></button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" data-action="close"><i class="mdi mdi-close-circle-outline me-2"></i>Close Loan</button></li></ul></div>`;
        actions.querySelector('[data-action="payment"]').onclick = () => openPayment(findNext());
        actions.querySelector('[data-action="prepay"]').onclick = () => openPrepay();
        actions.querySelector('[data-action="restructure"]').onclick = () => openRestructure();
        actions.querySelector('[data-action="close"]').onclick = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('closeLoanModal')).show();

        if (loan.status === 'pending_approval') {
            actions.insertAdjacentHTML('afterbegin', `<button class="btn btn-success btn-sm" id="detailApprove"><i class="mdi mdi-check me-1"></i>Approve</button><button class="btn btn-outline-danger btn-sm" id="detailReturn">Return</button>`);
            document.getElementById('detailApprove').onclick = approveLoan;
            document.getElementById('detailReturn').onclick = returnLoan;
        }
    }

    function findNext() {
        return [...(data.obligations || [])].filter((x) => ['overdue','partial','today','upcoming'].includes(x.status)).sort((a,b) => String(a.date).localeCompare(String(b.date)))[0] || { loan_id: data.loan.id, amount: data.loan.emi, date: data.loan.next_due, title: 'Loan payment' };
    }

    function renderOverview() {
        const l = data.loan;
        const body = document.getElementById('detailTabBody');
        let typeHtml = '';
        if (l.type === 'vehicle' && data.vehicle) typeHtml = `<div class="loan-type-detail-card"><div class="loan-card-title mb-2">Vehicle details</div><div class="loan-detail-grid"><div><small>Registration</small><strong>${esc(data.vehicle.registration_no)}</strong></div><div><small>Make / Model</small><strong>${esc(data.vehicle.make_model)}</strong></div><div><small>Chassis</small><strong>${esc(data.vehicle.chassis_no || '—')}</strong></div><div><small>Engine</small><strong>${esc(data.vehicle.engine_no || '—')}</strong></div></div></div>`;
        if (l.type === 'cc' && data.cc) typeHtml = `<div class="loan-type-detail-card"><div class="loan-card-title mb-2">CC facility</div><div class="loan-detail-grid"><div><small>Sanctioned Limit</small><strong>${inr(data.cc.sanctioned_limit)}</strong></div><div><small>Drawing Power</small><strong>${inr(data.cc.drawing_power)}</strong></div><div><small>Margin</small><strong>${esc(data.cc.margin_percent)}%</strong></div><div><small>Renewal</small><strong>${date(data.cc.renewal_date)}</strong></div></div></div>`;
        if (l.type === 'jewel' && data.jewel) typeHtml = `<div class="loan-type-detail-card"><div class="loan-card-title mb-2">Jewel pledge</div><div class="loan-detail-grid"><div><small>Receipt No.</small><strong>${esc(data.jewel.pledge_receipt_no)}</strong></div><div><small>Interest pattern</small><strong>${esc(data.jewel.interest_pattern)}</strong></div><div><small>Redemption</small><strong>${date(data.jewel.redemption_due_date)}</strong></div><div><small>Appraised value</small><strong>${inr(data.jewel.appraised_value)}</strong></div></div></div>`;
        body.innerHTML = `<div class="row g-3 p-3"><div class="col-12"><div class="loan-detail-grid"><div><small>Loan A/c No.</small><strong>${esc(l.account_no)}</strong></div><div><small>Loan Type</small><strong>${esc(type(l.type)[1])}</strong></div><div><small>Sanctioned / Limit</small><strong>${inr(l.sanction_amount)}</strong></div><div><small>Disbursed</small><strong>${inr(l.disbursed_amount)}</strong></div><div><small>Interest</small><strong>${esc(l.interest_rate)}% · ${esc(l.frequency || 'monthly')}</strong></div><div><small>Monthly EMI</small><strong>${Number(l.emi || 0) ? inr(l.emi) : '—'}</strong></div></div></div>${typeHtml ? `<div class="col-12">${typeHtml}</div>` : ''}</div>`;
    }

    function renderSchedule() {
        const active = (data.schedules || []).find((x) => x.active) || (data.schedules || [])[0];
        const versions = (data.schedules || []).map((s) => `<option value="${s.id}" ${s.active ? 'selected' : ''}>v${s.version} — ${esc(s.label)}</option>`).join('');
        document.getElementById('detailTabBody').innerHTML = `<div class="p-3"><div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><div><div class="loan-card-title">Repayment Schedule</div><div class="small text-muted">Paid rows are retained for audit; the active version drives the calendar.</div></div><select class="form-select form-select-sm" style="width:auto;min-width:240px" id="scheduleVersionSelect">${versions}</select></div>${active?.lines?.length ? `<div class="loan-table-wrap"><table class="table loan-table mb-0"><thead><tr><th>#</th><th>Due Date</th><th class="text-end">EMI</th><th class="text-end">Principal</th><th class="text-end">Interest</th><th class="text-end">Balance</th><th>Status</th></tr></thead><tbody>${active.lines.map((line) => `<tr class="${line.status === 'paid' ? 'table-success' : ''}"><td>${line.installment_no}</td><td>${date(line.due_date)}</td><td class="text-end">${inr(line.emi_amount)}</td><td class="text-end">${inr(line.principal_amount)}</td><td class="text-end">${inr(line.interest_amount)}</td><td class="text-end">${inr(line.closing_balance)}</td><td>${chip(line.status)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="loan-empty"><i class="mdi mdi-table-off"></i><strong>No amortisation schedule</strong><span>Jewel and CC loans use obligation-based schedules.</span></div>'}</div>`;
    }

    function renderPayments() {
        const rows = data.payments || [];
        document.getElementById('detailTabBody').innerHTML = `<div class="p-3"><div class="d-flex justify-content-between align-items-center mb-2"><div><div class="loan-card-title">Payment History</div><div class="small text-muted">Every posted payment remains auditable.</div></div><button class="btn btn-success btn-sm" id="tabRecordPayment">Record Payment</button></div>${rows.length ? rows.map((p) => `<div class="loan-payment-line"><div><strong>${inr(p.amount)}</strong><span>${date(p.payment_date)} · ${esc(p.mode || '—')} · ${esc(p.reference_no || '—')}</span></div>${chip(p.status || 'paid')}</div>`).join('') : '<div class="loan-empty compact"><i class="mdi mdi-cash-remove"></i><strong>No payments recorded</strong></div>'}</div>`;
        document.getElementById('tabRecordPayment').onclick = () => openPayment(findNext());
    }

    function renderDocuments() {
        const rows = data.documents || [];
        document.getElementById('detailTabBody').innerHTML = `<div class="p-3"><div class="loan-card-title">Loan Documents</div><div class="small text-muted mb-3">Sanction letter, agreement, lender schedule, NOC and security documents.</div>${rows.length ? `<div class="row g-2">${rows.map((doc) => `<div class="col-md-6"><div class="loan-document-card"><i class="mdi mdi-file-document-outline"></i><div><strong>${esc(doc.original_name)}</strong><span>${esc(doc.document_type || 'Document')}</span></div></div></div>`).join('')}</div>` : '<div class="loan-empty compact"><i class="mdi mdi-file-outline"></i><strong>No documents attached</strong></div>'}</div>`;
    }

    function renderAudit() {
        const rows = data.audit || [];
        document.getElementById('detailTabBody').innerHTML = `<div class="p-3"><div class="loan-card-title">Who did what, when</div><div class="small text-muted mb-3">Immutable module activity including approvals and payment events.</div>${rows.length ? rows.map((a) => `<div class="loan-timeline-item"><span class="loan-timeline-dot"></span><div><strong>${esc(a.action)}</strong><span>${esc(a.user_id || 'System')} · ${a.created_at ? new Date(a.created_at).toLocaleString('en-GB') : '—'}</span></div></div>`).join('') : '<div class="loan-empty compact"><i class="mdi mdi-history"></i><strong>No audit events</strong></div>'}</div>`;
    }

    function selectTab(tab) {
        document.querySelectorAll('#detailTabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
        ({ overview: renderOverview, schedule: renderSchedule, payments: renderPayments, documents: renderDocuments, audit: renderAudit }[tab] || renderOverview)();
    }

    async function openPayment(item) {
        const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('detailPaymentModal'));
        document.getElementById('detailPaymentObligation').value = item?.id || '';
        document.getElementById('detailPaymentHint').textContent = `${item?.title || 'Loan payment'} · due ${date(item?.date || data.loan.next_due)}`;
        document.getElementById('detailPaymentAmount').value = item?.amount || data.loan.emi || '';
        document.getElementById('detailPaymentDate').value = new Date().toISOString().slice(0,10);
        modal.show();
    }

    async function approveLoan() {
        try { await api(urls.approve, { method: 'POST' }); toast('Loan approved and schedule activated.'); await load(); } catch (e) { toast(e.message, 'error'); }
    }
    async function returnLoan() {
        const remarks = prompt('Return reason:'); if (!remarks) return;
        try { await api(urls.return, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ remarks }) }); toast('Loan returned to maker.'); await load(); } catch (e) { toast(e.message, 'error'); }
    }
    function openRestructure() {
        const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('restructureModal'));
        document.getElementById('restructureDate').value = new Date().toISOString().slice(0, 10);
        document.getElementById('restructureRate').value = data.loan.interest_rate ?? '';
        document.getElementById('restructureTenure').value = data.loan.tenure_months ?? '';
        document.getElementById('restructurePreview').innerHTML = '<div class="loan-review-note"><i class="mdi mdi-information-outline"></i><span>Change the rate or tenure to preview the revised repayment plan.</span></div>';
        modal.show();
        previewRestructure();
    }

    async function previewRestructure() {
        const rate = document.getElementById('restructureRate')?.value;
        const tenure = document.getElementById('restructureTenure')?.value;
        const effective = document.getElementById('restructureDate')?.value;
        if (!rate || !tenure || !effective) return;
        try {
            const params = new URLSearchParams({ interest_rate: rate, tenure_months: tenure, effective_date: effective });
            const result = await fetch(`${urls.restructurePreview}?${params.toString()}`, { method:'POST', headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body: params.toString() });
            const d = await result.json();
            if (!result.ok) throw new Error(d.message || 'Unable to preview restructure.');
            const x = d.data;
            document.getElementById('restructurePreview').innerHTML = [
                ['Current EMI', inr(x.current.emi)], ['Current Rate', `${x.current.rate}%`], ['Current Maturity', date(x.current.maturity)],
                ['Remaining Principal', inr(x.current.remaining_principal)], ['New EMI', inr(x.proposed.emi)], ['New Rate', `${x.proposed.rate}%`],
                ['New Tenure', `${x.proposed.months} months`], ['Interest Estimate', inr(x.proposed.interest_total)],
            ].map(([a,b]) => `<div class="loan-review-item"><small>${a}</small><strong>${b}</strong></div>`).join('');
        } catch (e) {
            document.getElementById('restructurePreview').innerHTML = `<div class="loan-review-note warning"><i class="mdi mdi-alert-outline"></i><span>${esc(e.message)}</span></div>`;
        }
    }

    async function submitRestructure(event) {
        event.preventDefault();
        try {
            await api(urls.restructure, { method:'POST', body:new FormData(event.currentTarget) });
            bootstrap.Modal.getInstance(document.getElementById('restructureModal'))?.hide();
            toast('Restructure submitted for Finance Head approval.');
            await load();
        } catch (e) { toast(e.message, 'error'); }
    }

    function openPrepay() { bootstrap.Modal.getOrCreateInstance(document.getElementById('prepayModal')).show(); document.getElementById('prepayDate').value = new Date().toISOString().slice(0,10); }
    async function previewPrepay() {
        const form = document.getElementById('prepayForm');
        const result = await api(urls.prepayPreview, { method:'POST', body:new FormData(form) });
        const d = result.data;
        document.getElementById('prepayPreview').innerHTML = [['Current EMI',inr(d.current.emi)],['Remaining Principal',inr(d.current.principal)],['New EMI',inr(d.proposed.emi)],['Interest Estimate',inr(d.proposed.interest_total)]].map(([a,b])=>`<div class="loan-review-item"><small>${a}</small><strong>${b}</strong></div>`).join('');
    }
    async function submitPrepay(event) { event.preventDefault(); try { await api(urls.prepay,{method:'POST',body:new FormData(event.currentTarget)}); bootstrap.Modal.getInstance(document.getElementById('prepayModal'))?.hide(); toast('Prepayment submitted for approval.'); await load(); } catch(e){toast(e.message,'error');} }
    async function submitClose(event) { event.preventDefault(); if (!document.getElementById('nocReceived').checked || !document.getElementById('securityReleased').checked){toast('Complete the closure checklist first.','error');return;} try { await api(urls.close,{method:'POST',body:new FormData(event.currentTarget)}); bootstrap.Modal.getInstance(document.getElementById('closeLoanModal'))?.hide(); toast('Loan closed.'); await load(); } catch(e){toast(e.message,'error');} }
    async function submitPayment(event){event.preventDefault();try{await api(urls.payment,{method:'POST',body:new FormData(event.currentTarget)});bootstrap.Modal.getInstance(document.getElementById('detailPaymentModal'))?.hide();toast('Payment recorded.');await load();}catch(e){toast(e.message,'error');}}

    async function load(){
        document.getElementById('loanDetailLoading').classList.remove('d-none');
        document.getElementById('loanDetailContent').classList.add('d-none');
        try{const result=await api(urls.show);data=result.data;renderHeader();selectTab(document.querySelector('#detailTabs button.active')?.dataset.tab||'overview');document.getElementById('loanDetailContent').classList.remove('d-none');}catch(e){toast(e.message,'error');}finally{document.getElementById('loanDetailLoading').classList.add('d-none');}
    }

    document.querySelectorAll('#detailTabs button').forEach((button)=>button.onclick=()=>selectTab(button.dataset.tab));
    document.getElementById('detailPaymentForm').addEventListener('submit',submitPayment);
    document.getElementById('prepayForm').addEventListener('submit',submitPrepay);
    document.getElementById('closeLoanForm').addEventListener('submit',submitClose);
    document.getElementById('restructureForm')?.addEventListener('submit', submitRestructure);
    ['prepayAmount','prepayDate','prepayMode'].forEach(id=>document.getElementById(id)?.addEventListener('change',()=>previewPrepay().catch(()=>{})));
    ['restructureRate','restructureTenure','restructureDate'].forEach(id=>document.getElementById(id)?.addEventListener('change',()=>previewRestructure()));
    if ($.fn.datepicker) $(document).find('.date-picker').datepicker({format:'yyyy-mm-dd',autoclose:true,todayHighlight:true});
    load();
})(window.jQuery);
