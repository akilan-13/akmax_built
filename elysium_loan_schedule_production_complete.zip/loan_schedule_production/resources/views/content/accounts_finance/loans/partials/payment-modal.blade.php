<div class="modal fade loan-modal" id="loanPaymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="loanPaymentForm">
                @csrf
                <div class="modal-header"><div><h5 class="modal-title mb-1"><i class="mdi mdi-cash-check me-1 text-success"></i>Record Payment</h5><div class="small text-muted" id="paymentLoanSummary">—</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <input type="hidden" name="obligation_id" id="paymentObligationId"><input type="hidden" name="pay_from_account_id" id="paymentPayAccountId"><input type="hidden" id="paymentLoanId">
                    <div class="loan-payment-banner"><div><span class="small text-muted">Amount due</span><strong id="paymentAmountDue">₹0</strong></div><div><span class="small text-muted">Due date</span><strong id="paymentDueDate">—</strong></div><div><span class="small text-muted">Remaining</span><strong id="paymentRemaining">₹0</strong></div></div>
                    <div class="row g-3 mt-1">
                        <div class="col-md-4"><label class="form-label">Paid Amount <span class="text-danger">*</span></label><input type="number" class="form-control" name="amount" id="paymentAmount" min="0.01" step="0.01" required></div>
                        <div class="col-md-4"><label class="form-label">Payment Date <span class="text-danger">*</span></label><input type="text" class="form-control date-picker" name="payment_date" id="paymentDate" required value="{{ now()->format('Y-m-d') }}"></div>
                        <div class="col-md-4"><label class="form-label">Mode <span class="text-danger">*</span></label><select class="form-select" name="mode" id="paymentMode"><option>NACH</option><option>NEFT/RTGS</option><option>Cash</option><option>Cheque</option></select></div>
                        <div class="col-md-6"><label class="form-label">Reference No.</label><input class="form-control" name="reference_no" id="paymentReference" maxlength="120"></div>
                        <div class="col-md-6"><label class="form-label">Pay From Account</label><select class="form-select" id="paymentAccount"></select></div>
                        <div class="col-md-6"><label class="form-label">Penal Interest</label><input type="number" class="form-control" name="penal_interest" min="0" step="0.01" value="0"></div>
                        <div class="col-md-6"><label class="form-label">Bounce Charge</label><input type="number" class="form-control" name="bounce_charge" min="0" step="0.01" value="0"></div>
                        <div class="col-12"><div id="paymentShortfall" class="loan-shortfall d-none"></div></div>
                        <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="3" maxlength="1000" placeholder="Optional payment note"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-success" id="savePayment"><i class="mdi mdi-check-circle-outline me-1"></i>Save Payment</button></div>
            </form>
        </div>
    </div>
</div>
