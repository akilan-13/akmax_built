<div class="modal fade loan-modal" id="addLoanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <form id="addLoanForm" novalidate>
                @csrf
                <div class="modal-header">
                    <div><h5 class="modal-title mb-1"><i class="mdi mdi-bank-plus me-1 text-primary"></i>Add Loan</h5><div class="small text-muted">Capture the borrowing. Finance Head approval activates the schedule.</div></div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="loan-wizard-steps">
                        <span class="active" data-wizard-step="1"><b>1</b> Basics</span><span data-wizard-step="2"><b>2</b> Amounts & Dates</span><span data-wizard-step="3"><b>3</b> Review</span>
                    </div>
                    <input type="hidden" name="loan_type" id="loanTypeInput" value="vehicle">

                    <section class="loan-wizard-panel active" data-wizard-panel="1">
                        <div class="loan-form-section-title">Loan basics</div>
                        <div class="row g-3">
                            <div class="col-lg-4"><label class="form-label">Entity <span class="text-danger">*</span></label><select class="form-select select2" id="loanEntity" name="entity_id" required><option value="">Select entity</option></select><input type="hidden" name="entity_name" id="loanEntityName"></div>
                            <div class="col-lg-4"><label class="form-label">Lender <span class="text-danger">*</span></label><select class="form-select select2" id="loanLenderSelect" name="lender_id"><option value="">Select existing lender</option></select><input class="form-control mt-2" name="lender_name" id="loanLenderName" placeholder="Or enter a new lender name"><div class="small text-muted mt-1">Existing lender is preferred.</div></div>
                            <div class="col-lg-4"><label class="form-label">Loan A/c No. <span class="text-danger">*</span></label><input class="form-control" name="loan_account_no" required maxlength="120" placeholder="Bank / NBFC account number"></div>
                        </div>
                        <div class="loan-form-section-title mt-4">Loan type</div>
                        <div class="row g-3">
                            @foreach($loanTypes as $key => $type)
                                <div class="col-6 col-lg-3"><button type="button" class="loan-type-card {{ $loop->first ? 'selected' : '' }}" data-type="{{ $key }}" data-hint="{{ $key === 'vehicle' ? 'EMI loan against a vehicle.' : ($key === 'term' ? 'Business borrowing with single or multiple tranches.' : ($key === 'jewel' ? 'Pledge-based borrowing with an interest pattern and redemption deadline.' : 'Working-capital limit with annual renewal.')) }}"><span class="loan-type-icon">{{ $type['icon'] }}</span><strong>{{ $type['label'] }}</strong></button></div>
                            @endforeach
                        </div>
                        <div id="loanTypeHint" class="loan-type-hint mt-3">EMI loan against a vehicle.</div>
                    </section>

                    <section class="loan-wizard-panel" data-wizard-panel="2">
                        <div class="loan-form-section-title">Amounts & dates</div>
                        <div class="row g-3">
                            <div class="col-md-4"><label class="form-label">Sanctioned / Limit Amount <span class="text-danger">*</span></label><input type="number" min="0" step="0.01" class="form-control emi-input" name="sanction_amount" required></div>
                            <div class="col-md-4"><label class="form-label">Disbursed Amount</label><input type="number" min="0" step="0.01" class="form-control emi-input" name="disbursed_amount"></div>
                            <div class="col-md-4"><label class="form-label">Interest Rate % <span class="text-danger">*</span></label><input type="number" min="0" max="100" step="0.0001" class="form-control emi-input" name="interest_rate" required></div>
                            <div class="col-md-4"><label class="form-label">Start Date <span class="text-danger">*</span></label><input type="text" class="form-control date-picker" name="start_date" id="loanStartDate" required value="{{ now()->format('Y-m-d') }}"></div>
                            <div class="col-md-4"><label class="form-label">Tenure (months)</label><input type="number" min="1" max="480" class="form-control emi-input" name="tenure_months" id="loanTenure"></div>
                            <div class="col-md-4"><label class="form-label">Frequency</label><select class="form-select" name="frequency" id="loanFrequency"><option value="monthly">Monthly</option><option value="quarterly">Quarterly</option></select></div>
                            <div class="col-md-4"><label class="form-label">Interest Method</label><select class="form-select" name="interest_type" id="loanInterestType"><option value="reducing_balance">Reducing Balance</option><option value="flat_rate">Flat Rate</option></select></div>
                            <div class="col-md-4"><label class="form-label">Pay From Account</label><select class="form-select select2" id="loanPayAccount" name="pay_from_account_id"><option value="">Select bank account</option></select></div>
                            <div class="col-md-4"><label class="form-label">Internal Loan Name</label><input class="form-control" name="loan_name" placeholder="e.g. Bolero Finance"></div>
                        </div>

                        <div class="loan-live-emi mt-3" id="emiPreviewCard">
                            <div><span class="small text-muted">Estimated monthly payment</span><div class="loan-live-emi-value" id="emiPreviewValue">₹0</div></div>
                            <div class="text-end"><span class="small text-muted">Estimated maturity</span><div class="fw-bold" id="emiMaturityValue">—</div></div>
                        </div>

                        <div data-type-panel="vehicle" class="row g-3 mt-1">
                            <div class="col-md-4"><label class="form-label">Vehicle Registration <span class="text-danger">*</span></label><input class="form-control" name="registration_no"></div>
                            <div class="col-md-4"><label class="form-label">Make / Model <span class="text-danger">*</span></label><input class="form-control" name="make_model"></div>
                            <div class="col-md-4"><label class="form-label">Insurance Renewal</label><input type="text" class="form-control date-picker" name="insurance_renewal_date"></div>
                            <div class="col-md-6"><label class="form-label">Chassis No.</label><input class="form-control" name="chassis_no"></div>
                            <div class="col-md-6"><label class="form-label">Engine No.</label><input class="form-control" name="engine_no"></div>
                        </div>

                        <div data-type-panel="term" class="loan-type-panel d-none mt-3">
                            <div class="loan-subpanel"><div class="d-flex justify-content-between align-items-center mb-2"><div><strong>Disbursement tranches</strong><div class="small text-muted">Use this only when disbursement happens in multiple parts.</div></div><button type="button" class="btn btn-outline-primary btn-sm" id="addTrancheBtn"><i class="mdi mdi-plus me-1"></i>Add tranche</button></div><div id="trancheRows"></div></div>
                        </div>

                        <div data-type-panel="jewel" class="loan-type-panel d-none mt-3">
                            <div class="row g-3">
                                <div class="col-md-4"><label class="form-label">Pledge Receipt No. <span class="text-danger">*</span></label><input class="form-control" name="pledge_receipt_no"></div>
                                <div class="col-md-4"><label class="form-label">Pledged-at Branch</label><input class="form-control" name="pledged_at_branch"></div>
                                <div class="col-md-4"><label class="form-label">Interest Pattern</label><select class="form-select" name="interest_pattern"><option value="monthly">Monthly Interest</option><option value="redemption">Lump-sum at Redemption</option></select></div>
                                <div class="col-md-4"><label class="form-label">Redemption Due Date <span class="text-danger">*</span></label><input type="text" class="form-control date-picker" name="redemption_due_date"></div>
                                <div class="col-md-4"><label class="form-label">Appraised Value</label><input type="number" step="0.01" min="0" class="form-control" name="appraised_value"></div>
                                <div class="col-12"><div id="jewelItemRows"></div><button type="button" class="btn btn-outline-primary btn-sm" id="addJewelItemBtn"><i class="mdi mdi-plus me-1"></i>Add pledged item</button></div>
                            </div>
                        </div>

                        <div data-type-panel="cc" class="loan-type-panel d-none mt-3">
                            <div class="row g-3">
                                <div class="col-md-4"><label class="form-label">Sanctioned Limit <span class="text-danger">*</span></label><input type="number" step="0.01" min="0" class="form-control" name="sanctioned_limit"></div>
                                <div class="col-md-4"><label class="form-label">Margin %</label><input type="number" step="0.0001" min="0" max="100" class="form-control" name="margin_percent"></div>
                                <div class="col-md-4"><label class="form-label">Drawing Power</label><input type="number" step="0.01" min="0" class="form-control" name="drawing_power"></div>
                                <div class="col-md-4"><label class="form-label">Renewal Date <span class="text-danger">*</span></label><input type="text" class="form-control date-picker" name="renewal_date"></div>
                                <div class="col-md-4"><label class="form-label">Stock Statement Day</label><input type="number" min="1" max="31" class="form-control" name="stock_statement_day"></div>
                            </div>
                        </div>
                    </section>

                    <section class="loan-wizard-panel" data-wizard-panel="3">
                        <div class="loan-form-section-title">Review & submit</div>
                        <div id="loanReview" class="loan-review-grid"></div>
                        <div class="loan-review-note"><i class="mdi mdi-bell-outline"></i><div><strong>Reminder defaults</strong><div class="small">EMI: 7 & 1 days before · CC renewal: 45/30/15 days · Jewel redemption: 30/15/7 days.</div></div></div>
                        <div class="loan-review-note warning"><i class="mdi mdi-shield-check-outline"></i><div><strong>Approval control</strong><div class="small">Submitting creates a Pending Approval record. Finance Head approval activates the schedule and calendar obligations.</div></div></div>
                    </section>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <div class="d-flex gap-2"><button type="button" class="btn btn-outline-primary d-none" id="loanWizardPrev">Previous</button><button type="button" class="btn btn-primary" id="loanWizardNext">Next</button><button type="button" class="btn btn-success d-none" id="saveLoan"><i class="mdi mdi-send-outline me-1"></i>Submit for Approval</button></div>
                </div>
            </form>
        </div>
    </div>
</div>
