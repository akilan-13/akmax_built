@extends('layouts/layoutMaster')

@section('title', 'Schedule Calendar')

@section('vendor-style')
    @vite([
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    ])
@endsection

@section('vendor-script')
    @vite([
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    ])
@endsection

@section('page-style')
    @vite(['resources/css/pages/loan-schedule.css'])
@endsection

@section('page-script')
    <script>
        window.loanModuleUrls = @json([
            'data' => route('accounts_finance.loans.data'),
            'dashboard' => route('accounts_finance.loans.dashboard.data'),
            'lookups' => route('accounts_finance.loans.lookups'),
            'store' => route('accounts_finance.loans.store'),
            'calendar' => route('accounts_finance.loans.calendar.data'),
            'show' => route('accounts_finance.loans.data.show', ['loan' => ':id']),
            'detail' => route('accounts_finance.loans.show', ['loan' => ':id']),
            'payment' => route('accounts_finance.loans.payments.store', ['loan' => ':id']),
            'approve' => route('accounts_finance.loans.approve', ['loan' => ':id']),
            'return' => route('accounts_finance.loans.return', ['loan' => ':id']),
            'snooze' => route('accounts_finance.loans.obligations.snooze', ['obligation' => ':id']),
        ]);
    </script>
    @vite(['resources/js/pages/loan-schedule.js'])
@endsection

@section('content')
<div id="loanModuleRoot" class="loan-module">
    <div class="loan-page container-fluid py-3">
        <div class="loan-page-head">
            <div>
                <div class="loan-eyebrow"><i class="mdi mdi-calendar-month-outline me-1"></i> Accounts & Finance</div>
                <h1 class="loan-title">Schedule Calendar</h1>
                <p class="loan-subtitle">One calendar for EMIs, interest dues, renewals, stock statements and redemption deadlines.</p>
            </div>
            <div class="loan-page-actions">
                <a href="{{ route('accounts_finance.loans.index') }}" class="btn btn-outline-secondary btn-sm"><i class="mdi mdi-arrow-left me-1"></i>Loans</a>
                <button type="button" class="btn btn-primary btn-sm" id="calendarPageRefresh"><i class="mdi mdi-refresh me-1"></i>Refresh</button>
            </div>
        </div>

        <div class="loan-card" id="scheduleCalendarCard">
            <div class="loan-card-head calendar-head">
                <div>
                    <div class="loan-card-title">Repayment & Obligation Calendar</div>
                    <div class="loan-card-help">Click any obligation to see payment actions and open the loan.</div>
                </div>
                <div class="calendar-toolbar">
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="calendarToday">Today</button>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-secondary" id="calendarPrev">‹</button>
                        <button type="button" class="btn btn-outline-secondary" id="calendarNext">›</button>
                    </div>
                    <div class="btn-group btn-group-sm calendar-view-group">
                        <button type="button" class="btn btn-outline-primary active" data-calendar-view="month">Month</button>
                        <button type="button" class="btn btn-outline-primary" data-calendar-view="week">Week</button>
                        <button type="button" class="btn btn-outline-primary" data-calendar-view="list">List</button>
                    </div>
                </div>
            </div>

            <div class="loan-filter-row calendar-filter-row">
                <select id="calendarEntity" class="form-select form-select-sm"><option value="all">All Entities</option></select>
                <div class="loan-filter-chip-group" id="calendarTypeFilters">
                    <button type="button" class="loan-filter-chip active" data-value="all">All</button>
                    <button type="button" class="loan-filter-chip" data-value="vehicle">🚗</button>
                    <button type="button" class="loan-filter-chip" data-value="term">📄</button>
                    <button type="button" class="loan-filter-chip" data-value="jewel">💍</button>
                    <button type="button" class="loan-filter-chip" data-value="cc">🏦</button>
                </div>
                <div class="loan-filter-chip-group" id="calendarStatusFilters">
                    <button type="button" class="loan-filter-chip active" data-value="all">Any status</button>
                    <button type="button" class="loan-filter-chip" data-value="upcoming">Upcoming</button>
                    <button type="button" class="loan-filter-chip" data-value="today">Due Today</button>
                    <button type="button" class="loan-filter-chip" data-value="overdue">Overdue</button>
                    <button type="button" class="loan-filter-chip" data-value="paid">Paid</button>
                </div>
            </div>

            <div id="calendarLoading" class="loan-loading d-none"><span class="spinner-border spinner-border-sm me-2"></span>Loading calendar…</div>
            <div id="calendarGridWrap" class="loan-calendar-wrap">
                <div class="loan-calendar-titlebar"><button type="button" class="btn btn-link btn-sm" id="calendarCaptionToday">Jump to today</button><span id="calendarTitle"></span><button type="button" class="btn btn-link btn-sm" id="exportCalendar">Export Month</button></div>
                <div id="calendarGrid" class="loan-calendar"></div>
            </div>
            <div id="calendarWeekWrap" class="d-none"></div>
            <div id="agendaWrap" class="d-none"></div>
            <div class="loan-calendar-legend"><span><i class="legend-dot upcoming"></i>Upcoming</span><span><i class="legend-dot today"></i>Due Today</span><span><i class="legend-dot overdue"></i>Overdue</span><span><i class="legend-dot paid"></i>Paid</span><span class="ms-auto text-muted">🚗 Vehicle · 📄 Term · 💍 Jewel · 🏦 CC</span></div>
        </div>
    </div>
@include('content.accounts_finance.loans.partials.payment-modal')
@endsection
