@extends('layouts/layoutMaster')

@section('title', 'Loan Reports')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss','resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js','resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection
@section('page-style')
    @vite(['resources/css/pages/loan-schedule.css'])
@endsection
@section('page-script')
<script>window.loanReportUrls=@json(['data'=>route('accounts_finance.loans.reports.data'),'export'=>route('accounts_finance.loans.reports.export'),'index'=>route('accounts_finance.loans.reports.index'),'lookups'=>route('accounts_finance.loans.lookups')]);</script>
@vite(['resources/js/pages/loan-reports.js'])
@endsection

@section('content')
<div class="loan-page container-fluid py-3" id="loanReportsRoot">
    <div class="loan-page-head"><div><div class="loan-eyebrow"><i class="mdi mdi-file-chart-outline me-1"></i> Accounts & Finance</div><h1 class="loan-title">Loan Reports</h1><p class="loan-subtitle">Finance-ready reports with the same entity scope, Indian money format and ERP visual language.</p></div><div class="loan-page-actions"><a href="{{ route('accounts_finance.loans.index') }}" class="btn btn-outline-secondary btn-sm"><i class="mdi mdi-arrow-left me-1"></i>Loans</a><a href="{{ route('accounts_finance.loans.calendar') }}" class="btn btn-outline-primary btn-sm"><i class="mdi mdi-calendar-month-outline me-1"></i>Calendar</a></div></div>

    <div class="row g-3">
        <div class="col-12 col-xl-3">
            <div class="loan-card h-100">
                <div class="loan-card-title mb-1">Standard Reports</div><div class="loan-card-help mb-3">Select a report, set filters and run.</div>
                <div class="report-list" id="reportList">
                    @foreach($reports as $key => $report)
                        <button type="button" class="report-item {{ $loop->first ? 'active' : '' }}" data-report="{{ $key }}"><span class="report-code">{{ $key }}</span><span>{{ $report['name'] }}</span></button>
                    @endforeach
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-9">
            <div class="loan-card">
                <div class="loan-print-header"><h2 id="printReportTitle">Loan Report</h2><div id="printReportMeta"></div></div>
                <div class="loan-card-head"><div><div class="loan-card-title" id="reportTitle">{{ $reports['R1']['name'] }}</div><div class="loan-card-help">All reports are filterable by entity and date; generated timestamp is shown for audit.</div></div><button type="button" class="btn btn-primary btn-sm" id="runReport"><i class="mdi mdi-play me-1"></i>Run Report</button></div>
                <div class="row g-2 mb-3"><div class="col-md-3"><label class="form-label">From</label><input id="reportFrom" class="form-control date-picker" autocomplete="off"></div><div class="col-md-3"><label class="form-label">To</label><input id="reportTo" class="form-control date-picker" autocomplete="off"></div><div class="col-md-3"><label class="form-label">Entity</label><select id="reportEntity" class="form-select"><option value="all">All Entities</option></select></div><div class="col-md-3"><label class="form-label">Loan Type</label><select id="reportLoanType" class="form-select"><option value="all">All Types</option><option value="vehicle">Vehicle</option><option value="term">Term</option><option value="jewel">Jewel</option><option value="cc">CC</option></select></div></div>
                <div class="report-summary row g-2 mb-3" id="reportSummary"></div>
                <div class="loan-table-wrap" id="reportTableWrap" class="report-table-wrap"><div class="loan-empty compact"><i class="mdi mdi-file-chart-outline"></i><strong>Run a report</strong><span>Your report rows will appear here.</span></div></div>
                <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap mt-3"><small class="text-muted" id="reportGeneratedAt"></small><div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" id="exportXlsx">Export XLSX</button><button class="btn btn-outline-secondary" id="exportPdf">Export PDF</button></div></div>
            </div>
        </div>
    </div>
</div>
@endsection
