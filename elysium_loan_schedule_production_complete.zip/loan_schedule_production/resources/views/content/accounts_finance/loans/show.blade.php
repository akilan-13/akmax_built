@extends('layouts/layoutMaster')

@section('title', 'Loan Detail')

@section('vendor-style')
    @vite([
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    ])
@endsection

@section('vendor-script')
    @vite([
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    ])
@endsection

@section('page-style')
    @vite(['resources/css/pages/loan-schedule.css'])
@endsection

@section('page-script')
    <script>
        window.loanDetailUrls = @json([
            'show' => route('accounts_finance.loans.data.show', ['loan' => $record->sno]),
            'approve' => route('accounts_finance.loans.approve', ['loan' => $record->sno]),
            'return' => route('accounts_finance.loans.return', ['loan' => $record->sno]),
            'payment' => route('accounts_finance.loans.payments.store', ['loan' => $record->sno]),
            'prepayPreview' => route('accounts_finance.loans.prepay.preview', ['loan' => $record->sno]),
            'prepay' => route('accounts_finance.loans.prepay', ['loan' => $record->sno]),
            'prepayApprove' => route('accounts_finance.loans.prepay.approve', ['loan' => $record->sno]),
            'restructurePreview' => route('accounts_finance.loans.restructure.preview', ['loan' => $record->sno]),
            'restructure' => route('accounts_finance.loans.restructure', ['loan' => $record->sno]),
            'restructureApprove' => route('accounts_finance.loans.restructure.approve', ['loan' => $record->sno]),
            'close' => route('accounts_finance.loans.close', ['loan' => $record->sno]),
            'renewal' => route('accounts_finance.loans.renewal', ['loan' => $record->sno]),
        ]);
    </script>
    @vite(['resources/js/pages/loan-detail.js'])
@endsection

@section('content')
<div id="loanDetailRoot" class="loan-module">
    <div class="loan-page container-fluid py-3">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
            <a href="{{ route('accounts_finance.loans.index') }}" class="text-decoration-none small"><i class="mdi mdi-arrow-left me-1"></i>All loans</a>
            <div id="detailActionButtons" class="d-flex gap-2"></div>
        </div>

        <div id="loanDetailLoading" class="loan-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading loan…</div>
        <div id="loanDetailContent" class="d-none">
            <div class="loan-card loan-detail-hero mb-3">
                <div class="loan-detail-hero-main"><div class="loan-detail-type" id="detailTypeIcon">🚗</div><div><div class="loan-detail-kicker" id="detailEntity">—</div><h1 id="detailTitle">—</h1><div class="loan-detail-sub" id="detailSub">—</div><div class="mt-2" id="detailStatus"></div></div></div>
                <div class="loan-detail-money"><small>Amount Left to Pay</small><strong id="detailOutstanding">₹0</strong></div>
            </div>

            <div class="loan-detail-progress-card loan-card mb-3"><div class="d-flex justify-content-between gap-2 mb-2"><span class="small text-muted">Tenure progress</span><strong id="detailProgressText">0 / 0 months</strong></div><div class="loan-progress loan-progress-lg"><span id="detailProgressBar" style="width:0%"></span></div><div class="small text-muted mt-2" id="detailMaturity">Maturity —</div></div>

            <div class="loan-card">
                <div class="loan-detail-tabs" id="detailTabs"><button class="active" data-tab="overview">Overview</button><button data-tab="schedule">Schedule</button><button data-tab="payments">Payments</button><button data-tab="documents">Documents</button><button data-tab="audit">Audit</button></div>
                <div class="loan-detail-tab-body" id="detailTabBody"></div>
            </div>
        </div>
    </div>
</div>

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:1300"><div id="loanDetailToast" class="toast"><div class="d-flex"><div class="toast-body"></div><button class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>

<div class="modal fade loan-modal" id="detailPaymentModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content"><form id="detailPaymentForm"><div class="modal-header"><div><h5 class="modal-title">Record Payment</h5><div class="small text-muted" id="detailPaymentHint">—</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="obligation_id" id="detailPaymentObligation"><div class="row g-3"><div class="col-md-4"><label class="form-label">Amount</label><input class="form-control" type="number" name="amount" id="detailPaymentAmount" min="0.01" step="0.01" required></div><div class="col-md-4"><label class="form-label">Payment Date</label><input class="form-control" type="text" name="payment_date" id="detailPaymentDate" required></div><div class="col-md-4"><label class="form-label">Mode</label><select class="form-select" name="mode"><option>NACH</option><option>NEFT/RTGS</option><option>Cash</option><option>Cheque</option></select></div><div class="col-md-6"><label class="form-label">Reference No.</label><input class="form-control" name="reference_no" maxlength="120"></div><div class="col-md-6"><label class="form-label">Pay From Account</label><input class="form-control" name="pay_from_account_id" type="number"></div><div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="3"></textarea></div></div></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-success">Save Payment</button></div></form></div></div></div>

<div class="modal fade loan-modal" id="prepayModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content"><form id="prepayForm"><div class="modal-header"><div><h5 class="modal-title">Part-Prepay / Foreclose</h5><div class="small text-muted">Preview before submitting the schedule change to Finance Head.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="row g-3"><div class="col-md-4"><label class="form-label">Prepayment Amount</label><input class="form-control" name="amount" id="prepayAmount" type="number" min="0.01" step="0.01" required></div><div class="col-md-4"><label class="form-label">Effective Date</label><input class="form-control" name="date" id="prepayDate" type="text" required></div><div class="col-md-4"><label class="form-label">Change</label><select class="form-select" name="mode" id="prepayMode"><option value="emi">Reduce EMI</option><option value="tenure">Reduce Tenure</option></select></div></div><div id="prepayPreview" class="loan-review-grid mt-3"></div><div class="mt-3"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="3"></textarea></div></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Submit for Approval</button></div></form></div></div></div>

<div class="modal fade loan-modal" id="closeLoanModal" tabindex="-1"><div class="modal-dialog modal-md modal-dialog-centered"><div class="modal-content"><form id="closeLoanForm"><div class="modal-header"><h5 class="modal-title">Close Loan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="loan-review-note warning mb-3"><i class="mdi mdi-shield-check-outline"></i><div><strong>Closure checklist</strong><div class="small">Confirm NOC receipt and security release before closing.</div></div></div><div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="noc_received" value="1" id="nocReceived"><label class="form-check-label" for="nocReceived">NOC received</label></div><div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="security_released" value="1" id="securityReleased"><label class="form-check-label" for="securityReleased">Security / hypothecation / pledged item released</label></div><label class="form-label">Closure reason</label><textarea class="form-control" name="closure_reason" rows="3" required></textarea></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-danger">Close Loan</button></div></form></div></div></div>
<div class="modal fade loan-modal" id="restructureModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content"><form id="restructureForm"><div class="modal-header"><div><h5 class="modal-title">Restructure Loan</h5><div class="small text-muted">Change the rate or remaining tenure. Finance Head approval is required.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="row g-3"><div class="col-md-4"><label class="form-label">Effective Date</label><input class="form-control date-picker" type="text" name="effective_date" id="restructureDate" required></div><div class="col-md-4"><label class="form-label">New Interest Rate %</label><input class="form-control" type="number" min="0" max="100" step="0.01" name="interest_rate" id="restructureRate" required></div><div class="col-md-4"><label class="form-label">New Tenure (Months)</label><input class="form-control" type="number" min="1" max="240" name="tenure_months" id="restructureTenure" required></div></div><div class="loan-review-grid mt-3" id="restructurePreview"></div><div class="mt-3"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="3" maxlength="1000"></textarea></div></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Submit for Approval</button></div></form></div></div></div>

@endsection
