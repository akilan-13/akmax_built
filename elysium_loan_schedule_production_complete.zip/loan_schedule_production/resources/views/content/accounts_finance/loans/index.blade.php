@extends('layouts/layoutMaster')

@section('title', 'Loans & Schedules')

@section('vendor-style')
    @vite([
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    ])
@endsection

@section('vendor-script')
    @vite([
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    ])
@endsection

@section('page-style')
    @vite(['resources/css/pages/loan-schedule.css'])
@endsection

@section('page-script')
    <script>
        window.loanModuleUrls = @json([
            'data' => route('accounts_finance.loans.data'),
            'dashboard' => route('accounts_finance.loans.dashboard.data'),
            'lookups' => route('accounts_finance.loans.lookups'),
            'store' => route('accounts_finance.loans.store'),
            'calendar' => route('accounts_finance.loans.calendar.data'),
            'show' => route('accounts_finance.loans.data.show', ['loan' => ':id']),
            'detail' => route('accounts_finance.loans.show', ['loan' => ':id']),
            'payment' => route('accounts_finance.loans.payments.store', ['loan' => ':id']),
            'approve' => route('accounts_finance.loans.approve', ['loan' => ':id']),
            'return' => route('accounts_finance.loans.return', ['loan' => ':id']),
            'snooze' => route('accounts_finance.loans.obligations.snooze', ['obligation' => ':id']),
        ]);
    </script>
    @vite(['resources/js/pages/loan-schedule.js'])
@endsection

@section('content')
<div id="loanModuleRoot" class="loan-module">
    <div class="loan-page container-fluid py-3">
        <div class="loan-page-head">
            <div>
                <div class="loan-eyebrow"><i class="mdi mdi-bank-transfer me-1"></i> Accounts & Finance</div>
                <h1 class="loan-title">Loans & Schedules</h1>
                <p class="loan-subtitle">One group-wide place for loans, due dates, repayments and renewals.</p>
            </div>
            <div class="loan-page-actions">
                <button type="button" class="btn btn-outline-secondary btn-sm" id="refreshLoanModule">
                    <i class="mdi mdi-refresh me-1"></i>Refresh
                </button>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addLoanModal">
                    <i class="mdi mdi-plus me-1"></i>Add Loan
                </button>
            </div>
        </div>

        <div class="row g-3 mb-3" id="loanKpiGrid">
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="loan-card loan-kpi-card">
                    <div class="loan-kpi-icon navy"><i class="mdi mdi-cash-multiple"></i></div>
                    <div class="loan-kpi-copy"><span class="loan-kpi-label">Total Outstanding</span><strong id="kpiOutstanding">₹0</strong><small>Active group exposure</small></div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="loan-card loan-kpi-card">
                    <div class="loan-kpi-icon blue"><i class="mdi mdi-calendar-alert"></i></div>
                    <div class="loan-kpi-copy"><span class="loan-kpi-label">Due This Week</span><strong id="kpiDueWeek">0</strong><small id="kpiDueWeekAmount">₹0</small></div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="loan-card loan-kpi-card">
                    <div class="loan-kpi-icon red"><i class="mdi mdi-alert-circle-outline"></i></div>
                    <div class="loan-kpi-copy"><span class="loan-kpi-label">Overdue</span><strong id="kpiOverdue">0</strong><small id="kpiOverdueAmount">₹0</small></div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="loan-card loan-kpi-card">
                    <div class="loan-kpi-icon gold"><i class="mdi mdi-calendar-sync-outline"></i></div>
                    <div class="loan-kpi-copy"><span class="loan-kpi-label">Renewals / Redemptions</span><strong id="kpiRenewals">0</strong><small>Next 60 days</small></div>
                </div>
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-12 col-xl-8">
                <div class="loan-card loan-actions-card h-100">
                    <div class="loan-card-head">
                        <div><div class="loan-card-title">Today's Actions</div><div class="loan-card-help">Payments, overdue items and time-sensitive renewals.</div></div>
                        <button type="button" class="btn btn-link btn-sm p-0" id="viewCalendarToday">Open Calendar <i class="mdi mdi-arrow-top-right ms-1"></i></button>
                    </div>
                    <div id="todayActions" class="loan-action-list">
                        <div class="loan-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading actions…</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-xl-4">
                <div class="loan-card h-100">
                    <div class="loan-card-head">
                        <div><div class="loan-card-title">Entity Exposure</div><div class="loan-card-help">Outstanding by accessible entity.</div></div>
                    </div>
                    <div id="entityExposure" class="loan-exposure-list"></div>
                </div>
            </div>
        </div>

        <div class="loan-card mb-3" id="loanRegisterCard">
            <div class="loan-card-head loan-register-head">
                <div>
                    <div class="loan-card-title">Loan Register</div>
                    <div class="loan-card-help">Search, filter and open any loan without leaving the ERP.</div>
                </div>
                <div class="loan-search-wrap">
                    <i class="mdi mdi-magnify"></i>
                    <input type="search" id="loanSearch" class="form-control form-control-sm" placeholder="Search account no., lender or loan name" autocomplete="off">
                </div>
            </div>

            <div class="loan-filter-row" id="loanTypeFilters">
                @foreach(['all'=>'All','vehicle'=>'🚗 Vehicle','term'=>'📄 Term','jewel'=>'💍 Jewel','cc'=>'🏦 CC'] as $value => $label)
                    <button type="button" class="loan-filter-chip {{ $value === 'all' ? 'active' : '' }}" data-value="{{ $value }}">{{ $label }}</button>
                @endforeach
                <span class="loan-filter-separator"></span>
                @foreach(['all'=>'Any status','active'=>'Active','pending_approval'=>'Pending Approval','closed'=>'Closed','foreclosed'=>'Foreclosed'] as $value => $label)
                    <button type="button" class="loan-filter-chip" data-status-value="{{ $value }}">{{ $label }}</button>
                @endforeach
                <select id="loanEntityFilter" class="form-select form-select-sm loan-entity-filter"><option value="all">All Entities</option></select>
            </div>

            <div id="loanTableLoading" class="loan-loading d-none"><span class="spinner-border spinner-border-sm me-2"></span>Loading loans…</div>
            <div class="loan-table-wrap">
                <table class="table loan-table align-middle mb-0">
                    <thead>
                    <tr>
                        <th>Loan A/c No.</th>
                        <th>Type</th>
                        <th>Entity</th>
                        <th>Lender</th>
                        <th class="text-end">Outstanding</th>
                        <th class="text-end">EMI / Obligation</th>
                        <th>Next Due</th>
                        <th>Tenure</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                    </thead>
                    <tbody id="loanTableBody"></tbody>
                </table>
            </div>
            <div id="loanPagination" class="loan-pagination"></div>
        </div>

        <div class="loan-card" id="scheduleCalendarCard">
            <div class="loan-card-head calendar-head">
                <div>
                    <div class="loan-card-title">Repayment Schedule Calendar</div>
                    <div class="loan-card-help">EMIs, interest dues, CC renewals and jewel redemption deadlines.</div>
                </div>
                <div class="calendar-toolbar">
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="calendarToday">Today</button>
                    <div class="btn-group btn-group-sm" role="group" aria-label="Calendar navigation">
                        <button type="button" class="btn btn-outline-secondary" id="calendarPrev" aria-label="Previous">‹</button>
                        <button type="button" class="btn btn-outline-secondary" id="calendarNext" aria-label="Next">›</button>
                    </div>
                    <div class="btn-group btn-group-sm calendar-view-group" role="group" aria-label="Calendar view">
                        <button type="button" class="btn btn-outline-primary active" data-calendar-view="month">Month</button>
                        <button type="button" class="btn btn-outline-primary" data-calendar-view="week">Week</button>
                        <button type="button" class="btn btn-outline-primary" data-calendar-view="list">List</button>
                    </div>
                </div>
            </div>

            <div class="loan-filter-row calendar-filter-row">
                <select id="calendarEntity" class="form-select form-select-sm"><option value="all">All Entities</option></select>
                <div class="loan-filter-chip-group" id="calendarTypeFilters">
                    @foreach(['all'=>'All','vehicle'=>'🚗','term'=>'📄','jewel'=>'💍','cc'=>'🏦'] as $value => $label)
                        <button type="button" class="loan-filter-chip {{ $value === 'all' ? 'active' : '' }}" data-value="{{ $value }}">{{ $label }}</button>
                    @endforeach
                </div>
                <div class="loan-filter-chip-group" id="calendarStatusFilters">
                    @foreach(['all'=>'Any status','upcoming'=>'Upcoming','today'=>'Due Today','overdue'=>'Overdue','paid'=>'Paid'] as $value => $label)
                        <button type="button" class="loan-filter-chip {{ $value === 'all' ? 'active' : '' }}" data-value="{{ $value }}">{{ $label }}</button>
                    @endforeach
                </div>
            </div>

            <div id="calendarLoading" class="loan-loading d-none"><span class="spinner-border spinner-border-sm me-2"></span>Loading calendar…</div>
            <div id="calendarGridWrap" class="loan-calendar-wrap">
                <div class="loan-calendar-titlebar"><button type="button" class="btn btn-link btn-sm" id="calendarCaptionToday">Jump to today</button><span id="calendarTitle"></span><button type="button" class="btn btn-link btn-sm" id="exportCalendar">Export Month</button></div>
                <div id="calendarGrid" class="loan-calendar"></div>
            </div>
            <div id="calendarWeekWrap" class="d-none"></div>
            <div id="agendaWrap" class="d-none"></div>

            <div class="loan-legend mt-3">
                <span class="legend-label">Legend</span>
                <span><i class="legend-dot upcoming"></i>Upcoming</span>
                <span><i class="legend-dot today"></i>Due Today</span>
                <span><i class="legend-dot overdue"></i>Overdue</span>
                <span><i class="legend-dot paid"></i>Paid</span>
                <span class="legend-types">🚗 Vehicle · 📄 Term · 💍 Jewel · 🏦 CC</span>
            </div>
        </div>
    </div>
</div>

<div id="loanScrim" class="loan-scrim"></div>
<aside id="loanDrawer" class="loan-drawer" aria-hidden="true">
    <div class="loan-drawer-head">
        <div class="d-flex align-items-start gap-2">
            <div class="flex-grow-1"><div id="loanDrawerTitle" class="loan-drawer-title"></div><div id="loanDrawerSub" class="loan-drawer-sub"></div></div>
            <button type="button" id="loanDrawerClose" class="btn btn-sm btn-light"><i class="mdi mdi-close"></i></button>
        </div>
    </div>
    <div id="loanDrawerBody" class="loan-drawer-body"></div>
</aside>

<div id="calendarPopover" class="loan-popover d-none"></div>

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:1300">
    <div id="loanToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex"><div class="toast-body"></div><button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"></button></div>
    </div>
</div>

@include('content.accounts_finance.loans.partials.add-loan-modal')
@include('content.accounts_finance.loans.partials.payment-modal')
@endsection
