<?php

namespace App\Console\Commands;

use App\Services\Loan\LoanNotifierService;
use Illuminate\Console\Command;

class LoanDispatchNotifications extends Command
{
    protected $signature = 'loan:dispatch-notifications';
    protected $description = 'Queue and dispatch Elysium loan reminder notifications.';

    public function handle(LoanNotifierService $notifier): int
    {
        $result = $notifier->run();
        $this->info(sprintf('Loan notifications: %d queued, %d sent, %d failed.', $result['queued'], $result['sent'], $result['failed']));
        return $result['failed'] > 0 ? self::FAILURE : self::SUCCESS;
    }
}
