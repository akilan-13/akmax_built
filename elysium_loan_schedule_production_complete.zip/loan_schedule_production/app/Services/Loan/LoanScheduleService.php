<?php

namespace App\Services\Loan;

use App\Models\Loan;
use App\Models\LoanObligation;
use App\Models\LoanSchedule;
use App\Models\LoanScheduleLine;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class LoanScheduleService
{
    public function emi(float $principal, float $annualRate, int $periods): float
    {
        if ($periods <= 0) {
            return 0.0;
        }

        $monthlyRate = $annualRate / 1200;
        if (abs($monthlyRate) < 0.00000001) {
            return round($principal / $periods, 2);
        }

        $factor = pow(1 + $monthlyRate, $periods);
        return round($principal * $monthlyRate * $factor / ($factor - 1), 2);
    }

    public function generate(Loan $loan, bool $activate = true, ?Carbon $effectiveDate = null): LoanSchedule
    {
        return DB::transaction(function () use ($loan, $activate, $effectiveDate) {
            $loan->loadMissing('schedules.lines');

            if ($activate) {
                LoanSchedule::query()
                    ->where('loan_id', $loan->sno)
                    ->where('is_active', 1)
                    ->update([
                        'is_active' => 0,
                        'superseded_at' => now(),
                        'superseded_by' => $this->userId(),
                    ]);
            }

            $version = ((int) $loan->schedules()->max('version_no')) + 1;
            $effective = $effectiveDate ?: Carbon::parse($loan->start_date ?: today());
            $method = $loan->schedule_method ?: $loan->interest_type ?: 'reducing_balance';
            $schedule = $loan->schedules()->create([
                'version_no' => $version,
                'label' => sprintf('v%d — %s', $version, $version === 1 ? 'original' : 'recomputed'),
                'method' => $method,
                'effective_date' => $effective->toDateString(),
                'is_active' => $activate,
                'created_by' => $this->userId(),
            ]);

            $principal = round((float) ($loan->disbursed_amount ?: $loan->sanction_amount), 2);
            $rate = (float) $loan->interest_rate;
            $frequency = $loan->frequency ?: 'monthly';
            $intervalMonths = $frequency === 'quarterly' ? 3 : 1;
            $tenureMonths = max(1, (int) ($loan->tenure_months ?: 1));
            $periods = $frequency === 'quarterly'
                ? max(1, (int) ceil($tenureMonths / 3))
                : $tenureMonths;

            $emi = $this->emi($principal, $rate, $periods);
            $balance = $principal;

            for ($i = 1; $i <= $periods; $i++) {
                $due = $effective->copy()->addMonthsNoOverflow($i * $intervalMonths);
                $interest = $method === 'flat_rate'
                    ? round($principal * ($rate / 100) / $periods, 2)
                    : round($balance * ($rate / 1200) * $intervalMonths, 2);

                if ($method === 'flat_rate') {
                    $principalPart = round($principal / $periods, 2);
                    if ($i === $periods) {
                        $principalPart = round($balance, 2);
                    }
                } else {
                    $principalPart = min(max(round($emi - $interest, 2), 0), $balance);
                    if ($i === $periods) {
                        $principalPart = round($balance, 2);
                    }
                }

                $actualEmi = round($principalPart + $interest, 2);
                $balance = round(max($balance - $principalPart, 0), 2);

                $schedule->lines()->create([
                    'installment_no' => $i,
                    'due_date' => $due->toDateString(),
                    'emi_amount' => $actualEmi,
                    'principal_amount' => $principalPart,
                    'interest_amount' => $interest,
                    'closing_balance' => $balance,
                    'status' => 'due',
                ]);
            }

            $maturity = $effective->copy()->addMonthsNoOverflow($periods * $intervalMonths)->toDateString();
            $loan->updateQuietly([
                'emi_amount' => $emi,
                'maturity_date' => $maturity,
                'updated_by' => $this->userId(),
            ]);

            $this->syncObligations($loan->fresh(), $schedule->fresh('lines'));

            return $schedule->fresh('lines');
        });
    }

    public function syncObligations(Loan $loan, LoanSchedule $schedule): void
    {
        $schedule->loadMissing('lines');

        // Superseded schedules must not continue to produce active calendar items.
        LoanObligation::query()
            ->where('loan_id', $loan->sno)
            ->whereHas('scheduleLine', function ($query) use ($schedule) {
                $query->where('schedule_id', '!=', $schedule->sno);
            })
            ->whereIn('status', ['upcoming', 'today', 'overdue', 'partial'])
            ->delete();

        foreach ($schedule->lines as $line) {
            LoanObligation::updateOrCreate(
                [
                    'loan_id' => $loan->sno,
                    'schedule_line_id' => $line->sno,
                ],
                [
                    'obligation_type' => 'emi',
                    'title' => 'EMI #'.$line->installment_no,
                    'due_date' => $line->due_date,
                    'display_date' => $line->due_date,
                    'amount_due' => $line->emi_amount,
                    'status' => $line->status === 'paid' ? 'paid' : $this->obligationStatus($line->due_date),
                    'pay_from_account_id' => $loan->pay_from_account_id,
                    'metadata' => [
                        'schedule_version' => $schedule->version_no,
                        'installment_no' => $line->installment_no,
                    ],
                    'created_by' => $this->userId(),
                    'updated_by' => $this->userId(),
                ]
            );
        }
    }

    public function obligationStatus($dueDate): string
    {
        $date = Carbon::parse($dueDate, config('loan.timezone', 'Asia/Kolkata'))->startOfDay();
        $today = Carbon::now(config('loan.timezone', 'Asia/Kolkata'))->startOfDay();

        return $date->lt($today)
            ? 'overdue'
            : ($date->equalTo($today) ? 'today' : 'upcoming');
    }

    public function recalculateRemaining(
        Loan $loan,
        float $newPrincipal,
        ?float $newRate = null,
        ?int $newPeriods = null
    ): array {
        $rate = $newRate ?? (float) $loan->interest_rate;
        $frequency = $loan->frequency ?: 'monthly';
        $currentRemainingMonths = max(1, $newPeriods ?? (int) $loan->tenure_months);
        $periods = $frequency === 'quarterly'
            ? max(1, (int) ceil($currentRemainingMonths / 3))
            : $currentRemainingMonths;
        $emi = $this->emi($newPrincipal, $rate, $periods);

        return [
            'principal' => round($newPrincipal, 2),
            'rate' => round($rate, 4),
            'periods' => $periods,
            'months' => $frequency === 'quarterly' ? $periods * 3 : $periods,
            'emi' => $emi,
            'interest_total' => round(max(0, ($emi * $periods) - $newPrincipal), 2),
        ];
    }

    private function userId(): ?int
    {
        $user = auth()->user();
        return $user ? (int) ($user->user_id ?? $user->id) : null;
    }
}
