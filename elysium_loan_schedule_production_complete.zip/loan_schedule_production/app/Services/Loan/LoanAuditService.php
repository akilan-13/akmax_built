<?php
namespace App\Services\Loan;
use App\Models\Loan;
use App\Models\LoanAuditLog;
class LoanAuditService
{
    public function log(?Loan $loan, string $action, ?string $entityType = null, $entityId = null, array $before = [], array $after = []): void
    {
        $user = auth()->user();
        LoanAuditLog::create([
            'loan_id' => $loan?->sno,
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'user_id' => $user ? (int)($user->user_id ?? $user->id) : null,
            'before_json' => $before,
            'after_json' => $after,
            'ip_address' => request()->ip(),
            'user_agent' => substr((string)request()->userAgent(), 0, 500),
            'created_at' => now(),
        ]);
    }
}
