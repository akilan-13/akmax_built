<?php

namespace App\Services\Loan;

use App\Models\LoanNotification;
use App\Models\LoanNotificationRule;
use App\Models\LoanObligation;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class LoanNotifierService
{
    public function prepareDueNotifications(?Carbon $now = null): int
    {
        $now = $now ?: now(config('loan.timezone', 'Asia/Kolkata'));
        $created = 0;

        LoanObligation::query()
            ->with('loan')
            ->whereNotIn('status', ['paid', 'cancelled'])
            ->whereDate('due_date', '>=', $now->toDateString())
            ->whereDate('due_date', '<=', $now->copy()->addDays(60)->toDateString())
            ->chunkById(250, function ($obligations) use ($now, &$created) {
                foreach ($obligations as $obligation) {
                    $days = $now->copy()->startOfDay()->diffInDays(Carbon::parse($obligation->due_date, config('loan.timezone')), false);
                    if ($days < 0) continue;

                    $rules = LoanNotificationRule::query()
                        ->where('enabled', 1)
                        ->where('obligation_type', $obligation->obligation_type)
                        ->where(function ($q) use ($obligation) {
                            $q->whereNull('entity_id')->orWhere('entity_id', $obligation->loan?->entity_id);
                        })
                        ->where('lead_days', $days)
                        ->orderByDesc('entity_id')
                        ->get();

                    foreach ($rules as $rule) {
                        $created += $this->queueRule($obligation, $rule, $now) ? 1 : 0;
                    }
                }
            });

        return $created;
    }

    public function processPending(?Carbon $now = null): array
    {
        $now = $now ?: now(config('loan.timezone', 'Asia/Kolkata'));
        $sent = $failed = 0;

        LoanNotification::query()
            ->where('delivery_status', 'pending')
            ->where('scheduled_for', '<=', $now)
            ->orderBy('sno')
            ->limit(500)
            ->get()
            ->each(function (LoanNotification $notification) use (&$sent, &$failed) {
                try {
                    if ($notification->channel === 'email') {
                        $this->sendEmail($notification);
                    }
                    // In-app is intentionally retained as a durable DB notification row.
                    // The host ERP notification centre can read these rows directly.
                    $notification->update([
                        'delivery_status' => 'sent',
                        'sent_at' => now(),
                        'attempts' => $notification->attempts + 1,
                    ]);
                    $sent++;
                } catch (\Throwable $e) {
                    $notification->update([
                        'delivery_status' => 'failed',
                        'error_message' => config('app.debug') ? $e->getMessage() : 'Dispatch failed',
                        'attempts' => $notification->attempts + 1,
                    ]);
                    Log::error('Loan notification dispatch failed', [
                        'notification_id' => $notification->sno,
                        'message' => $e->getMessage(),
                    ]);
                    $failed++;
                }
            });

        return compact('sent', 'failed');
    }

    public function run(?Carbon $now = null): array
    {
        $created = $this->prepareDueNotifications($now);
        $processed = $this->processPending($now);
        return array_merge(['queued' => $created], $processed);
    }

    private function queueRule(LoanObligation $obligation, LoanNotificationRule $rule, Carbon $now): bool
    {
        $addresses = $this->recipientsFor($rule->recipient_role);
        $recipientAddress = $addresses[0] ?? null;
        $key = implode('|', [
            $obligation->sno,
            $rule->sno,
            $rule->lead_days,
            $rule->channel,
            $obligation->due_date,
        ]);

        $notification = LoanNotification::firstOrCreate(
            ['idempotency_key' => hash('sha256', $key)],
            [
                'obligation_id' => $obligation->sno,
                'loan_id' => $obligation->loan_id,
                'rule_id' => $rule->sno,
                'channel' => $rule->channel,
                'recipient_address' => $recipientAddress,
                'scheduled_for' => $now,
                'delivery_status' => 'pending',
                'attempts' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        return $notification->wasRecentlyCreated;
    }

    private function recipientsFor(?string $role): array
    {
        return config('loan.notification_recipients.'.($role ?: 'accounts'), []);
    }

    private function sendEmail(LoanNotification $notification): void
    {
        if (!$notification->recipient_address) {
            throw new \RuntimeException('No email recipient configured for loan notification role.');
        }

        $notification->loadMissing(['obligation.loan.lender']);
        $obligation = $notification->obligation;
        $loan = $obligation?->loan;

        Mail::raw(
            sprintf(
                "Loan reminder\n\n%s\nLoan A/c: %s\nLender: %s\nEntity: %s\nDue date: %s\nAmount: ₹%s\n\nPlease review the obligation in Elysium ERP.",
                $obligation?->title ?: 'Loan obligation',
                $loan?->loan_account_no ?: '-',
                $loan?->lender?->lender_name ?: '-',
                $loan?->entity_name ?: '-',
                $obligation?->due_date ?: '-',
                number_format((float) ($obligation?->amount_due ?? 0), 2)
            ),
            function ($message) use ($notification) {
                $message->to($notification->recipient_address)->subject('Elysium ERP — Loan Reminder');
            }
        );
    }
}
