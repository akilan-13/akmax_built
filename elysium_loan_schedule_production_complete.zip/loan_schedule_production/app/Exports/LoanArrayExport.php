<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class LoanArrayExport implements FromArray, WithHeadings, ShouldAutoSize
{
    public function __construct(private readonly array $columns, private readonly array $rows) {}

    public function headings(): array
    {
        return array_map(fn ($column) => $column['label'], $this->columns);
    }

    public function array(): array
    {
        return array_map(function ($row) {
            return array_map(fn ($column) => $row[$column['key']] ?? null, $this->columns);
        }, $this->rows);
    }
}
