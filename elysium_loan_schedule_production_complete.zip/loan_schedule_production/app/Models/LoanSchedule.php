<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LoanSchedule extends Model { protected $table='loan_schedules'; protected $primaryKey='sno'; protected $fillable=['loan_id','version_no','label','method','effective_date','is_active','superseded_at','superseded_by','notes','created_by']; protected $casts=['version_no'=>'integer','effective_date'=>'date','is_active'=>'boolean','superseded_at'=>'datetime','superseded_by'=>'integer']; public function lines(): HasMany { return $this->hasMany(LoanScheduleLine::class,'schedule_id','sno'); } }
