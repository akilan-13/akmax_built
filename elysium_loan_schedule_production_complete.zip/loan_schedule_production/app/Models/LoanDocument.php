<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanDocument extends Model { protected $table='loan_documents'; protected $primaryKey='sno'; protected $fillable=['loan_id','document_type','original_name','storage_disk','storage_path','mime_type','file_size','checksum','uploaded_by','created_by']; protected $casts=['file_size'=>'integer','uploaded_by'=>'integer','created_by'=>'integer']; }
