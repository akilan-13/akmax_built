<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanScheduleLine extends Model { protected $table='loan_schedule_lines'; protected $primaryKey='sno'; protected $fillable=['schedule_id','installment_no','due_date','emi_amount','principal_amount','interest_amount','closing_balance','status','paid_at']; protected $casts=['installment_no'=>'integer','due_date'=>'date','emi_amount'=>'decimal:2','principal_amount'=>'decimal:2','interest_amount'=>'decimal:2','closing_balance'=>'decimal:2','paid_at'=>'datetime']; }
