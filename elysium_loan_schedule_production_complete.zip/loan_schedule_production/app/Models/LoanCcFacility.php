<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LoanCcFacility extends Model { protected $table='loan_cc_facilities'; protected $primaryKey='sno'; protected $fillable=['loan_id','sanctioned_limit','margin_percent','drawing_power','interest_rate','renewal_date','stock_statement_day','status','created_by','updated_by']; protected $casts=['sanctioned_limit'=>'decimal:2','margin_percent'=>'decimal:4','drawing_power'=>'decimal:2','interest_rate'=>'decimal:4','renewal_date'=>'date','stock_statement_day'=>'integer']; public function utilisations(): HasMany { return $this->hasMany(LoanCcUtilisation::class,'cc_facility_id','sno'); } }
