<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanPayment extends Model { protected $table='loan_payments'; protected $primaryKey='sno'; protected $fillable=['loan_id','obligation_id','payment_type','payment_date','amount','penal_interest','bounce_charge','mode','reference_no','pay_from_account_id','status','reversal_of','remarks','created_by','approved_by','approved_at']; protected $casts=['payment_date'=>'date','amount'=>'decimal:2','penal_interest'=>'decimal:2','bounce_charge'=>'decimal:2','pay_from_account_id'=>'integer','reversal_of'=>'integer','created_by'=>'integer','approved_by'=>'integer','approved_at'=>'datetime']; }
