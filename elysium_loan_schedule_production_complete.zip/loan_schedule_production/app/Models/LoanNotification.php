<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LoanNotification extends Model
{
    protected $table = 'loan_notifications';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'obligation_id', 'loan_id', 'rule_id', 'channel', 'recipient_user_id', 'recipient_address',
        'scheduled_for', 'sent_at', 'delivery_status', 'provider_message_id', 'attempts',
        'idempotency_key', 'error_message', 'acknowledged_at', 'acknowledged_by',
    ];

    protected $casts = [
        'scheduled_for' => 'datetime',
        'sent_at' => 'datetime',
        'attempts' => 'integer',
        'acknowledged_at' => 'datetime',
        'acknowledged_by' => 'integer',
    ];

    public function obligation(): BelongsTo
    {
        return $this->belongsTo(LoanObligation::class, 'obligation_id', 'sno');
    }

    public function loan(): BelongsTo
    {
        return $this->belongsTo(Loan::class, 'loan_id', 'sno');
    }

    public function rule(): BelongsTo
    {
        return $this->belongsTo(LoanNotificationRule::class, 'rule_id', 'sno');
    }
}
