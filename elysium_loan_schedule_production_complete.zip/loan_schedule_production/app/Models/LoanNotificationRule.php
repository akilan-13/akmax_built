<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanNotificationRule extends Model { protected $table='loan_notification_rules'; protected $primaryKey='sno'; protected $fillable=['obligation_type','lead_days','channel','recipient_role','enabled','entity_id','created_by','updated_by']; protected $casts=['lead_days'=>'integer','enabled'=>'boolean','entity_id'=>'integer']; }
