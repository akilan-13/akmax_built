<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Loan extends Model
{
    protected $table = 'loans';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'entity_id', 'entity_name', 'lender_id', 'loan_account_no', 'loan_name', 'loan_type', 'status',
        'sanction_amount', 'disbursed_amount', 'interest_rate', 'interest_type', 'schedule_method', 'frequency',
        'start_date', 'tenure_months', 'emi_amount', 'maturity_date', 'pay_from_account_id', 'security_details',
        'purpose_id', 'remarks', 'approved_at', 'approved_by', 'created_by', 'updated_by', 'submitted_at',
        'closed_at', 'closure_reason',
    ];

    protected $casts = [
        'entity_id' => 'integer',
        'lender_id' => 'integer',
        'sanction_amount' => 'decimal:2',
        'disbursed_amount' => 'decimal:2',
        'interest_rate' => 'decimal:4',
        'emi_amount' => 'decimal:2',
        'start_date' => 'date',
        'maturity_date' => 'date',
        'tenure_months' => 'integer',
        'pay_from_account_id' => 'integer',
        'approved_at' => 'datetime',
        'submitted_at' => 'datetime',
        'closed_at' => 'datetime',
        'approved_by' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
        'purpose_id' => 'integer',
    ];

    public function lender(): BelongsTo
    {
        return $this->belongsTo(LoanLender::class, 'lender_id', 'sno');
    }

    public function vehicle(): HasOne
    {
        return $this->hasOne(LoanVehicleDetail::class, 'loan_id', 'sno');
    }

    public function jewel(): HasOne
    {
        return $this->hasOne(LoanJewelPledge::class, 'loan_id', 'sno');
    }

    public function cc(): HasOne
    {
        return $this->hasOne(LoanCcFacility::class, 'loan_id', 'sno');
    }

    public function tranches(): HasMany
    {
        return $this->hasMany(LoanTranche::class, 'loan_id', 'sno');
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(LoanSchedule::class, 'loan_id', 'sno');
    }

    public function obligations(): HasMany
    {
        return $this->hasMany(LoanObligation::class, 'loan_id', 'sno');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(LoanPayment::class, 'loan_id', 'sno');
    }

    public function documents(): HasMany
    {
        return $this->hasMany(LoanDocument::class, 'loan_id', 'sno');
    }

    public function audits(): HasMany
    {
        return $this->hasMany(LoanAuditLog::class, 'loan_id', 'sno');
    }
}
