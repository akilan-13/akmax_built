<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanCcUtilisation extends Model { protected $table='loan_cc_utilisations'; protected $primaryKey='sno'; protected $fillable=['cc_facility_id','month_end','utilised_amount','interest_debited','drawing_power','remarks','created_by','updated_by']; protected $casts=['month_end'=>'date','utilised_amount'=>'decimal:2','interest_debited'=>'decimal:2','drawing_power'=>'decimal:2']; }
