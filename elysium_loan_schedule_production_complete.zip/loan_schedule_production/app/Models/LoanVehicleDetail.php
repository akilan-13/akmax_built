<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanVehicleDetail extends Model { protected $table='loan_vehicle_details'; protected $primaryKey='sno'; public $timestamps=true; protected $fillable=['loan_id','registration_no','make_model','chassis_no','engine_no','hypothecated_to_lender','insurance_renewal_date','created_by','updated_by']; protected $casts=['hypothecated_to_lender'=>'boolean','insurance_renewal_date'=>'date']; }
