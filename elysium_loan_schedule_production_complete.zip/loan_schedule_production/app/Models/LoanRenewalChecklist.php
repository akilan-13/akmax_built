<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LoanRenewalChecklist extends Model { protected $table='loan_renewal_checklists'; protected $primaryKey='sno'; protected $fillable=['loan_id','renewal_date','status','submitted_at','renewed_at','next_renewal_date','created_by','updated_by']; protected $casts=['renewal_date'=>'date','submitted_at'=>'datetime','renewed_at'=>'datetime','next_renewal_date'=>'date']; public function items(): HasMany { return $this->hasMany(LoanRenewalChecklistItem::class,'checklist_id','sno'); } }
