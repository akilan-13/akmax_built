<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanHoliday extends Model { protected $table='loan_holidays'; protected $primaryKey='sno'; protected $fillable=['holiday_date','holiday_name','is_active','created_by','updated_by']; protected $casts=['holiday_date'=>'date','is_active'=>'boolean']; }
