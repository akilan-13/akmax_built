<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanRenewalChecklistItem extends Model { protected $table='loan_renewal_checklist_items'; protected $primaryKey='sno'; protected $fillable=['checklist_id','item_key','item_label','is_complete','completed_at','completed_by','remarks']; protected $casts=['is_complete'=>'boolean','completed_at'=>'datetime','completed_by'=>'integer']; }
