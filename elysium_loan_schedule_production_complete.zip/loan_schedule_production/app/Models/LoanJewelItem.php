<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanJewelItem extends Model { protected $table='loan_jewel_items'; protected $primaryKey='sno'; protected $fillable=['pledge_id','item_description','gross_weight','net_weight','appraised_value','created_by','updated_by']; protected $casts=['gross_weight'=>'decimal:3','net_weight'=>'decimal:3','appraised_value'=>'decimal:2']; }
