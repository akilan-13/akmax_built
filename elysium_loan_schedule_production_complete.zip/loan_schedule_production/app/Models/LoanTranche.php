<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanTranche extends Model { protected $table='loan_tranches'; protected $primaryKey='sno'; protected $fillable=['loan_id','tranche_no','disbursed_date','amount','remarks','created_by','updated_by']; protected $casts=['tranche_no'=>'integer','disbursed_date'=>'date','amount'=>'decimal:2']; }
