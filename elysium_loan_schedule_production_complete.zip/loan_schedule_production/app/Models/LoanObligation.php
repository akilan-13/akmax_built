<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LoanObligation extends Model { protected $table='loan_obligations'; protected $primaryKey='sno'; protected $fillable=['loan_id','schedule_line_id','obligation_type','title','due_date','display_date','amount_due','amount_paid','status','priority','pay_from_account_id','snoozed_until','acknowledged_at','acknowledged_by','metadata','created_by','updated_by']; protected $casts=['due_date'=>'date','display_date'=>'date','amount_due'=>'decimal:2','amount_paid'=>'decimal:2','snoozed_until'=>'datetime','acknowledged_at'=>'datetime','metadata'=>'array']; public function scheduleLine(): \Illuminate\Database\Eloquent\Relations\BelongsTo { return $this->belongsTo(LoanScheduleLine::class,'schedule_line_id','sno'); } public function notifications(): HasMany { return $this->hasMany(LoanNotification::class,'obligation_id','sno'); } public function payments(): HasMany { return $this->hasMany(LoanPayment::class,'obligation_id','sno'); } }
