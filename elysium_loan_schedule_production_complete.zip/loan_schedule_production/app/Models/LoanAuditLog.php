<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class LoanAuditLog extends Model { protected $table='loan_audit_log'; protected $primaryKey='sno'; public $timestamps=false; protected $fillable=['loan_id','action','entity_type','entity_id','user_id','before_json','after_json','ip_address','user_agent','created_at']; protected $casts=['before_json'=>'array','after_json'=>'array','created_at'=>'datetime','user_id'=>'integer','entity_id'=>'integer']; }
