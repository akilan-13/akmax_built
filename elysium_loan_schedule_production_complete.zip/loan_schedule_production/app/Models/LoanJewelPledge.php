<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class LoanJewelPledge extends Model { protected $table='loan_jewel_pledges'; protected $primaryKey='sno'; protected $fillable=['loan_id','pledge_receipt_no','pledged_at_branch','interest_pattern','redemption_due_date','appraised_value','status','created_by','updated_by','released_at','released_by']; protected $casts=['redemption_due_date'=>'date','appraised_value'=>'decimal:2','released_at'=>'datetime','released_by'=>'integer']; public function items(): HasMany { return $this->hasMany(LoanJewelItem::class,'pledge_id','sno'); } }
