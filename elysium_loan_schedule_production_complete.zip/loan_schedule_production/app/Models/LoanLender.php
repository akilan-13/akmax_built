<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class LoanLender extends Model
{
    protected $table = 'loan_lenders';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $fillable = ['lender_name','lender_type','branch_name','contact_person','phone','email','address','status','created_by','updated_by'];
    protected $casts = ['status'=>'integer','created_by'=>'integer','updated_by'=>'integer'];
    public function loans(): HasMany { return $this->hasMany(Loan::class, 'lender_id', 'sno'); }
}
