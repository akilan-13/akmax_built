<?php

namespace App\Http\Controllers\AccountsFinance;

use App\Http\Controllers\Controller;
use App\Models\Loan;
use App\Models\LoanCcFacility;
use App\Models\LoanJewelItem;
use App\Models\LoanJewelPledge;
use App\Models\LoanLender;
use App\Models\LoanObligation;
use App\Models\LoanPayment;
use App\Models\LoanSchedule;
use App\Models\LoanScheduleLine;
use App\Models\LoanTranche;
use App\Models\LoanVehicleDetail;
use App\Services\Loan\LoanAuditService;
use App\Services\Loan\LoanScheduleService;
use Carbon\Carbon;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Throwable;

class LoanScheduleController extends Controller
{
    public function __construct(
        private readonly LoanScheduleService $scheduleService,
        private readonly LoanAuditService $audit
    ) {
    }

    public function index()
    {
        return view('content.accounts_finance.loans.index', [
            'loanTypes' => config('loan.loan_types', []),
        ]);
    }

    public function calendarPage()
    {
        return view('content.accounts_finance.loans.calendar');
    }

    public function detail(int $loan)
    {
        $record = $this->findLoan($loan);

        return view('content.accounts_finance.loans.show', [
            'record' => $record,
        ]);
    }

    public function data(Request $request): JsonResponse
    {
        try {
            $search = trim((string) $request->input('search', ''));
            $type = (string) $request->input('type', 'all');
            $status = (string) $request->input('status', 'all');
            $entity = $request->input('entity', 'all');
            $page = max(1, (int) $request->input('page', 1));
            $perPage = max(10, min((int) $request->input('per_page', config('loan.pagination', 50)), 100));

            $query = Loan::query()
                ->with([
                    'lender',
                    'schedules' => fn ($q) => $q->where('is_active', 1)->with('lines'),
                    'obligations' => fn ($q) => $q->whereIn('status', ['upcoming', 'today', 'overdue', 'partial'])->orderBy('due_date'),
                ])
                ->whereIn('status', config('loan.status', []));

            $this->applyScope($query);

            $query->when($search !== '', function ($q) use ($search) {
                $like = '%'.$search.'%';
                $q->where(function ($inner) use ($like) {
                    $inner->where('loan_account_no', 'like', $like)
                        ->orWhere('loan_name', 'like', $like)
                        ->orWhere('entity_name', 'like', $like)
                        ->orWhereHas('lender', fn ($lender) => $lender->where('lender_name', 'like', $like));
                });
            });

            if ($type !== 'all' && $type !== '') {
                $query->where('loan_type', $type);
            }

            if ($status !== 'all' && $status !== '') {
                $query->where('status', $status);
            }

            if ($entity !== 'all' && $entity !== '') {
                $query->where('entity_id', (int) $entity);
            }

            $rows = $query
                ->orderByDesc('sno')
                ->paginate($perPage, ['*'], 'page', $page);

            $items = $rows->getCollection()
                ->map(fn (Loan $loan) => $this->mapLoanRow($loan))
                ->values();

            return response()->json([
                'status' => 200,
                'message' => 'Loans loaded successfully.',
                'data' => $items,
                'pagination' => [
                    'current_page' => $rows->currentPage(),
                    'last_page' => $rows->lastPage(),
                    'per_page' => $rows->perPage(),
                    'total' => $rows->total(),
                ],
            ]);
        } catch (Throwable $e) {
            return $this->error('Unable to load loans.', $e);
        }
    }

    public function dashboard(Request $request): JsonResponse
    {
        try {
            $query = Loan::query()
                ->with(['schedules' => fn ($q) => $q->where('is_active', 1)->with('lines')])
                ->whereIn('status', ['active', 'restructured']);
            $this->applyScope($query);

            $loans = $query->get();
            $today = Carbon::now(config('loan.timezone', 'Asia/Kolkata'))->startOfDay();
            $weekEnd = $today->copy()->addDays(7)->endOfDay();
            $sixty = $today->copy()->addDays(60)->endOfDay();

            $loanIds = $loans->pluck('sno')->all();
            $obligations = LoanObligation::query()
                ->with(['loan.lender'])
                ->whereIn('loan_id', $loanIds ?: [0])
                ->whereBetween('due_date', [$today->toDateString(), $sixty->toDateString()])
                ->orderBy('due_date')
                ->get();

            $overdue = LoanObligation::query()
                ->whereIn('loan_id', $loanIds ?: [0])
                ->whereIn('status', ['overdue', 'partial'])
                ->whereDate('due_date', '<', $today->toDateString())
                ->get();

            $nextWeek = $obligations->filter(function ($o) use ($today, $weekEnd) {
                $date = Carbon::parse($o->due_date, config('loan.timezone', 'Asia/Kolkata'));
                return $date->betweenIncluded($today, $weekEnd);
            });

            $renewals = $obligations->filter(fn ($o) => in_array($o->obligation_type, ['cc_renewal', 'redemption'], true));

            $entityExposure = $loans->groupBy('entity_name')->map(function ($rows, $entityName) {
                return [
                    'entity' => $entityName ?: 'Unassigned',
                    'outstanding' => round($rows->sum(fn ($loan) => $this->outstanding($loan, $loan->schedules()->where('is_active', 1)->with('lines')->first())), 2),
                ];
            })->values();

            $todayActions = LoanObligation::query()
                ->with(['loan.lender'])
                ->whereIn('loan_id', $loanIds ?: [0])
                ->where(function ($q) use ($today) {
                    $q->whereDate('due_date', $today->toDateString())
                        ->orWhere(function ($overdue) use ($today) {
                            $overdue->whereDate('due_date', '<', $today->toDateString())
                                ->whereIn('status', ['overdue', 'partial']);
                        });
                })
                ->orderBy('due_date')
                ->limit(20)
                ->get()
                ->map(fn ($o) => $this->mapObligation($o))
                ->values();

            return response()->json([
                'status' => 200,
                'data' => [
                    'kpis' => [
                        'outstanding' => round($loans->sum(fn ($loan) => $this->outstanding($loan, $loan->schedules()->where('is_active', 1)->with('lines')->first())), 2),
                        'due_week_count' => $nextWeek->count(),
                        'due_week_amount' => round($nextWeek->sum('amount_due'), 2),
                        'overdue_count' => $overdue->count(),
                        'overdue_amount' => round($overdue->sum(fn ($o) => max(0, (float) $o->amount_due - (float) $o->amount_paid)), 2),
                        'renewals_60_count' => $renewals->count(),
                    ],
                    'today_actions' => $todayActions,
                    'entity_exposure' => $entityExposure,
                ],
            ]);
        } catch (Throwable $e) {
            return $this->error('Unable to load dashboard summary.', $e);
        }
    }

    public function lookups(): JsonResponse
    {
        try {
            $entities = collect();
            $table = config('loan.entity_table');

            if ($table && DB::getSchemaBuilder()->hasTable($table)) {
                $id = config('loan.entity_id_column');
                $name = config('loan.entity_name_column');
                $status = config('loan.entity_status_column');

                $entities = DB::table($table)
                    ->when($status, fn ($q) => $q->where($status, config('loan.active_status_value', 0)))
                    ->orderBy($name)
                    ->get([$id, $name])
                    ->map(fn ($row) => [
                        'id' => $row->{$id},
                        'name' => $row->{$name},
                    ])
                    ->values();
            }

            $bankAccounts = collect();
            $bankTable = config('loan.bank_account_table');
            if ($bankTable && DB::getSchemaBuilder()->hasTable($bankTable)) {
                $id = config('loan.bank_account_id_column');
                $name = config('loan.bank_account_name_column');
                $status = config('loan.bank_account_status_column');

                $bankAccounts = DB::table($bankTable)
                    ->when($status, fn ($q) => $q->where($status, config('loan.bank_account_active_status', 0)))
                    ->orderBy($name)
                    ->get([$id, $name])
                    ->map(fn ($row) => [
                        'id' => $row->{$id},
                        'name' => $row->{$name},
                    ])
                    ->values();
            }

            $lenders = LoanLender::query()
                ->where('status', 0)
                ->orderBy('lender_name')
                ->get(['sno as id', 'lender_name as name', 'lender_type', 'branch_name', 'phone']);

            return response()->json([
                'status' => 200,
                'message' => 'Loan masters loaded successfully.',
                'data' => [
                    'entities' => $entities,
                    'lenders' => $lenders,
                    'banks' => $bankAccounts,
                    'types' => config('loan.loan_types', []),
                    'modes' => config('loan.payment_modes', []),
                ],
            ]);
        } catch (Throwable $e) {
            return $this->error('Unable to load loan masters.', $e);
        }
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate($this->storeRules());

        try {
            return DB::transaction(function () use ($request, $validated) {
                $userId = $this->userId();

                $lender = $request->filled('lender_id')
                    ? LoanLender::query()->where('status', 0)->findOrFail((int) $request->input('lender_id'))
                    : LoanLender::create([
                        'lender_name' => trim((string) $request->input('lender_name')),
                        'lender_type' => $request->input('lender_type', 'bank'),
                        'branch_name' => $request->input('lender_branch'),
                        'phone' => $request->input('lender_phone'),
                        'created_by' => $userId,
                        'updated_by' => $userId,
                        'status' => 0,
                    ]);

                $loan = Loan::create([
                    'entity_id' => $request->input('entity_id'),
                    'entity_name' => $request->input('entity_name'),
                    'lender_id' => $lender->sno,
                    'loan_account_no' => trim((string) $request->input('loan_account_no')),
                    'loan_name' => $request->input('loan_name'),
                    'loan_type' => $request->input('loan_type'),
                    'status' => 'pending_approval',
                    'sanction_amount' => $request->input('sanction_amount', 0),
                    'disbursed_amount' => $request->input('disbursed_amount', $request->input('sanction_amount', 0)),
                    'interest_rate' => $request->input('interest_rate', 0),
                    'interest_type' => $request->input('interest_type', 'reducing_balance'),
                    'schedule_method' => $request->input('schedule_method', $request->input('interest_type', 'reducing_balance')),
                    'frequency' => $request->input('frequency', 'monthly'),
                    'start_date' => $request->input('start_date'),
                    'tenure_months' => $request->input('tenure_months'),
                    'pay_from_account_id' => $request->input('pay_from_account_id'),
                    'security_details' => $request->input('security_details'),
                    'purpose_id' => $request->input('purpose_id'),
                    'remarks' => $request->input('remarks'),
                    'submitted_at' => now(),
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);

                $this->saveTypeDetails($request, $loan, $userId);
                $this->audit->log($loan, 'Loan submitted for approval', 'loans', $loan->sno, [], $loan->fresh()->toArray());

                return response()->json([
                    'status' => 200,
                    'message' => 'Loan submitted for Finance Head approval.',
                    'data' => ['id' => $loan->sno],
                ]);
            });
        } catch (QueryException $e) {
            if (str_contains(strtolower($e->getMessage()), 'uq_loans_lender_account') || str_contains(strtolower($e->getMessage()), 'duplicate')) {
                return response()->json([
                    'status' => 422,
                    'message' => 'A loan with the same lender and account number already exists.',
                ], 422);
            }

            return $this->error('Unable to save loan.', $e);
        } catch (Throwable $e) {
            return $this->error('Unable to save loan.', $e);
        }
    }

    public function approve(int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeChecker($record);

        if ($record->status !== 'pending_approval') {
            return response()->json(['status' => 422, 'message' => 'Only pending loans can be approved.'], 422);
        }

        $before = $record->toArray();

        DB::transaction(function () use ($record) {
            $record->update([
                'status' => 'active',
                'approved_at' => now(),
                'approved_by' => $this->userId(),
                'updated_by' => $this->userId(),
            ]);

            if (in_array($record->loan_type, ['vehicle', 'term'], true)) {
                $this->scheduleService->generate($record->fresh());
            } elseif ($record->loan_type === 'jewel') {
                $this->createJewelObligations($record->fresh());
            } elseif ($record->loan_type === 'cc') {
                $this->createCcObligations($record->fresh());
            }
        });

        $this->audit->log($record, 'Loan approved', 'loans', $record->sno, $before, $record->fresh()->toArray());

        return response()->json([
            'status' => 200,
            'message' => 'Loan approved and schedule/calendar updated.',
        ]);
    }

    public function reject(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeChecker($record);

        $data = $request->validate([
            'remarks' => 'required|string|max:1000',
        ]);

        if (!in_array($record->status, ['pending_approval', 'returned'], true)) {
            return response()->json(['status' => 422, 'message' => 'Only pending loans can be returned.'], 422);
        }

        $before = $record->toArray();
        $record->update([
            'status' => 'returned',
            'remarks' => $data['remarks'],
            'updated_by' => $this->userId(),
        ]);

        $this->audit->log($record, 'Loan returned to maker', 'loans', $record->sno, $before, $record->fresh()->toArray());

        return response()->json([
            'status' => 200,
            'message' => 'Loan returned to maker for correction.',
        ]);
    }

    public function calendar(Request $request): JsonResponse
    {
        try {
            $timezone = config('loan.timezone', 'Asia/Kolkata');
            $from = Carbon::parse($request->input('from', Carbon::now($timezone)->startOfMonth()->toDateString()), $timezone)->startOfDay();
            $to = Carbon::parse($request->input('to', Carbon::now($timezone)->endOfMonth()->toDateString()), $timezone)->endOfDay();

            $query = LoanObligation::query()
                ->with(['loan.lender'])
                ->whereBetween('due_date', [$from->toDateString(), $to->toDateString()])
                ->whereHas('loan', fn ($q) => $q->whereIn('status', ['active', 'restructured']));

            $this->applyScopeToObligations($query, $request);

            $items = $query
                ->orderBy('due_date')
                ->orderBy('priority', 'desc')
                ->orderBy('sno')
                ->get()
                ->map(fn (LoanObligation $obligation) => $this->mapObligation($obligation))
                ->filter(function (array $item) use ($request) {
                    $status = (string) $request->input('status', 'all');
                    return $status === 'all' || $status === '' || $item['status'] === $status;
                })
                ->values();

            return response()->json([
                'status' => 200,
                'message' => 'Calendar loaded successfully.',
                'data' => $items,
            ]);
        } catch (Throwable $e) {
            return $this->error('Unable to load calendar.', $e);
        }
    }

    public function show(int $loan): JsonResponse
    {
        $record = $this->findLoan($loan)->load([
            'lender',
            'vehicle',
            'tranches',
            'jewel.items',
            'cc.utilisations',
            'schedules.lines',
            'obligations.scheduleLine',
            'payments',
            'documents',
            'audits',
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Loan loaded successfully.',
            'data' => $this->detailPayload($record),
        ]);
    }

    public function payment(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMakerOrChecker($record);

        $data = $request->validate([
            'obligation_id' => 'nullable|integer|exists:loan_obligations,sno',
            'payment_date' => 'required|date',
            'amount' => 'required|numeric|min:0.01',
            'penal_interest' => 'nullable|numeric|min:0',
            'bounce_charge' => 'nullable|numeric|min:0',
            'mode' => ['required', Rule::in(config('loan.payment_modes', []))],
            'reference_no' => 'nullable|string|max:120',
            'pay_from_account_id' => 'nullable|integer',
            'remarks' => 'nullable|string|max:1000',
        ]);

        DB::transaction(function () use ($record, $data) {
            $obligation = null;

            if (!empty($data['obligation_id'])) {
                $obligation = LoanObligation::query()
                    ->lockForUpdate()
                    ->where('sno', $data['obligation_id'])
                    ->where('loan_id', $record->sno)
                    ->first();
            }

            if (!$obligation) {
                $obligation = LoanObligation::query()
                    ->lockForUpdate()
                    ->where('loan_id', $record->sno)
                    ->whereIn('status', ['today', 'overdue', 'partial', 'upcoming'])
                    ->orderByRaw("CASE WHEN status IN ('overdue','partial','today') THEN 0 ELSE 1 END")
                    ->orderBy('due_date')
                    ->first();
            }

            $payment = LoanPayment::create([
                'loan_id' => $record->sno,
                'obligation_id' => $obligation?->sno,
                'payment_type' => 'installment',
                'payment_date' => $data['payment_date'],
                'amount' => $data['amount'],
                'penal_interest' => $data['penal_interest'] ?? 0,
                'bounce_charge' => $data['bounce_charge'] ?? 0,
                'mode' => $data['mode'],
                'reference_no' => $data['reference_no'] ?? null,
                'pay_from_account_id' => $data['pay_from_account_id'] ?? null,
                'status' => 'posted',
                'remarks' => $data['remarks'] ?? null,
                'created_by' => $this->userId(),
            ]);

            if ($obligation) {
                $newPaid = round((float) $obligation->amount_paid + (float) $data['amount'], 2);
                $newStatus = $newPaid >= (float) $obligation->amount_due
                    ? 'paid'
                    : 'partial';

                $obligation->update([
                    'amount_paid' => $newPaid,
                    'status' => $newStatus,
                    'updated_by' => $this->userId(),
                ]);

                if ($obligation->schedule_line_id) {
                    $line = LoanScheduleLine::query()->find($obligation->schedule_line_id);
                    if ($line) {
                        $line->update([
                            'status' => $newStatus === 'paid' ? 'paid' : 'due',
                            'paid_at' => $newStatus === 'paid' ? now() : null,
                        ]);
                    }
                }
            }

            $this->audit->log(
                $record,
                'Payment recorded',
                'loan_payments',
                $payment->sno,
                [],
                $payment->toArray()
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Payment recorded. Calendar and loan details are updated.',
        ]);
    }

    public function snooze(Request $request, int $obligation): JsonResponse
    {
        $data = $request->validate([
            'until' => 'required|date',
            'reason' => 'required|string|max:500',
        ]);

        $obligationRecord = LoanObligation::with('loan')->findOrFail($obligation);
        $this->authorizeMakerOrChecker($obligationRecord->loan);

        $until = Carbon::parse($data['until']);
        $due = Carbon::parse($obligationRecord->due_date)->endOfDay();

        if ($until->gt($due)) {
            return response()->json([
                'status' => 422,
                'message' => 'Snooze cannot go beyond the due date.',
            ], 422);
        }

        $obligationRecord->update([
            'snoozed_until' => $data['until'],
            'updated_by' => $this->userId(),
        ]);

        $this->audit->log(
            $obligationRecord->loan,
            'Reminder snoozed',
            'loan_obligations',
            $obligationRecord->sno,
            [],
            ['until' => $data['until'], 'reason' => $data['reason']]
        );

        return response()->json([
            'status' => 200,
            'message' => 'Reminder snoozed until '.Carbon::parse($data['until'])->format('d-m-Y H:i').'.',
        ]);
    }

    public function prepayPreview(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMaker($record);

        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'date' => 'required|date',
            'mode' => ['required', Rule::in(['emi', 'tenure'])],
        ]);

        $active = $record->schedules()->where('is_active', 1)->with('lines')->first();
        if (!$active) {
            return response()->json(['status' => 422, 'message' => 'No active schedule found.'], 422);
        }

        $remaining = $active->lines
            ->where('status', '!=', 'paid')
            ->first();

        $remainingPrincipal = (float) ($remaining?->closing_balance ?? 0);
        $newPrincipal = max(0, $remainingPrincipal - (float) $data['amount']);
        $remainingPeriods = max(1, $active->lines->where('status', '!=', 'paid')->count());

        $proposed = $this->scheduleService->recalculateRemaining(
            $record,
            $newPrincipal,
            (float) $record->interest_rate,
            $remainingPeriods
        );

        return response()->json([
            'status' => 200,
            'data' => [
                'current' => [
                    'emi' => (float) $record->emi_amount,
                    'remaining_periods' => $remainingPeriods,
                    'principal' => round($remainingPrincipal, 2),
                ],
                'proposed' => $proposed,
                'mode' => $data['mode'],
                'prepayment_amount' => (float) $data['amount'],
                'date' => $data['date'],
            ],
        ]);
    }

    public function prepay(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMaker($record);

        $data = $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'date' => 'required|date',
            'mode' => ['required', Rule::in(['emi', 'tenure'])],
            'remarks' => 'nullable|string|max:1000',
        ]);

        $active = $record->schedules()->where('is_active', 1)->with('lines')->first();
        if (!$active) {
            return response()->json(['status' => 422, 'message' => 'No active schedule found.'], 422);
        }

        $remaining = $active->lines->where('status', '!=', 'paid')->first();
        $remainingPrincipal = (float) ($remaining?->closing_balance ?? 0);
        $newPrincipal = max(0, $remainingPrincipal - (float) $data['amount']);
        if ($newPrincipal < 0) {
            $newPrincipal = 0;
        }

        // The new schedule is created as inactive. Finance Head approval is required to activate it.
        $proposalNotes = json_encode([
            'pending_action' => 'prepay',
            'amount' => (float) $data['amount'],
            'date' => $data['date'],
            'mode' => $data['mode'],
            'remarks' => $data['remarks'] ?? null,
            'source_schedule_id' => $active->sno,
            'remaining_principal' => $remainingPrincipal,
            'new_principal' => $newPrincipal,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        DB::transaction(function () use ($record, $active, $newPrincipal, $data, $proposalNotes) {
            $nextVersion = ((int) $record->schedules()->max('version_no')) + 1;
            $schedule = $record->schedules()->create([
                'version_no' => $nextVersion,
                'label' => 'v'.$nextVersion.' — pending prepayment approval',
                'method' => $active->method,
                'effective_date' => $data['date'],
                'is_active' => false,
                'notes' => $proposalNotes,
                'created_by' => $this->userId(),
            ]);

            $this->buildProposalLines($record, $schedule, $newPrincipal, $active, $data['mode']);
            $this->audit->log(
                $record,
                'Part-prepayment submitted for approval',
                'loan_schedules',
                $schedule->sno,
                [],
                ['amount' => $data['amount'], 'date' => $data['date'], 'mode' => $data['mode']]
            );
        });

        return response()->json([
            'status' => 200,
            'message' => 'Part-prepayment submitted for Finance Head approval.',
        ]);
    }

    public function approvePrepay(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeChecker($record);

        $proposal = $record->schedules()
            ->where('is_active', false)
            ->where('label', 'like', '%pending prepayment approval%')
            ->latest('sno')
            ->first();

        if (!$proposal) {
            return response()->json(['status' => 422, 'message' => 'No pending prepayment request found.'], 422);
        }

        $meta = json_decode((string) $proposal->notes, true) ?: [];
        $before = $record->toArray();

        DB::transaction(function () use ($record, $proposal, $meta) {
            $current = $record->schedules()->where('is_active', 1)->first();
            if ($current) {
                $current->update([
                    'is_active' => false,
                    'superseded_at' => now(),
                    'superseded_by' => $this->userId(),
                ]);
            }

            $proposal->update([
                'is_active' => true,
                'label' => 'v'.$proposal->version_no.' — after prepayment '.Carbon::parse($meta['date'] ?? now())->format('d-m-Y'),
            ]);

            LoanObligation::query()
                ->where('loan_id', $record->sno)
                ->whereIn('status', ['upcoming', 'today', 'overdue', 'partial'])
                ->delete();

            $this->scheduleService->syncObligations($record->fresh(), $proposal->fresh('lines'));

            $payment = LoanPayment::create([
                'loan_id' => $record->sno,
                'payment_type' => 'part_prepayment',
                'payment_date' => $meta['date'] ?? now()->toDateString(),
                'amount' => $meta['amount'] ?? 0,
                'mode' => 'NEFT/RTGS',
                'reference_no' => 'PREPAY-'.$record->sno.'-'.$proposal->version_no,
                'status' => 'posted',
                'remarks' => $meta['remarks'] ?? null,
                'created_by' => $this->userId(),
            ]);

            $this->audit->log($record, 'Part-prepayment approved; new schedule activated', 'loan_payments', $payment->sno, [], $payment->toArray());
        });

        $this->audit->log($record, 'Prepayment approval completed', 'loans', $record->sno, $before, $record->fresh()->toArray());

        return response()->json([
            'status' => 200,
            'message' => 'Prepayment approved. New schedule version is now active.',
        ]);
    }

    public function restructurePreview(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMaker($record);

        $data = $request->validate([
            'effective_date' => 'required|date',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'tenure_months' => 'required|integer|min:1|max:240',
        ]);

        if (!in_array($record->loan_type, ['vehicle', 'term'], true)) {
            return response()->json(['status' => 422, 'message' => 'Restructure is available for Vehicle and Business Term loans.'], 422);
        }

        $active = $record->schedules()->where('is_active', 1)->with('lines')->first();
        if (!$active) {
            return response()->json(['status' => 422, 'message' => 'No active schedule found.'], 422);
        }

        $firstUnpaid = $active->lines->where('status', '!=', 'paid')->sortBy('installment_no')->first();
        $remainingPrincipal = (float) ($firstUnpaid?->closing_balance ?? 0) + (float) ($firstUnpaid?->principal_amount ?? 0);
        $frequency = $record->frequency ?: 'monthly';
        $periods = $frequency === 'quarterly' ? (int) ceil($data['tenure_months'] / 3) : (int) $data['tenure_months'];
        $proposal = $this->scheduleService->recalculateRemaining($record, max(0, $remainingPrincipal), (float) $data['interest_rate'], max(1, $periods));

        return response()->json([
            'status' => 200,
            'data' => [
                'current' => [
                    'emi' => (float) $record->emi_amount,
                    'rate' => (float) $record->interest_rate,
                    'maturity' => $record->maturity_date,
                    'remaining_principal' => round($remainingPrincipal, 2),
                ],
                'proposed' => $proposal,
                'effective_date' => $data['effective_date'],
            ],
        ]);
    }

    public function restructure(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMaker($record);

        $data = $request->validate([
            'effective_date' => 'required|date',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'tenure_months' => 'required|integer|min:1|max:240',
            'remarks' => 'nullable|string|max:1000',
        ]);

        if (!in_array($record->loan_type, ['vehicle', 'term'], true)) {
            return response()->json(['status' => 422, 'message' => 'Restructure is available for Vehicle and Business Term loans.'], 422);
        }

        $active = $record->schedules()->where('is_active', 1)->with('lines')->first();
        if (!$active) {
            return response()->json(['status' => 422, 'message' => 'No active schedule found.'], 422);
        }

        $firstUnpaid = $active->lines->where('status', '!=', 'paid')->sortBy('installment_no')->first();
        $remainingPrincipal = (float) ($firstUnpaid?->closing_balance ?? 0) + (float) ($firstUnpaid?->principal_amount ?? 0);
        $frequency = $record->frequency ?: 'monthly';
        $periods = $frequency === 'quarterly' ? (int) ceil($data['tenure_months'] / 3) : (int) $data['tenure_months'];
        $notes = json_encode([
            'pending_action' => 'restructure',
            'effective_date' => $data['effective_date'],
            'interest_rate' => (float) $data['interest_rate'],
            'tenure_months' => (int) $data['tenure_months'],
            'periods' => $periods,
            'remaining_principal' => round($remainingPrincipal, 2),
            'source_schedule_id' => $active->sno,
            'remarks' => $data['remarks'] ?? null,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        DB::transaction(function () use ($record, $active, $remainingPrincipal, $data, $periods, $notes) {
            $nextVersion = ((int) $record->schedules()->max('version_no')) + 1;
            $schedule = $record->schedules()->create([
                'version_no' => $nextVersion,
                'label' => 'v'.$nextVersion.' — pending restructure approval',
                'method' => $active->method,
                'effective_date' => $data['effective_date'],
                'is_active' => false,
                'notes' => $notes,
                'created_by' => $this->userId(),
            ]);

            $this->buildCustomProposalLines(
                $record,
                $schedule,
                $remainingPrincipal,
                (float) $data['interest_rate'],
                $periods,
                Carbon::parse($data['effective_date'], config('loan.timezone', 'Asia/Kolkata')),
                $active->method,
                $record->frequency ?: 'monthly'
            );

            $this->audit->log($record, 'Restructure submitted for approval', 'loan_schedules', $schedule->sno, [], [
                'new_rate' => $data['interest_rate'],
                'tenure_months' => $data['tenure_months'],
                'effective_date' => $data['effective_date'],
            ]);
        });

        return response()->json(['status' => 200, 'message' => 'Restructure submitted for Finance Head approval.']);
    }

    public function approveRestructure(int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeChecker($record);

        $proposal = $record->schedules()
            ->where('is_active', false)
            ->where('label', 'like', '%pending restructure approval%')
            ->latest('sno')
            ->first();

        if (!$proposal) {
            return response()->json(['status' => 422, 'message' => 'No pending restructure request found.'], 422);
        }

        $meta = json_decode((string) $proposal->notes, true) ?: [];
        DB::transaction(function () use ($record, $proposal, $meta) {
            $current = $record->schedules()->where('is_active', 1)->first();
            if ($current) {
                $current->update(['is_active' => false, 'superseded_at' => now(), 'superseded_by' => $this->userId()]);
            }

            $proposal->update([
                'is_active' => true,
                'label' => 'v'.$proposal->version_no.' — restructured '.Carbon::parse($meta['effective_date'] ?? now())->format('d-m-Y'),
            ]);

            $loanRate = (float) ($meta['interest_rate'] ?? $record->interest_rate);
            $record->update([
                'interest_rate' => $loanRate,
                'tenure_months' => (int) ($meta['tenure_months'] ?? $record->tenure_months),
                'status' => 'active',
                'updated_by' => $this->userId(),
            ]);

            LoanObligation::query()->where('loan_id', $record->sno)->whereIn('status', ['upcoming', 'today', 'overdue', 'partial'])->delete();
            $this->scheduleService->syncObligations($record->fresh(), $proposal->fresh('lines'));
            $this->audit->log($record, 'Restructure approved; new schedule activated', 'loan_schedules', $proposal->sno, [], [
                'version' => $proposal->version_no,
                'rate' => $loanRate,
                'tenure_months' => $meta['tenure_months'] ?? null,
            ]);
        });

        return response()->json(['status' => 200, 'message' => 'Restructure approved. New schedule version is now active.']);
    }

    public function close(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeChecker($record);

        $data = $request->validate([
            'closure_reason' => 'required|string|max:500',
            'noc_received' => 'required|boolean',
            'security_released' => 'required|boolean',
        ]);

        if (!$data['noc_received'] || !$data['security_released']) {
            return response()->json([
                'status' => 422,
                'message' => 'NOC and security release must be confirmed before closing the loan.',
            ], 422);
        }

        $before = $record->toArray();

        $record->update([
            'status' => 'closed',
            'closed_at' => now(),
            'closure_reason' => $data['closure_reason'],
            'updated_by' => $this->userId(),
        ]);

        LoanObligation::query()
            ->where('loan_id', $record->sno)
            ->whereNotIn('status', ['paid'])
            ->update(['status' => 'cancelled', 'updated_by' => $this->userId()]);

        $this->audit->log($record, 'Loan closed', 'loans', $record->sno, $before, $record->fresh()->toArray());

        return response()->json(['status' => 200, 'message' => 'Loan closed successfully.']);
    }

    public function renewal(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMakerOrChecker($record);

        if ($record->loan_type !== 'cc' || !$record->cc) {
            return response()->json(['status' => 422, 'message' => 'Renewal is available only for CC facilities.'], 422);
        }

        $data = $request->validate([
            'next_renewal_date' => 'required|date',
        ]);

        $before = $record->cc->toArray();
        $record->cc->update([
            'renewal_date' => $data['next_renewal_date'],
            'updated_by' => $this->userId(),
        ]);

        LoanObligation::query()
            ->where('loan_id', $record->sno)
            ->where('obligation_type', 'cc_renewal')
            ->whereNotIn('status', ['paid'])
            ->update([
                'due_date' => $data['next_renewal_date'],
                'display_date' => $data['next_renewal_date'],
                'status' => $this->scheduleService->obligationStatus($data['next_renewal_date']),
                'updated_by' => $this->userId(),
            ]);

        $this->audit->log($record, 'CC renewal date updated', 'loan_cc_facilities', $record->cc->sno, $before, $record->cc->fresh()->toArray());

        return response()->json(['status' => 200, 'message' => 'CC renewal date updated.']);
    }

    public function utilisation(Request $request, int $loan): JsonResponse
    {
        $record = $this->findLoan($loan);
        $this->authorizeMakerOrChecker($record);

        if ($record->loan_type !== 'cc' || !$record->cc) {
            return response()->json(['status' => 422, 'message' => 'Utilisation is available only for CC facilities.'], 422);
        }

        $data = $request->validate([
            'month_end' => 'required|date',
            'utilised_amount' => 'required|numeric|min:0',
            'interest_debited' => 'nullable|numeric|min:0',
            'drawing_power' => 'nullable|numeric|min:0',
            'remarks' => 'nullable|string|max:500',
        ]);

        $u = $record->cc->utilisations()->updateOrCreate(
            ['month_end' => $data['month_end']],
            array_merge($data, [
                'created_by' => $this->userId(),
                'updated_by' => $this->userId(),
            ])
        );

        $this->audit->log($record, 'CC utilisation updated', 'loan_cc_utilisations', $u->sno, [], $u->toArray());

        return response()->json(['status' => 200, 'message' => 'CC utilisation updated.']);
    }

    private function buildCustomProposalLines(
        Loan $loan,
        LoanSchedule $schedule,
        float $principal,
        float $rate,
        int $periods,
        Carbon $startDate,
        string $method,
        string $frequency
    ): void {
        $periods = max(1, $periods);
        $intervalMonths = $frequency === 'quarterly' ? 3 : 1;
        $emi = $this->scheduleService->emi($principal, $rate, $periods);
        $balance = round($principal, 2);
        for ($i = 1; $i <= $periods; $i++) {
            $due = $startDate->copy()->addMonthsNoOverflow($i * $intervalMonths);
            $interest = $method === 'flat_rate'
                ? round($principal * ($rate / 100) / $periods, 2)
                : round($balance * ($rate / 1200) * $intervalMonths, 2);
            $principalPart = $method === 'flat_rate'
                ? round($principal / $periods, 2)
                : min(max(round($emi - $interest, 2), 0), $balance);
            if ($i === $periods) $principalPart = round($balance, 2);
            $actual = round($principalPart + $interest, 2);
            $balance = round(max(0, $balance - $principalPart), 2);
            $schedule->lines()->create([
                'installment_no' => $i,
                'due_date' => $due->toDateString(),
                'emi_amount' => $actual,
                'principal_amount' => $principalPart,
                'interest_amount' => $interest,
                'closing_balance' => $balance,
                'status' => 'due',
            ]);
        }
    }

    private function buildProposalLines(Loan $loan, LoanSchedule $schedule, float $principal, LoanSchedule $source, string $mode): void
    {
        $sourceLines = $source->lines()->where('status', '!=', 'paid')->orderBy('installment_no')->get();
        $periods = $sourceLines->count();
        if ($periods <= 0) {
            return;
        }

        $rate = (float) $loan->interest_rate;
        $frequency = $loan->frequency ?: 'monthly';
        $intervalMonths = $frequency === 'quarterly' ? 3 : 1;
        $startDate = Carbon::parse($sourceLines->first()->due_date, config('loan.timezone', 'Asia/Kolkata'));

        $periodsForEmi = $mode === 'tenure'
            ? $periods
            : $periods;
        $emi = $this->scheduleService->emi($principal, $rate, max(1, $periodsForEmi));
        $balance = $principal;

        foreach ($sourceLines->values() as $index => $sourceLine) {
            $due = $startDate->copy()->addMonthsNoOverflow($index * $intervalMonths);
            if ($mode === 'tenure') {
                $due = Carbon::parse($sourceLine->due_date, config('loan.timezone', 'Asia/Kolkata'));
            }

            $interest = round($balance * ($rate / 1200) * $intervalMonths, 2);
            $principalPart = min(max(round($emi - $interest, 2), 0), $balance);
            if ($index === $sourceLines->count() - 1) {
                $principalPart = round($balance, 2);
            }
            $actual = round($principalPart + $interest, 2);
            $balance = round(max(0, $balance - $principalPart), 2);

            $schedule->lines()->create([
                'installment_no' => $index + 1,
                'due_date' => $due->toDateString(),
                'emi_amount' => $actual,
                'principal_amount' => $principalPart,
                'interest_amount' => $interest,
                'closing_balance' => $balance,
                'status' => 'due',
            ]);
        }
    }

    private function saveTypeDetails(Request $request, Loan $loan, ?int $userId): void
    {
        if ($loan->loan_type === 'vehicle') {
            LoanVehicleDetail::create([
                'loan_id' => $loan->sno,
                'registration_no' => $request->input('registration_no'),
                'make_model' => $request->input('make_model'),
                'chassis_no' => $request->input('chassis_no'),
                'engine_no' => $request->input('engine_no'),
                'hypothecated_to_lender' => $request->boolean('hypothecated_to_lender', true),
                'insurance_renewal_date' => $request->input('insurance_renewal_date'),
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);
            return;
        }

        if ($loan->loan_type === 'term') {
            foreach (collect($request->input('tranches', []))->values() as $index => $tranche) {
                LoanTranche::create([
                    'loan_id' => $loan->sno,
                    'tranche_no' => $index + 1,
                    'disbursed_date' => $tranche['date'],
                    'amount' => $tranche['amount'],
                    'remarks' => $tranche['remarks'] ?? null,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            }
            return;
        }

        if ($loan->loan_type === 'jewel') {
            $pledge = LoanJewelPledge::create([
                'loan_id' => $loan->sno,
                'pledge_receipt_no' => $request->input('pledge_receipt_no'),
                'pledged_at_branch' => $request->input('pledged_at_branch'),
                'interest_pattern' => $request->input('interest_pattern', 'monthly'),
                'redemption_due_date' => $request->input('redemption_due_date'),
                'appraised_value' => $request->input('appraised_value'),
                'status' => 'active',
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            foreach (collect($request->input('jewel_items', []))->values() as $item) {
                LoanJewelItem::create([
                    'pledge_id' => $pledge->sno,
                    'item_description' => $item['description'],
                    'gross_weight' => $item['gross_weight'] ?? null,
                    'net_weight' => $item['net_weight'] ?? null,
                    'appraised_value' => $item['value'] ?? null,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            }
            return;
        }

        if ($loan->loan_type === 'cc') {
            LoanCcFacility::create([
                'loan_id' => $loan->sno,
                'sanctioned_limit' => $request->input('sanctioned_limit'),
                'margin_percent' => $request->input('margin_percent', 0),
                'drawing_power' => $request->input('drawing_power', 0),
                'interest_rate' => $request->input('interest_rate', 0),
                'renewal_date' => $request->input('renewal_date'),
                'stock_statement_day' => $request->input('stock_statement_day'),
                'status' => 'active',
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);
        }
    }

    private function createJewelObligations(Loan $loan): void
    {
        if (!$loan->jewel?->redemption_due_date) {
            return;
        }

        LoanObligation::updateOrCreate(
            [
                'loan_id' => $loan->sno,
                'obligation_type' => 'redemption',
                'due_date' => $loan->jewel->redemption_due_date,
            ],
            [
                'title' => 'Jewel redemption',
                'amount_due' => $loan->sanction_amount,
                'status' => $this->scheduleService->obligationStatus($loan->jewel->redemption_due_date),
                'priority' => 3,
                'pay_from_account_id' => $loan->pay_from_account_id,
                'created_by' => $this->userId(),
                'updated_by' => $this->userId(),
            ]
        );

        if ($loan->jewel->interest_pattern === 'monthly') {
            $nextInterest = Carbon::parse($loan->start_date ?: today(), config('loan.timezone', 'Asia/Kolkata'))->addMonthNoOverflow();
            while ($nextInterest->lte(Carbon::parse($loan->jewel->redemption_due_date))) {
                LoanObligation::updateOrCreate(
                    [
                        'loan_id' => $loan->sno,
                        'obligation_type' => 'jewel_interest',
                        'due_date' => $nextInterest->toDateString(),
                    ],
                    [
                        'title' => 'Jewel interest',
                        'amount_due' => round((float) $loan->sanction_amount * ((float) $loan->interest_rate / 1200), 2),
                        'status' => $this->scheduleService->obligationStatus($nextInterest),
                        'priority' => 2,
                        'pay_from_account_id' => $loan->pay_from_account_id,
                        'created_by' => $this->userId(),
                        'updated_by' => $this->userId(),
                    ]
                );
                $nextInterest->addMonthNoOverflow();
            }
        }
    }

    private function createCcObligations(Loan $loan): void
    {
        if (!$loan->cc?->renewal_date) {
            return;
        }

        LoanObligation::updateOrCreate(
            [
                'loan_id' => $loan->sno,
                'obligation_type' => 'cc_renewal',
                'due_date' => $loan->cc->renewal_date,
            ],
            [
                'title' => 'CC renewal',
                'amount_due' => 0,
                'status' => $this->scheduleService->obligationStatus($loan->cc->renewal_date),
                'priority' => 3,
                'pay_from_account_id' => $loan->pay_from_account_id,
                'created_by' => $this->userId(),
                'updated_by' => $this->userId(),
            ]
        );

        if ($loan->cc->stock_statement_day) {
            $month = Carbon::now(config('loan.timezone', 'Asia/Kolkata'))->startOfMonth();
            for ($i = 0; $i < 12; $i++) {
                $date = $month->copy()->addMonthsNoOverflow($i)->day(min($loan->cc->stock_statement_day, $month->copy()->addMonthsNoOverflow($i)->daysInMonth));
                LoanObligation::updateOrCreate(
                    [
                        'loan_id' => $loan->sno,
                        'obligation_type' => 'stock_statement',
                        'due_date' => $date->toDateString(),
                    ],
                    [
                        'title' => 'CC stock statement',
                        'amount_due' => 0,
                        'status' => $this->scheduleService->obligationStatus($date),
                        'priority' => 1,
                        'created_by' => $this->userId(),
                        'updated_by' => $this->userId(),
                    ]
                );
            }
        }
    }

    private function mapLoanRow(Loan $loan): array
    {
        $active = $loan->relationLoaded('schedules')
            ? $loan->schedules->firstWhere('is_active', true)
            : $loan->schedules()->where('is_active', 1)->with('lines')->first();

        if ($active && !$active->relationLoaded('lines')) {
            $active->load('lines');
        }

        $next = $loan->relationLoaded('obligations')
            ? $loan->obligations->first()
            : $loan->obligations()
                ->whereIn('status', ['upcoming', 'today', 'overdue', 'partial'])
                ->orderBy('due_date')
                ->first();

        $paid = (int) ($active?->lines?->where('status', 'paid')->count() ?? 0);
        $total = (int) ($active?->lines?->count() ?? $loan->tenure_months ?? 0);
        $nextDue = $next?->due_date?->format('Y-m-d');
        $maturity = $loan->maturity_date?->format('Y-m-d');

        return [
            'id' => $loan->sno,
            'account_no' => $loan->loan_account_no,
            'name' => $loan->loan_name,
            'type' => $loan->loan_type,
            'entity' => $loan->entity_name,
            'entity_id' => $loan->entity_id,
            'lender' => $loan->lender?->lender_name,
            'outstanding' => $this->outstanding($loan, $active),
            'emi' => (float) ($loan->emi_amount ?? 0),
            'next_due' => $nextDue,
            'next_status' => $next ? $this->obligationDisplayStatus($next) : null,
            'next_obligation_id' => $next?->sno,
            'paid_months' => $paid,
            'total_months' => $total,
            'maturity' => $maturity,
            'status' => $loan->status,
        ];
    }

    private function mapObligation(LoanObligation $obligation): array
    {
        $loan = $obligation->loan;
        $status = $this->obligationDisplayStatus($obligation);

        return [
            'id' => $obligation->sno,
            'loan_id' => $loan?->sno,
            'date' => Carbon::parse($obligation->due_date)->toDateString(),
            'amount' => (float) $obligation->amount_due,
            'paid' => (float) $obligation->amount_paid,
            'status' => $status,
            'type' => $obligation->obligation_type,
            'title' => $obligation->title,
            'account_no' => $loan?->loan_account_no,
            'lender' => $loan?->lender?->lender_name,
            'entity' => $loan?->entity_name,
            'entity_id' => $loan?->entity_id,
            'loan_type' => $loan?->loan_type,
            'pay_from_account_id' => $obligation->pay_from_account_id ?: $loan?->pay_from_account_id,
        ];
    }

    private function obligationDisplayStatus(LoanObligation $obligation): string
    {
        if ($obligation->status === 'paid' || (float) $obligation->amount_paid >= (float) $obligation->amount_due && (float) $obligation->amount_due > 0) {
            return 'paid';
        }

        if ($obligation->status === 'partial') {
            return 'partial';
        }

        return $this->scheduleService->obligationStatus($obligation->due_date);
    }

    private function outstanding(Loan $loan, ?LoanSchedule $schedule): float
    {
        if (!$schedule) {
            return round((float) ($loan->disbursed_amount ?: $loan->sanction_amount), 2);
        }

        $line = $schedule->lines()
            ->where('status', '!=', 'paid')
            ->orderBy('installment_no')
            ->first();

        return round((float) ($line?->closing_balance ?? 0), 2);
    }

    private function detailPayload(Loan $loan): array
    {
        return [
            'loan' => $this->mapLoanRow($loan),
            'vehicle' => $loan->vehicle,
            'tranches' => $loan->tranches,
            'jewel' => $loan->jewel,
            'cc' => $loan->cc,
            'schedules' => $loan->schedules->map(fn ($schedule) => [
                'id' => $schedule->sno,
                'version' => $schedule->version_no,
                'label' => $schedule->label,
                'active' => (bool) $schedule->is_active,
                'method' => $schedule->method,
                'effective_date' => $schedule->effective_date?->format('Y-m-d'),
                'notes' => $schedule->notes,
                'lines' => $schedule->lines,
            ])->values(),
            'obligations' => $loan->obligations->map(fn ($o) => $this->mapObligation($o))->values(),
            'payments' => $loan->payments->sortByDesc('payment_date')->values(),
            'documents' => $loan->documents,
            'audit' => $loan->audits->sortByDesc('created_at')->values(),
        ];
    }

    private function findLoan(int $id): Loan
    {
        $query = Loan::query()->where('sno', $id);
        $this->applyScope($query);
        return $query->firstOrFail();
    }

    private function applyScope($query): void
    {
        $user = auth()->user();
        $scope = data_get($user, 'loan_entity_scope');

        if (is_array($scope) && count($scope)) {
            $query->whereIn('entity_id', $scope);
        }
    }

    private function applyScopeToObligations($query, Request $request): void
    {
        $user = auth()->user();
        $scope = data_get($user, 'loan_entity_scope');

        if (is_array($scope) && count($scope)) {
            $query->whereHas('loan', fn ($q) => $q->whereIn('entity_id', $scope));
        }

        if ($request->filled('entity_id')) {
            $query->whereHas('loan', fn ($q) => $q->where('entity_id', $request->integer('entity_id')));
        }

        if ($request->filled('loan_type') && $request->loan_type !== 'all') {
            $query->whereHas('loan', fn ($q) => $q->where('loan_type', $request->loan_type));
        }

        // Status is derived from due date for calendar display, so the final status
        // filter is intentionally applied after retrieval in the controller. This avoids
        // mixing raw persisted status with the user's timezone-aware display state.
    }

    private function authorizeMaker(Loan $loan): void
    {
        $this->authorizeLoanAction($loan, ['add', 'pay']);
    }

    private function authorizeChecker(Loan $loan): void
    {
        $this->authorizeLoanAction($loan, ['approve']);
    }

    private function authorizeMakerOrChecker(Loan $loan): void
    {
        $user = auth()->user();
        if ($user && (data_get($user, 'is_finance_head') || data_get($user, 'is_accounts_executive'))) {
            return;
        }

        $perms = data_get($user, 'loan_permissions', []);
        if (is_array($perms) && count(array_intersect(['pay', 'ack'], $perms))) {
            return;
        }

        abort(403);
    }

    private function authorizeLoanAction(Loan $loan, array $roles): void
    {
        $user = auth()->user();
        $perms = data_get($user, 'loan_permissions', []);
        if (is_array($perms) && count(array_intersect($roles, $perms))) {
            return;
        }

        abort(403);
    }

    private function userId(): ?int
    {
        $user = auth()->user();
        return $user ? (int) ($user->user_id ?? $user->id) : null;
    }

    private function storeRules(): array
    {
        return [
            'entity_id' => 'nullable|integer',
            'entity_name' => 'nullable|string|max:180',
            'lender_id' => 'nullable|integer|exists:loan_lenders,sno',
            'lender_name' => 'nullable|required_without:lender_id|string|max:180',
            'lender_type' => 'nullable|string|max:30',
            'loan_account_no' => 'required|string|max:120',
            'loan_name' => 'nullable|string|max:180',
            'loan_type' => ['required', Rule::in(array_keys(config('loan.loan_types', [])))],
            'sanction_amount' => 'required|numeric|min:0',
            'disbursed_amount' => 'nullable|numeric|min:0',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'interest_type' => 'nullable|in:reducing_balance,flat_rate',
            'schedule_method' => 'nullable|in:reducing_balance,flat_rate',
            'frequency' => 'nullable|in:monthly,quarterly',
            'start_date' => 'required|date',
            'tenure_months' => 'nullable|integer|min:1|max:480',
            'pay_from_account_id' => 'nullable|integer',
            'security_details' => 'nullable|string|max:5000',
            'purpose_id' => 'nullable|integer',
            'remarks' => 'nullable|string|max:5000',
            'registration_no' => [Rule::requiredIf(fn () => request('loan_type') === 'vehicle'), 'nullable', 'string', 'max:60'],
            'make_model' => [Rule::requiredIf(fn () => request('loan_type') === 'vehicle'), 'nullable', 'string', 'max:180'],
            'chassis_no' => 'nullable|string|max:120',
            'engine_no' => 'nullable|string|max:120',
            'insurance_renewal_date' => 'nullable|date',
            'pledge_receipt_no' => [Rule::requiredIf(fn () => request('loan_type') === 'jewel'), 'nullable', 'string', 'max:120'],
            'pledged_at_branch' => 'nullable|string|max:180',
            'interest_pattern' => 'nullable|in:monthly,redemption',
            'redemption_due_date' => [Rule::requiredIf(fn () => request('loan_type') === 'jewel'), 'nullable', 'date'],
            'appraised_value' => 'nullable|numeric|min:0',
            'sanctioned_limit' => [Rule::requiredIf(fn () => request('loan_type') === 'cc'), 'nullable', 'numeric|min:0'],
            'margin_percent' => 'nullable|numeric|min:0|max:100',
            'drawing_power' => 'nullable|numeric|min:0',
            'renewal_date' => [Rule::requiredIf(fn () => request('loan_type') === 'cc'), 'nullable', 'date'],
            'stock_statement_day' => 'nullable|integer|min:1|max:31',
            'tranches' => 'nullable|array|max:24',
            'tranches.*.date' => 'nullable|date',
            'tranches.*.amount' => 'nullable|numeric|min:0',
            'tranches.*.remarks' => 'nullable|string|max:255',
            'jewel_items' => 'nullable|array|max:50',
            'jewel_items.*.description' => 'required_with:jewel_items|string|max:255',
            'jewel_items.*.gross_weight' => 'nullable|numeric|min:0',
            'jewel_items.*.net_weight' => 'nullable|numeric|min:0',
            'jewel_items.*.value' => 'nullable|numeric|min:0',
            'pay_from_account_id' => 'nullable|integer',
        ];
    }

    private function error(string $message, Throwable $e): JsonResponse
    {
        Log::error('Loan Schedule Module Error', [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);

        return response()->json([
            'status' => 500,
            'message' => $message,
            'data' => [],
        ], 500);
    }
}
