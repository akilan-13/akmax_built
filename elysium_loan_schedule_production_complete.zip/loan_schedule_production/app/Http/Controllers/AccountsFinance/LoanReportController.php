<?php

namespace App\Http\Controllers\AccountsFinance;

use App\Http\Controllers\Controller;
use App\Models\Loan;
use App\Models\LoanObligation;
use App\Models\LoanPayment;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\LoanArrayExport;
use Throwable;

class LoanReportController extends Controller
{
    private const REPORTS = [
        'R1' => ['name' => 'Loan Register', 'export' => ['xlsx', 'pdf']],
        'R2' => ['name' => 'Due List', 'export' => ['xlsx', 'pdf']],
        'R3' => ['name' => 'Overdue Report', 'export' => ['xlsx', 'pdf']],
        'R4' => ['name' => 'Loan Statement', 'export' => ['pdf']],
        'R5' => ['name' => 'CC Utilisation Report', 'export' => ['xlsx']],
        'R6' => ['name' => 'Maturity & Renewal Watchlist', 'export' => ['xlsx', 'pdf']],
        'R7' => ['name' => 'Closure / Foreclosure Report', 'export' => ['xlsx']],
        'R8' => ['name' => 'Notification & Acknowledgement Log', 'export' => ['xlsx']],
        'R9' => ['name' => 'Interest Cost Summary', 'export' => ['xlsx']],
    ];

    public function index()
    {
        return view('content.accounts_finance.loans.reports.index', [
            'reports' => self::REPORTS,
        ]);
    }

    public function export(Request $request)
    {
        $request->validate([
            'report' => 'required|in:R1,R2,R3,R4,R5,R6,R7,R8,R9',
            'format' => 'required|in:xlsx,pdf',
            'from' => 'nullable|date',
            'to' => 'nullable|date|after_or_equal:from',
            'entity_id' => 'nullable',
            'loan_type' => 'nullable|string|in:all,vehicle,term,jewel,cc',
            'loan_id' => 'nullable|integer|min:1',
        ]);

        $report = $request->string('report')->toString();
        $from = $request->input('from') ?: now(config('loan.timezone'))->startOfMonth()->toDateString();
        $to = $request->input('to') ?: now(config('loan.timezone'))->endOfMonth()->toDateString();
        $entityId = $request->input('entity_id');
        $loanType = $request->input('loan_type', 'all');
        $payload = match ($report) {
            'R1' => $this->loanRegister($entityId, $loanType),
            'R2' => $this->dueList($from, $to, $entityId, $loanType),
            'R3' => $this->overdue($from, $to, $entityId, $loanType),
            'R4' => $this->loanStatement((int) $request->input('loan_id'), $from, $to),
            'R5' => $this->ccUtilisation($from, $to, $entityId),
            'R6' => $this->watchlist($entityId, $loanType),
            'R7' => $this->closureReport($from, $to, $entityId, $loanType),
            'R8' => $this->notificationLog($from, $to, $entityId),
            'R9' => $this->interestCost($from, $to, $entityId, $loanType),
        };

        $filename = strtolower($report.'-loan-report-'.now(config('loan.timezone'))->format('Ymd-His'));
        if ($request->input('format') === 'xlsx') {
            if (!class_exists(Excel::class)) {
                abort(500, 'Laravel Excel is not installed.');
            }
            return Excel::download(new LoanArrayExport($payload['columns'], $payload['data']), $filename.'.xlsx');
        }

        if (!class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            abort(500, 'DomPDF is not installed.');
        }
        return \Barryvdh\DomPDF\Facade\Pdf::loadView('content.accounts_finance.loans.reports.export', [
            'reportName' => self::REPORTS[$report]['name'],
            'columns' => $payload['columns'],
            'rows' => $payload['data'],
            'generatedAt' => now(config('loan.timezone'))->format('d-m-Y H:i:s'),
        ])->setPaper('a4', 'landscape')->download($filename.'.pdf');
    }

    public function data(Request $request): JsonResponse
    {
        $request->validate([
            'report' => 'required|in:R1,R2,R3,R4,R5,R6,R7,R8,R9',
            'from' => 'nullable|date',
            'to' => 'nullable|date|after_or_equal:from',
            'entity_id' => 'nullable',
            'loan_type' => 'nullable|string|in:all,vehicle,term,jewel,cc',
            'loan_id' => 'nullable|integer|min:1',
        ]);

        try {
            $report = $request->string('report')->toString();
            $from = $request->input('from') ?: now(config('loan.timezone'))->startOfMonth()->toDateString();
            $to = $request->input('to') ?: now(config('loan.timezone'))->endOfMonth()->toDateString();
            $entityId = $request->input('entity_id');
            $loanType = $request->input('loan_type', 'all');

            $payload = match ($report) {
                'R1' => $this->loanRegister($entityId, $loanType),
                'R2' => $this->dueList($from, $to, $entityId, $loanType),
                'R3' => $this->overdue($from, $to, $entityId, $loanType),
                'R4' => $this->loanStatement((int) $request->input('loan_id'), $from, $to),
                'R5' => $this->ccUtilisation($from, $to, $entityId),
                'R6' => $this->watchlist($entityId, $loanType),
                'R7' => $this->closureReport($from, $to, $entityId, $loanType),
                'R8' => $this->notificationLog($from, $to, $entityId),
                'R9' => $this->interestCost($from, $to, $entityId, $loanType),
            };

            return response()->json([
                'status' => 200,
                'message' => self::REPORTS[$report]['name'].' generated successfully.',
                'report' => $report,
                'report_name' => self::REPORTS[$report]['name'],
                'exports' => self::REPORTS[$report]['export'],
                'filters' => compact('from', 'to', 'entityId', 'loanType'),
                'generated_at' => now(config('loan.timezone'))->toIso8601String(),
                'data' => $payload['data'],
                'columns' => $payload['columns'],
                'summary' => $payload['summary'] ?? [],
            ]);
        } catch (Throwable $e) {
            Log::error('Loan report generation failed', [
                'report' => $request->input('report'),
                'message' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => 500,
                'message' => 'Unable to generate the selected report.',
                'data' => [],
            ], 500);
        }
    }

    private function scopedLoanQuery(?string $entityId = null, string $loanType = 'all')
    {
        $query = Loan::query()->with('lender');
        $this->applyScope($query);

        if ($entityId !== null && $entityId !== '' && $entityId !== 'all') {
            $query->where('entity_id', $entityId);
        }

        if ($loanType !== 'all') {
            $query->where('loan_type', $loanType);
        }

        return $query;
    }

    private function applyScope($query): void
    {
        $user = auth()->user();
        if (!$user) return;

        $scope = $user->loan_entity_scope ?? null;
        if (is_string($scope)) {
            $scope = json_decode($scope, true) ?: array_filter(array_map('trim', explode(',', $scope)));
        }
        if (is_array($scope) && count($scope)) {
            if (is_numeric($scope[0])) {
                $query->whereIn('entity_id', array_values(array_filter($scope, 'is_numeric')));
            } else {
                $query->whereIn('entity_name', array_values($scope));
            }
        }
    }

    private function loanRegister(?string $entityId, string $loanType): array
    {
        $rows = $this->scopedLoanQuery($entityId, $loanType)
            ->with(['schedules' => fn ($q) => $q->where('is_active', 1)->with('lines')])
            ->orderByDesc('sno')
            ->get();

        $data = $rows->map(function (Loan $loan) {
            $schedule = $loan->schedules->first();
            $lines = $schedule?->lines ?? collect();
            $paid = $lines->where('status', 'paid')->count();
            $pending = $lines->whereIn('status', ['due', 'partial'])->sortBy('due_date')->first();
            $outstanding = $pending ? (float) $pending->closing_balance + (float) $pending->principal_amount : 0;

            return [
                'account_no' => $loan->loan_account_no,
                'loan_name' => $loan->loan_name,
                'type' => $loan->loan_type,
                'entity' => $loan->entity_name,
                'lender' => $loan->lender?->lender_name,
                'sanctioned' => (float) $loan->sanction_amount,
                'disbursed' => (float) $loan->disbursed_amount,
                'outstanding' => round($outstanding, 2),
                'rate' => (float) $loan->interest_rate,
                'emi' => (float) $loan->emi_amount,
                'maturity' => optional($loan->maturity_date)->format('Y-m-d'),
                'status' => $loan->status,
                'paid_installments' => $paid,
                'total_installments' => $lines->count(),
            ];
        })->values()->all();

        return [
            'columns' => [
                ['key' => 'account_no', 'label' => 'Loan A/c No.'],
                ['key' => 'type', 'label' => 'Type'], ['key' => 'entity', 'label' => 'Entity'],
                ['key' => 'lender', 'label' => 'Lender'], ['key' => 'sanctioned', 'label' => 'Sanctioned'],
                ['key' => 'disbursed', 'label' => 'Disbursed'], ['key' => 'outstanding', 'label' => 'Outstanding'],
                ['key' => 'rate', 'label' => 'Rate %'], ['key' => 'emi', 'label' => 'EMI / Obligation'],
                ['key' => 'maturity', 'label' => 'Maturity'], ['key' => 'status', 'label' => 'Status'],
            ],
            'data' => $data,
            'summary' => [
                'loans' => count($data),
                'outstanding' => round(array_sum(array_column($data, 'outstanding')), 2),
            ],
        ];
    }

    private function dueList(string $from, string $to, ?string $entityId, string $loanType): array
    {
        $query = LoanObligation::query()
            ->with(['loan.lender'])
            ->whereBetween('due_date', [$from, $to])
            ->whereNotIn('status', ['cancelled']);
        $this->applyScopeToObligations($query, $entityId, $loanType);
        $rows = $query->orderBy('due_date')->get();

        $data = $rows->map(fn (LoanObligation $o) => [
            'date' => $o->due_date,
            'type' => $o->obligation_type,
            'title' => $o->title,
            'account_no' => $o->loan?->loan_account_no,
            'entity' => $o->loan?->entity_name,
            'lender' => $o->loan?->lender?->lender_name,
            'amount' => (float) $o->amount_due,
            'paid' => (float) $o->amount_paid,
            'balance' => max(0, (float) $o->amount_due - (float) $o->amount_paid),
            'status' => $o->status,
            'days_to_due' => Carbon::today(config('loan.timezone'))->diffInDays(Carbon::parse($o->due_date, config('loan.timezone')), false),
        ])->values()->all();

        return [
            'columns' => [
                ['key' => 'date', 'label' => 'Due Date'], ['key' => 'type', 'label' => 'Type'], ['key' => 'title', 'label' => 'Obligation'],
                ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'], ['key' => 'lender', 'label' => 'Lender'],
                ['key' => 'amount', 'label' => 'Amount Due'], ['key' => 'paid', 'label' => 'Paid'], ['key' => 'balance', 'label' => 'Balance'],
                ['key' => 'status', 'label' => 'Status'], ['key' => 'days_to_due', 'label' => 'Days to Due'],
            ],
            'data' => $data,
            'summary' => ['items' => count($data), 'amount' => round(array_sum(array_column($data, 'balance')), 2)],
        ];
    }

    private function overdue(string $from, string $to, ?string $entityId, string $loanType): array
    {
        $query = LoanObligation::query()
            ->with(['loan.lender'])
            ->where('due_date', '<', today(config('loan.timezone')))
            ->whereBetween('due_date', [$from, $to])
            ->whereIn('status', ['overdue', 'partial']);
        $this->applyScopeToObligations($query, $entityId, $loanType);

        $data = $query->orderBy('due_date')->get()->map(function (LoanObligation $o) {
            $age = Carbon::parse($o->due_date, config('loan.timezone'))->diffInDays(now(config('loan.timezone')));
            return [
                'date' => $o->due_date,
                'account_no' => $o->loan?->loan_account_no,
                'entity' => $o->loan?->entity_name,
                'lender' => $o->loan?->lender?->lender_name,
                'title' => $o->title,
                'amount' => max(0, (float) $o->amount_due - (float) $o->amount_paid),
                'age_days' => $age,
                'age_bucket' => $age <= 7 ? '0–7 days' : ($age <= 30 ? '8–30 days' : ($age <= 60 ? '31–60 days' : '60+ days')),
                'status' => $o->status,
            ];
        })->values()->all();

        return [
            'columns' => [
                ['key' => 'date', 'label' => 'Due Date'], ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'],
                ['key' => 'lender', 'label' => 'Lender'], ['key' => 'title', 'label' => 'Obligation'], ['key' => 'amount', 'label' => 'Outstanding Due'],
                ['key' => 'age_days', 'label' => 'Age'], ['key' => 'age_bucket', 'label' => 'Age Bucket'], ['key' => 'status', 'label' => 'Status'],
            ],
            'data' => $data,
            'summary' => ['items' => count($data), 'amount' => round(array_sum(array_column($data, 'amount')), 2)],
        ];
    }

    private function loanStatement(int $loanId, string $from, string $to): array
    {
        if ($loanId <= 0) throw new \InvalidArgumentException('Select a loan for the statement.');
        $loan = $this->scopedLoanQuery()->with(['schedules.lines', 'payments'])->findOrFail($loanId);
        $schedule = $loan->schedules->sortByDesc('version_no')->first();
        $lines = $schedule?->lines?->filter(fn ($l) => $l->due_date >= $from && $l->due_date <= $to) ?? collect();
        $payments = $loan->payments->filter(fn ($p) => $p->payment_date >= $from && $p->payment_date <= $to)->sortBy('payment_date');

        $data = $lines->map(fn ($l) => [
            'date' => $l->due_date,
            'entry' => 'Scheduled payment #'.$l->installment_no,
            'debit' => (float) $l->emi_amount,
            'credit' => 0,
            'principal' => (float) $l->principal_amount,
            'interest' => (float) $l->interest_amount,
            'balance' => (float) $l->closing_balance,
            'status' => $l->status,
        ])->concat($payments->map(fn ($p) => [
            'date' => $p->payment_date,
            'entry' => ucfirst(str_replace('_', ' ', $p->payment_type)),
            'debit' => 0,
            'credit' => (float) $p->amount,
            'principal' => 0,
            'interest' => (float) $p->penal_interest,
            'balance' => 0,
            'status' => $p->status,
        ]))->sortBy('date')->values()->all();

        return [
            'columns' => [
                ['key' => 'date', 'label' => 'Date'], ['key' => 'entry', 'label' => 'Entry'], ['key' => 'debit', 'label' => 'Scheduled'],
                ['key' => 'credit', 'label' => 'Paid'], ['key' => 'principal', 'label' => 'Principal'], ['key' => 'interest', 'label' => 'Interest'],
                ['key' => 'balance', 'label' => 'Balance'], ['key' => 'status', 'label' => 'Status'],
            ],
            'data' => $data,
            'summary' => [
                'account_no' => $loan->loan_account_no,
                'lender' => $loan->lender?->lender_name,
                'scheduled_total' => round(array_sum(array_column($data, 'debit')), 2),
                'paid_total' => round(array_sum(array_column($data, 'credit')), 2),
            ],
        ];
    }

    private function ccUtilisation(string $from, string $to, ?string $entityId): array
    {
        $query = DB::table('loan_cc_utilisations as u')
            ->join('loan_cc_facilities as c', 'c.sno', '=', 'u.cc_facility_id')
            ->join('loans as l', 'l.sno', '=', 'c.loan_id')
            ->leftJoin('loan_lenders as ll', 'll.sno', '=', 'l.lender_id')
            ->whereBetween('u.month_end', [$from, $to])
            ->where('l.loan_type', 'cc')
            ->where('l.status', 'active');
        $this->applyScopeQueryBuilder($query, $entityId);

        $data = $query->orderBy('u.month_end')->get([
            'u.month_end as date', 'l.loan_account_no as account_no', 'l.entity_name as entity', 'll.lender_name as lender',
            'c.sanctioned_limit', 'u.drawing_power', 'u.utilised_amount', 'u.interest_debited',
        ])->map(function ($r) {
            $limit = (float) $r->sanctioned_limit;
            $util = (float) $r->utilised_amount;
            return [
                'date' => $r->date, 'account_no' => $r->account_no, 'entity' => $r->entity, 'lender' => $r->lender,
                'sanctioned_limit' => $limit, 'drawing_power' => (float) $r->drawing_power, 'utilised' => $util,
                'utilisation_percent' => $limit > 0 ? round(($util / $limit) * 100, 2) : 0,
                'interest_debited' => (float) $r->interest_debited,
            ];
        })->values()->all();

        return [
            'columns' => [
                ['key' => 'date', 'label' => 'Month End'], ['key' => 'account_no', 'label' => 'CC A/c'], ['key' => 'entity', 'label' => 'Entity'],
                ['key' => 'lender', 'label' => 'Lender'], ['key' => 'sanctioned_limit', 'label' => 'Limit'], ['key' => 'drawing_power', 'label' => 'Drawing Power'],
                ['key' => 'utilised', 'label' => 'Utilised'], ['key' => 'utilisation_percent', 'label' => 'Utilisation %'], ['key' => 'interest_debited', 'label' => 'Interest Debited'],
            ],
            'data' => $data,
            'summary' => ['rows' => count($data), 'interest' => round(array_sum(array_column($data, 'interest_debited')), 2)],
        ];
    }

    private function watchlist(?string $entityId, string $loanType): array
    {
        $today = today(config('loan.timezone'));
        $loans = $this->scopedLoanQuery($entityId, $loanType)
            ->whereIn('status', ['active', 'pending_approval'])
            ->with('cc', 'jewel')
            ->get();

        $data = [];
        foreach ($loans as $loan) {
            if ($loan->maturity_date && $loan->maturity_date >= $today->toDateString() && $loan->maturity_date <= $today->copy()->addDays(90)->toDateString()) {
                $data[] = ['kind' => 'maturity', 'date' => $loan->maturity_date, 'days_left' => $today->diffInDays(Carbon::parse($loan->maturity_date), false), 'account_no' => $loan->loan_account_no, 'entity' => $loan->entity_name, 'lender' => $loan->lender?->lender_name, 'type' => $loan->loan_type];
            }
            if ($loan->cc?->renewal_date && $loan->cc->renewal_date >= $today->toDateString() && $loan->cc->renewal_date <= $today->copy()->addDays(60)->toDateString()) {
                $data[] = ['kind' => 'cc renewal', 'date' => $loan->cc->renewal_date, 'days_left' => $today->diffInDays(Carbon::parse($loan->cc->renewal_date), false), 'account_no' => $loan->loan_account_no, 'entity' => $loan->entity_name, 'lender' => $loan->lender?->lender_name, 'type' => 'cc'];
            }
            if ($loan->jewel?->redemption_due_date && $loan->jewel->redemption_due_date >= $today->toDateString() && $loan->jewel->redemption_due_date <= $today->copy()->addDays(30)->toDateString()) {
                $data[] = ['kind' => 'jewel redemption', 'date' => $loan->jewel->redemption_due_date, 'days_left' => $today->diffInDays(Carbon::parse($loan->jewel->redemption_due_date), false), 'account_no' => $loan->loan_account_no, 'entity' => $loan->entity_name, 'lender' => $loan->lender?->lender_name, 'type' => 'jewel'];
            }
        }

        usort($data, fn ($a, $b) => $a['date'] <=> $b['date']);

        return [
            'columns' => [
                ['key' => 'kind', 'label' => 'Watch'], ['key' => 'date', 'label' => 'Date'], ['key' => 'days_left', 'label' => 'Days Left'],
                ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'], ['key' => 'lender', 'label' => 'Lender'], ['key' => 'type', 'label' => 'Type'],
            ],
            'data' => $data,
            'summary' => ['items' => count($data)],
        ];
    }

    private function closureReport(string $from, string $to, ?string $entityId, string $loanType): array
    {
        $data = $this->scopedLoanQuery($entityId, $loanType)
            ->whereIn('status', ['closed', 'foreclosed'])
            ->whereBetween(DB::raw('DATE(COALESCE(closed_at, updated_at))'), [$from, $to])
            ->get()
            ->map(fn (Loan $l) => [
                'date' => optional($l->closed_at ?: $l->updated_at)->format('Y-m-d'), 'account_no' => $l->loan_account_no,
                'entity' => $l->entity_name, 'lender' => $l->lender?->lender_name, 'type' => $l->loan_type,
                'status' => $l->status, 'reason' => $l->closure_reason,
            ])->values()->all();

        return [
            'columns' => [
                ['key' => 'date', 'label' => 'Closed Date'], ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'],
                ['key' => 'lender', 'label' => 'Lender'], ['key' => 'type', 'label' => 'Type'], ['key' => 'status', 'label' => 'Status'], ['key' => 'reason', 'label' => 'Reason'],
            ],
            'data' => $data,
            'summary' => ['items' => count($data)],
        ];
    }

    private function notificationLog(string $from, string $to, ?string $entityId): array
    {
        $query = DB::table('loan_notifications as n')
            ->join('loans as l', 'l.sno', '=', 'n.loan_id')
            ->whereBetween(DB::raw('DATE(n.created_at)'), [$from, $to]);
        $this->applyScopeQueryBuilder($query, $entityId);

        $data = $query->orderByDesc('n.created_at')->get([
            'n.created_at', 'n.channel', 'n.recipient_user_id', 'n.recipient_address', 'n.scheduled_for', 'n.sent_at', 'n.delivery_status',
            'n.attempts', 'n.acknowledged_at', 'l.loan_account_no as account_no', 'l.entity_name as entity',
        ])->map(fn ($r) => [
            'created_at' => $r->created_at, 'scheduled_for' => $r->scheduled_for, 'sent_at' => $r->sent_at,
            'channel' => $r->channel, 'recipient' => $r->recipient_address ?: $r->recipient_user_id,
            'status' => $r->delivery_status, 'attempts' => (int) $r->attempts, 'acknowledged_at' => $r->acknowledged_at,
            'account_no' => $r->account_no, 'entity' => $r->entity,
        ])->values()->all();

        return [
            'columns' => [
                ['key' => 'created_at', 'label' => 'Created'], ['key' => 'scheduled_for', 'label' => 'Scheduled'], ['key' => 'sent_at', 'label' => 'Sent'],
                ['key' => 'channel', 'label' => 'Channel'], ['key' => 'recipient', 'label' => 'Recipient'], ['key' => 'status', 'label' => 'Status'],
                ['key' => 'attempts', 'label' => 'Attempts'], ['key' => 'acknowledged_at', 'label' => 'Acknowledged'], ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'],
            ],
            'data' => $data,
            'summary' => ['sent' => count(array_filter($data, fn ($x) => $x['status'] === 'sent')), 'failed' => count(array_filter($data, fn ($x) => $x['status'] === 'failed'))],
        ];
    }

    private function interestCost(string $from, string $to, ?string $entityId, string $loanType): array
    {
        $query = LoanPayment::query()->with('loan.lender')->whereBetween('payment_date', [$from, $to])->whereIn('status', ['posted', 'approved']);
        $this->applyScopeToPayments($query, $entityId, $loanType);

        $grouped = $query->get()->groupBy(fn ($p) => $p->loan_id)->map(function ($payments) {
            $loan = $payments->first()->loan;
            return [
                'account_no' => $loan?->loan_account_no,
                'entity' => $loan?->entity_name,
                'lender' => $loan?->lender?->lender_name,
                'type' => $loan?->loan_type,
                'interest_paid' => round((float) $payments->sum('amount') * 0 + (float) $payments->sum('penal_interest'), 2),
                'penal_interest' => round((float) $payments->sum('penal_interest'), 2),
                'payment_count' => $payments->count(),
            ];
        })->values()->all();

        // Base interest cost also comes from scheduled interest lines in the selected period.
        $lineQuery = DB::table('loan_schedule_lines as sl')
            ->join('loan_schedules as ss', 'ss.sno', '=', 'sl.schedule_id')
            ->join('loans as l', 'l.sno', '=', 'ss.loan_id')
            ->leftJoin('loan_lenders as ll', 'll.sno', '=', 'l.lender_id')
            ->whereBetween('sl.due_date', [$from, $to])
            ->where('ss.is_active', 1);
        $this->applyScopeQueryBuilder($lineQuery, $entityId, $loanType);
        $interestRows = $lineQuery->get(['l.sno as loan_id', 'l.loan_account_no as account_no', 'l.entity_name as entity', 'll.lender_name as lender', 'l.loan_type as type', DB::raw('SUM(sl.interest_amount) as interest_scheduled')])->groupBy('loan_id');

        $map = collect($grouped)->keyBy('account_no');
        foreach ($interestRows as $r) {
            if (!$map->has($r->account_no)) {
                $map->put($r->account_no, ['account_no' => $r->account_no, 'entity' => $r->entity, 'lender' => $r->lender, 'type' => $r->type, 'interest_paid' => 0, 'penal_interest' => 0, 'payment_count' => 0]);
            }
            $row = $map->get($r->account_no);
            $row['interest_scheduled'] = round((float) $r->interest_scheduled, 2);
            $map->put($r->account_no, $row);
        }

        $data = $map->values()->all();

        return [
            'columns' => [
                ['key' => 'account_no', 'label' => 'Loan A/c'], ['key' => 'entity', 'label' => 'Entity'], ['key' => 'lender', 'label' => 'Lender'],
                ['key' => 'type', 'label' => 'Type'], ['key' => 'interest_scheduled', 'label' => 'Scheduled Interest'], ['key' => 'penal_interest', 'label' => 'Penal Interest'], ['key' => 'payment_count', 'label' => 'Payments'],
            ],
            'data' => $data,
            'summary' => ['interest_scheduled' => round(array_sum(array_column($data, 'interest_scheduled')), 2), 'penal_interest' => round(array_sum(array_column($data, 'penal_interest')), 2)],
        ];
    }

    private function applyScopeToObligations($query, ?string $entityId, string $loanType): void
    {
        $query->whereHas('loan', function ($q) use ($entityId, $loanType) {
            $this->applyScope($q);
            if ($entityId !== null && $entityId !== '' && $entityId !== 'all') $q->where('entity_id', $entityId);
            if ($loanType !== 'all') $q->where('loan_type', $loanType);
        });
    }

    private function applyScopeToPayments($query, ?string $entityId, string $loanType): void
    {
        $query->whereHas('loan', function ($q) use ($entityId, $loanType) {
            $this->applyScope($q);
            if ($entityId !== null && $entityId !== '' && $entityId !== 'all') $q->where('entity_id', $entityId);
            if ($loanType !== 'all') $q->where('loan_type', $loanType);
        });
    }

    private function applyScopeQueryBuilder($query, ?string $entityId = null, string $loanType = 'all'): void
    {
        $user = auth()->user();
        $scope = $user?->loan_entity_scope ?? null;
        if (is_string($scope)) $scope = json_decode($scope, true) ?: array_filter(array_map('trim', explode(',', $scope)));
        if (is_array($scope) && count($scope)) {
            if (is_numeric($scope[0])) $query->whereIn('l.entity_id', array_values(array_filter($scope, 'is_numeric')));
            else $query->whereIn('l.entity_name', array_values($scope));
        }
        if ($entityId !== null && $entityId !== '' && $entityId !== 'all') $query->where('l.entity_id', $entityId);
        if ($loanType !== 'all') $query->where('l.loan_type', $loanType);
    }
}
