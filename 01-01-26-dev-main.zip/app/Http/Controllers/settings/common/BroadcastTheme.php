<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BroadcastThemeModel;
use Illuminate\Support\Facades\Validator;
use App\Models\BranchModel;
use App\Models\UserRolePermissionModel;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\DB;

class BroadcastTheme extends Controller
{
  protected static $branch_id = 1;
  
 public function index(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $search_filter = $request->search_filter ?? '';
   
    $query = BroadcastThemeModel::where('status', '!=', 2);

    if ($search_filter != '') {
        $query->where(function ($subquery) use ($search_filter) {
            $subquery->where('theme_name', 'LIKE', "%{$search_filter}%");
        });
    }

    $country = $query->orderBy('status', 'asc')->orderBy('sno', 'asc')->orderBy('status', 'desc')->paginate($perpage);
    $helper = new \App\Helpers\Helpers();
    // If AJAX request → return JSON only
    if ($request->ajax()) {
        $data = $country->map(function($item) use ($helper) {
            // Decode DB theme JSON
                $theme = json_decode($item->theme_style, true);
        
                if (is_array($theme)) {
                    // ✅ Force overwrite position
                    $theme['position'] = 'relative';
                }
            return [
                'sno' => $item->sno,
                'theme_name' => $item->theme_name,
                'status' => $item->status,
                'template_name' => $item->template_name,
                'data' => $theme,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });
    
        return response()->json([
            'data' => $data,
            'current_page' => $country->currentPage(),
            'last_page' => $country->lastPage(),
            'total' => $country->total(),
        ]);
    }

    // Normal blade load
    return view('content.settings.common.broadcast_theme.broadcast_theme_list', [
        'perpage' => $perpage,
        'search_filter' => $search_filter
    ]);
}


 
  
  

  public function List()
  {
      $city = BroadcastThemeModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    
    public function List_for_edit()
  {
    $sms_template = BroadcastThemeModel::orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  public function Add(Request $request)
  {
      
      $branch_list = BranchModel::where('status', 0)->get();

        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
    return view('content.settings.common.broadcast_theme.add_broadcast_theme',[
        'branch_list'=>$branch_list,
        'roleList'=>$roleList,
        ]);
  }
  public function Edit($id,Request $request)
  {
      $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      
      $branch_list = BranchModel::where('status', 0)->get();

        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
        $editData = BroadcastThemeModel::where('status', '!=', 2)
                    ->where('sno',$decryptedValue)
                    ->first();
        $editData->theme_style=json_decode($editData->theme_style);
        
    return view('content.settings.common.broadcast_theme.edit_broadcast_theme',[
        'branch_list'=>$branch_list,
        'roleList'=>$roleList,
        'editData'=>$editData,
        ]);
  }
  
    public function saveTemplate(Request $request)
{
    $branch_id = $request->branch_id;
    $user_id = $request->user()->user_id ?? 1;
    
        
       try{
           $add_theme = new BroadcastThemeModel();
            $add_theme->theme_style  = $request->theme;
            $add_theme->theme_name = $request->theme_name;
            $add_theme->created_by = $user_id;
            $add_theme->updated_by = $user_id;
        
            $add_theme->save();
            return response()->json(["status" => "success" ,"message"=>"Theme added Successfully"]);
       }catch(\Exception $e){
            return response()->json(["status" => "error","message"=>$e->getMessage()]);
       }
    return response()->json(["status" => "success"]);
}

  public function Update(Request $request)
  {
    $theme_id = $request->theme_id;
    $user_id = $request->user()->user_id ?? 1;

    
    $themeData=BroadcastThemeModel::where('sno',$theme_id)->where('status','!=',2)->first();
        
       try{
           if($themeData){
            $themeData->theme_style  = $request->theme;
            $themeData->theme_name = $request->theme_name;
            $themeData->updated_by = $user_id;
            $themeData->update();
             return response()->json(["status" => "success" ,"message"=>"Theme Updated Successfully"]);
           } 
       }catch(\Exception $e){
            return response()->json(["status" => "error","message"=>$e->getMessage()]);
       }
    return response()->json(["status" => "success"]);
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  BroadcastThemeModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

 public function Status($id, Request $request)
{
    // Fetch the current theme (ignore deleted ones)
    $theme = BroadcastThemeModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->firstOrFail();

    $newStatus = (int) $request->input('status', 0);

    if ($newStatus === 0) {
        // ✅ Activate this one and deactivate others
        $theme->status = 0;
        $theme->save();

        BroadcastThemeModel::where('sno', '!=', $id)
            ->where('status', '!=', 2)
            ->update(['status' => 1]);
    } else {
        // ✅ If user deactivates, just set it to inactive (others untouched)
        $theme->status = 1;
        $theme->save();
    }

    return response()->json([
        'status'    => 200,
        'message'   => 'Status updated successfully!',
        'error_msg' => null,
        'data'      => null,
    ]);
}

  
  public function checkDates(Request $request) {
      
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('egc_news_broadcast')
        ->where('status', '!=',2)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}
  
  
}
