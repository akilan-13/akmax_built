<?php

namespace App\Http\Controllers\errors;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ErrorController extends Controller
{
    public function index()
    {
        return view('errors.role_permission_error');
    }

    public function unauthorized()
    {
        return view('errors.unauthorized');
    }
}