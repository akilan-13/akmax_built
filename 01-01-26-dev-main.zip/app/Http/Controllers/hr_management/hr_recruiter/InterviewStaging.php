<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewSessionModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class InterviewStaging extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
      ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->select('egc_job_request.*','egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_entity.entity_base_color',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_entity.entity_logo',
      'egc_company.company_base_color')
      ->orderBy('egc_job_request.sno','desc')
      ->get();
     
        foreach($jobRequest as $request){
          $interviewStageList = InterviewScheduleStageModel::where('egc_interview_schedule_stage.status','!=',2)
            ->join('egc_interview_schedule', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
            ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
            ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
            ->where('egc_interview_schedule.job_request_id',$request->sno)
            ->select('egc_interview_schedule_stage.*','egc_interview_category.interview_category_name','egc_interview_mode.interview_mode_name','egc_interview_mode.mode_icon')
            ->orderBy('egc_interview_schedule_stage.stage_order','asc')
            ->get();
           
            $appicants=DB::table('egc_applicant')->where('job_request_id',$request->sno)->where('status','!=',2)->count();
            $appicantShorlist=DB::table('egc_applicant')->where('job_request_id',$request->sno)->where('shortlist_check',1)->where('status','!=',2)->count();
            $request->candidate_count=$appicants;
            $request->shortlist_count=$appicantShorlist;
             $request->interviewStageList =$interviewStageList;   
        }

      $helper = new \App\Helpers\Helpers();
        // return $jobRequest;
    
      return view('content.hr_management.hr_recruiter.interview_staging.staging_list', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          // 'jobRequest' => $jobRequest,
          // 'perpage' => $perpage,
          // 'search_filter' => $search_filter,
      ]);
  }

   


  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }
      

  public function candidateList(Request $request)
    {
        $jobRequestId = $request->job_request_id;
        $filterType   = $request->filter_type;
        $stageId      = $request->stage_id;

        $query = DB::table('egc_applicant')
            ->where('job_request_id', $jobRequestId)
            ->where('status', '!=', 2);


        // Default / Candidates
        if ($filterType === 'candidates') {
         $candidates = $query
            ->orderBy('created_at', 'desc')
            ->get();

           return view(
                'content.hr_management.hr_recruiter.interview_staging.candidate_list',
                compact('candidates')
            );
        }

        // Shortlisted
        elseif ($filterType === 'shortlisted') {
            $query->where('shortlist_check', 1);
            $candidates = $query
            ->orderBy('created_at', 'desc')
            ->get();

           return view(
                'content.hr_management.hr_recruiter.interview_staging.candidate_list',
                compact('candidates')
            );
        }

        // Interview Stage
        elseif ($filterType === 'stage' && $stageId) {

           $stage = DB::table('egc_interview_schedule_stage')
                ->join('egc_interview_category', 'egc_interview_category.sno', '=', 'egc_interview_schedule_stage.interview_category_id')
                ->where('egc_interview_schedule_stage.sno', $stageId)
                ->select('egc_interview_schedule_stage.*','egc_interview_category.interview_category_name')
                ->first();

            $selectedIds = [];

            if (!empty($stage->selected_ids)) {
                $decoded = json_decode($stage->selected_ids, true);
                if (is_array($decoded)) {
                    $selectedIds = $decoded;
                }
            }
            $isLastStage = !DB::table('egc_interview_schedule_stage')
               ->join('egc_interview_schedule', 'egc_interview_schedule.sno', '=', 'egc_interview_schedule_stage.interview_schedule_id')
              ->where('egc_interview_schedule.job_request_id', $jobRequestId)
              ->where('egc_interview_schedule_stage.sno', '>', $stageId)
              ->exists();
            

            $ids = [];

            if ($stage && $stage->shortlist_applicant_ids) {
                $decoded = json_decode($stage->shortlist_applicant_ids, true);
                if (is_array($decoded)) {
                    $ids = $decoded;
                }
            }

            // If no shortlisted applicants
            if (empty($ids)) {
                return view(
                    'content.hr_management.hr_recruiter.interview_staging.interview_result',
                    ['candidates' => collect()]
                );
            }

            // 2️⃣ Fetch applicants
            $candidates = DB::table('egc_applicant')
                ->whereIn('sno', $ids)
                ->where('status', '!=', 2)
                ->orderBy('created_at', 'desc')
                ->get();

            // 3️⃣ Fetch answers (MATCH saveAnswer())
            $answers = DB::table('egc_interview_answers as ia')
              ->where('ia.interview_schedule_stage_id', $stageId)
              ->whereIn('ia.created_by', $ids)
              ->where('ia.status', 1)
              ->select(
                  'ia.created_by as applicant_id',
                  'ia.interview_question_id',
                  'ia.answer_type',
                  'ia.answer_text',
                  'ia.answer_file',
                  'ia.time_taken',
                  'ia.retake_count',
                  'ia.created_at'
              )
              ->orderBy('ia.created_at')
              ->get()
              ->groupBy('applicant_id');


            $stageQuestions = DB::table('egc_interview_schedule_questions as sq')
              ->join('egc_interview_question as iq', 'iq.sno', '=', 'sq.interview_question_id')
              ->where('sq.interview_schedule_stage_id', $stageId)
              ->select(
                  'sq.interview_question_id',
                  'iq.field_name as question_text'
              )
              ->orderBy('sq.sno')
              ->get();

          foreach ($candidates as $candidate) {
              $candidate->is_selected = in_array((string)$candidate->sno, $selectedIds) ? 1 : 0;
              $candidateAnswers = $answers[$candidate->sno] ?? collect();

              $candidate->questions = $stageQuestions->map(function ($q) use ($candidateAnswers) {

                  $answer = $candidateAnswers
                      ->firstWhere('interview_question_id', $q->interview_question_id);

                  return (object) [
                      'question_text' => $q->question_text,

                      'answer_type'   => $answer->answer_type   ?? null,
                      'answer_text'   => $answer->answer_text   ?? null,
                      'answer_file'   => $answer->answer_file   ?? null,
                      'time_taken'    => $answer->time_taken    ?? 0,
                      'created_at'    => $answer->created_at    ?? null,
                      'retake_count' => $answer->retake_count ?? 0,

                      // ✅ SIMPLE STATUS
                      'status' => $answer ? 'completed' : 'not_answered'
                  ];
              });

                $totalQuestions = $candidate->questions->count();
                $answeredCount  = $candidate->questions
                  ->where('status', 'completed')
                  ->count();
                // $candidate->is_selected = $selected ? 1 : 0;
                $candidate->is_completed = ($totalQuestions > 0 && $answeredCount === $totalQuestions);
                $candidate->is_last_stage = $isLastStage;
              
          }


            return view(
                'content.hr_management.hr_recruiter.interview_staging.interview_result',
                compact('candidates','stageId','stage')
            );
        }

        // Hired
        elseif ($filterType === 'hired') {
            $query->where('hiring_status', 1); 
        }


        $candidates = $query
            ->orderBy('created_at', 'desc')
            ->get();

        return view(
            'content.hr_management.hr_recruiter.interview_staging.candidate_list',
            compact('candidates')
        );
    }


public function hireCandidate(Request $request)
{
    $request->validate([
        'applicant_id' => 'required|integer'
    ]);

    DB::beginTransaction();

    try {
        $applicantId = (string) $request->applicant_id;

        /* -----------------------------
           1️⃣ Mark applicant as hired
        ------------------------------ */
        DB::table('egc_applicant')
            ->where('sno', $applicantId)
            ->update([
                'hiring_status' => 1,
                'updated_at'    => now()
            ]);

        /* -----------------------------
           2️⃣ Find CURRENT interview stage
        ------------------------------ */
        $currentStage = DB::table('egc_interview_schedule_stage')
            ->whereJsonContains('shortlist_applicant_ids', $applicantId)
            ->orderBy('stage_order', 'desc')
            ->first();

        if (!$currentStage) {
            throw new \Exception('Current interview stage not found');
        }

        /* -----------------------------
           3️⃣ Update selected_ids safely
        ------------------------------ */
        $selectedIds = [];

        if (!empty($currentStage->selected_ids)) {
            $decoded = json_decode($currentStage->selected_ids, true);
            if (is_array($decoded)) {
                $selectedIds = $decoded;
            }
        }

        if (!in_array($applicantId, $selectedIds)) {
            $selectedIds[] = $applicantId;

            DB::table('egc_interview_schedule_stage')
                ->where('sno', $currentStage->sno)
                ->update([
                    'selected_ids' => json_encode(array_values($selectedIds)),
                    'updated_at'   => now()
                ]);
        }

        DB::commit();

        return response()->json([
            'success' => true,
            'message' => 'Candidate hired successfully'
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Failed to hire candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
}


public function shortlistCandidate(Request $request)
{
    $request->validate([
        'applicant_id' => 'required|integer'
    ]);

    DB::beginTransaction();

    try {
        $applicantId = (string) $request->applicant_id;

        /* -----------------------------
           1️⃣ Mark applicant shortlisted
        ------------------------------ */
        DB::table('egc_applicant')
            ->where('sno', $applicantId)
            ->update([
                'shortlist_check' => 1,
                'updated_at'      => now()
            ]);

        /* -----------------------------
           2️⃣ Get applicant current stage
        ------------------------------ */
        $currentStage = DB::table('egc_interview_schedule_stage')
            ->whereJsonContains('shortlist_applicant_ids', $applicantId)
            ->orderBy('stage_order', 'desc')
            ->first();

        if (!$currentStage) {
            throw new \Exception('Current interview stage not found');
        }

        /* -----------------------------
           3️⃣ Get NEXT stage
        ------------------------------ */
        $nextStage = DB::table('egc_interview_schedule_stage')
            ->where('interview_schedule_id', $currentStage->interview_schedule_id)
            ->where('stage_order', '>', $currentStage->stage_order)
            ->orderBy('stage_order')
            ->first();

        // If last stage → nothing to shortlist into
        if (!$nextStage) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant shortlisted (last stage reached)'
            ]);
        }

        /* -----------------------------
           4️⃣ Update shortlist_applicant_ids
        ------------------------------ */
       $ids = [];

        if ($nextStage->shortlist_applicant_ids) {
            $decoded = json_decode($nextStage->shortlist_applicant_ids, true);
            if (is_array($decoded)) {
                $ids = $decoded;
            }
        }

        // Already shortlisted → stop
        if (in_array($applicantId, $ids)) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant already shortlisted'
            ]);
        }

        // ✅ ADD applicant to next stage
        $ids[] = $applicantId;

        DB::table('egc_interview_schedule_stage')
            ->where('sno', $nextStage->sno)
            ->update([
                'shortlist_applicant_ids' => json_encode(array_values($ids)),
                'updated_at'              => now()
            ]);

            $currentIds = [];

          if ($currentStage->selected_ids) {
              $decoded = json_decode($currentStage->selected_ids, true);
              if (is_array($decoded)) {
                  $currentIds = $decoded;
              }
          }

          if (!in_array($applicantId, $currentIds)) {
              $currentIds[] = $applicantId;

              DB::table('egc_interview_schedule_stage')
                  ->where('sno', $currentStage->sno)
                  ->update([
                      'selected_ids' => json_encode(array_values($currentIds)),
                      'updated_at' => now()
                  ]);
          }

        DB::commit();

        return response()->json([
            'success' => true,
            'next_stage_id' => $nextStage->sno
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Failed to shortlist candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
}



}
