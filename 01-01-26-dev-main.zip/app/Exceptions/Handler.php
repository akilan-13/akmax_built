<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
// 1. HTTP Exceptions
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;

// 2. Authentication & Authorization
use Illuminate\Auth\AuthenticationException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Session\TokenMismatchException;

// 3. Validation
use Illuminate\Validation\ValidationException;

use GuzzleHttp\Exception\RequestException;

// 4. Database
use Illuminate\Database\QueryException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\Eloquent\RelationNotFoundException;
use Illuminate\Pagination\CursorPaginationException; // optional
use Illuminate\Pagination\Paginator; // for RecordsNotFoundException (deprecated)

// 5. File/System
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

// 6. Session / Cache
use Illuminate\Session\StoreException;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Cache\CacheException;

// 7. Queue
use Illuminate\Queue\MaxAttemptsExceededException;
use Illuminate\Queue\TimeoutExceededException as TimeoutException;

// 8. Mail
use Symfony\Component\Mailer\Exception\TransportException;

// 9. PHP Exceptions
use BadMethodCallException;
use ErrorException;
use Error;
use RuntimeException;
use InvalidArgumentException;
use LogicException;

// Laravel internal
use Illuminate\Contracts\Container\BindingResolutionException;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

    public function render($request, Throwable $exception)
    {
        if ($exception instanceof NotFoundHttpException) {
            return response()->view('errors.404', [], 404);
        }

        if ($exception instanceof BadMethodCallException) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof ErrorException) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof InvalidArgumentException) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof Error) {
            return response()->view('errors.500', [
                'message' => $exception->getMessage(),
            ], 500);
        }

        if ($exception instanceof BindingResolutionException) {
            return response()->view('errors.500', [
                'message' => "Binding Resolution Error: " . $exception->getMessage(),
            ], 500);
        }
        if ($exception instanceof RequestException) {
            return response()->view('errors.500', [
                'message' => "Network Error: " . $exception->getMessage(),
            ], 500);
        }

        if ($exception instanceof QueryException) {
            return response()->view('errors.500', [
                'message' => "Query Exception Error: " . $exception->getMessage(),
            ], 500);
        }
        
        if ($exception instanceof HttpException) {
            $status = $exception->getStatusCode();

            // If a view exists for this status code, use it:
            if (view()->exists("errors.$status")) {
                return response()->view("errors.$status", [], $status);
            }
        }

        return parent::render($request, $exception);
    }
}
