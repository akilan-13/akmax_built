<!-- resources/views/errors/404.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Not Found</title>
    
</head>
<body>
    <div class="error-page">
        
        <img src="{{ asset('assets/egc_images/bg_image/404-Error-Page.png') }}" alt="404 Not Found" class="error-image " />   
        <a href="{{ url('/dashboard') }}" class="btn btn-primary">Return to Homepage</a>
    </div>
</body>

<style>

    html, body {
        margin: 0;
        padding: 0;
        height: 100%;
        overflow: hidden; /* Prevent scroll */
    }
  /* public/css/app.css */
  .error-page {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    height: 100vh;
    width: 100%;
    box-sizing: border-box;
    padding: 20px;
    background-color: #f8f9fa;
}

.error-image {
    max-width: 100%;
    height: auto;
    max-height: 60vh; 
    margin-bottom: 20px;
}

.btn-primary {
    background-color: #ab2b22; 
    border-color: #ab2b22;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    text-decoration: none;
  
}

.btn-primary:hover {
    background-color:#fba919;
    border-color:#fba919;
    color:black;
}

.btn-primary:focus, .btn-primary:active {
    box-shadow: none; 
}

</style>
</html>