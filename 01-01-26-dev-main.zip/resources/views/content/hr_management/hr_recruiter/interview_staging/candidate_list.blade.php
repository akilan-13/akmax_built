@if(count($candidates))
<table class="table table-row-dashed table-striped table-hover mb-0 bg-white">
    <thead >
        <tr class="fw-bold fs-6 gs-0 bg-primary">
            <th>Name</th>
            <th>mobile / Email</th>
            <th>Status</th>
            <th>Applied On</th>
        </tr>
    </thead>
    <tbody>
        @foreach($candidates as $c)
        <tr>
            <td>{{ $c->applicant_name }}</td>
            <td>
                <div>{{ $c->mobile}}</div>
                <div>{{ $c->email }}</div>
            </td>
            <td>
                <span class="badge bg-info">{{ $c->status_text ?? '-' }}</span>
            </td>
            <td>{{ date('d M Y', strtotime($c->created_at)) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="text-center text-muted py-4">
    No candidates found
</div>
@endif
