@extends('layouts/layoutMaster')

@section('title', 'Staff Timechamp')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<style>
    /* Scroll styling */
    .staff-scroll {
        height: calc(100vh - 190px);
        overflow-y: auto;
    }

    .staff-details-scroll {
        height: calc(100vh - 190px);
        overflow-y: auto;
    }

    /* Hover & Selected Effect */
    .staff-item {
        transition: background 0.2s ease;
        cursor: pointer;
    }

    .staff-item:hover {
        background: #f5f5f5;
    }

    .staff-selected {
        background: #eef4ff !important;
        border-left: 4px solid #4a6cf7;
    }

    /* Rounded Image */
    .staff-avatar {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        object-fit: cover;
    }
</style>
<style>
    .mini-card {
        border-radius: 10px;
        transition: 0.2s ease-in-out;
    }

    .mini-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .icon-box {
        width: 45px;
        height: 45px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Staff Timechamp</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Staff Timechamp
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            @if($user_id == 0)
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_report">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>update report
            </a>
            @endif
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                 <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-2">
            <div class="col-lg-4">
                <label class="text-dark mb-1 fs-6 fw-semibold">Company<span
                        class="text-danger">*</span></label>
                <select id="company_fill" name="company_fill" class="select3 form-select" >
                    <option value="egc">Elysium Groups of Companies</option>
                    @if(isset($company_list))
                    @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                    @endforeach
                    @endif
                </select>
            </div>
            <div class="col-lg-4">
                <label class="text-dark mb-1 fs-6 fw-semibold">Entity<span
                        class="text-danger">*</span></label>
                <select class="select3 form-select" id="entity_fill" name="entity_fill">/
                    <option value="">Select Entity Name</option>
                </select>
            </div>
        </div>
        <div class="d-flex gap-3" style="height: calc(100vh - 120px);">

            <!-- LEFT: STAFF LIST -->
            <div class="staff-list card shadow-sm border-0" style="width: 340px; overflow: hidden;">
                <div class="card-header bg-white border-bottom py-3">
                    <h5 class="mb-0 fw-semibold">Staff</h5>
                </div>

                <div class="card-body p-0">
                    <ul id="list-table-body" class="list-group list-group-flush staff-scroll">
                        <!-- Staff list items append here -->
                    </ul>
                </div>
            </div>


            <!-- RIGHT: STAFF DETAILS -->
            <div class="staff-details card shadow-sm border-0 flex-grow-1">
                <div class="card-header bg-white border-bottom py-3 ">
                    <h5 class="mb-0 fw-semibold d-flex justify-content-between align-items-center w-100">
                        <span>Staff Details</span>
                        <div class="w-150px">
                            <input type="text" id="date_timestamp" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                        <div>
                    </h5>
                    
                </div>

                <div class="card-body staff-details-scroll" id="staff-details">
                    <div class="text-center text-muted mt-5">
                        <i class="mdi mdi-account-circle-outline fs-1"></i>
                        <p class="mt-2">Select a staff member to view details.</p>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>




<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_staff_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Staff Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form  method="POST" action="{{ route('update_staff_timestamp_report') }}" enctype="multipart/form-data" autocomplete="off" id="updateTimestampForm">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                         <input type="text" id="date_timestamp" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Timechamp data :</label>
                        <span lass="text-black mb-1 fs-6 fw-semibold "id="total_timestamp_data">0 </span>Record Found
                      
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                    <button type="button" class="btn btn-primary me-3" id="submitTimestampBtn" onclick="submit_timestamp_form()">Update Staff Timechamp</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

 <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

<script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
   
     
<script>
    function open_update_staffId(){
        loadCompanyStaff(0);
    }

// CLICK COMPANY TAB
$(document).on("click", ".company-tab", function () {
    let companyId = $(this).data("company");
    loadCompanyStaff(companyId);
});

// COMMON FUNCTION TO LOAD STAFF
function loadCompanyStaff(companyId) {

    $("#companyStaffList").html(`
        <div class="text-center py-5">
            <div class="spinner-border"></div>
            <p>Loading staff...</p>
        </div>
    `);

    $.ajax({
        url: "/get-company-staff",
        type: "GET",
        data: { company_id: companyId },
        success: function (res) {

            // RENDER STAFF TABLE HTML COMING FROM BACKEND
            $("#companyStaffList").html(res.staff_html);

            // Show Bulk Update button when list loads
            $("#bulkUpdateContainer").show();
        }
    });
}

// BULK UPDATE BUTTON CLICK
$("#bulkUpdateBtn").on("click", function () {

    let updates = [];

    $(".staff-id-input").each(function () {
        let sno = $(this).data("sno");
        let newId = $(this).val();
        updates.push({ sno: sno, staff_id: newId });
    });

    $.ajax({
        url: "/bulk-update-staff-id",
        type: "POST",
        data: {
            _token: $("meta[name='csrf-token']").attr("content"),
            updates: updates
        },
        success: function (res) {
            toastr.success("Bulk Update Successful!");
        }
    });
});

</script>

   <script>
     function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
     function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
    // Example: Add event listeners to staff list items to show their details on the right side.
    function selectStaff(item) {
        // highlight selected
        document.querySelectorAll(".staff-item").forEach(el => el.classList.remove("staff-selected"));
        document.getElementById("staff-" + item.sno).classList.add("staff-selected");
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        let date = document.getElementById("date_timestamp").value;
        var staff_id =data.timechamp_id;
        if (staff_id) {
            // Fetch and populate states based on selected country
            $.ajax({
                url: "{{ route('get_staff_daily_timestamp') }}",
                type: "GET",
                data: {
                    staff_id: staff_id,
                    date:date
                },
                success: function(response) {
                    console.log(response)
                },
                error: function(error) {
                    console.error('Error fetching report:', error);
                }
            });
        }

        if (staff_id) {
            $.ajax({
                url: "{{ route('get_staff_daily_timestamp') }}",
                type: "GET",
                data: {
                    staff_id: staff_id,
                    date: date
                },
                success: function (response) {
                    console.log(response);

                    if (response.status === true && response.data.length > 0) {
                        updateDetails(item, data, response.data[0]);  // send timestamp data
                    } else {
                        updateDetails(item, data, null); // no logs
                    }
                },
                error: function (error) {
                    console.error("Timechamp Error:", error);
                    updateDetails(item, data, null);
                }
            });
        }
        
    }
    function formatTime(timeString) {
        if (!timeString) return "00:00";

        // Convert to JS Date
        const date = new Date(timeString);

        if (isNaN(date)) return "00:00";

        let hours = date.getHours();
        let minutes = date.getMinutes().toString().padStart(2, "0");
        let seconds = date.getSeconds().toString().padStart(2, "0");

        let ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12; // 0 → 12

        return `${hours.toString().padStart(2, "0")}:${minutes}:${seconds} ${ampm}`;
    }

    function updateDetails(item, staff, logs) {

        let staff_image = '';

        if (staff.staff_image && staff.staff_image.trim() !== '') {
            if (staff.company_type == 1) {
                staff_image = `staff_images/Management/${staff.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${staff.company_id}/${staff.entity_id}/${staff.staff_image}`;
            }
        } else {
            staff_image = staff.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;

        let d = logs || {}; // fallback if no logs

        const staffDetails = document.getElementById('staff-details');

        staffDetails.innerHTML = `
            <div class="p-3">

                <!-- Profile -->
                <div class="d-flex align-items-center mb-4">
                    <img src="${staff_image}" class="staff-avatar me-3" style="width:70px;height:70px;">
                    <div>
                        <h4 class="fw-bold mb-1">${item.staff_name}</h4>
                        <span class="badge bg-primary">${item.gender == 1 ? "Male" : "Female"}</span>
                        <div class="text-muted small">Employee ID: ${staff.staff_id}</div>
                    </div>
                </div>

                <!-- Mini Cards -->
                <div class="row g-3">

                    ${miniCard("Start Time", formatTime(d.startDateTime) || "00:00")}
                    ${miniCard("Working Time", d.workingTime || "00:00:00")}
                    ${miniCard("Last Seen", formatTime(d.finishDateTime) || "—")}

                    ${miniCard("Productive Time", d.productiveTime || "00:00:00")}
                    ${miniCard("Non Productive", d.nonProductiveTime || "00:00:00")}
                    ${miniCard("Neutral Time", d.neutralTime || "00:00:00")}

                    ${miniCard("Away Time", d.awayTime || "00:00:00")}
                    ${miniCard("Online Time", d.onlineTime || "00:00:00")}
                    ${miniCard("Offline Time", d.offlineTime || "00:00:00")}
                </div>

            </div>`;
    }

    function miniCard(title, value) {
        return `
            <div class="col-md-4">
                <div class="card shadow-sm border-0 mini-card">
                    <div class="card-body">
                        <div class="fw-semibold text-black fs-6">${title}</div>
                        <div class="fw-bold fs-5 mt-2">${value}</div>
                    </div>
                </div>
            </div>
        `;
    }



    // Update `buildRow` function to call `selectStaff` on click
    function buildRow(item) {
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;

        let staff_image = '';

        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;

        return `
            <li id="staff-${item.sno}" 
                class="list-group-item staff-item"
                onclick='selectStaff(${JSON.stringify(item)})'>
                
                <div class="d-flex align-items-center">
                    <img src="${staff_image}" class="staff-avatar me-3">

                    <div>
                        <div class="fw-semibold">${item.staff_name}</div>
                        <small class="text-muted">${data.staff_id}</small>
                    </div>
                </div>
            </li>
        `;
    }

</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
 
    function loadThemes(page = 1) {
        // const perpage = document.getElementById('perpage').value;
        // const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        // const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        // const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        // const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        // const job_role_fill = document.getElementById('job_role_fill').value;
        // const division_fill = document.getElementById('division_fill').value;
        // const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_management/staff_timechamp?page=${page}&sorting_filter=&search_filter=&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=&division_fill=&job_role_fill=&dt_fill_issue_rpt=&from_dt_iss_rpt=&to_dt_iss_rpt=`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                // updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <li class="skeleton-loader" id="skeleton-loader">
                <div style="position:relative;" class="skeleton-cell">
                    <div class="skeleton"></div>
                </div>
             </li>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    // document.getElementById('search_filter').addEventListener('input', function() {
    //     const searchValue = document.getElementById('search_filter').value;
    //     if (searchValue) {
    //         document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
    //     } else {
    //         document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
    //     }
    // });

     // Listen for changes in the perpage dropdown and reload data
    // document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    // document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    // document.getElementById('refreshSearch').addEventListener('click', function() {
    //     document.getElementById('search_filter').value = '';  // Clear the search input
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    // document.getElementById('searchSubmit').addEventListener('click', function() {
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    //  document.getElementById('filterSubmit').addEventListener('click', function() {
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
</script>

<script>
    // document.addEventListener("DOMContentLoaded", function () {
    //     // Show filter div on "Add Filter"
    //     document.getElementById('filter_btn').addEventListener('click', function () {
    //         document.getElementById('filter_div').style.display = 'block';
    //     });
    // });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
 <script>
$(document).ready(function() {

    // When company changes
    $('#staff_company_name').on('change', function() {
        var companyId = $(this).val();
        var entityDropdown = $('#staff_entity_name');

        // Reset dropdown
        entityDropdown.empty().append('<option value="">Select Entity</option>');

        if (companyId) {
            $.ajax({
                url: "{{ route('entity_list') }}",
                type: "GET",
                data: { company_id: companyId },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            entityDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .attr('data-baseurl', entity.entity_base_url)
                                    .text(entity.entity_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
    });

    // When entity changes
    $('#staff_entity_name').on('change', function() {
         $('#staff_add_btn').prop('disabled', true);
         $('#staff_data_payload').val('');
         $('#total_Staff_data').text('0');
          var entityId = $(this).val();
          const verify_key='egcsecret2030datagetapierp';
         var branchDropdown = $('#staff_branch_name');
         if (entityId) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: { entity_id: entityId},
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            branchDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .text(entity.branch_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
        var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
        if (baseurl) {
            var url = baseurl + 'api/staff_data_get';
            $.ajax({
                url: url,
                type: "GET",
                data:{auth_key:verify_key},
                success: function(response) {
                    console.log('response:', response);
                    if (response.status === 200 && response.data) {
                        console.log(response.data);
                        var length=response.data.length;
                        var staffData =response.data;
                        $('#total_Staff_data').text(length+' ')
                        // TODO: handle data display or form updates here
                        if(length > 0){
                            $('#staff_add_btn').prop('disabled', false);
                            // $('#staff_data_payload').val(JSON.stringify(staffData));
                        }else{
                             $('#staff_add_btn').prop('disabled', true);
                        }
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff data:', error);
                }
            });
        }
    });

});
</script>

 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }

    
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
    if (!joinDate) return '-';

    const start = new Date(joinDate);
    const now = new Date();

    if (isNaN(start)) return '-'; // invalid date safeguard

    // Determine direction
    const isFuture = start > now;
    const earlier = isFuture ? now : start;
    const later = isFuture ? start : now;

    // Calculate raw differences
    let years = later.getFullYear() - earlier.getFullYear();
    let months = later.getMonth() - earlier.getMonth();
    let days = later.getDate() - earlier.getDate();

    // Adjust days
    if (days < 0) {
        const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
        days += prevMonth.getDate();
        months--;
    }

    // Adjust months
    if (months < 0) {
        months += 12;
        years--;
    }

    // Build result text
    let result = '';
    if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
    if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
    if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

    if (!result.trim()) result = '0 days';

        result = result.trim();

        // Add "In" or "Ago"
        if (isFuture) {
            result = `In ${result}`;
        } else if (result !== '0 days') {
            // result += ' ago';
            result += '';
        }

        return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }

</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>

<script>
     $(document).ready(function() {
            // Business dropdown
            $('#company_fill').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_fill');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
                if(countryId == 'egc'){
                    loadThemes(currentPage);
                }
            });

            // depart list
            $('#entity_fill').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#department_fill');
                if(entity_id ){
                    loadThemes(currentPage);
                }

                stateDropdown.empty().append('<option value="">Select Department</option>');

                if (entity_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }

                
            });
            // division dropdown
             $('#department_fill').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#division_fill');
                stateDropdown.empty().append('<option value="">Select Division</option>');

                let erp_depert = $(this).find(':selected').data('erpdepartmentid');
                $('#erp_department_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpdivisionid', state.erp_division_id)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
             });

              $('#division_fill').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#job_role_fill');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                let erp_depert = $(this).find(':selected').data('erpdivisionid');
                $('#erp_division_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpjobroleid', state.erp_job_role_id)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
             });

        })
</script>



@endsection
