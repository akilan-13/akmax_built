/**
 * Form Picker
 */

'use strict';

(function () {
  // Flat Picker
  // --------------------------------------------------------------------
  const slot_st_tm = document.querySelector('#slot_st_tm'),
    flatpickrDateTime = document.querySelector('#offer_start'),
    flatpickrDateTimeEnd = document.querySelector('#offer_end'),
    flatpickrDateTimeCRS = document.querySelector('#courseoffer_start'),
    flatpickrDateTimeEndCRS = document.querySelector('#courseoffer_end'),
    DateTimeCRSEdit = document.querySelector('#courseoffer_start_edit'),
    DateTimeEndCRSEdit = document.querySelector('#courseoffer_end_edit'),
    slot_ed_tm = document.querySelector('#slot_ed_tm'),
    slot_st_tm_up = document.querySelector('#slot_st_tm_up'),
    slot_ed_tm_up = document.querySelector('#slot_ed_tm_up'),
    job_st_tm = document.querySelector('#job_st_tm'),
    job_ed_tm = document.querySelector('#job_ed_tm'),
    job_st_tm_up = document.querySelector('#job_st_tm_up'),
    job_ed_tm_up = document.querySelector('#job_ed_tm_up'),
    schedule_start = document.querySelector('#schedule_start'),
    training_planner_sch_dt_add = document.querySelector('#training_planner_sch_dt_add'),
    training_planner_sch_dt_edit = document.querySelector('#training_planner_sch_dt_edit'),
    goalset_sch_month_filtr = $('#goalset_sch_month_filtr'),
    goalset_sch_month_add = $('#goalset_sch_month_add'),
    goalset_sch_month_edit = $('#goalset_sch_month_edit'),
    common_date_class = $('.common_date_class'),
    common_datepicker = $('.common_datepicker'),
    cus_date_dob = $('.cus_date_dob'),
    cus_date_doj = $('.cus_date_doj'),
    date_att_up = $('.date_att_up'),
    cus_doj = $('#cus_doj'),
    common_date_range_class = $('.common_date_range_class'),
    common_time_class = document.querySelector('.common_time_class'),
    common_timepicker = document.querySelector('.common_timepicker'),
    common_datetime_picker = document.querySelector('.common_datetime_picker'),
    app_time_class = document.querySelector('.app_time_class'),
    app_new_time_class = document.querySelector('.app_new_time_class'),
    att_time_class = document.querySelector('.att_time_class'),
    lead_create = $('#lead_create'),
    lead_dob = $('#lead_dob'),
    lead_lfd = $('#lead_lfd'),
    lead_lfd_up = $('#lead_lfd_up'),
    lead_create_up = $('#lead_create_up'),
    lead_dob_up = $('#lead_dob_up'),
    lead_apt_sch = $('#lead_apt_sch'),
    re_app_date = $('#re_app_date'),
    staff_doj = $('#staff_doj'),
    staff_create = $('#staff_create'),
    slot_base_tm = document.querySelector('#slot_base_tm'),
    slot_base_end = document.querySelector('#slot_base_end'),
    slot_base_tm_up = document.querySelector('#slot_base_tm_up'),
    slot_base_end_up = document.querySelector('#slot_base_end_up'),
    staff_dob = $('#staff_dob'),
    staff_dob_edit = $('#staff_dob_edit'),
    batch_star_date = $('#batch_star_date'),
    batch_end_date = $('#batch_end_date'),
    batch_create = $('#batch_create'),
    exam_add_crd_dt = $('#exam_add_crd_dt'),
    exam_add_st_dt = $('#exam_add_st_dt'),
    exam_add_ed_dt = $('#exam_add_ed_dt'),
    shift_st_tm = document.querySelector('#shift_st_tm'),
    shift_ed_tm = document.querySelector('#shift_ed_tm'),
    lunch_st_tm = document.querySelector('#lunch_st_tm'),
    lunch_ed_tm = document.querySelector('#lunch_ed_tm'),
    ld_appt_dt_add = document.querySelector('#ld_appt_dt_add'),
    ld_appt_dt_edit = document.querySelector('#ld_appt_dt_edit'),
    ld_appt_reappt_date = document.querySelector('#ld_appt_reappt_date'),
    course_starting = $('#course_starting'),
    ovr_month_fill = $('.month_filter_common_class');

  if (flatpickrDateTime) {
    flatpickrDateTime.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (ovr_month_fill.length) {
    ovr_month_fill.datepicker({
      format: 'M-yyyy',
      showButtonPanel: true,
      viewMode: 'months',
      minViewMode: 'months',
      todayHighlight: true,
      autoclose: true,
      orientation: isRtl ? 'left' : 'right',
      endDate: new Date()
    });
  }

  if (common_time_class) {
    common_time_class.flatpickr({
      enableTime: true,
      format: 'H:i:K',
      noCalendar: true
    });
  }

  if (common_timepicker) {
    common_timepicker.flatpickr({
      enableTime: true,
      noCalendar: true,
      dateFormat: 'h:i K',
      defaultHour: 12,
      defaultMinute: 0,
      minuteIncrement: 5
    });
  }

  if (common_datetime_picker) {
    common_datetime_picker.flatpickr({
      enableTime: true,
      dateFormat: 'd-M-Y h:i K', // e.g. 17-Jul-2025 03:45 PM
      time_24hr: false,
      altInput: true,
      altFormat: 'd-M-Y h:i K',
      defaultHour: 12,
      defaultMinute: 0
    });
  }

  if (shift_st_tm) {
    shift_st_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (shift_ed_tm) {
    shift_ed_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (lunch_st_tm) {
    lunch_st_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (lunch_ed_tm) {
    lunch_ed_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (app_time_class) {
    app_time_class.flatpickr({
      enableTime: true,
      noCalendar: true, // Only allow time selection
      format: 'H:i K', // Format for time (12-hour format with AM/PM)
      minTime: new Date(), // Set minimum time to the current time
      time_24hr: false, // Use 12-hour format (optional, set to true for 24-hour format)
      defaultDate: new Date() // Default to the current time
    });
  }
  if (app_new_time_class) {
    app_new_time_class.flatpickr({
      enableTime: true,
      noCalendar: true, // Only allow time selection
      format: 'H:i K', // Format for time (12-hour format with AM/PM)
      minTime: new Date(), // Set minimum time to the current time
      time_24hr: false, // Use 12-hour format (optional, set to true for 24-hour format)
      defaultDate: new Date() // Default to the current time
    });
  }
  if (att_time_class) {
    att_time_class.flatpickr({
      enableTime: true,
      format: 'H:i:K',
      noCalendar: true
    });
  }
  if (flatpickrDateTimeEnd) {
    flatpickrDateTimeEnd.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (flatpickrDateTimeCRS) {
    flatpickrDateTimeCRS.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (flatpickrDateTimeEndCRS) {
    flatpickrDateTimeEndCRS.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (DateTimeCRSEdit) {
    DateTimeCRSEdit.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (DateTimeEndCRSEdit) {
    DateTimeEndCRSEdit.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  // Time
  if (job_st_tm) {
    job_st_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (job_st_tm_up) {
    job_st_tm_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (common_date_range_class.length) {
    common_date_range_class.datepicker({
      todayHighlight: true,
      autoclose: true,
      locale: {
        dateFormat: 'd-M-Y'
      },
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (slot_st_tm) {
    slot_st_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_base_end) {
    slot_base_end.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_base_end_up) {
    slot_base_end_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_base_tm) {
    slot_base_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_base_tm_up) {
    slot_base_tm_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_st_tm_up) {
    slot_st_tm_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (slot_ed_tm) {
    slot_ed_tm.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (job_ed_tm) {
    job_ed_tm.flatpickr({
      enableTime: true,
      format: 'H:i:K',
      noCalendar: true
    });
  }
  if (job_ed_tm_up) {
    job_ed_tm_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }
  if (schedule_start) {
    schedule_start.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (training_planner_sch_dt_add) {
    training_planner_sch_dt_add.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (training_planner_sch_dt_edit) {
    training_planner_sch_dt_edit.flatpickr({
      enableTime: true,
      dateFormat: 'Y-m-d H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (slot_ed_tm_up) {
    slot_ed_tm_up.flatpickr({
      enableTime: true,
      noCalendar: true
    });
  }

  if (lead_create.length) {
    lead_create.datepicker({
      todayHighlight: true,
      autoclose: true,
      locale: {
        dateFormat: 'd-M-Y'
      },
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (cus_doj.length) {
    cus_doj.datepicker({
      todayHighlight: true,
      autoclose: true,
      locale: {
        dateFormat: 'd-M-Y'
      },
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (batch_star_date.length) {
    batch_star_date.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (batch_end_date.length) {
    batch_end_date.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (batch_create.length) {
    batch_create.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_dob.length) {
    lead_dob.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      endDate: '-15y'
    });
  }
  // if (lead_dob.length) {
  //   // Get today's date
  //   const today = new Date();
  //   // Calculate the minimum date (15 years ago)
  //   const minDate = new Date();
  //   minDate.setFullYear(today.getFullYear() - 15);

  //   lead_dob.datepicker({
  //     todayHighlight: true,
  //     autoclose: true,
  //     format: 'dd-M-yyyy', // Ensure this format matches your datepicker's expectations
  //     orientation: isRtl ? 'auto right' : 'auto left',
  //     endDate: today, // Restrict future dates
  //     startDate: minDate, // Restrict dates older than 15 years ago
  //     todayBtn: true,
  //     endDate: '-15y'
  //   });
  // }

  if (staff_doj.length) {
    staff_doj.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (staff_dob.length) {
    staff_dob.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      endDate: '-18y' // Set max date as 18 years ago from today
    });
  }
  // Goalset Month Picker Start
  if (goalset_sch_month_filtr.length) {
    goalset_sch_month_filtr.datepicker({
      format: 'M-yyyy',
      showButtonPanel: true,
      viewMode: 'months',
      minViewMode: 'months',
      startDate: '0m',
      todayHighlight: true,
      autoclose: true,
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (goalset_sch_month_add.length) {
    goalset_sch_month_add.datepicker({
      format: 'M-yyyy',
      showButtonPanel: true,
      viewMode: 'months',
      minViewMode: 'months',
      startDate: '0m',
      todayHighlight: true,
      autoclose: true,
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (goalset_sch_month_edit.length) {
    goalset_sch_month_edit.datepicker({
      format: 'M-yyyy',
      showButtonPanel: true,
      viewMode: 'months',
      minViewMode: 'months',
      startDate: '0m',
      todayHighlight: true,
      autoclose: true,
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  // Goalset Month Picker End
  if (common_date_class.length) {
    common_date_class.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (common_datepicker.length) {
    common_datepicker.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'dd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (cus_date_dob.length) {
    cus_date_dob.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      endDate: '-15y'
    });
  }
  if (cus_date_doj.length) {
    cus_date_doj.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      startDate: new Date()
    });
  }
  if (date_att_up.length) {
    date_att_up.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      endDate: new Date()
    });
  }

  if (staff_dob_edit.length) {
    staff_dob_edit.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left',
      endDate: '-18y' // Set max date as 18 years ago from today
    });
  }
  if (staff_create.length) {
    staff_create.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_lfd.length) {
    lead_lfd.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_create_up.length) {
    lead_create_up.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_dob_up.length) {
    lead_dob_up.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_lfd_up.length) {
    lead_lfd_up.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (lead_apt_sch.length) {
    lead_apt_sch.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (re_app_date.length) {
    re_app_date.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  // Exam Date & Time js Start

  if (exam_add_crd_dt.length) {
    exam_add_crd_dt.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (exam_add_st_dt.length) {
    exam_add_st_dt.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (exam_add_ed_dt.length) {
    exam_add_ed_dt.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  if (ld_appt_dt_add) {
    ld_appt_dt_add.flatpickr({
      enableTime: true,
      dateFormat: 'd-m-Y H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (ld_appt_dt_edit) {
    ld_appt_dt_edit.flatpickr({
      enableTime: true,
      dateFormat: 'd-m-Y H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }
  if (ld_appt_reappt_date) {
    ld_appt_reappt_date.flatpickr({
      enableTime: true,
      dateFormat: 'd-m-Y H:i',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  // Exam Date & Time js End

  // Customer Date Picker Start

  if (course_starting.length) {
    course_starting.datepicker({
      todayHighlight: true,
      autoclose: true,
      format: 'd-M-yyyy',
      orientation: isRtl ? 'auto right' : 'auto left'
    });
  }

  // Customer Date Picker End
})();
