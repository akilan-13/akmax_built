<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use PDF;
class ManagePayroll extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
    public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $closing_date_filt = $request->closing_date_filt ?? '';
        $exp_type_filt = $request->exp_type_filt ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';
        $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
        ->select('egc_job_request.*','egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_job_role.job_position_name as job_role_name',
        'egc_company.company_name',
        'egc_company.company_base_color',);
        if($search_filter != '') {
            $jobRequest->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%");
            });
        }

            if ($job_role_fill) {
            $jobRequest->where('egc_job_request.job_role_name', $job_role_fill);
            }
            if ($closing_date_filt) {
            $jobRequest->where('egc_job_request.closing_date', $closing_date_filt);
            }
            if ($exp_type_filt) {
            $jobRequest->whereJsonContains('egc_job_request.exp_type_ids', $exp_type_filt);
            }

            if ($date_filter == "today") {
                $todayDate = date("Y-m-d");
                $jobRequest->whereDate('egc_job_request.created_at', $todayDate);
            } elseif ($date_filter == "week") {
                $today = date('l');
                if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
                } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
                }
                $jobRequest->whereBetween('egc_job_request.created_at', [$weekFromDate, $weekToDate]);
            } elseif ($date_filter == "monthly") {
                $firstDayOfMonth = date('Y-m-01');
                $lastDayOfMonth = date('Y-m-t');
                $jobRequest->whereBetween('egc_job_request.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
            } elseif ($date_filter == "custom_date") {
                if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $jobRequest->whereBetween('egc_job_request.created_at', [$fromDate, $toDate]);
                } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $jobRequest->where('egc_job_request.created_at', '>=', $fromDate);
                } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $jobRequest->where('egc_job_request.created_at', '<=', $toDate);
                }
            }
            $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                    ->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $jobRequest->map(function ($item) use ($helper) {
                $applicants_count = ApplicantModel::where('job_request_id', $item->sno)
                        ->where('status', '!=', 2)
                        ->count();

                $interview_stage_count = 0;
                
                $interview_schedule = InterviewScheduleModel::where('job_request_id', $item->sno)
                    ->where('status', '!=', 2)
                    ->first();

                if ($interview_schedule) {
                    $interview_stage_count = InterviewScheduleStageModel::where(
                            'interview_schedule_id',
                            $interview_schedule->sno
                        )
                        ->where('status', '!=', 2)
                        ->count();
                }
                
                // return $interview_schedule;
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'job_role_name' => $item->job_role_name ?? '-',
                    'min_salary' => $item->min_salary,
                    'max_salary' => $item->max_salary,
                    'vacancy_count' => $item->vacancy_count,
                    'experience' => $item->experience,
                    'experience' => $item->experience,
                    'closing_date' => $item->closing_date,
                    'last_apply_date' => $item->last_apply_date,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'skill_required' => $item->skill_required,
                    'applicants_count' => $applicants_count,
                    'exp_type_ids' => $item->exp_type_ids,
                    'data' => $item,
                    'interview_schedule_status' => $interview_stage_count > 0 ? 1 : 0,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    'short_encrypt_id' => base64_encode($item->sno),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $jobRequest->currentPage(),
                'last_page' => $jobRequest->lastPage(),
                'total' => $jobRequest->total(),
            ]);
        }
        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        return view('content.hr_management.hr_general.manage_payroll.payroll_list', [
            'jobRequest' => $jobRequest,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'source_list' => $source_list,
        ]);
    }

    public function  indexNew(Request $request){

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $runs=DB::table('egc_payroll_runs')
            ->where('status',0)
            ->orderBy('sno','desc')
            ->get();
        
        return view('content.hr_management.hr_general.manage_payroll.payroll_list_new', [
           
            'runs' => $runs,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            
        ]);

    }
 public function Payslip($id,Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      
     
      return view('content.hr_management.hr_general.manage_payroll.payslip_print', [
          
      ]);
  }

public function create(Request $r)
{
    DB::table('egc_payroll_runs')
        ->insert([
        'payroll_month'=>$r->payroll_month,
        'payroll_year'=>$r->payroll_year,
        'run_status'=>'DRAFT',
        'created_by'=>$r->user()->user_id ?? 1
        ]);

    return response()->json(['status'=>true]);

}


public function process($runSno,Request $r)
{

    DB::transaction(function() use($runSno,$r){
        try{
            $run=DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->first();


            $employees=DB::table('egc_staff_payroll_profile')
            ->where('status','0')
            ->get();
            
            foreach($employees as $emp){

                $employeeSno=$emp->staff_id;
              
                // get salary structure
                $mapping=DB::table('egc_staff_salary_mapping')
                ->where('staff_id',$employeeSno)
                ->whereNull('effective_to')
                ->first();
                 
                if(!$mapping) continue;

                $components=DB::table('egc_salary_structure_components')
                ->where('salary_structure_sno',
                $mapping->salary_structure_sno)
                ->get();
                  
                $gross=0;
                $deduction=0;

                // create payroll entry

                $entryId=DB::table('egc_payroll_entries')
                            ->insertGetId([
                                'payroll_run_sno'=>$runSno,
                                'staff_id'=>$employeeSno,
                                'gross_salary'=>0,
                                'total_deductions'=>0,
                                'net_salary'=>0,
                                'created_by'=>$r->user()->user_id ?? 1
                            ]);

            // return $entryId;

                foreach($components as $c){

                    $amount=$c->value;
                    $type=DB::table('egc_pay_components')
                    ->where('sno',$c->component_sno)
                    ->value('component_type');
                    DB::table('egc_payroll_entry_components')
                        ->insert([
                            'payroll_entry_sno'=>$entryId,
                            'component_sno'=>$c->component_sno,
                            'amount'=>$amount,
                            'created_by'=>$r->user()->user_id ?? 1
                        ]);

                    if($type=='EARNING'){
                        $gross+=$amount;
                    }else{
                        $deduction+=$amount;
                    }
                
                }
                $net=$gross-$deduction;
                DB::table('egc_payroll_entries')
                    ->where('sno',$entryId)
                    ->update([
                        'gross_salary'=>$gross,
                        'total_deductions'=>$deduction,
                        'net_salary'=>$net
                    ]);
            }

            // finalize
            DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->update([
                'run_status'=>'FINALIZED'
            ]);
        }catch(\Exception $e){
            return response()->json([
                'status'=>false,
                'message'=>'Error processing payroll: '.$e->getMessage()
            ]);
        }
    });

    return response()->json([
    'status'=>true,
    'message'=>'Payroll processed successfully'
    ]);

}


public function indexPayslip()
{

    $payslips=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'e.sno',
            'emp.staff_name as employee_name',
            'emp.staff_id as employee_code',
            'r.payroll_month',
            'r.payroll_year',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary'
        )
        ->get();

    return view('content.hr_management.hr_general.manage_payroll.payslips',compact('payslips'));
}


public function viewpayslip ($entrySno)
{

    $data=$this->getPayslipData($entrySno);

    return view('content.hr_management.hr_general.manage_payroll.payslip_view',$data);

}


public function pdfpayslip($entrySno,Request $r)
{

    $data=$this->getPayslipData($entrySno);

    $pdf=PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_pdf',$data);

    DB::table('egc_payslip_logs')
    ->insert([
    'payroll_entry_sno'=>$entrySno,
    'generated_at'=>now(),
    'generated_by'=>$r->user()->user_id ?? 1
    ]);

    return $pdf->download('payslip.pdf');

}


private function getPayslipData($entrySno)
{

    $entry=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','emp.sno')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'emp.staff_name as name',
            'emp.staff_id as employee_code',
            'b.bank_account_no',
            'b.bank_name',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary',
            'r.payroll_month',
            'r.payroll_year'
        )
        ->where('e.sno',$entrySno)
        ->first();


    $components=DB::table('egc_payroll_entry_components as c')
        ->leftJoin('egc_pay_components as p',
        'p.sno','=','c.component_sno')
        ->select(
            'p.component_name',
            'p.component_type',
            'c.amount'
        )
        ->where('c.payroll_entry_sno',$entrySno)
        ->get();

    return [
        'entry'=>$entry,
        'components'=>$components
    ];

}


public function getPreviewData(Request $request)
{

$month = $request->month;
$year = $request->year;
 $helper = new \App\Helpers\Helpers();
$pfPercentage = $helper->payroll_setting('pf_percentage');
$esiPercentage = $helper->payroll_setting('esi_percentage');
$esiLimit = $helper->payroll_setting('esi_salary_limit');

$staff = DB::table('egc_staff as s')

->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){

$join->on('a.staff_id','=','s.sno')
->whereMonth('a.date',$month)
->whereYear('a.date',$year)
->where('a.status',0);

})

->where('s.status',0)

->select(

's.sno',
's.staff_name as name',
's.staff_id as staff_code',
's.basic_salary',
's.per_day_salary',
's.casual_leave_count_per_month',
DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),

DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),

DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),

DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
// DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

// DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")

)

->groupBy('s.sno','s.staff_id','s.staff_name','s.basic_salary','s.per_day_salary','s.casual_leave_count_per_month',)

->get();




$data = [];

foreach($staff as $row)
{

$absentDays = $row->absent_days ?? 0;

$lateCount = DB::table('egc_staff_attendance')

->where('staff_id',$row->sno)

->whereMonth('date',$month)
->whereYear('date',$year)

->where('status',0)

->whereNotNull('in_time')

->whereTime('in_time','>','09:30:00')

->count();

$allowedLeave = $row->casual_leave_count_per_month ?? 0;
$lateAllowed = $helper->payroll_setting('late_allowed_per_month');
$lopPerLate = $helper->payroll_setting('lop_per_late');
// $lopDays = max(0,$absent - $allowedLeave);

// absent LOP
$absentLopDays = max(0, $absentDays - $allowedLeave);


// late LOP
$extraLate = max(0, $lateCount - $lateAllowed);

$lateLopDays = $extraLate * $lopPerLate;


// total LOP
$totalLopDays = $absentLopDays + $lateLopDays;


// LOP amount
$lopAmount = $totalLopDays * $row->per_day_salary;

// $lopAmount = $lopDays * $row->per_day_salary;

$pfAmount = ($row->basic_salary * $pfPercentage)/100;

$esiAmount = 0;



if($row->basic_salary <= $esiLimit)
$esiAmount = ($row->basic_salary * $esiPercentage)/100;

$netSalary = $row->basic_salary - ($lopAmount + $pfAmount + $esiAmount);

$entry = DB::table('egc_payroll_entries')
->where('staff_id',$row->sno)
->whereMonth('created_at',$month)
->whereYear('created_at',$year)
->first();

$isSaved = $entry ? true : false;

$entryId = $entry->sno ?? null;

$data[] = [

'staff_id'=>$row->sno,
'name'=>$row->name,
'staff_code'=>$row->staff_code,

'basic_salary'=>$row->basic_salary,

'present_days'=>$row->present_days ?? 0,

'absent_days'=>$absentDays,

'leave_days'=>$row->leave_days ?? 0,

'permission_days'=>$row->permission_days ?? 0,

'onduty_days'=>$row->onduty_days ?? 0,

'late_count'=>$lateCount,

'lop_days'=>$totalLopDays,

'lop_amount'=>$lopAmount,

'pf_amount'=>$pfAmount,

'esi_amount'=>$esiAmount,

'is_saved'=>$isSaved,
'entry_id'=>$entryId,

'net_salary'=>$netSalary

];

}

return response()->json($data);

}

public function savePayroll(Request $request)
{

$month = $request->month;
$year = $request->year;


// prevent duplicate save

$exists = DB::table('egc_payroll_runs')

->where('payroll_month',$month)
->where('payroll_year',$year)
->where('status',0)
->exists();

if($exists)
{

return response()->json([
'status'=>false,
'message'=>'Payroll already saved for this month'
]);

}


DB::beginTransaction();

try {


// create payroll run

$runId = DB::table('egc_payroll_runs')

->insertGetId([

'payroll_month'=>$month,
'payroll_year'=>$year,
'run_type'=>'MANUAL',
'created_by'=>auth()->id()

]);


// get preview data using same logic

$preview = $this->getPreviewData($request)->getData();


foreach($preview as $row)
{


$entryId = DB::table('egc_payroll_entries')

->insertGetId([

'payroll_run_sno'=>$runId,

'staff_id'=>$row->staff_id,

'basic_salary'=>$row->basic_salary,

'per_day_salary'=>$row->basic_salary,

'present_days'=>$row->present_days,

'absent_days'=>$row->absent_days,

'allowed_leave'=>0,

'lop_days'=>$row->lop_days,

'lop_amount'=>$row->lop_amount,

'pf_amount'=>$row->pf_amount,

'esi_amount'=>$row->esi_amount,

'incentive_amount'=>0,

'net_salary'=>$row->net_salary,

'created_by'=>auth()->id()

]);


// save components

DB::table('egc_payroll_entry_components')

->insert([

[
'payroll_entry_sno'=>$entryId,
'component_name'=>'Basic Salary',
'component_type'=>'EARNING',
'amount'=>$row->basic_salary
],

[
'payroll_entry_sno'=>$entryId,
'component_name'=>'LOP',
'component_type'=>'DEDUCTION',
'amount'=>$row->lop_amount
],

[
'payroll_entry_sno'=>$entryId,
'component_name'=>'PF',
'component_type'=>'DEDUCTION',
'amount'=>$row->pf_amount
],

[
'payroll_entry_sno'=>$entryId,
'component_name'=>'ESI',
'component_type'=>'DEDUCTION',
'amount'=>$row->esi_amount
]

]);

}


DB::commit();

return response()->json([
'status'=>true,
'message'=>'Payroll saved successfully'
]);

}
catch(\Exception $e)
{

DB::rollBack();

return response()->json([
'status'=>false,
'message'=>$e->getMessage()
]);

}

}

}
