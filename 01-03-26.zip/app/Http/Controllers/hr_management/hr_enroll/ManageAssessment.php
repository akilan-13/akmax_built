<?php

namespace App\Http\Controllers\exam_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ExamQuestionsModel;
use App\Models\QuestionBankModel;
use App\Models\ManageExamModel;
use App\Models\StaffExamPointsModel;
use App\Models\ProctoringModel;
use App\Models\EstplStudentsModel;
use Carbon\Carbon;
use App\Models\ExamProcessModel;
use App\Models\ExamStaffBadgeModel;
use Illuminate\Support\Facades\Http;
use App\Models\WhatsappApiConfigureModel;
use PDF;
use Illuminate\Support\Facades\DB;



class ManageAssessment extends Controller
{


    public function index(Request $request)
    {
        $page        = $request->input('page', 1);
        $perpage     = (int) $request->input('sorting_filter', 25);
        $search_fill = $request->search_fill ?? '';

        // return $search_fill;

        
        $student = $this->getStudent($request);

        if (!$student) {
            return redirect()->route('assessment_login')
                ->with('error', 'Unauthorized access');
        }

        $branch_id = $student->branch_id;
        $user_id   = $student->id; // student id
         
        // return $student;

        // Fetch batch details
        $user_details = DB::table('students')
            ->join('estpl_batch','estpl_batch.sno','=','students.batch_id')
            ->where('id', $user_id)
            ->select('students.*','estpl_batch.starting_date')
            ->first();

        // return $user_details;

        // Fetch exam guidelines
        $guide_line = DB::table('estpl_exam_guidelines')
            ->where('sno', 1)
            ->first();

        // ================= ATTEMPT COUNT SUBQUERY =================
        $attemptedSubQuery = DB::table('estpl_exam_process')
            ->selectRaw('exam_id, COUNT(*) as attempted_count')
            ->where('staff_id', $user_id)
            ->whereIn('status', [1, 2])
            ->groupBy('exam_id');

        // ================= MAIN QUERY =================
        $user_exam = DB::table('estpl_manage_exam')
            ->where('estpl_manage_exam.status', 0)
            ->where('estpl_manage_exam.branch_id', $branch_id)
            ->where('estpl_manage_exam.branch_id', $branch_id)

            ->whereJsonContains('estpl_manage_exam.role_id', (string) $user_details->batch_id)
            ->leftJoin('estpl_exam_schedule', 'estpl_exam_schedule.sno', '=', 'estpl_manage_exam.schedule_id')
            ->leftJoinSub($attemptedSubQuery, 'attempts', function ($join) {
                $join->on('attempts.exam_id', '=', 'estpl_manage_exam.sno');
            })
            ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
            ->leftJoin('estpl_exam_category', 'estpl_exam_category.sno', '=', 'estpl_exam_badge.exam_cat_id')
            ->select(
                'estpl_manage_exam.*',
                'estpl_exam_schedule.duration as sch_duration',
                'estpl_exam_schedule.unit',
                'estpl_exam_badge.badge_name',
                'estpl_exam_badge.badge_image',
                'estpl_exam_category.category_name as badge_cat',
                DB::raw('IFNULL(attempts.attempted_count, 0) as attempted_count')
            );

        // ================= SEARCH =================
        if (!empty($search_fill)) {
            $user_exam->where('estpl_manage_exam.exam_name', 'LIKE', "%{$search_fill}%");
        }

        // ================= PAGINATION =================
        $lists = $user_exam
            ->orderBy('estpl_manage_exam.level_id', 'ASC')
            ->paginate($perpage);

        // ================= LAST PROCESS (kept same logic) =================
        foreach ($lists as $list) {
            $list->last_process_data = DB::table('estpl_exam_process')
                ->where('exam_id', $list->sno)
                ->where('staff_id', $user_id)
                ->orderBy('sno', 'DESC')
                ->first();
        }

        return view('content.exam_management.manage_assessments.list', [
            'lists'        => $lists,
            'perpage'      => $perpage,
            'user_details' => $user_details,
            'guide_line'   => $guide_line,
            'search_fill'  => $search_fill,
            'user_id'=>$user_id,
            'student'=>$student
        ]);
    }

    public function exam_log(Request $request,$student,$id)
    {
        $user_id = $student;
        // return $id;

        // Fetch exam process data for the given exam and staff
        $data = DB::table('estpl_exam_process')
            ->where('estpl_exam_process.exam_id', $id)
            ->where('estpl_exam_process.staff_id', $user_id)
            ->where('estpl_exam_process.status', 2)
            ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
            ->select('estpl_exam_process.*', 'students.username as staff_name')
            ->get();

        // Retrieve the exam details (make sure it exists)
        $exam_name = DB::table('estpl_manage_exam')
            ->where('sno', $id)
            ->where('status', 0)
            ->first();

        // If the exam is not found, return an error response
        if (!$exam_name) {
            return response([
                'status' => 404,
                'message' => 'Exam not found or inactive.',
                'error_msg' => 'No exam data available.',
                'data' => [],
                'exam_name' => null
            ], 404);
        }

        // Retrieve exam properties
        $positiveMarks = $exam_name->positive_mark;
        $negativeMarks = $exam_name->negative_mark;
        $totalQuestions = $exam_name->question_count;
        $passMark = $exam_name->pass_mark;
        $exam_duration_in_seconds = $exam_name->duration * 60; // duration in seconds

        // Process each exam record for the user
        foreach ($data as $d) {
            // Check if there's an attended duration available
            if (!empty($d->total_attended_duration)) {

                // Decode the answers data
                $answers = json_decode($d->exam_question_answers_datas, true);

                // Check if answers data is valid
                if (!$answers) {
                    $d->total_attended_duration = 'Invalid Answers Data';
                    continue;
                }

                // Count correct and incorrect answers
                $correctCount = collect($answers)->where('correctness', 'correct')->count();
                $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();

                // Calculate total marks possible and marks scored
                $totalMarks = $positiveMarks * $totalQuestions;
                $marksScored = ($positiveMarks * $correctCount) - ($negativeMarks * $incorrectCount);

                // Ensure marksScored doesn't go below 0
                $marksScored = max(0, $marksScored);

                // Check if exam is passed
                $d->isPassed = $marksScored >= $passMark;

                // Calculate remaining time
                $attendedDuration = $d->total_attended_duration;

                // Check if the duration is in correct format (HH:MM:SS)
                if (preg_match('/^(\d+):(\d+):(\d+)$/', $attendedDuration, $matches)) {
                    $hours = $matches[1];
                    $minutes = $matches[2];
                    $seconds = $matches[3];

                    // Convert attended time to seconds
                    $attendedDurationInSeconds = $hours * 3600 + $minutes * 60 + $seconds;
                } else {
                    $attendedDurationInSeconds = 0;  // If the format is invalid, set it to 0
                }

                // Calculate the remaining time in seconds
                $remainingDurationInSeconds = $exam_duration_in_seconds - $attendedDurationInSeconds;

                // If time is still remaining
                if ($remainingDurationInSeconds > 0) {
                    $remainingMinutes = floor($remainingDurationInSeconds / 60);
                    $remainingSeconds = $remainingDurationInSeconds % 60;

                    $remainingTime = $remainingMinutes . ' Mins';
                    if ($remainingSeconds > 0) {
                        $remainingTime .= ' ' . $remainingSeconds . ' Sec';
                    }
                } else {
                    // If no time is remaining, mark as completed
                    $remainingTime = '<span class="text-danger"> In Completed</span>';
                }

                // Update the attended duration with the remaining time
                $d->total_attended_duration = $remainingTime;
            } else {
                // If no attended duration, set as unavailable
                $d->total_attended_duration = 'No Duration Available';
            }
        }

        // Return the data along with exam name
        return response([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'error_msg' => null,
            'data' => $data,
            'exam_name' => $exam_name->exam_name // Assuming 'exam_name' is the column you want to return
        ], 200);
    }

    public function write_exam(Request $request, $student, $exam)
    {
        
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($exam, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;
        // return $id;


        $student = $this->getStudentfull($request);

        // return $student;

        if (!$student) {
            return redirect()->route('assessment_login')
                ->with('error', 'Unauthorized access');
        }

        $branch_id = $student->branch_id;
        $user_id   = $student->id; // student id

  
         
        // $user_details = DB::table('estpl_batch')
        //     ->select(
        //         'estpl_batch.*',
        //         'estpl_beneficiary.image',
        //         'estpl_beneficiary.name as ben_name',
        //         'estpl_beneficiary.gender',

        //     )
        //     ->where('estpl_batch.branch_id', $branch_id)
        //     ->where('estpl_batch.status',0)
        //     ->leftJoin('estpl_batch_training', 'estpl_batch_training.batch_id', '=', 'estpl_batch.sno')
        //     ->leftJoin('estpl_beneficiary', 'estpl_batch_training.beneficiary_id', '=', 'estpl_beneficiary.sno')
        //     ->first();
        $user_details = DB::table('students')
            ->select(
                'students.*',
                'estpl_batch.batch_name',
                'estpl_batch.sno',
                'estpl_beneficiary.image',
                'estpl_beneficiary.gender',

            )
            ->leftJoin('estpl_batch', 'estpl_batch.sno', '=', 'students.batch_id')
            ->leftJoin('estpl_beneficiary', 'estpl_beneficiary.sno', '=', 'students.beneficiary_id')
            ->where('students.id', $user_id)
            ->first();

        // return $user_details;

        // return $user_details;
        $user_exam = DB::table('estpl_manage_exam')
            ->where('estpl_manage_exam.status', 0)
            ->whereJsonContains('estpl_manage_exam.role_id', (string)$user_details->sno) // JSON array match
            ->where('estpl_manage_exam.sno', $id)
            ->select(
                'estpl_manage_exam.*',
                'estpl_exam_schedule.duration as sch_duration',
                'estpl_exam_schedule.unit'
            )
            ->leftJoin('estpl_exam_schedule', 'estpl_exam_schedule.sno', '=', 'estpl_manage_exam.schedule_id')
            ->first();

        // return $decryptedValue;

        $questions = json_decode($user_exam->question_ids ?? '[]', true);

        if (is_array($questions) && !empty($questions)) {
            // Shuffle if question_generate is 0
            if ($user_exam->question_generate == 0) {
                shuffle($questions);
            }

            // Make sure IDs are integers
            $question_ids = array_map('intval', $questions);

            $question_list = DB::table('estpl_exam_questions')
                ->whereIn('sno', $question_ids)
                ->orderByRaw('FIELD(sno, ' . implode(',', $question_ids) . ')')
                ->get();
        } else {
            // Empty question list
            $question_list = collect();
        }
        // return $questions;


        // Fetch the questions from the database, preserving the shuffled order using `ORDER BY FIELD()`
        $question_list = DB::table('estpl_exam_questions')
            ->whereIn('sno', $questions)
            ->orderByRaw('FIELD(sno, ' . implode(',', $questions) . ')') // Order by the shuffled question IDs
            ->get();

        $examProcess = ExamProcessModel::where('exam_id', $id)
            ->where('staff_id', $user_id)
            ->where('branch_id', $branch_id)
            ->where('status', '!=', 2)
            ->first();

        // return $examProcess;

        $attempted_count = ExamProcessModel::where('exam_id', $id)
            ->where('staff_id', $user_id)
            ->where('branch_id', $branch_id)
            ->where('status', 2)
            ->count();

        // return $examProcess;

        // Check if $examProcess is not null before accessing its property
        if ($examProcess && isset($examProcess->exam_question_answers_datas)) {
            // If the field is already an array, use it directly
            $savedAnswers = is_array($examProcess->exam_question_answers_datas) ? $examProcess->exam_question_answers_datas : [];
        } else {
            // Handle the case where no exam process is found or the field is empty
            $savedAnswers = [];
        }
        // Count the number of saved answers
        $countsaved = count($savedAnswers) ?? 0;
        $countnext = $countsaved + 1;  // Set the next question index
        // return $savedAnswers;


        return view('content.exam_management.manage_assessments.write_exam', [
            'exam' => $user_exam,
            'user_details' => $user_details,
            'question_list' => $question_list,
            'examProcess' => $examProcess,
            'savedAnswers' => $savedAnswers,
            'countsaved' => $countsaved,
            'attempted_count' => $attempted_count,
            'countnext' => $countnext,
            'user_id'=>$user_id
        ]);
    }

    public function saveAnswer(Request $request)
    {
        // return $request;
       $branch_id = $request->branch_id;
       $user_id = $request->userid;

      

        $examModel = ManageExamModel::where('sno', $request->exam_id)->first();

        // Ensure exam process exists
        $examProcess = ExamProcessModel::where('exam_id', $request->exam_id)
            ->where('staff_id', $user_id)
            ->where('status', '!=', 2)
            ->first();

        if (!$examProcess) {
            $examProcess = ExamProcessModel::create([
                'exam_id' => $request->exam_id,
                'staff_id' => $user_id,
                'exam_process_id' => uniqid(),
                'branch_id' => $examModel->branch_id,
                'total_marks' => $examModel->pass_mark,
                'staff_marks' => 0,
                'attempted_not_count' => 0,
                'total_attended_duration' => 0,
                'status' => 1,
                'exam_question_answers_datas' => [],
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
        }

        $answers = $examProcess->exam_question_answers_datas ?? [];

        $question = ExamQuestionsModel::find($request->question_id);
        if (!$question) {
            return response()->json(['error' => 'Question not found'], 404);
        }

        // Normalize submitted answer: always array for checkboxes
        $submittedAnswer = $request->answer_data['answer'];
        if ($question->option_type == 1 && !is_array($submittedAnswer)) {
            $submittedAnswer = [$submittedAnswer];
        }

        $index = array_search($request->question_id, array_column($answers, 'question_id'));

        $entry = [
            'question_id' => $request->question_id,
            'answer' => $submittedAnswer,
            'time_spent' => $request->answer_data['time_spent'],
            'correctness' => $this->checkAnswer($request->question_id, $submittedAnswer),
        ];

        if ($index === false) {
            $answers[] = $entry;
        } else {
            $answers[$index] = $entry;
        }

        // Count correct and skipped answers
        $correctCount = 0;
        $skipCount = 0;

        foreach ($answers as $ans) {
            $submitted = $ans['answer'];

            // Normalize: if checkbox, ensure array
            if (is_array($submitted)) {
                // Skip only if no real answer selected
                $isSkipped = count(array_filter($submitted, fn($val) => $val !== null && $val !== '')) === 0;
            } else {
                $isSkipped = $submitted === null || $submitted === '';
            }

            if ($isSkipped) $skipCount++;
            if ($ans['correctness'] === 'correct') $correctCount++;
        }


        $examProcess->staff_marks = $correctCount * $examModel->positive_mark;
        $notAttempt = $examModel->question_count - count($answers);
        $examProcess->attempted_not_count = $notAttempt + $skipCount;
        $examProcess->total_marks = $examModel->question_count * $examModel->positive_mark;


        // $examProcess->total_attended_duration = array_reduce(
        //     $answers,
        //     fn($carry, $item) => $carry + $item['time_spent'],
        //     0
        // );


        // Mark exam completed if all questions attempted
        // if (count($answers) == $examModel->question_count) {
        //     $examProcess->status = 2;
        // }

        $examProcess->exam_question_answers_datas = $answers;
        $examProcess->save();

        return response()->json(['message' => 'Answer and time saved successfully', 'Exam_process' => $examProcess]);
    }

    public function checkAnswer($questionId, $answer)
    {
        $question = ExamQuestionsModel::find($questionId);
        if (!$question) return 'incorrect';

        $correctAnswerArray = json_decode($question->option_answer, true); // ["1","2"]
        if (!$correctAnswerArray || count($correctAnswerArray) == 0) return 'incorrect';

        // normalize submitted answer to array of strings
        $submitted = is_array($answer) ? array_map('strval', $answer) : [strval($answer)];
        $correct = array_map('strval', $correctAnswerArray);

        sort($submitted);
        sort($correct);

        return ($submitted === $correct) ? 'correct' : 'incorrect';
    }

    public function TimeOut(Request $request)
    {
        // Retrieve the user information and request parameters
        $branch_id = $request->branch_id;
       $user_id = $request->user_id;

        $process_id = $request->process_id; // Ensure that 'process_id' exists in the request
        $exam_id = $request->exam_id; // Ensure that 'exam_id' exists in the request

        // Validate that the required parameters are present
        if (!$process_id || !$exam_id) {
            return response()->json(['error' => 'Process ID and Exam ID are required.'], 400);
        }

        // Try to find the process record first
        $exam_process = DB::table('estpl_exam_process')->where('sno', $process_id)->first();

        // If no process found, return an error response
        if (!$exam_process) {
            return response()->json(['error' => 'Process not found.'], 404);
        }

        // Update the ExamProcess record status to 2 (timeout)
        $updated = DB::table('estpl_exam_process')
            ->where('sno', $process_id)
            ->update([
                'status' => 2, // Timeout status
                'completed_date' => now()
            ]);

        // Check if the update was successful
        if ($updated) {
            return response()->json(['message' => 'Time out successfully']);
        }

        // In case update failed, return a generic error response
        return response()->json(['error' => 'Failed to update exam process. Please try again later.'], 500);
    }

    public function ExamTimeSave(Request $request)
    {
        // Validate the incoming request parameters


       $branch_id = $request->branch_id;
       $user_id = $request->user_id;

        $process_id = $request->process_id;  // Process ID from request
        $exam_id = $request->exam_id;  // Exam ID from request
        $time = $request->balance_time;  // Time left in seconds

        // Update the ExamProcess record using the query builder
        $updated = DB::table('estpl_exam_process')
            ->where('sno', $process_id)
            ->update([
                'total_attended_duration' => $time,
            ]);

        // Check if the record was updated successfully
        if ($updated) {
            // Return a successful response
            return response()->json(['message' => 'Time saved successfully']);
        } else {
            // Return an error response if the record was not found or not updated
            return response()->json(['message' => 'Exam process not found or no changes made'], 404);
        }
    }

    public function getQuestionStatuses(Request $request)
    {
        $student = $this->getStudentfull($request);
        if (!$student) {
            return redirect()->route('assessment_login');
        }

        $branch_id = $student->branch_id;
        $user_id   = $student->sno; // student id
        $process_id = $request->sno;
        $savedAnswers = $request->input('savedAnswers', []);

        if ($process_id == 0) {
            $examQuestions = ExamProcessModel::where('staff_id', $user_id)->where('status', '!=', 2)->get();
        } else {
            $examQuestions = ExamProcessModel::where('staff_id', $user_id)->where('sno', $process_id)->where('status', '!=', 2)->get();
        }

        $questionStatuses = [];
        $questionindex = [];
        $attemptedCount = 0;
        $notAttemptedCount = 0;

        foreach ($examQuestions as $question) {
            $answersData = $question->exam_question_answers_datas ?? [];

            foreach ($answersData as $i => $answerData) {
                $questionId = (string)$answerData['question_id'];
                $questionindex[$i] = $i;
                $submittedAnswer = $answerData['answer'] ?? null;

                // Determine if answered
                if (is_array($submittedAnswer)) {
                    $isAnswered = count(array_filter($submittedAnswer, fn($val) => $val !== null && $val !== '')) > 0;
                } else {
                    $isAnswered = $submittedAnswer !== null && $submittedAnswer !== '';
                }

                if ($isAnswered) {
                    $questionStatuses[$questionId] = 'attempted';
                    $attemptedCount++;
                } else {
                    $questionStatuses[$questionId] = 'not_attempted';
                    $notAttemptedCount++;
                }
            }
        }

        $countsaved = count($questionStatuses);

        return response()->json([
            'questionStatuses' => $questionStatuses,
            'countsaved' => $countsaved,
            'questionindex' => $questionindex,
            'attemptedCount' => $attemptedCount,
            'notAttemptedCount' => $notAttemptedCount,
        ]);
    }

    public function view_result(Request $request, $student, $exam)
    {
        // return $request;
        $student = $this->getStudentfull($request);

        // return $student;

        if (!$student) {
            return redirect()->route('assessment_login')
                ->with('error', 'Unauthorized access');
        }

        $branch_id = $student->branch_id;
        $batch_id = $student->batch_id;
        $user_id   = $student->id; // student id


        // return $batch_id;
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($exam, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;

        // Fetch exam details
        $edit = DB::table('estpl_manage_exam')
            ->select(
                'estpl_manage_exam.*',
                'estpl_exam_badge.badge_image',
                'estpl_exam_badge.prize_id',
                'estpl_exam_badge.gift',
                'estpl_exam_badge.points',
                'estpl_exam_badge.promotion_id',
             
            )
            ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
            ->where('estpl_manage_exam.sno', $id)
            ->first();

        // return $edit;

        if ($edit) {
            // Fetch the role data
            $roleData = DB::table('estpl_batch')->where('sno', $batch_id)->first();
            if ($roleData) {
                $edit->role_name = $roleData->batch_name;
            } else {
                $edit->role_name = 'Unknown'; // In case no role data is found
            }
        }

        // Fetch exam process details
        $process = DB::table('estpl_exam_process')
            ->select(
                'estpl_exam_process.*',
                'students.username',
                'estpl_beneficiary.image',
                'estpl_batch.batch_name',
               
            )
            ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
            ->leftJoin('estpl_batch', 'estpl_batch.sno', '=', 'students.batch_id')
            ->leftJoin('estpl_beneficiary', 'estpl_beneficiary.sno', '=', 'students.beneficiary_id')
            ->where('estpl_exam_process.exam_id', $edit->sno)
            ->where('estpl_exam_process.status', 2)
            ->where('estpl_exam_process.staff_id', $user_id)
            ->get();

        $processUser = $process->first();


        // return $process;

        $answersMap = [];
        foreach ($process as $p) {
            $answers = json_decode($p->exam_question_answers_datas, true);

            $answersMap = [];
            if (is_array($answers)) {
                foreach ($answers as $answer) {
                    if (isset($answer['question_id'])) {
                        $answersMap[$answer['question_id']] = $answer;
                    }
                }
            }

            // Get all question_ids
            $questionIds = array_keys($answersMap);

            // Fetch questions based on these question_ids
            $questions = DB::table('estpl_exam_questions')
                ->select(
                    'estpl_exam_questions.sno as question_id',
                    'estpl_exam_section.section_name'
                )
                ->leftJoin('estpl_exam_section', 'estpl_exam_section.sno', '=', 'estpl_exam_questions.section_id')
                ->whereIn('estpl_exam_questions.sno', $questionIds)
                ->get();

            // Group by section & count total and correct answers
            $sectionStats = [];
            foreach ($questions as $q) {
                $sectionName = $q->section_name ?? 'Unknown';

                // Initialize the section data if it doesn't exist
                if (!isset($sectionStats[$sectionName])) {
                    $sectionStats[$sectionName] = [
                        'section_name' => $sectionName,
                        'question_count' => 0,
                        'correct_count' => 0,
                    ];
                }

                // Increment the question count for the section
                $sectionStats[$sectionName]['question_count']++;

                // Check if the answer for this question is correct
                if (
                    isset($answersMap[$q->question_id]) &&
                    $answersMap[$q->question_id]['correctness'] === 'correct'
                ) {
                    $sectionStats[$sectionName]['correct_count']++;
                }
            }

            // Attach the section data to the process item
            $p->section_data = array_values($sectionStats);
        }


        $sections = [];
        foreach ($questionIds as $question) {
            $section = DB::table('estpl_exam_questions')
                ->select(
                    'estpl_question_bank.bank_name',
                    'estpl_exam_section.section_name',
                    'estpl_exam_questions.*',
                )
                ->leftJoin('estpl_question_bank', 'estpl_question_bank.sno', '=', 'estpl_exam_questions.bank_id')
                ->leftJoin('estpl_exam_section', 'estpl_exam_section.sno', '=', 'estpl_exam_questions.section_id')
                ->where('estpl_exam_questions.sno', $question)
                ->first();

            $sections[$question] = $section;
        }

        // Return the view with the data
        return view('content.exam_management.manage_assessments.view_result', [
            'view' => $edit,
            'id' => $decryptedValue,
            'process' => $process,
            'processUser'=>$processUser,
            'user_id'=>$user_id,
            'branch_id'=>$branch_id,
            'sections' => $sections,
            'answersMap' => $answersMap,
            'section_data' => $sectionStats,  // Corrected this part
        ]);
    }

    public function NextSchudule(Request $request)
    {
        // Validate the incoming data
        $validated = $request->validate([
            'process_id' => 'required|integer|exists:estpl_exam_process,sno',
            'date' => 'required|date'
        ]);

        // Find the record by the process_id (sno)
        $examProcess = ExamProcessModel::find($validated['process_id']);

        if ($examProcess) {
            // Update the next_schedule field with the new date
            $examProcess->next_schedule = date('Y-m-d', strtotime($validated['date']));
            $examProcess->save();

            // Return success response
            return response()->json([
                'success' => true,
                'message' => 'Schedule updated successfully!'
            ]);
        } else {
            // If process_id does not exist
            return response()->json([
                'success' => false,
                'message' => 'Process ID not found.'
            ], 404);
        }
    }

    public function BadgeClaim(Request $request)
    {

        // Validate the incoming data
        $validated = $request->validate([
            'badge_id' => 'required|integer', // Assume badge_id is valid and used for validation
            'process_id' => 'required|integer|exists:estpl_exam_process,sno'
        ]);

        $branch_id = $request->branch_id;
        $user_id = $request->user_id;

        // Find the record by the process_id (sno)
        $examProcess = ExamProcessModel::find($validated['process_id']);

        if ($examProcess) {
            // Update the badge_claim field to 1
            $examProcess->pass_fail = 1;
            $examProcess->badge_claim = 1;
            $examProcess->save();

            $badge = new ExamStaffBadgeModel();

            $badge->branch_id = $branch_id;
            $badge->staff_id  = $examProcess->staff_id;
            $badge->exam_id   = $examProcess->exam_id;
            $badge->pin_sts   = 1;
            $badge->created_by = $user_id;
            $badge->updated_by = $user_id;

            $badge->save();

            $exam_data = DB::table('estpl_manage_exam')->where('sno', $examProcess->exam_id)->first();

            if ($exam_data) {
                if ($exam_data->badge_check) {
                    $badge_data = DB::table('estpl_exam_badge')->where('sno', $exam_data->badge)->first();
                    // 🧩 Save or update staff exam points
                    StaffExamPointsModel::updateOrCreate(
                        [
                            'staff_id' => $user_id,
                            'exam_id'  => $exam_data->sno,
                            'created_at' => now(),
                            'created_by' => $user_id,
                        ],
                        [
                            'badge_id'     => $badge_data->sno ?? 0,
                            'points'     => $badge_data->points ?? 0,
                            'gift'       => $badge_data->gift ?? null,
                            'promotion_id'     => $badge_data->promotion_id ?? null,
                            'updated_at' => now(),
                            'updated_by' => $user_id,
                        ]
                    );
                }
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => 'Badge claimed successfully!'
            ]);
        } else {
            // If process_id does not exist
            return response()->json([
                'success' => false,
                'message' => 'Process ID not found.'
            ], 404);
        }
    }

    public function encrypt_ids(Request $request)
    {
        // Get the values sent from JavaScript
        $values = $request->input('values');
        // Encrypt the combined values
        $helper = new \App\Helpers\Helpers();
        $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');
        // Return the encrypted value as JSON
        return response()->json($encrypted_values);
    }

    public function assesment_certificate($eid, Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        try {
            $decryptedValue = $helper->encrypt_decrypt($eid, 'decrypt');

            if ($decryptedValue === false) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }

            // Split the decrypted string into parts with validation
            $parts = explode('~', $decryptedValue);
            if (count($parts) < 3) {
                return redirect()->back()->with('error', 'Invalid certificate data');
            }

            list($id, $user_id, $process_sno) = $parts;

            // Validate IDs are numeric
            if (!is_numeric($id) || !is_numeric($user_id) || !is_numeric($process_sno)) {
                return redirect()->back()->with('error', 'Invalid certificate parameters');
            }

            // Fetch staff data
            $staff = DB::table('students')->join('estpl_beneficiary','estpl_beneficiary.sno','=','students.beneficiary_id')->where('id', $user_id)->select('students.*','estpl_beneficiary.image')->first();
            if (!$staff) {
                return redirect()->back()->with('error', 'Staff not found');
            }

            // Fetch exam data with proper joins
            $exam = DB::table('estpl_manage_exam')
                ->select(
                    'estpl_manage_exam.*',
                    'estpl_exam_badge.badge_image',
                    'estpl_exam_badge.prize_id',
                    'estpl_exam_badge.gift',
                    'estpl_exam_badge.points',
                    'estpl_exam_badge.promotion_id',
                  
                )
                ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
                ->where('estpl_manage_exam.sno', $id)
                ->first();

            if (!$exam) {
                return redirect()->back()->with('error', 'Exam not found');
            }

            // Add staff information to exam object
            $exam->role_name = '';
            $exam->staff_names = $staff->username ?? '';
            $exam->nick_name = $staff->username ?? '';
            $exam->staff_image = $staff->image ?? '';

            if ($staff->batch_id) {
                $roleData = DB::table('estpl_batch')->where('sno', $staff->batch_id)->first();
                $exam->role_name = $roleData->batch_name ?? '';
            }

            // Fetch exam process details
            $process = DB::table('estpl_exam_process')
                ->select(
                    'estpl_exam_process.*',
                    'students.username as staff_name',
                    'students.username as nick_name',
                )
                ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
                ->where('estpl_exam_process.exam_id', $exam->sno)
                ->where('estpl_exam_process.status', 2)
                ->where('estpl_exam_process.sno', $process_sno)
                ->where('estpl_exam_process.staff_id', $user_id)
                ->orderBy('estpl_exam_process.sno', 'desc')
                ->get();

            // Return the view with the data
            return view('content.exam_management.manage_assessments.assessment_certificate', [
                'view' => $exam,
                'id' => $decryptedValue,
                'process' => $process,
            ]);
        } catch (\Exception $e) {
            // \Log::error('Certificate generation error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'An error occurred while generating the certificate');
        }
    }

    public function assesment_certificate_download($eid, Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        // return 'hiii';

        try {
            $decryptedValue = $helper->encrypt_decrypt($eid, 'decrypt');

            if ($decryptedValue === false) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }

            // Split the decrypted string into parts with validation
            $parts = explode('~', $decryptedValue);
            if (count($parts) < 3) {
                return redirect()->back()->with('error', 'Invalid certificate data');
            }

            list($id, $user_id, $process_sno) = $parts;

            // Validate IDs are numeric
            if (!is_numeric($id) || !is_numeric($user_id) || !is_numeric($process_sno)) {
                return redirect()->back()->with('error', 'Invalid certificate parameters');
            }

            // Fetch staff data
            $staff = DB::table('students')->join('estpl_beneficiary','estpl_beneficiary.sno','=','students.beneficiary_id')->where('id', $user_id)->select('students.*','estpl_beneficiary.image')->first();
            if (!$staff) {
                return redirect()->back()->with('error', 'Staff not found');
            }

            // Fetch exam data with proper joins
            $exam = DB::table('estpl_manage_exam')
                ->select(
                    'estpl_manage_exam.*',
                    'estpl_exam_badge.badge_image',
                    'estpl_exam_badge.prize_id',
                    'estpl_exam_badge.gift',
                    'estpl_exam_badge.points',
                    'estpl_exam_badge.promotion_id',
               
                )
                ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
                ->where('estpl_manage_exam.sno', $id)
                ->first();

            if (!$exam) {
                return redirect()->back()->with('error', 'Exam not found');
            }

            // Add staff information to exam object
            $exam->role_name = '';
            $exam->staff_names =$staff->username?? '';
            $exam->nick_name = $staff->username ?? '';
            $exam->staff_image = $staff->image ?? '';

            if ($staff->batch_id) {
                $roleData = DB::table('estpl_batch')->where('sno', $staff->batch_id)->first();
                $exam->role_name = $roleData->batch_name ?? '';
            }

            // Fetch exam process details
            $process = DB::table('estpl_exam_process')
                ->select(
                    'estpl_exam_process.*',
                   'students.username as staff_name',
                    'students.username as nick_name',
                )
                ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
                ->where('estpl_exam_process.exam_id', $exam->sno)
                ->where('estpl_exam_process.status', 2)
                ->where('estpl_exam_process.sno', $process_sno)
                ->where('estpl_exam_process.staff_id', $user_id)
                ->orderBy('estpl_exam_process.sno', 'desc')
                ->get();

            // return $interns;
            $pdf = PDF::loadView('content.exam_management.manage_result.assessment_downlaod', [
                'view' => $exam,
                'id' => $decryptedValue,
                'process' => $process
            ])
                ->setPaper('a4', 'landscape')
                ->setOption('isHtml5ParserEnabled', true)  // Enable HTML5 parsing
                ->setOption('isPhpEnabled', true)
                ->setOption('enable-javascript', false)
                ->setOption('defaultFont', 'sofia')
                ->setOption('isRemoteEnabled', true)  // now you can safely set false
                ->setPaper('a4');


            // return $pdf;
            return $pdf->download('assessment_certificate.pdf');
        } catch (\Exception $e) {
            return $e->getMessage();
            // \Log::error('Certificate generation error: ' . $e->getMessage());
            // return redirect()->back()->with('error', 'An error occurred while generating the certificate');
        }
    }

    public function assesment_certificate_preview($eid, Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        // return 'hiii';

        try {
            $decryptedValue = $helper->encrypt_decrypt($eid, 'decrypt');

            if ($decryptedValue === false) {
                return redirect()->back()->with('error', 'Invalid Entry');
            }

            // Split the decrypted string into parts with validation
            $parts = explode('~', $decryptedValue);
            if (count($parts) < 3) {
                return redirect()->back()->with('error', 'Invalid certificate data');
            }

            list($id, $user_id, $process_sno) = $parts;

            // Validate IDs are numeric
            if (!is_numeric($id) || !is_numeric($user_id) || !is_numeric($process_sno)) {
                return redirect()->back()->with('error', 'Invalid certificate parameters');
            }

            // Fetch staff data
            $staff = DB::table('students')->join('estpl_beneficiary','estpl_beneficiary.sno','=','students.beneficiary_id')->where('id', $user_id)->select('students.*','estpl_beneficiary.image')->first();
            if (!$staff) {
                return redirect()->back()->with('error', 'Staff not found');
            }

            // Fetch exam data with proper joins
            $exam = DB::table('estpl_manage_exam')
                ->select(
                    'estpl_manage_exam.*',
                    'estpl_exam_badge.badge_image',
                    'estpl_exam_badge.prize_id',
                    'estpl_exam_badge.gift',
                    'estpl_exam_badge.points',
                    'estpl_exam_badge.promotion_id',
                   
                )
                ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
                ->where('estpl_manage_exam.sno', $id)
                ->first();

            if (!$exam) {
                return redirect()->back()->with('error', 'Exam not found');
            }

            // Add staff information to exam object
            $exam->role_name = '';
            $exam->staff_names = $staff->username ?? '';
            $exam->nick_name = $staff->username ?? '';
            $exam->staff_image = $staff->image ?? '';

            if ($staff->batch_id) {
                $roleData = DB::table('estpl_batch')->where('sno', $staff->batch_id)->first();
                $exam->role_name = $roleData->batch_name ?? '';
            }

            // Fetch exam process details
            $process = DB::table('estpl_exam_process')
                ->select(
                    'estpl_exam_process.*',
                    'students.username as staff_name',
                    'students.username as nick_name',
                )
                ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
                ->where('estpl_exam_process.exam_id', $exam->sno)
                ->where('estpl_exam_process.status', 2)
                ->where('estpl_exam_process.sno', $process_sno)
                ->where('estpl_exam_process.staff_id', $user_id)
                ->orderBy('estpl_exam_process.sno', 'desc')
                ->get();

            return view('content.exam_management.manage_result.certificate_preview', [
                'view' => $exam,
                'id' => $decryptedValue,
                'process' => $process
            ]);
        } catch (\Exception $e) {
            return $e->getMessage();
            // \Log::error('Certificate generation error: ' . $e->getMessage());
            // return redirect()->back()->with('error', 'An error occurred while generating the certificate');
        }
    }

    public function staff_certificate_send($id, Request $request)
    {

        $helper = new \App\Helpers\Helpers();

        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        // Split the decrypted string into parts with validation
        $parts = explode('~', $decryptedValue);
        if (count($parts) < 3) {
            return redirect()->back()->with('error', 'Invalid certificate data');
        }

        list($id, $user_id, $process_sno) = $parts;

        // Validate IDs are numeric
        if (!is_numeric($id) || !is_numeric($user_id) || !is_numeric($process_sno)) {
            return redirect()->back()->with('error', 'Invalid certificate parameters');
        }

        // Fetch staff data
        $staff = DB::table('students')->where('id', $user_id)->first();

        // Fetch exam data with proper joins
        $exam = DB::table('estpl_manage_exam')
            ->select(
                'estpl_manage_exam.*',
                'estpl_exam_badge.badge_image',
                'estpl_exam_badge.badge_image',
                'estpl_exam_badge.prize_id',
                'estpl_exam_badge.gift',
                'estpl_exam_badge.points',
                'estpl_exam_badge.promotion_id',
               
            )
            ->leftJoin('estpl_exam_badge', 'estpl_exam_badge.sno', '=', 'estpl_manage_exam.badge')
            ->where('estpl_manage_exam.sno', $id)
            ->first();

        if ($staff->batch_id) {
            $roleData = DB::table('estpl_batch')->where('sno', $staff->batch_id)->first();
            $exam->role_name = $roleData->batch_name ?? '';
        }

        // Fetch exam process details
        $process = DB::table('estpl_exam_process')
            ->select(
                'estpl_exam_process.*',
                'students.username as staff_name',
                'students.username as nick_name',
            )
            ->leftJoin('students', 'students.id', '=', 'estpl_exam_process.staff_id')
            ->where('estpl_exam_process.exam_id', $exam->sno)
            ->where('estpl_exam_process.status', 2)
            ->where('estpl_exam_process.sno', $process_sno)
            ->where('estpl_exam_process.staff_id', $user_id)
            ->orderBy('estpl_exam_process.sno', 'desc')
            ->get();


        $certificate_key = null;
        $exam_uni_id = 0;
        $marksScored = 0;
        $totalMarks = 0;
        $date = date('d-M-Y');
        $Link = url('assesment_certificate_download/' . $id);

        if (isset($process[0])) {
            $p = $process[0];
            $answers = json_decode($p->exam_question_answers_datas, true) ?? [];
            $positiveMarks = $view->positive_mark ?? 1;
            $negativeMarks = $view->negative_mark ?? 0;
            $totalQuestions = $view->question_count ?? 0;
            $correctCount = collect($answers)->where('correctness', 'correct')->count();
            $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();
            $totalMarks = $positiveMarks * $totalQuestions;
            $marksScored = max(0, $positiveMarks * $correctCount - $negativeMarks * $incorrectCount);
            $isPassed = $marksScored >= $exam->pass_mark;
            $date = $p->completed_date;
            $exam_uni_id = $p->sno;

            if (!$p->chotta_link) {
                $channelId = 14;
                $shortUrlData = $this->shortenUrlExam($Link, $channelId);
                $shortUrl = $shortUrlData['shorturl'];
                $urlId = $shortUrlData['id'];
                if ($shortUrl) {
                    DB::table('estpl_exam_process')
                        ->where('sno', $exam_uni_id)
                        ->update(['chotta_link' => $shortUrl]);
                }
            }
            $examData = DB::table('estpl_exam_process')->where('sno', $exam_uni_id)->first();
            $shortsendUrl = $examData->chotta_link;

            $certificate_key = basename($shortsendUrl);
        }


        $emp_name = $staff->username;
        $staff_mobile = $staff->password;
        $assess_name = $exam->exam_name;
        $date1 = $date;
        $score = $marksScored;
        $badge_name = $exam->badge_name ?? '-';


        if ($staff_mobile && $certificate_key) {
            // $templateName  = "hello_world";
            $templateName  = "certificate_download";

            $hasHeader  = false; // Example flag: set based on template
            $hasBody    = false; // Example flag: set based on template
            $hasFooter  = false; // Example flag: set based on template
            $hasButton  = false;
            $components = [];
            $couponCode = " ";
            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')

            if ($templateName == 'certificate_download') {
                // $headerImage = 'https://erp.elysiumtechnologies.com/assets/egc_images/exam_certiificate_template_image.jpg';
                $headerImage =  url('public/assets/egc_images/exam_certiificate_template_image.jpg');
                $couponCode  = 'NOOFFER';
                $buttonIndex = 1;
                $bodyText    = [
                    [
                        'type'           => 'text',
                        'text'           => $emp_name ?? "Elysium Mate",
                        'parameter_name' => 'emp_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $assess_name ?? "Assessment",
                        'parameter_name' => 'assess_name',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $date1,
                        'parameter_name' => 'date1',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $score,
                        'parameter_name' => 'score',
                    ],
                    [
                        'type'           => 'text',
                        'text'           => $badge_name ?? '-',
                        'parameter_name' => 'badge_name',
                    ]
                ];
                $hasHeader = true;
                $hasBody   = true;
                $hasButton = true;
            }

            // Add Header if required
            if ($hasHeader) {
                $components[] = [
                    'type'       => 'header',
                    'parameters' => [
                        [
                            'type'  => 'image',
                            'image' => [
                                'link' => $headerImage, // Dynamically set header image
                            ],
                        ],
                    ],
                ];
            }

            // Add Body if required
            if ($hasBody) {
                $components[] = [
                    'type'       => 'body',
                    'parameters' => $bodyText,
                ];
            }

            // Add Footer if required
            if ($hasButton) {
                $components[] = [
                    'type'       => 'button',
                    'sub_type'   => 'url',
                    'index'      => 0,
                    'parameters' => [
                        [
                            'type' => 'text',
                            'text' => $certificate_key,
                        ],
                    ],
                ];
            }


            $dynamicParameters         = $templateParameters[$templateName] ?? [];
            $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
            $accessToken               = $this->accessData($request)->access_tokken;
            $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            $mobile = preg_replace('/\D/', '', $staff_mobile); // remove any non-digits
            if (strpos($staff_mobile, '+') === 0) {
                $to = $staff_mobile;
            } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
                $to = '+' . $mobile;
            } else {
                $to = '+91' . $mobile;
            }
            $languageCode = 'en';

            // if (strpos($to, $countryCode) !== 0) {
            //     $to = $countryCode . $to;
            // }
            
            $message = 'test~message';
            if (empty($components)) {
                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to'                => $to,
                    'type'              => 'template',
                    'template'          => [
                        'name'     => $templateName,
                        'language' => [
                            'code' => $languageCode,
                        ],
                    ],
                ];
            } else {
                $payload = [
                    'messaging_product' => 'whatsapp',
                    'to'                => $to,
                    'type'              => 'template',
                    'template'          => [
                        'name'       => $templateName,
                        'language'   => [
                            'code' => $languageCode,
                        ],
                        'components' => $components,
                    ],
                ];
            }
            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            return response([
                'status' => 200,
                'message' => 'Message send Successfully',
                'Data' => $response,
            ], 200);
        } else {
            return response([
                'status' => 404,
                'message' => 'Failed to send message',
                'certificate_status' => 2,
                'error_msg' => 'Error',
            ], 400);
        }
    }

    public function accessData(Request $request)
    {

        $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 2)->first();
        return $whatsappConfig;
    }

    private function sendRequestToWhatsApp($url, $token, $data)
    {
        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->post($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,

            ]);

            return [
                'status' => $response->getStatusCode(),
                'data' => json_decode($response->getBody(), true),
            ];
        } catch (\Exception $e) {
            return [
                'status' => 400,
                'error' => $e->getMessage(),
            ];
        }
    }

    public function shortenUrlExam($longUrl, $channelId)
    {
        $response = Http::withToken('aFLQFlykraqpANsi')
            ->post('https://chotta.link/api/url/add', [
                'url' => $longUrl
            ]);

        if ($response->successful() && isset($response['shorturl'])) {

            $shortUrl = $response['shorturl'];
            $urlId = $response['id'];

            $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

            $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);

            if ($assignResponse->successful()) {
                return $response; // success
            }
        }


        return null;
    }

    private function getStudent(Request $request)
    {
        // return $request;
        if (!$request->route('id')) {
            return null;
        }

        $helper = new \App\Helpers\Helpers();

        try {
            $studentId = $helper->encrypt_decrypt($request->route('id'), 'decrypt');
        } catch (\Exception $e) {
            return null;
        }

        if (!$studentId) {
            return null;
        }

        return EstplStudentsModel::select(
                'students.*',
                'estpl_beneficiary.status as ben_status',
                'estpl_beneficiary.image',
                'estpl_beneficiary.name'
            )
            ->leftJoin('estpl_beneficiary', 'students.beneficiary_id', '=', 'estpl_beneficiary.sno')
            ->where('students.id', $studentId)
            ->where('estpl_beneficiary.status', 0)
            ->first();
    }

    private function getStudentfull(Request $request)
    {
        $encryptedStudentId = $request->route('student');

        if (!$encryptedStudentId) {
            return null;
        }

        $helper = new \App\Helpers\Helpers();

        try {
            $studentId = $helper->encrypt_decrypt($encryptedStudentId, 'decrypt');
        } catch (\Exception $e) {
            return null;
        }

        return EstplStudentsModel::where('students.id', $studentId)->first();
    }

   
    public function saveMedia(Request $request)
    {
        try {
            /* ================= VALIDATION ================= */
            $request->validate([
                'video'     => 'required|file',
                'audio'     => 'required|file',
                'exam_id'   => 'required|integer',
                'user_id'   => 'required|integer',
                'branch_id' => 'required|integer',
            ]);

            $userId   = $request->user_id;
            $examId   = $request->exam_id;
            $branchId = $request->branch_id;

            /* ================= SAVE FILES ================= */
            $basePath = public_path("assesment_media/user_{$userId}");
            if (!file_exists($basePath)) {
                mkdir($basePath, 0777, true);
            }

            $videoName = iconv('UTF-8', 'UTF-8//IGNORE', "video_{$examId}_" . time() . ".webm");
            $audioName = iconv('UTF-8', 'UTF-8//IGNORE', "audio_{$examId}_" . time() . ".webm");

            $videoPath = "{$basePath}/{$videoName}";
            $audioPath = "{$basePath}/{$audioName}";

            $request->file('video')->move($basePath, $videoName);
            $request->file('audio')->move($basePath, $audioName);

            /* ================= DB SAVE ================= */
            ProctoringModel::create([
                'user_id'    => $userId,
                'branch_id'  => $branchId,
                'exam_id'    => $examId,
                'video_name' => $videoName,
                'audio_name' => $audioName,
            ]);

            /* ================= LOCAL ANALYSIS ================= */
            $analysis = $this->analyzeSession($videoPath, $audioPath, $basePath);

            /* ================= HUGGINGFACE SCORING ================= */
            $signals = $this->runHuggingFaceAnalysis(
                $analysis,
                $videoPath,
                $audioPath
            );

            $malpracticeScore = $this->calculateMalpracticeScore($signals);

            /* ================= NEGATIVE MARKS ================= */
            $exam = ManageExamModel::find($examId);
            $negativeScore = $exam->negative_malpractice_score ?? 0;
            \Log::info('PROCTOR SCORES', [
                'negativeScore'     => (float) $negativeScore,
                'malpracticeScore' => (int) $malpracticeScore,
            ]);


            if ($negativeScore > 0 && $malpracticeScore > 0) {

                $examProcess = ExamProcessModel::where('exam_id', $examId)
                    ->where('staff_id', $userId)
                    ->orderByDesc('sno') 
                    ->first();


                if ($examProcess) {

                    // score-based deduction
                    $deduction =  $negativeScore;

                    $examProcess->staff_marks = max(
                        0,
                        $examProcess->staff_marks - $deduction
                    );

                    $examProcess->save();

                    \Log::info('MALPRACTICE DEDUCTED', [
                        'user_id' => $userId,
                        'exam_id' => $examId,
                        'score' => $malpracticeScore,
                        'deducted' => $deduction,
                        'remaining_marks' => $examProcess->staff_marks
                    ]);
                }
            }
            // MALPRACTICE DEDUCTED log is not working

            // sanitize signals
            $signals = [
                'speech' => (bool) ($signals['speech'] ?? false),
                'multiple_faces' => (bool) ($signals['multiple_faces'] ?? false),
            ];

            // safe logging
            \Log::info('PROCTOR ANALYSIS', json_decode(json_encode($signals, JSON_INVALID_UTF8_IGNORE), true));

            // return response safely
            return response()->json([
                'success' => true,
                'malpractice_score' => $malpracticeScore,
                'signals' => $signals
            ]);

        } catch (\Throwable $e) {
            // sanitize error message
            $errorMessage = iconv('UTF-8', 'UTF-8//IGNORE', $e->getMessage());

            \Log::error('PROCTOR FAILED', [
                'error' => $errorMessage,
                'line'  => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Proctoring analysis failed'
            ], 500);
        }
    }

    /* ====================== ANALYZE SESSION ====================== */
    private function analyzeSession($videoPath, $audioPath, $basePath)
    {
        $sessionId = uniqid('session_', true);
        $frameDir = "{$basePath}/frames_{$sessionId}";
        mkdir($frameDir, 0755, true);

        // Extract frames safely
        $cmd = sprintf(
            'ffmpeg -y -i %s -vf fps=1/5 %s/frame_%%03d.jpg 2>&1',
            escapeshellarg($videoPath),
            escapeshellarg($frameDir)
        );
        exec($cmd, $ffmpegOutput, $returnVar);
        $ffmpegOutput = array_map(fn($line) => iconv('UTF-8', 'UTF-8//IGNORE', $line), $ffmpegOutput);

        $frames = glob("{$frameDir}/frame_*.jpg");
        $keyFrames = array_slice($frames, 0, 3);

        // Lightweight audio hint
        $audioCmd = sprintf(
            'ffmpeg -i %s -af volumedetect -f null /dev/null 2>&1',
            escapeshellarg($audioPath)
        );
        exec($audioCmd, $audioOutput);
        $audioOutput = array_map(fn($line) => iconv('UTF-8', 'UTF-8//IGNORE', $line), $audioOutput);

        $localSpeechHint = false;
        foreach ($audioOutput as $line) {
            if (preg_match('/mean_volume:\s(-?\d+(\.\d+)?)/', $line, $m)) {
                if ((float)$m[1] > -30) {
                    $localSpeechHint = true;
                }
            }
        }

        return [
            'key_frames' => $keyFrames,
            'local_speech_hint' => $localSpeechHint,
            'frame_dir' => $frameDir
        ];
    }

    /* ====================== HUGGINGFACE VISION ====================== */
    private function hfVisionAnalysis(array $frames)
    {
        foreach ($frames as $frame) {
            if (!file_exists($frame)) continue;

            $response = Http::withToken(env('HF_API_KEY'))
                ->timeout(60)
                ->attach(
                    'file',
                    file_get_contents($frame),
                    basename($frame)
                )
                ->post('https://router.huggingface.co/hf-inference/models/Salesforce/blip-image-captioning-large');

            if (!$response->successful()) continue;

            $caption = strtolower($response->json()[0]['generated_text'] ?? '');
            $caption = iconv('UTF-8', 'UTF-8//IGNORE', $caption);

            if (str_contains($caption, 'people') ||
                str_contains($caption, 'persons') ||
                str_contains($caption, 'phone') ||
                str_contains($caption, 'mobile') ||
                str_contains($caption, 'book')
            ) {
                return true;
            }
        }

        return false;
    }

    

     private function hfAudioAnalysis($audioPath)
    {
        if (!file_exists($audioPath)) return false;

        $audioData = file_get_contents($audioPath);

        $response = Http::withToken(env('HF_API_KEY'))
            ->timeout(120)
            ->withBody($audioData, 'audio/webm')
            ->post('https://router.huggingface.co/hf-inference/models/openai/whisper-large-v3');

        if (!$response->successful()) {
            \Log::error('HF AUDIO FAILED', [
                'status' => $response->status(),
                'body'   => substr(strip_tags($response->body()), 0, 300),
            ]);
            return false;
        }

        $json = $response->json();

        $text = iconv(
            'UTF-8',
            'UTF-8//IGNORE',
            $json['text'] ?? ''
        );

        return trim($text) !== '';
    }



    /* ====================== RUN HUGGINGFACE ANALYSIS ====================== */
    private function runHuggingFaceAnalysis($analysis, $videoPath, $audioPath)
    {
        $speech = $this->hfAudioAnalysis($audioPath);
        $sceneSuspicious = $this->hfVisionAnalysis($analysis['key_frames']);

        return [
            'speech' => $speech,
            'multiple_faces' => $sceneSuspicious
        ];
    }

    /* ====================== CALCULATE MALPRACTICE ====================== */
    private function calculateMalpracticeScore(array $signals)
    {
        $score = 0;

        if ($signals['speech']) {
            $score += 10;
        }
        if ($signals['multiple_faces']) {
            $score += 20;
        }

        return min(100, $score);
    }

    

}
