<?php

namespace App\Http\Controllers\hr_management\exam_management;

use App\Http\Controllers\Controller;
use App\Models\ExamQuestionsModel;
use App\Models\ManageExamModel;
use App\Models\QuestionBankModel;
use App\Models\UserRoleModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageExam extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';
        $branch_id = $request->user()->branch_id;

        $query = DB::table('egc_manage_exam')->select(
            'egc_manage_exam.*'
        )
            ->where('egc_manage_exam.status', '!=', 2);

        if ($search_fill != '') {
            $query->where(function ($query) use ($search_fill) {
                $query->where('egc_manage_exam.exam_name', 'LIKE', "%{$search_fill}%");
            });
        }


        $lists = $query
            // ->where('egc_manage_exam.branch_id', $branch_id)
            ->orderBy('sno', 'desc')
            ->paginate($perpage);

        return view('content.hr_management.exam_management.manage_exam.list', [
            'lists' => $lists,
            'perpage' => $perpage,
            'search_fill' => $search_fill
        ]);
    }

    public function showCreateExam()
    {
        return view('content.hr_management.exam_management.manage_exam.add');
    }

    public function fetchQuestionBankName($id)
    {
        $banks = DB::table('egc_question_bank')->where('level_id', $id)->where('status', 0)->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => [
                'banks' => $banks
            ]
        ], 200);
    }

    public function levelBasedQuestion(Request $request)
    {
        // Expect multiple IDs: ?ids[]=1&ids[]=2 OR from JS as comma-separated
        $ids = $request->ids ?? [];

        if (!is_array($ids)) {
            $ids = explode(',', $ids);
        }

        // Fetch all banks
        $banks = DB::table('egc_question_bank')
            ->whereIn('sno', $ids)
            ->where('status', 0)
            ->get();

        if ($banks->isEmpty()) {
            return response([
                'status' => 404,
                'message' => 'No Question Banks Found!',
                'error_msg' => null,
                'data' => []
            ], 404);
        }

        $sections = [];

        // Fetch sections for each bank
        foreach ($banks as $bank) {
            $sections[$bank->sno] = DB::table('egc_exam_questions')
                ->select(
                    'egc_exam_section.sno as section_id',
                    'egc_exam_section.section_name',
                    DB::raw('COUNT(egc_exam_questions.sno) as question_count')
                )
                ->leftJoin('egc_exam_section', 'egc_exam_section.sno', '=', 'egc_exam_questions.section_id')
                ->where('egc_exam_questions.bank_id', $bank->sno)
                ->where('egc_exam_questions.status', 0)
                ->groupBy('egc_exam_section.sno', 'egc_exam_section.section_name')
                ->get();
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => [
                'sections' => $sections,
                'banks' => $banks
            ]
        ], 200);
    }


    public function fetchJobRoles(Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $data = UserRoleModel::where('status', 0)->get();
        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data,
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed',
                'error_msg' => null,
                'data' => null,
            ], 402);
        }
    }

    public function Status($id, Request $request)
    {
        $status = ManageExamModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Create(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;

        $selectedSections = $request->input('selected_sections', []);
        $totalQuestionsNeeded = (int)$request->question_count;
        $sectionsWithCount = [];
        $totalAvailable = 0;

        // Parse selected sections: format expected is "bankId_sectionId"
        foreach ($selectedSections as $value) {
            if (!preg_match('/^\d+_\d+$/', $value)) {
                continue; // Skip if invalid format
            }

            list($bankId, $sectionId) = explode('_', $value);

            $count = ExamQuestionsModel::where('bank_id', $bankId)
                ->where('section_id', $sectionId)
                ->where('status', 0)
                ->count();

            if ($count > 0) {
                $key = "$bankId|$sectionId"; // Key format for internal usage
                $sectionsWithCount[$key] = [
                    'count' => $count,
                    'bank_id' => $bankId,
                    'section_id' => $sectionId
                ];
                $totalAvailable += $count;
            }
        }

        // Check if enough questions available overall
        if ($totalAvailable < $totalQuestionsNeeded) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Not enough questions in selected sections'
            ]);
            return redirect()->back()->withInput();
        }

        // Proportional distribution logic
        $distribution = [];
        $remaining = $totalQuestionsNeeded;
        $totalWeight = array_sum(array_column($sectionsWithCount, 'count'));

        foreach ($sectionsWithCount as $key => $info) {
            $share = floor(($info['count'] / $totalWeight) * $totalQuestionsNeeded);
            $distribution[$key] = $share;
            $remaining -= $share;
        }

        // Distribute any remaining questions
        if ($remaining > 0) {
            foreach ($sectionsWithCount as $key => $info) {
                if ($remaining <= 0) break;

                $current = $distribution[$key];
                if ($current < $info['count']) {
                    $distribution[$key]++;
                    $remaining--;
                }
            }
        }

        // ✅ REMOVED: Checking previously used question IDs from other exams
        // We only care about uniqueness within THIS exam

        $selectedQuestionIds = [];
        $isSequence = $request->trail == 1;

        // ✅ Select questions for each section - ENSURING UNIQUENESS WITHIN THIS EXAM ONLY
        foreach ($distribution as $key => $count) {
            if ($count == 0) continue;

            list($bankId, $sectionId) = explode('|', $key);

            $query = ExamQuestionsModel::where('bank_id', $bankId)
                ->where('section_id', $sectionId)
                ->where('status', 0)
                ->whereNotIn('sno', $selectedQuestionIds); // Only exclude already picked in THIS exam

            if ($isSequence) {
                $query = $query->orderBy('sno');
            } else {
                $query = $query->inRandomOrder();
            }

            $questions = $query->take($count)->pluck('sno')->toArray();

            // ✅ Remove any duplicates that might have been selected
            $questions = array_unique($questions);

            // ✅ If we got fewer questions than needed due to uniqueness constraint, try to get more
            if (count($questions) < $count) {
                $additionalNeeded = $count - count($questions);

                $additionalQuery = ExamQuestionsModel::where('bank_id', $bankId)
                    ->where('section_id', $sectionId)
                    ->where('status', 0)
                    ->whereNotIn('sno', $selectedQuestionIds) // Exclude already picked in this exam
                    ->whereNotIn('sno', $questions); // Also exclude the ones we already selected from this section

                if ($isSequence) {
                    $additionalQuery = $additionalQuery->orderBy('sno');
                } else {
                    $additionalQuery = $additionalQuery->inRandomOrder();
                }

                $additionalQuestions = $additionalQuery->take($additionalNeeded)->pluck('sno')->toArray();
                $questions = array_merge($questions, $additionalQuestions);
                $questions = array_unique($questions);
            }

            $selectedQuestionIds = array_merge($selectedQuestionIds, $questions);

            // ✅ Ensure no duplicates across sections for this exam
            $selectedQuestionIds = array_unique($selectedQuestionIds);
        }

        // ✅ Final check for duplicates (shouldn't be needed but just in case)
        $selectedQuestionIds = array_unique($selectedQuestionIds);

        // Shuffle questions if not sequential
        if (!$isSequence) {
            shuffle($selectedQuestionIds);
        }

        // ✅ If not enough unique questions found
        if (count($selectedQuestionIds) < $totalQuestionsNeeded) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Not enough unique questions available for this exam. Required: ' . $totalQuestionsNeeded . ', Found: ' . count($selectedQuestionIds)
            ]);
            return redirect()->back()->withInput();
        }

        // ✅ If we have more questions than needed (due to array_unique), take only the required number
        if (count($selectedQuestionIds) > $totalQuestionsNeeded) {
            $selectedQuestionIds = array_slice($selectedQuestionIds, 0, $totalQuestionsNeeded);
        }

        $selectedRoles = $request->role_id;

        if (is_array($selectedRoles) && in_array('all', $selectedRoles)) {
            $selectedRoles = UserRoleModel::where('status', 0)->pluck('sno')->toArray();
        }

        $bank_id = $request->question_bnk_id;

        $exam = ManageExamModel::create([
            'exam_name' => $request->exam_name,
            'branch_id' => $branch_id,
            'level_id' => $request->level_id,
            'role_id' => json_encode($selectedRoles),
            'bank_id' => json_encode($bank_id),
            'schedule_id' => $request->schedule_id,
            'question_count' => $totalQuestionsNeeded,
            'duration' => $request->duration,
            'positive_mark' => $request->pst_mark,
            'negative_mark' => $request->ngt_mark,
            'exam_attempt' => $request->exam_attempt,
            'question_generate' => $isSequence ? '1' : '0',
            'pass_mark' => $request->pass_mark,
            'attempts' => $request->attempts ?? null,
            'badge_check' => $request->has('badge_check') ? 1 : 0,
            'detailed_view' => $request->has('detailed_view') ? 1 : 0,
            'is_certificate' => $request->has('IsCertificate') ? 1 : 0,
            'tips_check' => $request->has('tips_check') ? 1 : 0,
            'explanation_check' => $request->has('explanation_check') ? 1 : 0,
            'case_study_check' => $request->has('case_study_check') ? 1 : 0,
            'badge' => $request->badge ?? null,
            'description' => $request->exam_desc,
            'question_ids' => json_encode($selectedQuestionIds),
            'created_by' => $user_id,
            'updated_by' => $user_id,
        ]);

        if ($exam) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Created Successfully! Questions Selected: ' . count($selectedQuestionIds)
            ]);
            return redirect('/manage_exam');
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Creation Failed!'
            ]);
            return redirect('/manage_exam');
        }
    }

    public function Edit($id = '')
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;
        $edit = ManageExamModel::where('sno', $decryptedValue)->where('status', 0)->first();

        return view('content.hr_management.exam_management.manage_exam.edit', [
            'edit' => $edit,
            'id' => $decryptedValue
        ]);
    }

    public function editLevelQuestions($sno, Request $request)
    {
        $edit = ManageExamModel::where('sno', $sno)->where('status', 0)->first();

        $ids = $request->ids ?? [];

        if (!is_array($ids)) {
            $ids = explode(',', $ids);
        }

        $banks = DB::table('egc_question_bank')
            ->whereIn('sno', $ids)
            ->select('sno', 'bank_name')
            ->get();

        $questionIds = json_decode($edit->question_ids ?? '[]', true);

        $sections = [];
        foreach ($ids as $bankId) {
            $sectionData = DB::table('egc_exam_questions')
                ->select(
                    'egc_exam_section.sno as section_id',
                    'egc_exam_section.section_name',
                    DB::raw('COUNT(egc_exam_questions.sno) as question_count'),
                    DB::raw('GROUP_CONCAT(egc_exam_questions.sno) as question_ids')
                )
                ->leftJoin('egc_exam_section', 'egc_exam_section.sno', '=', 'egc_exam_questions.section_id')
                ->where('egc_exam_questions.bank_id', $bankId)
                ->groupBy('egc_exam_section.sno', 'egc_exam_section.section_name')
                ->get();

            foreach ($sectionData as $section) {
                $section->question_ids = array_map('intval', explode(',', $section->question_ids));
            }

            $sections[$bankId] = $sectionData;
        }

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => [
                'sections' => $sections,
                'banks' => $banks,
                'selected_question_ids' => $questionIds
            ]
        ], 200);
    }

    public function Update(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $exam_id = $request->edit_id;

        $exam = ManageExamModel::find($exam_id);

        if (!$exam) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam not found!'
            ]);
            return redirect('/manage_exam');
        }

        $selectedSections = $request->input('selected_sections', []);
        $totalQuestionsNeeded = (int)$request->question_count;
        $sectionsWithCount = [];
        $totalAvailable = 0;

        // Parse selected sections: format should be "bankId_sectionId"
        foreach ($selectedSections as $value) {
            if (!preg_match('/^\d+_\d+$/', $value)) continue;

            list($bankId, $sectionId) = explode('_', $value);

            $count = ExamQuestionsModel::where('bank_id', $bankId)
                ->where('section_id', $sectionId)
                ->count();

            if ($count > 0) {
                $key = "$bankId|$sectionId";
                $sectionsWithCount[$key] = [
                    'count' => $count,
                    'bank_id' => $bankId,
                    'section_id' => $sectionId
                ];
                $totalAvailable += $count;
            }
        }

        if ($totalAvailable < $totalQuestionsNeeded) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Not enough questions in selected sections'
            ]);
            return redirect()->back()->withInput();
        }

        // Proportional distribution
        $distribution = [];
        $remaining = $totalQuestionsNeeded;
        $totalWeight = array_sum(array_column($sectionsWithCount, 'count'));

        foreach ($sectionsWithCount as $key => $info) {
            $share = floor(($info['count'] / $totalWeight) * $totalQuestionsNeeded);
            $distribution[$key] = $share;
            $remaining -= $share;
        }

        // Distribute remaining
        if ($remaining > 0) {
            foreach ($sectionsWithCount as $key => $info) {
                if ($remaining <= 0) break;
                if ($distribution[$key] < $info['count']) {
                    $distribution[$key]++;
                    $remaining--;
                }
            }
        }

        // Select questions
        $selectedQuestionIds = [];
        $isSequence = $request->trail == 1;

        foreach ($distribution as $key => $count) {
            if ($count == 0) continue;

            list($bankId, $sectionId) = explode('|', $key);

            $query = ExamQuestionsModel::where('bank_id', $bankId)
                ->where('status', 0)
                ->where('section_id', $sectionId);

            $query = $isSequence ? $query->orderBy('sno') : $query->inRandomOrder();

            $questions = $query->take($count)->pluck('sno')->toArray();
            $selectedQuestionIds = array_merge($selectedQuestionIds, $questions);
        }

        if (!$isSequence) {
            shuffle($selectedQuestionIds);
        }

        $selectedRoles = $request->role_id;

        if (is_array($selectedRoles) && in_array('all', $selectedRoles)) {
            $selectedRoles = UserRoleModel::where('status', 0)->pluck('sno')->toArray();
        }

        $bank_id = $request->question_bnk_id;

        // Update exam
        $updated = $exam->update([
            'exam_name' => $request->exam_name,
            'branch_id' => $branch_id,
            'level_id' => $request->level_id,
            'role_id' => json_encode($selectedRoles),
            'bank_id' => json_encode($bank_id),
            'schedule_id' => $request->schedule_id,
            'question_count' => $totalQuestionsNeeded,
            'duration' => $request->duration,
            'positive_mark' => $request->pst_mark,
            'negative_mark' => $request->ngt_mark,
            'exam_attempt' => $request->exam_attempt,
            'question_generate' => $isSequence ? '1' : '0',
            'pass_mark' => $request->pass_mark,
            'attempts' => $request->attempts ?? null,
            'detailed_view' => $request->has('detailed_view') ? 1 : 0,
            'is_certificate' => $request->has('IsCertificate') ? 1 : 0,
            'badge_check' => $request->has('badge_check') ? 1 : 0,
            'tips_check' => $request->has('tips_check') ? 1 : 0,
            'explanation_check' => $request->has('explanation_check') ? 1 : 0,
            'case_study_check' => $request->has('case_study_check') ? 1 : 0,
            'badge' => $request->badge ?? null,
            'description' => $request->description,
            'question_ids' => json_encode($selectedQuestionIds),
            'updated_by' => $user_id,
        ]);

        if ($updated) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Exam Updated Successfully!'
            ]);
            return redirect('/manage_exam');
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Exam Update Failed!'
            ]);
            return redirect('/manage_exam');
        }
    }


    public function view($id)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if ($decryptedValue === false) {
            return redirect()->back()->with('error', 'Invalid Entry');
        }

        $id = $decryptedValue;
        $edit = ManageExamModel::where('egc_manage_exam.sno', $decryptedValue)
            ->select(
                'egc_manage_exam.*',
                'egc_exam_badge.badge_image',
                'egc_exam_badge.badge_name',
                'egc_exam_schedule.schedule_name',
                'egc_exam_schedule.duration as schedule_duration',
                'egc_exam_schedule.unit as schedule_unit'
            )
            ->leftJoin('egc_exam_badge', 'egc_exam_badge.sno', '=', 'egc_manage_exam.badge')
            ->leftJoin('egc_exam_schedule', 'egc_exam_schedule.sno', '=', 'egc_manage_exam.schedule_id')
            ->where('egc_manage_exam.status', 0)
            ->first();

        if ($edit) {
            // Decoding the JSON string into an array (if role_id is stored as a JSON)
            $role_ids = json_decode($edit->role_id ?? '[]', true);

            // Initialize an empty array to store role names
            $rolename = [];

            // Loop through each role_id to get the corresponding role name
            foreach ($role_ids as $role) {
                // Fetch role data from the database
                $roleData = DB::table('egc_user_role')->where('sno', $role)->first();

                // Check if role data exists and then push the role name to the $rolename array
                if ($roleData) {
                    $rolename[] = $roleData->role_name;  // Add role name to the array
                }
            }

            // Convert the array of role names to a comma-separated string
            $edit->role_name = implode(', ', $rolename);
        }


        $questionIds = json_decode($edit->question_ids ?? '[]', true);

        $sections = [];

        foreach ($questionIds as $question) {
            $section = DB::table('egc_exam_questions')
                ->select(
                    'egc_question_bank.bank_name',
                    'egc_exam_section.section_name',
                    'egc_exam_questions.*'
                )
                ->leftJoin('egc_question_bank', 'egc_question_bank.sno', '=', 'egc_exam_questions.bank_id')
                ->leftJoin('egc_exam_section', 'egc_exam_section.sno', '=', 'egc_exam_questions.section_id')
                ->where('egc_exam_questions.sno', $question)
                ->first();

            $sections[$question] = $section;
        }

        // return $edit;

        return view('content.hr_management.exam_management.manage_exam.view', [
            'view' => $edit,
            'id' => $decryptedValue,
            'sections' => $sections
        ]);
    }

    public function checkExamProcess($id)
    {
        // Fetch assessment records with staff info
        $assessments = DB::table('egc_exam_process')
            ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_exam_process.staff_id')
            ->where('egc_exam_process.exam_id', $id)
            ->select('egc_staff.staff_name', 'egc_staff.nick_name', 'egc_staff.staff_id')
            ->get();

        // Fetch badge earners with staff info
        $badges = DB::table('egc_exam_staff_badges')
            ->leftJoin('egc_manage_exam', 'egc_manage_exam.sno', '=', 'egc_exam_staff_badges.exam_id')
            ->leftJoin('egc_exam_badge', 'egc_exam_badge.sno', '=', 'egc_manage_exam.badge')
            ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_exam_staff_badges.staff_id')
            ->where('egc_exam_staff_badges.exam_id', $id)
            ->select('egc_staff.staff_name', 'egc_staff.nick_name', 'egc_staff.staff_id', 'egc_exam_badge.badge_name')
            ->get();

        // Fetch points records with staff info
        $points = DB::table('egc_staff_exam_points')
            ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_staff_exam_points.staff_id')
            ->where('egc_staff_exam_points.exam_id', $id)
            ->select('egc_staff.staff_name', 'egc_staff.nick_name', 'egc_staff.staff_id', 'egc_staff_exam_points.points')
            ->get();

        return response()->json([
            'process_count' => $assessments->count(),
            'badge_count' => $badges->count(),
            'points_count' => $points->count(),
            'assessments' => $assessments,
            'badges' => $badges,
            'points' => $points,
        ]);
    }

    public function Delete($id)
    {
        // Optional double check for security
        $exam = ManageExamModel::where('sno', $id)->first();

        if (!$exam) {
            return response()->json(['status' => 404, 'message' => 'Exam not found']);
        }

        // delete related badges, processes, and points if any
        // DB::table('egc_exam_staff_badges')->where('exam_id', $id)->delete();
        // DB::table('egc_exam_process')->where('exam_id', $id)->delete();
        // DB::table('egc_staff_exam_points')->where('exam_id', $id)->delete();

        // Update related badges, processes, and points with status = 2 instead of deleting
        DB::table('egc_exam_staff_badges')->where('exam_id', $id)->update(['status' => 2]);
        DB::table('egc_exam_process')->where('exam_id', $id)->update(['status' => 2]);
        DB::table('egc_staff_exam_points')->where('exam_id', $id)->update(['status' => 2]);

        // mark exam as deleted
        $exam->status = 2;
        $exam->update();

        return response()->json([
            'status' => 200,
            'message' => 'Exam and all related records deleted successfully',
        ]);
    }
}
