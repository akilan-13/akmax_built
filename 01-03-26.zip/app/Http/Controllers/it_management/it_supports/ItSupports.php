<?php

namespace App\Http\Controllers\it_management\it_supports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ApprovalHierarchyModel;
use App\Models\LeaveApprovalModel;
use App\Models\ITTicketModel;
use App\Models\ITTicketMessageModel;
use App\Models\ITTicketLogModel;
use App\Models\LeavePermissionModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class ItSupports extends Controller
{
 public function index(Request $request)
{

    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

        
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();
        
        $tickets = ITTicketModel::with('category')
            ->orderBy('priority','desc')
            ->orderBy('created_at','asc');

            if ($request->has('search_filter') && $request->search_filter != '') {
                $tickets->where('ticket_no', 'LIKE', "%" . $request->search_filter . "%")
                    ->orWhere('subject', 'LIKE', "%" . $request->search_filter . "%")
                    ->orWhere('description', 'LIKE', "%" . $request->search_filter . "%")
                    ->orWhere('priority', 'LIKE', "%" . $request->search_filter . "%");
            }

            // Apply date filter if provided (custom or predefined like "today", "week", "monthly")
            if ($request->has('date_filter')) {
                $date_filter = $request->date_filter;
                if ($date_filter == 'today') {
                    $tickets->whereDate('created_at', now()->toDateString());
                } elseif ($date_filter == 'week') {
                    $tickets->whereBetween('created_at', [
                        now()->startOfWeek()->toDateString(),
                        now()->endOfWeek()->toDateString()
                    ]);
                } elseif ($date_filter == 'monthly') {
                    $tickets->whereMonth('created_at', now()->month);
                } elseif ($date_filter == 'custom_date' && $request->has('from_date_filter') && $request->has('to_date_filter')) {
                    $tickets->whereBetween('created_at', [
                        date('Y-m-d', strtotime($request->from_date_filter)),
                        date('Y-m-d', strtotime($request->to_date_filter))
                    ]);
                }
            }

        $tickets = $tickets
        ->orderByDesc('sno')
        ->paginate($perpage);
                
                
        

        if ($request->ajax()) {
            $data = $tickets->map(function ($item) use ($helper) {
                $general_setting=$helper->general_setting_data();
                    $staffProfile = StaffModel::where('egc_staff.status', '!=', 2)
                        ->select('egc_staff.*',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_name',
                        'egc_company.company_base_color',
                        'egc_entity.entity_base_color',
                        'egc_department.department_name',
                        'egc_branch.branch_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name as job_role_name',
                        )
                        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
                        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                        ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
                        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
                        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
                        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
                        ->where('egc_staff.sno',$item->staff_id)->first();
                        if($staffProfile->company_type == 1){
                                $staffProfile->company_name=$general_setting->title;
                                $staffProfile->company_base_color ='#ab2b22';
                        }

                    $messagesCount = DB::table('egc_it_ticket_messages')
                        ->where('ticket_id', $item->sno)
                        ->where('sender_type', 'it')
                        ->where('is_read', 0)
                        ->count();

                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staffProfile' => $item->staffProfile,
                    'ticket_no' => $item->ticket_no,
                    'subject' => $item->subject,
                    'description' => $item->description,
                    'priority' => $item->priority,
                    'unread_count' => $item->messagesCount,
                    'priority' => $item->priority,
                    'category' => $item->category,
                    'attachments' => $item->attachments ? json_decode($item->attachments):[],
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $tickets->currentPage(),
                'last_page' => $tickets->lastPage(),
                'total' => $tickets->total(),
            ]);
        }
    
        $categories = DB::table('egc_it_support_category')->where('status', 0)->orderBy('sno', 'ASC')->get();
    //  return $staffProfile;
    return view('content.it_management.it_support.it_support',[
        'categories' => $categories,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
}

  public function View($id)
  {
    $data =  StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_languages.name as mother_tongue',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', $id)
      ->first();
      $languages_ids=$data->languages ? json_decode($data->languages):[];
      $hobby_ids=$data->hobby ? json_decode($data->hobby):[];
      $language_known=DB::table('egc_languages')->whereIn('sno',$languages_ids)->pluck('name');
      $hobbies=DB::table('egc_hobbies')->whereIn('sno',$hobby_ids)->pluck('hobby_name');
      $staff_family=DB::table('egc_staff_family')->where('staff_id',$id)->where('status','!=',2)->first();
      $data->language_known=$language_known;
      $data->hobbies=$hobbies;
      // family details
      $data->father_name=$staff_family? $staff_family->father_name :'';
      $data->father_occup=$staff_family? $staff_family->father_occup :'';
      $data->mother_name=$staff_family? $staff_family->mother_name :'';
      $data->mother_occup=$staff_family? $staff_family->mother_occup :'';
      $data->has_children=$staff_family? $staff_family->has_children :'';
      $data->children_count=$staff_family? $staff_family->children_count :'';
      $data->has_siblings=$staff_family? $staff_family->has_siblings :'';

      $other_credential = DB::table('egc_staff_credential')
        ->select('egc_staff_credential.*', 'egc_credential.credential_name')
        ->join('egc_credential', 'egc_staff_credential.credential_id', 'egc_credential.sno')
        ->where('egc_staff_credential.staff_id', $id)
        ->where('egc_staff_credential.status', '!=', 2)
        ->get();
    $data->other_credential = $other_credential;
    $data->contact_person_name = $data->contact_person_name ? json_decode($data->contact_person_name) : [];
    $data->contact_person_no = $data->contact_person_no ? json_decode($data->contact_person_no) : [];
    $contact_person_relation_ids = $data->contact_person_relation ? json_decode($data->contact_person_relation) : [];
    $relation=DB::table('egc_relationship_type')->whereIn('sno',$contact_person_relation_ids)->pluck('relationship_name');
    $data->relationship=$relation;

    $work_details = DB::table('egc_staff_work_info')
        ->select('egc_staff_work_info.*')
        ->where('egc_staff_work_info.staff_id', $id)
        ->where('egc_staff_work_info.status', '!=', 2)
        ->orderBy('egc_staff_work_info.sno','asc')
        ->get();
    
    $data->work_details =$work_details;

    $documents = DB::table('egc_staff_attachment')
    ->where('egc_staff_attachment.staff_id', $id)
    ->select('egc_staff_attachment.*','egc_documents.document_name')
    ->where('egc_staff_attachment.status', '!=', 2)
    ->join('egc_documents', 'egc_staff_attachment.document_id', '=', 'egc_documents.sno')
    ->get();
    $documentData = [];
    foreach ($documents as $doc) {
        $fileNames = json_decode($doc->attachment_name); // Decode the JSON file names
        $documentData[] = [
            'document_name' => $doc->document_name,
            'files' => array_map(function($fileName) use ($doc) {
                return asset("staff_attachments/{$doc->staff_id}/{$doc->document_id}/{$fileName}");
            }, $fileNames)
        ];
    }

    $qualification = DB::table('egc_staff_education_info')
    ->select('egc_staff_education_info.*','egc_education.education as qualification_name')
    ->where('egc_staff_education_info.status', '!=', 2)
    ->where('egc_staff_education_info.staff_id', $id)
    ->join('egc_education', 'egc_staff_education_info.qualification_type', '=', 'egc_education.sno')
    ->get();

    $document_checkList = DB::table('egc_document_checklist')
    ->select('egc_document_checklist.*')
    ->where('egc_document_checklist.status', '!=', 2)
    ->get();
    $document_checklist_snos = $data->document_checklist ? json_decode($data->document_checklist) : [];

      foreach ($document_checkList as $document) {
          if (in_array($document->sno, $document_checklist_snos)) {
              $document->is_checked = 1;
          } else {
              $document->is_checked = 0;
          }
      }
    $data->documents =$documentData;
    $data->qualification =$qualification;
    $data->document_checkList =$document_checkList;
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'staff not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Staff fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  
  public function Status($id, Request $request)
  {

    $staff =  StaffModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_StaffModel = StaffModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function getStaffByBranch(Request $request)
  {
      $department_id = $request->department_id;

      $staff = StaffModel::where('egc_staff.department_id', $department_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function getStaffByRole(Request $request)
  {
      $role_id = $request->role_id;

      $staff = StaffModel::where('egc_staff.job_role_id', $role_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function getStaffByDepart(Request $request)
  {
      $department_id = $request->department_id;

      $staff = StaffModel::where('egc_staff.department_id', $department_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function get_role_by_department(Request $request)
  {
      $department_id = $request->department_id;

      $staff = DB::table('egc_job_role')->where('egc_job_role.department_id', $department_id)
          ->where('egc_job_role.status',0)
          ->orderBy('egc_job_role.job_position_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'role data fetched Successfully',
      ]);
  }



  public function save(Request $request)
{

    $user_id = $request->user()->user_id ?? 1;
  
    DB::transaction(function() use ($request,$user_id){
        $company_id= $request->company_id ?? 0;
        $enyity_id= $request->entity_id ?? 0 ;
        $workflow = ApprovalHierarchyModel::updateOrCreate(
            [
                'company_id'=>$company_id,
                'entity_id'=>$enyity_id,
                'department_id'=>$request->department_id,
                'job_role_id'=>$request->role_id
            ],
            [
              'approve_level'=>json_encode($request->levels),
              'updated_by'=>$user_id,
              'created_by'=>$user_id,
            ]
        ); 
    });

    return response()->json(['status'=>true]);
}


  function staffDataById(Request $request){
    $staff_id = $request->staff_id;

      $staff = StaffModel::select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', $staff_id)
          ->first();

      return response()->json([
          'status' => 200,
          'data' => $staff
      ]);
  }


  public function myApprovals()
  {
      return ApprovalTask::with('leave','employee')
          ->where('approver_staff_id',auth()->user()->staff_id)
          ->where('status',0)
          ->get();
  }

public function reject(Request $request)
{
    $task = ApprovalTask::findOrFail($request->task_id);

    DB::transaction(function() use ($task){

        $task->update([
            'status'=>2,
            'action_date'=>now(),
            'remarks'=>request('remarks')
        ]);

        LeaveRequest::where('sno',$task->request_id)
            ->update(['status'=>2]);
    });

    return response()->json(['message'=>'Rejected']);
}


public function approve(Request $request)
{
    $task = ApprovalTask::where('sno',$request->task_id)
            ->where('approver_staff_id',auth()->user()->staff_id)
            ->firstOrFail();

    DB::transaction(function() use ($task){

        // mark approved
        $task->update([
            'status'=>1,
            'action_date'=>now(),
            'remarks'=>request('remarks')
        ]);

        $leave = LeaveRequest::find($task->request_id);

        // next level?
        $nextLevel = ApprovalTask::where('request_id',$leave->sno)
                        ->where('level_no','>',$task->level_no)
                        ->where('status',0)
                        ->orderBy('level_no')
                        ->first();

        if($nextLevel){
            // move to next approver
            $leave->update([
                'current_level'=>$nextLevel->level_no
            ]);
        }else{
            // FINAL APPROVED
            $leave->update([
                'status'=>1
            ]);
        }
    });

    return response()->json(['message'=>'Approved']);
}


public function createApprovalFlow($leaveRequestId)
{
    $leave = LeaveRequest::find($leaveRequestId);

    $workflow = ApprovalHierarchyModel::where([
        'company_id'=>$leave->company_id,
        'entity_id'=>$leave->entity_id,
        'department_id'=>$leave->department_id,
        'role_id'=>$leave->role_id
    ])->first();

    if(!$workflow){
        throw new \Exception('Approval workflow not configured');
    }

    $levels = $workflow->approve_level ? json_decode($approve_level) : [];
   
    foreach($levels as $level){

        ApprovalTask::create([
            'request_id'=>$leave->sno,
            'level_no'=>$level->level_no,
            'approver_staff_id'=>$level->staff_id
        ]);
    }
}

public function getLeaveApprovalChain(Request $request)
{
    $staffId = $request->staff_id;

    // find staff department & role
    $staff = Staff::find($staffId);

    $workflow = ApprovalMatrix::where([
        'company_id' => $staff->company_id,
        'entity_id' => $staff->entity_id,
        'department_id' => $staff->department_id,
        'role_id' => $staff->role_id
    ])->first();

    if(!$workflow){
        return response()->json(['status'=>false]);
    }

    $levels = json_decode($workflow->levels,true);

    $result=[];

    foreach($levels as $lvl){

        $emp = Staff::find($lvl['staff_id']);

        if($emp){
            $result[]=[
                'staff_name'=>$emp->staff_name,
                'role_name'=>$emp->job_role_name,
                'role_type'=>$emp->role_type ?? 'Manager'
            ];
        }
    }

    return response()->json([
        'status'=>true,
        'data'=>$result
    ]);
}

public function indexMyself(Request $request)
{

$user_id = $request->user()->user_id;
$page = $request->input('page', 1);
$perpage = (int) $request->input('sorting_filter', 25);
$offset = ($page - 1) * $perpage;
$search_filter = $request->search_filter ?? '';
$company_fill = $request->company_fill ?? '';
$entity_fill = $request->entity_fill ?? '';
$department_fill = $request->department_fill ?? '';
$division_fill = $request->division_fill ?? '';
$job_role_fill = $request->job_role_fill ?? '';
$date_filter = $request->dt_fill_issue_rpt ?? '';
$from_date_filter = $request->to_dt_iss_rpt ?? '';
$to_date_filter = $request->to_date_fillter_textbox ?? '';

    
$helper = new \App\Helpers\Helpers();
$general_setting=$helper->general_setting_data();

$staffProfile = StaffModel::where('egc_staff.status', '!=', 2)
    ->select('egc_staff.*',
    'egc_entity.entity_name',
    'egc_entity.entity_short_name',
    'egc_company.company_name',
    'egc_company.company_base_color',
    'egc_entity.entity_base_color',
    'egc_department.department_name',
    'egc_branch.branch_name',
    'egc_division.division_name',
    'egc_job_role.job_position_name as job_role_name',
    )
    ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
    ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
    ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
    ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
    ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
    ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
    ->where('egc_staff.sno',$user_id)->first();
    if($staffProfile->company_type == 1){
            $staffProfile->company_name=$general_setting->title;
            $staffProfile->company_base_color ='#ab2b22';
    }

    
    $tickets = ITTicketModel::with('category')
        ->where('staff_id', $user_id);

        if ($request->has('search_filter') && $request->search_filter != '') {
            $tickets->where('ticket_no', 'LIKE', "%" . $request->search_filter . "%")
                ->orWhere('subject', 'LIKE', "%" . $request->search_filter . "%")
                ->orWhere('description', 'LIKE', "%" . $request->search_filter . "%")
                ->orWhere('priority', 'LIKE', "%" . $request->search_filter . "%");
        }

        // Apply date filter if provided (custom or predefined like "today", "week", "monthly")
        if ($request->has('date_filter')) {
            $date_filter = $request->date_filter;
            if ($date_filter == 'today') {
                $tickets->whereDate('created_at', now()->toDateString());
            } elseif ($date_filter == 'week') {
                $tickets->whereBetween('created_at', [
                    now()->startOfWeek()->toDateString(),
                    now()->endOfWeek()->toDateString()
                ]);
            } elseif ($date_filter == 'monthly') {
                $tickets->whereMonth('created_at', now()->month);
            } elseif ($date_filter == 'custom_date' && $request->has('from_date_filter') && $request->has('to_date_filter')) {
                $tickets->whereBetween('created_at', [
                    date('Y-m-d', strtotime($request->from_date_filter)),
                    date('Y-m-d', strtotime($request->to_date_filter))
                ]);
            }
        }

    $tickets = $tickets
    ->orderByDesc('sno')
    ->paginate($perpage);
            
            
    

    if ($request->ajax()) {
        $data = $tickets->map(function ($item) use ($helper) {

        $messagesCount = DB::table('egc_it_ticket_messages')
            ->where('ticket_id', $item->sno)
            ->where('sender_type', 'it')
            ->where('is_read', 0)
            ->count();
       

            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'ticket_no' => $item->ticket_no,
                'subject' => $item->subject,
                'description' => $item->description,
                'priority' => $item->priority,
                'unread_count' => $messagesCount,
                'priority' => $item->priority,
                'category' => $item->category,
                'attachments' => $item->attachments ? json_decode($item->attachments):[],
                'data' => $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $tickets->currentPage(),
            'last_page' => $tickets->lastPage(),
            'total' => $tickets->total(),
        ]);
    }
  
    $categories = DB::table('egc_it_support_category')->where('status', 0)->orderBy('sno', 'ASC')->get();
//  return $staffProfile;
return view('content.my_self.it_supports.it_supports',[
    'staffProfile' => $staffProfile,
    'categories' => $categories,
    'perpage' => $perpage,
    'search_filter' => $search_filter,
    'company_fill' => $company_fill,
    'date_filter' => $date_filter,
    'job_role_fill' => $job_role_fill,
    'division_fill' => $division_fill,
    'department_fill' => $department_fill,
    'entity_fill' => $entity_fill,
    ]);
}


public function AddItTicketMyself(Request $request)
{

    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

     $request->validate([
        'system_ip'     => 'required',
        'category_id'   => 'required',
        'priority'      => 'required',
        'subject'       => 'required|string|max:255',
        'description'   => 'required|string',
        'attachments.*' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
    ]);
    // Get user ID and staff data
    $user_id = $request->user()->user_id ?? 1;
    $staff = staffModel::where('sno', $request->staff_hidden_id)->first();

    if (!$staff) {
        return response()->json([
            'status' => false,
            'message' => 'Staff not found',
            'error' => 'Staff not found',
        ]);
    }

    DB::transaction(function () use ($request, $user_id, $staff) {
        $uploadedFiles = [];

        $folder = 'it_support';

        if (!Storage::disk('public')->exists($folder)) {
            Storage::disk('public')->makeDirectory($folder);
        }
            // composer require intervention/image
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $file) {

                    // secure unique filename
                    $filename = time() . '_' . Str::uuid() . '.' . $file->extension();

                    $path = $file->storeAs(
                        $folder,
                        $filename,
                        'public'
                    );

                    $uploadedFiles[] = $path;
                }
            }
        // <img src="{{ asset('storage/'.$file) }}" width="120">
            // if ($request->hasFile('attachments')) {

            //     foreach ($request->file('attachments') as $file) {

            //         $filename = time().'_'.Str::uuid().'.jpg'; // force jpg

            //         $image = Image::make($file->getPathname());

            //         // Resize if too big (max width 1600px)
            //         $image->resize(1600, null, function ($constraint) {
            //             $constraint->aspectRatio();
            //             $constraint->upsize();
            //         });

            //         // Save compressed
            //         $tempPath = storage_path('app/temp_'.$filename);

            //         $image->encode('jpg', 80)->save($tempPath);

            //         Storage::disk('public')->put(
            //             $folder.'/'.$filename,
            //             file_get_contents($tempPath)
            //         );

            //         unlink($tempPath);

            //         $uploadedFiles[] = $folder.'/'.$filename;
            //     }
            // }
      
         $ticket_no = $this->generateRequestId();

         $ticket = ITTicketModel::create([
            'staff_id'    => $request->staff_hidden_id,
            'ticket_no'   => $ticket_no,
            'system_ip'   => $request->system_ip,
            'category_id' => $request->category_id,
            'priority'    => $request->priority,
            'subject'     => $request->subject,
            'description' => $request->description,
            'attachments' => json_encode($uploadedFiles),
            'created_by'  => $user_id,
            'updated_by'  => $user_id,
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);

        $this->addTicketLog($ticket->sno,'created','Ticket created',$user_id,'staff');
        
    });

    return response()->json([
        'status' => true,
        'message' => 'It Ticket submitted successfully.',
    ]);
}

  // Helper method to get HR Staff
  private function getHrStaff()
  {
      $HrStaff = staffModel::where('department_id', 1)
          ->where('division_id', 1)
          ->where('job_role_id', 1)
          ->where('status', 0)
          ->orderBy('sno', 'asc')
          ->first();

      return $HrStaff ? $HrStaff->sno : 2;  // Fallback to staff ID 2 if no HR staff is found
  }

  // Helper method to generate a unique request ID
    private function generateRequestId()
    {
        $year  = date('y');
        $month = date('m');

        $last = ITTicketModel::lockForUpdate()
            ->where('ticket_no', 'like', "IT-{$month}-{$year}-%")
            ->orderBy('sno', 'desc')
            ->first();

        if (!$last) {
            return "IT-{$month}-{$year}-0001";
        }

        preg_match('/(\d{4})$/', $last->ticket_no, $matches);

        $next = (int)($matches[1] ?? 0) + 1;

        return "IT-{$month}-{$year}-" . str_pad($next, 4, '0', STR_PAD_LEFT);
    }


    public function viewTicket($id,Request $request)
    {
        $helper = new \App\Helpers\Helpers();

        $user_id = $request->user()->user_id ?? 0;
        try {
            $ticketId = $helper->encrypt_decrypt($id, 'decrypt');
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid ticket'
            ], 404);
        }

        $ticket = ITTicketModel::with('category')
            ->where('sno', $ticketId)
            ->where('staff_id', $user_id) // prevent others viewing
            ->first();

        if (!$ticket) {
            return response()->json([
                'status' => false,
                'message' => 'Ticket not found'
            ], 404);
        }
        
        return response()->json([
            'status' => true,
            'data' => [
                'ticket_no'   => $ticket->ticket_no,
                'subject'     => $ticket->subject,
                'description' => $ticket->description,
                'priority'    => $ticket->priority,
                'status'      => $ticket->status ?? 'Open',
                'category'    => $ticket->category->category_name ?? '-',
                'created_at'  => \Carbon\Carbon::parse($ticket->created_at)->format('d M Y h:i A'),
                'attachments' => $ticket->attachments ? json_decode($ticket->attachments, true) : [],
            ]
        ]);
    }


    public function chat($id, Request $request)
    {
        $user_id = $request->user()->user_id ?? 0;

        $messages = ITTicketMessageModel::where('ticket_id',$id)
            ->orderBy('sno')
            ->get();

        // mark IT messages as read
        ITTicketMessageModel::where('ticket_id',$id)
            ->where('sender_type',$request->receiver_type)
            ->update(['is_read'=>1]);

        return response()->json([
            'status'=>true,
            'messages'=>$messages
        ]);
    }

    public function sendMessage(Request $request)
    {
        $user_id = $request->user()->user_id ?? 0;
        $request->validate([
            'ticket_id'=>'required',
            'message'=>'nullable|string',
            'type'=>'nullable|string',
            'attachment'=>'nullable|image|max:2048'
        ]);

        $path = null;

        if($request->hasFile('attachment')){
            $path = $request->file('attachment')
                ->store('it_support/chat','public');
        }

        ITTicketMessageModel::create([
            'ticket_id'=>$request->ticket_id,
            'sender_id'=>$request->user()->user_id,
            'sender_type'=>$request->type,
            'message'=>$request->message,
            'attachment'=>$path,
            'created_by'=>$user_id,
            'updated_by'=>$user_id,
            'is_read'=>0
        ]);
        $this->addTicketLog($request->ticket_id,'message_sent','New message added',$user_id,$request->type);

        return response()->json(['status'=>true]);
    }


    public function assignItStaff(Request $request)
    {
        
        $assign = ITTicketModel::where('id',$request->id)->update([
            'assigned_to'=>$request->staff_id,
            'status'=>1
        ]);

        $this->addTicketLog($request->id,'assigned','Assigned to IT Staff',$request->staff_id,'it');

    }

    // public function changeStatusTicket(Request $request)
    // {
    //    $ticket= ITTicketModel::where('id',$request->id)->update([
    //         'status'=>$request->status
    //     ]);

    //     $this->addTicketLog($ticket->sno,'status_changed','Status changed to In Progress',$ticket->assigned_to,'it');

    // }

    public function changeStatusTicket(Request $request)
    {
        $request->validate([
            'ticket_id'=>'required',
            'status'=>'required|in:1,2,3'
        ]);

         $helper = new \App\Helpers\Helpers();

        $user_id = $request->user()->user_id ?? 0;
        try {
            $ticketId = $helper->encrypt_decrypt($request->ticket_id, 'decrypt');
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid ticket'
            ], 404);
        }
        
        $ticket = ITTicketModel::findOrFail($ticketId);

        // security → only IT allowed
        // if(!auth()->user()->is_it){
        //     return response()->json(['status'=>false]);
        // }

        // prevent invalid transitions
        $current = $ticket->status;
        $next = (int)$request->status;

        // return response()->json([
        //         'status'=>false,
        //         'message'=>$current . 'next->'.$next
        //     ]);

        $allowed = [
            0 => [1],     // open → assigned
            1 => [2],     // assigned → in progress
            2 => [3],     // in progress → closed
        ];

        if(!in_array($next,$allowed[$current] ?? [])){
            return response()->json([
                'status'=>false,
                'message'=>'Invalid status transition'
            ]);
        }
        if($current==0){
            $assign = ITTicketModel::where('sno',$ticketId)->update([
                'assigned_to'=>$user_id,
                'status'=>1
            ]);
        }

        $ticket->update([
            'status'=>$next,
            'closed_at'=>$next==3 ? now() : null
        ]);

        // log
        $labels = [
            1=>'Assigned',
            2=>'In Progress',
            3=>'Closed'
        ];

       
         $this->addTicketLog($ticket->sno,'status_changed','Status → '.$labels[$next],$user_id,'it');

        return response()->json(['status'=>true]);
    }


    public function timeline($id)
    {
        $helper = new \App\Helpers\Helpers();
        try {
            $ticketId = $helper->encrypt_decrypt($id, 'decrypt');
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid ticket'
            ], 404);
        }
      
        $logs = ITTicketLogModel::where('ticket_id',$ticketId)
            ->orderBy('created_at','asc')
            ->get();

        return response()->json($logs);
    }
  
    public static function addTicketLog($ticketId,$action,$message,$userId,$type='staff')
    {
        ITTicketLogModel::create([
            'ticket_id'=>$ticketId,
            'action'=>$action,
            'message'=>$message,
            'staff_id'=>$userId,
            'created_by'=>$userId,
            'updated_by'=>$userId,
            'user_type'=>$type
        ]);
    }
}