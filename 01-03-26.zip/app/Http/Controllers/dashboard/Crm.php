<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Crm extends Controller
{
    public function index(){
            $user = Auth::user();
            
      return view('content.dashboard.dashboards-crm');
    }
}
