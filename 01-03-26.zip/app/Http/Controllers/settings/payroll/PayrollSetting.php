<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PayrollSettingModel;
use Illuminate\Support\Facades\Validator;

class PayrollSetting extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PayrollSettingModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('setting_key', 'LIKE', "%{$search_filter}%")
                    ->orWhere('description', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'setting_key' => $item->setting_key,
                    'mode_icon' => $item->mode_icon,
                    'setting_value' => $item->setting_value,
                    'description' => $item->description,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.payroll.payroll_setting.payroll_setting',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = PayrollSettingModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {
       
        $validator = Validator::make( $request->all(), [
            'setting_key' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $setting_key       = $request->setting_key;
            $setting_value       = $request->setting_value;
            $description          = $request->description;
             $user_id = $request->user()->user_id ?? 1;
            $chk = PayrollSettingModel::where( 'setting_key', $setting_key )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Payroll Setting is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = PayrollSettingModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

    
                $add_branchtype = new PayrollSettingModel();
                $add_branchtype->setting_key       = $setting_key;
                $add_branchtype->setting_value       = $setting_value;
                $add_branchtype->description       = $description;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Payroll Setting added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payroll Setting!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {
            // return $request;
        $validator = Validator::make( $request->all(), [
            'setting_key' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $setting_key       = $request->setting_key;
            $setting_value       = $request->setting_value;
            $description       = $request->description;
            $document_id       = $request->edit_id;
            $user_id = $request->user()->user_id ?? 1;

            $upd_PayrollSettingModel =  PayrollSettingModel::where( 'sno', $document_id )->first();

            $chk = PayrollSettingModel::where( 'setting_key', $setting_key )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Payroll Setting is exist!'
                ] );
                return redirect()->back();
            }

            $upd_PayrollSettingModel->setting_key  = $setting_key;
            $upd_PayrollSettingModel->setting_value  = $setting_value;
            $upd_PayrollSettingModel->description  = $description;
            $upd_PayrollSettingModel->updated_by  = $user_id;
            $upd_PayrollSettingModel->update();

            if ( $upd_PayrollSettingModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Payroll Setting Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Payroll Setting!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_PayrollSettingModel = PayrollSettingModel::where( 'sno', $id )->first();
        $upd_PayrollSettingModel->status  = 2;
        $upd_PayrollSettingModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Payroll Setting Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_PayrollSettingModel =  PayrollSettingModel::where( 'sno', $id )->first();
        $upd_PayrollSettingModel->status = $request->input( 'status', 0 );
        $upd_PayrollSettingModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
