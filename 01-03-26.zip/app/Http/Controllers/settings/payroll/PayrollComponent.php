<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PayrollComponentModel;
use Illuminate\Support\Facades\Validator;

class PayrollComponent extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PayrollComponentModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('component_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('component_type', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'component_name' => $item->component_name,
                    'component_code' => $item->component_code,
                    'is_taxable' => $item->is_taxable,
                    'is_statutory' => $item->is_statutory,
                    'is_prorated' => $item->is_prorated,
                    'component_type' => $item->component_type,
                    'show_in_payslip' => $item->show_in_payslip,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.payroll.payroll_component.payroll_component',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = PayrollComponentModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {
        // return $request;
        $validator = Validator::make( $request->all(), [
            'component_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $component_name       = $request->component_name;
            $component_code       = $request->component_code;
            $component_type          = $request->component_type;
            $is_taxable       = $request->is_taxable ? 1 : 0;
            $is_statutory       = $request->is_statutory ? 1 : 0;
            $is_prorated       = $request->is_prorated ? 1 : 0;
            $show_in_payslip          = $request->show_in_payslip ? 1 : 0;
            $user_id = $request->user()->user_id ?? 1;
            $chk = PayrollComponentModel::where( 'component_name', $component_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Payroll Component is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = PayrollComponentModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                

                $add_branchtype = new PayrollComponentModel();
                $add_branchtype->component_name       = $component_name;
                $add_branchtype->component_code       = $component_code;
                $add_branchtype->component_type       = $component_type;
                $add_branchtype->is_taxable       = $is_taxable;
                $add_branchtype->is_statutory       = $is_statutory;
                $add_branchtype->is_prorated       = $is_prorated;
                $add_branchtype->show_in_payslip          = $show_in_payslip;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Payroll Component added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payroll Component!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'component_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $component_name       = $request->component_name;
            $component_code       = $request->component_code;
            $component_type          = $request->component_type;
            $is_taxable       = $request->is_taxable ? 1 : 0;
            $is_statutory       = $request->is_statutory ? 1 : 0;
            $is_prorated       = $request->is_prorated ? 1 : 0;
            $show_in_payslip          = $request->show_in_payslip ? 1 : 0;
            $document_id       = $request->edit_id;
            $user_id = $request->user()->user_id ?? 1;

            $upd_PayrollComponentModel =  PayrollComponentModel::where( 'sno', $document_id )->first();

            $chk = PayrollComponentModel::where( 'component_name', $component_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Payroll Component is exist!'
                ] );
                return redirect()->back();
            }

            $upd_PayrollComponentModel->component_name  = $component_name;
            $upd_PayrollComponentModel->component_code  = $component_code;
            $upd_PayrollComponentModel->is_taxable  = $is_taxable;
            $upd_PayrollComponentModel->is_statutory  = $is_statutory;
            $upd_PayrollComponentModel->is_prorated  = $is_prorated;
            $upd_PayrollComponentModel->show_in_payslip  = $show_in_payslip;
            $upd_PayrollComponentModel->component_type  = $component_type;
            $upd_PayrollComponentModel->updated_by                 = $user_id;
            $upd_PayrollComponentModel->update();

            if ( $upd_PayrollComponentModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Payroll Component Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Payroll Component!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_PayrollComponentModel = PayrollComponentModel::where( 'sno', $id )->first();
        $upd_PayrollComponentModel->status  = 2;
        $upd_PayrollComponentModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Payroll Setting Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_PayrollComponentModel =  PayrollComponentModel::where( 'sno', $id )->first();
        $upd_PayrollComponentModel->status = $request->input( 'status', 0 );
        $upd_PayrollComponentModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
