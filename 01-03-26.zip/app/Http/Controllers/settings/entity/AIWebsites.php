<?php

namespace App\Http\Controllers\settings\entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\AIWebsiteModel;



class AIWebsites extends Controller
{
  

public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $level = AIWebsiteModel::where('status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('ai_website_name', 'LIKE', "%{$search_filter}%");
                      
              });
          }
        $level=$level->orderBy('sno', 'desc')
         ->paginate($perpage);

          

        if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {
               $logo = asset('settings/ai/' . $item->logo ?? '');
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'ai_website_name' => $item->ai_website_name,
                    'ai_website_url' => $item->ai_website_url,
                    'ai_website_logo' => $logo,
                    'ai_website_desc' => $item->ai_website_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }
      
        return view('content.settings.entity.ai_websites.ai_websites', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function list()
    {
        $knowledge_level = AIWebsiteModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $knowledge_level,
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'ai_website_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $ai_website_name = $request->ai_website_name;
            $ai_website_url = $request->ai_website_url;
            $ai_website_desc = $request->ai_website_desc;
            $ai_website_slug = $request->ai_website_slug ? json_encode($request->ai_website_slug) : null;

            $user_id = $request->user()->user_id ?? 1;
            $chk = AIWebsiteModel::where('ai_website_name', $ai_website_name)->where('status', '!=', 2)->first();
            $urlchk = AIWebsiteModel::where('ai_website_url', $ai_website_url)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!',
                ]);
            }else if($urlchk){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'URL has been  already created!',
                ]);
             }else {


                $add_category = new AIWebsiteModel();
                $add_category->ai_website_name = $ai_website_name;
                $add_category->ai_website_url = $ai_website_url;
                $add_category->ai_website_desc = $ai_website_desc;
                $add_category->ai_website_slug = $ai_website_slug;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                if ($request->hasFile('ai_image')) {
                    $file = $request->file('ai_image');
                    $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('settings/ai/'), $fileName);
                    $add_category->logo = $fileName;
                }

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'AI Website added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the AI Website!',
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'AI Website Created successfully!');
        }
    }

    public function Edit($id)
    {
        $credential = AIWebsiteModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $credential,
        ], 200);
    }

    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'ai_website_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $id = $request->input('edit_ai_website_id');
            $ai_website_name = $request->ai_website_name;
            $ai_website_url = $request->ai_website_url_edit;
            $ai_website_desc = $request->ai_website_desc;
             $ai_website_slug = $request->ai_website_slug_edit ? json_encode($request->ai_website_slug_edit) : null;


            $upd_CourseCategoryModel = AIWebsiteModel::where('sno', $id)->first();

            $chk = AIWebsiteModel::where('ai_website_name', $ai_website_name)->where('status', '!=', 2)->where('sno', '!=', $id)->first();
            $urlChk = AIWebsiteModel::where('ai_website_url', $ai_website_url)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already created!',
                    ]);
                } else {
                }
            } else if ($urlChk) {
                if ($urlChk->sno != $id) {
                   session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'URL has been  already created!',
                    ]);
                }
            }else{
                $upd_CourseCategoryModel->ai_website_name = $ai_website_name;
                $upd_CourseCategoryModel->ai_website_url = $ai_website_url;
                $upd_CourseCategoryModel->ai_website_desc = $ai_website_desc;
                $upd_CourseCategoryModel->ai_website_slug = $ai_website_slug;
                if ($request->hasFile('ai_edit_image')) {
                    $file = $request->file('ai_edit_image');
                    $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                    $path = 'settings/ai/';
                    $file->move(public_path($path), $fileName);
                    $upd_CourseCategoryModel->logo = $fileName;
                }
                $upd_CourseCategoryModel->update();
                if ($upd_CourseCategoryModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'AI Website Updated Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the AI Website!',
                    ]);
                }
            }
           
        }
        return redirect()->back()->with('success', 'AI Website Updated successfully!');
        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = AIWebsiteModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel = AIWebsiteModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
