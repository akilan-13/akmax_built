<?php
namespace App\Http\Middleware;

use Closure;
use App\Models\AiUsageModel;

class EnforceAiLimit
{
    public function handle($request, Closure $next)
    {
        $limit = config('ai-models.monthly_limit');

        $spent = AiUsageModel::whereMonth('created_at', now()->month)
            ->sum('total_cost');

        if ($spent >= $limit) {
            return response()->json([
                'error' => 'Hugging Face FREE limit ($0.10) exceeded'
            ], 429);
        }

        return $next($request);
    }
}