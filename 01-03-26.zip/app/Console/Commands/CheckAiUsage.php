<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\AiUsage;

class CheckAiUsage extends Command
{
    protected $signature = 'ai:check-usage';

    public function handle()
    {
        $limit = config('ai-models.monthly_limit');
        $spent = AiUsage::whereMonth('created_at', now()->month)->sum('cost');

        foreach (config('ai-models.alert_thresholds') as $level => $percent) {
            if ($spent >= $limit * $percent) {
                // send webhook/email/slack
                logger("AI Usage {$level}: {$spent}");
            }
        }
    }

    // $schedule->command('ai:check-usage')->hourly();
}
