<?php
namespace App\Services\HuggingFace;

use App\Models\AiModel;
use App\Models\AiUsageModel;

class UsageTracker
{
    public function track(string $modelKey, array $usage): void
    {
        $model = AiModel::where('model_key', $modelKey)->firstOrFail();

        $costs = app(CostCalculator::class)->calculate(
            $model,
            $usage['prompt_tokens'],
            $usage['completion_tokens']
        );

        AiUsageModel::create([
            'ai_model_id' => $model->sno,
            'prompt_tokens' => $usage['prompt_tokens'],
            'completion_tokens' => $usage['completion_tokens'],
            'input_cost' => $costs['input_cost'],
            'output_cost' => $costs['output_cost'],
            'total_cost' => $costs['total_cost'],
            'usage_date' => now()->toDateString(),
        ]);
    }
}
