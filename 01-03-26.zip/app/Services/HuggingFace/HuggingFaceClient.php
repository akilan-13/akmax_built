<?php
namespace App\Services\HuggingFace;

use Illuminate\Support\Facades\Http;

class HuggingFaceClient
{
    public function chat(string $model, array $messages): array
    {
        // $response = Http::withToken(config('services.huggingface.token'))
        //     ->post('https://router.huggingface.co/v1/chat/completions', [
        //         'model' => $model,
        //         'messages' => $messages,
        //     ]);

        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions'; 
        $primaryApiKey = config('services.huggingface.token'); 
        $maxTokens = 1000;
        $aiTimeout = 60; 
        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ 
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
        ])->post($primaryApiUrl, [
            'model' => $model, 
            // 'provider' => 'nebius',
            'messages' =>  $messages,
            'max_tokens' => $maxTokens, 
            'stream' => false,
            'extra_body' => [
                'prompt_cache_retention' => '1h' 
            ]
        ]);

        return $response->json();
        
    }
}
