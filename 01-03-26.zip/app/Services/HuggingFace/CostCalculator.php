<?php
namespace App\Services\HuggingFace;

use App\Models\AiModel;

class CostCalculator
{
    public function calculate(
        AiModel $model,
        int $promptTokens,
        int $completionTokens
    ): array {
        $inputCost = ($promptTokens / 1_000_000)
            * $model->input_price_per_million;

        $outputCost = ($completionTokens / 1_000_000)
            * $model->output_price_per_million;

        return [
            'input_cost' => $inputCost,
            'output_cost' => $outputCost,
            'total_cost' => $inputCost + $outputCost,
        ];
    }
}
