<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffModel extends Model
{
  use HasFactory;

  protected $table = 'egc_staff';
  protected $primaryKey = 'sno';
  public $timestamps = true;

  protected $fillable = [
    'staff_id',
    'timechamp_id',
    'erp_staff_id',
    'company_type',
    'company_id',
    'entity_id',
    'branch_id',
    'department_id',
    'division_id',
    'role_id',
    'exp_type',
    'total_experience',
    'total_company_shift',
    'staff_name',
    'mobile_no',
    'is_Course',
    'applied_company_ids',
    'course_tag',
    'alternative_no',
    'email_id',
    'gender',
    'dob',
    'discount',
    'coupon_code',
    'login_access',
    'date_of_joining',
    'contact_person_name',
    'contact_person_no',
    'martial_status',
    'address',
    'residential_address',
    'location_url',
    'latitude',
    'longitude',
    'completion_percentage',
    'staff_image',
    'source_details',
    'source_id',
    'user_name',
    'attachment',
    'knowledge_tag',
    'nick_name',
    'applied_position',
    'password',
    'credential',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
    'shift_time_id',
    'basic_salary',
    'per_hour_cost',
    'dep_reason',
    'notice_end_date',
    'contact_person_relation',
    'notice_start_date',
    'welcome_status',
    'staff_last_date',
    'social_media_details',
    'application_details',
    'mother_tongue',
    'document_checklist',
    'job_role_id',
    'languages',
    'hobby',
  ];
}
