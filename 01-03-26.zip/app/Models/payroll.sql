
-- payroll_settings

CREATE TABLE payroll_settings (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100),
    setting_value VARCHAR(255),
    description VARCHAR(255),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- Examples
-- late_allowed_count = 4
-- lop_per_late = 0.25
-- currency = INR
-- rounding_method = nearest
-- ________________________________________

-- pay_components

CREATE TABLE pay_components (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    component_name VARCHAR(100),
    component_code VARCHAR(50),
    component_type ENUM('EARNING','DEDUCTION'),
    is_taxable TINYINT DEFAULT 0,
    is_statutory TINYINT DEFAULT 0,
    is_prorated TINYINT DEFAULT 0,
    show_in_payslip TINYINT DEFAULT 1,

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- Examples:
-- •	BASIC
-- •	HRA
-- •	PF
-- •	ESI
-- •	PT
-- •	INCENTIVE
-- •	TRAVEL_ALLOWANCE
-- •	LOP


-- salary_structures

CREATE TABLE salary_structures (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    structure_name VARCHAR(100),
    effective_from DATE,
    effective_to DATE NULL,

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- salary_structure_components

CREATE TABLE salary_structure_components (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    salary_structure_sno INT,
    component_sno INT,
    calculation_type ENUM('FIXED','PERCENTAGE','FORMULA'),
    value DECIMAL(10,2),
    percentage_of_component_sno INT NULL,

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);


-- employee_salary_mapping

CREATE TABLE egc_staff_salary_mapping (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    staff_id INT,
    salary_structure_sno INT,
    effective_from DATE,
    effective_to DATE NULL,
    change_reason VARCHAR(255),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- ✔ Salary change = new row
-- ✔ Old salary preserved forever


-- attendance_rules

CREATE TABLE attendance_rules (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100),
    rule_type ENUM('LATE','ABSENT'),
    threshold_value INT,
    lop_days DECIMAL(5,2),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- Example:
-- •	4 late = 1 LOP


-- statutory_rules

CREATE TABLE statutory_rules (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    statutory_name ENUM('PF','ESI','PT'),
    employee_percentage DECIMAL(5,2),
    employer_percentage DECIMAL(5,2),
    wage_limit DECIMAL(10,2),
    effective_from DATE,
    effective_to DATE NULL,

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- ✔ Government changes = insert new row
-- ✔ Old payroll stays intact


-- incentive_rules

CREATE TABLE incentive_rules (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    department_sno INT,
    component_sno INT,
    calculation_type ENUM('FIXED','PERCENTAGE'),
    value DECIMAL(10,2),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- employee_incentives

CREATE TABLE employee_incentives (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    component_sno INT,
    incentive_month INT,
    incentive_year INT,
    amount DECIMAL(10,2),
    approval_status ENUM('PENDING','APPROVED','REJECTED'),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- employee_appraisals

CREATE TABLE employee_appraisals (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    appraisal_type ENUM('PERCENTAGE','AMOUNT'),
    appraisal_value DECIMAL(10,2),
    effective_from DATE,
    effective_to DATE,
    reason VARCHAR(255),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- ✔ Yearly (Mar / Sep)
-- ✔ Mid-year join → prorated in payroll logic
-- ✔ No overwrite ever

-- employee_expenses

CREATE TABLE employee_expenses (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    expense_type VARCHAR(50),
    expense_date DATE,
    amount DECIMAL(10,2),
    proof_file VARCHAR(255),
    approval_status ENUM('PENDING','APPROVED','REJECTED'),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- ✔ Approved → added to payroll dynamically


-- payroll_runs

CREATE TABLE payroll_runs (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    payroll_month INT,
    payroll_year INT,
    run_status ENUM('DRAFT','FINALIZED'),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- payroll_entries

CREATE TABLE payroll_entries (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    payroll_run_sno INT,
    employee_sno INT,
    gross_salary DECIMAL(10,2),
    total_deductions DECIMAL(10,2),
    net_salary DECIMAL(10,2),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- payroll_entry_components

CREATE TABLE payroll_entry_components (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    payroll_entry_sno INT,
    component_sno INT,
    amount DECIMAL(10,2),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

-- ✔ Payslip data is locked forever

-- payslip_logs

CREATE TABLE payslip_logs (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    payroll_entry_sno INT,
    generated_at DATETIME,
    generated_by INT,

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);

CREATE TABLE employee_payroll_profile (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    pay_cycle ENUM('MONTHLY'),
    payroll_status ENUM('ACTIVE','HOLD'),
    tax_regime ENUM('OLD','NEW'),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);


CREATE TABLE employee_bank_details (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    bank_account_no VARCHAR(50),
    bank_name VARCHAR(100),
    ifsc_code VARCHAR(20),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);


CREATE TABLE employee_statutory_details (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    employee_sno INT,
    uan_no VARCHAR(50),
    esi_no VARCHAR(50),
    pan_no VARCHAR(20),
    aadhar_no VARCHAR(20),

    created_by INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by INT DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status INT DEFAULT 0
);


-- You already approved this structure:
-- CREATE TABLE employee_salary_mapping (
--     sno INT AUTO_INCREMENT PRIMARY KEY,
--     employee_sno INT,
--     salary_structure_sno INT,
--     effective_from DATE,
--     effective_to DATE NULL,
--     change_reason VARCHAR(255),

--     created_by INT DEFAULT 0,
--     created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
--     updated_by INT DEFAULT 0,
--     updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
--     status INT DEFAULT 0
-- );
