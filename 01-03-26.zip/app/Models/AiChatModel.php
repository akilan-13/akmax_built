<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AiChatModel extends Model
{
    use HasFactory;

    protected $table = 'egc_ai_chats';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'user_id',
        'ai_model_id',
        'user_message',
        'ai_reply',
        'prompt_tokens',
        'completion_tokens',
        'total_cost',
        'created_by',
        'updated_by',
    ];

        public function model()
    {
        return $this->belongsTo(AiModel::class, 'ai_model_id', 'sno');
    }

    public function user()
    {
        return $this->belongsTo(StaffModel::class ,'user_id', 'sno');
    }

}
