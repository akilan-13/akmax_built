<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingPlannerModel extends Model {
    use HasFactory;
    public $table      = 'egc_training_planner';
    public $primaryKey = 'sno';

    protected $fillable = [
        'training_planner_id', 'branch_id', 'department_id', 'staff_id', 'job_role_id', 'training_planner_name', 'training_mode',
        'trainer', 'trainer_name', 'training_duration', 'schedule_date', 'training_desc', 'all_check',
        'staff_check', 'created_at', 'created_by', 'updated_at', 'updated_by', 'status'
    ];

}
