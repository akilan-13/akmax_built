<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionBankModel extends Model
{
    use HasFactory;
    public $table      = 'egc_question_bank';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'bank_name',
        'category_id',
        'level_id',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
