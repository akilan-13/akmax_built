<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamModel extends Model
{

    use HasFactory;
    public $table = 'egc_exam';
    public $primaryKey = 'sno';

    protected $fillable = [
        'exam_id',
        'branch_id',
        'created_date',
        'exam_name',
        'exam_category',
        'exam_based_on',
        'course_id',
        'chapter_id',
        'section_id',
        'title_name',
        'question_bank_id',
        'exam_type',
        'no_of_questions',
        'exam_duration',
        'exam_start_date',
        'exam_end_date',
        'exam_attempt',
        'no_of_attempt',
        'positive_mark_per_quest',
        'negative_mark_per_quest',
        'total_marks',
        'passing_marks',
        'exam_batch',
        'exam_hint',
        'hint_text',
        'exam_explanation',
        'explanation_text',
        'question_generate',
        'display_total_score',
        'display_report',
        'certificate',
        'certificate_template',
        'exam_mode',
        'exam_mode_amount',
        'exam_mode_points',
        'knowledge_level_id',
        'exam_description',
        'thumbnail_image',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
