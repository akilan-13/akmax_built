<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappTemplateModel extends Model
{
    use HasFactory;
    public $table = 'egc_whatsapp_template';
    public $primaryKey = 'sno';

    protected $fillable = [
        'whatsapp_template_id',
        'branch_id',
        'whatsapp_title_name',
        'whatsapp_template_name',
        'template_use_modals',
        'template_content',
        'start_date',
        'end_date',
        'waba_template_id',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
