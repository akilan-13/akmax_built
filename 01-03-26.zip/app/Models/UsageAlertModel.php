<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UsageAlertModel extends Model
{
    use HasFactory;

    protected $table = 'egc_usage_alerts';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'level',
        'threshold',
        'sent_at',
        'total_tokens',
        'input_cost',
        'output_cost',
        'total_cost',
        'usage_date',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

}
