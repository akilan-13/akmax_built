<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamSectionModel extends Model
{
    use HasFactory;

    public $table = 'egc_exam_section';
    public $primaryKey = 'sno';

    protected $fillable = [
        'section_name',
        'section_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
