<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AIWebsiteModel extends Model
{
    use HasFactory;

    protected $table = 'egc_ai_websites';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'ai_website_desc',
        'ai_website_slug',
        'ai_website_name',
        'ai_website_url',
        'logo',
        'status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

}
