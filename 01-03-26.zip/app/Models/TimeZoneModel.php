<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TimeZoneModel extends Model
{
    use HasFactory;
    public $table      = "egc_countrytimezones";
    public $primaryKey = 'sno';


    protected $fillable = [
        'country_id',
        'time_zone',
        'utc_offset',
        'description'
    ];
}
