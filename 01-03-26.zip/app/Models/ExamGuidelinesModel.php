<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamGuidelinesModel extends Model
{
    use HasFactory;
    public $table = 'egc_exam_guidelines';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'exam_guidelines',
        'created_by',
        'updated_by',
        'status',
    ];
}
