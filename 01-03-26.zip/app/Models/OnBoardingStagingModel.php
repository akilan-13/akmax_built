<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OnBoardingStagingModel extends Model
{
    use HasFactory;
    public $table      = "egc_onboarding_staging";
    public $primaryKey = 'sno';


    protected $fillable = [
        'onboarding_staging_name',
        'schedule_duration',
        'duration_type',
        'score_check',
        'evaluation_check',
        'emoji',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}