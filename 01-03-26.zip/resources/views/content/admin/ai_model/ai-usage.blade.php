@extends('layouts/layoutMaster')

@section('content')
<h2>AI Usage Dashboard</h2>

<!-- <p>
    <strong>Monthly Spend:</strong>
    ${{ number_format($monthlySpend, 6) }}
    /
    ${{ number_format($limit, 2) }}
</p> -->

<p>
    <strong>Plan:</strong> Hugging Face FREE<br>
    <strong>Monthly Spend:</strong>
    ${{ number_format($monthlySpend, 6) }}
    / ${{ number_format($limit, 2) }}
</p>

<table width="100%" border="1" cellpadding="8">
    <thead>
        <tr>
            <th>Date</th>
            <th>Model</th>
            <th>Prompt Tokens</th>
            <th>Completion Tokens</th>
            <th>Total Cost ($)</th>
        </tr>
    </thead>

    <tbody>
        @forelse ($usages as $usage)
            <tr>
                <td>{{ $usage->usage_date }}</td>
                <td>{{ $usage->model->model_key }}</td>
                <td>{{ $usage->prompt_tokens }}</td>
                <td>{{ $usage->completion_tokens }}</td>
                <td>{{ number_format($usage->total_cost, 6) }}</td>
            </tr>
        @empty
            <tr>
                <td colspan="5">No usage found.</td>
            </tr>
        @endforelse
    </tbody>
</table>

<br>

{{ $usages->links() }}
@endsection
