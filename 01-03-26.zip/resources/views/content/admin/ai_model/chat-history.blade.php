@extends('layouts/layoutMaster')

@section('content')
<h2>Your Chat History</h2>

<table border="1" cellpadding="10" width="100%">
    <thead>
        <tr>
            <th>Date</th>
            <th>Model</th>
            <th>Message</th>
            <th>Reply</th>
            <th>Tokens</th>
            <th>Cost</th>
        </tr>
    </thead>

    <tbody>
        @if(isset($chats))
        @foreach($chats as $chat)
        <tr>
            <td>{{ \Carbon\Carbon::parse($chat->created_on)->format('Y-m-d H:i') }}</td>
            <td>{{ $chat->model->model_key }}</td>
            <td>{{ $chat->user_message }}</td>
            <td>{{ $chat->ai_reply }}</td>
            <td>
                {{ $chat->prompt_tokens }} + {{ $chat->completion_tokens }}
            </td>
            <td>${{ number_format($chat->total_cost, 6) }}</td>
        </tr>
        @endforeach
        @endif
    </tbody>
</table>

@endsection
