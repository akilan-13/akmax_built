@extends('layouts/layoutMaster')
@section('content')
<style>
.chat-wrapper {
    max-width: 900px;
    margin: 40px auto;
    background: #0f172a;
    color: #e5e7eb;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    height: 80vh;
}

.chat-header {
    padding: 16px;
    font-size: 18px;
    font-weight: 600;
    border-bottom: 1px solid #1e293b;
}

.chat-messages {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
}

.message {
    max-width: 75%;
    margin-bottom: 16px;
    padding: 12px 16px;
    border-radius: 12px;
    line-height: 1.5;
    white-space: pre-wrap;
}

.message.user {
    background: #2563eb;
    align-self: flex-end;
}

.message.ai {
    background: #1e293b;
    align-self: flex-start;
}

.chat-input {
    border-top: 1px solid #1e293b;
    padding: 16px;
    display: flex;
    gap: 10px;
}

.chat-input textarea {
    flex: 1;
    resize: none;
    border-radius: 8px;
    padding: 10px;
    border: none;
    outline: none;
    font-size: 14px;
}

.chat-input button {
    background: #22c55e;
    border: none;
    color: #022c22;
    padding: 0 20px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
}

.chat-input button:disabled {
    background: #64748b;
    cursor: not-allowed;
}

.loader {
    font-size: 13px;
    opacity: 0.6;
    margin-bottom: 10px;
}
</style>

<div class="chat-wrapper">
    <div class="chat-header">
        🤖 AI Chat (HF Free Tier)
    </div>

    <div id="messages" class="chat-messages"></div>

    <div class="chat-input">
        <textarea id="input" rows="2" placeholder="Type your message..."></textarea>
        <button id="send">Send</button>
    </div>
</div>

<script>
const sendBtn = document.getElementById('send');
const input = document.getElementById('input');
const messages = document.getElementById('messages');

function addMessage(text, type) {
    const div = document.createElement('div');
    div.className = `message ${type}`;
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

sendBtn.onclick = async () => {
    const text = input.value.trim();
    if (!text) return;

    addMessage(text, 'user');
    input.value = '';
    sendBtn.disabled = true;

    const loader = document.createElement('div');
    loader.className = 'loader';
    loader.textContent = 'AI is thinking...';
    messages.appendChild(loader);

    try {
        const res = await fetch('{{ url('/ai/chat') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ message: text })
        });

        const data = await res.json();
        loader.remove();

        if (!res.ok) {
            addMessage(data.message || data.error || 'Error', 'ai');
        } else {
            addMessage(data.reply, 'ai');
        }

    } catch (e) {
        loader.remove();
        addMessage('Network error. Try again.', 'ai');
    }

    sendBtn.disabled = false;
};

input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendBtn.click();
    }
});
</script>
@endsection
