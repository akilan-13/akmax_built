import 'tui-image-editor/dist/tui-image-editor.css';
import ImageEditor from 'tui-image-editor';

window.initImageEditor = function () {
  const editor = new ImageEditor('#image-editor', {
    includeUI: {
      loadImage: {
        path: '',
        name: 'Blank'
      },
      menu: ['crop', 'flip', 'rotate', 'draw', 'shape', 'icon', 'text', 'filter'],
      initMenu: 'filter',
      uiSize: {
        width: '100%',
        height: '700px'
      },
      menuBarPosition: 'left'
    },
    cssMaxWidth: 1000,
    cssMaxHeight: 700,
    selectionStyle: {
      cornerSize: 20,
      rotatingPointOffset: 70
    }
  });

  window.imageEditor = editor;
};
