/**
 * Form Editors
 */

'use strict';

(function () {
  // Snow Theme
  // --------------------------------------------------------------------
  const snow_editor = document.getElementById('snow-editor');
  if (snow_editor) {
    const snowEditor = new Quill('#snow-editor', {
      bounds: '#snow-editor',
      modules: {
        formula: true,
        toolbar: '#snow-toolbar'
      },
      theme: 'snow'
    });
  }

  // Bubble Theme
  // --------------------------------------------------------------------
  const bubble_editor = document.getElementById('bubble-editor');
  if (snow_editor) {
    const bubbleEditor = new Quill('#bubble-editor', {
      modules: {
        toolbar: '#bubble-toolbar'
      },
      theme: 'bubble'
    });
  }

  // Full Toolbar
  // --------------------------------------------------------------------
  const full_editor = document.getElementById('full-editor');
  if (full_editor) {
    const fullToolbar = [
      [
        {
          font: []
        },
        {
          size: []
        }
      ],
      ['bold', 'italic', 'underline', 'strike'],
      [
        {
          color: []
        },
        {
          background: []
        }
      ],
      [
        {
          script: 'super'
        },
        {
          script: 'sub'
        }
      ],
      [
        {
          header: '1'
        },
        {
          header: '2'
        },
        'blockquote',
        'code-block'
      ],
      [
        {
          list: 'ordered'
        },
        {
          list: 'bullet'
        },
        {
          indent: '-1'
        },
        {
          indent: '+1'
        }
      ],
      [{ direction: 'rtl' }],
      ['link', 'image', 'video', 'formula'],
      ['clean']
    ];
    const fullEditor = new Quill('#full-editor', {
      bounds: '#full-editor',
      placeholder: 'Type Something...',
      modules: {
        formula: true,
        toolbar: fullToolbar
      },
      theme: 'snow'
    });
  }
})();
