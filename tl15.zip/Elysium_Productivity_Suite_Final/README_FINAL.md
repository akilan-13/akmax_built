# Elysium ERP — Productivity & Knowledge Suite — Final Production Package

This package is the final assembled ERP implementation based on the supplied Elysium ERP Suite prototype, `erp-data.js`, module prototypes, runtime assets, and the approved EGPK PDD.

## Module structure

- Dashboard
- ContactBook
- BookMarks
- PassWallet
- Knowledge Panel
- Portals & Apps
- Meetings
- Tasks
- Sticky Notes
- My Money
- Events
- Documents
- Reports
- Admin

## ERP integration

All screens extend the existing `layouts/layoutMaster` and use the Elysium visual language: navy, purple, gold, compact Bootstrap tables, MDI icons, responsive cards and AJAX-driven module data.

The supplied PDD defines the formal five-module baseline as ContactBook, BookMarks, PassWallet, Knowledge Panel and InHouse Portals & Apps. The prototype also supplied Meetings, Tasks, Sticky Notes, My Money, Events, Documents, Reports and Admin; these are included as first-class productivity tools in this package.

## Install

1. Run `database/sql/egpk_productivity_suite_final.sql` on the target MySQL 8 database.
2. Add `routes/egpk_productivity.php` to the authenticated ERP route registration (or `require` it from the existing web routes file).
3. Copy `app/Models/Productivity`, `app/Services/Productivity`, and `app/Http/Controllers/productivity` into the ERP application.
4. Copy `resources/views/content/productivity` and `resources/js/productivity` into the ERP resources tree.
5. Add `config/productivity.php` and merge `.env.example.egpk` values into the production environment.
6. Run the normal ERP `npm run build` / Vite deployment flow.
7. Run `php artisan route:clear`, `php artisan config:clear`, and the application's normal cache warm-up commands.

## Storage

Documents, Knowledge media and optional PassWallet attachments use the configured `s3` disk in the production controllers. The PDD expects S3-backed media and encrypted-at-rest storage. Configure the existing ERP AWS/S3 credentials rather than hard-coding keys.

## PassWallet

PassWallet requires the existing ERP user's password hash for step-up verification. Secret values never appear in list responses. Reveal/copy/change/share actions are audited. AWS KMS configuration should be enabled for production encryption; do not use a local fallback for a real production environment.

## Gmail import

The included ContactBook controller supports a user-authorized Google People API token path. The host ERP should wire its OAuth consent/callback flow using the `EGPK_GOOGLE_*` configuration values and pass the short-lived access token to the snapshot-import endpoint.

## Security expectations

- Server-side object-level authorization remains mandatory.
- Private/company/group visibility and explicit share grants are enforced by `ProductivityAccessService`.
- Cross-company sharing follows the approval flow in the share controller.
- My Money is intentionally private and is rejected by the generic sharing endpoint.
- Password secrets are not returned to global search, reports, normal detail responses, or exports.
- File uploads are constrained by MIME/extension/size validation; production deployment should add the existing ERP antivirus/S3 scanning pipeline required by the PDD.

## Validation performed

The release build includes PHP syntax checks, JavaScript syntax checks and route/controller method consistency checks. Live DB, AWS, Redis, Meilisearch and OAuth configuration cannot be verified in this isolated workspace and must be exercised in the staging ERP environment.
