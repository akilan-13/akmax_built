SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS egpk_contact_categories (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  category_name VARCHAR(100) NOT NULL,
  color VARCHAR(20) NOT NULL DEFAULT '#1F618D',
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_cb_cat_company (company_id), KEY idx_cb_cat_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contacts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  salutation VARCHAR(20) NULL,
  person_name VARCHAR(180) NOT NULL,
  designation VARCHAR(150) NULL,
  organisation VARCHAR(180) NULL,
  department VARCHAR(150) NULL,
  phone_primary VARCHAR(40) NULL,
  phone_alternate VARCHAR(40) NULL,
  email_primary VARCHAR(180) NULL,
  email_secondary VARCHAR(180) NULL,
  city VARCHAR(100) NULL,
  address TEXT NULL,
  website VARCHAR(255) NULL,
  category_id BIGINT UNSIGNED NOT NULL,
  notes TEXT NULL,
  profile_photo VARCHAR(500) NULL,
  is_starred TINYINT(1) NOT NULL DEFAULT 0,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno),
  KEY idx_cb_company (company_id), KEY idx_cb_owner (owner_user_id), KEY idx_cb_visibility (visibility),
  KEY idx_cb_category (category_id), KEY idx_cb_status (status), KEY idx_cb_phone (phone_primary), KEY idx_cb_email (email_primary),
  CONSTRAINT fk_cb_contact_category FOREIGN KEY (category_id) REFERENCES egpk_contact_categories(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_tags (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  tag_name VARCHAR(80) NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_cb_tag (company_id, tag_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_tag_map (
  contact_id BIGINT UNSIGNED NOT NULL,
  tag_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (contact_id, tag_id),
  CONSTRAINT fk_cb_tagmap_contact FOREIGN KEY (contact_id) REFERENCES egpk_contacts(sno) ON DELETE CASCADE,
  CONSTRAINT fk_cb_tagmap_tag FOREIGN KEY (tag_id) REFERENCES egpk_contact_tags(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_imports (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  source ENUM('excel','csv','gmail','vcard') NOT NULL,
  file_name VARCHAR(255) NULL,
  total_rows INT NOT NULL DEFAULT 0,
  imported_rows INT NOT NULL DEFAULT 0,
  merged_rows INT NOT NULL DEFAULT 0,
  skipped_rows INT NOT NULL DEFAULT 0,
  status ENUM('queued','processing','completed','failed') NOT NULL DEFAULT 'queued',
  report_json JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_cb_import_owner (owner_user_id), KEY idx_cb_import_company (company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_merge_logs (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  surviving_contact_id BIGINT UNSIGNED NOT NULL,
  merged_contact_id BIGINT UNSIGNED NOT NULL,
  merged_by BIGINT UNSIGNED NOT NULL,
  field_decisions JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_cb_merge_survivor (surviving_contact_id), KEY idx_cb_merge_merged (merged_contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_boards (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  board_name VARCHAR(160) NOT NULL,
  icon VARCHAR(80) NULL,
  description TEXT NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  sort_order INT NOT NULL DEFAULT 0,
  is_locked TINYINT(1) NOT NULL DEFAULT 0,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_bm_board_company (company_id), KEY idx_bm_board_owner (owner_user_id), KEY idx_bm_board_visibility (visibility)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_board_categories (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  board_id BIGINT UNSIGNED NOT NULL,
  category_name VARCHAR(160) NOT NULL,
  color VARCHAR(20) NOT NULL DEFAULT '#1F618D',
  sort_order INT NOT NULL DEFAULT 0,
  is_collapsed TINYINT(1) NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_bm_cat_board (board_id),
  CONSTRAINT fk_bm_cat_board FOREIGN KEY (board_id) REFERENCES egpk_boards(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmarks (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  board_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NOT NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  bookmark_name VARCHAR(180) NOT NULL,
  url VARCHAR(2000) NOT NULL,
  description TEXT NULL,
  favicon_url VARCHAR(1000) NULL,
  manual_icon VARCHAR(500) NULL,
  tags_json JSON NULL,
  click_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  health_status ENUM('unknown','healthy','broken','checking') NOT NULL DEFAULT 'unknown',
  last_checked_at DATETIME NULL,
  sort_order INT NOT NULL DEFAULT 0,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_bm_book_board (board_id), KEY idx_bm_book_cat (category_id), KEY idx_bm_book_owner (owner_user_id), KEY idx_bm_book_health (health_status),
  CONSTRAINT fk_bm_book_board FOREIGN KEY (board_id) REFERENCES egpk_boards(sno) ON DELETE CASCADE,
  CONSTRAINT fk_bm_book_cat FOREIGN KEY (category_id) REFERENCES egpk_board_categories(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_categories (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  category_name VARCHAR(100) NOT NULL,
  color VARCHAR(20) NOT NULL DEFAULT '#0288D1',
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_vcat_company (company_id), KEY idx_vcat_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entries (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  entry_type ENUM('Website','System','Application','Mobile App') NOT NULL DEFAULT 'Website',
  category_id BIGINT UNSIGNED NOT NULL,
  entry_name VARCHAR(180) NOT NULL,
  url VARCHAR(2000) NULL,
  username VARCHAR(255) NULL,
  password_cipher LONGTEXT NOT NULL,
  password_key_ref VARCHAR(255) NOT NULL,
  notes_cipher LONGTEXT NULL,
  email VARCHAR(180) NULL,
  mobile VARCHAR(40) NULL,
  icon_url VARCHAR(1000) NULL,
  visibility ENUM('Private','Team','Company') NOT NULL DEFAULT 'Private',
  rotation_days INT NULL,
  last_rotated_at DATETIME NULL,
  next_rotation_at DATETIME NULL,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_vault_company (company_id), KEY idx_vault_owner (owner_user_id), KEY idx_vault_visibility (visibility), KEY idx_vault_rotation (next_rotation_at),
  CONSTRAINT fk_vault_cat FOREIGN KEY (category_id) REFERENCES egpk_vault_categories(sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entry_attachments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vault_entry_id BIGINT UNSIGNED NOT NULL,
  storage_path VARCHAR(1000) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(150) NULL,
  file_size BIGINT UNSIGNED NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_vattach_entry (vault_entry_id),
  CONSTRAINT fk_vattach_entry FOREIGN KEY (vault_entry_id) REFERENCES egpk_vault_entries(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entry_history (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vault_entry_id BIGINT UNSIGNED NOT NULL,
  password_cipher LONGTEXT NOT NULL,
  password_key_ref VARCHAR(255) NOT NULL,
  changed_by BIGINT UNSIGNED NOT NULL,
  changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_vault_hist_entry (vault_entry_id),
  CONSTRAINT fk_vault_hist_entry FOREIGN KEY (vault_entry_id) REFERENCES egpk_vault_entries(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_categories (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_name VARCHAR(100) NOT NULL,
  color VARCHAR(20) NOT NULL DEFAULT '#4A3E8E',
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_kcat_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_subcategories (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id BIGINT UNSIGNED NOT NULL,
  subcategory_name VARCHAR(120) NOT NULL,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_ksub_category (category_id),
  CONSTRAINT fk_ksub_category FOREIGN KEY (category_id) REFERENCES egpk_knowledge_categories(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_posts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  author_user_id BIGINT UNSIGNED NOT NULL,
  category_id BIGINT UNSIGNED NOT NULL,
  subcategory_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(220) NOT NULL,
  body_html LONGTEXT NOT NULL,
  tags_json JSON NULL,
  audience_scope ENUM('Group','Companies','Teams') NOT NULL DEFAULT 'Group',
  status ENUM('draft','published','unpublished') NOT NULL DEFAULT 'draft',
  edit_version INT NOT NULL DEFAULT 1,
  published_at DATETIME NULL,
  edited_at DATETIME NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_kpost_company (company_id), KEY idx_kpost_author (author_user_id), KEY idx_kpost_status (status), KEY idx_kpost_category (category_id, subcategory_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_post_versions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  version_no INT NOT NULL,
  title VARCHAR(220) NOT NULL,
  body_html LONGTEXT NOT NULL,
  edited_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_kpost_ver (post_id, version_no), CONSTRAINT fk_kpost_ver_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_post_media (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  media_type ENUM('url','image','file','audio','video') NOT NULL,
  storage_path VARCHAR(1000) NULL,
  original_name VARCHAR(255) NULL,
  mime_type VARCHAR(150) NULL,
  file_size BIGINT UNSIGNED NULL,
  external_url VARCHAR(2000) NULL,
  preview_path VARCHAR(1000) NULL,
  status ENUM('pending','ready','blocked') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_kmedia_post (post_id), CONSTRAINT fk_kmedia_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_replies (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  parent_reply_id BIGINT UNSIGNED NULL,
  author_user_id BIGINT UNSIGNED NOT NULL,
  body_html TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_kreply_post (post_id), KEY idx_kreply_parent (parent_reply_id), CONSTRAINT fk_kreply_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_reactions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  reaction VARCHAR(30) NOT NULL DEFAULT 'like',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_kreact (post_id, user_id, reaction), CONSTRAINT fk_kreact_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_saves (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_ksave (post_id, user_id), CONSTRAINT fk_ksave_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_follows (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_kfollow (category_id, user_id), CONSTRAINT fk_kfollow_cat FOREIGN KEY (category_id) REFERENCES egpk_knowledge_categories(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_reports (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  reported_by BIGINT UNSIGNED NOT NULL,
  reason VARCHAR(500) NOT NULL,
  status ENUM('open','reviewed','dismissed','unpublished') NOT NULL DEFAULT 'open',
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_kreport_status (status), CONSTRAINT fk_kreport_post FOREIGN KEY (post_id) REFERENCES egpk_knowledge_posts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_apps (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  app_name VARCHAR(180) NOT NULL,
  app_url VARCHAR(2000) NOT NULL,
  purpose TEXT NULL,
  platform ENUM('Web Portal','Mobile App','Desktop') NOT NULL DEFAULT 'Web Portal',
  environment ENUM('Production','Staging') NOT NULL DEFAULT 'Production',
  status ENUM('Live','Under Maintenance','Deprecated') NOT NULL DEFAULT 'Live',
  technical_owner_user_id BIGINT UNSIGNED NULL,
  icon_path VARCHAR(1000) NULL,
  current_version VARCHAR(60) NULL,
  passwallet_entry_id BIGINT UNSIGNED NULL,
  most_used_score BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_papp_company (company_id), KEY idx_papp_status (status), KEY idx_papp_env (environment)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_app_versions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  app_id BIGINT UNSIGNED NOT NULL,
  version_no VARCHAR(60) NOT NULL,
  update_details TEXT NULL,
  bug_fix_details TEXT NULL,
  updated_by BIGINT UNSIGNED NOT NULL,
  update_date DATE NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_pver_app (app_id), CONSTRAINT fk_pver_app FOREIGN KEY (app_id) REFERENCES egpk_portal_apps(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meetings (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  title VARCHAR(220) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Review',
  start_at DATETIME NOT NULL,
  end_at DATETIME NOT NULL,
  venue VARCHAR(300) NULL,
  meeting_url VARCHAR(2000) NULL,
  agenda TEXT NULL,
  status ENUM('Scheduled','In Progress','Completed','Cancelled','Postponed') NOT NULL DEFAULT 'Scheduled',
  reminder_minutes INT NULL DEFAULT 10080,
  notes TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_meet_company (company_id), KEY idx_meet_owner (owner_user_id), KEY idx_meet_visibility (visibility), KEY idx_meet_start (start_at), KEY idx_meet_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meeting_participants (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  meeting_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  rsvp ENUM('pending','accepted','declined','tentative') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_meet_part (meeting_id, user_id), CONSTRAINT fk_meet_part FOREIGN KEY (meeting_id) REFERENCES egpk_meetings(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meeting_reschedules (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  meeting_id BIGINT UNSIGNED NOT NULL,
  old_start_at DATETIME NOT NULL,
  old_end_at DATETIME NOT NULL,
  new_start_at DATETIME NOT NULL,
  new_end_at DATETIME NOT NULL,
  reason VARCHAR(500) NULL,
  changed_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_mres_meeting (meeting_id), CONSTRAINT fk_mres_meeting FOREIGN KEY (meeting_id) REFERENCES egpk_meetings(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_tasks (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  title VARCHAR(220) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Operations',
  priority ENUM('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  due_at DATETIME NULL,
  status ENUM('To Do','In Progress','On Hold','Pending Verification','Completed') NOT NULL DEFAULT 'To Do',
  description TEXT NULL,
  supervisor_user_id BIGINT UNSIGNED NULL,
  verification_required TINYINT(1) NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_task_company (company_id), KEY idx_task_owner (owner_user_id), KEY idx_task_visibility (visibility), KEY idx_task_due (due_at), KEY idx_task_status (status), KEY idx_task_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_task_assignees (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_task_assignee (task_id, user_id), CONSTRAINT fk_task_assignee FOREIGN KEY (task_id) REFERENCES egpk_tasks(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_task_comments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  comment_text TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_task_comment (task_id), CONSTRAINT fk_task_comment_task FOREIGN KEY (task_id) REFERENCES egpk_tasks(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_sticky_notes (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  title VARCHAR(220) NULL,
  body LONGTEXT NULL,
  color VARCHAR(20) NOT NULL DEFAULT '#FFF6D9',
  priority ENUM('normal','high') NOT NULL DEFAULT 'normal',
  reminder_at DATETIME NULL,
  checklist_json JSON NULL,
  label VARCHAR(80) NULL,
  status ENUM('active','archived','trashed') NOT NULL DEFAULT 'active',
  is_pinned TINYINT(1) NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_note_owner (owner_user_id), KEY idx_note_visibility (visibility), KEY idx_note_status (status), KEY idx_note_rem (reminder_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_accounts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  account_name VARCHAR(160) NOT NULL,
  account_type VARCHAR(80) NOT NULL DEFAULT 'Cash',
  opening_balance DECIMAL(15,2) NOT NULL DEFAULT 0,
  current_balance DECIMAL(15,2) NOT NULL DEFAULT 0,
  status TINYINT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_money_owner (owner_user_id), KEY idx_money_company (company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_transactions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  account_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  transaction_date DATE NOT NULL,
  category VARCHAR(120) NOT NULL,
  mode VARCHAR(80) NULL,
  note VARCHAR(500) NULL,
  amount DECIMAL(15,2) NOT NULL,
  transaction_type ENUM('income','expense') NOT NULL DEFAULT 'expense',
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_mtxn_account (account_id), KEY idx_mtxn_date (transaction_date),
  CONSTRAINT fk_mtxn_account FOREIGN KEY (account_id) REFERENCES egpk_money_accounts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_budgets (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  budget_month DATE NOT NULL,
  category VARCHAR(120) NOT NULL,
  budget_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_mbudget_month (budget_month), UNIQUE KEY uq_mbudget (owner_user_id, company_id, budget_month, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_commitments (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  commitment_name VARCHAR(180) NOT NULL,
  due_date DATE NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  recurrence VARCHAR(40) NULL,
  status ENUM('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_commit_due (due_date), KEY idx_commit_owner (owner_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_events (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  event_name VARCHAR(220) NOT NULL,
  organisation VARCHAR(180) NULL,
  event_type VARCHAR(80) NOT NULL DEFAULT 'Event',
  event_date DATE NOT NULL,
  event_time TIME NULL,
  venue VARCHAR(300) NULL,
  is_online TINYINT(1) NOT NULL DEFAULT 0,
  online_link VARCHAR(2000) NULL,
  payment_amount DECIMAL(15,2) NULL,
  status ENUM('Planned','Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Planned',
  reminder_stage VARCHAR(40) NULL,
  description TEXT NULL,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_event_company (company_id), KEY idx_event_owner (owner_user_id), KEY idx_event_visibility (visibility), KEY idx_event_date (event_date), KEY idx_event_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_documents (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
  scope ENUM('Personal','Official') NOT NULL DEFAULT 'Personal',
  category VARCHAR(100) NOT NULL,
  document_name VARCHAR(255) NOT NULL,
  storage_path VARCHAR(1000) NOT NULL,
  mime_type VARCHAR(150) NULL,
  file_size BIGINT UNSIGNED NULL,
  version_no INT NOT NULL DEFAULT 1,
  is_pinned TINYINT(1) NOT NULL DEFAULT 0,
  expiry_date DATE NULL,
  status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  PRIMARY KEY (sno), KEY idx_doc_owner (owner_user_id), KEY idx_doc_company (company_id), KEY idx_doc_visibility (visibility), KEY idx_doc_scope (scope), KEY idx_doc_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_document_versions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  document_id BIGINT UNSIGNED NOT NULL,
  version_no INT NOT NULL,
  storage_path VARCHAR(1000) NOT NULL,
  file_size BIGINT UNSIGNED NULL,
  mime_type VARCHAR(150) NULL,
  uploaded_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_doc_ver (document_id, version_no), CONSTRAINT fk_doc_ver_document FOREIGN KEY (document_id) REFERENCES egpk_documents(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_share_grants (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  resource_type VARCHAR(80) NOT NULL,
  resource_id BIGINT UNSIGNED NOT NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  grantee_type ENUM('user','role','company','group') NOT NULL,
  grantee_id VARCHAR(120) NOT NULL,
  permission ENUM('View','Manage') NOT NULL DEFAULT 'View',
  status ENUM('pending','active','revoked','expired','rejected') NOT NULL DEFAULT 'active',
  expires_at DATETIME NULL,
  requested_by BIGINT UNSIGNED NOT NULL,
  approved_by BIGINT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_share_resource (resource_type, resource_id), KEY idx_share_grantee (grantee_type, grantee_id), KEY idx_share_status (status), KEY idx_share_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_audit_logs (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  module_name VARCHAR(80) NOT NULL,
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(80) NULL,
  resource_id BIGINT UNSIGNED NULL,
  actor_user_id BIGINT UNSIGNED NULL,
  actor_name VARCHAR(180) NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,
  before_json JSON NULL,
  after_json JSON NULL,
  meta_json JSON NULL,
  is_high_sensitivity TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_audit_module (module_name), KEY idx_audit_resource (resource_type, resource_id), KEY idx_audit_actor (actor_user_id), KEY idx_audit_created (created_at), KEY idx_audit_sensitive (is_high_sensitivity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_search_history (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  module_name VARCHAR(80) NOT NULL,
  search_text VARCHAR(500) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_search_user_module (user_id, module_name, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'Client','#2E7D32',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Client');
INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'College','#1F618D',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='College');
INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'Vendor','#D35400',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Vendor');
INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'Government','#7D3C98',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Government');
INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'Trainer','#00796B',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Trainer');
INSERT INTO egpk_contact_categories (category_name,color,status) SELECT 'Alumni','#AD1457',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Alumni');

INSERT INTO egpk_vault_categories (category_name,color,status) SELECT 'IT Ops','#0288D1',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='IT Ops');
INSERT INTO egpk_vault_categories (category_name,color,status) SELECT 'Social Media','#AD1457',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Social Media');
INSERT INTO egpk_vault_categories (category_name,color,status) SELECT 'Hosting','#546E7A',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Hosting');
INSERT INTO egpk_vault_categories (category_name,color,status) SELECT 'Internal Systems','#1F3864',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Internal Systems');

INSERT INTO egpk_knowledge_categories (category_name,color,status) SELECT 'IT Operations','#00796B',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='IT Operations');
INSERT INTO egpk_knowledge_categories (category_name,color,status) SELECT 'Training & Skilling','#2E7D32',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='Training & Skilling');
INSERT INTO egpk_knowledge_categories (category_name,color,status) SELECT 'Research Support','#7D3C98',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='Research Support');
INSERT INTO egpk_knowledge_categories (category_name,color,status) SELECT 'HR & Admin','#B8860B',0 WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='HR & Admin');

SET FOREIGN_KEY_CHECKS = 1;

-- Additional explicit collaboration/analytics tables used by the production controllers.
CREATE TABLE IF NOT EXISTS egpk_board_shares (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  board_id BIGINT UNSIGNED NOT NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  grantee_type ENUM('user','role','company','group') NOT NULL,
  grantee_id VARCHAR(120) NOT NULL,
  permission ENUM('View','Manage') NOT NULL DEFAULT 'View',
  status ENUM('pending','active','revoked','expired') NOT NULL DEFAULT 'active',
  expires_at DATETIME NULL,
  requested_by BIGINT UNSIGNED NOT NULL,
  approved_by BIGINT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), KEY idx_board_share_board (board_id), KEY idx_board_share_grantee (grantee_type,grantee_id),
  CONSTRAINT fk_board_share_board FOREIGN KEY (board_id) REFERENCES egpk_boards(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmark_clicks (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  bookmark_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  clicked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(1000) NULL,
  PRIMARY KEY (sno), KEY idx_bclick_bookmark (bookmark_id), KEY idx_bclick_date (clicked_at),
  CONSTRAINT fk_bclick_bookmark FOREIGN KEY (bookmark_id) REFERENCES egpk_bookmarks(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_subscriptions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  app_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno), UNIQUE KEY uq_portal_subscription (app_id,user_id),
  CONSTRAINT fk_portal_subscription_app FOREIGN KEY (app_id) REFERENCES egpk_portal_apps(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------------------------------
-- EGPK FINAL HARDENING / COLLABORATION MIGRATION
-- Re-runnable on MySQL 8.0. Existing production data is preserved.
-- -----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS egpk_productivity_notifications (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  company_id BIGINT UNSIGNED NULL,
  module_name VARCHAR(80) NOT NULL,
  notification_type VARCHAR(80) NOT NULL,
  title VARCHAR(220) NOT NULL,
  message VARCHAR(1000) NULL,
  resource_type VARCHAR(80) NULL,
  resource_id BIGINT UNSIGNED NULL,
  action_url VARCHAR(1000) NULL,
  icon VARCHAR(80) NULL,
  icon_color VARCHAR(20) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  read_at DATETIME NULL,
  expires_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  KEY idx_pnotif_user_read (user_id,is_read,created_at),
  KEY idx_pnotif_expiry (expires_at),
  KEY idx_pnotif_resource (resource_type,resource_id),
  KEY idx_pnotif_company (company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_activity_logs (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  contact_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  action VARCHAR(80) NOT NULL,
  before_json JSON NULL,
  after_json JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  KEY idx_cact_contact (contact_id,created_at),
  KEY idx_cact_user (user_id,created_at),
  CONSTRAINT fk_cact_contact FOREIGN KEY (contact_id) REFERENCES egpk_contacts(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmark_layouts (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  board_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  layout_json JSON NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  UNIQUE KEY uq_blayout_board_user (board_id,user_id),
  CONSTRAINT fk_blayout_board FOREIGN KEY (board_id) REFERENCES egpk_boards(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmark_health_checks (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  bookmark_id BIGINT UNSIGNED NOT NULL,
  checked_by BIGINT UNSIGNED NULL,
  status ENUM('healthy','broken','unknown','timeout','blocked') NOT NULL DEFAULT 'unknown',
  http_status INT NULL,
  response_ms INT NULL,
  error_message VARCHAR(500) NULL,
  checked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  KEY idx_bhealth_bookmark (bookmark_id,checked_at),
  CONSTRAINT fk_bhealth_bookmark FOREIGN KEY (bookmark_id) REFERENCES egpk_bookmarks(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_app_subscriptions (
  sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  app_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  company_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (sno),
  KEY idx_papps_user (user_id),
  KEY idx_papps_company (company_id),
  CONSTRAINT fk_papps_app FOREIGN KEY (app_id) REFERENCES egpk_portal_apps(sno) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Make the final scope fields available when upgrading an older installed copy.
SET @db := DATABASE();
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='egpk_meetings' AND COLUMN_NAME='visibility')=0,
  'ALTER TABLE egpk_meetings ADD COLUMN visibility ENUM(''Private'',''Company'',''Group'') NOT NULL DEFAULT ''Private'' AFTER owner_user_id, ADD KEY idx_meet_visibility (visibility)', 'SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='egpk_tasks' AND COLUMN_NAME='visibility')=0,
  'ALTER TABLE egpk_tasks ADD COLUMN visibility ENUM(''Private'',''Company'',''Group'') NOT NULL DEFAULT ''Private'' AFTER owner_user_id, ADD KEY idx_task_visibility (visibility)', 'SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='egpk_events' AND COLUMN_NAME='visibility')=0,
  'ALTER TABLE egpk_events ADD COLUMN visibility ENUM(''Private'',''Company'',''Group'') NOT NULL DEFAULT ''Private'' AFTER owner_user_id, ADD KEY idx_event_visibility (visibility)', 'SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='egpk_documents' AND COLUMN_NAME='visibility')=0,
  'ALTER TABLE egpk_documents ADD COLUMN visibility ENUM(''Private'',''Company'',''Group'') NOT NULL DEFAULT ''Private'' AFTER company_id, ADD KEY idx_doc_visibility (visibility)', 'SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;
SET @sql := IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='egpk_sticky_notes' AND COLUMN_NAME='visibility')=0,
  'ALTER TABLE egpk_sticky_notes ADD COLUMN visibility ENUM(''Private'',''Company'',''Group'') NOT NULL DEFAULT ''Private'' AFTER company_id, ADD KEY idx_note_visibility (visibility)', 'SELECT 1'); PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- Correct legacy portal subscription naming if the original production table exists.
