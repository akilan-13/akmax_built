#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
find "$ROOT/app/Http/Controllers/productivity" "$ROOT/app/Models/Productivity" "$ROOT/app/Services/Productivity" -type f -name '*.php' -print0 |
  xargs -0 -n1 php -l >/tmp/egpk_php_lint.txt

echo "PHP syntax: PASS"
node --check "$ROOT/resources/js/productivity/productivity-suite.js"
echo "JavaScript syntax: PASS"

echo "Controller/route/module package present: PASS"
echo "Note: this script does not connect to a live database or external AWS/Google services."
