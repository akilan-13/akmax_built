@extends('layouts/layoutMaster')
@section('title', 'Reports')
@section('content')
  @php($module='reports')
  @php($title='Reports')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
