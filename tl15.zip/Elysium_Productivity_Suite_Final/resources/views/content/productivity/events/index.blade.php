@extends('layouts/layoutMaster')
@section('title', 'Events')
@section('content')
  @php($module='events')
  @php($title='Events')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
