@extends('layouts/layoutMaster')
@section('title', 'Tasks')
@section('content')
  @php($module='tasks')
  @php($title='Tasks')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
