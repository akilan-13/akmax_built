<div class="egpk-page" data-egpk-module="{{ $module }}">
    <style>
        .egpk-page{--egpk-navy:#1F3864;--egpk-navy2:#273F70;--egpk-purple:#4A3E8E;--egpk-gold:#C9A227;--egpk-red:#B02418;--egpk-green:#2E7D32;--egpk-blue:#1F618D;--egpk-bg:#F5F6FA;--egpk-border:#E2E5EE;--egpk-text:#1F2430;--egpk-muted:#7A8299;background:var(--egpk-bg);min-height:calc(100vh - 70px);padding:10px 14px 22px;color:var(--egpk-text)}
        .egpk-wrap{display:grid;grid-template-columns:220px minmax(0,1fr);gap:12px;min-height:calc(100vh - 92px)}
        .egpk-side{background:var(--egpk-navy);border-radius:12px;overflow:hidden;display:flex;flex-direction:column;position:sticky;top:10px;height:calc(100vh - 112px)}
        .egpk-brand{padding:13px 14px;border-bottom:1px solid rgba(255,255,255,.12)}.egpk-brand strong{display:block;font-size:14px;color:#fff;font-weight:800}.egpk-brand small{display:block;color:#AEBBDA;font-size:9.5px;letter-spacing:.75px;margin-top:2px}
        .egpk-nav{padding:8px;overflow:auto;flex:1}.egpk-nav a{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:8px;color:#DCE5FA;text-decoration:none;font-size:11.5px;font-weight:600;margin-bottom:2px}.egpk-nav a:hover{background:rgba(255,255,255,.08);color:#fff}.egpk-nav a.active{background:var(--egpk-purple);color:#fff}.egpk-nav .mdi{font-size:18px}
        .egpk-side-foot{padding:11px 12px;border-top:1px solid rgba(255,255,255,.12);color:#AEBBDA;font-size:10px}
        .egpk-main{min-width:0}.egpk-topbar{position:relative;z-index:30;display:flex;align-items:center;gap:8px;flex-wrap:wrap;background:#fff;border:1px solid var(--egpk-border);border-radius:10px;padding:8px;margin-bottom:10px}.egpk-global-search-wrap{position:relative;flex:1;max-width:520px;min-width:220px}.egpk-global-results{position:absolute;left:0;right:0;top:39px;background:#fff;border:1px solid var(--egpk-border);border-radius:10px;box-shadow:0 14px 36px rgba(31,56,100,.18);max-height:380px;overflow:auto;display:none}.egpk-global-item{display:block;padding:10px 12px;border-bottom:1px solid #F1F3F7;color:var(--egpk-text);text-decoration:none}.egpk-global-item:hover{background:#FAFBFE}.egpk-global-item strong{display:block;font-size:11px}.egpk-global-item span{display:block;font-size:9px;color:var(--egpk-muted);margin-top:2px}.egpk-top-select{border:1px solid var(--egpk-border);border-radius:8px;min-height:34px;padding:6px 9px;font-size:11px;background:#fff;color:var(--egpk-navy);font-weight:700}.egpk-top-icon{width:34px;height:34px;border:1px solid var(--egpk-border);background:#fff;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;color:#4B5468;cursor:pointer}.egpk-top-icon:hover{background:#F3F5FA}.egpk-tool-menu{position:absolute;right:52px;top:49px;width:360px;background:#fff;border:1px solid var(--egpk-border);border-radius:12px;box-shadow:0 16px 44px rgba(31,56,100,.20);padding:12px;display:none}.egpk-tool-menu.open{display:block}.egpk-tool-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}.egpk-tool-item{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 6px;border-radius:10px;text-decoration:none;color:var(--egpk-text)}.egpk-tool-item:hover{background:#F4F6FA}.egpk-tool-icon{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px}.egpk-tool-label{font-size:9.5px;font-weight:800;text-align:center;line-height:1.2}
        .egpk-notif-menu{position:absolute;right:8px;top:49px;width:350px;background:#fff;border:1px solid var(--egpk-border);border-radius:12px;box-shadow:0 16px 44px rgba(31,56,100,.18);padding:0;display:none;overflow:hidden}.egpk-notif-menu.open{display:block}.egpk-notif-head{padding:11px 13px;border-bottom:1px solid var(--egpk-border);display:flex;justify-content:space-between;font-size:11px;font-weight:800}.egpk-notif-row{padding:10px 13px;border-bottom:1px solid #F1F3F7;display:flex;gap:9px}.egpk-notif-row:last-child{border-bottom:0}.egpk-notif-icon{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex:0 0 auto}.egpk-notif-text{font-size:10.5px;line-height:1.45}.egpk-notif-time{font-size:8.5px;color:var(--egpk-muted);margin-top:2px}
        .egpk-hero{background:linear-gradient(100deg,var(--egpk-navy),var(--egpk-navy2));color:#fff;border-radius:12px;padding:16px 18px;margin-bottom:10px;box-shadow:0 8px 25px rgba(31,56,100,.13)}.egpk-hero-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.egpk-title{font-size:20px;font-weight:800}.egpk-subtitle{font-size:10px;color:#C8D2E8;margin-top:3px}.egpk-actions{display:flex;gap:7px;flex-wrap:wrap}.egpk-btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:8px;padding:8px 12px;font-size:10.5px;font-weight:800;cursor:pointer;text-decoration:none}.egpk-btn-gold{background:var(--egpk-gold);color:var(--egpk-navy)}.egpk-btn-light{background:#fff;color:var(--egpk-navy)}.egpk-btn-outline{background:transparent;border:1px solid rgba(255,255,255,.42);color:#fff}.egpk-btn-outline:hover{color:#fff;background:rgba(255,255,255,.08)}
        .egpk-stat-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-bottom:10px}.egpk-stat{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;padding:11px 12px}.egpk-stat label{display:block;color:var(--egpk-muted);font-size:8.5px;text-transform:uppercase;font-weight:800;letter-spacing:.05em}.egpk-stat strong{display:block;color:var(--egpk-navy);font-size:19px;margin-top:5px}
        .egpk-toolbar{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;padding:8px;display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:10px}.egpk-input,.egpk-select{border:1px solid var(--egpk-border);border-radius:8px;background:#fff;color:var(--egpk-text);padding:7px 9px;font-size:10.5px;min-height:35px}.egpk-search{flex:1;min-width:210px}.egpk-view-toggle .btn{font-size:10px}.egpk-view-toggle .btn.active{background:var(--egpk-navy);color:#fff;border-color:var(--egpk-navy)}
        .egpk-card{background:#fff;border:1px solid var(--egpk-border);border-radius:11px;box-shadow:0 4px 14px rgba(31,56,100,.04)}.egpk-table-wrap{overflow:auto;border-radius:11px}.egpk-table{width:100%;min-width:950px;border-collapse:separate;border-spacing:0}.egpk-table th{position:sticky;top:0;z-index:2;background:#EFF2F8;color:#33415F;padding:10px;font-size:9px;text-transform:uppercase;letter-spacing:.05em;font-weight:800;text-align:left;border-bottom:1px solid var(--egpk-border)}.egpk-table td{padding:10px;border-bottom:1px solid #EEF1F6;font-size:10.5px;vertical-align:middle}.egpk-table tbody tr:hover{background:#FBFCFE}.egpk-actions-cell{white-space:nowrap}.egpk-row-title{font-weight:800;color:#23365D}.egpk-row-sub{font-size:9px;color:var(--egpk-muted);margin-top:2px}.egpk-badge{display:inline-flex;align-items:center;gap:4px;padding:4px 7px;border-radius:999px;font-size:8.5px;font-weight:800}.egpk-badge-green{background:#E7F6ED;color:#2E7D32}.egpk-badge-red{background:#FDECEC;color:#B02418}.egpk-badge-amber{background:#FDF3E2;color:#B8860B}.egpk-badge-purple{background:#EEEAFE;color:#4A3E8E}.egpk-badge-blue{background:#E8F1FF;color:#1F618D}.egpk-badge-slate{background:#EEF0F3;color:#546E7A}.egpk-muted{color:var(--egpk-muted)}
        .egpk-board-grid{display:grid;grid-template-columns:repeat(4,minmax(235px,1fr));gap:9px;overflow:auto;padding-bottom:2px}.egpk-board-col{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;min-height:220px;overflow:hidden}.egpk-board-head{padding:10px;border-left:4px solid var(--egpk-purple);border-bottom:1px solid var(--egpk-border);font-weight:800;font-size:11px;display:flex;justify-content:space-between;align-items:center}.egpk-link{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #F3F5F8;text-decoration:none;color:#33415F}.egpk-link:hover{background:#FAFBFE}.egpk-favicon{width:18px;height:18px;border-radius:4px;object-fit:contain;background:#F3F5FA;flex:0 0 auto}.egpk-link-title{font-size:10px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.egpk-link-domain{font-size:8.5px;color:var(--egpk-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .egpk-feed{display:grid;grid-template-columns:minmax(0,1fr) 290px;gap:10px}.egpk-post{padding:14px}.egpk-post-top{display:flex;justify-content:space-between;gap:8px}.egpk-post-title{font-size:14px;font-weight:800;color:#23365D}.egpk-post-body{font-size:10.5px;line-height:1.7;margin-top:8px}.egpk-sidecard{padding:12px}.egpk-media{margin-top:9px;border:1px solid var(--egpk-border);border-radius:9px;background:#F8FAFC;padding:10px;font-size:10px}.egpk-actions-row{display:flex;align-items:center;gap:6px;margin-top:10px}.egpk-small-btn{border:1px solid var(--egpk-border);background:#fff;border-radius:7px;padding:5px 8px;font-size:9px;font-weight:700}.egpk-small-btn:hover{background:#F4F6FA}
        .egpk-kanban{display:grid;grid-template-columns:repeat(5,minmax(190px,1fr));gap:8px;overflow:auto}.egpk-kanban-col{background:#EEF1F6;border-radius:10px;padding:8px;min-height:320px}.egpk-kanban-head{font-size:9.5px;font-weight:800;color:#33415F;padding:5px 6px 8px}.egpk-task{background:#fff;border:1px solid var(--egpk-border);border-radius:8px;padding:9px;margin-bottom:7px}.egpk-note-grid{display:grid;grid-template-columns:repeat(4,minmax(200px,1fr));gap:9px}.egpk-note{border-radius:10px;padding:12px;min-height:160px;box-shadow:0 4px 12px rgba(0,0,0,.05)}
        .egpk-calendar-wrap{overflow:auto}.egpk-calendar{background:#fff;border:1px solid var(--egpk-border);border-radius:11px;overflow:hidden;min-width:840px}.egpk-cal-top{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;border-bottom:1px solid var(--egpk-border)}.egpk-cal-head,.egpk-cal-grid{display:grid;grid-template-columns:repeat(7,minmax(120px,1fr))}.egpk-cal-head{background:#EFF2F8}.egpk-cal-head div{padding:8px;font-size:9px;font-weight:800;text-align:center;color:#475467;border-right:1px solid var(--egpk-border)}.egpk-cal-day{min-height:128px;border-right:1px solid var(--egpk-border);border-top:1px solid var(--egpk-border);padding:7px;background:#fff}.egpk-cal-day.other{background:#FBFCFE}.egpk-cal-day.today{box-shadow:inset 0 0 0 2px rgba(74,62,142,.28)}.egpk-cal-num{font-size:9px;font-weight:800;color:#475467;margin-bottom:6px}.egpk-cal-event{display:block;width:100%;border:0;border-radius:7px;padding:5px 6px;margin-bottom:4px;font-size:8.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.egpk-calendar-nav{display:flex;gap:4px}.egpk-calendar-nav button{border:1px solid var(--egpk-border);background:#fff;border-radius:7px;padding:5px 8px;font-size:9px}
        .egpk-empty{padding:46px 20px;text-align:center;color:#98A2B3;font-size:11px}.egpk-loader{padding:30px;text-align:center;color:#7A8299}.egpk-modal .modal-content{border:0;border-radius:14px;box-shadow:0 20px 52px rgba(31,56,100,.20)}.egpk-modal .modal-header{background:#F8F9FC;border-bottom:1px solid var(--egpk-border)}.egpk-modal .modal-title{font-size:14px;font-weight:800}.egpk-modal .modal-body{max-height:72vh;overflow:auto}.egpk-field label{display:block;font-size:9.5px;font-weight:800;color:#475467;margin-bottom:4px}.egpk-field .form-control,.egpk-field .form-select{font-size:10.5px;min-height:36px;border-radius:8px}.egpk-field textarea.form-control{min-height:90px}.egpk-help{font-size:9px;color:var(--egpk-muted);line-height:1.5}.egpk-error{font-size:9px;color:var(--egpk-red);margin-top:3px}.egpk-section{border:1px solid var(--egpk-border);border-radius:10px;padding:12px;margin-bottom:10px;background:#fff}.egpk-section-title{display:flex;align-items:center;gap:6px;font-size:10.5px;font-weight:800;color:var(--egpk-navy);margin-bottom:9px}.egpk-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.egpk-detail{padding:9px;border:1px solid var(--egpk-border);border-radius:8px;background:#FBFCFE}.egpk-detail small{display:block;text-transform:uppercase;font-size:7.5px;color:var(--egpk-muted);font-weight:800}.egpk-detail div{margin-top:3px;font-size:10.5px;font-weight:600;word-break:break-word}.egpk-progress{height:6px;border-radius:999px;background:#EDF0F5;overflow:hidden}.egpk-progress>span{display:block;height:100%;background:var(--egpk-purple);border-radius:inherit}
        .egpk-alert{padding:9px 10px;border-radius:8px;font-size:9.5px}.egpk-alert.info{background:#EFF6FF;color:#1E40AF}.egpk-alert.warn{background:#FFF7ED;color:#9A3412}.egpk-alert.danger{background:#FEF2F2;color:#991B1B}.egpk-alert.success{background:#ECFDF3;color:#166534}
        @media(max-width:1200px){.egpk-wrap{grid-template-columns:185px minmax(0,1fr)}.egpk-stat-grid{grid-template-columns:repeat(3,1fr)}.egpk-board-grid{grid-template-columns:repeat(3,minmax(235px,1fr))}.egpk-note-grid{grid-template-columns:repeat(3,minmax(200px,1fr))}.egpk-feed{grid-template-columns:1fr}}
        @media(max-width:900px){.egpk-wrap{grid-template-columns:1fr}.egpk-side{position:static;height:auto}.egpk-nav{display:grid;grid-template-columns:repeat(3,1fr)}.egpk-stat-grid{grid-template-columns:repeat(2,1fr)}.egpk-board-grid{grid-template-columns:repeat(2,minmax(235px,1fr))}.egpk-note-grid{grid-template-columns:repeat(2,minmax(200px,1fr))}.egpk-tool-menu{right:8px}}
        @media(max-width:576px){.egpk-page{padding:7px}.egpk-nav{grid-template-columns:repeat(2,1fr)}.egpk-topbar{padding:7px}.egpk-global-search-wrap{min-width:100%;max-width:none}.egpk-hero-top{flex-direction:column}.egpk-actions{width:100%}.egpk-actions .egpk-btn{flex:1}.egpk-stat-grid{grid-template-columns:1fr 1fr}.egpk-detail-grid{grid-template-columns:1fr}.egpk-tool-grid{grid-template-columns:repeat(2,1fr)}.egpk-notif-menu{left:8px;right:8px;width:auto}}
    </style>

    <div class="egpk-topbar">
        <div class="egpk-global-search-wrap">
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-white border-end-0"><i class="mdi mdi-magnify"></i></span>
                <input type="search" class="form-control border-start-0 egpk-global-search" placeholder="Search contacts, bookmarks, knowledge...">
            </div>
            <div class="egpk-global-results" aria-live="polite"></div>
        </div>

        <select class="egpk-top-select" id="egpkCompanySelect"><option value="all">All Companies</option></select>
        <div class="egpk-spacer"></div>

        <button type="button" class="egpk-top-icon" id="egpkToolsButton" title="All tools"><i class="mdi mdi-apps"></i></button>
        <button type="button" class="egpk-top-icon position-relative" id="egpkNotifButton" title="Notifications"><i class="mdi mdi-bell-outline"></i><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" id="egpkNotifCount">0</span></button>
        <span class="small text-muted d-none d-md-inline">{{ auth()->user()->name ?? auth()->user()->staff_name ?? 'User' }}</span>

        <div class="egpk-tool-menu" id="egpkToolMenu">
            <div class="small text-muted fw-bold mb-2 px-1">ALL TOOLS</div>
            <div class="egpk-tool-grid">
                @php
                    $tools = [
                        ['dashboard','Dashboard','view-dashboard-outline','#1F3864'],
                        ['contacts','ContactBook','account-box-outline','#4A3E8E'],
                        ['bookmarks','BookMarks','bookmark-outline','#1565C0'],
                        ['passwallet','PassWallet','shield-key-outline','#1F3864'],
                        ['knowledge','Knowledge Panel','school-outline','#6A1B9A'],
                        ['portals','Portals & Apps','application-outline','#00796B'],
                        ['meetings','Meetings','calendar-month-outline','#C0392B'],
                        ['tasks','Tasks','check-circle-outline','#2E7D32'],
                        ['notes','Sticky Notes','note-multiple-outline','#B8860B'],
                        ['money','My Money','wallet-outline','#AD1457'],
                        ['events','Events','calendar-star-outline','#D35400'],
                        ['documents','Documents','file-document-outline','#0E7490'],
                        ['reports','Reports','chart-box-outline','#546E7A'],
                        ['admin','Admin','shield-crown-outline','#6D4C41'],
                    ];
                @endphp
                @foreach($tools as $tool)
                    <a class="egpk-tool-item" href="{{ route('productivity.'.$tool[0]) }}">
                        <span class="egpk-tool-icon" style="background:{{ $tool[3] }}18;color:{{ $tool[3] }}"><i class="mdi mdi-{{ $tool[2] }}"></i></span>
                        <span class="egpk-tool-label">{{ $tool[1] }}</span>
                    </a>
                @endforeach
            </div>
        </div>

        <div class="egpk-notif-menu" id="egpkNotifMenu">
            <div class="egpk-notif-head"><span>Notifications</span><div class="d-flex gap-2"><button type="button" class="btn btn-link btn-sm p-0" id="egpkNotifRead">Mark all read</button><button type="button" class="btn btn-link btn-sm p-0" id="egpkNotifRefresh">Refresh</button></div></div>
            <div id="egpkNotifList"><div class="egpk-empty py-4">Notifications are available from the ERP notification service.</div></div>
        </div>
    </div>

    <div class="egpk-wrap">
        <aside class="egpk-side">
            <div class="egpk-brand"><strong>Elysium Groups</strong><small>ERP · PRODUCTIVITY SUITE</small></div>
            <nav class="egpk-nav">
                @foreach($tools as $tool)
                    <a href="{{ route('productivity.'.$tool[0]) }}" class="{{ $module===$tool[0]?'active':'' }}">
                        <i class="mdi mdi-{{ $tool[2] }}"></i><span>{{ $tool[1] }}</span>
                    </a>
                @endforeach
            </nav>
            <div class="egpk-side-foot"><i class="mdi mdi-shield-check-outline me-1"></i> Governed workspace · RBAC enabled</div>
        </aside>

        <main class="egpk-main">
            <section class="egpk-hero">
                <div class="egpk-hero-top">
                    <div>
                        <div class="egpk-title" id="egpkPageTitle">{{ $title ?? ucfirst($module) }}</div>
                        <div class="egpk-subtitle" id="egpkPageSubtitle">Company-aware, role-scoped, audited productivity workspace.</div>
                    </div>
                    <div class="egpk-actions" id="egpkHeroActions"></div>
                </div>
            </section>

            <div id="egpkStats" class="egpk-stat-grid"></div>

            <section class="egpk-toolbar" id="egpkToolbar">
                <input type="search" class="egpk-input egpk-search" id="egpkSearch" placeholder="Search this module...">
                <select class="egpk-select" id="egpkFilterOne"><option value="">All Types</option></select>
                <select class="egpk-select" id="egpkFilterTwo"><option value="">All Status</option></select>
                <button type="button" class="egpk-btn egpk-btn-light border" id="egpkReset"><i class="mdi mdi-refresh me-1"></i>Reset</button>
                <div class="egpk-spacer"></div>
                <div class="egpk-view-toggle btn-group" id="egpkViewToggle">
                    <button type="button" class="btn btn-sm active" data-view="table"><i class="mdi mdi-view-list-outline"></i></button>
                    <button type="button" class="btn btn-sm" data-view="card"><i class="mdi mdi-view-grid-outline"></i></button>
                </div>
            </section>

            <div id="egpkContent"></div>
        </main>
    </div>

    <div class="modal fade egpk-modal" id="egpkFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header">
                <div><h5 class="modal-title" id="egpkFormTitle">New Entry</h5><div class="egpk-muted" id="egpkFormSubtitle">Create or update this record.</div></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body"><form id="egpkForm" autocomplete="off" enctype="multipart/form-data"><div id="egpkFormFields"></div></form></div>
            <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="button" class="egpk-btn egpk-btn-gold" id="egpkFormSave">Save</button></div>
        </div></div>
    </div>

    <div class="modal fade egpk-modal" id="egpkViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title" id="egpkViewTitle">Details</h5><div class="egpk-muted" id="egpkViewSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="egpkViewBody"></div>
        </div></div>
    </div>

    <div class="modal fade egpk-modal" id="egpkShareModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title">Share Resource</h5><div class="egpk-muted">Share with a user, role, company or the whole group. Cross-company access is approval-controlled.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="egpkShareForm"><input type="hidden" id="egpkShareType"><input type="hidden" id="egpkShareId">
                    <div class="row g-3">
                        <div class="col-md-6 egpk-field"><label>Share With</label><select id="egpkShareGrantee" class="form-select"><option value="user">User</option><option value="role">Role</option><option value="company">Company</option><option value="group">Group</option></select></div>
                        <div class="col-md-6 egpk-field"><label>Recipient</label><select id="egpkShareGranteeId" class="form-select"></select></div>
                        <div class="col-md-6 egpk-field"><label>Permission</label><select id="egpkSharePermission" class="form-select"><option value="View">View</option><option value="Manage">Manage</option></select></div>
                        <div class="col-md-6 egpk-field"><label>Expiry (optional)</label><input id="egpkShareExpiry" type="datetime-local" class="form-control"></div>
                    </div>
                </form>
                <div class="mt-4"><div class="egpk-section-title">Active / Pending Shares</div><div id="egpkShareList"></div></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button><button type="button" class="egpk-btn egpk-btn-gold" id="egpkShareSave">Share</button></div>
        </div></div>
    </div>

    <div class="modal fade egpk-modal" id="egpkConfirmModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="egpkConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="egpkConfirmBody"></div><div class="modal-footer"><button class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button class="egpk-btn egpk-btn-gold" id="egpkConfirmYes">Confirm</button></div></div></div></div>

    <div class="modal fade egpk-modal" id="egpkStepupModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><div><h5 class="modal-title">Security Verification</h5><div class="egpk-muted">Re-enter your ERP password to continue.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><div class="egpk-alert warn mb-3">This verification is valid for 5 minutes and is required for sensitive PassWallet actions.</div><div class="egpk-field"><label>ERP Password</label><input id="egpkStepupPassword" type="password" class="form-control" autocomplete="current-password"></div></div>
            <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="button" class="egpk-btn egpk-btn-gold" id="egpkStepupConfirm">Verify</button></div>
        </div></div>
    </div>

    <div class="position-fixed bottom-0 end-0 p-3" style="z-index:1080"><div id="egpkToast" class="toast" role="alert"><div class="toast-body"></div></div></div>
</div>

<script>
window.EGPK = {
    module: @json($module),
    csrf: @json(csrf_token()),
    urls: {
        dashboard: @json(route('productivity.dashboard.data')),
        companies: @json(route('productivity.companies')),
        users: @json(route('productivity.users')),
        global: @json(route('productivity.global.search')),
        notifications: @json(route('productivity.notifications')), notificationsRead: @json(route('productivity.notifications.read')),
        contacts: {
            data:@json(route('productivity.contacts.data')), categories:@json(route('productivity.contacts.categories')), store:@json(route('productivity.contacts.store')), show:@json(url('/productivity/contactbook')), update:@json(url('/productivity/contactbook')), bulk:@json(route('productivity.contacts.bulk')), star:@json(url('/productivity/contactbook')), exportCsv:@json(route('productivity.contacts.export.csv')), exportXlsx:@json(route('productivity.contacts.export.xlsx')), vcard:@json(route('productivity.contacts.export.vcard')), import:@json(route('productivity.contacts.import')), googleImport:@json(route('productivity.contacts.google.import'))
        },
        bookmarks: {
            data:@json(route('productivity.bookmarks.data')), boards:@json(route('productivity.bookmarks.boards')), board:@json(url('/productivity/bookmarks/board')), boardStore:@json(route('productivity.bookmarks.board.store')), store:@json(route('productivity.bookmarks.store')), quick:@json(route('productivity.bookmarks.quick')), update:@json(url('/productivity/bookmarks')), importHtml:@json(route('productivity.bookmarks.import.html')), open:@json(url('/productivity/bookmarks')), health:@json(url('/productivity/bookmarks')), delete:@json(url('/productivity/bookmarks')), moveCopy:@json(url('/productivity/bookmarks'))
        },
        passwallet: {
            data:@json(route('productivity.passwallet.data')), categories:@json(route('productivity.passwallet.categories')), store:@json(route('productivity.passwallet.store')), show:@json(url('/productivity/passwallet')), update:@json(url('/productivity/passwallet')), reveal:@json(url('/productivity/passwallet')), history:@json(url('/productivity/passwallet')), shares:@json(url('/productivity/passwallet')), delete:@json(url('/productivity/passwallet')), generator:@json(route('productivity.passwallet.generator')), attachment:@json(url('/productivity/passwallet'))
        },
        knowledge: {data:@json(route('productivity.knowledge.data')), categories:@json(route('productivity.knowledge.categories')), store:@json(route('productivity.knowledge.store')), show:@json(url('/productivity/knowledge')), update:@json(url('/productivity/knowledge')), media:@json(url('/productivity/knowledge'))},
        portals: {data:@json(route('productivity.portals.data')), store:@json(route('productivity.portals.store')), show:@json(url('/productivity/portals')), update:@json(url('/productivity/portals')), version:@json(url('/productivity/portals')), launch:@json(url('/productivity/portals')), subscribe:@json(url('/productivity/portals')), exportXlsx:@json(route('productivity.portals.export.xlsx'))},
        meetings: {data:@json(route('productivity.meetings.data')), calendar:@json(route('productivity.meetings.calendar')), store:@json(route('productivity.meetings.store')), show:@json(url('/productivity/meetings')), update:@json(url('/productivity/meetings')), reschedule:@json(url('/productivity/meetings')), rsvp:@json(url('/productivity/meetings')), delete:@json(url('/productivity/meetings'))},
        tasks: {data:@json(route('productivity.tasks.data')), store:@json(route('productivity.tasks.store')), show:@json(url('/productivity/tasks')), update:@json(url('/productivity/tasks')), status:@json(url('/productivity/tasks')), comment:@json(url('/productivity/tasks')), verify:@json(url('/productivity/tasks')), delete:@json(url('/productivity/tasks'))},
        notes: {data:@json(route('productivity.notes.data')), store:@json(route('productivity.notes.store')), update:@json(url('/productivity/notes')), action:@json(url('/productivity/notes'))},
        money: {data:@json(route('productivity.money.data')), account:@json(route('productivity.money.account')), transaction:@json(route('productivity.money.transaction')), budget:@json(route('productivity.money.budget')), commitment:@json(route('productivity.money.commitment'))},
        events: {data:@json(route('productivity.events.data')), calendar:@json(route('productivity.events.calendar')), store:@json(route('productivity.events.store')), show:@json(url('/productivity/events')), update:@json(url('/productivity/events')), delete:@json(url('/productivity/events'))},
        documents: {data:@json(route('productivity.documents.data')), upload:@json(route('productivity.documents.upload')), version:@json(url('/productivity/documents')), versions:@json(url('/productivity/documents')), url:@json(url('/productivity/documents')), pin:@json(url('/productivity/documents')), delete:@json(url('/productivity/documents'))},
        shares: {data:@json(route('productivity.shares.data')), store:@json(route('productivity.shares.store')), approve:@json(url('/productivity/shares')), revoke:@json(url('/productivity/shares'))},
        reports: {data:@json(route('productivity.reports.data')), csv:@json(route('productivity.reports.csv')), xlsx:@json(route('productivity.reports.xlsx'))},
        admin: {data:@json(route('productivity.admin.data')), category:@json(route('productivity.admin.category'))}
    }
};
</script>
@vite('resources/js/productivity/productivity-suite.js')
