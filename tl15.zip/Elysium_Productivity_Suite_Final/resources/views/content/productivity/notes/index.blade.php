@extends('layouts/layoutMaster')
@section('title', 'Sticky Notes')
@section('content')
  @php($module='notes')
  @php($title='Sticky Notes')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
