@extends('layouts/layoutMaster')
@section('title', 'ContactBook')
@section('content')
  @php($module='contacts')
  @php($title='ContactBook')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
