@extends('layouts/layoutMaster')
@section('title', 'Knowledge Panel')
@section('content')
  @php($module='knowledge')
  @php($title='Knowledge Panel')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
