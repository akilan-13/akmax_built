@extends('layouts/layoutMaster')
@section('title', 'Admin')
@section('content')
  @php($module='admin')
  @php($title='Admin')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
