@extends('layouts/layoutMaster')
@section('title', 'My Money')
@section('content')
  @php($module='money')
  @php($title='My Money')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
