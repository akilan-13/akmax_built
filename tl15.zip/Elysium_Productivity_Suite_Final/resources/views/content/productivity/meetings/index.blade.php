@extends('layouts/layoutMaster')
@section('title', 'Meetings')
@section('content')
  @php($module='meetings')
  @php($title='Meetings')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
