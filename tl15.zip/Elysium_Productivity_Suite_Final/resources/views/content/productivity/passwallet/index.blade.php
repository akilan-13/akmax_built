@extends('layouts/layoutMaster')
@section('title', 'PassWallet')
@section('content')
  @php($module='passwallet')
  @php($title='PassWallet')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
