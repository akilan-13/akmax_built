@extends('layouts/layoutMaster')
@section('title', 'Dashboard')
@section('content')
  @php($module='dashboard')
  @php($title='Dashboard')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
