@extends('layouts/layoutMaster')
@section('title', 'Documents')
@section('content')
  @php($module='documents')
  @php($title='Documents')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
