@extends('layouts/layoutMaster')
@section('title', 'Portals & Apps')
@section('content')
  @php($module='portals')
  @php($title='Portals & Apps')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
