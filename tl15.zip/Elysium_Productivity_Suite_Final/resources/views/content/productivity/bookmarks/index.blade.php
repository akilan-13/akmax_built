@extends('layouts/layoutMaster')
@section('title', 'BookMarks')
@section('content')
  @php($module='bookmarks')
  @php($title='BookMarks')
  @include('content.productivity.partials._suite_shell', ['module'=>$module,'title'=>$title])
@endsection
