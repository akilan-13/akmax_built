(() => {
    'use strict';

    const cfg = window.EGPK || {};
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    const state = {
        module: cfg.module || 'dashboard',
        company: 'all',
        page: 1,
        perPage: 25,
        view: 'table',
        rows: [],
        current: null,
        calendarDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        timers: {},
        pendingStepup: null,
        reportType: 'contact_master'
    };

    const el = {
        content: $('#egpkContent'),
        stats: $('#egpkStats'),
        heroTitle: $('#egpkPageTitle'),
        heroSubtitle: $('#egpkPageSubtitle'),
        heroActions: $('#egpkHeroActions'),
        search: $('#egpkSearch'),
        filterOne: $('#egpkFilterOne'),
        filterTwo: $('#egpkFilterTwo'),
        company: $('#egpkCompanySelect'),
        reset: $('#egpkReset'),
        form: $('#egpkForm'),
        fields: $('#egpkFormFields'),
        formTitle: $('#egpkFormTitle'),
        formSubtitle: $('#egpkFormSubtitle'),
        viewTitle: $('#egpkViewTitle'),
        viewSubtitle: $('#egpkViewSubtitle'),
        viewBody: $('#egpkViewBody'),
        global: $('.egpk-global-search'),
        globalResults: $('.egpk-global-results'),
        shareType: $('#egpkShareType'),
        shareId: $('#egpkShareId'),
        shareGrantee: $('#egpkShareGrantee'),
        shareGranteeId: $('#egpkShareGranteeId'),
        sharePermission: $('#egpkSharePermission'),
        shareExpiry: $('#egpkShareExpiry'),
        shareList: $('#egpkShareList'),
        toolsButton: $('#egpkToolsButton'),
        toolMenu: $('#egpkToolMenu'),
        notifButton: $('#egpkNotifButton'),
        notifMenu: $('#egpkNotifMenu'),
        notifList: $('#egpkNotifList'),
        notifCount: $('#egpkNotifCount'),
        stepupModal: $('#egpkStepupModal'),
        stepupPassword: $('#egpkStepupPassword'),
        stepupConfirm: $('#egpkStepupConfirm')
    };

    const modal = {
        form: bootstrap.Modal.getOrCreateInstance($('#egpkFormModal')),
        view: bootstrap.Modal.getOrCreateInstance($('#egpkViewModal')),
        share: bootstrap.Modal.getOrCreateInstance($('#egpkShareModal')),
        confirm: bootstrap.Modal.getOrCreateInstance($('#egpkConfirmModal')),
        stepup: el.stepupModal ? bootstrap.Modal.getOrCreateInstance(el.stepupModal) : null
    };

    const MODULES = {
        dashboard: ['Dashboard', 'Unified productivity workspace'],
        contacts: ['ContactBook', 'Canonical contacts, import/export, sharing and activity'],
        bookmarks: ['BookMarks', 'Boards → categories → bookmarks with collaboration and health'],
        passwallet: ['PassWallet', 'Controlled credentials, sharing, rotation and access audit'],
        knowledge: ['Knowledge Panel', 'Rich-media knowledge, feeds, interaction and moderation'],
        portals: ['Portals & Apps', 'Authoritative application registry and version history'],
        meetings: ['Meetings', 'Agendas, participants, RSVP, rescheduling and calendar'],
        tasks: ['Tasks', 'Personal and delegated work with Kanban and verification'],
        notes: ['Sticky Notes', 'Pinned notes, reminders, checklists and sharing'],
        money: ['My Money', 'Personal accounts, income, expenses, budgets and commitments'],
        events: ['Events', 'Company and personal events with calendar visibility'],
        documents: ['Documents', 'Personal/official document library with versions'],
        reports: ['Reports', 'Role-scoped operational reports and exports'],
        admin: ['Admin', 'Taxonomy, share governance and audit administration']
    };

    function esc(value) {
        return String(value ?? '').replace(/[&<>"']/g, (char) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
        })[char]);
    }

    function toast(message, type = 'success') {
        const node = $('#egpkToast');
        if (!node) return;
        node.className = `toast text-bg-${type === 'error' ? 'danger' : type === 'info' ? 'primary' : 'success'}`;
        node.querySelector('.toast-body').textContent = message;
        bootstrap.Toast.getOrCreateInstance(node, { delay: 3000 }).show();
    }

    async function request(url, options = {}) {
        const headers = {
            Accept: 'application/json',
            ...(options.headers || {})
        };
        let body = options.body;

        if (body instanceof FormData) {
            headers['X-CSRF-TOKEN'] = cfg.csrf;
        } else if (body !== undefined && body !== null) {
            headers['Content-Type'] = 'application/json';
            headers['X-CSRF-TOKEN'] = cfg.csrf;
            body = JSON.stringify(body);
        }

        const response = await fetch(url, {
            ...options,
            credentials: 'same-origin',
            headers,
            body
        });

        let data = null;
        try {
            data = await response.json();
        } catch (error) {
            data = null;
        }

        if (!response.ok) {
            const validation = data?.errors ? Object.values(data.errors).flat()[0] : null;
            const message = data?.message || validation || `Request failed (${response.status})`;
            const err = new Error(message);
            err.payload = data;
            err.status = response.status;
            throw err;
        }
        return data;
    }

    function queryString(data) {
        const params = new URLSearchParams();
        Object.entries(data || {}).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') params.set(key, value);
        });
        return params.toString();
    }

    function nowInputDate() {
        const date = new Date();
        const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
        return local.toISOString().slice(0, 16);
    }

    function formatDateTime(value) {
        if (!value) return '-';
        const d = new Date(String(value).replace(' ', 'T'));
        return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    }

    function formatDate(value) {
        if (!value) return '-';
        const d = new Date(`${String(value).slice(0, 10)}T00:00:00`);
        return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    function titleCase(value) {
        return String(value || '').replaceAll('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase());
    }

    function badge(value) {
        if (value === null || value === undefined || value === '') return '-';
        const v = String(value);
        let tone = 'slate';
        if (/completed|live|confirmed|healthy|active|accepted|published|success/i.test(v)) tone = 'green';
        else if (/cancel|broken|overdue|urgent|deprecated|unpublished|rejected|trashed/i.test(v)) tone = 'red';
        else if (/pending|due|warning|high|postponed|maintenance|draft|scheduled/i.test(v)) tone = 'amber';
        else if (/group|manage|company|in progress/i.test(v)) tone = 'purple';
        else if (/todo|low|medium|production|staging|view/i.test(v)) tone = 'blue';
        return `<span class="egpk-badge egpk-badge-${tone}">${esc(v)}</span>`;
    }

    function setStats(stats = {}) {
        el.stats.innerHTML = Object.entries(stats).map(([key, value]) => `
            <div class="egpk-stat">
                <label>${esc(titleCase(key))}</label>
                <strong>${esc(value)}</strong>
            </div>
        `).join('');
    }

    function setHero() {
        const [title, subtitle] = MODULES[state.module] || MODULES.dashboard;
        el.heroTitle.textContent = title;
        el.heroSubtitle.textContent = subtitle;

        let actions = '';
        if (state.module === 'contacts') {
            actions += `<button class="egpk-btn egpk-btn-outline" data-hero="contact-import"><i class="mdi mdi-upload-outline me-1"></i>Import</button>`;
            actions += `<a class="egpk-btn egpk-btn-outline" href="${esc(cfg.urls.contacts.exportCsv)}"><i class="mdi mdi-download-outline me-1"></i>CSV</a>`;
            actions += `<a class="egpk-btn egpk-btn-outline" href="${esc(cfg.urls.contacts.exportXlsx)}"><i class="mdi mdi-file-excel-outline me-1"></i>XLSX</a>`;
        }
        if (state.module === 'bookmarks') {
            actions += `<button class="egpk-btn egpk-btn-outline" data-hero="bookmark-import"><i class="mdi mdi-import"></i> Browser Import</button>`;
            actions += `<button class="egpk-btn egpk-btn-outline" data-hero="bookmark-quick"><i class="mdi mdi-link-plus"></i> Quick Add</button>`;
        }
        if (state.module === 'passwallet') actions += `<button class="egpk-btn egpk-btn-outline" data-hero="generator"><i class="mdi mdi-key-variant me-1"></i>Generator</button>`;
        if (state.module === 'meetings' || state.module === 'events') actions += `<button class="egpk-btn egpk-btn-outline" data-hero="calendar"><i class="mdi mdi-calendar-month-outline me-1"></i>Calendar</button>`;
        if (state.module === 'tasks') actions += `<button class="egpk-btn egpk-btn-outline" data-hero="kanban"><i class="mdi mdi-view-column-outline me-1"></i>Kanban</button>`;
        if (state.module === 'portals') actions += `<a class="egpk-btn egpk-btn-outline" href="${esc(cfg.urls.portals.exportXlsx)}"><i class="mdi mdi-file-excel-outline me-1"></i>Export XLSX</a>`;
        if (state.module === 'reports') actions += `<button class="egpk-btn egpk-btn-gold" data-hero="report-refresh"><i class="mdi mdi-refresh me-1"></i>Refresh</button>`;
        if (['dashboard', 'reports', 'admin'].indexOf(state.module) === -1 && state.module !== 'money' && state.module !== 'documents') {
            const label = state.module === 'bookmarks' ? 'New Board' : `New ${MODULES[state.module][0].replace('Book', '')}`;
            actions += `<button class="egpk-btn egpk-btn-gold" data-hero="add"><i class="mdi mdi-plus me-1"></i>${esc(label)}</button>`;
        }
        if (state.module === 'money') actions += `<button class="egpk-btn egpk-btn-gold" data-hero="money-transaction"><i class="mdi mdi-plus me-1"></i>New Transaction</button>`;
        if (state.module === 'documents') actions += `<button class="egpk-btn egpk-btn-gold" data-hero="document-upload"><i class="mdi mdi-upload me-1"></i>Upload</button>`;
        if (state.module === 'admin') actions += `<button class="egpk-btn egpk-btn-gold" data-hero="category"><i class="mdi mdi-tag-plus-outline me-1"></i>New Category</button>`;
        el.heroActions.innerHTML = actions;
    }

    function applyFilterOptions() {
        const m = state.module;
        el.filterOne.style.display = '';
        el.filterTwo.style.display = '';
        el.filterOne.innerHTML = '<option value="">All</option>';
        el.filterTwo.innerHTML = '<option value="">All Status</option>';

        const options = (values, all = 'All') => `<option value="">${esc(all)}</option>${values.map((v) => `<option value="${esc(v.value ?? v)}">${esc(v.label ?? v)}</option>`).join('')}`;

        if (m === 'contacts') {
            el.filterOne.innerHTML = options([], 'All Categories');
            el.filterTwo.innerHTML = options(['Private', 'Company', 'Group'], 'All Visibility');
        } else if (m === 'bookmarks') {
            el.filterOne.innerHTML = options(['healthy', 'broken', 'unknown'], 'All Health');
            el.filterTwo.style.display = 'none';
        } else if (m === 'passwallet') {
            el.filterOne.innerHTML = options(['Website', 'System', 'Application', 'Mobile App'], 'All Types');
            el.filterTwo.innerHTML = options(['Private', 'Team', 'Company'], 'All Visibility');
        } else if (m === 'knowledge') {
            el.filterOne.innerHTML = options([], 'All Categories');
            el.filterTwo.innerHTML = options(['draft', 'published', 'unpublished'], 'All Status');
        } else if (m === 'portals') {
            el.filterOne.innerHTML = options(['Production', 'Staging'], 'All Environments');
            el.filterTwo.innerHTML = options(['Live', 'Under Maintenance', 'Deprecated'], 'All Status');
        } else if (m === 'meetings') {
            el.filterOne.innerHTML = options(['Review', 'Client', 'Training', 'HR', 'Planning'], 'All Categories');
            el.filterTwo.innerHTML = options(['Scheduled', 'In Progress', 'Completed', 'Cancelled', 'Postponed'], 'All Status');
        } else if (m === 'tasks') {
            el.filterOne.innerHTML = options(['Low', 'Medium', 'High', 'Urgent'], 'All Priority');
            el.filterTwo.innerHTML = options(['To Do', 'In Progress', 'On Hold', 'Pending Verification', 'Completed'], 'All Status');
        } else if (m === 'events') {
            el.filterOne.innerHTML = options(['Meeting', 'Event', 'Function', 'Seminar', 'Workshop', 'Annual Event'], 'All Types');
            el.filterTwo.innerHTML = options(['Planned', 'Confirmed', 'Completed', 'Cancelled'], 'All Status');
        } else if (m === 'documents') {
            el.filterOne.innerHTML = options(['Personal', 'Official'], 'All Scope');
            el.filterTwo.style.display = 'none';
        } else if (m === 'notes') {
            el.filterOne.innerHTML = options(['normal', 'high'], 'All Priority');
            el.filterTwo.innerHTML = options(['active', 'archived', 'trashed'], 'All Status');
        } else {
            el.filterOne.innerHTML = options([], 'All Types');
        }
    }

    function buildFiltersQuery() {
        const q = {
            company_id: state.company,
            search: el.search.value.trim(),
            page: state.page,
            per_page: state.perPage
        };

        const one = el.filterOne.value;
        const two = el.filterTwo.value;
        if (one && el.filterOne.style.display !== 'none') {
            const map = {
                contacts: 'category_id', bookmarks: 'health_status', passwallet: 'entry_type', knowledge: 'category_id', portals: 'environment', meetings: 'category', tasks: 'priority', events: 'event_type', documents: 'scope', notes: 'priority'
            };
            if (map[state.module]) q[map[state.module]] = one;
        }
        if (two && el.filterTwo.style.display !== 'none') {
            const map = { contacts: 'visibility', passwallet: 'visibility', knowledge: 'status', portals: 'status', meetings: 'status', tasks: 'status', events: 'status', notes: 'status' };
            if (map[state.module]) q[map[state.module]] = two;
        }
        return q;
    }

    function columnsFor(module) {
        const map = {
            contacts: [['person_name', 'Contact'], ['organisation', 'Organisation'], ['designation', 'Designation'], ['phone_primary', 'Phone'], ['email_primary', 'Email'], ['city', 'City'], ['visibility', 'Visibility']],
            bookmarks: [['bookmark_name', 'Bookmark'], ['url', 'URL'], ['board.board_name', 'Board'], ['category.category_name', 'Category'], ['health_status', 'Health'], ['click_count', 'Clicks']],
            passwallet: [['entry_name', 'Entry'], ['entry_type', 'Type'], ['username', 'Username'], ['visibility', 'Scope'], ['next_rotation_at', 'Rotation']],
            knowledge: [['title', 'Post'], ['status', 'Status'], ['audience_scope', 'Audience'], ['edit_version', 'Version'], ['published_at', 'Published']],
            portals: [['app_name', 'Application'], ['platform', 'Platform'], ['environment', 'Environment'], ['status', 'Status'], ['current_version', 'Version']],
            meetings: [['title', 'Meeting'], ['category', 'Category'], ['start_at', 'Start'], ['end_at', 'End'], ['status', 'Status']],
            tasks: [['title', 'Task'], ['category', 'Category'], ['priority', 'Priority'], ['due_at', 'Due'], ['status', 'Status']],
            notes: [['title', 'Title'], ['label', 'Label'], ['priority', 'Priority'], ['reminder_at', 'Reminder'], ['status', 'Status']],
            events: [['event_name', 'Event'], ['event_type', 'Type'], ['organisation', 'Organisation'], ['event_date', 'Date'], ['status', 'Status']],
            documents: [['document_name', 'Document'], ['scope', 'Scope'], ['category', 'Category'], ['version_no', 'Version'], ['expiry_date', 'Expiry']],
            money: [['account_name', 'Account'], ['current_balance', 'Balance'], ['account_type', 'Type']]
        };
        return map[module] || [];
    }

    function nestedValue(obj, path) {
        return path.split('.').reduce((acc, part) => acc == null ? undefined : acc[part], obj);
    }

    function valueCell(row, path) {
        const value = nestedValue(row, path);
        if (value === null || value === undefined || value === '') return '<span class="egpk-muted">—</span>';
        if (['status', 'visibility', 'priority', 'health_status', 'scope'].includes(path)) return badge(value);
        if (/(_at|_date)$/.test(path)) return `<span class="egpk-muted">${esc(path.endsWith('_at') ? formatDateTime(value) : formatDate(value))}</span>`;
        if (path === 'url') return `<span title="${esc(value)}">${esc(value)}</span>`;
        if (['amount', 'current_balance', 'opening_balance', 'payment_amount'].includes(path)) return `₹ ${Number(value).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
        return esc(value);
    }

    function rowAction(module, row) {
        const id = row.sno;
        const actions = [`<button class="dropdown-item" data-action="view" data-id="${id}"><i class="mdi mdi-eye-outline me-2"></i>View</button>`];
        const editable = !['money', 'documents'].includes(module) || module === 'documents';
        if (editable) actions.push(`<button class="dropdown-item" data-action="edit" data-id="${id}"><i class="mdi mdi-pencil-outline me-2"></i>Edit</button>`);
        if (['contacts','bookmarks','passwallet','knowledge','portals','meetings','tasks','notes','events','documents'].includes(module)) actions.push(`<button class="dropdown-item" data-action="share" data-id="${id}"><i class="mdi mdi-share-variant-outline me-2"></i>Share</button>`);
        if (module === 'contacts') actions.push(`<button class="dropdown-item" data-action="star" data-id="${id}"><i class="mdi mdi-star-outline me-2"></i>${row.is_starred ? 'Unstar' : 'Star'}</button>`);
        if (module === 'bookmarks') {
            actions.push(`<button class="dropdown-item" data-action="open" data-id="${id}"><i class="mdi mdi-open-in-new me-2"></i>Open</button>`);
            actions.push(`<button class="dropdown-item" data-action="health" data-id="${id}"><i class="mdi mdi-link-check me-2"></i>Check Health</button>`);
        }
        if (module === 'passwallet') {
            actions.push(`<button class="dropdown-item" data-action="reveal" data-id="${id}"><i class="mdi mdi-eye-lock-open-outline me-2"></i>Reveal</button>`);
            actions.push(`<button class="dropdown-item" data-action="history" data-id="${id}"><i class="mdi mdi-history me-2"></i>Password History</button>`);
        }
        if (module === 'knowledge') {
            actions.push(`<button class="dropdown-item" data-action="like" data-id="${id}"><i class="mdi mdi-thumb-up-outline me-2"></i>Like / Unlike</button>`);
            actions.push(`<button class="dropdown-item" data-action="save" data-id="${id}"><i class="mdi mdi-bookmark-outline me-2"></i>Save / Unsave</button>`);
            actions.push(`<button class="dropdown-item" data-action="reply" data-id="${id}"><i class="mdi mdi-reply-outline me-2"></i>Reply</button>`);
            actions.push(`<button class="dropdown-item" data-action="report" data-id="${id}"><i class="mdi mdi-flag-outline me-2"></i>Report</button>`);
        }
        if (module === 'portals') {
            actions.push(`<button class="dropdown-item" data-action="launch" data-id="${id}"><i class="mdi mdi-open-in-new me-2"></i>Open App</button>`);
            actions.push(`<button class="dropdown-item" data-action="version" data-id="${id}"><i class="mdi mdi-update me-2"></i>Record Version</button>`);
            actions.push(`<button class="dropdown-item" data-action="subscribe" data-id="${id}"><i class="mdi mdi-bell-outline me-2"></i>Subscribe</button>`);
        }
        if (module === 'meetings') {
            actions.push(`<button class="dropdown-item" data-action="rsvp" data-id="${id}"><i class="mdi mdi-account-check-outline me-2"></i>RSVP</button>`);
            actions.push(`<button class="dropdown-item" data-action="reschedule" data-id="${id}"><i class="mdi mdi-calendar-edit-outline me-2"></i>Reschedule</button>`);
        }
        if (module === 'tasks') {
            actions.push(`<button class="dropdown-item" data-action="status" data-id="${id}"><i class="mdi mdi-progress-check me-2"></i>Change Status</button>`);
            actions.push(`<button class="dropdown-item" data-action="comment" data-id="${id}"><i class="mdi mdi-comment-plus-outline me-2"></i>Add Comment</button>`);
            if (row.verification_required) actions.push(`<button class="dropdown-item" data-action="verify" data-id="${id}"><i class="mdi mdi-check-decagram-outline me-2"></i>Verify</button>`);
        }
        if (module === 'notes') {
            actions.push(`<button class="dropdown-item" data-action="pin" data-id="${id}"><i class="mdi mdi-pin-outline me-2"></i>Pin / Unpin</button>`);
            actions.push(`<button class="dropdown-item" data-action="archive" data-id="${id}"><i class="mdi mdi-archive-outline me-2"></i>Archive</button>`);
            actions.push(`<button class="dropdown-item text-danger" data-action="trash" data-id="${id}"><i class="mdi mdi-trash-can-outline me-2"></i>Trash</button>`);
        }
        if (module === 'documents') {
            actions.push(`<button class="dropdown-item" data-action="version" data-id="${id}"><i class="mdi mdi-file-replace-outline me-2"></i>New Version</button>`);
            actions.push(`<button class="dropdown-item" data-action="pin" data-id="${id}"><i class="mdi mdi-pin-outline me-2"></i>Pin / Unpin</button>`);
            actions.push(`<button class="dropdown-item" data-action="download" data-id="${id}"><i class="mdi mdi-download-outline me-2"></i>Open / Download</button>`);
        }
        if (['contacts','bookmarks','passwallet','meetings','tasks','events','documents'].includes(module)) actions.push(`<div class="dropdown-divider"></div><button class="dropdown-item text-danger" data-action="delete" data-id="${id}"><i class="mdi mdi-delete-outline me-2"></i>Delete</button>`);
        return `<div class="dropdown"><button class="btn btn-sm btn-light border" data-bs-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></button><div class="dropdown-menu dropdown-menu-end">${actions.join('')}</div></div>`;
    }

    function renderTable(rows) {
        const columns = columnsFor(state.module);
        if (!columns.length) return '<div class="egpk-card egpk-empty">No table view configured for this module.</div>';
        return `<div class="egpk-card egpk-table-wrap"><table class="egpk-table"><thead><tr>${columns.map(([, label]) => `<th>${esc(label)}</th>`).join('')}<th class="text-end">Action</th></tr></thead><tbody>${rows.length ? rows.map((row) => `<tr>${columns.map(([key]) => `<td>${valueCell(row, key)}</td>`).join('')}<td class="text-end egpk-actions-cell">${rowAction(state.module, row)}</td></tr>`).join('') : `<tr><td colspan="${columns.length + 1}"><div class="egpk-empty">No records found.</div></td></tr>`}</tbody></table></div>`;
    }

    function renderCards(rows) {
        if (!rows.length) return '<div class="egpk-card egpk-empty">No records found.</div>';
        return `<div class="row g-2">${rows.map((row) => {
            const title = row.person_name || row.bookmark_name || row.entry_name || row.title || row.app_name || row.event_name || row.document_name || row.account_name || 'Record';
            const sub = row.organisation || row.url || row.category || row.status || row.event_type || row.scope || '';
            return `<div class="col-sm-6 col-xl-4"><div class="egpk-card p-3 h-100"><div class="d-flex justify-content-between gap-2"><div><div class="egpk-row-title">${esc(title)}</div><div class="egpk-row-sub">${esc(sub)}</div></div>${badge(row.status || row.visibility || row.health_status || row.priority || '')}</div><div class="row g-2 mt-2">${columnsFor(state.module).slice(0,4).map(([key,label]) => `<div class="col-6"><small class="text-muted d-block text-uppercase" style="font-size:7px;font-weight:800">${esc(label)}</small><div class="mt-1" style="font-size:9.5px">${valueCell(row,key)}</div></div>`).join('')}</div><div class="mt-3 text-end">${rowAction(state.module,row)}</div></div></div>`;
        }).join('')}</div>`;
    }

    function renderPagination(page) {
        const current = Number(page?.current_page || 1);
        const last = Number(page?.last_page || 1);
        const total = Number(page?.total || 0);
        if (last <= 1) return '';
        return `<div class="d-flex justify-content-between align-items-center mt-2 small text-muted"><span>${total} records</span><div class="btn-group btn-group-sm">${Array.from({ length: Math.min(last, 7) }, (_, i) => { const n = Math.max(1, Math.min(last - 6, current - 3)) + i; return n <= last ? `<button class="btn ${n===current?'btn-primary':'btn-light border'}" data-page="${n}">${n}</button>` : ''; }).join('')}</div></div>`;
    }

    function typeFromCalendarRow(row) {
        return state.module === 'meetings' ? row.title : row.event_name;
    }

    function calendarEventDate(row) {
        return state.module === 'meetings' ? String(row.start_at).slice(0,10) : String(row.event_date).slice(0,10);
    }

    function calendarEventColor(row) {
        const value = String(row.status || '');
        if (/cancel/i.test(value)) return '#FDECEC';
        if (/complete/i.test(value)) return '#E7F6ED';
        if (/postponed|planned/i.test(value)) return '#FDF3E2';
        return '#E8F1FF';
    }

    async function loadCalendar() {
        const year = state.calendarDate.getFullYear();
        const month = state.calendarDate.getMonth();
        const start = new Date(year, month, 1);
        const end = new Date(year, month + 1, 0);
        const endpoint = state.module === 'meetings' ? cfg.urls.meetings.calendar : cfg.urls.events.calendar;
        const data = await request(`${endpoint}?${queryString({ company_id: state.company, start: start.toISOString().slice(0,10), end: end.toISOString().slice(0,10) })}`);
        const rows = data.data?.rows || data.data || [];
        state.rows = rows;
        renderCalendar(rows);
    }

    function renderCalendar(rows) {
        const year = state.calendarDate.getFullYear();
        const month = state.calendarDate.getMonth();
        const first = new Date(year, month, 1);
        const last = new Date(year, month + 1, 0);
        const days = [];
        for (let i = 0; i < first.getDay(); i++) days.push(null);
        for (let d = 1; d <= last.getDate(); d++) days.push(new Date(year, month, d));
        while (days.length % 7) days.push(null);

        el.content.innerHTML = `<div class="egpk-calendar-wrap"><div class="egpk-calendar"><div class="egpk-cal-top"><div><strong>${first.toLocaleString('en-IN',{month:'long',year:'numeric'})}</strong><div class="small text-muted">${rows.length} item(s)</div></div><div class="egpk-calendar-nav"><button data-calendar="prev"><i class="mdi mdi-chevron-left"></i></button><button data-calendar="today">Today</button><button data-calendar="next"><i class="mdi mdi-chevron-right"></i></button></div></div><div class="egpk-cal-head">${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d)=>`<div>${d}</div>`).join('')}</div><div class="egpk-cal-grid">${days.map((d) => {
            if (!d) return '<div class="egpk-cal-day other"></div>';
            const key = d.toISOString().slice(0,10);
            const isToday = key === new Date().toISOString().slice(0,10);
            const dayRows = rows.filter((r) => calendarEventDate(r) === key);
            return `<div class="egpk-cal-day ${isToday?'today':''}"><div class="egpk-cal-num">${d.getDate()}</div>${dayRows.slice(0,5).map((r)=>`<button class="egpk-cal-event" style="background:${calendarEventColor(r)}" data-action="view" data-id="${r.sno}">${esc(typeFromCalendarRow(r))}<br><span class="egpk-muted">${state.module==='meetings'?esc(formatDateTime(r.start_at).split(', ')[1]||''):esc(r.event_time||'')}</span></button>`).join('')}${dayRows.length>5?`<div class="small text-muted">+ ${dayRows.length-5} more</div>`:''}</div>`;
        }).join('')}</div></div></div>`;
    }

    function renderBoard(rows) {
        const boards = {};
        rows.forEach((row) => {
            const boardName = row.board?.board_name || row.board_name || 'Board';
            if (!boards[boardName]) boards[boardName] = [];
            boards[boardName].push(row);
        });
        const entries = Object.entries(boards);
        if (!entries.length) return '<div class="egpk-card egpk-empty">No bookmarks found.</div>';
        return `<div class="egpk-board-grid">${entries.map(([name, items]) => `<div class="egpk-board-col"><div class="egpk-board-head"><span>${esc(name)}</span><span class="egpk-badge egpk-badge-blue">${items.length}</span></div>${items.map((b)=>`<a href="javascript:void(0)" class="egpk-link" data-action="open" data-id="${b.sno}"><img class="egpk-favicon" src="${esc(b.favicon_url||'')}" onerror="this.style.visibility='hidden'"><span style="min-width:0"><span class="egpk-link-title d-block">${esc(b.bookmark_name)}</span><span class="egpk-link-domain d-block">${esc(b.url)}</span></span></a>`).join('')}</div>`).join('')}</div>`;
    }

    function renderFeed(rows) {
        if (!rows.length) return '<div class="egpk-card egpk-empty">No knowledge posts found.</div>';
        return `<div class="egpk-feed"><div>${rows.map((p)=>`<article class="egpk-card egpk-post mb-2"><div class="egpk-post-top"><div><div class="small text-muted">${esc(p.author_name||p.author_user_id||'Author')} · ${esc(p.company_name||'')}</div><div class="egpk-post-title mt-1">${esc(p.title)}</div></div>${badge(p.status)}</div><div class="egpk-post-body">${p.body_html ? p.body_html : '<span class="text-muted">No body content.</span>'}</div>${p.media_count?`<div class="egpk-media"><i class="mdi mdi-paperclip"></i> ${p.media_count} media attachment(s)</div>`:''}<div class="egpk-actions-row"><button class="egpk-small-btn" data-action="like" data-id="${p.sno}"><i class="mdi mdi-thumb-up-outline"></i> ${p.reactions_count||0}</button><button class="egpk-small-btn" data-action="reply" data-id="${p.sno}"><i class="mdi mdi-reply-outline"></i> ${p.replies_count||0}</button><button class="egpk-small-btn" data-action="save" data-id="${p.sno}"><i class="mdi mdi-bookmark-outline"></i> ${p.saves_count||0}</button><button class="egpk-small-btn" data-action="view" data-id="${p.sno}">Open</button></div></article>`).join('')}</div><aside><div class="egpk-card egpk-sidecard"><div class="fw-bold mb-2">Knowledge shortcuts</div><button class="btn btn-sm btn-light border w-100 text-start mb-1" data-hero="add"><i class="mdi mdi-plus me-2"></i>New post</button><button class="btn btn-sm btn-light border w-100 text-start mb-1" data-hero="knowledge-saved"><i class="mdi mdi-bookmark me-2"></i>My Saved Library</button><button class="btn btn-sm btn-light border w-100 text-start" data-hero="knowledge-trending"><i class="mdi mdi-fire me-2"></i>Trending</button></div></aside></div>`;
    }

    function renderKanban(rows) {
        const columns = ['To Do','In Progress','On Hold','Pending Verification','Completed'];
        return `<div class="egpk-kanban">${columns.map((status)=>`<div class="egpk-kanban-col"><div class="egpk-kanban-head d-flex justify-content-between"><span>${status}</span><span>${rows.filter(r=>r.status===status).length}</span></div>${rows.filter(r=>r.status===status).map((t)=>`<div class="egpk-task" data-action="view" data-id="${t.sno}"><div class="fw-bold" style="font-size:10px">${esc(t.title)}</div><div class="small text-muted mt-1">${esc(t.category||'')}</div><div class="mt-2">${badge(t.priority)}</div><div class="small text-muted mt-2">${t.due_at?formatDateTime(t.due_at):'No deadline'}</div></div>`).join('')||'<div class="small text-muted p-2">No tasks</div>'}</div>`).join('')}</div>`;
    }

    function renderNotes(rows) {
        if (!rows.length) return '<div class="egpk-card egpk-empty">No notes found.</div>';
        return `<div class="egpk-note-grid">${rows.map((n)=>`<div class="egpk-note" style="background:${esc(n.color||'#FFF6D9')}"><div class="d-flex justify-content-between gap-2"><strong style="font-size:11px">${esc(n.title||'Untitled')}</strong>${n.is_pinned?'<i class="mdi mdi-pin" style="font-size:14px"></i>':''}</div><div class="small mt-2" style="white-space:pre-wrap">${esc(n.body||'')}</div><div class="small text-muted mt-3">${n.reminder_at?`Reminder: ${formatDateTime(n.reminder_at)}`:'No reminder'}</div><div class="mt-2">${badge(n.priority)} ${badge(n.status)}</div></div>`).join('')}</div>`;
    }

    async function loadModule() {
        setHero();
        applyFilterOptions();
        el.content.innerHTML = '<div class="egpk-card egpk-loader"><span class="spinner-border spinner-border-sm me-2"></span>Loading...</div>';
        if (state.module === 'dashboard') return loadDashboard();
        if (state.module === 'money') return loadMoney();
        if (state.module === 'reports') return renderReports();
        if (state.module === 'admin') return loadAdmin();
        if ((state.module === 'meetings' || state.module === 'events') && state.view === 'calendar') {
            try { await loadCalendar(); } catch (error) { showLoadError(error); }
            return;
        }

        const endpoint = cfg.urls[state.module]?.data;
        if (!endpoint) {
            el.content.innerHTML = '<div class="egpk-card egpk-empty">Module endpoint is not configured.</div>';
            return;
        }

        try {
            const data = await request(`${endpoint}?${queryString(buildFiltersQuery())}`);
            const rows = data.data?.rows?.data || data.data?.rows || data.data || [];
            state.rows = Array.isArray(rows) ? rows : [];
            const payload = data.data || {};
            const stats = payload.stats || (data.stats || null);
            if (stats) setStats(stats);
            else setStats({ total: payload.total ?? state.rows.length });

            if (state.module === 'bookmarks') el.content.innerHTML = renderBoard(state.rows);
            else if (state.module === 'knowledge') el.content.innerHTML = renderFeed(state.rows);
            else if (state.module === 'tasks' && state.view === 'card') el.content.innerHTML = renderKanban(state.rows);
            else if (state.module === 'notes' && state.view === 'card') el.content.innerHTML = renderNotes(state.rows);
            else if (state.view === 'card') el.content.innerHTML = renderCards(state.rows);
            else el.content.innerHTML = `${renderTable(state.rows)}${renderPagination(data.data?.rows)}`;
        } catch (error) {
            showLoadError(error);
        }
    }

    function showLoadError(error) {
        el.content.innerHTML = `<div class="egpk-card egpk-empty text-danger"><i class="mdi mdi-alert-outline fs-3 d-block mb-2"></i>${esc(error.message)}</div>`;
        toast(error.message, 'error');
    }

    async function loadDashboard() {
        try {
            const d = await request(cfg.urls.dashboard);
            const k = d.data?.kpis || {};
            setStats(k);
            const attention = d.data?.attention || {};
            const trend = d.data?.adoption || [];
            el.content.innerHTML = `<div class="row g-2"><div class="col-xl-7"><div class="egpk-card p-3"><div class="d-flex justify-content-between align-items-center"><strong>Attention</strong><span class="small text-muted">Actionable items</span></div>${Object.entries(attention).map(([key,val])=>`<div class="d-flex justify-content-between align-items-center py-2 border-bottom"><span style="font-size:10px">${esc(titleCase(key))}</span>${badge(val)}</div>`).join('')}</div></div><div class="col-xl-5"><div class="egpk-card p-3"><strong>Adoption / Activity</strong>${trend.slice(-12).map((x)=>`<div class="d-flex justify-content-between py-2 border-bottom small"><span>${esc(x.label)}</span><span>Contacts ${esc(x.contacts)} · Knowledge ${esc(x.knowledge)}</span></div>`).join('')}</div></div></div>`;
            loadNotifications(attention);
        } catch (error) { showLoadError(error); }
    }

    async function loadMoney() {
        try {
            const d = await request(cfg.urls.money.data);
            const data = d.data || {};
            setStats({ balance: Number(data.summary?.balance || 0).toLocaleString('en-IN',{style:'currency',currency:'INR'}), income: Number(data.summary?.income||0).toLocaleString('en-IN',{style:'currency',currency:'INR'}), expense: Number(data.summary?.expense||0).toLocaleString('en-IN',{style:'currency',currency:'INR'}), accounts: (data.accounts||[]).length, commitments: (data.commitments||[]).length, budgets: (data.budgets||[]).length });
            el.content.innerHTML = `<div class="row g-2"><div class="col-xl-7"><div class="egpk-card egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Account</th><th>Type</th><th>Balance</th></tr></thead><tbody>${(data.accounts||[]).map((a)=>`<tr><td>${esc(a.account_name)}</td><td>${esc(a.account_type)}</td><td>₹ ${Number(a.current_balance||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</td></tr>`).join('')}</tbody></table></div></div><div class="col-xl-5"><div class="egpk-card p-3"><strong>Commitments</strong>${(data.commitments||[]).map((c)=>`<div class="d-flex justify-content-between py-2 border-bottom small"><span>${esc(c.commitment_name)}<small class="d-block text-muted">${formatDate(c.due_date)}</small></span><strong>₹ ${Number(c.amount||0).toLocaleString('en-IN',{minimumFractionDigits:2})}</strong></div>`).join('')||'<div class="small text-muted mt-3">No upcoming commitments.</div>'}</div></div></div>`;
        } catch (error) { showLoadError(error); }
    }

    async function loadAdmin() {
        try {
            const d = await request(cfg.urls.admin.data);
            const data = d.data || {};
            el.content.innerHTML = `<div class="row g-2"><div class="col-xl-6"><div class="egpk-card p-3"><div class="d-flex justify-content-between"><strong>Sharing Register</strong><span class="small text-muted">${(data.shares||[]).length}</span></div><div class="table-responsive mt-2"><table class="table table-sm align-middle mb-0"><thead><tr><th>Resource</th><th>Recipient</th><th>Permission</th><th>Status</th><th></th></tr></thead><tbody>${(data.shares||[]).slice(0,50).map((s)=>`<tr><td>${esc(s.resource_type)} #${s.resource_id}</td><td>${esc(s.grantee_type)}:${esc(s.grantee_id)}</td><td>${badge(s.permission)}</td><td>${badge(s.status)}</td><td>${s.status==='pending'?`<button class="btn btn-sm btn-success" data-admin-approve="${s.sno}">Approve</button>`:''}</td></tr>`).join('')}</tbody></table></div></div></div><div class="col-xl-6"><div class="egpk-card p-3"><strong>Recent Audit</strong>${(data.audits||[]).slice(0,20).map((a)=>`<div class="py-2 border-bottom small"><div class="fw-bold">${esc(a.action)}</div><div class="text-muted">${esc(a.module_name)} · ${esc(a.actor_name||'-')} · ${esc(a.created_at)}</div></div>`).join('')}</div></div></div>`;
        } catch (error) { showLoadError(error); }
    }

    const REPORTS = [
        ['contact_master','Contact Master','contacts and visibility'],
        ['import_audit','Import Audit','source, imported, merged, skipped'],
        ['board_health','Board Health','broken links and bookmark usage'],
        ['credential_compliance','Credential Compliance','rotation status without secrets'],
        ['vault_access_audit','Vault Access Audit','reveal/copy/change/share events'],
        ['knowledge_engagement','Knowledge Engagement','likes, replies, saves'],
        ['application_inventory','Application Inventory','company-wise portal/app registry'],
        ['version_change_log','Version Change Log','chronological releases and bug fixes']
    ];

    function renderReports() {
        setStats({ reports: REPORTS.length, exports: 'CSV + XLSX', scope: state.company === 'all' ? 'All companies' : 'Selected company' });
        el.content.innerHTML = `<div class="row g-2">${REPORTS.map(([id,name,desc])=>`<div class="col-md-6 col-xl-4"><div class="egpk-card p-3 h-100"><div class="d-flex justify-content-between gap-2"><strong>${esc(name)}</strong><i class="mdi mdi-chart-box-outline text-muted"></i></div><div class="small text-muted mt-1">${esc(desc)}</div><div class="mt-3 d-flex gap-2"><button class="egpk-btn egpk-btn-gold" data-report-view="${id}">View</button><a class="egpk-btn egpk-btn-light border" href="${cfg.urls.reports.csv}?type=${encodeURIComponent(id)}&company_id=${encodeURIComponent(state.company)}">CSV</a><a class="egpk-btn egpk-btn-light border" href="${cfg.urls.reports.xlsx}?type=${encodeURIComponent(id)}&company_id=${encodeURIComponent(state.company)}">XLSX</a></div></div></div>`).join('')}</div><div id="egpkReportResult" class="mt-2"></div>`;
    }

    async function viewReport(type) {
        state.reportType = type;
        const holder = $('#egpkReportResult');
        if (!holder) return;
        holder.innerHTML = '<div class="egpk-card egpk-loader">Loading report...</div>';
        try {
            const d = await request(`${cfg.urls.reports.data}?type=${encodeURIComponent(type)}&company_id=${encodeURIComponent(state.company)}`);
            const rows = d.data?.data || [];
            const keys = Object.keys(rows[0] || {});
            holder.innerHTML = `<div class="egpk-card egpk-table-wrap"><table class="egpk-table"><thead><tr>${keys.map((k)=>`<th>${esc(titleCase(k))}</th>`).join('')}</tr></thead><tbody>${rows.map((r)=>`<tr>${keys.map((k)=>`<td>${typeof r[k]==='object'?esc(JSON.stringify(r[k])):esc(r[k] ?? '—')}</td>`).join('')}</tr>`).join('')||'<tr><td><div class="egpk-empty">No rows.</div></td></tr>'}</tbody></table></div>`;
        } catch (error) { holder.innerHTML = `<div class="egpk-card egpk-empty text-danger">${esc(error.message)}</div>`; }
    }

    async function loadCompanies() {
        try {
            const d = await request(cfg.urls.companies);
            el.company.innerHTML = '<option value="all">All Companies</option>' + (d.data || []).map((company)=>`<option value="${company.sno}">${esc(company.company_short_name || company.company_name)}</option>`).join('');
            el.company.value = state.company;
        } catch (error) { console.warn(error); }
    }

    async function loadDynamicFilters() {
        try {
            if (state.module === 'contacts') {
                const d = await request(cfg.urls.contacts.categories);
                el.filterOne.innerHTML = '<option value="">All Categories</option>' + (d.data || []).map((c)=>`<option value="${c.sno}">${esc(c.category_name)}</option>`).join('');
            }
            if (state.module === 'knowledge') {
                const d = await request(cfg.urls.knowledge.categories);
                el.filterOne.innerHTML = '<option value="">All Categories</option>' + (d.data?.categories || []).map((c)=>`<option value="${c.sno}">${esc(c.category_name)}</option>`).join('');
            }
        } catch (error) { console.warn(error); }
    }

    function field(name, label, type='text', value='', attrs='') {
        return `<div class="col-md-6 egpk-field"><label>${esc(label)}</label><input class="form-control" type="${type}" name="${esc(name)}" value="${esc(value)}" ${attrs}></div>`;
    }

    function selectField(name, label, values, value='') {
        return `<div class="col-md-6 egpk-field"><label>${esc(label)}</label><select class="form-select" name="${esc(name)}">${values.map((item)=>{const v=item.value??item;const l=item.label??item;return `<option value="${esc(v)}" ${String(v)===String(value??'')?'selected':''}>${esc(l)}</option>`;}).join('')}</select></div>`;
    }

    function textareaField(name, label, value='') {
        return `<div class="col-12 egpk-field"><label>${esc(label)}</label><textarea class="form-control" name="${esc(name)}" rows="4">${esc(value)}</textarea></div>`;
    }

    function companyField(item={}) {
        return `<div class="col-md-6 egpk-field"><label>Owning Company</label><select class="form-select" name="company_id"><option value="">Current Company</option>${Array.from(el.company.options).slice(1).map((o)=>`<option value="${esc(o.value)}" ${String(item.company_id||state.company)===String(o.value)?'selected':''}>${esc(o.textContent)}</option>`).join('')}</select></div>`;
    }

    function buildForm(item = {}) {
        const m = state.module;
        if (m === 'contacts') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-account-outline"></i>Contact Details</div><div class="row g-3">${companyField(item)}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${selectField('salutation','Salutation',['','Mr.','Ms.','Mrs.','Dr.','Prof.'],item.salutation)}${field('person_name','Person Name','text',item.person_name,'required')}${field('designation','Designation','text',item.designation)}${field('organisation','Company / College','text',item.organisation)}${field('department','Department','text',item.department)}${field('phone_primary','Primary Number','text',item.phone_primary)}${field('phone_alternate','Alternate Number','text',item.phone_alternate)}${field('email_primary','Email','email',item.email_primary)}${field('email_secondary','Secondary Email','email',item.email_secondary)}${field('city','City','text',item.city)}${field('website','Website','url',item.website)}${selectField('category_id','Category',[],item.category_id)}${textareaField('address','Address',item.address)}${textareaField('notes','Notes',item.notes)}</div></div>`;
        if (m === 'bookmarks') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-bookmark-outline"></i>Bookmark</div><div class="row g-3">${selectField('board_id','Board',[],item.board_id)}${selectField('category_id','Category',[],item.category_id)}${field('bookmark_name','Bookmark Name','text',item.bookmark_name,'required')}${field('url','URL','url',item.url,'required')}${field('favicon_url','Favicon URL','url',item.favicon_url)}${field('manual_icon','Manual Icon','text',item.manual_icon)}${field('tags_text','Tags','text',Array.isArray(item.tags_json)?item.tags_json.join(', '):(item.tags_json||''))}${textareaField('description','Description',item.description)}</div></div>`;
        if (m === 'passwallet') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-shield-lock-outline"></i>Credential</div><div class="row g-3">${companyField(item)}${selectField('entry_type','Entry Type',['Website','System','Application','Mobile App'],item.entry_type)}${selectField('category_id','Category',[],item.category_id)}${field('entry_name','Entry Name','text',item.entry_name,'required')}${field('url','URL','url',item.url)}${field('username','Username','text',item.username)}${field('email','Registered Email','email',item.email)}${field('mobile','Registered Mobile','text',item.mobile)}${field('password','Password','password','','autocomplete="new-password"')}${field('rotation_days','Rotation Period (days)','number',item.rotation_days,'min="1" max="3650"')}${selectField('visibility','Visibility',['Private','Team','Company'],item.visibility||'Private')}${textareaField('notes','Encrypted Notes','')}</div><div class="mt-2"><button type="button" class="egpk-btn egpk-btn-light border" id="egpkGenerateStrong"><i class="mdi mdi-key-variant me-1"></i>Generate Strong Password</button></div></div>`;
        if (m === 'knowledge') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-school-outline"></i>Knowledge Post</div><div class="row g-3">${companyField(item)}${field('title','Title','text',item.title,'required')}${selectField('category_id','Category',[],item.category_id)}${selectField('subcategory_id','Sub-category',[],item.subcategory_id)}${selectField('audience_scope','Audience',['Group','Companies','Teams'],item.audience_scope||'Group')}${selectField('status','Status',['draft','published','unpublished'],item.status||'draft')}${field('tags_text','Tags','text',Array.isArray(item.tags_json)?item.tags_json.join(', '):(item.tags_json||''))}${textareaField('body_html','Rich Content HTML',item.body_html||'')}</div><div class="egpk-help">For production, connect Tiptap/your approved rich-text editor to this field and upload media through the media endpoint.</div></div>`;
        if (m === 'portals') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-application-outline"></i>Portal / Application</div><div class="row g-3">${companyField(item)}${field('app_name','Application Name','text',item.app_name,'required')}${field('app_url','Application URL','url',item.app_url,'required')}${selectField('platform','Platform',['Web Portal','Mobile App','Desktop'],item.platform||'Web Portal')}${selectField('environment','Environment',['Production','Staging'],item.environment||'Production')}${selectField('status','Status',['Live','Under Maintenance','Deprecated'],item.status||'Live')}${field('technical_owner_user_id','Technical Owner User ID','number',item.technical_owner_user_id)}${field('passwallet_entry_id','PassWallet Entry ID','number',item.passwallet_entry_id)}${textareaField('purpose','Purpose',item.purpose)}</div></div>`;
        if (m === 'meetings') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-calendar-month-outline"></i>Meeting</div><div class="row g-3">${companyField(item)}${field('title','Title','text',item.title,'required')}${field('category','Category','text',item.category||'Review')}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${field('start_at','Start','datetime-local',(item.start_at||nowInputDate()).slice(0,16),'required')}${field('end_at','End','datetime-local',(item.end_at||new Date(Date.now()+3600000).toISOString()).slice(0,16),'required')}${field('venue','Venue','text',item.venue)}${field('meeting_url','Meeting URL','url',item.meeting_url)}${selectField('status','Status',['Scheduled','In Progress','Completed','Cancelled','Postponed'],item.status||'Scheduled')}${field('reminder_minutes','Reminder (minutes)','number',item.reminder_minutes||10080,'min="0"')}${textareaField('agenda','Agenda',item.agenda)}${textareaField('notes','Notes',item.notes)}</div><div class="egpk-help">Participants and RSVP are managed from the meeting view after saving.</div></div>`;
        if (m === 'tasks') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-check-circle-outline"></i>Task</div><div class="row g-3">${companyField(item)}${field('title','Title','text',item.title,'required')}${field('category','Category','text',item.category||'Operations')}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${selectField('priority','Priority',['Low','Medium','High','Urgent'],item.priority||'Medium')}${selectField('status','Status',['To Do','In Progress','On Hold','Pending Verification','Completed'],item.status||'To Do')}${field('due_at','Due','datetime-local',(item.due_at||'').slice(0,16))}${field('supervisor_user_id','Supervisor User ID','number',item.supervisor_user_id)}${selectField('verification_required','Verification Required',[{value:0,label:'No'},{value:1,label:'Yes'}],item.verification_required?1:0)}${textareaField('description','Description',item.description)}</div></div>`;
        if (m === 'notes') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-note-multiple-outline"></i>Sticky Note</div><div class="row g-3">${companyField(item)}${field('title','Title','text',item.title)}${field('label','Label','text',item.label)}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${selectField('priority','Priority',['normal','high'],item.priority||'normal')}${field('color','Color','color',item.color||'#FFF6D9')}${field('reminder_at','Reminder','datetime-local',(item.reminder_at||'').slice(0,16))}${textareaField('body','Note',item.body)}</div></div>`;
        if (m === 'events') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-calendar-star-outline"></i>Event</div><div class="row g-3">${companyField(item)}${field('event_name','Event Name','text',item.event_name,'required')}${field('organisation','Organisation','text',item.organisation)}${field('event_type','Event Type','text',item.event_type||'Event')}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${field('event_date','Date','date',item.event_date||new Date().toISOString().slice(0,10),'required')}${field('event_time','Time','time',item.event_time)}${field('venue','Venue','text',item.venue)}${field('online_link','Online Link','url',item.online_link)}${field('payment_amount','Payment Amount','number',item.payment_amount,'min="0" step="0.01"')}${selectField('status','Status',['Planned','Confirmed','Completed','Cancelled'],item.status||'Planned')}${field('reminder_stage','Reminder Stage','text',item.reminder_stage)}${textareaField('description','Description',item.description)}</div></div>`;
        if (m === 'money') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-wallet-outline"></i>Transaction</div><div class="row g-3">${selectField('transaction_type','Transaction Type',['income','expense'],'expense')}${field('account_id','Account ID','number','', 'required')}${field('transaction_date','Date','date',new Date().toISOString().slice(0,10),'required')}${field('category','Category','text','General','required')}${field('amount','Amount','number','0','min="0.01" step="0.01" required')}${field('mode','Mode','text','Cash')}${field('note','Note','text','')}</div></div>`;
        if (m === 'documents') return `<div class="egpk-section"><div class="egpk-section-title"><i class="mdi mdi-file-document-outline"></i>Document</div><div class="row g-3">${companyField(item)}${selectField('visibility','Visibility',['Private','Company','Group'],item.visibility||'Private')}${selectField('scope','Scope',['Personal','Official'],item.scope||'Personal')}${field('category','Category','text',item.category||'General','required')}<div class="col-12 egpk-field"><label>File</label><input class="form-control" name="document" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.jpg,.jpeg,.png,.webp,.txt,.csv" required></div></div></div>`;
        return '';
    }

    async function loadFormLookups() {
        try {
            if (state.module === 'contacts') {
                const d = await request(cfg.urls.contacts.categories);
                const select = $('[name="category_id"]', el.fields);
                if (select) select.innerHTML = '<option value="">Select Category</option>' + (d.data || []).map((c)=>`<option value="${c.sno}">${esc(c.category_name)}</option>`).join('');
                if (state.current?.category_id) select.value = state.current.category_id;
            }
            if (state.module === 'passwallet') {
                const d = await request(cfg.urls.passwallet.categories);
                const select = $('[name="category_id"]', el.fields);
                if (select) select.innerHTML = '<option value="">Select Category</option>' + (d.data || []).map((c)=>`<option value="${c.sno}">${esc(c.category_name)}</option>`).join('');
                if (state.current?.category_id) select.value = state.current.category_id;
            }
            if (state.module === 'knowledge') {
                const d = await request(cfg.urls.knowledge.categories);
                const categories = d.data?.categories || [];
                const subs = d.data?.subcategories || [];
                const c = $('[name="category_id"]', el.fields);
                const s = $('[name="subcategory_id"]', el.fields);
                if (c) c.innerHTML = '<option value="">Select Category</option>' + categories.map((x)=>`<option value="${x.sno}">${esc(x.category_name)}</option>`).join('');
                if (s) s.innerHTML = '<option value="">Select Sub-category</option>' + subs.map((x)=>`<option value="${x.sno}" data-category="${x.category_id}">${esc(x.subcategory_name)}</option>`).join('');
                if (state.current?.category_id) c.value = state.current.category_id;
                if (state.current?.subcategory_id) s.value = state.current.subcategory_id;
            }
            if (state.module === 'bookmarks') {
                const boards = await request(cfg.urls.bookmarks.boards);
                const b = $('[name="board_id"]', el.fields);
                b.innerHTML = '<option value="">Select Board</option>' + (boards.data || []).map((x)=>`<option value="${x.sno}">${esc(x.board_name)}</option>`).join('');
                if (state.current?.board_id) b.value = state.current.board_id;
                await loadBookmarkCategories(b.value, state.current?.category_id);
                b.addEventListener('change',()=>loadBookmarkCategories(b.value));
            }
        } catch (error) {
            toast(error.message, 'error');
        }
    }

    async function loadBookmarkCategories(boardId, selectedId = '') {
        const c = $('[name="category_id"]', el.fields);
        if (!c || !boardId) { if (c) c.innerHTML = '<option value="">Select Category</option>'; return; }
        const data = await request(`${cfg.urls.bookmarks.board}/${boardId}`);
        c.innerHTML = '<option value="">Select Category</option>' + (data.data?.categories || []).map((x)=>`<option value="${x.sno}">${esc(x.category_name)}</option>`).join('');
        if (selectedId) c.value = selectedId;
    }

    function prepareFormData() {
        const fd = new FormData(el.form);
        ['tags','tags_text'].forEach((name)=>{
            if (!fd.has(name)) return;
            const value = String(fd.get(name) || '');
            fd.delete(name);
            value.split(',').map(x=>x.trim()).filter(Boolean).forEach((tag)=>fd.append('tags[]',tag));
        });
        ['participant_ids','assignee_ids'].forEach((name)=>fd.delete(name));
        return fd;
    }

    async function openCreate() {
        state.current = null;
        el.form.dataset.id = '';
        el.formTitle.textContent = `New ${MODULES[state.module]?.[0] || 'Entry'}`;
        el.formSubtitle.textContent = 'Create a governed record inside the ERP Productivity Suite.';
        el.fields.innerHTML = buildForm({});
        modal.form.show();
        await loadFormLookups();
        bindFormExtras();
    }

    async function openEdit(id) {
        try {
            let row = state.rows.find((r)=>String(r.sno)===String(id));
            if (cfg.urls[state.module]?.show) {
                const result = await request(`${cfg.urls[state.module].show}/${id}`);
                const payload = result.data || result;
                if (payload?.sno) row = payload;
                else if (payload?.app) row = payload.app;
                else if (payload?.post) row = payload.post;
            }
            state.current = row || {};
            el.form.dataset.id = id;
            el.formTitle.textContent = `Edit ${MODULES[state.module]?.[0] || 'Entry'}`;
            el.fields.innerHTML = buildForm(state.current);
            modal.form.show();
            await loadFormLookups();
            bindFormExtras();
        } catch (error) { toast(error.message, 'error'); }
    }

    function openView(id) {
        viewResource(id).catch((error)=>toast(error.message,'error'));
    }

    async function viewResource(id) {
        let row = state.rows.find((r)=>String(r.sno)===String(id));
        let detail = null;
        const endpoint = cfg.urls[state.module]?.show;
        if (endpoint) {
            const d = await request(`${endpoint}/${id}`);
            detail = d.data || d;
            row = detail.sno ? detail : (detail.contact || detail.app || detail.post || detail.meeting || detail.task || detail.note || detail.event || detail.document || row);
        }
        state.current = row || {};
        const title = row?.person_name || row?.bookmark_name || row?.entry_name || row?.title || row?.app_name || row?.event_name || row?.document_name || 'Details';
        el.viewTitle.textContent = title;
        el.viewSubtitle.textContent = MODULES[state.module]?.[0] || 'Details';
        el.viewBody.innerHTML = buildDetailView(row, detail);
        modal.view.show();
    }

    function buildDetailView(row = {}, detail = {}) {
        const fields = Object.entries(row).filter(([key]) => !['password_cipher','password_key_ref','notes_cipher','deleted_at'].includes(key));
        let html = `<div class="egpk-detail-grid">${fields.map(([key,value])=>`<div class="egpk-detail"><small>${esc(titleCase(key))}</small><div>${typeof value==='object' ? esc(JSON.stringify(value)) : esc(value ?? '—')}</div></div>`).join('')}</div>`;

        if (state.module === 'knowledge' && detail) {
            html += `<div class="egpk-section mt-3"><div class="egpk-section-title">Replies</div>${(detail.replies || []).map((r)=>`<div class="py-2 border-bottom small"><strong>${esc(r.author_name||r.author_user_id||'User')}</strong><div class="mt-1">${r.body_html || ''}</div></div>`).join('') || '<div class="small text-muted">No replies yet.</div>'}</div>`;
        }
        if (state.module === 'portals' && detail) {
            html += `<div class="egpk-section mt-3"><div class="egpk-section-title">Version Timeline</div>${(detail.versions || []).map((v)=>`<div class="py-2 border-bottom small"><strong>${esc(v.version_no)}</strong> · ${formatDate(v.update_date)}<div>${esc(v.update_details||'')}</div><div class="text-danger mt-1">${esc(v.bug_fix_details||'')}</div></div>`).join('') || '<div class="small text-muted">No version history.</div>'}</div>`;
        }
        if (state.module === 'meetings' && detail) {
            html += `<div class="egpk-section mt-3"><div class="egpk-section-title">Participants</div>${(detail.participants || []).map((p)=>`<div class="d-flex justify-content-between py-2 border-bottom small"><span>${esc(p.staff_name||p.staff_id)}</span>${badge(p.rsvp||'pending')}</div>`).join('') || '<div class="small text-muted">No participants.</div>'}</div>`;
        }
        return `<div>${html}<div class="mt-3 d-flex gap-2 flex-wrap">${state.module!=='passwallet'?`<button class="egpk-btn egpk-btn-light border" data-view-edit="${row.sno}">Edit</button>`:''}${['contacts','bookmarks','passwallet','knowledge','portals','meetings','tasks','notes','events','documents'].includes(state.module)?`<button class="egpk-btn egpk-btn-light border" data-view-share="${row.sno}"><i class="mdi mdi-share-outline me-1"></i>Share</button>`:''}</div></div>`;
    }

    async function save() {
        const id = el.form.dataset.id || '';
        const fd = prepareFormData();
        let endpoint = null;
        let method = 'POST';

        if (id === '__contact-import__') endpoint = cfg.urls.contacts.import;
        else if (id === '__google-import__') endpoint = cfg.urls.contacts.googleImport;
        else if (id === '__bookmark-import__') endpoint = cfg.urls.bookmarks.importHtml;
        else if (id === '__board__') endpoint = cfg.urls.bookmarks.boardStore;
        else if (id === '__money-transaction__') endpoint = cfg.urls.money.transaction;
        else if (id === '__document-upload__') endpoint = cfg.urls.documents.upload;
        else if (id === '__doc-version__') endpoint = `${cfg.urls.documents.version}/${state.docVersionId}/version`;
        else if (id === '__category__') endpoint = cfg.urls.admin.category;
        else if (id) {
            endpoint = cfg.urls[state.module]?.update;
            method = 'PUT';
        } else {
            endpoint = cfg.urls[state.module]?.store;
        }

        if (!endpoint) return toast('Save endpoint is not configured for this action.', 'error');

        if (state.module === 'passwallet' && id && id !== '__board__') {
            if (!(await ensureStepup('change'))) return;
            fd.append('stepup_password', state.lastStepup || '');
        }

        try {
            const result = await request(id === '__bookmark-import__' || id.startsWith('__') ? endpoint : `${endpoint}${id && !endpoint.endsWith('/'+id) ? '/'+id : ''}`, { method, body: fd });
            toast(result.message || 'Saved successfully.');
            modal.form.hide();
            await loadModule();
        } catch (error) { toast(error.message, 'error'); }
    }

    function openContactImport() {
        el.formTitle.textContent = 'Import Contacts';
        el.formSubtitle.textContent = 'Excel, CSV, TXT or vCard snapshot with duplicate reporting.';
        el.fields.innerHTML = `<div class="egpk-section"><div class="egpk-alert info mb-3">Supported: XLSX/XLS/CSV/TXT/VCF. The import is a snapshot; it does not continuously sync your phone or Google account.</div><div class="egpk-field"><label>Import File</label><input class="form-control" name="file" type="file" accept=".xlsx,.xls,.csv,.txt,.vcf" required></div></div>`;
        el.form.dataset.id='__contact-import__';
        modal.form.show();
    }

    function openBookmarkImport() {
        el.formTitle.textContent = 'Browser Bookmark Import';
        el.formSubtitle.textContent = 'Import a browser-exported HTML bookmark file into a selected board.';
        el.fields.innerHTML = `${field('board_id','Target Board','number','','required')}<div class="egpk-section"><div class="egpk-field"><label>Browser HTML File</label><input class="form-control" name="file" type="file" accept=".html,.htm" required></div></div>`;
        el.form.dataset.id='__bookmark-import__';
        modal.form.show();
        loadBookmarkImportBoards();
    }

    async function loadBookmarkImportBoards(){
        try{const d=await request(cfg.urls.bookmarks.boards);const s=$('[name="board_id"]',el.fields);s.outerHTML=selectField('board_id','Target Board',(d.data||[]).map(x=>({value:x.sno,label:x.board_name})), '');}catch(e){toast(e.message,'error');}
    }

    async function openBoardCreate(){await openCreate(); el.form.dataset.id='__board__'; el.formTitle.textContent='New Board'; el.fields.innerHTML=`<div class="row g-3">${companyField({})}${field('board_name','Board Name','text','','required')}${field('icon','Icon','text','bookmarks')}${selectField('visibility','Visibility',['Private','Company','Group'],'Private')}${selectField('is_locked','Restricted Board',[{value:0,label:'No'},{value:1,label:'Yes'}],0)}${textareaField('description','Description','')}</div>`;}

    function openGenerator(){
        el.formTitle.textContent='Password Generator';
        el.formSubtitle.textContent='Generate a strong password without persisting it until you choose to save.';
        el.fields.innerHTML=`<div class="egpk-section"><div class="row g-3"><div class="col-md-4 egpk-field"><label>Length</label><input class="form-control" type="number" name="length" value="20" min="8" max="128"></div><div class="col-md-2 egpk-field"><label>Uppercase</label><input type="checkbox" name="upper" value="1" checked class="form-check-input mt-2"></div><div class="col-md-2 egpk-field"><label>Lowercase</label><input type="checkbox" name="lower" value="1" checked class="form-check-input mt-2"></div><div class="col-md-2 egpk-field"><label>Numbers</label><input type="checkbox" name="numbers" value="1" checked class="form-check-input mt-2"></div><div class="col-md-2 egpk-field"><label>Symbols</label><input type="checkbox" name="symbols" value="1" checked class="form-check-input mt-2"></div><div class="col-12"><button type="button" class="egpk-btn egpk-btn-gold" id="egpkGenerateNow">Generate</button><input class="form-control mt-2" id="egpkGenerated" readonly></div></div></div>`;
        el.form.dataset.id='__generator__';
        modal.form.show();
        $('#egpkGenerateNow')?.addEventListener('click', async ()=>{
            try{
                const fd=new FormData(el.form);
                const result=await request(cfg.urls.passwallet.generator,{method:'POST',body:{length:Number(fd.get('length')||20),upper:fd.get('upper')?1:0,lower:fd.get('lower')?1:0,numbers:fd.get('numbers')?1:0,symbols:fd.get('symbols')?1:0}});
                $('#egpkGenerated').value=result.data.password;
            }catch(e){toast(e.message,'error');}
        });
    }

    async function ensureStepup(action) {
        const until = Number(sessionStorage.getItem('egpk_stepup_until') || 0);
        if (until > Date.now()) return true;
        if (!modal.stepup) return false;
        state.pendingStepup = action;
        el.stepupPassword.value='';
        modal.stepup.show();
        return new Promise((resolve)=>{ state.stepupResolver=resolve; });
    }

    async function confirmStepup() {
        try {
            const pwd = el.stepupPassword.value.trim();
            if (!pwd) return toast('Enter your ERP password.', 'error');
            const result = await request(cfg.urls.passwallet.stepup, {method:'POST', body:{stepup_password:pwd}});
            const verifiedUntil = Number(result.data?.verified_until || 0) * 1000;
            sessionStorage.setItem('egpk_stepup_until', String(verifiedUntil || (Date.now()+4*60*1000)));
            modal.stepup.hide();
            const resolver = state.stepupResolver;
            state.stepupResolver=null;
            resolver?.(true);
            if (state.pendingStepup === 'reveal' && state.stepTargetId) {
                await openRevealAfterStepup(state.stepTargetId);
            }
        } catch (error) {
            toast(error.message,'error');
            state.stepupResolver?.(false); state.stepupResolver=null;
        }
    }

    async function openRevealAfterStepup(id) {
        try {
            const result = await request(`${cfg.urls.passwallet.reveal}/${id}/reveal`, {method:'POST'});
            showSecret(id, result.data.password);
        } catch (error) {
            toast(error.message,'error');
        }
    }

    function showSecret(id, secret) {
        el.viewTitle.textContent='Credential Revealed';
        el.viewSubtitle.textContent='The secret is displayed only after step-up verification.';
        el.viewBody.innerHTML=`<div class="egpk-section"><div class="egpk-alert warn mb-3">Do not leave the secret visible. Clipboard will be cleared automatically after 30 seconds where the browser permits.</div><div class="input-group"><input class="form-control" value="${esc(secret)}" id="egpkSecretField" readonly><button class="btn btn-outline-secondary" id="egpkCopySecret">Copy</button></div><div class="small text-muted mt-2" id="egpkClipboardTimer">Clipboard timer: 30s</div></div>`;
        modal.view.show();
        let remaining=30;
        let timer=setInterval(()=>{remaining--;const timerEl=$('#egpkClipboardTimer');if(timerEl)timerEl.textContent=`Clipboard timer: ${Math.max(0,remaining)}s`;if(remaining<=0)clearInterval(timer);},1000);
        $('#egpkCopySecret').onclick=async()=>{try{await navigator.clipboard.writeText(secret);toast('Secret copied.');setTimeout(()=>navigator.clipboard.writeText('').catch(()=>{}),30000);}catch(e){toast('Clipboard access is unavailable in this browser.','error');}};
    }

    async function openReveal(id) {
        state.current = {sno:Number(id)};
        state.stepTargetId = Number(id);
        const valid = await ensureStepup('reveal');
        if (!valid) return;
        if (Number(sessionStorage.getItem('egpk_stepup_until') || 0) > Date.now()) await openRevealAfterStepup(id);
    }

    async function shareOpen(id) {
        state.current = {sno:Number(id)};
        state.stepTargetId = Number(id);
        const typeMap = {contacts:'contact',bookmarks:'board',passwallet:'vault',knowledge:'knowledge',portals:'portal',meetings:'meeting',tasks:'task',notes:'note',events:'event',documents:'document'};
        el.shareType.value=typeMap[state.module]||state.module;
        el.shareId.value=id;
        el.shareGrantee.value='user';
        await populateShareRecipients('user');
        if (state.module === 'passwallet') {
            const valid=await ensureStepup('share');
            if (!valid) return;
        }
        await loadShares();
        modal.share.show();
    }

    async function populateShareRecipients(type) {
        try {
            const select=el.shareGranteeId;
            if(type==='group'){select.innerHTML='<option value="0">Entire Group</option>';return;}
            if(type==='role'){select.innerHTML=['Super Admin','Group Admin','Company Admin','Module Manager','Staff','Auditor'].map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');return;}
            if(type==='company'){const d=await request(cfg.urls.companies);select.innerHTML=(d.data||[]).map(x=>`<option value="${x.sno}">${esc(x.company_name)}</option>`).join('');return;}
            const d=await request(cfg.urls.users);select.innerHTML=(d.data||[]).map(x=>`<option value="${x.sno}">${esc(x.staff_name)}${x.email_id?` · ${esc(x.email_id)}`:''}</option>`).join('');
        } catch(error){toast(error.message,'error');}
    }

    async function loadShares(){
        const d=await request(`${cfg.urls.shares.data}?${queryString({resource_type:el.shareType.value,resource_id:el.shareId.value})}`);
        el.shareList.innerHTML=(d.data||[]).map((s)=>`<div class="border rounded p-2 mb-2 small d-flex justify-content-between align-items-center"><span><strong>${esc(s.grantee_type)}</strong> · ${esc(s.grantee_id)} · ${esc(s.permission)} · ${badge(s.status)}${s.expires_at?` <span class="text-muted">until ${formatDateTime(s.expires_at)}</span>`:''}</span>${s.status!=='revoked'?`<button class="btn btn-sm btn-link text-danger" data-share-revoke="${s.sno}">Revoke</button>`:''}</div>`).join('')||'<div class="small text-muted">No active/pending shares.</div>';
    }

    async function saveShare(){
        try{
            const payload={resource_type:el.shareType.value,resource_id:Number(el.shareId.value),grantee_type:el.shareGrantee.value,grantee_id:el.shareGranteeId.value,permission:el.sharePermission.value,expires_at:el.shareExpiry.value||null};
            if(state.module==='passwallet'){ if(!(await ensureStepup('share'))) return; payload.stepup_password=state.lastStepup||''; }
            const d=await request(cfg.urls.shares.store,{method:'POST',body:payload});
            toast(d.message); await loadShares();
        }catch(error){toast(error.message,'error');}
    }

    async function askDelete(id) {
        $('#egpkConfirmTitle').textContent=`Delete ${MODULES[state.module]?.[0] || 'Record'}`;
        $('#egpkConfirmBody').textContent='This will remove the record from the active register. Continue?';
        $('#egpkConfirmYes').onclick=async()=>{try{const endpoint=cfg.urls[state.module]?.delete||cfg.urls[state.module]?.update||cfg.urls[state.module]?.show;const d=await request(`${endpoint}/${id}`,{method:'DELETE'});toast(d.message||'Deleted');modal.confirm.hide();await loadModule();}catch(e){toast(e.message,'error');}};
        modal.confirm.show();
    }

    function bindFormExtras(){
        $('#egpkGenerateStrong')?.addEventListener('click',async()=>{try{const d=await request(cfg.urls.passwallet.generator,{method:'POST',body:{length:20,upper:1,lower:1,numbers:1,symbols:1}});$('[name="password"]',el.form).value=d.data.password;}catch(e){toast(e.message,'error');}});
    }

    async function handleAction(action,id) {
        const row=state.rows.find((r)=>String(r.sno)===String(id))||{};
        if(action==='view') return openView(id);
        if(action==='edit') return openEdit(id);
        if(action==='share') return shareOpen(id);
        if(action==='delete') return askDelete(id);
        if(action==='star') {const d=await request(`${cfg.urls.contacts.star}/${id}/star`,{method:'POST'});toast(d.message|| (d.data?.starred?'Starred':'Unstarred'));return loadModule();}
        if(action==='open'){const d=await request(`${cfg.urls.bookmarks.open}/${id}/open`,{method:'POST'});if(d.data?.url)window.open(d.data.url,'_blank','noopener,noreferrer');return;}
        if(action==='health'){const d=await request(`${cfg.urls.bookmarks.health}/${id}/health`,{method:'POST'});toast(`Link ${d.data?.health_status||'checked'}.`, d.data?.health_status==='healthy'?'success':'error');return loadModule();}
        if(action==='reveal') return openReveal(id);
        if(action==='history'){const d=await request(`${cfg.urls.passwallet.history}/${id}/history`);el.viewTitle.textContent='Password History';el.viewSubtitle.textContent='Last five rotations';el.viewBody.innerHTML=`<div class="egpk-section">${(d.data||[]).map(h=>`<div class="py-2 border-bottom small"><strong>${formatDateTime(h.changed_at)}</strong><span class="text-muted ms-2">By user #${esc(h.changed_by)}</span></div>`).join('')||'<div class="small text-muted">No history.</div>'}</div>`;modal.view.show();return;}
        if(action==='like'){const d=await request(`${cfg.urls.knowledge.show}/${id}/like`,{method:'POST'});toast(d.message||'Reaction updated');return loadModule();}
        if(action==='save'){const d=await request(`${cfg.urls.knowledge.show}/${id}/save`,{method:'POST'});toast(d.data?.saved?'Saved to My Library':'Removed from My Library');return loadModule();}
        if(action==='reply'){return promptAction('Reply',`<div class="egpk-field"><label>Reply</label><textarea class="form-control" id="egpkActionText" rows="5"></textarea></div>`,async()=>{const body=$('#egpkActionText').value.trim();if(!body)throw new Error('Reply is required.');await request(`${cfg.urls.knowledge.show}/${id}/reply`,{method:'POST',body:{body_html:body}});toast('Reply added.');loadModule();});}
        if(action==='report'){return promptAction('Report Post',`<div class="egpk-field"><label>Reason</label><textarea class="form-control" id="egpkActionText" rows="4"></textarea></div>`,async()=>{const reason=$('#egpkActionText').value.trim();if(!reason)throw new Error('Reason is required.');await request(`${cfg.urls.knowledge.show}/${id}/report`,{method:'POST',body:{reason}});toast('Report submitted.');});}
        if(action==='launch'){const d=await request(`${cfg.urls.portals.launch}/${id}/launch`,{method:'POST'});if(d.url)window.open(d.url,'_blank','noopener,noreferrer');return;}
        if(action==='subscribe'){const d=await request(`${cfg.urls.portals.subscribe}/${id}/subscribe`,{method:'POST'});toast(d.data?.subscribed?'Subscribed':'Unsubscribed');return;}
        if(action==='version') return promptAction('Record Version', `<div class="row g-3">${field('version_no','Version','text','','required')}${field('update_date','Date','date',new Date().toISOString().slice(0,10),'required')}${textareaField('update_details','Update Details','')}${textareaField('bug_fix_details','Bug Fix Details','')}</div>`, async()=>{const payload=Object.fromEntries(new FormData(el.actionForm||el.form));await request(`${cfg.urls.portals.version}/${id}/version`,{method:'POST',body:payload});toast('Version recorded.');loadModule();});
        if(action==='rsvp') return promptAction('Meeting RSVP',selectField('rsvp','Response',['pending','accepted','declined','tentative'],row.rsvp||'pending'),async()=>{const response=$('[name="rsvp"]',el.actionForm).value;await request(`${cfg.urls.meetings.rsvp}/${id}/rsvp`,{method:'POST',body:{rsvp:response}});toast('RSVP updated.');loadModule();});
        if(action==='reschedule') return promptAction('Reschedule Meeting',`<div class="row g-3">${field('start_at','Start','datetime-local',(row.start_at||nowInputDate()).slice(0,16),'required')}${field('end_at','End','datetime-local',(row.end_at||nowInputDate()).slice(0,16),'required')}${textareaField('reason','Reason','')}</div>`,async()=>{const payload=Object.fromEntries(new FormData(el.actionForm));await request(`${cfg.urls.meetings.reschedule}/${id}/reschedule`,{method:'POST',body:payload});toast('Meeting rescheduled.');loadModule();});
        if(action==='status') return promptAction('Change Task Status',selectField('status','Status',['To Do','In Progress','On Hold','Pending Verification','Completed'],row.status),async()=>{const status=$('[name="status"]',el.actionForm).value;await request(`${cfg.urls.tasks.status}/${id}/status`,{method:'POST',body:{status}});toast('Task status updated.');loadModule();});
        if(action==='comment') return promptAction('Task Comment',`<div class="egpk-field"><label>Comment</label><textarea class="form-control" id="egpkActionText" rows="4"></textarea></div>`,async()=>{const comment_text=$('#egpkActionText').value.trim();await request(`${cfg.urls.tasks.comment}/${id}/comment`,{method:'POST',body:{comment_text}});toast('Comment added.');});
        if(action==='verify') {const d=await request(`${cfg.urls.tasks.verify}/${id}/verify`,{method:'POST'});toast(d.message||'Task verified.');return loadModule();}
        if(action==='pin'||action==='archive'||action==='trash') {const d=await request(`${cfg.urls.notes.action}/${id}/action`,{method:'POST',body:{action}});toast(d.message||'Note updated.');return loadModule();}
        if(action==='version' && state.module==='documents') return openDocumentVersion(id);
        if(action==='download'){const d=await request(`${cfg.urls.documents.url}/${id}/url`);if(d.data?.url)window.open(d.data.url,'_blank','noopener,noreferrer');return;}
        if(action==='pin' && state.module==='documents'){const d=await request(`${cfg.urls.documents.pin}/${id}/pin`,{method:'POST'});toast(d.message||'Document updated.');return loadModule();}
        if(action==='approve-share')return;
    }

    function promptAction(title, html, callback){
        el.formTitle.textContent=title;
        el.formSubtitle.textContent='Complete the action and confirm.';
        el.fields.innerHTML=html;
        el.actionForm=el.form;
        el.form.dataset.id='__action__';
        el.actionCallback=callback;
        modal.form.show();
    }

    async function openDocumentVersion(id){
        el.formTitle.textContent='Upload New Document Version';
        el.formSubtitle.textContent='The existing version remains in history.';
        el.fields.innerHTML=`<div class="egpk-field"><label>Document File</label><input class="form-control" type="file" name="document" required></div>`;
        el.form.dataset.id='__doc-version__';state.docVersionId=id;modal.form.show();
    }

    function openMoneyTransaction(){state.module='money';el.formTitle.textContent='New Transaction';el.fields.innerHTML=buildForm({});el.form.dataset.id='__money-transaction__';modal.form.show();}
    function openDocumentUpload(){state.module='documents';el.formTitle.textContent='Upload Document';el.fields.innerHTML=buildForm({});el.form.dataset.id='__document-upload__';modal.form.show();}
    function openCategory(){el.formTitle.textContent='New Category';el.formSubtitle.textContent='Create an admin-managed taxonomy item.';el.fields.innerHTML=`<div class="row g-3">${selectField('type','Module',['contact','vault','knowledge'],'contact')}${field('name','Name','text','','required')}${field('color','Color','color','#1F618D')}</div>`;el.form.dataset.id='__category__';modal.form.show();}

    async function loadNotifications(attention = {}) {
        const items = [];
        try {
            const d = await request(cfg.urls.notifications);
            (d.data?.items || []).forEach((n) => items.push({
                icon: n.icon ? `mdi-${n.icon}` : 'mdi-bell-outline',
                color: n.icon_color || '#4A3E8E',
                text: n.message ? `${n.title} · ${n.message}` : n.title,
                time: n.created_at,
                id: n.sno,
                unread: Number(n.is_read) === 0,
            }));
        } catch (error) {
            // Dashboard attention items remain useful even if the notification store is unavailable.
        }
        if (attention.vault_rotation_overdue) items.push({icon:'mdi-lock-clock-outline',color:'#B02418',text:`${attention.vault_rotation_overdue} vault password(s) overdue for rotation`});
        if (attention.broken_bookmarks) items.push({icon:'mdi-link-off',color:'#B8860B',text:`${attention.broken_bookmarks} broken bookmark(s) detected`});
        if (attention.reported_posts) items.push({icon:'mdi-flag-outline',color:'#4A3E8E',text:`${attention.reported_posts} knowledge post report(s) awaiting moderation`});
        if (attention.apps_maintenance) items.push({icon:'mdi-wrench-outline',color:'#546E7A',text:`${attention.apps_maintenance} application(s) under maintenance`});
        el.notifList.innerHTML = items.map((n)=>`<div class="egpk-notif-row" ${n.id?`data-notification-id="${esc(n.id)}"`:''}><div class="egpk-notif-icon" style="background:${n.color}18;color:${n.color}"><i class="mdi ${esc(n.icon)}"></i></div><div><div class="egpk-notif-text">${esc(n.text)}</div><div class="egpk-notif-time">${esc(n.time || 'Attention item')}</div></div></div>`).join('') || '<div class="egpk-empty py-4">No notifications or attention items.</div>';
        const unread = items.filter(x=>x.unread).length || items.filter(x=>x.id).length;
        if (unread) { el.notifCount.textContent=unread;el.notifCount.classList.remove('d-none'); } else { el.notifCount.classList.add('d-none'); }
    }

    function routeGlobal(module,id){
        const key={ContactBook:'contacts',BookMarks:'bookmarks','Knowledge Panel':'knowledge','Portals & Apps':'portals',Meetings:'meetings',Tasks:'tasks'}[module];
        if(key && cfg.urls[key]?.show)window.location.href=`${cfg.urls[key].show}/${id}`; else if(key)window.location.href=cfg.urls[key].data?.replace(/\/data$/,'');
    }

    function bind() {
        el.company.addEventListener('change',()=>{state.company=el.company.value;state.page=1;loadModule();});
        el.search.addEventListener('input',()=>{clearTimeout(state.timers.search);state.timers.search=setTimeout(()=>{state.page=1;loadModule();},300);});
        el.filterOne.addEventListener('change',()=>{state.page=1;loadModule();});
        el.filterTwo.addEventListener('change',()=>{state.page=1;loadModule();});
        el.reset.addEventListener('click',()=>{el.search.value='';el.filterOne.value='';el.filterTwo.value='';state.page=1;state.calendarDate=new Date(new Date().getFullYear(),new Date().getMonth(),1);state.view='table';$$('#egpkViewToggle button').forEach(b=>b.classList.toggle('active',b.dataset.view==='table'));loadModule();});
        $$('#egpkViewToggle button').forEach((button)=>button.addEventListener('click',()=>{state.view=button.dataset.view;$$('#egpkViewToggle button').forEach(b=>b.classList.toggle('active',b===button));loadModule();}));
        $('#egpkFormSave').addEventListener('click',async()=>{
            if(el.form.dataset.id==='__action__' && typeof el.actionCallback==='function'){
                try{ await el.actionCallback(); modal.form.hide(); }catch(e){ toast(e.message||'Unable to complete action.','error'); }
                return;
            }
            return save();
        });
        $('#egpkShareSave').addEventListener('click',saveShare);
        el.shareGrantee.addEventListener('change',()=>populateShareRecipients(el.shareGrantee.value));
        el.toolsButton?.addEventListener('click',()=>{el.toolMenu.classList.toggle('open');el.notifMenu.classList.remove('open');});
        el.notifButton?.addEventListener('click',()=>{el.notifMenu.classList.toggle('open');el.toolMenu.classList.remove('open');});
        document.addEventListener('click',(event)=>{if(!event.target.closest('#egpkToolMenu,#egpkToolsButton'))el.toolMenu?.classList.remove('open');if(!event.target.closest('#egpkNotifMenu,#egpkNotifButton'))el.notifMenu?.classList.remove('open');});
        $('#egpkNotifRefresh')?.addEventListener('click',()=>loadDashboard());
        $('#egpkNotifRead')?.addEventListener('click',async()=>{try{await request(cfg.urls.notificationsRead,{method:'POST',body:{}});toast('Notifications marked as read.');await loadNotifications({});}catch(e){toast(e.message,'error');}});
        el.stepupConfirm?.addEventListener('click',confirmStepup);

        el.global?.addEventListener('input',async()=>{
            const q=el.global.value.trim();
            if(q.length<2){el.globalResults.style.display='none';return;}
            try{
                const d=await request(`${cfg.urls.global}?${queryString({q,company_id:state.company})}`);
                el.globalResults.innerHTML=(d.data||[]).map((x)=>`<a class="egpk-global-item" href="javascript:void(0)" data-global-module="${esc(x.module)}" data-global-id="${esc(x.id)}"><strong>${esc(x.title)}</strong><span>${esc(x.module)} · ${esc(x.subtitle||'')}</span></a>`).join('')||'<div class="egpk-global-item"><span>No results.</span></div>';
                el.globalResults.style.display='block';
            }catch(error){}
        });

        el.globalResults?.addEventListener('click',(event)=>{const item=event.target.closest('[data-global-id]');if(item)routeGlobal(item.dataset.globalModule,item.dataset.globalId);});
        el.shareList?.addEventListener('click',async(event)=>{const button=event.target.closest('[data-share-revoke]');if(!button)return;try{await request(`${cfg.urls.shares.revoke}/${button.dataset.shareRevoke}/revoke`,{method:'POST'});toast('Share revoked.');await loadShares();}catch(e){toast(e.message,'error');}});
        el.content.addEventListener('click',async(event)=>{
            const page=event.target.closest('[data-page]');if(page){state.page=Number(page.dataset.page);return loadModule();}
            const cal=event.target.closest('[data-calendar]');if(cal){if(cal.dataset.calendar==='prev')state.calendarDate=new Date(state.calendarDate.getFullYear(),state.calendarDate.getMonth()-1,1);if(cal.dataset.calendar==='next')state.calendarDate=new Date(state.calendarDate.getFullYear(),state.calendarDate.getMonth()+1,1);if(cal.dataset.calendar==='today')state.calendarDate=new Date(new Date().getFullYear(),new Date().getMonth(),1);return loadCalendar();}
            const approve=event.target.closest('[data-admin-approve]');if(approve){try{await request(`${cfg.urls.shares.approve}/${approve.dataset.adminApprove}/approve`,{method:'POST'});toast('Share approved.');loadAdmin();}catch(e){toast(e.message,'error');}return;}
            const report=event.target.closest('[data-report-view]');if(report)return viewReport(report.dataset.reportView);
            const viewEdit=event.target.closest('[data-view-edit]');if(viewEdit){modal.view.hide();return openEdit(viewEdit.dataset.viewEdit);}
            const viewShare=event.target.closest('[data-view-share]');if(viewShare){modal.view.hide();return shareOpen(viewShare.dataset.viewShare);}
            const action=event.target.closest('[data-action]');if(action){event.preventDefault();try{await handleAction(action.dataset.action,action.dataset.id);}catch(e){toast(e.message,'error');}return;}
            const hero=event.target.closest('[data-hero]');if(hero){const h=hero.dataset.hero;if(h==='add')return openCreate();if(h==='contact-import')return openContactImport();if(h==='bookmark-import')return openBookmarkImport();if(h==='bookmark-quick'){state.module='bookmarks';el.form.dataset.id='';return promptAction('Quick Add Bookmark',`${field('url','URL','url','','required')}${field('bookmark_name','Optional Title','text','')}`,async()=>{const payload=Object.fromEntries(new FormData(el.actionForm));const d=await request(cfg.urls.bookmarks.quick,{method:'POST',body:payload});toast(d.message);loadModule();});}if(h==='generator')return openGenerator();if(h==='calendar'){state.view='calendar';$$('#egpkViewToggle button').forEach(b=>b.classList.toggle('active',b.dataset.view==='table'));return loadModule();}if(h==='kanban'){state.view='card';return loadModule();}if(h==='money-transaction')return openMoneyTransaction();if(h==='document-upload')return openDocumentUpload();if(h==='category')return openCategory();if(h==='report-refresh')return renderReports();}
        });

        $('#egpkFormModal').addEventListener('hidden.bs.modal',()=>{el.form.dataset.id='';el.actionCallback=null;el.actionForm=null;el.lastFormFile=null;});
    }

    (async function init(){
        try {
            await loadCompanies();
            applyFilterOptions();
            await loadDynamicFilters();
            bind();
            await loadModule();
        } catch (error) { showLoadError(error); }
    })();
})();
