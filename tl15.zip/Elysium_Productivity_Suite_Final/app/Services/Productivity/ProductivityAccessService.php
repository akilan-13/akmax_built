<?php
namespace App\Services\Productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductivityAccessService
{
    public function userId(): int
    {
        return (int) (auth()->user()->user_id ?? auth()->id() ?? 0);
    }

    public function companyId(): ?int
    {
        $id = auth()->user()->company_id ?? auth()->user()->company ?? null;
        return $id !== null && $id !== '' ? (int) $id : null;
    }

    public function role(): string
    {
        return (string) (auth()->user()->role_name ?? auth()->user()->role ?? 'Staff');
    }

    public function isSuper(): bool { return $this->role() === 'Super Admin'; }
    public function isGroupAdmin(): bool { return in_array($this->role(), ['Super Admin','Group Admin'], true); }
    public function isCompanyAdmin(): bool { return in_array($this->role(), ['Super Admin','Group Admin','Company Admin'], true); }
    public function isModuleManager(): bool { return $this->role() === 'Module Manager'; }
    public function isAuditor(): bool { return $this->role() === 'Auditor'; }
    public function canWrite(): bool { return !$this->isAuditor(); }
    public function canExport(): bool { return $this->isGroupAdmin() || $this->isCompanyAdmin() || $this->isAuditor(); }

    public function companyScope(Request $request, $column = 'company_id'): array
    {
        if ($this->isGroupAdmin() || $this->isAuditor()) {
            $selected = $request->input('company_id');
            if ($selected !== null && $selected !== '' && $selected !== 'all') return [(int) $selected];
            return [];
        }
        return $this->companyId() ? [$this->companyId()] : [];
    }

    public function applyCompanyScope($query, Request $request, string $column = 'company_id'): void
    {
        $scope = $this->companyScope($request, $column);
        if ($scope) $query->whereIn($column, $scope);
        elseif (!$this->isGroupAdmin() && !$this->isAuditor() && $this->companyId() === null) $query->whereRaw('1=0');
    }

    public function canReadResource(string $resourceType, int $resourceId, ?int $ownerId = null, ?int $companyId = null, ?string $visibility = null): bool
    {
        $uid = $this->userId();
        if ($this->isGroupAdmin() || $this->isAuditor()) return true;
        if ($ownerId !== null && (int)$ownerId === $uid) return true;
        if ($visibility === 'Group') return true;
        if ($visibility === 'Company' && $companyId !== null && $companyId === $this->companyId()) return true;
        return DB::table('egpk_share_grants')->where('resource_type',$resourceType)->where('resource_id',$resourceId)
            ->where('status','active')->where(function($q) use ($uid) {
                $q->where(function($x) use ($uid){ $x->where('grantee_type','user')->where('grantee_id',(string)$uid); })
                  ->orWhere(function($x){ $x->where('grantee_type','group')->where('grantee_id','0'); })
                  ->orWhere(function($x){ $x->where('grantee_type','company')->where('grantee_id',(string)($this->companyId() ?? -1)); })
                  ->orWhere(function($x){ $x->where('grantee_type','role')->where('grantee_id',$this->role()); });
            })->where(function($q){ $q->whereNull('expires_at')->orWhere('expires_at','>=',now()); })->exists();
    }

    public function canManageResource(string $resourceType, int $resourceId, ?int $ownerId = null): bool
    {
        if ($this->isGroupAdmin()) return true;
        if ($ownerId !== null && (int)$ownerId === $this->userId()) return true;
        return DB::table('egpk_share_grants')->where('resource_type',$resourceType)->where('resource_id',$resourceId)
            ->where('status','active')->where('permission','Manage')->where(function($q){
                $uid=$this->userId();
                $q->where(function($x) use ($uid){$x->where('grantee_type','user')->where('grantee_id',(string)$uid);})
                  ->orWhere(function($x){$x->where('grantee_type','group')->where('grantee_id','0');})
                  ->orWhere(function($x){$x->where('grantee_type','role')->where('grantee_id',$this->role());})
                  ->orWhere(function($x){$x->where('grantee_type','company')->where('grantee_id',(string)($this->companyId() ?? -1));});
            })->where(function($q){$q->whereNull('expires_at')->orWhere('expires_at','>=',now());})->exists();
    }


    /**
     * Apply record-level read visibility for list queries.
     * Group/Admin roles are still constrained by the optional company selector.
     * Standard users see their own records, explicit visibility scopes, or active share grants.
     */
    public function applyReadableScope($query, Request $request, string $resourceType, string $ownerColumn = 'owner_user_id', string $visibilityColumn = 'visibility', string $companyColumn = 'company_id'): void
    {
        $this->applyCompanyScope($query, $request, $companyColumn);

        if ($this->isGroupAdmin() || $this->isAuditor()) {
            return;
        }

        $uid = $this->userId();
        $companyId = $this->companyId();
        $role = $this->role();

        $table = method_exists($query, 'getModel') ? $query->getModel()->getTable() : $query->from;

        $query->where(function ($q) use ($uid, $companyId, $role, $ownerColumn, $visibilityColumn, $companyColumn, $resourceType, $table) {
            $q->where($ownerColumn, $uid)
              ->orWhere($visibilityColumn, 'Group')
              ->when($companyId !== null, fn ($x) => $x->orWhere(fn ($y) => $y
                  ->where($visibilityColumn, 'Company')
                  ->where($companyColumn, $companyId)))
              ->orWhereExists(function ($share) use ($uid, $companyId, $role, $ownerColumn, $resourceType, $table) {
                  $share->selectRaw('1')
                      ->from('egpk_share_grants as sg')
                      ->where('sg.resource_type', $resourceType)
                      ->whereColumn('sg.resource_id', $table.'.sno')
                      ->where('sg.status', 'active')
                      ->where(function ($g) use ($uid, $companyId, $role) {
                          $g->where(fn ($u) => $u->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                            ->orWhere(fn ($r) => $r->where('sg.grantee_type', 'role')->where('sg.grantee_id', $role))
                            ->orWhere(fn ($grp) => $grp->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'))
                            ->when($companyId !== null, fn ($co) => $co->orWhere(fn ($c) => $c
                                ->where('sg.grantee_type', 'company')
                                ->where('sg.grantee_id', (string) $companyId)));
                      })
                      ->where(fn ($e) => $e->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
              });
        });
    }

    public function audit(Request $request, string $module, string $action, ?string $resourceType=null, ?int $resourceId=null, $before=null, $after=null, array $meta=[], bool $sensitive=false): void
    {
        DB::table('egpk_audit_logs')->insert([
            'module_name'=>$module,'action'=>$action,'resource_type'=>$resourceType,'resource_id'=>$resourceId,
            'actor_user_id'=>$this->userId(),'actor_name'=>auth()->user()->name ?? auth()->user()->staff_name ?? null,
            'ip_address'=>$request->ip(),'user_agent'=>substr((string)$request->userAgent(),0,1000),
            'before_json'=>$before ? json_encode($before, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'after_json'=>$after ? json_encode($after, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'meta_json'=>$meta ? json_encode($meta, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'is_high_sensitivity'=>$sensitive ? 1 : 0,'created_at'=>now()
        ]);
    }
}
