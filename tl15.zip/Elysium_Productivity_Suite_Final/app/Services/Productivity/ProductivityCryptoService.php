<?php

namespace App\Services\Productivity;

use Aws\Kms\KmsClient;
use RuntimeException;

class ProductivityCryptoService
{
    public function encrypt(string $plaintext): array
    {
        $dataKey = random_bytes(32);
        $nonce = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plaintext, 'aes-256-gcm', $dataKey, OPENSSL_RAW_DATA, $nonce, $tag, '');

        if ($cipher === false) {
            throw new RuntimeException('Unable to encrypt credential.');
        }

        $kms = $this->kmsClient();
        if ($kms) {
            $result = $kms->encrypt([
                'KeyId' => $this->kmsKeyId(),
                'Plaintext' => $dataKey,
                'EncryptionAlgorithm' => 'SYMMETRIC_DEFAULT',
            ]);

            $keyReference = [
                'v' => 2,
                'provider' => 'aws-kms',
                'ciphertext_blob' => base64_encode((string) $result['CiphertextBlob']),
            ];
        } else {
            $wrapNonce = random_bytes(12);
            $wrapTag = '';
            $wrapped = openssl_encrypt(
                $dataKey,
                'aes-256-gcm',
                $this->localMasterKey(),
                OPENSSL_RAW_DATA,
                $wrapNonce,
                $wrapTag,
                ''
            );

            if ($wrapped === false) {
                throw new RuntimeException('Unable to wrap credential key.');
            }

            $keyReference = [
                'v' => 1,
                'provider' => 'local',
                'n' => base64_encode($wrapNonce),
                't' => base64_encode($wrapTag),
                'c' => base64_encode($wrapped),
            ];
        }

        return [
            'cipher' => base64_encode(json_encode([
                'v' => 1,
                'n' => base64_encode($nonce),
                't' => base64_encode($tag),
                'c' => base64_encode($cipher),
            ], JSON_THROW_ON_ERROR)),
            'key_ref' => base64_encode(json_encode($keyReference, JSON_THROW_ON_ERROR)),
        ];
    }

    public function decrypt(string $cipherB64, string $keyRefB64): string
    {
        $payload = json_decode(base64_decode($cipherB64, true) ?: '', true);
        $keyReference = json_decode(base64_decode($keyRefB64, true) ?: '', true);

        if (!is_array($payload) || !is_array($keyReference)) {
            throw new RuntimeException('Invalid encrypted credential payload.');
        }

        if (($keyReference['v'] ?? 1) === 2 && ($keyReference['provider'] ?? '') === 'aws-kms') {
            $kms = $this->kmsClient();
            if (!$kms) {
                throw new RuntimeException('AWS KMS is required to decrypt this credential.');
            }

            $result = $kms->decrypt([
                'CiphertextBlob' => base64_decode($keyReference['ciphertext_blob'], true),
                'KeyId' => $this->kmsKeyId(),
                'EncryptionAlgorithm' => 'SYMMETRIC_DEFAULT',
            ]);
            $dataKey = (string) $result['Plaintext'];
        } else {
            $dataKey = openssl_decrypt(
                base64_decode($keyReference['c'], true),
                'aes-256-gcm',
                $this->localMasterKey(),
                OPENSSL_RAW_DATA,
                base64_decode($keyReference['n'], true),
                base64_decode($keyReference['t'], true),
                ''
            );

            if ($dataKey === false) {
                throw new RuntimeException('Unable to unwrap credential key.');
            }
        }

        $plain = openssl_decrypt(
            base64_decode($payload['c'], true),
            'aes-256-gcm',
            $dataKey,
            OPENSSL_RAW_DATA,
            base64_decode($payload['n'], true),
            base64_decode($payload['t'], true),
            ''
        );

        if ($plain === false) {
            throw new RuntimeException('Unable to decrypt credential.');
        }

        return $plain;
    }

    public function usesKms(): bool
    {
        return $this->kmsClient() !== null;
    }

    private function localMasterKey(): string
    {
        $raw = (string) config('app.key');
        $raw = str_starts_with($raw, 'base64:')
            ? base64_decode(substr($raw, 7), true)
            : $raw;

        if (!$raw) {
            throw new RuntimeException('Application encryption key is not configured.');
        }

        return hash('sha256', $raw . '|EGPK|PassWallet|2026', true);
    }

    private function kmsKeyId(): string
    {
        $keyId = trim((string) config('services.egpk.kms_key_id', env('EGPK_KMS_KEY_ID', '')));
        if ($keyId === '') {
            throw new RuntimeException('EGPK_KMS_KEY_ID is not configured.');
        }
        return $keyId;
    }

    private function kmsClient(): ?KmsClient
    {
        $keyId = trim((string) config('services.egpk.kms_key_id', env('EGPK_KMS_KEY_ID', '')));
        if ($keyId === '') {
            return null;
        }

        if (!class_exists(KmsClient::class)) {
            throw new RuntimeException('AWS KMS support is not installed. Run composer require aws/aws-sdk-php.');
        }

        return new KmsClient([
            'version' => 'latest',
            'region' => config('services.egpk.aws_region', env('AWS_DEFAULT_REGION', 'ap-south-1')),
            // AWS SDK uses the default credential provider chain in production.
        ]);
    }
}
