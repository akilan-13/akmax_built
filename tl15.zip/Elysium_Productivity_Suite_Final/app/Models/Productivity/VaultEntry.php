<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VaultEntry extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_vault_entries';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['company_id' => 'integer', 'owner_user_id' => 'integer', 'category_id' => 'integer', 'rotation_days' => 'integer', 'last_rotated_at' => 'datetime', 'next_rotation_at' => 'datetime'];
}
