<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StickyNote extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_sticky_notes';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['visibility' => 'string', 'owner_user_id' => 'integer', 'company_id' => 'integer', 'reminder_at' => 'datetime', 'checklist_json' => 'array', 'is_pinned' => 'boolean'];
}
