<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Document extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_documents';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['visibility' => 'string', 'owner_user_id' => 'integer', 'company_id' => 'integer', 'file_size' => 'integer', 'version_no' => 'integer', 'is_pinned' => 'boolean', 'expiry_date' => 'date'];
}
