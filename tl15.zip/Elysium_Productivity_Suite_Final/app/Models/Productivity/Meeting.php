<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Meeting extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_meetings';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['visibility' => 'string', 'company_id' => 'integer', 'owner_user_id' => 'integer', 'start_at' => 'datetime', 'end_at' => 'datetime', 'reminder_minutes' => 'integer'];

    public function participants(){return $this->hasMany(MeetingParticipant::class,'meeting_id','sno');}
    public function reschedules(){return $this->hasMany(MeetingReschedule::class,'meeting_id','sno');}
}
