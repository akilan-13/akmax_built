<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Task extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_tasks';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['visibility' => 'string', 'company_id' => 'integer', 'owner_user_id' => 'integer', 'due_at' => 'datetime', 'supervisor_user_id' => 'integer', 'verification_required' => 'boolean'];

    public function assignees(){return $this->hasMany(TaskAssignee::class,'task_id','sno');}
    public function comments(){return $this->hasMany(TaskComment::class,'task_id','sno');}
}
