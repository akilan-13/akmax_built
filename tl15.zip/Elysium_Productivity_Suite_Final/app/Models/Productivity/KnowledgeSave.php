<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class KnowledgeSave extends Model { protected $table='egpk_knowledge_saves'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
