<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class KnowledgePost extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_knowledge_posts';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['company_id' => 'integer', 'author_user_id' => 'integer', 'category_id' => 'integer', 'subcategory_id' => 'integer', 'tags_json' => 'array', 'edit_version' => 'integer', 'published_at' => 'datetime', 'edited_at' => 'datetime'];

    public function replies(){return $this->hasMany(KnowledgeReply::class,'post_id','sno');}
    public function reactions(){return $this->hasMany(KnowledgeReaction::class,'post_id','sno');}
    public function saves(){return $this->hasMany(KnowledgeSave::class,'post_id','sno');}
}
