<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class MeetingParticipant extends Model { protected $table='egpk_meeting_participants'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
