<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class MeetingReschedule extends Model { protected $table='egpk_meeting_reschedules'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
