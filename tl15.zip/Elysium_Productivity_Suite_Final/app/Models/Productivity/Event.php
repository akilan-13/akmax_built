<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Event extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_events';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['visibility' => 'string', 'company_id' => 'integer', 'owner_user_id' => 'integer', 'event_date' => 'date', 'payment_amount' => 'decimal:2', 'is_online' => 'boolean'];
}
