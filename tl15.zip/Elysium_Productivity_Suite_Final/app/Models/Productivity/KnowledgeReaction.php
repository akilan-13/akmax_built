<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class KnowledgeReaction extends Model { protected $table='egpk_knowledge_reactions'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
