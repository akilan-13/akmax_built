<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class KnowledgeReply extends Model { protected $table='egpk_knowledge_replies'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
