<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class TaskComment extends Model { protected $table='egpk_task_comments'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
