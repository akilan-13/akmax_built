<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bookmark extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_bookmarks';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['board_id' => 'integer', 'category_id' => 'integer', 'owner_user_id' => 'integer', 'click_count' => 'integer', 'sort_order' => 'integer', 'tags_json' => 'array', 'last_checked_at' => 'datetime'];

    public function board(){return $this->belongsTo(Board::class,'board_id','sno');}
    public function category(){return $this->belongsTo(BoardCategory::class,'category_id','sno');}
}
