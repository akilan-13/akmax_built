<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PortalApp extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egpk_portal_apps';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['company_id' => 'integer', 'technical_owner_user_id' => 'integer', 'passwallet_entry_id' => 'integer', 'most_used_score' => 'integer', 'sort_order' => 'integer'];

    public function versions(){return $this->hasMany(PortalAppVersion::class,'app_id','sno');}
}
