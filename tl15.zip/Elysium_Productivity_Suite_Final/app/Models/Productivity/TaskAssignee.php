<?php
namespace App\Models\Productivity;
use Illuminate\Database\Eloquent\Model;
class TaskAssignee extends Model { protected $table='egpk_task_assignees'; protected $primaryKey='sno'; public $timestamps=false; protected $guarded=[]; }
