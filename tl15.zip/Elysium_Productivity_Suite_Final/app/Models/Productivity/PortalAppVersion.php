<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PortalAppVersion extends Model
{
    use HasFactory;

    protected $table = 'egpk_portal_app_versions';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $casts = ['app_id' => 'integer', 'updated_by' => 'integer', 'update_date' => 'date'];
}
