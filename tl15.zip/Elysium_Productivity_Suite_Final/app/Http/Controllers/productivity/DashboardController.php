<?php
namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class DashboardController extends ProductivityBaseController
{
    public function index(){ return view('content.productivity.dashboard.index'); }

    public function data(Request $request){
        $c = $this->access->companyScope($request);
        $scope = fn($q) => $c ? $q->whereIn('company_id',$c) : $q;
        $uid=$this->uid();
        $contacts=DB::table('egpk_contacts')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($contacts,$request,'contact');
        $boards=DB::table('egpk_boards')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($boards,$request,'board');
        $vault=DB::table('egpk_vault_entries')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($vault,$request,'vault');
        $knowledge=DB::table('egpk_knowledge_posts')->whereNull('deleted_at')->where('status','published'); $this->applyReadableScope($knowledge,$request,'knowledge','author_user_id','audience_scope');
        $apps=DB::table('egpk_portal_apps')->whereNull('deleted_at'); $this->applyCompanyScope($apps,$request);
        $attention=[
            'vault_rotation_overdue'=>$vault->clone()->whereNotNull('next_rotation_at')->where('next_rotation_at','<',now())->count(),
            'broken_bookmarks'=>DB::table('egpk_bookmarks')->whereNull('deleted_at')->where('health_status','broken')->whereExists(function($q) use($c){$q->selectRaw('1')->from('egpk_boards')->whereColumn('egpk_boards.sno','egpk_bookmarks.board_id')->whereNull('egpk_boards.deleted_at')->when($c,fn($x)=>$x->whereIn('company_id',$c));})->count(),
            'reported_posts'=>DB::table('egpk_knowledge_reports')->whereIn('status',['open','pending'])->count(),
            'apps_maintenance'=>$apps->clone()->where('status','Under Maintenance')->count(),
        ];
        $series=[]; for($i=11;$i>=0;$i--){$m=now()->subWeeks($i);$series[]= ['label'=>$m->format('d M'),'contacts'=>$scope(DB::table('egpk_contacts'))->where('created_at','>=',$m->copy()->startOfWeek())->where('created_at','<=',$m->copy()->endOfWeek())->count(),'knowledge'=>$scope(DB::table('egpk_knowledge_posts'))->where('created_at','>=',$m->copy()->startOfWeek())->where('created_at','<=',$m->copy()->endOfWeek())->count()];}
        return $this->ok(['kpis'=>['contacts'=>$contacts->count(),'boards'=>$boards->count(),'bookmarks'=>DB::table('egpk_bookmarks')->whereNull('deleted_at')->count(),'vault_entries'=>$vault->count(),'knowledge_posts'=>$knowledge->count(),'apps'=>$apps->count()], 'attention'=>$attention,'adoption'=>$series,'role'=>$this->access->role()]);
    }
}
