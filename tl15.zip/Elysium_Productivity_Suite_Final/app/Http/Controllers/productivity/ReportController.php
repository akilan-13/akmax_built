<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ReportController extends ProductivityBaseController
{
    private array $allowed = [
        'contact_master',
        'import_audit',
        'board_health',
        'credential_compliance',
        'vault_access_audit',
        'knowledge_engagement',
        'application_inventory',
        'version_change_log',
    ];

    public function index()
    {
        return view('content.productivity.reports.index');
    }

    public function data(Request $request)
    {
        $type = (string) $request->get('type', 'contact_master');
        abort_unless(in_array($type, $this->allowed, true), 422, 'Unknown report type.');

        $company = $request->get('company_id');
        $rows = collect();

        switch ($type) {
            case 'contact_master':
                $q = DB::table('egpk_contacts as c')
                    ->leftJoin('egpk_contact_categories as cat', 'cat.sno', '=', 'c.category_id')
                    ->where('c.status', 0)
                    ->select('c.sno', 'c.person_name', 'c.organisation', 'c.phone_primary', 'c.email_primary', 'c.city', 'c.visibility', 'cat.category_name');
                if ($company && $company !== 'all') $q->where('c.company_id', $company);
                $rows = $q->orderBy('c.person_name')->paginate(100);
                break;

            case 'import_audit':
                $q = DB::table('egpk_contact_imports')->orderByDesc('created_at');
                if ($company && $company !== 'all') $q->where('company_id', $company);
                $rows = $q->paginate(100);
                break;

            case 'board_health':
                $q = DB::table('egpk_boards as b')
                    ->leftJoin('egpk_bookmarks as bm', 'bm.board_id', '=', 'b.sno')
                    ->where('b.status', 0)
                    ->when($company && $company !== 'all', fn($x) => $x->where('b.company_id', $company))
                    ->groupBy('b.sno', 'b.board_name')
                    ->select(
                        'b.sno',
                        'b.board_name',
                        DB::raw('COUNT(bm.sno) as bookmark_count'),
                        DB::raw("SUM(CASE WHEN bm.health_status='broken' THEN 1 ELSE 0 END) as broken_links"),
                        DB::raw('MAX(bm.last_checked_at) as last_checked_at')
                    );
                $rows = $q->orderByDesc('broken_links')->orderBy('b.board_name')->paginate(100);
                break;

            case 'credential_compliance':
                $q = DB::table('egpk_vault_entries')
                    ->where('status', 0)
                    ->select('sno', 'entry_name', 'entry_type', 'visibility', 'rotation_days', 'last_rotated_at', 'next_rotation_at', DB::raw("CASE WHEN next_rotation_at IS NOT NULL AND next_rotation_at < NOW() THEN 'Overdue' WHEN next_rotation_at IS NOT NULL THEN 'Scheduled' ELSE 'Not configured' END AS rotation_status"));
                if ($company && $company !== 'all') $q->where('company_id', $company);
                $rows = $q->orderBy('entry_name')->paginate(100);
                break;

            case 'vault_access_audit':
                $q = DB::table('egpk_audit_logs')
                    ->where('module_name', 'PassWallet')
                    ->whereIn('action', ['revealed', 'copied', 'updated', 'created', 'deleted', 'shared', 'share_created', 'share_revoked'])
                    ->orderByDesc('created_at');
                $rows = $q->paginate(100);
                break;

            case 'knowledge_engagement':
                $q = DB::table('egpk_knowledge_posts as p')
                    ->leftJoin('egpk_knowledge_reactions as r', 'r.post_id', '=', 'p.sno')
                    ->leftJoin('egpk_knowledge_replies as rp', 'rp.post_id', '=', 'p.sno')
                    ->leftJoin('egpk_knowledge_saves as s', 's.post_id', '=', 'p.sno')
                    ->where('p.status', 'published')
                    ->when($company && $company !== 'all', fn($x) => $x->where('p.company_id', $company))
                    ->groupBy('p.sno', 'p.title')
                    ->select('p.sno', 'p.title', 'p.company_id', DB::raw('COUNT(DISTINCT r.sno) likes'), DB::raw('COUNT(DISTINCT rp.sno) replies'), DB::raw('COUNT(DISTINCT s.sno) saves'));
                $rows = $q->orderByDesc('likes')->paginate(100);
                break;

            case 'application_inventory':
                $q = DB::table('egpk_portal_apps')->whereNull('deleted_at')->orderBy('app_name');
                if ($company && $company !== 'all') $q->where('company_id', $company);
                $rows = $q->paginate(100);
                break;

            case 'version_change_log':
                $q = DB::table('egpk_portal_app_versions as v')
                    ->join('egpk_portal_apps as a', 'a.sno', '=', 'v.app_id')
                    ->when($company && $company !== 'all', fn($x) => $x->where('a.company_id', $company))
                    ->orderByDesc('v.update_date')
                    ->select('a.app_name', 'a.company_id', 'v.version_no', 'v.update_details', 'v.bug_fix_details', 'v.update_date', 'v.updated_by');
                $rows = $q->paginate(100);
                break;
        }

        return $this->ok($rows);
    }

    public function csv(Request $request)
    {
        abort_unless($this->access->canExport(), 403);

        $data = $this->data($request)->getData(true);
        $rows = $data['data']['data'] ?? [];
        $filename = 'egpk_'.preg_replace('/[^a-z0-9_]+/i', '_', trim($request->get('type', 'report'))).'_'.now()->format('Ymd_His').'.csv';

        $this->audit($request, 'Reports', 'export', 'report', null, null, null, [
            'format' => 'csv',
            'type' => $request->get('type', 'report'),
            'row_count' => count($rows),
        ]);

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            if (!$rows) {
                fputcsv($out, ['No data']);
                fclose($out);
                return;
            }
            fputcsv($out, array_keys((array) $rows[0]));
            foreach ($rows as $row) fputcsv($out, array_map(fn($v) => is_array($v) ? json_encode($v) : $v, (array) $row));
            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv']);
    }

    public function xlsx(Request $request)
    {
        abort_unless($this->access->canExport(), 403);
        abort_unless(class_exists(Spreadsheet::class) && class_exists(Xlsx::class), 503, 'XLSX support is not installed. Run composer require phpoffice/phpspreadsheet.');

        $data = $this->data($request)->getData(true);
        $rows = $data['data']['data'] ?? [];
        $type = (string) $request->get('type', 'report');
        $filename = 'egpk_'.preg_replace('/[^a-z0-9_]+/i', '_', $type).'_'.now()->format('Ymd_His').'.xlsx';

        $this->audit($request, 'Reports', 'export', 'report', null, null, null, [
            'format' => 'xlsx', 'type' => $type, 'row_count' => count($rows),
        ]);

        $ss = new Spreadsheet();
        $sh = $ss->getActiveSheet();
        if (!$rows) {
            $sh->setCellValue('A1', 'No data');
        } else {
            $headers = array_keys((array) $rows[0]);
            $sh->fromArray($headers, null, 'A1');
            $line = 2;
            foreach ($rows as $row) {
                $sh->fromArray(array_map(fn($v) => is_array($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : $v, (array) $row), null, 'A'.$line++);
            }
            $lastColumn = $sh->getHighestColumn();
            $sh->getStyle('A1:'.$lastColumn.'1')->getFont()->setBold(true);
            foreach (range('A', $lastColumn) as $col) $sh->getColumnDimension($col)->setAutoSize(true);
        }

        $writer = new Xlsx($ss);
        return response()->streamDownload(function () use ($writer) { $writer->save('php://output'); }, $filename, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ]);
    }
}
