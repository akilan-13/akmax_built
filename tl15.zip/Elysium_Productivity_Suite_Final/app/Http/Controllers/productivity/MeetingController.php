<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Meeting;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class MeetingController extends ProductivityBaseController
{
    public function index()
    {
        return view('content.productivity.meetings.index');
    }

    private function base(Request $request)
    {
        $query = Meeting::query()->whereNull('deleted_at');
        $this->applyReadableScope($query, $request, 'meeting');
        $uid = $this->uid();
        $query->where(function ($scope) use ($uid) {
            $scope->where('owner_user_id', $uid)
                ->orWhereExists(function ($participants) use ($uid) {
                    $participants->selectRaw('1')
                        ->from('egpk_meeting_participants as mp')
                        ->whereColumn('mp.meeting_id', 'egpk_meetings.sno')
                        ->where('mp.user_id', $uid);
                })
                ->orWhereExists(function ($share) use ($uid) {
                    $share->selectRaw('1')->from('egpk_share_grants as sg')
                        ->where('sg.resource_type', 'meeting')->whereColumn('sg.resource_id', 'egpk_meetings.sno')
                        ->where('sg.status', 'active')
                        ->where(function ($g) use ($uid) {
                            $g->where(fn ($u) => $u->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                                ->orWhere(fn ($r) => $r->where('sg.grantee_type', 'role')->where('sg.grantee_id', $this->access->role()))
                                ->orWhere(fn ($c) => $c->where('sg.grantee_type', 'company')->where('sg.grantee_id', (string) ($this->cid() ?? -1)))
                                ->orWhere(fn ($g2) => $g2->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'));
                        })
                        ->where(fn ($e) => $e->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
                })
                ->orWhere('visibility', 'Group')
                ->orWhere(function ($company) {
                    $company->where('visibility', 'Company')
                        ->when($this->cid(), fn ($q) => $q->where('company_id', $this->cid()));
                });
        });
        return $query;
    }

    public function data(Request $request)
    {
        $query = $this->base($request);
        foreach (['status', 'category'] as $filter) {
            if ($request->filled($filter)) {
                $query->where($filter, $request->input($filter));
            }
        }
        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            $query->where(fn ($q) => $q
                ->where('title', 'like', "%{$search}%")
                ->orWhere('agenda', 'like', "%{$search}%")
                ->orWhere('venue', 'like', "%{$search}%"));
        }
        if ($request->filled('start') && $request->filled('end')) {
            $query->where('start_at', '<=', Carbon::parse($request->input('end'))->endOfDay())
                ->where('end_at', '>=', Carbon::parse($request->input('start'))->startOfDay());
        }
        return $this->ok(['rows' => $query->orderBy('start_at')->paginate(min(max((int) $request->get('per_page', 30), 10), 100))]);
    }

    public function calendar(Request $request)
    {
        $request->validate(['start' => ['required', 'date'], 'end' => ['required', 'date']]);
        return $this->ok($this->base($request)
            ->whereBetween('start_at', [Carbon::parse($request->start)->startOfDay(), Carbon::parse($request->end)->endOfDay()])
            ->orderBy('start_at')->get());
    }

    public function show(Request $request, int $id)
    {
        $meeting = Meeting::findOrFail($id);
        abort_unless($this->access->canReadResource('meeting', $id, $meeting->owner_user_id, $meeting->company_id, $meeting->visibility), 403);
        return $this->ok([
            'meeting' => $meeting,
            'participants' => DB::table('egpk_meeting_participants')->where('meeting_id', $id)->get(),
            'reschedules' => DB::table('egpk_meeting_reschedules')->where('meeting_id', $id)->orderByDesc('created_at')->get(),
        ]);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $this->validateData($request);
        $this->assertCompanyAllowed($data['company_id'] ?? null);
        $this->conflictCheck($data);

        $meeting = Meeting::create(array_merge($data, [
            'company_id' => $data['company_id'] ?? $this->cid(),
            'owner_user_id' => $this->uid(),
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]));
        $this->syncParticipants($meeting, $data['participant_ids'] ?? []);
        $this->audit($request, 'Meetings', 'created', 'meeting', $meeting->sno, null, $meeting->toArray());
        return $this->ok($meeting, 'Meeting created successfully.');
    }

    public function update(Request $request, int $id)
    {
        $meeting = Meeting::findOrFail($id);
        abort_unless($this->access->canManageResource('meeting', $id, $meeting->owner_user_id), 403);
        $data = $this->validateData($request);
        $this->assertCompanyAllowed($data['company_id'] ?? $meeting->company_id);
        $this->conflictCheck($data, $id);
        $before = $meeting->toArray();
        $payload = array_merge($data, ['updated_by' => $this->uid()]);
        unset($payload['participant_ids']);
        $meeting->update($payload);
        $this->syncParticipants($meeting, $data['participant_ids'] ?? []);
        if ($before['start_at'] !== (string) $meeting->start_at || $before['end_at'] !== (string) $meeting->end_at) {
            DB::table('egpk_meeting_reschedules')->insert([
                'meeting_id' => $id,
                'old_start_at' => $before['start_at'],
                'old_end_at' => $before['end_at'],
                'new_start_at' => $meeting->start_at,
                'new_end_at' => $meeting->end_at,
                'reason' => $request->input('reschedule_reason'),
                'changed_by' => $this->uid(),
                'created_at' => now(),
            ]);
        }
        $this->audit($request, 'Meetings', 'updated', 'meeting', $id, $before, $meeting->fresh()->toArray());
        return $this->ok($meeting->fresh(), 'Meeting updated.');
    }

    public function reschedule(Request $request, int $id)
    {
        $meeting = Meeting::findOrFail($id);
        abort_unless($this->access->canManageResource('meeting', $id, $meeting->owner_user_id), 403);
        $data = $request->validate(['start_at' => ['required', 'date'], 'end_at' => ['required', 'date', 'after:start_at'], 'reason' => ['nullable', 'string', 'max:500']]);
        $payload = ['start_at' => $data['start_at'], 'end_at' => $data['end_at'], 'participant_ids' => DB::table('egpk_meeting_participants')->where('meeting_id', $id)->pluck('user_id')->all()];
        $this->conflictCheck($payload, $id);
        $before = [$meeting->start_at, $meeting->end_at];
        $meeting->update(['start_at' => $data['start_at'], 'end_at' => $data['end_at'], 'status' => 'Postponed', 'updated_by' => $this->uid()]);
        DB::table('egpk_meeting_reschedules')->insert([
            'meeting_id' => $id, 'old_start_at' => $before[0], 'old_end_at' => $before[1],
            'new_start_at' => $data['start_at'], 'new_end_at' => $data['end_at'], 'reason' => $data['reason'] ?? null,
            'changed_by' => $this->uid(), 'created_at' => now(),
        ]);
        $this->audit($request, 'Meetings', 'rescheduled', 'meeting', $id, ['start_at' => $before[0], 'end_at' => $before[1]], ['start_at' => $data['start_at'], 'end_at' => $data['end_at']]);
        return $this->ok($meeting->fresh(), 'Meeting rescheduled.');
    }

    public function rsvp(Request $request, int $id)
    {
        $meeting = Meeting::findOrFail($id);
        abort_unless($this->access->canReadResource('meeting', $id, $meeting->owner_user_id, $meeting->company_id, $meeting->visibility), 403);
        $data = $request->validate(['rsvp' => ['required', 'in:pending,accepted,declined,tentative']]);
        DB::table('egpk_meeting_participants')->updateOrInsert(
            ['meeting_id' => $id, 'user_id' => $this->uid()],
            ['rsvp' => $data['rsvp'], 'updated_at' => now(), 'created_at' => now()]
        );
        return $this->ok(['rsvp' => $data['rsvp']], 'RSVP updated.');
    }

    public function delete(Request $request, int $id)
    {
        $meeting = Meeting::findOrFail($id);
        abort_unless($this->access->canManageResource('meeting', $id, $meeting->owner_user_id), 403);
        $meeting->update(['deleted_at' => now(), 'updated_by' => $this->uid(), 'status' => 'Cancelled']);
        $this->audit($request, 'Meetings', 'deleted', 'meeting', $id);
        return $this->ok(null, 'Meeting cancelled and removed from active lists.');
    }

    private function validateData(Request $request): array
    {
        $data = $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'title' => ['required', 'string', 'max:220'],
            'category' => ['required', 'string', 'max:80'],
            'start_at' => ['required', 'date'],
            'end_at' => ['required', 'date', 'after:start_at'],
            'venue' => ['nullable', 'string', 'max:300'],
            'meeting_url' => ['nullable', 'url', 'max:2000'],
            'agenda' => ['nullable', 'string', 'max:10000'],
            'status' => ['nullable', 'in:Scheduled,In Progress,Completed,Cancelled,Postponed'],
            'reminder_minutes' => ['nullable', 'integer', 'min:0', 'max:525600'],
            'notes' => ['nullable', 'string', 'max:10000'],
            'participant_ids' => ['nullable', 'array', 'max:500'],
            'participant_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
        ]);
        return $data;
    }

    private function assertCompanyAllowed(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin() || $this->access->isAuditor()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company meeting access is not permitted.');
    }

    private function syncParticipants(Meeting $meeting, array $ids): void
    {
        DB::transaction(function () use ($meeting, $ids) {
            DB::table('egpk_meeting_participants')->where('meeting_id', $meeting->sno)->delete();
            foreach ($this->ids($ids) as $userId) {
                DB::table('egpk_meeting_participants')->insert([
                    'meeting_id' => $meeting->sno,
                    'user_id' => $userId,
                    'rsvp' => $userId === $this->uid() ? 'accepted' : 'pending',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        });
    }

    private function conflictCheck(array $data, int $ignore = 0): void
    {
        $ids = $this->ids($data['participant_ids'] ?? []);
        if (!$ids) return;
        $exists = DB::table('egpk_meeting_participants as mp')
            ->join('egpk_meetings as m', 'm.sno', '=', 'mp.meeting_id')
            ->whereIn('mp.user_id', $ids)
            ->where('m.start_at', '<', $data['end_at'])
            ->where('m.end_at', '>', $data['start_at'])
            ->whereNull('m.deleted_at')
            ->where('m.status', '!=', 'Cancelled')
            ->when($ignore, fn ($q) => $q->where('m.sno', '!=', $ignore))
            ->exists();
        abort_if($exists, 422, 'One or more participants are already booked for this time.');
    }
}
