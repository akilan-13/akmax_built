<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Document;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DocumentController extends ProductivityBaseController
{
    private const MIME = 'pdf,doc,docx,xls,xlsx,ppt,pptx,zip,jpg,jpeg,png,webp,txt,csv';

    public function index() { return view('content.productivity.documents.index'); }

    public function data(Request $request)
    {
        $query = Document::query()->whereNull('deleted_at')->where('status', 0);
        $this->applyReadableScope($query, $request, 'document', 'owner_user_id', 'visibility');
        if ($request->filled('scope')) $query->where('scope', $request->scope);
        if ($request->filled('category')) $query->where('category', $request->category);
        if ($request->filled('search')) $query->where('document_name', 'like', '%'.trim((string) $request->search).'%');
        return $this->ok(['rows' => $query->orderByDesc('is_pinned')->orderByDesc('updated_at')->paginate(min(max((int) $request->get('per_page', 30), 10), 100))]);
    }

    public function upload(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'scope' => ['required', 'in:Personal,Official'],
            'category' => ['required', 'string', 'max:100'],
            'document' => ['required', 'file', 'max:51200', 'mimes:'.self::MIME],
        ]);
        $this->assertCompany($data['company_id'] ?? null);
        $file = $request->file('document');
        $path = $file->store('egpk/documents/'.date('Y/m'), 's3');
        $document = Document::create([
            'owner_user_id' => $this->uid(), 'company_id' => $data['company_id'] ?? $this->cid(),
            'visibility' => $data['visibility'], 'scope' => $data['scope'], 'category' => $data['category'],
            'document_name' => $file->getClientOriginalName(), 'storage_path' => $path,
            'mime_type' => $file->getMimeType(), 'file_size' => $file->getSize(), 'version_no' => 1,
            'created_by' => $this->uid(), 'updated_by' => $this->uid(),
        ]);
        DB::table('egpk_document_versions')->insert([
            'document_id' => $document->sno, 'version_no' => 1, 'storage_path' => $path,
            'file_size' => $file->getSize(), 'mime_type' => $file->getMimeType(), 'uploaded_by' => $this->uid(), 'created_at' => now(),
        ]);
        $this->audit($request, 'Documents', 'uploaded', 'document', $document->sno, null, ['name' => $document->document_name, 'version' => 1]);
        return $this->ok($document, 'Document uploaded successfully.');
    }

    public function version(Request $request, int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document', $id, $document->owner_user_id), 403);
        $request->validate(['document' => ['required', 'file', 'max:51200', 'mimes:'.self::MIME]]);
        $file = $request->file('document');
        $version = (int) $document->version_no + 1;
        $path = $file->store('egpk/documents/'.date('Y/m'), 's3');
        $document->update(['storage_path' => $path, 'mime_type' => $file->getMimeType(), 'file_size' => $file->getSize(), 'version_no' => $version, 'updated_by' => $this->uid()]);
        DB::table('egpk_document_versions')->insert([
            'document_id' => $id, 'version_no' => $version, 'storage_path' => $path, 'file_size' => $file->getSize(), 'mime_type' => $file->getMimeType(), 'uploaded_by' => $this->uid(), 'created_at' => now(),
        ]);
        return $this->ok($document->fresh(), 'New document version uploaded.');
    }

    public function versions(int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canReadResource('document', $id, $document->owner_user_id, $document->company_id, $document->visibility), 403);
        return $this->ok(DB::table('egpk_document_versions')->where('document_id', $id)->orderByDesc('version_no')->get());
    }

    public function url(int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canReadResource('document', $id, $document->owner_user_id, $document->company_id, $document->visibility), 403);
        abort_if(config('filesystems.default') !== 's3' && !Storage::disk('s3')->exists($document->storage_path), 404, 'Document storage object was not found.');
        return $this->ok(['url' => Storage::disk('s3')->temporaryUrl($document->storage_path, now()->addMinutes(10))]);
    }

    public function pin(Request $request, int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document', $id, $document->owner_user_id), 403);
        $document->update(['is_pinned' => ! (bool) $document->is_pinned, 'updated_by' => $this->uid()]);
        return $this->ok(['pinned' => (bool) $document->is_pinned]);
    }

    public function delete(Request $request, int $id)
    {
        $document = Document::findOrFail($id);
        abort_unless($this->access->canManageResource('document', $id, $document->owner_user_id), 403);
        $document->update(['status' => 2, 'deleted_at' => now(), 'updated_by' => $this->uid()]);
        return $this->ok(null, 'Document removed.');
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company document access is not permitted.');
    }
}
