<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SuiteController extends ProductivityBaseController
{
    public function menu()
    {
        return $this->ok([
            ['key'=>'dashboard','label'=>'Dashboard','icon'=>'view-dashboard-outline','route'=>route('productivity.dashboard')],
            ['key'=>'contacts','label'=>'ContactBook','icon'=>'account-box-outline','route'=>route('productivity.contacts')],
            ['key'=>'bookmarks','label'=>'BookMarks','icon'=>'bookmark-outline','route'=>route('productivity.bookmarks')],
            ['key'=>'passwallet','label'=>'PassWallet','icon'=>'shield-key-outline','route'=>route('productivity.passwallet')],
            ['key'=>'knowledge','label'=>'Knowledge Panel','icon'=>'school-outline','route'=>route('productivity.knowledge')],
            ['key'=>'portals','label'=>'Portals & Apps','icon'=>'application-outline','route'=>route('productivity.portals')],
            ['key'=>'meetings','label'=>'Meetings','icon'=>'calendar-month-outline','route'=>route('productivity.meetings')],
            ['key'=>'tasks','label'=>'Tasks','icon'=>'check-circle-outline','route'=>route('productivity.tasks')],
            ['key'=>'notes','label'=>'Sticky Notes','icon'=>'note-multiple-outline','route'=>route('productivity.notes')],
            ['key'=>'money','label'=>'My Money','icon'=>'wallet-outline','route'=>route('productivity.money')],
            ['key'=>'events','label'=>'Events','icon'=>'calendar-star-outline','route'=>route('productivity.events')],
            ['key'=>'documents','label'=>'Documents','icon'=>'file-document-outline','route'=>route('productivity.documents')],
            ['key'=>'reports','label'=>'Reports','icon'=>'chart-box-outline','route'=>route('productivity.reports')],
            ['key'=>'admin','label'=>'Admin','icon'=>'shield-crown-outline','route'=>route('productivity.admin')],
        ]);
    }

    public function users(Request $request)
    {
        $q = DB::table('egc_staff')
            ->where('status', '!=', 2)
            ->where('sno', '>', 0)
            ->select('sno', 'staff_name', 'email_id', 'company_id');

        if ($request->filled('q')) {
            $term = trim((string) $request->q);
            $q->where(fn($x) => $x
                ->where('staff_name', 'like', "%{$term}%")
                ->orWhere('email_id', 'like', "%{$term}%"));
        }

        if (!$this->access->isGroupAdmin() && !$this->access->isAuditor() && $this->cid()) {
            $q->where('company_id', $this->cid());
        }

        return $this->ok($q->orderBy('staff_name')->limit(100)->get());
    }

    public function globalSearch(Request $request)
    {
        $term = trim((string) $request->input('q', ''));
        if (mb_strlen($term) < 2) return $this->ok([]);

        $like = "%{$term}%";
        $scope = $this->access->companyScope($request);
        $uid = $this->uid();
        $results = [];

        // Contacts: Group and same-company visibility are searchable, private records remain owner-only.
        $contacts = DB::table('egpk_contacts as c')
            ->leftJoin('egpk_contact_categories as cat', 'cat.sno', '=', 'c.category_id')
            ->where('c.status', 0)
            ->whereNull('c.deleted_at')
            ->when($scope, fn($q) => $q->whereIn('c.company_id', $scope))
            ->where(function ($q) use ($like, $uid) {
                $q->where('c.person_name', 'like', $like)
                  ->orWhere('c.organisation', 'like', $like)
                  ->orWhere('c.email_primary', 'like', $like)
                  ->orWhere('c.phone_primary', 'like', $like);
            })
            ->where(function ($q) use ($uid) {
                $q->where('c.owner_user_id', $uid)
                  ->orWhere('c.visibility', 'Group')
                  ->orWhere(function ($x) use ($uid) {
                      $x->where('c.visibility', 'Company')->where('c.company_id', $this->cid());
                  })
                  ->orWhereExists(function ($x) use ($uid) {
                      $x->selectRaw('1')->from('egpk_share_grants as sg')
                          ->whereColumn('sg.resource_id', 'c.sno')
                          ->where('sg.resource_type', 'contact')
                          ->where('sg.status', 'active')
                          ->where(function ($g) use ($uid) {
                              $g->where(fn($u) => $u->where('sg.grantee_type','user')->where('sg.grantee_id',(string)$uid))
                                ->orWhere(fn($r) => $r->where('sg.grantee_type','role')->where('sg.grantee_id',$this->access->role()))
                                ->orWhere(fn($g2) => $g2->where('sg.grantee_type','group')->where('sg.grantee_id','0'))
                                ->orWhere(fn($co) => $co->where('sg.grantee_type','company')->where('sg.grantee_id',(string)($this->cid() ?? -1)));
                          })
                          ->where(fn($e) => $e->whereNull('sg.expires_at')->orWhere('sg.expires_at','>=',now()));
                  });
            })
            ->limit(8)
            ->get(['c.sno','c.person_name','c.organisation','cat.category_name']);
        foreach ($contacts as $x) $results[] = ['module'=>'ContactBook','id'=>$x->sno,'title'=>$x->person_name,'subtitle'=>trim(($x->organisation ?? '').' · '.($x->category_name ?? ''))];

        // BookMarks are searchable by permitted boards only.
        $books = DB::table('egpk_bookmarks as bm')
            ->join('egpk_boards as b','b.sno','=','bm.board_id')
            ->where('bm.status',0)->where('b.status',0)->where('b.is_archived',0)
            ->when($scope,fn($q)=>$q->whereIn('b.company_id',$scope))
            ->where(fn($q)=>$q->where('bm.bookmark_name','like',$like)->orWhere('bm.url','like',$like)->orWhere('bm.description','like',$like))
            ->where(fn($q)=>$q->where('b.owner_user_id',$uid)->orWhere('b.visibility','Group')->orWhere(fn($x)=>$x->where('b.visibility','Company')->where('b.company_id',$this->cid()))
                ->orWhereExists(function($x)use($uid){$x->selectRaw('1')->from('egpk_share_grants as sg')->whereColumn('sg.resource_id','b.sno')->where('sg.resource_type','board')->where('sg.status','active')->where(fn($g)=>$g->where(fn($u)=>$u->where('sg.grantee_type','user')->where('sg.grantee_id',(string)$uid))->orWhere(fn($r)=>$r->where('sg.grantee_type','role')->where('sg.grantee_id',$this->access->role()))->orWhere(fn($gr)=>$gr->where('sg.grantee_type','group')->where('sg.grantee_id','0'))->orWhere(fn($co)=>$co->where('sg.grantee_type','company')->where('sg.grantee_id',(string)($this->cid()??-1))))->where(fn($e)=>$e->whereNull('sg.expires_at')->orWhere('sg.expires_at','>=',now()));}))
            ->limit(8)->get(['bm.sno','bm.bookmark_name','bm.url','b.board_name']);
        foreach ($books as $x) $results[] = ['module'=>'BookMarks','id'=>$x->sno,'title'=>$x->bookmark_name,'subtitle'=>trim($x->board_name.' · '.$x->url)];

        $posts = DB::table('egpk_knowledge_posts as p')
            ->where('p.status','published')->whereNull('p.deleted_at')
            ->when($scope,fn($q)=>$q->whereIn('p.company_id',$scope))
            ->where(fn($q)=>$q->where('p.title','like',$like)->orWhere('p.body_html','like',$like))
            ->where(fn($q)=>$q->where('p.author_user_id',$uid)->orWhere('p.audience_scope','Group')->orWhere('p.company_id',$this->cid()))
            ->limit(8)->get(['p.sno','p.title','p.company_id']);
        foreach ($posts as $x) $results[] = ['module'=>'Knowledge Panel','id'=>$x->sno,'title'=>$x->title,'subtitle'=>'Knowledge post'];

        $apps = DB::table('egpk_portal_apps as a')->whereNull('a.deleted_at')->when($scope,fn($q)=>$q->whereIn('a.company_id',$scope))
            ->where(fn($q)=>$q->where('a.app_name','like',$like)->orWhere('a.purpose','like',$like))->limit(8)
            ->get(['a.sno','a.app_name','a.current_version']);
        foreach ($apps as $x) $results[] = ['module'=>'Portals & Apps','id'=>$x->sno,'title'=>$x->app_name,'subtitle'=>'Version '.($x->current_version ?: '-')];

        $meetings = DB::table('egpk_meetings')->whereNull('deleted_at')->when($scope,fn($q)=>$q->whereIn('company_id',$scope))
            ->where('title','like',$like)->where(fn($q)=>$q->where('owner_user_id',$uid)->orWhereExists(function($s)use($uid){$s->selectRaw('1')->from('egpk_meeting_participants as mp')->whereColumn('mp.meeting_id','egpk_meetings.sno')->where('mp.staff_id',$uid);}))->limit(5)->get(['sno','title','start_at']);
        foreach($meetings as $x) $results[]=['module'=>'Meetings','id'=>$x->sno,'title'=>$x->title,'subtitle'=>(string)$x->start_at];

        $tasks = DB::table('egpk_tasks')->whereNull('deleted_at')->when($scope,fn($q)=>$q->whereIn('company_id',$scope))->where('title','like',$like)->where(fn($q)=>$q->where('owner_user_id',$uid)->orWhereExists(function($a)use($uid){$a->selectRaw('1')->from('egpk_task_assignees as ta')->whereColumn('ta.task_id','egpk_tasks.sno')->where('ta.staff_id',$uid);}))->limit(5)->get(['sno','title','status']);
        foreach($tasks as $x) $results[]=['module'=>'Tasks','id'=>$x->sno,'title'=>$x->title,'subtitle'=>(string)$x->status];

        return $this->ok(array_slice($results, 0, 30));
    }

    public function companies()
    {
        return $this->ok(DB::table('egc_company')->where('status',0)->orderBy('company_name')->get(['sno','company_name','company_short_name','company_base_color']));
    }

    public function notifications(Request $request)
    {
        $rows = DB::table('egpk_productivity_notifications')
            ->where('user_id', $this->uid())
            ->where(function ($q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>=', now());
            })
            ->orderByDesc('created_at')
            ->limit(50)
            ->get();

        return $this->ok([
            'unread' => $rows->where('is_read', 0)->count(),
            'items' => $rows,
        ]);
    }

    public function markNotificationsRead(Request $request)
    {
        if ($request->filled('id')) {
            DB::table('egpk_productivity_notifications')
                ->where('sno', (int) $request->input('id'))
                ->where('user_id', $this->uid())
                ->update(['is_read' => 1, 'read_at' => now(), 'updated_at' => now()]);
        } else {
            DB::table('egpk_productivity_notifications')
                ->where('user_id', $this->uid())
                ->where('is_read', 0)
                ->update(['is_read' => 1, 'read_at' => now(), 'updated_at' => now()]);
        }
        return $this->ok(null, 'Notifications marked as read.');
    }

}
