<?php
namespace App\Http\Controllers\productivity;
use Illuminate\Http\Request;use Illuminate\Support\Facades\DB;
class AdminController extends ProductivityBaseController
{
 public function index(){return view('content.productivity.admin.index');}
 public function data(Request $r){abort_unless($this->access->isCompanyAdmin(),403);return $this->ok(['shares'=>DB::table('egpk_share_grants')->orderByDesc('created_at')->limit(500)->get(),'audits'=>DB::table('egpk_audit_logs')->orderByDesc('created_at')->limit(500)->get(),'contact_categories'=>DB::table('egpk_contact_categories')->where('status',0)->orderBy('category_name')->get(),'vault_categories'=>DB::table('egpk_vault_categories')->where('status',0)->orderBy('category_name')->get(),'knowledge_categories'=>DB::table('egpk_knowledge_categories')->where('status',0)->orderBy('category_name')->get()]);}
 public function category(Request $r){abort_unless($this->access->isGroupAdmin(),403);$d=$r->validate(['type'=>'required|in:contact,vault,knowledge','name'=>'required|string|max:100','color'=>'nullable|string|max:20']);$map=['contact'=>'egpk_contact_categories','vault'=>'egpk_vault_categories','knowledge'=>'egpk_knowledge_categories'];$row=['category_name'=>$d['name'],'status'=>0,'created_by'=>$this->uid(),'updated_by'=>$this->uid()];if($d['type']!=='knowledge')$row['company_id']=$this->cid();if($d['color'])$row['color']=$d['color'];$id=DB::table($map[$d['type']])->insertGetId($row);return $this->ok(['id'=>$id],'Category created.');}
}
