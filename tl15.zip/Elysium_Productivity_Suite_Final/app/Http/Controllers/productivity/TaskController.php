<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskController extends ProductivityBaseController
{
    public function index()
    {
        return view('content.productivity.tasks.index');
    }

    public function data(Request $request)
    {
        $query = Task::query()->whereNull('deleted_at');
        $this->applyReadableScope($query, $request, 'task');
        $uid = $this->uid();
        $query->where(function ($q) use ($uid) {
            $q->where('owner_user_id', $uid)
                ->orWhere('supervisor_user_id', $uid)
                ->orWhereExists(function ($share) use ($uid) {
                    $share->selectRaw('1')->from('egpk_share_grants as sg')
                        ->where('sg.resource_type', 'task')->whereColumn('sg.resource_id', 'egpk_tasks.sno')
                        ->where('sg.status', 'active')
                        ->where(function ($g) use ($uid) {
                            $g->where(fn ($u) => $u->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                                ->orWhere(fn ($r) => $r->where('sg.grantee_type', 'role')->where('sg.grantee_id', $this->access->role()))
                                ->orWhere(fn ($c) => $c->where('sg.grantee_type', 'company')->where('sg.grantee_id', (string) ($this->cid() ?? -1)))
                                ->orWhere(fn ($g2) => $g2->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'));
                        })
                        ->where(fn ($e) => $e->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
                })
                ->orWhereExists(function ($s) use ($uid) {
                    $s->selectRaw('1')->from('egpk_task_assignees as ta')->whereColumn('ta.task_id', 'egpk_tasks.sno')->where('ta.user_id', $uid);
                });
        });
        foreach (['priority', 'status', 'category'] as $filter) {
            if ($request->filled($filter)) $query->where($filter, $request->input($filter));
        }
        if ($request->filled('search')) {
            $s = trim((string) $request->input('search'));
            $query->where(fn ($q) => $q->where('title', 'like', "%{$s}%")->orWhere('description', 'like', "%{$s}%"));
        }
        return $this->ok(['rows' => $query->orderByRaw("FIELD(priority,'Urgent','High','Medium','Low')")->orderBy('due_at')->paginate(min(max((int) $request->get('per_page', 30), 10), 100))]);
    }

    public function show(int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canReadResource('task', $id, $task->owner_user_id, $task->company_id, $task->visibility), 403);
        return $this->ok([
            'task' => $task,
            'assignees' => DB::table('egpk_task_assignees')->where('task_id', $id)->get(),
            'comments' => DB::table('egpk_task_comments')->where('task_id', $id)->orderBy('created_at')->get(),
        ]);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $this->validateData($request);
        $this->assertCompany($data['company_id'] ?? null);
        $task = Task::create(array_merge($data, [
            'company_id' => $data['company_id'] ?? $this->cid(),
            'owner_user_id' => $this->uid(),
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]));
        $this->sync($task, $data['assignee_ids'] ?? []);
        $this->audit($request, 'Tasks', 'created', 'task', $task->sno, null, $task->toArray());
        return $this->ok($task, 'Task created.');
    }

    public function update(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $data = $this->validateData($request);
        $this->assertCompany($data['company_id'] ?? $task->company_id);
        $before = $task->toArray();
        $assignees = $data['assignee_ids'] ?? [];
        unset($data['assignee_ids']);
        $task->update(array_merge($data, ['updated_by' => $this->uid()]));
        $this->sync($task, $assignees);
        $this->audit($request, 'Tasks', 'updated', 'task', $id, $before, $task->fresh()->toArray());
        return $this->ok($task->fresh(), 'Task updated.');
    }

    public function status(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $data = $request->validate(['status' => ['required', 'in:To Do,In Progress,On Hold,Pending Verification,Completed']]);
        $task->update(['status' => $data['status'], 'updated_by' => $this->uid()]);
        return $this->ok($task->fresh());
    }

    public function comment(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canReadResource('task', $id, $task->owner_user_id, $task->company_id, $task->visibility), 403);
        $data = $request->validate(['comment_text' => ['required', 'string', 'max:5000']]);
        $commentId = DB::table('egpk_task_comments')->insertGetId(['task_id' => $id, 'user_id' => $this->uid(), 'comment_text' => $data['comment_text'], 'created_at' => now()]);
        return $this->ok(['id' => $commentId], 'Comment added.');
    }

    public function verify(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($task->status === 'Pending Verification', 422, 'Task is not pending verification.');
        abort_unless($task->supervisor_user_id === $this->uid() || $this->access->isCompanyAdmin(), 403);
        $task->update(['status' => 'Completed', 'updated_by' => $this->uid()]);
        return $this->ok($task->fresh(), 'Task verified and completed.');
    }

    public function delete(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $task->update(['deleted_at' => now(), 'updated_by' => $this->uid()]);
        return $this->ok(null, 'Task deleted.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'title' => ['required', 'string', 'max:220'],
            'category' => ['required', 'string', 'max:80'],
            'priority' => ['required', 'in:Low,Medium,High,Urgent'],
            'due_at' => ['nullable', 'date'],
            'status' => ['nullable', 'in:To Do,In Progress,On Hold,Pending Verification,Completed'],
            'description' => ['nullable', 'string', 'max:10000'],
            'supervisor_user_id' => ['nullable', 'integer', 'exists:egc_staff,sno'],
            'verification_required' => ['nullable', 'boolean'],
            'assignee_ids' => ['nullable', 'array', 'max:500'],
            'assignee_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
        ]);
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company task access is not permitted.');
    }

    private function sync(Task $task, array $ids): void
    {
        DB::transaction(function () use ($task, $ids) {
            DB::table('egpk_task_assignees')->where('task_id', $task->sno)->delete();
            foreach ($this->ids($ids) as $userId) {
                DB::table('egpk_task_assignees')->insert(['task_id' => $task->sno, 'user_id' => $userId, 'created_at' => now()]);
            }
        });
    }
}
