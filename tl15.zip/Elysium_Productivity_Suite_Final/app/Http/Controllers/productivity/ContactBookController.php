<?php
namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Contact;
use App\Models\Productivity\ContactCategory;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ContactBookController extends ProductivityBaseController
{
    public function index(){ return view('content.productivity.contactbook.index'); }
    public function categories(Request $r){$q=ContactCategory::where('status',0)->orderBy('category_name');$this->applyScope($q,$r);return $this->ok($q->get());}
    public function data(Request $r){
        $q=Contact::query()->with('category')->where('status',0); $this->applyReadableScope($q,$r,'contact');
        $q->when($r->filled('category_id'),fn($x)=>$x->where('category_id',(int)$r->category_id));
        $q->when($r->filled('visibility'),fn($x)=>$x->where('visibility',$r->visibility));
        $q->when($r->filled('city'),fn($x)=>$x->where('city','like','%'.trim($r->city).'%'));
        if($r->filled('search')){$s=trim($r->search);$q->where(function($x)use($s){$x->where('person_name','like',"%$s%")->orWhere('organisation','like',"%$s%")->orWhere('phone_primary','like',"%$s%")->orWhere('email_primary','like',"%$s%")->orWhere('notes','like',"%$s%");});}
        $p=$q->orderByDesc('is_starred')->orderBy('person_name')->paginate(min(max((int)$r->get('per_page',25),10),100));
        return $this->ok([
            'rows' => $p->items(),
            'pagination' => ['current'=>$p->currentPage(),'last'=>$p->lastPage(),'total'=>$p->total()],
            'stats' => ['total' => (clone $q)->toBase()->count(), 'starred' => (clone $q)->where('is_starred',1)->count()],
        ]);
    }
    public function show($id, Request $r)
    {
        $c=Contact::find($id);
        abort_unless($c && $c->status===0,404);
        abort_unless($this->access->canReadResource('contact',$c->sno,$c->owner_user_id,$c->company_id,$c->visibility),403);
        $posts=DB::table('egpk_knowledge_posts')->where('status','published')->where(fn($q)=>$q->where('body_html','like','%'.addslashes($c->person_name).'%')->orWhere('title','like','%'.addslashes($c->person_name).'%'))->limit(20)->get(['sno','title','published_at']);
        return $this->ok(['contact'=>$c->load('category'),'activity'=>DB::table('egpk_audit_logs')->where('resource_type','contact')->where('resource_id',$id)->orderByDesc('created_at')->limit(100)->get(),'knowledge_posts'=>$posts]);
    }
    public function store(Request $r){
        abort_unless($this->access->canWrite(),403); $d=$r->validate(['company_id'=>'nullable|integer','visibility'=>'required|in:Private,Company,Group','salutation'=>'nullable|string|max:20','person_name'=>'required|string|max:180','designation'=>'nullable|string|max:150','organisation'=>'nullable|string|max:180','department'=>'nullable|string|max:150','phone_primary'=>'nullable|string|max:40','phone_alternate'=>'nullable|string|max:40','email_primary'=>'nullable|email|max:180','email_secondary'=>'nullable|email|max:180','city'=>'nullable|string|max:100','address'=>'nullable|string|max:5000','website'=>'nullable|url|max:255','category_id'=>'required|integer|exists:egpk_contact_categories,sno','notes'=>'nullable|string|max:10000','profile_photo'=>'nullable|string|max:500','is_starred'=>'nullable|boolean']);
        $d['owner_user_id']=$this->uid(); $d['created_by']=$this->uid(); $d['updated_by']=$this->uid(); $d['company_id']=$d['company_id']??$this->cid();
        $dup=Contact::where(function($q)use($d){$q->whereNotNull('phone_primary')->where('phone_primary',$d['phone_primary']??'')->when(!empty($d['email_primary']),fn($x)=>$x->orWhere('email_primary',$d['email_primary']));})->where('status',0)->first();
        if($dup) return $this->fail('A possible duplicate contact already exists.',409,['duplicate'=>$dup]);
        $c=Contact::create($d); $this->audit($r,'ContactBook','created','contact',$c->sno,null,$c->toArray()); return $this->ok($c->load('category'),'Contact created successfully.');
    }
    public function update(Request $r,$id){$c=Contact::findOrFail($id);abort_unless($this->access->canManageResource('contact',$c->sno,$c->owner_user_id),403);$d=$r->validate(['company_id'=>'nullable|integer','visibility'=>'required|in:Private,Company,Group','salutation'=>'nullable|string|max:20','person_name'=>'required|string|max:180','designation'=>'nullable|string|max:150','organisation'=>'nullable|string|max:180','department'=>'nullable|string|max:150','phone_primary'=>'nullable|string|max:40','phone_alternate'=>'nullable|string|max:40','email_primary'=>'nullable|email|max:180','email_secondary'=>'nullable|email|max:180','city'=>'nullable|string|max:100','address'=>'nullable|string|max:5000','website'=>'nullable|url|max:255','category_id'=>'required|integer|exists:egpk_contact_categories,sno','notes'=>'nullable|string|max:10000','profile_photo'=>'nullable|string|max:500','is_starred'=>'nullable|boolean']);$before=$c->toArray();$d['updated_by']=$this->uid();$c->update($d);$this->audit($r,'ContactBook','updated','contact',$c->sno,$before,$c->fresh()->toArray());return $this->ok($c->fresh()->load('category'),'Contact updated successfully.');}
    public function delete(Request $r,$id){$c=Contact::findOrFail($id);abort_unless($this->access->canManageResource('contact',$c->sno,$c->owner_user_id),403);$c->update(['status'=>2,'deleted_at'=>now(),'updated_by'=>$this->uid()]);$this->audit($r,'ContactBook','deactivated','contact',$id);return $this->ok(null,'Contact deactivated successfully.');}
    public function restore(Request $r,$id){abort_unless($this->access->isCompanyAdmin(),403);$c=Contact::withTrashed()->findOrFail($id);$c->restore();$c->update(['status'=>0,'updated_by'=>$this->uid()]);return $this->ok($c,'Contact restored successfully.');}
    public function star(Request $r,$id){$c=Contact::findOrFail($id);abort_unless($this->access->canManageResource('contact',$c->sno,$c->owner_user_id),403);$c->update(['is_starred'=>!$c->is_starred,'updated_by'=>$this->uid()]);return $this->ok(['starred'=>(bool)$c->is_starred]);}
    public function bulk(Request $r){abort_unless($this->access->canWrite(),403);$d=$r->validate(['ids'=>'required|array|min:1','ids.*'=>'integer','action'=>'required|in:category,visibility,tag,deactivate']);$ids=$this->ids($d['ids']);$q=Contact::whereIn('sno',$ids);$this->applyScope($q,$r);$update=['updated_by'=>$this->uid()];if($d['action']==='category'){$r->validate(['category_id'=>'required|integer|exists:egpk_contact_categories,sno']);$update['category_id']=(int)$r->category_id;}elseif($d['action']==='visibility'){$r->validate(['visibility'=>'required|in:Private,Company,Group']);$update['visibility']=$r->visibility;}elseif($d['action']==='deactivate'){$update['status']=2;$update['deleted_at']=now();}$count=$q->update($update);$this->audit($r,'ContactBook','bulk_'.$d['action'],'contact',null,null,$update,['count'=>$count]);return $this->ok(['updated'=>$count]);}
    public function searchHistory(Request $r){$q=DB::table('egpk_search_history')->where('user_id',$this->uid())->where('module_name','ContactBook')->latest()->limit(10);return $this->ok($q->get());}
    public function saveSearch(Request $r){$d=$r->validate(['search_text'=>'required|string|max:500']);DB::table('egpk_search_history')->insert(['user_id'=>$this->uid(),'module_name'=>'ContactBook','search_text'=>$d['search_text'],'created_at'=>now()]);return $this->ok(null,'Search saved.');}
    public function exportCsv(Request $r)
    {
        abort_unless($this->access->canExport(),403); $q=Contact::where('status',0); $this->applyReadableScope($q,$r,'contact');
        $rows=$q->with('category')->orderBy('person_name')->get(); $this->audit($r,'ContactBook','export','contact',null,null,null,['format'=>'csv','row_count'=>$rows->count()]);
        return response()->streamDownload(function()use($rows){$out=fopen('php://output','w');fputcsv($out,['Name','Organisation','Designation','Phone','Email','City','Category','Visibility']);foreach($rows as $c)fputcsv($out,[$c->person_name,$c->organisation,$c->designation,$c->phone_primary,$c->email_primary,$c->city,$c->category?->category_name,$c->visibility]);fclose($out);},'contactbook_'.now()->format('Ymd_His').'.csv',['Content-Type'=>'text/csv']);
    }
    public function import(Request $r)
    {
        abort_unless($this->access->canWrite(),403); $d=$r->validate(['file'=>'required|file|max:10240|mimes:xlsx,xls,csv,txt,vcf']); $file=$r->file('file'); $rows=[]; $ext=strtolower($file->getClientOriginalExtension());
        if(in_array($ext,['xlsx','xls'],true)){ abort_unless(class_exists(\PhpOffice\PhpSpreadsheet\IOFactory::class),503,'Excel import support is not installed. Run composer require phpoffice/phpspreadsheet.'); $sheet=\PhpOffice\PhpSpreadsheet\IOFactory::load($file->getRealPath())->getActiveSheet(); $raw=$sheet->toArray(null,true,true,true); $headers=array_shift($raw); foreach($raw as $r){ $mapped=[]; foreach($headers as $k=>$h){ if($h!==null && $h!=='') $mapped[trim((string)$h)]=$r[$k]??null; } $rows[]=$mapped; } }
        elseif($ext==='csv'||$ext==='txt'){ $h=fopen($file->getRealPath(),'r'); $headers=fgetcsv($h); while(($row=fgetcsv($h))!==false){$rows[]=array_combine($headers,$row);} fclose($h); }
        else { $text=file_get_contents($file->getRealPath()); foreach(preg_split("/END:VCARD\s*/i",$text) as $card){if(stripos($card,'BEGIN:VCARD')===false)continue;$get=function($key)use($card){if(preg_match('/^'.preg_quote($key,'/').'.*?:([^\r\n]*)/mi',$card,$m))return trim($m[1]);return null;};$rows[]=['Name'=>$get('FN'),'Phone'=>$get('TEL'),'Email'=>$get('EMAIL')];} }
        $imported=$skipped=$merged=0; foreach($rows as $row){$name=trim((string)($row['Name']??$row['name']??$row['Person Name']??''));if($name===''){ $skipped++;continue;} $phone=trim((string)($row['Phone']??$row['phone']??$row['Primary Number']??''));$email=trim((string)($row['Email']??$row['email']??''));$dup=Contact::where('status',0)->where(function($q)use($phone,$email){if($phone!=='')$q->where('phone_primary',$phone);if($email!=='')$q->orWhere('email_primary',$email);})->first();if($dup){$merged++;continue;}$cat=ContactCategory::where('status',0)->orderBy('sno')->first();if(!$cat){$skipped++;continue;}Contact::create(['company_id'=>$this->cid(),'owner_user_id'=>$this->uid(),'visibility'=>'Private','person_name'=>$name,'phone_primary'=>$phone?:null,'email_primary'=>$email?:null,'organisation'=>$row['Organisation']??$row['Company']??null,'designation'=>$row['Designation']??null,'city'=>$row['City']??null,'category_id'=>$cat->sno,'created_by'=>$this->uid(),'updated_by'=>$this->uid()]);$imported++;}
        $id=DB::table('egpk_contact_imports')->insertGetId(['company_id'=>$this->cid(),'owner_user_id'=>$this->uid(),'source'=>$ext==='vcf'?'vcard':$ext,'file_name'=>$file->getClientOriginalName(),'total_rows'=>count($rows),'imported_rows'=>$imported,'merged_rows'=>$merged,'skipped_rows'=>$skipped,'status'=>'completed','report_json'=>json_encode(['imported'=>$imported,'merged'=>$merged,'skipped'=>$skipped]),'created_at'=>now(),'updated_at'=>now()]);$this->audit($r,'ContactBook','imported','contact_import',$id,null,null,['imported'=>$imported,'merged'=>$merged,'skipped'=>$skipped]);return $this->ok(['import_id'=>$id,'imported'=>$imported,'merged'=>$merged,'skipped'=>$skipped],'Contact import completed.');
    }
    public function merge(Request $r){abort_unless($this->access->isCompanyAdmin(),403);$d=$r->validate(['surviving_id'=>'required|integer','merged_id'=>'required|integer|different:surviving_id','field_decisions'=>'nullable|array']);$a=Contact::findOrFail($d['surviving_id']);$b=Contact::findOrFail($d['merged_id']);DB::transaction(function()use($a,$b,$d){$fields=['salutation','designation','organisation','department','phone_primary','phone_alternate','email_primary','email_secondary','city','address','website','notes'];foreach($fields as $f){if(empty($a->$f)&&!empty($b->$f))$a->$f=$b->$f;} $a->updated_by=$this->uid();$a->save();$b->update(['status'=>2,'deleted_at'=>now(),'updated_by'=>$this->uid()]);DB::table('egpk_contact_merge_logs')->insert(['surviving_contact_id'=>$a->sno,'merged_contact_id'=>$b->sno,'merged_by'=>$this->uid(),'field_decisions'=>json_encode($d['field_decisions']??[]),'created_at'=>now()]);});return $this->ok($a->fresh(),'Contacts merged successfully.');}
    public function exportXlsx(Request $r)
    {
        abort_unless($this->access->canExport(), 403);
        abort_unless(class_exists(Spreadsheet::class) && class_exists(Xlsx::class), 503, 'XLSX support is not installed. Run composer require phpoffice/phpspreadsheet.');

        $q = Contact::where('status', 0);
        $this->applyReadableScope($q, $r, 'contact');
        $rows = $q->with('category')->orderBy('person_name')->get();
        $this->audit($r, 'ContactBook', 'export', 'contact', null, null, null, ['format' => 'xlsx', 'row_count' => $rows->count()]);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Name','Organisation','Designation','Department','Phone','Alternate Phone','Email','Secondary Email','City','Address','Website','Category','Visibility'];
        $sheet->fromArray($headers, null, 'A1');
        $rowNo = 2;
        foreach ($rows as $c) {
            $sheet->fromArray([
                $c->person_name,$c->organisation,$c->designation,$c->department,$c->phone_primary,$c->phone_alternate,
                $c->email_primary,$c->email_secondary,$c->city,$c->address,$c->website,$c->category?->category_name,$c->visibility
            ], null, 'A'.$rowNo++);
        }
        $sheet->getStyle('A1:M1')->getFont()->setBold(true);
        foreach (range('A','M') as $col) $sheet->getColumnDimension($col)->setAutoSize(true);

        $writer = new Xlsx($spreadsheet);
        return response()->streamDownload(function() use ($writer) { $writer->save('php://output'); }, 'contactbook_'.now()->format('Ymd_His').'.xlsx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ]);
    }

    public function exportVcard(Request $r)
    {
        abort_unless($this->access->canExport(),403);$q=Contact::where('status',0);$this->applyScope($q,$r);$rows=$q->orderBy('person_name')->get();$this->audit($r,'ContactBook','export','contact',null,null,null,['format'=>'vcard','row_count'=>$rows->count()]);
        return response()->streamDownload(function()use($rows){foreach($rows as $c){echo "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:".str_replace(["\r","\n"],' ',$c->person_name)."\r\n";if($c->phone_primary)echo 'TEL;TYPE=CELL:'.$c->phone_primary."\r\n";if($c->email_primary)echo 'EMAIL:'.$c->email_primary."\r\n";if($c->organisation)echo 'ORG:'.str_replace(["\r","\n"],' ',$c->organisation)."\r\n";echo "END:VCARD\r\n";}},'contactbook_'.now()->format('Ymd_His').'.vcf',['Content-Type'=>'text/vcard']);
    }
    public function googleImport(Request $r)
    {
        abort_unless($this->access->canWrite(),403);$d=$r->validate(['access_token'=>'required|string']);$response=\Illuminate\Support\Facades\Http::withToken($d['access_token'])->acceptJson()->get('https://people.googleapis.com/v1/people/me/connections',['personFields'=>'names,emailAddresses,phoneNumbers,organizations,addresses','pageSize'=>1000]);abort_unless($response->successful(),422,'Unable to read Google contacts. OAuth consent or token may be invalid.');$rows=$response->json('connections',[]);$cat=ContactCategory::where('status',0)->orderBy('sno')->first();abort_if(!$cat,422,'Create at least one contact category.');$imported=$duplicates=0;foreach($rows as $p){$name=data_get($p,'names.0.displayName');if(!$name)continue;$phone=data_get($p,'phoneNumbers.0.value');$email=data_get($p,'emailAddresses.0.value');$dup=Contact::where('status',0)->where(fn($q)=>$q->where('phone_primary',$phone)->orWhere('email_primary',$email))->first();if($dup){$duplicates++;continue;}Contact::create(['company_id'=>$this->cid(),'owner_user_id'=>$this->uid(),'visibility'=>'Private','person_name'=>$name,'phone_primary'=>$phone,'email_primary'=>$email,'organisation'=>data_get($p,'organizations.0.name'),'category_id'=>$cat->sno,'created_by'=>$this->uid(),'updated_by'=>$this->uid()]);$imported++;}return $this->ok(['imported'=>$imported,'duplicates'=>$duplicates],'Google contact snapshot imported.');
    }

}
