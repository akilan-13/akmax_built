<?php

return [
    /*
    |--------------------------------------------------------------------------
    | External connectors
    |--------------------------------------------------------------------------
    */
    'google' => [
        'client_id' => env('EGPK_GOOGLE_CLIENT_ID'),
        'client_secret' => env('EGPK_GOOGLE_CLIENT_SECRET'),
        'redirect_uri' => env('EGPK_GOOGLE_REDIRECT_URI'),
    ],

    /*
    |--------------------------------------------------------------------------
    | PassWallet
    |--------------------------------------------------------------------------
    */
    'passwallet' => [
        'step_up_minutes' => (int) env('EGPK_STEP_UP_MINUTES', 5),
        'clipboard_clear_seconds' => (int) env('EGPK_CLIPBOARD_CLEAR_SECONDS', 30),
        'kms_key_id' => env('EGPK_KMS_KEY_ID'),
    ],

    /*
    |--------------------------------------------------------------------------
    | File policy
    |--------------------------------------------------------------------------
    */
    'files' => [
        'max_kb' => (int) env('EGPK_MAX_UPLOAD_KB', 51200),
        'disk' => env('EGPK_FILE_DISK', 's3'),
    ],
];
