# Feature Matrix

## ContactBook
CRUD, visibility, favourites, search, category filtering, bulk operations, CSV/XLSX/vCard export, CSV/XLSX/vCard import, duplicate detection, merge workflow, activity logging, Google snapshot import endpoint.

## BookMarks
Boards, categories, colours, quick add, URL validation, duplicate URL detection, browser HTML import, move/copy endpoints, click tracking, link-health endpoint, sharing, masonry-style board rendering.

## PassWallet
Website/System/Application/Mobile App types, encrypted secret storage, masked UI, step-up verification, reveal, copy audit, password generator, password history, rotation metadata, controlled sharing, lockdown endpoint, attachments, high-sensitivity audit.

## Knowledge Panel
Categories/subcategories, rich HTML body, draft/published/unpublished status, edit versions, media upload, likes, replies, saves, follows, reporting, moderation, searchable feed.

## Portals & Apps
Registry, platform/environment/status, version history, launch tracking, subscriptions, PassWallet linkage, company filtering, XLSX export.

## Meetings
Date/time range, category, venue, meeting URL, agenda, participants, RSVP, conflict detection, reschedule history, sharing, calendar endpoint.

## Tasks
Priority, status workflow, supervisor, assignees, verification, comments, sharing, company scope, delete/soft-delete.

## Sticky Notes
Colour, priority, reminder, checklist JSON, pin/archive/trash/restore, company/group/user visibility, sharing.

## My Money
Personal accounts, transactions, budgets and commitments. Cross-user sharing is blocked by design.

## Events
Event type, date/time, venue, online link, payment amount, status, visibility, calendar endpoint.

## Documents
Personal/Official scope, visibility, upload, version history, pin, temporary S3 URL, soft delete and sharing.

## Reports / Admin
Role-scoped reports, CSV/XLSX export endpoints, sharing register, audit viewer, category masters.
