# Deployment Checklist

- [ ] Apply `database/sql/egpk_productivity_suite_final.sql` to staging first.
- [ ] Confirm existing `egc_company`, `egc_staff` and ERP authentication fields match the controller assumptions.
- [ ] Verify `auth()->user()->user_id` and `company_id` values in staging.
- [ ] Configure S3 disk and production AWS permissions.
- [ ] Configure PassWallet KMS key and disable any local encryption fallback before go-live.
- [ ] Install PhpSpreadsheet for XLSX import/export if not already present.
- [ ] Configure Google People OAuth credentials and callback.
- [ ] Register routes under the normal authenticated `web` stack.
- [ ] Run Vite production build.
- [ ] Run PHP/JS smoke checks.
- [ ] Test each RBAC role, especially cross-company visibility and sharing.
- [ ] Test Auditor cannot reveal/copy/change credentials.
- [ ] Test My Money cannot be shared.
- [ ] Test file upload validation and S3 temporary URLs.
- [ ] Test notification create/read flow.
- [ ] Test backups and rollback according to the ERP release process.
