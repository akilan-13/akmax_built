(function ($) {
    'use strict';

    const routes = window.LoanCalendarRoutes || {};
    const config = window.LoanCalendarConfig || {};

    if (!routes.calendar || !document.getElementById('loanCalendarPage')) {
        return;
    }

    const state = {
        view: 'month',
        cursor: new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            1
        ),
        weekDate: config.today || new Date().toISOString().slice(0, 10),
        entityId: '',
        typeId: '',
        lenderId: '',
        status: '',
        search: '',
        items: [],
        activeItem: null,
        request: null,
    };

    let detailModal = null;
    let paymentModal = null;
    let snoozeModal = null;

    function safeModal(selector) {
        const element = document.querySelector(selector);

        if (!element || !window.bootstrap || !bootstrap.Modal) {
            return null;
        }

        return bootstrap.Modal.getOrCreateInstance(element);
    }

    function esc(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function url(template, id) {
        return String(template || '').replace(
            '__ID__',
            encodeURIComponent(String(id))
        );
    }

    function money(value) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2,
        }).format(Number(value || 0));
    }

    function date(value) {
        if (!value) {
            return '-';
        }

        const parts = String(value).slice(0, 10).split('-');

        return parts.length === 3
            ? `${parts[2]}-${parts[1]}-${parts[0]}`
            : String(value);
    }

    function isoDate(dateObject) {
        const year = dateObject.getFullYear();
        const month = String(dateObject.getMonth() + 1).padStart(2, '0');
        const day = String(dateObject.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }

    function parseLocalDate(value) {
        const parts = String(value).split('-').map(Number);

        return new Date(
            parts[0],
            parts[1] - 1,
            parts[2]
        );
    }

    function monthLabel(dateObject) {
        return dateObject.toLocaleString('en-GB', {
            month: 'long',
            year: 'numeric',
        });
    }

    function escapeSelector(value) {
        return window.CSS && CSS.escape
            ? CSS.escape(String(value))
            : String(value).replace(/["\\]/g, '\\$&');
    }

    function toast(message, type = 'success') {
        const el = document.getElementById('calendarToast');
        const body = document.getElementById('calendarToastBody');

        if (!el || !body) {
            return;
        }

        el.classList.remove(
            'text-bg-success',
            'text-bg-danger',
            'text-bg-warning',
            'text-bg-info'
        );

        const map = {
            success: 'text-bg-success',
            error: 'text-bg-danger',
            warning: 'text-bg-warning',
            info: 'text-bg-info',
        };

        el.classList.add(map[type] || map.success);
        body.textContent = message || 'Completed.';

        if (window.bootstrap && bootstrap.Toast) {
            bootstrap.Toast.getOrCreateInstance(el, {
                delay: 3500
            }).show();
        }
    }

    function statusBadge(status) {
        const map = {
            upcoming: ['Upcoming', 'event-upcoming'],
            today: ['Due Today', 'event-today'],
            overdue: ['Overdue', 'event-overdue'],
            paid: ['Paid', 'event-paid'],
            snoozed: ['Snoozed', 'event-snoozed'],
            pending: ['Pending', 'event-upcoming'],
            partial: ['Partial', 'event-today'],
        };

        const item = map[status] || ['Pending', 'event-upcoming'];

        return `
            <span class="badge rounded-pill ${item[1]}">
                ${esc(item[0])}
            </span>
        `;
    }

    function typeIcon(item) {
        const icon = item.loan?.loan_type_icon
            || 'mdi-calendar-check-outline';

        return `<i class="mdi ${esc(icon)}"></i>`;
    }

    function fetchLookups() {
        const parentRoutes = window.LoanScheduleRoutes || {};

        if (!parentRoutes.lookups) {
            return $.Deferred().resolve().promise();
        }

        return $.ajax({
            url: parentRoutes.lookups,
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        }).done(function (response) {
            if (Number(response?.status) !== 200) {
                return;
            }

            const data = response.data || {};

            populateSelect(
                '#calendarEntityFilter',
                data.entities || [],
                'All Entities',
                'id',
                'name'
            );

            populateSelect(
                '#calendarTypeFilter',
                data.types || [],
                'All Types',
                'id',
                'type_name'
            );

            populateSelect(
                '#calendarLenderFilter',
                data.lenders || [],
                'All Lenders',
                'id',
                'lender_name'
            );
        }).fail(function (xhr) {
            console.error('Loan calendar lookup error', xhr);
        });
    }

    function populateSelect(
        selector,
        items,
        placeholder,
        idField,
        nameField
    ) {
        const select = $(selector);
        let html = `<option value="">${esc(placeholder)}</option>`;

        items.forEach(function (item) {
            html += `
                <option value="${esc(item[idField])}">
                    ${esc(item[nameField] || '-')}
                </option>
            `;
        });

        select.html(html);
    }

    function buildRequest() {
        const year = state.cursor.getFullYear();
        const month = state.cursor.getMonth() + 1;

        return {
            year: year,
            month: month,
            view: state.view === 'week' ? 'week' : 'month',
            date: state.weekDate,
            entity_id: state.entityId,
            type_id: state.typeId,
            lender_id: state.lenderId,
            status: state.status,
            search: state.search,
        };
    }

    function loadCalendar() {
        $('#calendarMonthTitle').text(
            state.view === 'week'
                ? 'Loading week...'
                : monthLabel(state.cursor)
        );

        $('#calendarContent').html(`
            <div class="calendar-loading">
                <div class="spinner-border text-danger mb-2"></div>
                <div class="fw-semibold">
                    Loading schedule calendar...
                </div>
            </div>
        `);

        if (state.request && state.request.readyState !== 4) {
            state.request.abort();
        }

        state.request = $.ajax({
            url: routes.calendar,
            type: 'GET',
            data: buildRequest(),
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (Number(response?.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to load calendar.'
                );
            }

            state.items = response.data || [];

            renderSummary(response.summary || {});
            renderHeader(response.range || {});

            if (state.view === 'month') {
                renderMonth();
            } else if (state.view === 'week') {
                renderWeek();
            } else {
                renderList();
            }
        })
        .fail(function (xhr, statusText) {
            if (statusText === 'abort') {
                return;
            }

            $('#calendarContent').html(`
                <div class="calendar-empty">
                    <div class="calendar-empty-icon">
                        <i class="mdi mdi-alert-circle-outline"></i>
                    </div>
                    <div class="fw-bold text-dark">
                        Unable to load schedule
                    </div>
                    <div class="small mt-1">
                        Please try again.
                    </div>
                    <button
                        type="button"
                        class="btn btn-danger btn-sm mt-3"
                        id="calendarRetryBtn"
                    >
                        Retry
                    </button>
                </div>
            `);

            $('#calendarRetryBtn').on(
                'click',
                loadCalendar
            );

            const message = xhr.responseJSON?.message
                || 'Unable to load schedule calendar.';

            toast(message, 'error');
        });
    }

    function renderSummary(summary) {
        $('#calendarStatItems').text(
            Number(summary.items || 0)
        );

        $('#calendarStatAmount').text(
            money(summary.amount || 0)
        );

        $('#calendarStatToday').text(
            Number(summary.today || 0)
        );

        $('#calendarStatOverdue').text(
            Number(summary.overdue || 0)
        );
    }

    function renderHeader(range) {
        if (state.view === 'week') {
            const start = range.start
                ? parseLocalDate(range.start)
                : parseLocalDate(state.weekDate);

            const end = range.end
                ? parseLocalDate(range.end)
                : parseLocalDate(state.weekDate);

            $('#calendarMonthTitle').text(
                `${date(isoDate(start))} – ${date(isoDate(end))}`
            );

            return;
        }

        $('#calendarMonthTitle').text(
            monthLabel(state.cursor)
        );
    }

    function itemsForDate(iso) {
        return state.items.filter(function (item) {
            return item.due_date === iso;
        });
    }

    function renderMonth() {
        const year = state.cursor.getFullYear();
        const month = state.cursor.getMonth();

        const first = new Date(year, month, 1);
        const last = new Date(year, month + 1, 0);

        const startOffset = (
            first.getDay() + 6
        ) % 7;

        const totalDays = last.getDate();

        const previousMonthDays = new Date(
            year,
            month,
            0
        ).getDate();

        const cells = [];

        for (let i = startOffset - 1; i >= 0; i--) {
            cells.push({
                date: new Date(
                    year,
                    month - 1,
                    previousMonthDays - i
                ),
                other: true,
            });
        }

        for (let day = 1; day <= totalDays; day++) {
            cells.push({
                date: new Date(year, month, day),
                other: false,
            });
        }

        while (cells.length < 42) {
            const day = cells.length - (
                startOffset + totalDays
            ) + 1;

            cells.push({
                date: new Date(
                    year,
                    month + 1,
                    day
                ),
                other: true,
            });
        }

        const today = config.today
            || isoDate(new Date());

        let html = `
            <div class="calendar-month-grid">
                ${[
                    'Monday',
                    'Tuesday',
                    'Wednesday',
                    'Thursday',
                    'Friday',
                    'Saturday',
                    'Sunday'
                ].map(function (day) {
                    return `
                        <div class="calendar-weekday">
                            ${day}
                        </div>
                    `;
                }).join('')}
        `;

        cells.forEach(function (cell) {
            const iso = isoDate(cell.date);
            const items = itemsForDate(iso);
            const isToday = iso === today;

            let eventsHtml = '';

            items.slice(0, 3).forEach(function (item) {
                eventsHtml += eventHtml(item);
            });

            if (items.length > 3) {
                eventsHtml += `
                    <button
                        type="button"
                        class="event-more"
                        data-calendar-date="${esc(iso)}"
                    >
                        +${items.length - 3} more
                    </button>
                `;
            }

            html += `
                <div class="calendar-day
                    ${cell.other ? 'other-month' : ''}
                    ${isToday ? 'today' : ''}
                ">
                    <div class="calendar-day-number">
                        ${cell.date.getDate()}
                    </div>
                    ${eventsHtml || ''}
                </div>
            `;
        });

        html += '</div>';

        $('#calendarContent').html(html);
    }

    function eventHtml(item) {
        const status = item.status_key || 'upcoming';

        return `
            <button
                type="button"
                class="calendar-event event-${esc(status)}"
                data-calendar-item="${esc(item.id)}"
                title="${esc(item.title || '')}"
            >
                <span class="event-icon">
                    ${typeIcon(item)}
                </span>

                <span class="event-content">
                    <span class="event-title">
                        ${esc(item.title || '-')}
                    </span>

                    <span class="event-meta">
                        ${esc(item.loan?.account_no || '')}
                        ${item.balance_amount
                            ? ` · ${esc(money(item.balance_amount))}`
                            : ''}
                    </span>
                </span>
            </button>
        `;
    }

    function renderWeek() {
        const anchor = parseLocalDate(
            state.weekDate
        );

        const monday = new Date(anchor);

        monday.setDate(
            anchor.getDate()
            - ((anchor.getDay() + 6) % 7)
        );

        let html = `
            <div class="calendar-week-grid">
        `;

        for (let index = 0; index < 7; index++) {
            const current = new Date(monday);

            current.setDate(
                monday.getDate() + index
            );

            const iso = isoDate(current);
            const items = itemsForDate(iso);
            const isToday = iso === (
                config.today || isoDate(new Date())
            );

            html += `
                <div class="calendar-week-column">
                    <div class="calendar-week-head ${isToday ? 'text-danger' : ''}">
                        ${current.toLocaleString(
                            'en-GB',
                            { weekday: 'long' }
                        )}
                        <span class="text-muted ms-1">
                            ${date(iso)}
                        </span>
                    </div>

                    ${
                        items.length
                            ? items.map(eventHtml).join('')
                            : `
                                <div class="small text-muted text-center pt-5">
                                    No dues
                                </div>
                            `
                    }
                </div>
            `;
        }

        html += '</div>';

        $('#calendarContent').html(html);
    }

    function renderList() {
        if (!state.items.length) {
            $('#calendarContent').html(`
                <div class="calendar-empty">
                    <div class="calendar-empty-icon">
                        <i class="mdi mdi-calendar-blank-outline"></i>
                    </div>
                    <div class="fw-bold text-dark">
                        No schedule items found
                    </div>
                    <div class="small mt-1">
                        There are no obligations in the selected range with these filters.
                    </div>
                </div>
            `);

            return;
        }

        let html = `
            <div class="calendar-agenda-wrap">
                <table class="calendar-agenda-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Obligation</th>
                            <th>Loan / Account</th>
                            <th>Lender</th>
                            <th class="text-end">Amount</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        state.items.forEach(function (item) {
            html += `
                <tr>
                    <td>
                        <div class="agenda-date">
                            ${esc(date(item.due_date))}
                        </div>

                        ${
                            item.installment_no
                                ? `<div class="small text-muted">
                                    EMI #${esc(item.installment_no)}
                                </div>`
                                : ''
                        }
                    </td>

                    <td>
                        <span class="agenda-type">
                            ${typeIcon(item)}
                            ${esc(item.loan?.loan_type_name || item.obligation_type || '-')}
                        </span>
                    </td>

                    <td>
                        <div class="fw-bold">
                            ${esc(item.title || '-')}
                        </div>
                    </td>

                    <td>
                        <div class="fw-bold text-dark">
                            ${esc(item.loan?.account_no || '-')}
                        </div>
                        <div class="small text-muted">
                            ${esc(item.loan?.title || '')}
                        </div>
                    </td>

                    <td>
                        ${esc(item.loan?.lender_name || '-')}
                    </td>

                    <td class="text-end fw-bold">
                        ${money(item.balance_amount || 0)}
                    </td>

                    <td>
                        ${statusBadge(item.status_key)}
                    </td>

                    <td class="text-center">
                        <button
                            type="button"
                            class="btn btn-sm btn-outline-danger"
                            data-calendar-item="${esc(item.id)}"
                        >
                            Details
                        </button>
                    </td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        $('#calendarContent').html(html);
    }

    function findItem(id) {
        return state.items.find(function (item) {
            return String(item.id) === String(id);
        });
    }

    function openDetail(id) {
        const item = findItem(id);

        if (!item) {
            return;
        }

        state.activeItem = item;

        $('#calendarDetailTitle').text(
            item.title || 'Obligation Details'
        );

        $('#calendarDetailSubtitle').text(
            [
                item.loan?.lender_name,
                item.loan?.account_no,
                date(item.due_date)
            ].filter(Boolean).join(' · ')
        );

        $('#calendarDetailBody').html(`
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Due Date
                        </div>
                        <div class="detail-stat-value">
                            ${esc(date(item.due_date))}
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Amount Due
                        </div>
                        <div class="detail-stat-value">
                            ${money(item.balance_amount || 0)}
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Status
                        </div>
                        <div class="mt-2">
                            ${statusBadge(item.status_key)}
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border">
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Loan / Account
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.loan?.account_no || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Lender
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.loan?.lender_name || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Obligation Type
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.obligation_type || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Principal
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.principal_amount || 0)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Interest
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.interest_amount || 0)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Closing Balance
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.closing_balance || 0)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);

        toggleDetailActions(item);

        detailModal = detailModal || safeModal('#calendarDetailModal');

        if (detailModal) {
            detailModal.show();
        }
    }

    function toggleDetailActions(item) {
        const canPay = (
            Number(item.balance_amount || 0) > 0
            && !['paid'].includes(item.status_key)
        );

        $('#calendarPaymentBtn').prop(
            'disabled',
            !canPay
        );

        $('#calendarPaymentBtn').toggle(
            canPay
        );

        $('#calendarSnoozeBtn').toggle(
            !['paid', 'overdue'].includes(item.status_key)
        );

        $('#calendarOpenLoanBtn').prop(
            'disabled',
            !item.loan?.id
        );
    }

    function openPayment() {
        const item = state.activeItem;

        if (!item || !item.loan?.id) {
            return;
        }

        $('#calendarPaymentObligationId').val(
            item.id
        );

        $('#calendarPaymentLoanId').val(
            item.loan.id
        );

        $('#calendarPaymentObligationTitle').text(
            item.title || '-'
        );

        $('#calendarPaymentObligationMeta').text(
            `${item.loan.account_no || ''} · ${item.loan.lender_name || ''} · Due ${date(item.due_date)}`
        );

        $('#calendarPaymentAmount').val(
            Number(item.balance_amount || 0).toFixed(2)
        );

        $('#calendarPaymentBalanceHelp').text(
            `Outstanding against this item: ${money(item.balance_amount || 0)}`
        );

        $('#calendarPaymentDate').val(
            config.today || isoDate(new Date())
        );

        $('#calendarPaymentMode').val('NACH');
        $('#calendarPaymentReference').val('');
        $('#calendarPaymentAccount').val('');
        $('#calendarPaymentPrincipal').val(
            Number(item.principal_amount || 0).toFixed(2)
        );
        $('#calendarPaymentInterest').val(
            Number(item.interest_amount || 0).toFixed(2)
        );
        $('#calendarPaymentPenal').val('0');
        $('#calendarPaymentBounce').val('0');
        $('#calendarPaymentNotes').val('');
        $('#calendarPaymentError').text('');

        paymentModal = paymentModal || safeModal('#calendarPaymentModal');

        if (detailModal) {
            detailModal.hide();
        }

        setTimeout(function () {
            if (paymentModal) {
                paymentModal.show();
            }
        }, 180);
    }

    function submitPayment(event) {
        event.preventDefault();

        const item = state.activeItem;

        if (!item || !item.loan?.id) {
            return;
        }

        const saveButton = $('#calendarPaymentSaveBtn');

        saveButton.prop('disabled', true);

        $('.payment-save-text').addClass('d-none');
        $('.payment-save-loading').removeClass('d-none');
        $('#calendarPaymentError').text('');

        $.ajax({
            url: url(routes.payment, item.loan.id),
            type: 'POST',
            data: {
                _token: config.csrf || '',
                obligation_id: $('#calendarPaymentObligationId').val(),
                payment_type: 'regular',
                payment_date: $('#calendarPaymentDate').val(),
                amount: $('#calendarPaymentAmount').val(),
                principal_amount: $('#calendarPaymentPrincipal').val(),
                interest_amount: $('#calendarPaymentInterest').val(),
                penal_interest: $('#calendarPaymentPenal').val(),
                bounce_charge: $('#calendarPaymentBounce').val(),
                mode: $('#calendarPaymentMode').val(),
                reference_no: $('#calendarPaymentReference').val(),
                pay_from_account: $('#calendarPaymentAccount').val(),
                notes: $('#calendarPaymentNotes').val(),
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Payment recorded successfully.',
                'success'
            );

            if (paymentModal) {
                paymentModal.hide();
            }

            setTimeout(
                loadCalendar,
                250
            );
        })
        .fail(function (xhr) {
            const response = xhr.responseJSON || {};

            $('#calendarPaymentError').text(
                response.message
                || 'Unable to save payment.'
            );

            toast(
                response.message
                || 'Unable to save payment.',
                'error'
            );
        })
        .always(function () {
            saveButton.prop(
                'disabled',
                false
            );

            $('.payment-save-text').removeClass('d-none');
            $('.payment-save-loading').addClass('d-none');
        });
    }

    function openSnooze() {
        if (!state.activeItem) {
            return;
        }

        const base = new Date();

        base.setMinutes(
            base.getMinutes() + 60
        );

        const local = new Date(
            base.getTime()
            - base.getTimezoneOffset() * 60000
        );

        $('#calendarSnoozeUntil').val(
            local.toISOString().slice(0, 16)
        );

        $('#calendarSnoozeError').text('');

        snoozeModal = snoozeModal || safeModal('#calendarSnoozeModal');

        if (detailModal) {
            detailModal.hide();
        }

        setTimeout(function () {
            if (snoozeModal) {
                snoozeModal.show();
            }
        }, 180);
    }

    function submitSnooze(event) {
        event.preventDefault();

        if (!state.activeItem) {
            return;
        }

        const until = $('#calendarSnoozeUntil').val();

        $.ajax({
            url: url(
                routes.snooze,
                state.activeItem.id
            ),
            type: 'POST',
            data: {
                _token: config.csrf || '',
                snoozed_until: until,
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Reminder snoozed.',
                'success'
            );

            if (snoozeModal) {
                snoozeModal.hide();
            }

            setTimeout(
                loadCalendar,
                250
            );
        })
        .fail(function (xhr) {
            const response = xhr.responseJSON || {};

            $('#calendarSnoozeError').text(
                response.message
                || 'Unable to snooze reminder.'
            );
        });
    }

    function navigate(direction) {
        if (state.view === 'week') {
            const dateValue = parseLocalDate(
                state.weekDate
            );

            dateValue.setDate(
                dateValue.getDate() + (
                    direction * 7
                )
            );

            state.weekDate = isoDate(dateValue);
            state.cursor = new Date(
                dateValue.getFullYear(),
                dateValue.getMonth(),
                1
            );
        } else {
            state.cursor = new Date(
                state.cursor.getFullYear(),
                state.cursor.getMonth() + direction,
                1
            );

            state.weekDate = isoDate(
                state.cursor
            );
        }

        loadCalendar();
    }

    function goToday() {
        const now = new Date();

        state.cursor = new Date(
            now.getFullYear(),
            now.getMonth(),
            1
        );

        state.weekDate = isoDate(now);

        loadCalendar();
    }

    function bindEvents() {
        $('#calendarPrevBtn').on(
            'click',
            function () {
                navigate(-1);
            }
        );

        $('#calendarNextBtn').on(
            'click',
            function () {
                navigate(1);
            }
        );

        $('#calendarTodayBtn').on(
            'click',
            goToday
        );

        $('[data-calendar-view]').on(
            'click',
            function () {
                state.view = $(this).data('calendar-view');

                $('[data-calendar-view]')
                    .removeClass('active');

                $(this).addClass('active');

                loadCalendar();
            }
        );

        $('#calendarEntityFilter').on(
            'change',
            function () {
                state.entityId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarTypeFilter').on(
            'change',
            function () {
                state.typeId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarLenderFilter').on(
            'change',
            function () {
                state.lenderId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarStatusFilter').on(
            'change',
            function () {
                state.status = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarClearSearch').on(
            'click',
            function () {
                $('#calendarSearch').val('');
                state.search = '';
                loadCalendar();
            }
        );

        let searchTimer = null;

        $('#calendarSearch').on(
            'input',
            function () {
                clearTimeout(searchTimer);

                state.search = $.trim(
                    $(this).val()
                );

                searchTimer = setTimeout(
                    loadCalendar,
                    350
                );
            }
        );

        $(document).on(
            'click',
            '[data-calendar-item]',
            function () {
                openDetail(
                    $(this).data('calendar-item')
                );
            }
        );

        $(document).on(
            'click',
            '[data-calendar-date]',
            function () {
                const iso = $(this).data('calendar-date');
                const items = itemsForDate(iso);

                if (items.length) {
                    openDetail(items[0].id);
                }
            }
        );

        $('#calendarPaymentBtn').on(
            'click',
            openPayment
        );

        $('#calendarPaymentForm').on(
            'submit',
            submitPayment
        );

        $('#calendarSnoozeBtn').on(
            'click',
            openSnooze
        );

        $('#calendarSnoozeForm').on(
            'submit',
            submitSnooze
        );

        $('#calendarOpenLoanBtn').on(
            'click',
            function () {
                if (state.activeItem?.loan?.id) {
                    window.location.href = url(
                        routes.show,
                        state.activeItem.loan.id
                    );
                }
            }
        );
    }

    function init() {
        detailModal = safeModal(
            '#calendarDetailModal'
        );

        paymentModal = safeModal(
            '#calendarPaymentModal'
        );

        snoozeModal = safeModal(
            '#calendarSnoozeModal'
        );

        bindEvents();

        fetchLookups().always(
            loadCalendar
        );
    }

    $(function () {
        init();
    });

})(jQuery);
