(function ($) {
    'use strict';

    const config = window.LoanSchedulePageConfig || {};
    const routes = window.LoanScheduleRoutes || {};

    if (!routes.data || document.getElementById('loanSchedulePage') === null) {
        return;
    }

    let loanModal = null;
    let viewModal = null;
    let returnModal = null;

    const state = {
        page: 1,
        perPage: Number(config.initialPerPage || 25),
        type: '',
        status: '',
        entityId: '',
        lenderId: '',
        search: '',
        loanTypeId: '',
        lookupsLoaded: false,
        currentLoanId: null,
        currentRequest: null,
        trancheIndex: 0,
        jewelIndex: 0,
    };

    function safeModal(selector) {
        const el = document.querySelector(selector);

        if (!el || !window.bootstrap || !bootstrap.Modal) {
            return null;
        }

        return bootstrap.Modal.getOrCreateInstance(el);
    }

    function esc(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function url(template, id) {
        return String(template || '').replace(
            '__ID__',
            encodeURIComponent(String(id))
        );
    }

    function money(value) {
        const number = Number(value || 0);

        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2,
        }).format(number);
    }

    function date(value) {
        if (!value) {
            return '-';
        }

        const parts = String(value).split('-');

        if (parts.length !== 3) {
            return value;
        }

        return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }

    function toast(message, type = 'success') {
        const toastEl = document.getElementById('loanToast');
        const bodyEl = document.getElementById('loanToastBody');

        if (!toastEl || !bodyEl) {
            return;
        }

        toastEl.classList.remove(
            'text-bg-success',
            'text-bg-danger',
            'text-bg-warning',
            'text-bg-info'
        );

        const classMap = {
            success: 'text-bg-success',
            error: 'text-bg-danger',
            danger: 'text-bg-danger',
            warning: 'text-bg-warning',
            info: 'text-bg-info',
        };

        toastEl.classList.add(
            classMap[type] || classMap.success
        );

        bodyEl.textContent = message || 'Completed.';

        if (window.bootstrap && bootstrap.Toast) {
            bootstrap.Toast.getOrCreateInstance(toastEl, {
                delay: 3500
            }).show();
        }
    }

    function setLoading(button, loading) {
        const $button = $(button);

        $button.prop('disabled', loading);

        $button
            .find('.loan-save-text')
            .toggleClass('d-none', loading);

        $button
            .find('.loan-save-loading')
            .toggleClass('d-none', !loading);
    }

    function clearErrors() {
        $('.loan-error[data-error]').text('');
        $('#loanFormAlert').addClass('d-none').empty();
    }

    function applyErrors(errors) {
        clearErrors();

        if (!errors || typeof errors !== 'object') {
            return;
        }

        Object.keys(errors).forEach(function (field) {
            const message = Array.isArray(errors[field])
                ? errors[field][0]
                : errors[field];

            $(`.loan-error[data-error="${CSS.escape(field)}"]`)
                .text(message || 'Invalid value.');
        });

        const firstField = Object.keys(errors)[0];

        if (firstField) {
            const input = document.getElementById(
                firstField === 'loan_type_id'
                    ? 'loanTypeId'
                    : firstField
            );

            if (input) {
                input.focus();
            }
        }
    }

    function handleAjaxError(xhr, fallback) {
        let message = fallback || 'Unable to complete the request.';
        let payload = null;

        try {
            payload = xhr.responseJSON
                || JSON.parse(xhr.responseText || '{}');
        } catch (e) {
            payload = null;
        }

        if (payload && payload.message) {
            message = payload.message;
        }

        if (payload && payload.errors) {
            applyErrors(payload.errors);
        }

        toast(message, 'error');
    }

    function loadLookups() {
        if (state.lookupsLoaded) {
            return $.Deferred().resolve().promise();
        }

        return $.ajax({
            url: routes.lookups,
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        }).done(function (response) {
            if (!response || Number(response.status) !== 200) {
                return;
            }

            const data = response.data || {};

            renderEntities(data.entities || []);
            renderLenders(data.lenders || []);

            const types = data.types || [];

            $('#loanTypeId').data('types', types);
            state.lookupsLoaded = true;
        }).fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to load entity, lender and loan type masters.'
            );
        });
    }

    function renderEntities(items) {
        const $filter = $('#loanEntityFilter');
        const $form = $('#loanEntityId');

        let filterHtml = '<option value="">All Entities</option>';
        let formHtml = '<option value="">Select Entity</option>';

        items.forEach(function (item) {
            const id = item.id ?? item.sno;
            const name = item.name ?? item.entity_name ?? '-';

            filterHtml += `
                <option value="${esc(id)}">${esc(name)}</option>
            `;

            formHtml += `
                <option value="${esc(id)}">${esc(name)}</option>
            `;
        });

        $filter.html(filterHtml);
        $form.html(formHtml);

        $filter.val(state.entityId || '');
        $form.val($('#loanEntityId').val() || '');
    }

    function renderLenders(items) {
        const $filter = $('#loanLenderFilter');
        const $form = $('#loanLenderId');

        let filterHtml = '<option value="">All Lenders</option>';
        let formHtml = '<option value="">Select Lender</option>';

        items.forEach(function (item) {
            const id = item.id ?? item.sno;
            const name = item.lender_name ?? item.name ?? '-';
            const branch = item.branch_name
                ? ` — ${item.branch_name}`
                : '';

            filterHtml += `
                <option value="${esc(id)}">${esc(name)}${esc(branch)}</option>
            `;

            formHtml += `
                <option value="${esc(id)}">${esc(name)}${esc(branch)}</option>
            `;
        });

        $filter.html(filterHtml);
        $form.html(formHtml);
        $filter.val(state.lenderId || '');
    }

    function refreshList(page = 1) {
        state.page = page;

        const params = {
            page: state.page,
            per_page: state.perPage,
            type: state.type,
            status: state.status,
            entity_id: state.entityId,
            lender_id: state.lenderId,
            search: state.search,
        };

        $('#loanTableBody').html(`
            <tr>
                <td colspan="10">
                    <div class="loan-loading">
                        <div class="spinner-border text-danger mb-2"></div>
                        <div class="fw-semibold">
                            Loading loan register...
                        </div>
                    </div>
                </td>
            </tr>
        `);

        $('#loanResultMeta').text('Loading...');
        $('#loanPaginationMeta').text('');
        $('#loanPagination').empty();

        if (state.currentRequest && state.currentRequest.readyState !== 4) {
            state.currentRequest.abort();
        }

        state.currentRequest = $.ajax({
            url: routes.data,
            type: 'GET',
            data: params,
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response || Number(response.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to load loans.'
                );
            }

            renderSummary(response.summary || {});
            renderTable(response.data?.data || []);
            renderPagination(response.pagination || {});
        })
        .fail(function (xhr, statusText) {
            if (statusText === 'abort') {
                return;
            }

            $('#loanTableBody').html(`
                <tr>
                    <td colspan="10">
                        <div class="loan-empty">
                            <div class="loan-empty-icon">
                                <i class="mdi mdi-alert-circle-outline"></i>
                            </div>
                            <div class="fw-bold text-dark">
                                Unable to load loans
                            </div>
                            <div class="small mt-1">
                                Please try again.
                            </div>
                            <button
                                type="button"
                                class="btn loan-primary-btn btn-sm mt-3"
                                onclick="window.LoanScheduleReload()"
                            >
                                Retry
                            </button>
                        </div>
                    </td>
                </tr>
            `);

            handleAjaxError(
                xhr,
                'Unable to load loan register.'
            );
        });
    }

    function renderSummary(summary) {
        $('#loanKpiOutstanding').text(
            money(summary.total_outstanding || 0)
        );

        $('#loanKpiOutstandingMeta').text(
            `${Number(summary.active_loans || 0)} active loan(s)`
        );

        $('#loanKpiDue').text(
            Number(summary.due_this_week_count || 0)
        );

        $('#loanKpiDueMeta').text(
            `${money(summary.due_this_week_amount || 0)} due this week`
        );

        $('#loanKpiOverdue').text(
            Number(summary.overdue_count || 0)
        );

        $('#loanKpiOverdueMeta').text(
            `${money(summary.overdue_amount || 0)} overdue balance`
        );

        const watch =
            Number(summary.renewals_60_days || 0)
            + Number(summary.redemptions_30_days || 0);

        $('#loanKpiWatch').text(watch);

        $('#loanKpiWatchMeta').text(
            `${Number(summary.renewals_60_days || 0)} renewals · ` +
            `${Number(summary.redemptions_30_days || 0)} redemptions`
        );
    }

    function statusBadge(status) {
        const map = {
            active: ['Active', 'status-active'],
            pending_approval: ['Pending Approval', 'status-pending'],
            returned: ['Returned', 'status-returned'],
            closed: ['Closed', 'status-closed'],
            foreclosed: ['Foreclosed', 'status-closed'],
            restructured: ['Restructured', 'status-active'],
            overdue: ['Overdue', 'status-overdue'],
            today: ['Due Today', 'status-today'],
            upcoming: ['Upcoming', 'status-upcoming'],
            paid: ['Paid', 'status-paid'],
        };

        const item = map[status] || [status || '-', 'status-closed'];

        return `
            <span class="loan-status ${item[1]}">
                <span>●</span>
                ${esc(item[0])}
            </span>
        `;
    }

    function dueBadge(item) {
        if (!item.next_due) {
            return '<span class="text-muted">No pending due</span>';
        }

        let days = Number(item.days_to_due);

        let cls = 'normal';
        let label = `${days} day(s)`;

        if (Number.isFinite(days)) {
            if (days < 0) {
                cls = 'danger';
                label = `${Math.abs(days)} day(s) overdue`;
            } else if (days === 0) {
                cls = 'warn';
                label = 'Due today';
            } else if (days <= 7) {
                cls = 'warn';
            }
        }

        return `
            <div class="d-flex flex-column align-items-start gap-1">
                <span class="fw-semibold">${esc(date(item.next_due))}</span>
                <span class="loan-days-pill ${cls}">
                    ${esc(label)}
                </span>
            </div>
        `;
    }

    function renderTable(items) {
        if (!items.length) {
            $('#loanTableBody').html(`
                <tr>
                    <td colspan="10">
                        <div class="loan-empty">
                            <div class="loan-empty-icon">
                                <i class="mdi mdi-bank-outline"></i>
                            </div>
                            <div class="fw-bold text-dark">
                                No loans found
                            </div>
                            <div class="small mt-1">
                                Try changing your filters or add a new loan.
                            </div>
                            <button
                                type="button"
                                class="btn loan-primary-btn btn-sm mt-3"
                                id="loanEmptyAddBtn"
                            >
                                <i class="mdi mdi-plus me-1"></i>
                                Add Loan
                            </button>
                        </div>
                    </td>
                </tr>
            `);

            $('#loanEmptyAddBtn').off('click').on('click', openCreateModal);
            return;
        }

        let html = '';

        items.forEach(function (item) {
            const tenure = item.tenure_total
                ? `
                    <div class="loan-progress">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>${esc(item.tenure_paid)} / ${esc(item.tenure_total)}</span>
                            <span>${esc(item.tenure_percent)}%</span>
                        </div>
                        <div class="loan-progress-track">
                            <div
                                class="loan-progress-bar"
                                style="width:${Math.max(0, Math.min(100, Number(item.tenure_percent || 0)))}%"
                            ></div>
                        </div>
                    </div>
                `
                : '<span class="text-muted">-</span>';

            const entityText = item.entity_id
                ? getEntityName(item.entity_id)
                : '-';

            let actions = `
                <div class="d-flex justify-content-center gap-1">
                    <button
                        type="button"
                        class="loan-action-btn"
                        title="View loan"
                        data-loan-view="${esc(item.id)}"
                    >
                        <i class="mdi mdi-eye-outline"></i>
                    </button>
            `;

            if (
                ['draft', 'returned', 'pending_approval'].includes(item.status)
            ) {
                actions += `
                    <button
                        type="button"
                        class="loan-action-btn"
                        title="Edit loan"
                        data-loan-edit="${esc(item.id)}"
                    >
                        <i class="mdi mdi-pencil-outline"></i>
                    </button>
                `;
            }

            if (item.status === 'pending_approval') {
                actions += `
                    <button
                        type="button"
                        class="loan-action-btn text-success"
                        title="Approve"
                        data-loan-approve="${esc(item.id)}"
                    >
                        <i class="mdi mdi-check-circle-outline"></i>
                    </button>
                    <button
                        type="button"
                        class="loan-action-btn text-danger"
                        title="Return to maker"
                        data-loan-return="${esc(item.id)}"
                    >
                        <i class="mdi mdi-undo-variant"></i>
                    </button>
                `;
            }

            actions += '</div>';

            html += `
                <tr data-loan-row="${esc(item.id)}">
                    <td>
                        <div class="loan-account">
                            ${esc(item.account_no || '-')}
                        </div>
                        <div class="loan-name">
                            ${esc(item.title || '-')}
                        </div>
                    </td>

                    <td>
                        <span class="loan-type-badge">
                            <i class="mdi ${esc(item.loan_type_icon || 'mdi-bank-outline')}"></i>
                            ${esc(item.loan_type_name || item.loan_type || '-')}
                        </span>
                    </td>

                    <td>
                        <div class="fw-semibold">
                            ${esc(entityText)}
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold">
                            ${esc(item.lender_name || '-')}
                        </div>
                        <div class="loan-muted">
                            ${esc(item.branch_name || '')}
                        </div>
                    </td>

                    <td class="text-end">
                        <span class="fw-bold">
                            ${money(item.outstanding_amount || 0)}
                        </span>
                    </td>

                    <td class="text-end">
                        <span class="fw-semibold">
                            ${money(item.next_due_amount || item.emi_amount || 0)}
                        </span>
                    </td>

                    <td>
                        ${dueBadge(item)}
                    </td>

                    <td>
                        ${tenure}
                    </td>

                    <td>
                        ${statusBadge(item.status)}
                    </td>

                    <td>
                        ${actions}
                    </td>
                </tr>
            `;
        });

        $('#loanTableBody').html(html);
    }

    function renderPagination(meta) {
        const current = Number(meta.current_page || 1);
        const last = Number(meta.last_page || 1);
        const total = Number(meta.total || 0);
        const perPage = Number(meta.per_page || state.perPage);

        const from = total === 0
            ? 0
            : ((current - 1) * perPage) + 1;

        const to = Math.min(current * perPage, total);

        $('#loanResultMeta').text(
            `${total} loan(s)`
        );

        $('#loanPaginationMeta').text(
            total ? `Showing ${from}–${to} of ${total}` : 'No results'
        );

        let html = '';

        if (last <= 1) {
            $('#loanPagination').html('');
            return;
        }

        html += `
            <li class="page-item ${current <= 1 ? 'disabled' : ''}">
                <button
                    class="page-link"
                    type="button"
                    data-loan-page="${current - 1}"
                    ${current <= 1 ? 'disabled' : ''}
                >
                    Previous
                </button>
            </li>
        `;

        const start = Math.max(1, current - 2);
        const end = Math.min(last, current + 2);

        if (start > 1) {
            html += `
                <li class="page-item">
                    <button class="page-link" data-loan-page="1">1</button>
                </li>
            `;

            if (start > 2) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }
        }

        for (let page = start; page <= end; page++) {
            html += `
                <li class="page-item ${page === current ? 'active' : ''}">
                    <button
                        type="button"
                        class="page-link"
                        data-loan-page="${page}"
                    >
                        ${page}
                    </button>
                </li>
            `;
        }

        if (end < last) {
            if (end < last - 1) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }

            html += `
                <li class="page-item">
                    <button
                        type="button"
                        class="page-link"
                        data-loan-page="${last}"
                    >
                        ${last}
                    </button>
                </li>
            `;
        }

        html += `
            <li class="page-item ${current >= last ? 'disabled' : ''}">
                <button
                    class="page-link"
                    type="button"
                    data-loan-page="${current + 1}"
                    ${current >= last ? 'disabled' : ''}
                >
                    Next
                </button>
            </li>
        `;

        $('#loanPagination').html(html);
    }

    function getEntityName(id) {
        const value = String(id || '');
        const option = $('#loanEntityFilter option[value="' + CSS.escape(value) + '"]');

        return option.length
            ? option.text()
            : '-';
    }

    function getTypeById(id) {
        const types = $('#loanTypeId').data('types') || [];

        return types.find(function (item) {
            return String(item.id) === String(id);
        });
    }

    function resetForm() {
        const form = document.getElementById('loanForm');

        if (form) {
            form.reset();
        }

        $('#loanId').val('');
        $('#loanTypeId').val('');
        $('#loanEntityId').val('');
        $('#loanLenderId').val('');
        $('#loanInterestType').val('reducing');
        $('#loanMoratorium').val('0');
        $('#loanVehicleHypothecated').prop('checked', true);

        $('#loanTypeCards [data-loan-type-card]')
            .removeClass('active');

        $('#loanVehiclePanel, #loanTermPanel, #loanJewelPanel, #loanCcPanel')
            .addClass('d-none');

        $('#loanNoTypePanel').removeClass('d-none');

        $('#loanTrancheRows').empty();
        $('#loanJewelRows').empty();

        state.trancheIndex = 0;
        state.jewelIndex = 0;

        clearErrors();

        addTrancheRow();
        addJewelRow();
    }

    function openCreateModal() {
        resetForm();

        $('#loanFormModalTitle').text('Add Loan');

        loanModal = loanModal || safeModal('#loanFormModal');

        if (loanModal) {
            loanModal.show();
        }
    }

    function activateType(typeCode, typeId) {
        $('#loanTypeId').val(typeId || '');

        $('#loanTypeCards [data-loan-type-card]')
            .removeClass('active');

        $(`[data-loan-type-card="${CSS.escape(typeCode)}"]`)
            .addClass('active');

        $('#loanVehiclePanel, #loanTermPanel, #loanJewelPanel, #loanCcPanel, #loanNoTypePanel')
            .addClass('d-none');

        if (typeCode === 'vehicle') {
            $('#loanVehiclePanel').removeClass('d-none');
        } else if (typeCode === 'term') {
            $('#loanTermPanel').removeClass('d-none');
        } else if (typeCode === 'jewel') {
            $('#loanJewelPanel').removeClass('d-none');
        } else if (typeCode === 'cc') {
            $('#loanCcPanel').removeClass('d-none');
        } else {
            $('#loanNoTypePanel').removeClass('d-none');
        }
    }

    function addTrancheRow(data = {}) {
        const index = state.trancheIndex++;

        $('#loanTrancheRows').append(`
            <tr data-tranche-row="${index}">
                <td class="fw-bold">
                    ${index + 1}
                </td>

                <td>
                    <input
                        type="date"
                        class="form-control form-control-sm"
                        name="tranches[${index}][disbursed_date]"
                        value="${esc(data.disbursed_date || '')}"
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        class="form-control form-control-sm"
                        name="tranches[${index}][amount]"
                        value="${esc(data.amount || '')}"
                        placeholder="0.00"
                    >
                </td>

                <td>
                    <input
                        type="text"
                        maxlength="500"
                        class="form-control form-control-sm"
                        name="tranches[${index}][remarks]"
                        value="${esc(data.remarks || '')}"
                        placeholder="Optional"
                    >
                </td>

                <td class="text-center">
                    <button
                        type="button"
                        class="btn btn-sm btn-light text-danger"
                        data-remove-tranche="${index}"
                        title="Remove"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </td>
            </tr>
        `);
    }

    function addJewelRow(data = {}) {
        const index = state.jewelIndex++;

        $('#loanJewelRows').append(`
            <tr data-jewel-row="${index}">
                <td class="fw-bold">
                    ${index + 1}
                </td>

                <td>
                    <input
                        type="text"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][description]"
                        value="${esc(data.description || '')}"
                        placeholder="Chain / Ring / Bangle..."
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.001"
                        min="0"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][gross_weight]"
                        value="${esc(data.gross_weight || '')}"
                        placeholder="0.000"
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.001"
                        min="0"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][net_weight]"
                        value="${esc(data.net_weight || '')}"
                        placeholder="0.000"
                    >
                </td>

                <td>
                    <input
                        type="text"
                        maxlength="30"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][purity]"
                        value="${esc(data.purity || '')}"
                        placeholder="22K"
                    >
                </td>

                <td class="text-center">
                    <button
                        type="button"
                        class="btn btn-sm btn-light text-danger"
                        data-remove-jewel="${index}"
                        title="Remove"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </td>
            </tr>
        `);
    }

    function fillForm(loan) {
        resetForm();

        $('#loanId').val(loan.id || '');
        $('#loanFormModalTitle').text('Edit Loan');

        $('#loanEntityId').val(loan.entity_id || '');
        $('#loanLenderId').val(loan.lender_id || '');
        $('#loanAccountNo').val(loan.account_no || '');
        $('#loanTitle').val(loan.title || '');
        $('#loanInterestType').val(loan.interest_type || 'reducing');
        $('#loanSanctioned').val(loan.sanctioned_amount || '');
        $('#loanDisbursed').val(loan.disbursed_amount || '');
        $('#loanOutstanding').val(loan.outstanding_amount || '');
        $('#loanRate').val(loan.interest_rate || '');
        $('#loanStartDate').val(
            loan.start_date ? String(loan.start_date).slice(0, 10) : ''
        );
        $('#loanFirstDueDate').val(
            loan.first_due_date ? String(loan.first_due_date).slice(0, 10) : ''
        );
        $('#loanTenure').val(loan.tenure_months || '');
        $('#loanEmi').val(loan.emi_amount || '');
        $('#loanMaturityDate').val(
            loan.maturity_date ? String(loan.maturity_date).slice(0, 10) : ''
        );
        $('#loanMoratorium').val(loan.moratorium_months || 0);
        $('#loanSecurity').val(loan.security_details || '');
        $('#loanRemarks').val(loan.remarks || '');

        const type = loan.loan_type || loan.type?.type_code || '';

        activateType(type, loan.loan_type_id);

        if (loan.vehicle) {
            $('#loanVehicleReg').val(
                loan.vehicle.registration_no || ''
            );
            $('#loanVehicleMake').val(
                loan.vehicle.make_model || ''
            );
            $('#loanVehicleChassis').val(
                loan.vehicle.chassis_no || ''
            );
            $('#loanVehicleEngine').val(
                loan.vehicle.engine_no || ''
            );
            $('#loanVehicleInsurance').val(
                loan.vehicle.insurance_renewal_date
                    ? String(loan.vehicle.insurance_renewal_date).slice(0, 10)
                    : ''
            );
            $('#loanVehicleHypothecated').prop(
                'checked',
                !!loan.vehicle.hypothecated_flag
            );
        }

        $('#loanTrancheRows').empty();
        state.trancheIndex = 0;

        (loan.tranches || []).forEach(addTrancheRow);

        if (!loan.tranches || !loan.tranches.length) {
            addTrancheRow();
        }

        if (loan.jewel_pledge) {
            $('#loanPledgeReceipt').val(
                loan.jewel_pledge.pledge_receipt_no || ''
            );
            $('#loanJewelInterestPattern').val(
                loan.jewel_pledge.interest_pattern || 'monthly'
            );
            $('#loanRedemptionDate').val(
                loan.jewel_pledge.redemption_due_date
                    ? String(loan.jewel_pledge.redemption_due_date).slice(0, 10)
                    : ''
            );

            $('#loanJewelRows').empty();
            state.jewelIndex = 0;

            (loan.jewel_pledge.items || []).forEach(addJewelRow);

            if (!loan.jewel_pledge.items?.length) {
                addJewelRow();
            }
        }

        if (loan.cc_facility) {
            $('#loanCcLimit').val(
                loan.cc_facility.sanctioned_limit || ''
            );
            $('#loanCcMargin').val(
                loan.cc_facility.margin_percent || ''
            );
            $('#loanCcDrawingPower').val(
                loan.cc_facility.drawing_power || ''
            );
            $('#loanCcRate').val(
                loan.cc_facility.interest_rate || ''
            );
            $('#loanCcRenewalDate').val(
                loan.cc_facility.renewal_date
                    ? String(loan.cc_facility.renewal_date).slice(0, 10)
                    : ''
            );
            $('#loanCcStockDay').val(
                loan.cc_facility.stock_statement_day || ''
            );
        }
    }

    function openEditModal(id) {
        $.ajax({
            url: url(routes.show, id),
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response?.data?.loan) {
                throw new Error('Loan information was not returned.');
            }

            fillForm(response.data.loan);

            loanModal = loanModal || safeModal('#loanFormModal');

            if (loanModal) {
                loanModal.show();
            }
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to load loan details.'
            );
        });
    }

    function submitLoanForm(event) {
        event.preventDefault();

        const form = document.getElementById('loanForm');

        if (!form) {
            return;
        }

        clearErrors();

        const typeId = $('#loanTypeId').val();

        if (!typeId) {
            applyErrors({
                loan_type_id: ['Please select a loan type.']
            });

            return;
        }

        const id = $('#loanId').val();
        const isEdit = Boolean(id);

        const formData = new FormData(form);

        if (isEdit) {
            formData.append('_method', 'PUT');
        }

        setLoading('#loanSaveBtn', true);

        $.ajax({
            url: isEdit
                ? url(routes.update, id)
                : routes.store,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response || Number(response.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to save loan.'
                );
            }

            toast(
                response.message || 'Loan saved successfully.',
                'success'
            );

            if (loanModal) {
                loanModal.hide();
            }

            refreshList(state.page);
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                isEdit
                    ? 'Unable to update loan.'
                    : 'Unable to create loan.'
            );
        })
        .always(function () {
            setLoading('#loanSaveBtn', false);
        });
    }

    function renderLoanView(loan) {
        const type = loan.loan_type_name
            || loan.loan_type
            || '-';

        const nextDue = loan.obligations?.[0];

        const html = `
            <div class="row g-3">
                <div class="col-lg-8">
                    <div class="card border h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-start justify-content-between gap-3">
                                <div>
                                    <div class="text-muted small">
                                        ${esc(type)}
                                    </div>
                                    <h5 class="fw-bold text-dark mb-1">
                                        ${esc(loan.account_no || '-')}
                                    </h5>
                                    <div class="fw-semibold">
                                        ${esc(loan.title || '-')}
                                    </div>
                                </div>
                                <div>
                                    ${statusBadge(loan.status)}
                                </div>
                            </div>

                            <hr>

                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="small text-muted">Lender</div>
                                    <div class="fw-bold">${esc(loan.lender?.lender_name || '-')}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Start Date</div>
                                    <div class="fw-bold">${esc(date(loan.start_date))}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Maturity</div>
                                    <div class="fw-bold">${esc(date(loan.maturity_date))}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Outstanding</div>
                                    <div class="fw-bold text-danger">
                                        ${money(loan.outstanding_amount)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Rate</div>
                                    <div class="fw-bold">${esc(loan.interest_rate)}%</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Tenure</div>
                                    <div class="fw-bold">
                                        ${esc(loan.tenure_months || 0)} months
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card border h-100 bg-light">
                        <div class="card-body">
                            <div class="small text-muted mb-1">
                                Next Due
                            </div>

                            <div class="fw-bold fs-5 text-dark">
                                ${esc(nextDue?.title || 'No pending due')}
                            </div>

                            <div class="mt-2 fw-semibold">
                                ${nextDue ? date(nextDue.due_date) : '-'}
                            </div>

                            <div class="mt-1 text-danger fw-bold">
                                ${nextDue ? money(nextDue.balance_amount) : ''}
                            </div>

                            <div class="mt-3">
                                ${nextDue ? statusBadge(nextDue.status_key) : ''}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border">
                        <div class="card-body">
                            <div class="fw-bold mb-3">
                                Schedule Versions
                            </div>

                            <div id="loanViewScheduleVersions">
                                ${(loan.schedules || []).length
                                    ? loan.schedules.map(function (schedule) {
                                        return `
                                            <div class="border rounded p-3 mb-2">
                                                <div class="d-flex justify-content-between gap-2">
                                                    <div>
                                                        <div class="fw-bold">
                                                            ${esc(schedule.schedule_label || '-')}
                                                        </div>
                                                        <div class="small text-muted">
                                                            ${esc(schedule.method || '-')}
                                                            · Effective ${esc(date(schedule.effective_from))}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        ${schedule.is_active
                                                            ? '<span class="badge bg-success">Active</span>'
                                                            : '<span class="badge bg-secondary">Superseded</span>'}
                                                    </div>
                                                </div>
                                            </div>
                                        `;
                                    }).join('')
                                    : '<div class="text-muted">No schedule versions yet. Finance approval generates the first schedule.</div>'
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#loanViewTitle').text(
            loan.account_no || 'Loan Details'
        );

        $('#loanViewSubtitle').text(
            `${loan.lender?.lender_name || ''} · ${type}`
        );

        $('#loanViewBody').html(html);
    }

    function openViewModal(id) {
        $('#loanViewBody').html(`
            <div class="text-center py-5">
                <div class="spinner-border text-danger"></div>
                <div class="small text-muted mt-2">
                    Loading loan details...
                </div>
            </div>
        `);

        viewModal = viewModal || safeModal('#loanViewModal');

        if (viewModal) {
            viewModal.show();
        }

        $.ajax({
            url: url(routes.show, id),
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response?.data?.loan_raw && !response?.data?.loan) {
                throw new Error('Loan details were not returned.');
            }

            const loan = response.data.loan_raw || response.data.loan;

            renderLoanView({
                ...loan,
                schedules: response.data.schedule_versions || [],
                obligations: loan.obligations || [],
            });
        })
        .fail(function (xhr) {
            $('#loanViewBody').html(`
                <div class="loan-empty">
                    Unable to load this loan.
                </div>
            `);

            handleAjaxError(
                xhr,
                'Unable to load loan details.'
            );
        });
    }

    function approveLoan(id) {
        $.ajax({
            url: url(routes.approve, id),
            type: 'POST',
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Loan approved.',
                'success'
            );

            refreshList(state.page);
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to approve loan.'
            );
        });
    }

    function openReturnModal(id) {
        $('#loanReturnId').val(id);
        $('#loanReturnRemarks').val('');
        $('#loanReturnError').text('');

        returnModal = returnModal || safeModal('#loanReturnModal');

        if (returnModal) {
            returnModal.show();
        }
    }

    function submitReturn(event) {
        event.preventDefault();

        const id = $('#loanReturnId').val();
        const remarks = $.trim(
            $('#loanReturnRemarks').val()
        );

        if (!remarks) {
            $('#loanReturnError').text(
                'Please enter the return remarks.'
            );

            return;
        }

        $.ajax({
            url: url(routes.return, id),
            type: 'POST',
            data: {
                remarks: remarks,
                _token: config.csrf || '',
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Loan returned.',
                'success'
            );

            if (returnModal) {
                returnModal.hide();
            }

            refreshList(state.page);
        })
        .fail(function (xhr) {
            $('#loanReturnError').text(
                xhr.responseJSON?.message
                || 'Unable to return the loan.'
            );

            handleAjaxError(
                xhr,
                'Unable to return the loan.'
            );
        });
    }

    function bindEvents() {
        $('#loanAddBtn').on('click', openCreateModal);

        $('#loanForm').on('submit', submitLoanForm);

        $('#loanAddTrancheBtn').on(
            'click',
            function () {
                addTrancheRow();
            }
        );

        $('#loanAddJewelBtn').on(
            'click',
            function () {
                addJewelRow();
            }
        );

        $('[data-loan-type-card]').on(
            'click',
            function () {
                const code = $(this).data('loan-type-card');
                const type = ($('#loanTypeId').data('types') || [])
                    .find(function (item) {
                        return item.type_code === code;
                    });

                if (type) {
                    activateType(
                        type.type_code,
                        type.id
                    );
                }
            }
        );

        $('#loanEntityFilter').on(
            'change',
            function () {
                state.entityId = $(this).val();
                refreshList(1);
            }
        );

        $('#loanLenderFilter').on(
            'change',
            function () {
                state.lenderId = $(this).val();
                refreshList(1);
            }
        );

        $('#loanPerPage').on(
            'change',
            function () {
                state.perPage = Number($(this).val()) || 25;
                refreshList(1);
            }
        );

        $('#loanClearSearch').on(
            'click',
            function () {
                $('#loanSearch').val('');
                state.search = '';
                refreshList(1);
            }
        );

        let searchTimer = null;

        $('#loanSearch').on(
            'input',
            function () {
                clearTimeout(searchTimer);

                state.search = $.trim($(this).val());

                searchTimer = setTimeout(
                    function () {
                        refreshList(1);
                    },
                    350
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-type]',
            function () {
                state.type = $(this).data('loan-type') || '';

                $('[data-loan-type]')
                    .removeClass('active');

                $(this).addClass('active');

                refreshList(1);
            }
        );

        $(document).on(
            'click',
            '[data-loan-status]',
            function () {
                state.status = $(this).data('loan-status') || '';

                $('[data-loan-status]')
                    .removeClass('active');

                $(this).addClass('active');

                refreshList(1);
            }
        );

        $(document).on(
            'click',
            '[data-loan-page]',
            function () {
                const page = Number(
                    $(this).data('loan-page')
                );

                if (page >= 1) {
                    refreshList(page);
                }
            }
        );

        $(document).on(
            'click',
            '[data-loan-view]',
            function () {
                openViewModal(
                    $(this).data('loan-view')
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-edit]',
            function () {
                openEditModal(
                    $(this).data('loan-edit')
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-approve]',
            function () {
                approveLoan(
                    $(this).data('loan-approve')
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-return]',
            function () {
                openReturnModal(
                    $(this).data('loan-return')
                );
            }
        );

        $('#loanReturnForm').on(
            'submit',
            submitReturn
        );

        $(document).on(
            'click',
            '[data-remove-tranche]',
            function () {
                $(this)
                    .closest('[data-tranche-row]')
                    .remove();
            }
        );

        $(document).on(
            'click',
            '[data-remove-jewel]',
            function () {
                $(this)
                    .closest('[data-jewel-row]')
                    .remove();
            }
        );
    }

    function init() {
        loanModal = safeModal('#loanFormModal');
        viewModal = safeModal('#loanViewModal');
        returnModal = safeModal('#loanReturnModal');

        loadLookups()
            .always(function () {
                bindEvents();
                refreshList(1);
            });
    }

    window.LoanScheduleReload = function () {
        refreshList(state.page || 1);
    };

    $(function () {
        init();
    });

})(jQuery);
