<?php

use App\Http\Controllers\accounts_finance\LoanScheduleController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:web', 'throttle:120,1'])
    ->prefix('accounts_finance/loans')
    ->name('accounts_finance.loans.')
    ->group(function () {

        // -------------------------------------------------
        // Pages
        // -------------------------------------------------
        Route::get('/', [LoanScheduleController::class, 'index'])
            ->name('index');

        Route::get('/calendar', [LoanScheduleController::class, 'calendarPage'])
            ->name('calendar');

        // -------------------------------------------------
        // AJAX read endpoints
        // -------------------------------------------------
        Route::get('/data', [LoanScheduleController::class, 'data'])
            ->name('data');

        Route::get('/calendar/data', [LoanScheduleController::class, 'calendar'])
            ->name('calendar.data');

        Route::get('/lookups', [LoanScheduleController::class, 'lookups'])
            ->name('lookups');

        // Static / known paths must stay before /{loan}.
        Route::get('/{loan}/data', [LoanScheduleController::class, 'show'])
            ->whereNumber('loan')
            ->name('data.show');

        // -------------------------------------------------
        // Create / update
        // -------------------------------------------------
        Route::post('/', [LoanScheduleController::class, 'store'])
            ->name('store');

        Route::put('/{loan}', [LoanScheduleController::class, 'update'])
            ->whereNumber('loan')
            ->name('update');

        // -------------------------------------------------
        // Loan detail page
        // -------------------------------------------------
        Route::get('/{loan}', [LoanScheduleController::class, 'detail'])
            ->whereNumber('loan')
            ->name('show');

        // -------------------------------------------------
        // Maker / Checker
        // -------------------------------------------------
        Route::post('/{loan}/approve', [LoanScheduleController::class, 'approve'])
            ->whereNumber('loan')
            ->name('approve');

        Route::post('/{loan}/return', [LoanScheduleController::class, 'reject'])
            ->whereNumber('loan')
            ->name('return');

        // -------------------------------------------------
        // Payments
        // -------------------------------------------------
        Route::post('/{loan}/payments', [LoanScheduleController::class, 'payment'])
            ->whereNumber('loan')
            ->name('payments.store');

        // -------------------------------------------------
        // Part prepayment
        // -------------------------------------------------
        Route::post('/{loan}/prepay/preview', [LoanScheduleController::class, 'prepayPreview'])
            ->whereNumber('loan')
            ->name('prepay.preview');

        Route::post('/{loan}/prepay', [LoanScheduleController::class, 'prepay'])
            ->whereNumber('loan')
            ->name('prepay');

        Route::post('/{loan}/prepay/approve', [LoanScheduleController::class, 'approvePrepay'])
            ->whereNumber('loan')
            ->name('prepay.approve');

        // -------------------------------------------------
        // Restructure
        // -------------------------------------------------
        Route::post('/{loan}/restructure/preview', [LoanScheduleController::class, 'restructurePreview'])
            ->whereNumber('loan')
            ->name('restructure.preview');

        Route::post('/{loan}/restructure', [LoanScheduleController::class, 'restructure'])
            ->whereNumber('loan')
            ->name('restructure');

        Route::post('/{loan}/restructure/approve', [LoanScheduleController::class, 'approveRestructure'])
            ->whereNumber('loan')
            ->name('restructure.approve');

        // -------------------------------------------------
        // Closure / CC / calendar actions
        // -------------------------------------------------
        Route::post('/{loan}/close', [LoanScheduleController::class, 'close'])
            ->whereNumber('loan')
            ->name('close');

        Route::post('/{loan}/renewal', [LoanScheduleController::class, 'renewal'])
            ->whereNumber('loan')
            ->name('renewal');

        Route::post('/{loan}/utilisation', [LoanScheduleController::class, 'utilisation'])
            ->whereNumber('loan')
            ->name('utilisation');

        Route::post('/obligations/{obligation}/snooze', [LoanScheduleController::class, 'snooze'])
            ->whereNumber('obligation')
            ->name('obligations.snooze');
    });
