@extends('layouts.layoutMaster')

@section('title', 'Loan Schedule Calendar')

@section('content')
<style>
    :root {
        --loan-red: #b52b22;
        --loan-red-dark: #8f211b;
        --loan-gold: #f6b51d;
        --loan-green: #16803b;
        --loan-blue: #2e5fa3;
        --loan-amber: #b7791f;
        --loan-page: #f5f6f8;
        --loan-border: #e2e5ea;
        --loan-text: #1f2937;
        --loan-muted: #6b7280;
    }

    .loan-calendar-page {
        color: var(--loan-text);
    }

    .loan-card {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .04);
    }

    .loan-title {
        color: var(--loan-red);
        font-weight: 700;
    }

    .loan-subtitle {
        color: var(--loan-muted);
        font-size: 13px;
    }

    .loan-primary-btn {
        background: var(--loan-red);
        color: #fff;
        border-color: var(--loan-red);
        font-weight: 700;
    }

    .loan-primary-btn:hover {
        background: var(--loan-red-dark);
        border-color: var(--loan-red-dark);
        color: #fff;
    }

    .loan-outline-btn {
        background: #fff;
        color: #4b5563;
        border: 1px solid #d7dbe1;
        font-weight: 600;
    }

    .loan-outline-btn:hover {
        border-color: #c8cdd4;
        color: var(--loan-red);
        background: #fafafa;
    }

    .calendar-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
    }

    .calendar-nav {
        display: flex;
        align-items: center;
        gap: 7px;
    }

    .calendar-month-title {
        min-width: 210px;
        text-align: center;
        font-weight: 800;
        color: #1f3864;
        font-size: 18px;
    }

    .calendar-view-toggle {
        display: inline-flex;
        overflow: hidden;
        border: 1px solid #d9dde4;
        border-radius: 9px;
        background: #fff;
    }

    .calendar-view-toggle button {
        border: 0;
        border-right: 1px solid #e7e9ec;
        background: #fff;
        color: #5e6671;
        padding: 8px 15px;
        font-size: 12px;
        font-weight: 700;
    }

    .calendar-view-toggle button:last-child {
        border-right: 0;
    }

    .calendar-view-toggle button.active {
        background: var(--loan-red);
        color: #fff;
    }

    .calendar-filter {
        padding: 12px;
    }

    .calendar-filter .form-select,
    .calendar-filter .form-control {
        min-height: 40px;
        border-radius: 9px;
        font-size: 13px;
    }

    .calendar-stat {
        padding: 13px;
        border-radius: 12px;
        border: 1px solid #e9ebee;
        background: #fff;
    }

    .calendar-stat .label {
        color: #737a84;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .35px;
    }

    .calendar-stat .value {
        font-size: 22px;
        font-weight: 800;
        color: #1f3864;
        line-height: 1.15;
        margin-top: 4px;
    }

    .calendar-grid-wrap {
        overflow-x: auto;
    }

    .calendar-month-grid {
        min-width: 950px;
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border-top: 1px solid var(--loan-border);
        border-left: 1px solid var(--loan-border);
    }

    .calendar-weekday {
        background: var(--loan-red);
        color: #fff;
        text-align: center;
        padding: 10px 6px;
        font-size: 11px;
        font-weight: 800;
        border-right: 1px solid rgba(255,255,255,.18);
    }

    .calendar-day {
        min-height: 145px;
        padding: 8px;
        background: #fff;
        border-right: 1px solid var(--loan-border);
        border-bottom: 1px solid var(--loan-border);
        position: relative;
    }

    .calendar-day.other-month {
        background: #f9fafb;
        color: #adb4be;
    }

    .calendar-day.today {
        background: #fffdf6;
        box-shadow: inset 0 3px 0 var(--loan-gold);
    }

    .calendar-day-number {
        width: 28px;
        height: 28px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 12px;
        font-weight: 800;
        color: #555d68;
        margin-bottom: 5px;
    }

    .calendar-day.today .calendar-day-number {
        background: var(--loan-red);
        color: #fff;
    }

    .calendar-event {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        width: 100%;
        border: 0;
        text-align: left;
        border-radius: 7px;
        padding: 6px 7px;
        margin-bottom: 5px;
        font-size: 10px;
        line-height: 1.25;
        font-weight: 700;
        cursor: pointer;
        overflow: hidden;
    }

    .calendar-event:hover {
        filter: brightness(.97);
        transform: translateY(-1px);
    }

    .calendar-event .event-icon {
        flex: 0 0 auto;
        font-size: 12px;
    }

    .calendar-event .event-content {
        min-width: 0;
        flex: 1;
    }

    .calendar-event .event-title,
    .calendar-event .event-meta {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .event-upcoming {
        background: #eaf1f9;
        color: #245786;
    }

    .event-today {
        background: #fff2d9;
        color: #8b5c00;
    }

    .event-overdue {
        background: #fdeaea;
        color: #a72720;
    }

    .event-paid {
        background: #e9f7ee;
        color: #16803b;
    }

    .event-snoozed {
        background: #f0edfa;
        color: #6552a8;
    }

    .event-more {
        border: 0;
        background: transparent;
        color: var(--loan-red);
        font-size: 11px;
        font-weight: 800;
        padding: 2px 4px;
    }

    .calendar-week-grid {
        min-width: 950px;
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border-top: 1px solid var(--loan-border);
        border-left: 1px solid var(--loan-border);
    }

    .calendar-week-column {
        min-height: 550px;
        background: #fff;
        border-right: 1px solid var(--loan-border);
        border-bottom: 1px solid var(--loan-border);
        padding: 8px;
    }

    .calendar-week-head {
        padding: 8px;
        margin: -8px -8px 8px;
        border-bottom: 1px solid #edf0f2;
        font-size: 12px;
        font-weight: 800;
    }

    .calendar-agenda-wrap {
        overflow-x: auto;
    }

    .calendar-agenda-table {
        min-width: 1050px;
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }

    .calendar-agenda-table thead th {
        background: var(--loan-red);
        color: #fff;
        padding: 11px 12px;
        font-size: 11px;
        font-weight: 800;
        white-space: nowrap;
    }

    .calendar-agenda-table tbody td {
        padding: 11px 12px;
        border-bottom: 1px solid #eef0f2;
        vertical-align: middle;
        font-size: 12px;
    }

    .calendar-agenda-table tbody tr:nth-child(even) {
        background: #fbfbfc;
    }

    .calendar-agenda-table tbody tr:hover {
        background: #fff9eb;
    }

    .agenda-date {
        font-weight: 800;
        color: #1f3864;
    }

    .agenda-type {
        display: inline-flex;
        gap: 5px;
        align-items: center;
        border-radius: 7px;
        padding: 5px 8px;
        background: #fff4d6;
        color: #805c00;
        font-size: 10px;
        font-weight: 800;
    }

    .calendar-loading,
    .calendar-empty {
        min-height: 260px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: #79818d;
        text-align: center;
    }

    .calendar-empty-icon {
        width: 58px;
        height: 58px;
        border-radius: 15px;
        background: #fff4d6;
        color: #926b00;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        margin-bottom: 12px;
    }

    .calendar-legend {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        font-size: 11px;
        color: #606873;
    }

    .calendar-legend-item {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-weight: 600;
    }

    .calendar-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        display: inline-block;
    }

    .loan-detail-modal .modal-header {
        background: var(--loan-red);
        color: #fff;
    }

    .loan-detail-modal .btn-close {
        filter: brightness(0) invert(1);
    }

    .detail-stat {
        border: 1px solid #e6e9ed;
        border-radius: 10px;
        padding: 12px;
        background: #fff;
    }

    .detail-stat-label {
        color: #747b85;
        font-size: 11px;
        font-weight: 700;
    }

    .detail-stat-value {
        color: #1f3864;
        font-size: 16px;
        font-weight: 800;
        margin-top: 3px;
    }

    @media (max-width: 767.98px) {
        .calendar-month-title {
            min-width: 150px;
            font-size: 15px;
        }

        .calendar-day {
            min-height: 105px;
        }

        .calendar-event {
            padding: 5px;
            font-size: 9px;
        }

        .calendar-toolbar {
            align-items: stretch;
        }
    }
</style>

<div
    class="container-fluid loan-calendar-page py-3"
    id="loanCalendarPage"
>
    <div class="loan-card p-3 p-lg-4 mb-3">
        <div class="calendar-toolbar">
            <div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <h4 class="loan-title mb-0">
                        Schedule Calendar
                    </h4>
                    <span class="badge bg-light-danger text-danger">
                        Repayment &amp; Renewal Watch
                    </span>
                </div>

                <div class="loan-subtitle mt-1">
                    See EMIs, interest dues, CC renewals, stock statements and jewel redemption deadlines in one place.
                </div>

                <div class="small text-muted mt-2">
                    <i class="mdi mdi-home-outline me-1"></i>
                    Home
                    <span class="mx-1">/</span>
                    Accounts &amp; Finance
                    <span class="mx-1">/</span>
                    Loans &amp; Schedules
                    <span class="mx-1">/</span>
                    <span class="text-dark fw-semibold">Calendar</span>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2 flex-wrap">
                <button
                    type="button"
                    class="btn loan-outline-btn"
                    id="calendarTodayBtn"
                >
                    Today
                </button>

                <a
                    href="{{ route('accounts_finance.loans.index') }}"
                    class="btn loan-outline-btn"
                >
                    <i class="mdi mdi-format-list-bulleted me-1"></i>
                    Loan Register
                </a>
            </div>
        </div>
    </div>

    <div class="loan-card calendar-filter mb-3">
        <div class="row g-3 align-items-end">
            <div class="col-xl-3 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Entity
                </label>
                <select class="form-select" id="calendarEntityFilter">
                    <option value="">All Entities</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Loan Type
                </label>
                <select class="form-select" id="calendarTypeFilter">
                    <option value="">All Types</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Lender
                </label>
                <select class="form-select" id="calendarLenderFilter">
                    <option value="">All Lenders</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Status
                </label>
                <select class="form-select" id="calendarStatusFilter">
                    <option value="">All</option>
                    <option value="upcoming">Upcoming</option>
                    <option value="today">Due Today</option>
                    <option value="overdue">Overdue</option>
                    <option value="paid">Paid</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-8 col-md-12">
                <label class="small fw-bold text-muted mb-1">
                    Search
                </label>
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input
                        type="search"
                        id="calendarSearch"
                        class="form-control"
                        placeholder="Account, lender or obligation..."
                        autocomplete="off"
                    >
                    <button
                        type="button"
                        class="btn btn-light border"
                        id="calendarClearSearch"
                        title="Clear"
                    >
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Calendar Items</div>
                <div class="value" id="calendarStatItems">0</div>
                <div class="small text-muted mt-1">Visible in current range</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Due Value</div>
                <div class="value" id="calendarStatAmount">₹0</div>
                <div class="small text-muted mt-1">Outstanding calendar balance</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Due Today</div>
                <div class="value text-warning" id="calendarStatToday">0</div>
                <div class="small text-muted mt-1">Items requiring attention</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Overdue</div>
                <div class="value text-danger" id="calendarStatOverdue">0</div>
                <div class="small text-muted mt-1">Past due and not fully paid</div>
            </div>
        </div>
    </div>

    <div class="loan-card">
        <div class="p-3 border-bottom">
            <div class="calendar-toolbar">
                <div class="calendar-nav">
                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        id="calendarPrevBtn"
                        aria-label="Previous"
                    >
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <div class="calendar-month-title" id="calendarMonthTitle">
                        Loading...
                    </div>

                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        id="calendarNextBtn"
                        aria-label="Next"
                    >
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>

                <div class="calendar-view-toggle">
                    <button type="button" data-calendar-view="month" class="active">
                        Month
                    </button>
                    <button type="button" data-calendar-view="week">
                        Week
                    </button>
                    <button type="button" data-calendar-view="list">
                        List
                    </button>
                </div>
            </div>
        </div>

        <div
            id="calendarContent"
            class="calendar-grid-wrap"
        >
            <div class="calendar-loading">
                <div class="spinner-border text-danger mb-2"></div>
                <div class="fw-semibold">
                    Loading schedule calendar...
                </div>
            </div>
        </div>

        <div class="p-3 border-top">
            <div class="calendar-legend">
                <span class="fw-bold text-dark">Legend:</span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#2e5fa3;"></span>
                    Upcoming
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#b7791f;"></span>
                    Due Today
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#b3261e;"></span>
                    Overdue
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#16803b;"></span>
                    Paid
                </span>

                <span class="ms-auto text-muted">
                    <i class="mdi mdi-information-outline me-1"></i>
                    Click any item for payment, snooze and loan actions.
                </span>
            </div>
        </div>
    </div>
</div>

{{-- Calendar Detail --}}
<div
    class="modal fade loan-detail-modal"
    id="calendarDetailModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="calendarDetailTitle">
                        Obligation Details
                    </h5>
                    <div class="small opacity-75" id="calendarDetailSubtitle"></div>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>
            </div>

            <div class="modal-body" id="calendarDetailBody"></div>

            <div class="modal-footer">
                <button
                    type="button"
                    class="btn loan-outline-btn"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>

                <button
                    type="button"
                    class="btn loan-outline-btn"
                    id="calendarSnoozeBtn"
                >
                    <i class="mdi mdi-clock-outline me-1"></i>
                    Snooze
                </button>

                <button
                    type="button"
                    class="btn loan-primary-btn"
                    id="calendarPaymentBtn"
                >
                    <i class="mdi mdi-cash-check me-1"></i>
                    Record Payment
                </button>

                <button
                    type="button"
                    class="btn loan-gold-btn"
                    id="calendarOpenLoanBtn"
                >
                    <i class="mdi mdi-open-in-new me-1"></i>
                    Open Loan
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Payment --}}
<div
    class="modal fade"
    id="calendarPaymentModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header text-white" style="background:#b52b22;">
                <div>
                    <h5 class="modal-title">
                        Record Payment
                    </h5>
                    <div class="small opacity-75">
                        Save the actual payment made through the bank or other payment channel.
                    </div>
                </div>

                <button
                    type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                ></button>
            </div>

            <form id="calendarPaymentForm">
                <div class="modal-body">
                    <input type="hidden" id="calendarPaymentObligationId">
                    <input type="hidden" id="calendarPaymentLoanId">

                    <div class="alert alert-light border d-flex align-items-center gap-2">
                        <i class="mdi mdi-information-outline text-primary fs-4"></i>
                        <div>
                            <div class="fw-bold" id="calendarPaymentObligationTitle">
                                -
                            </div>
                            <div class="small text-muted" id="calendarPaymentObligationMeta">
                                -
                            </div>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Amount Paid <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                min="0.01"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentAmount"
                                required
                            >
                            <div class="small text-muted mt-1" id="calendarPaymentBalanceHelp"></div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Payment Date <span class="text-danger">*</span>
                            </label>
                            <input
                                type="date"
                                class="form-control"
                                id="calendarPaymentDate"
                                required
                            >
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Mode <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="calendarPaymentMode">
                                <option value="NACH">NACH</option>
                                <option value="NEFT">NEFT</option>
                                <option value="RTGS">RTGS</option>
                                <option value="Cash">Cash</option>
                                <option value="Cheque">Cheque</option>
                                <option value="UPI">UPI</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Reference No.
                            </label>
                            <input
                                type="text"
                                maxlength="150"
                                class="form-control"
                                id="calendarPaymentReference"
                                placeholder="UTR / cheque no. / transaction reference"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Pay From Account
                            </label>
                            <input
                                type="text"
                                maxlength="180"
                                class="form-control"
                                id="calendarPaymentAccount"
                                placeholder="Bank / account reference"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Principal Component
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentPrincipal"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Interest Component
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentInterest"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Penal Interest
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentPenal"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Bounce Charge
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentBounce"
                                value="0"
                            >
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                Notes
                            </label>
                            <textarea
                                class="form-control"
                                id="calendarPaymentNotes"
                                rows="3"
                                maxlength="1000"
                                placeholder="Optional payment notes..."
                            ></textarea>
                        </div>

                        <div
                            class="small text-danger"
                            id="calendarPaymentError"
                        ></div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        data-bs-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn loan-primary-btn"
                        id="calendarPaymentSaveBtn"
                    >
                        <span class="payment-save-text">
                            <i class="mdi mdi-content-save-outline me-1"></i>
                            Save Payment
                        </span>
                        <span class="payment-save-loading d-none">
                            <span class="spinner-border spinner-border-sm me-1"></span>
                            Saving...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Snooze --}}
<div class="modal fade" id="calendarSnoozeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Snooze Reminder</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="calendarSnoozeForm">
                <div class="modal-body">
                    <label class="form-label fw-semibold">
                        Remind me again at
                    </label>
                    <input
                        type="datetime-local"
                        class="form-control"
                        id="calendarSnoozeUntil"
                        required
                    >
                    <div class="small text-muted mt-2">
                        Snoozing changes only the reminder state; the due date remains unchanged.
                    </div>
                    <div class="small text-danger mt-2" id="calendarSnoozeError"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn loan-primary-btn">Snooze</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div
    class="position-fixed bottom-0 start-50 translate-middle-x p-3"
    style="z-index:1095;"
>
    <div
        id="calendarToast"
        class="toast align-items-center text-bg-success border-0 shadow"
        role="status"
        aria-live="polite"
    >
        <div class="d-flex">
            <div class="toast-body" id="calendarToastBody"></div>
            <button
                type="button"
                class="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
            ></button>
        </div>
    </div>
</div>

<script>
    window.LoanCalendarRoutes = {
        calendar: @json(route('accounts_finance.loans.calendar.data')),
        show: @json(route('accounts_finance.loans.data.show', ['loan' => '__ID__'])),
        payment: @json(route('accounts_finance.loans.payments.store', ['loan' => '__ID__'])),
        snooze: @json(route('accounts_finance.loans.obligations.snooze', ['obligation' => '__ID__'])),
    };

    window.LoanCalendarConfig = {
        csrf: @json(csrf_token()),
        today: @json(now()->format('Y-m-d')),
    };
</script>

<script src="{{ asset('assets/js/loans/loan-calendar.js') }}"></script>
@endsection
