@forelse($loans as $loan)
    @php
        $next = $loan->obligations->first();
        $entityName = $entityNames[$loan->entity_id] ?? '-';
    @endphp

    <tr>
        <td>
            <div class="fw-bold text-primary">{{ $loan->account_no }}</div>
            <div class="small text-muted">{{ $loan->title ?: '-' }}</div>
        </td>
        <td>{{ optional($loan->type)->type_name ?: $loan->loan_type }}</td>
        <td>{{ $entityName }}</td>
        <td>{{ optional($loan->lender)->lender_name ?: '-' }}</td>
        <td class="text-end fw-bold">
            ₹ {{ number_format((float) $loan->outstanding_amount, 2) }}
        </td>
        <td class="text-end">
            ₹ {{ number_format((float) ($next->balance_amount ?? $loan->emi_amount ?? 0), 2) }}
        </td>
        <td>
            {{ optional($next?->due_date)->format('d-m-Y') ?: '-' }}
        </td>
        <td>
            {{ (int) ($loan->tenure_months ?? 0) }}
        </td>
        <td>
            <span class="badge bg-light">
                {{ ucwords(str_replace('_', ' ', $loan->status)) }}
            </span>
        </td>
        <td class="text-center">
            <a href="{{ route('accounts_finance.loans.show', $loan->id) }}"
               class="btn btn-sm btn-light border">
                <i class="mdi mdi-eye-outline"></i>
            </a>
        </td>
    </tr>
@empty
    <tr>
        <td colspan="10" class="text-center py-5 text-muted">
            No loans found.
        </td>
    </tr>
@endforelse
