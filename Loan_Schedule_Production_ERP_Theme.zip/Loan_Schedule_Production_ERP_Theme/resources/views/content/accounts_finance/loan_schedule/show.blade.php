@extends('layouts.layoutMaster')

@section('title', 'Loan Details')

@section('content')
<style>
    .loan-detail-page {
        --loan-red: #b52b22;
        --loan-gold: #f6b51d;
        --loan-green: #16803b;
        --loan-blue: #0f6ea8;
        --loan-border: #e2e5ea;
        --loan-text: #212936;
        --loan-muted: #737b87;
    }

    .loan-detail-page .loan-card {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31,41,55,.04);
    }

    .loan-detail-page .loan-header {
        background: linear-gradient(135deg, #b52b22 0%, #8f211b 100%);
        color: #fff;
        border-radius: 14px;
        overflow: hidden;
        position: relative;
    }

    .loan-detail-page .loan-header::after {
        content: "";
        width: 190px;
        height: 190px;
        border-radius: 50%;
        border: 30px solid rgba(246,181,29,.16);
        position: absolute;
        right: -70px;
        top: -95px;
    }

    .loan-detail-page .loan-account {
        font-size: 12px;
        opacity: .78;
    }

    .loan-detail-page .loan-main-title {
        font-size: 22px;
        font-weight: 800;
        margin-top: 3px;
    }

    .loan-detail-page .loan-money {
        font-size: 27px;
        font-weight: 900;
        text-align: right;
    }

    .loan-detail-page .loan-header-meta {
        font-size: 12px;
        opacity: .82;
    }

    .loan-detail-page .loan-progress {
        height: 7px;
        background: rgba(255,255,255,.22);
        border-radius: 99px;
        overflow: hidden;
    }

    .loan-detail-page .loan-progress > span {
        display: block;
        height: 100%;
        background: var(--loan-gold);
        border-radius: 99px;
    }

    .loan-detail-page .loan-tab-nav {
        display: flex;
        gap: 0;
        overflow-x: auto;
        border-bottom: 1px solid var(--loan-border);
    }

    .loan-detail-page .loan-tab-btn {
        flex: 0 0 auto;
        border: 0;
        background: #fff;
        padding: 12px 18px;
        font-size: 12px;
        font-weight: 800;
        color: #707782;
        border-bottom: 2px solid transparent;
    }

    .loan-detail-page .loan-tab-btn.active {
        color: var(--loan-red);
        border-bottom-color: var(--loan-red);
    }

    .loan-detail-page .detail-box {
        background: #fff;
        border: 1px solid #e7e9ed;
        border-radius: 11px;
        padding: 13px;
        height: 100%;
    }

    .loan-detail-page .detail-label {
        color: var(--loan-muted);
        font-size: 11px;
        font-weight: 700;
    }

    .loan-detail-page .detail-value {
        color: #1f3864;
        font-size: 14px;
        font-weight: 800;
        margin-top: 3px;
    }

    .loan-detail-page .detail-table {
        width: 100%;
        min-width: 900px;
        border-collapse: separate;
        border-spacing: 0;
    }

    .loan-detail-page .detail-table th {
        background: var(--loan-red);
        color: #fff;
        font-size: 11px;
        padding: 10px 12px;
        white-space: nowrap;
    }

    .loan-detail-page .detail-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #edf0f2;
        font-size: 12px;
        vertical-align: middle;
    }

    .loan-detail-page .detail-table tbody tr:nth-child(even) {
        background: #fbfbfc;
    }

    .loan-detail-page .paid-row {
        background: #eff9f1 !important;
    }

    .loan-detail-page .timeline {
        border-left: 2px solid #e4e7eb;
        margin-left: 8px;
        padding-left: 18px;
    }

    .loan-detail-page .timeline-item {
        position: relative;
        padding-bottom: 17px;
    }

    .loan-detail-page .timeline-item::before {
        content: "";
        position: absolute;
        width: 9px;
        height: 9px;
        background: var(--loan-red);
        border-radius: 50%;
        left: -23px;
        top: 5px;
        border: 2px solid #fff;
        box-shadow: 0 0 0 1px #dfe3e8;
    }

    .loan-detail-page .status-chip {
        display: inline-flex;
        border-radius: 999px;
        padding: 5px 10px;
        font-size: 10px;
        font-weight: 800;
    }

    .loan-detail-page .status-active { background:#e9f7ee;color:#16803b; }
    .loan-detail-page .status-pending { background:#fff4df;color:#9a6300; }
    .loan-detail-page .status-returned { background:#fdeaea;color:#b3261e; }
    .loan-detail-page .status-closed { background:#eef0f3;color:#6b7280; }
    .loan-detail-page .status-overdue { background:#fdeaea;color:#b3261e; }
    .loan-detail-page .status-paid { background:#e9f7ee;color:#16803b; }
    .loan-detail-page .status-upcoming { background:#edf4fa;color:#0f6ea8; }
    .loan-detail-page .status-today { background:#fff4df;color:#b7791f; }

    .loan-detail-page .action-main {
        background: var(--loan-gold);
        color: #171717;
        border-color: var(--loan-gold);
        font-weight: 800;
    }

    .loan-detail-page .action-main:hover {
        background: #e4a70f;
        border-color: #e4a70f;
        color: #171717;
    }

    .loan-detail-page .action-red {
        background: var(--loan-red);
        color: #fff;
        border-color: var(--loan-red);
        font-weight: 800;
    }

    .loan-detail-page .action-red:hover {
        background: #8f211b;
        border-color: #8f211b;
        color: #fff;
    }

    .loan-detail-page .table-wrap {
        overflow-x: auto;
    }
</style>

<div class="container-fluid loan-detail-page py-3" id="loanDetailPage">
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <a
            href="{{ route('accounts_finance.loans.index') }}"
            class="btn btn-sm btn-light border"
        >
            <i class="mdi mdi-arrow-left me-1"></i>
            Back to Loans
        </a>

        <a
            href="{{ route('accounts_finance.loans.calendar') }}"
            class="btn btn-sm btn-light border"
        >
            <i class="mdi mdi-calendar-month-outline me-1"></i>
            Schedule Calendar
        </a>
    </div>

    <div class="loan-header p-3 p-lg-4 mb-3">
        <div class="row align-items-center g-3 position-relative" style="z-index:1;">
            <div class="col-lg-7">
                <div class="loan-account">
                    {{ $loan->account_no }}
                </div>

                <div class="loan-main-title">
                    {{ $loan->title ?: $loan->account_no }}
                </div>

                <div class="d-flex align-items-center flex-wrap gap-2 mt-2">
                    <span class="badge bg-light text-dark">
                        {{ $loan->loan_type ?: 'Loan' }}
                    </span>
                    <span class="loan-header-meta">
                        {{ optional($loan->lender)->lender_name }}
                    </span>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="text-lg-end">
                    <div class="loan-header-meta">
                        Amount Left to Pay
                    </div>

                    <div class="loan-money">
                        ₹ {{ number_format((float) $loan->outstanding_amount, 2) }}
                    </div>

                    <div class="loan-header-meta mt-1">
                        {{ (int) ($loan->tenure_months ?? 0) }} months
                        @if($loan->maturity_date)
                            · ends {{ $loan->maturity_date->format('m-Y') }}
                        @endif
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="d-flex align-items-center justify-content-between mb-1 small">
                    <span>
                        Tenure
                    </span>
                    <span>
                        Schedule status:
                        <strong>
                            {{ ucwords(str_replace('_', ' ', $loan->status)) }}
                        </strong>
                    </span>
                </div>

                <div class="loan-progress">
                    <span
                        id="loanDetailProgress"
                        style="width: {{ $loan->tenure_months ? 0 : 0 }}%;"
                    ></span>
                </div>
            </div>
        </div>
    </div>

    @if($loan->status === 'pending_approval')
        <div class="alert alert-warning border-0 shadow-sm">
            <div class="d-flex align-items-start gap-2">
                <i class="mdi mdi-shield-alert-outline fs-4"></i>
                <div>
                    <div class="fw-bold">
                        Waiting for Finance approval
                    </div>
                    <div class="small">
                        The schedule is generated only after the loan is approved.
                        Maker-checker rules prevent the creator from approving their own record.
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="loan-card mb-3">
        <div class="p-2 d-flex justify-content-end gap-2 flex-wrap">
            @if($loan->status === 'pending_approval')
                <button
                    type="button"
                    class="btn action-main btn-sm"
                    id="detailApproveBtn"
                    data-loan-id="{{ $loan->id }}"
                >
                    <i class="mdi mdi-check-circle-outline me-1"></i>
                    Approve
                </button>
            @endif

            @if(in_array($loan->status, ['active','restructured'], true))
                <button
                    type="button"
                    class="btn action-red btn-sm"
                    id="detailPaymentBtn"
                    data-loan-id="{{ $loan->id }}"
                >
                    <i class="mdi mdi-cash-check me-1"></i>
                    Record Payment
                </button>
            @endif

            <div class="dropdown">
                <button
                    class="btn btn-light border btn-sm dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                >
                    <i class="mdi mdi-cog-outline me-1"></i>
                    Actions
                </button>

                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    @if(in_array($loan->status, ['active','restructured'], true))
                        <li>
                            <button
                                type="button"
                                class="dropdown-item"
                                id="detailPrepayBtn"
                            >
                                <i class="mdi mdi-cash-minus me-2"></i>
                                Part-Prepay / Foreclose
                            </button>
                        </li>
                        <li>
                            <button
                                type="button"
                                class="dropdown-item"
                                id="detailRestructureBtn"
                            >
                                <i class="mdi mdi-file-edit-outline me-2"></i>
                                Restructure
                            </button>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                    @endif
                    @if(in_array($loan->status, ['active','restructured'], true))
                        <li>
                            <button
                                type="button"
                                class="dropdown-item text-danger"
                                id="detailCloseBtn"
                            >
                                <i class="mdi mdi-close-circle-outline me-2"></i>
                                Close Loan
                            </button>
                        </li>
                    @endif
                </ul>
            </div>
        </div>

        <div class="loan-tab-nav">
            <button class="loan-tab-btn active" data-loan-tab="overview">
                Overview
            </button>
            <button class="loan-tab-btn" data-loan-tab="schedule">
                Schedule
            </button>
            <button class="loan-tab-btn" data-loan-tab="payments">
                Payments
            </button>
            <button class="loan-tab-btn" data-loan-tab="documents">
                Documents
            </button>
            <button class="loan-tab-btn" data-loan-tab="audit">
                Audit
            </button>
        </div>

        <div id="loanDetailTabContent" class="p-3">
            <div class="text-center py-5 text-muted">
                <div class="spinner-border text-danger"></div>
                <div class="small mt-2">Loading loan details...</div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="loanDetailPaymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Record Payment</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="loanDetailPaymentForm">
                <div class="modal-body">
                    <input type="hidden" id="detailPaymentObligationId">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Amount <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="detailPaymentAmount" min="0.01" step="0.01" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Payment Date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="detailPaymentDate" value="{{ now()->toDateString() }}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Mode <span class="text-danger">*</span></label>
                            <select class="form-select" id="detailPaymentMode">
                                <option>NACH</option>
                                <option>NEFT</option>
                                <option>RTGS</option>
                                <option>Cash</option>
                                <option>Cheque</option>
                                <option>UPI</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Reference No.</label>
                            <input type="text" class="form-control" id="detailPaymentReference" maxlength="150">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Pay From Account</label>
                            <input type="text" class="form-control" id="detailPaymentAccount" maxlength="180">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Principal</label>
                            <input type="number" class="form-control" id="detailPaymentPrincipal" min="0" step="0.01" value="0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Interest</label>
                            <input type="number" class="form-control" id="detailPaymentInterest" min="0" step="0.01" value="0">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Notes</label>
                            <textarea class="form-control" id="detailPaymentNotes" rows="3" maxlength="1000"></textarea>
                        </div>
                        <div class="small text-danger" id="detailPaymentError"></div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn action-red">Save Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="loanDetailActionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" id="loanDetailActionContent"></div>
    </div>
</div>

<script>
    window.LoanDetailConfig = {
        id: @json($loan->id),
        csrf: @json(csrf_token()),
        today: @json(now()->toDateString()),
        routes: {
            show: @json(route('accounts_finance.loans.data.show', ['loan' => $loan->id])),
            payment: @json(route('accounts_finance.loans.payments.store', ['loan' => $loan->id])),
            approve: @json(route('accounts_finance.loans.approve', ['loan' => $loan->id])),
            prepayPreview: @json(route('accounts_finance.loans.prepay.preview', ['loan' => $loan->id])),
            prepay: @json(route('accounts_finance.loans.prepay', ['loan' => $loan->id])),
            restructurePreview: @json(route('accounts_finance.loans.restructure.preview', ['loan' => $loan->id])),
            restructure: @json(route('accounts_finance.loans.restructure', ['loan' => $loan->id])),
            close: @json(route('accounts_finance.loans.close', ['loan' => $loan->id])),
        }
    };
</script>

<script>
(function($){
    'use strict';

    const cfg = window.LoanDetailConfig;

    if (!cfg || !$('#loanDetailPage').length) {
        return;
    }

    let current = null;
    let activeTab = 'overview';

    const statusMap = {
        active: ['Active','status-active'],
        pending_approval: ['Pending Approval','status-pending'],
        returned: ['Returned','status-returned'],
        closed: ['Closed','status-closed'],
        foreclosed: ['Foreclosed','status-closed'],
        restructured: ['Restructured','status-active'],
        overdue: ['Overdue','status-overdue'],
        today: ['Due Today','status-today'],
        upcoming: ['Upcoming','status-upcoming'],
        paid: ['Paid','status-paid'],
    };

    function esc(v){
        return String(v ?? '')
            .replace(/&/g,'&amp;')
            .replace(/</g,'&lt;')
            .replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;')
            .replace(/'/g,'&#039;');
    }

    function money(v){
        return new Intl.NumberFormat('en-IN',{
            style:'currency',
            currency:'INR',
            maximumFractionDigits:2
        }).format(Number(v || 0));
    }

    function dt(v){
        if(!v) return '-';
        const p=String(v).slice(0,10).split('-');
        return p.length===3 ? `${p[2]}-${p[1]}-${p[0]}` : String(v);
    }

    function badge(v){
        const x=statusMap[v] || [String(v||'-'),'status-closed'];
        return `<span class="status-chip ${x[1]}">${esc(x[0])}</span>`;
    }

    function modal(id){
        const el=document.getElementById(id);
        return (el && window.bootstrap && bootstrap.Modal)
            ? bootstrap.Modal.getOrCreateInstance(el)
            : null;
    }

    function toast(msg, type='success'){
        const holder=document.createElement('div');
        holder.className='position-fixed bottom-0 start-50 translate-middle-x p-3';
        holder.style.zIndex='1095';

        holder.innerHTML=`
            <div class="toast text-bg-${type==='error'?'danger':'success'} border-0 shadow" role="status">
                <div class="d-flex">
                    <div class="toast-body">${esc(msg)}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;

        document.body.appendChild(holder);

        const t=holder.querySelector('.toast');

        if(window.bootstrap && bootstrap.Toast){
            bootstrap.Toast.getOrCreateInstance(t,{delay:3200}).show();
            t.addEventListener('hidden.bs.toast',()=>holder.remove());
        }
    }

    function renderOverview(){
        const l=current.loan_raw || current.loan;

        const paid = (l.schedules || [])
            .flatMap(s => s.lines || [])
            .filter(x => x.status === 'paid').length;

        const total = Number(l.tenure_months || 0);
        const percent = total ? Math.min(100, (paid / total) * 100) : 0;

        $('#loanDetailProgress').css('width',percent+'%');

        const html=`
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Lender</div>
                        <div class="detail-value">${esc(l.lender?.lender_name || '-')}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Loan Type</div>
                        <div class="detail-value">${esc(l.type?.type_name || l.loan_type || '-')}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Start Date</div>
                        <div class="detail-value">${dt(l.start_date)}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Rate</div>
                        <div class="detail-value">${esc(l.interest_rate)}%</div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Sanctioned</div>
                        <div class="detail-value">${money(l.sanctioned_amount)}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Disbursed</div>
                        <div class="detail-value">${money(l.disbursed_amount)}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">Outstanding</div>
                        <div class="detail-value text-danger">${money(l.outstanding_amount)}</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="detail-box">
                        <div class="detail-label">EMI</div>
                        <div class="detail-value">${money(l.emi_amount)}</div>
                    </div>
                </div>

                ${
                    l.vehicle ? `
                    <div class="col-12">
                        <div class="detail-box">
                            <div class="fw-bold mb-3">
                                Vehicle Details
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="detail-label">Registration</div>
                                    <div class="detail-value">${esc(l.vehicle.registration_no || '-')}</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Make / Model</div>
                                    <div class="detail-value">${esc(l.vehicle.make_model || '-')}</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Chassis</div>
                                    <div class="detail-value">${esc(l.vehicle.chassis_no || '-')}</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Insurance Renewal</div>
                                    <div class="detail-value">${dt(l.vehicle.insurance_renewal_date)}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ` : ''
                }

                ${
                    l.jewel_pledge ? `
                    <div class="col-12">
                        <div class="detail-box">
                            <div class="fw-bold mb-3">
                                Jewel Pledge
                            </div>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="detail-label">Pledge Receipt</div>
                                    <div class="detail-value">${esc(l.jewel_pledge.pledge_receipt_no || '-')}</div>
                                </div>
                                <div class="col-md-4">
                                    <div class="detail-label">Interest Pattern</div>
                                    <div class="detail-value">${esc(l.jewel_pledge.interest_pattern || '-')}</div>
                                </div>
                                <div class="col-md-4">
                                    <div class="detail-label">Redemption Due</div>
                                    <div class="detail-value text-danger">${dt(l.jewel_pledge.redemption_due_date)}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ` : ''
                }

                ${
                    l.cc_facility ? `
                    <div class="col-12">
                        <div class="detail-box">
                            <div class="fw-bold mb-3">
                                Cash Credit Facility
                            </div>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <div class="detail-label">Limit</div>
                                    <div class="detail-value">${money(l.cc_facility.sanctioned_limit)}</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Drawing Power</div>
                                    <div class="detail-value">${money(l.cc_facility.drawing_power)}</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Rate</div>
                                    <div class="detail-value">${esc(l.cc_facility.interest_rate || '-')}%</div>
                                </div>
                                <div class="col-md-3">
                                    <div class="detail-label">Renewal Date</div>
                                    <div class="detail-value text-danger">${dt(l.cc_facility.renewal_date)}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ` : ''
                }
            </div>
        `;

        $('#loanDetailTabContent').html(html);
    }

    function renderSchedule(){
        const l=current.loan_raw || current.loan;
        const schedules=l.schedules || [];
        const active=schedules.find(s=>s.is_active) || schedules[0];

        if(!active || !active.lines?.length){
            $('#loanDetailTabContent').html(`
                <div class="alert alert-light border">
                    No schedule is available yet. If this loan is pending approval,
                    approve it first to generate the repayment schedule.
                </div>
            `);
            return;
        }

        const lines=active.lines;

        let html=`
            <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap mb-3">
                <div>
                    <div class="fw-bold">
                        ${esc(active.schedule_label || 'Active Schedule')}
                    </div>
                    <div class="small text-muted">
                        ${esc(active.method || '')} · Effective ${dt(active.effective_from)}
                    </div>
                </div>

                <span class="badge bg-light-success text-success">
                    Active Version
                </span>
            </div>

            <div class="table-wrap">
                <table class="detail-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Due Date</th>
                            <th class="text-end">EMI</th>
                            <th class="text-end">Principal</th>
                            <th class="text-end">Interest</th>
                            <th class="text-end">Balance</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        lines.forEach(function(x){
            const s=x.status==='paid'
                ? 'paid'
                : (
                    String(x.due_date).slice(0,10) <
                    cfg.today ? 'overdue'
                    : String(x.due_date).slice(0,10) === cfg.today
                        ? 'today'
                        : 'upcoming'
                );

            html+=`
                <tr class="${x.status==='paid'?'paid-row':''}">
                    <td class="fw-bold">${esc(x.installment_no)}</td>
                    <td>${dt(x.due_date)}</td>
                    <td class="text-end">${money(x.emi_amount)}</td>
                    <td class="text-end">${money(x.principal_amount)}</td>
                    <td class="text-end">${money(x.interest_amount)}</td>
                    <td class="text-end">${money(x.closing_balance)}</td>
                    <td>${badge(s)}</td>
                </tr>
            `;
        });

        html+=`</tbody></table></div>`;
        $('#loanDetailTabContent').html(html);
    }

    function renderPayments(){
        const l=current.loan_raw || current.loan;
        const payments=l.payments || [];

        if(!payments.length){
            $('#loanDetailTabContent').html(`
                <div class="text-center py-5 text-muted">
                    <i class="mdi mdi-cash-remove fs-1"></i>
                    <div class="fw-bold mt-2 text-dark">
                        No payments recorded yet
                    </div>
                </div>
            `);
            return;
        }

        let html=`
            <div class="table-wrap">
                <table class="detail-table">
                    <thead>
                        <tr>
                            <th>Payment Date</th>
                            <th>Type</th>
                            <th class="text-end">Amount</th>
                            <th>Mode</th>
                            <th>Reference</th>
                            <th>Principal</th>
                            <th>Interest</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        payments.forEach(function(p){
            html+=`
                <tr class="paid-row">
                    <td>${dt(p.payment_date)}</td>
                    <td>${esc(p.payment_type || '-')}</td>
                    <td class="text-end fw-bold">${money(p.amount)}</td>
                    <td>${esc(p.mode || '-')}</td>
                    <td>${esc(p.reference_no || '-')}</td>
                    <td>${money(p.principal_amount)}</td>
                    <td>${money(p.interest_amount)}</td>
                </tr>
            `;
        });

        html+=`</tbody></table></div>`;
        $('#loanDetailTabContent').html(html);
    }

    function renderDocuments(){
        const l=current.loan_raw || current.loan;
        const docs=l.documents || [];

        $('#loanDetailTabContent').html(
            docs.length
                ? `
                    <div class="row g-3">
                        ${docs.map(function(d){
                            return `
                                <div class="col-md-6 col-xl-4">
                                    <div class="detail-box">
                                        <div class="d-flex align-items-center gap-2">
                                            <i class="mdi mdi-file-document-outline text-danger fs-3"></i>
                                            <div>
                                                <div class="fw-bold">
                                                    ${esc(d.document_name)}
                                                </div>
                                                <div class="small text-muted">
                                                    ${esc(d.document_type || 'Document')}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                `
                : `
                    <div class="text-center py-5 text-muted">
                        <i class="mdi mdi-file-document-remove-outline fs-1"></i>
                        <div class="fw-bold mt-2 text-dark">
                            No documents attached
                        </div>
                    </div>
                `
        );
    }

    function renderAudit(){
        const l=current.loan_raw || current.loan;
        const rows=l.audit_logs || [];

        if(!rows.length){
            $('#loanDetailTabContent').html(`
                <div class="text-center py-5 text-muted">
                    No audit entries available.
                </div>
            `);
            return;
        }

        $('#loanDetailTabContent').html(`
            <div class="timeline">
                ${rows.map(function(x){
                    return `
                        <div class="timeline-item">
                            <div class="fw-bold text-dark">
                                ${esc(x.summary || x.action || 'Activity')}
                            </div>
                            <div class="small text-muted">
                                ${esc(x.actor_name || 'System')}
                                ${x.actor_role ? ` · ${esc(x.actor_role)}` : ''}
                                ${x.created_at ? ` · ${esc(x.created_at)}` : ''}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `);
    }

    function activateTab(tab){
        activeTab=tab;

        $('[data-loan-tab]').removeClass('active');
        $(`[data-loan-tab="${tab}"]`).addClass('active');

        if(tab==='overview') renderOverview();
        if(tab==='schedule') renderSchedule();
        if(tab==='payments') renderPayments();
        if(tab==='documents') renderDocuments();
        if(tab==='audit') renderAudit();
    }

    function load(){
        $.ajax({
            url: cfg.routes.show,
            type:'GET',
            dataType:'json',
            headers:{
                'X-Requested-With':'XMLHttpRequest',
                'Accept':'application/json'
            }
        }).done(function(res){
            current=res.data;
            activateTab(activeTab);
        }).fail(function(xhr){
            $('#loanDetailTabContent').html(`
                <div class="alert alert-danger">
                    ${esc(xhr.responseJSON?.message || 'Unable to load loan details.')}
                </div>
            `);
        });
    }

    function paymentModalOpen(){
        const modalInstance=modal('loanDetailPaymentModal');

        if(!modalInstance) return;

        const l=current.loan_raw || current.loan;
        const first=(l.obligations || [])
            .filter(x=>!['paid','superseded'].includes(x.status))
            .sort((a,b)=>String(a.due_date).localeCompare(String(b.due_date)))[0];

        $('#detailPaymentObligationId').val(first?.id || '');
        $('#detailPaymentAmount').val(
            first ? Number(first.balance_amount || 0).toFixed(2) : ''
        );
        $('#detailPaymentDate').val(cfg.today);
        $('#detailPaymentMode').val('NACH');
        $('#detailPaymentReference').val('');
        $('#detailPaymentAccount').val('');
        $('#detailPaymentPrincipal').val(
            first ? Number(first.schedule_line?.principal_amount || 0).toFixed(2) : '0'
        );
        $('#detailPaymentInterest').val(
            first ? Number(first.schedule_line?.interest_amount || 0).toFixed(2) : '0'
        );
        $('#detailPaymentNotes').val('');
        $('#detailPaymentError').text('');

        modalInstance.show();
    }

    $('#loanDetailPage').on('click','[data-loan-tab]',function(){
        activateTab($(this).data('loan-tab'));
    });

    $('#detailPaymentBtn').on('click',paymentModalOpen);

    $('#loanDetailPaymentForm').on('submit',function(e){
        e.preventDefault();

        const btn=$(this).find('button[type="submit"]');
        btn.prop('disabled',true);

        $.ajax({
            url:cfg.routes.payment,
            type:'POST',
            data:{
                _token:cfg.csrf,
                obligation_id:$('#detailPaymentObligationId').val() || '',
                payment_type:'regular',
                payment_date:$('#detailPaymentDate').val(),
                amount:$('#detailPaymentAmount').val(),
                principal_amount:$('#detailPaymentPrincipal').val(),
                interest_amount:$('#detailPaymentInterest').val(),
                penal_interest:0,
                bounce_charge:0,
                mode:$('#detailPaymentMode').val(),
                reference_no:$('#detailPaymentReference').val(),
                pay_from_account:$('#detailPaymentAccount').val(),
                notes:$('#detailPaymentNotes').val()
            },
            dataType:'json',
            headers:{
                'X-CSRF-TOKEN':cfg.csrf,
                'X-Requested-With':'XMLHttpRequest',
                'Accept':'application/json'
            }
        }).done(function(res){
            toast(res?.message || 'Payment recorded.');
            modal('loanDetailPaymentModal')?.hide();
            load();
        }).fail(function(xhr){
            $('#detailPaymentError').text(
                xhr.responseJSON?.message || 'Unable to record payment.'
            );
        }).always(function(){
            btn.prop('disabled',false);
        });
    });

    $('#detailApproveBtn').on('click',function(){
        $.post(cfg.routes.approve,{
            _token:cfg.csrf
        },function(res){
            toast(res?.message || 'Loan approved.');
            load();
        },'json').fail(function(xhr){
            toast(xhr.responseJSON?.message || 'Unable to approve loan.','error');
        });
    });

    $('#detailPrepayBtn').on('click',function(){
        $('#loanDetailActionContent').html(`
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Part-Prepay / Foreclose Request</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="detailPrepayForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Prepayment Amount</label>
                            <input type="number" min="0.01" step="0.01" class="form-control" id="prepayAmount" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Effective Date</label>
                            <input type="date" class="form-control" id="prepayDate" value="${esc(cfg.today)}" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Apply By</label>
                            <div class="d-flex gap-3 flex-wrap">
                                <label class="form-check">
                                    <input class="form-check-input" type="radio" name="prepayMode" value="reduce_emi" checked>
                                    <span class="form-check-label">Reduce EMI</span>
                                </label>
                                <label class="form-check">
                                    <input class="form-check-input" type="radio" name="prepayMode" value="reduce_tenure">
                                    <span class="form-check-label">Reduce Tenure</span>
                                </label>
                            </div>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Reason</label>
                            <textarea class="form-control" id="prepayReason" rows="3" maxlength="1000" required></textarea>
                        </div>
                        <div id="prepayPreview" class="col-12"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn action-red">Submit for Approval</button>
                </div>
            </form>
        `);

        const m=modal('loanDetailActionModal');
        m?.show();

        $('#detailPrepayForm').on('submit',function(e){
            e.preventDefault();

            $.ajax({
                url:cfg.routes.prepayPreview,
                type:'POST',
                data:{
                    _token:cfg.csrf,
                    amount:$('#prepayAmount').val(),
                    effective_date:$('#prepayDate').val(),
                    mode:$('input[name="prepayMode"]:checked').val()
                },
                dataType:'json',
                headers:{'X-CSRF-TOKEN':cfg.csrf,'Accept':'application/json'}
            }).done(function(res){
                const p=res.data;

                $('#prepayPreview').html(`
                    <div class="alert alert-light border">
                        <div class="row g-2">
                            <div class="col-6 col-md-3"><div class="small text-muted">Current EMI</div><div class="fw-bold">${money(p.current_emi)}</div></div>
                            <div class="col-6 col-md-3"><div class="small text-muted">New EMI</div><div class="fw-bold">${money(p.new_emi)}</div></div>
                            <div class="col-6 col-md-3"><div class="small text-muted">Interest Saved</div><div class="fw-bold text-success">${money(p.interest_saved_preview)}</div></div>
                            <div class="col-6 col-md-3"><div class="small text-muted">New End Date</div><div class="fw-bold">${dt(p.new_end_date)}</div></div>
                        </div>
                    </div>
                `);

                $('#detailPrepayForm').off('submit').on('submit',function(evt){
                    evt.preventDefault();

                    $.ajax({
                        url:cfg.routes.prepay,
                        type:'POST',
                        data:{
                            _token:cfg.csrf,
                            amount:$('#prepayAmount').val(),
                            effective_date:$('#prepayDate').val(),
                            mode:$('input[name="prepayMode"]:checked').val(),
                            reason:$('#prepayReason').val()
                        },
                        dataType:'json',
                        headers:{'X-CSRF-TOKEN':cfg.csrf,'Accept':'application/json'}
                    }).done(function(resp){
                        toast(resp?.message || 'Prepayment submitted.');
                        m?.hide();
                        load();
                    }).fail(function(xhr){
                        toast(xhr.responseJSON?.message || 'Unable to submit prepayment.','error');
                    });
                });
            }).fail(function(xhr){
                toast(xhr.responseJSON?.message || 'Unable to calculate preview.','error');
            });
        });
    });

    $('#detailRestructureBtn').on('click',function(){
        $('#loanDetailActionContent').html(`
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Restructure Loan</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="detailRestructureForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">New Rate %</label>
                            <input type="number" min="0" max="100" step="0.0001" class="form-control" id="restructureRate" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">New Tenure</label>
                            <input type="number" min="1" max="360" class="form-control" id="restructureMonths" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Effective Date</label>
                            <input type="date" class="form-control" id="restructureDate" value="${esc(cfg.today)}" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Reason</label>
                            <textarea class="form-control" id="restructureReason" rows="3" maxlength="1000" required></textarea>
                        </div>
                        <div class="col-12" id="restructurePreview"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn action-red">Submit for Approval</button>
                </div>
            </form>
        `);

        const m=modal('loanDetailActionModal');
        m?.show();

        $('#detailRestructureForm').on('submit',function(e){
            e.preventDefault();

            const payload={
                _token:cfg.csrf,
                new_rate:$('#restructureRate').val(),
                new_months:$('#restructureMonths').val(),
                effective_date:$('#restructureDate').val()
            };

            $.ajax({
                url:cfg.routes.restructurePreview,
                type:'POST',
                data:payload,
                dataType:'json',
                headers:{'X-CSRF-TOKEN':cfg.csrf,'Accept':'application/json'}
            }).done(function(res){
                const p=res.data;

                $('#restructurePreview').html(`
                    <div class="alert alert-light border">
                        Current EMI: <strong>${money(p.current.emi)}</strong>
                        · New EMI: <strong>${money(p.new.emi)}</strong>
                        · New end date: <strong>${dt(p.new.end_date)}</strong>
                    </div>
                `);

                $('#detailRestructureForm').off('submit').on('submit',function(evt){
                    evt.preventDefault();

                    $.ajax({
                        url:cfg.routes.restructure,
                        type:'POST',
                        data:{
                            _token:cfg.csrf,
                            new_rate:$('#restructureRate').val(),
                            new_months:$('#restructureMonths').val(),
                            effective_date:$('#restructureDate').val(),
                            reason:$('#restructureReason').val()
                        },
                        dataType:'json',
                        headers:{'X-CSRF-TOKEN':cfg.csrf,'Accept':'application/json'}
                    }).done(function(resp){
                        toast(resp?.message || 'Restructure submitted.');
                        m?.hide();
                        load();
                    }).fail(function(xhr){
                        toast(xhr.responseJSON?.message || 'Unable to submit restructure.','error');
                    });
                });
            }).fail(function(xhr){
                toast(xhr.responseJSON?.message || 'Unable to calculate preview.','error');
            });
        });
    });

    $('#detailCloseBtn').on('click',function(){
        $('#loanDetailActionContent').html(`
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Close Loan</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="detailCloseForm">
                <div class="modal-body">
                    <div class="alert alert-warning">
                        Complete both checks before closing this loan.
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="nocReceived">
                        <label class="form-check-label fw-semibold" for="nocReceived">
                            NOC / closure letter received
                        </label>
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="securityReleased">
                        <label class="form-check-label fw-semibold" for="securityReleased">
                            Security / hypothecation / pledge released
                        </label>
                    </div>

                    <label class="form-label fw-semibold">Remarks</label>
                    <textarea class="form-control" id="closeRemarks" rows="3" maxlength="1000"></textarea>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light border" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Close Loan</button>
                </div>
            </form>
        `);

        const m=modal('loanDetailActionModal');
        m?.show();

        $('#detailCloseForm').on('submit',function(e){
            e.preventDefault();

            $.ajax({
                url:cfg.routes.close,
                type:'POST',
                data:{
                    _token:cfg.csrf,
                    closure_type:'closed',
                    noc_received:$('#nocReceived').is(':checked') ? 1 : 0,
                    security_released:$('#securityReleased').is(':checked') ? 1 : 0,
                    remarks:$('#closeRemarks').val()
                },
                dataType:'json',
                headers:{'X-CSRF-TOKEN':cfg.csrf,'Accept':'application/json'}
            }).done(function(res){
                toast(res?.message || 'Loan closed.');
                m?.hide();
                load();
            }).fail(function(xhr){
                toast(xhr.responseJSON?.message || 'Unable to close loan.','error');
            });
        });
    });

    load();

})(jQuery);
</script>
@endsection
