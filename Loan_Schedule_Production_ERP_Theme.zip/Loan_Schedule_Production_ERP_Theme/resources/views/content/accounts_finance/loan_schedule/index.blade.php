@extends('layouts.layoutMaster')

@section('title', 'Loans & Schedules')

@section('content')
<style>
    :root {
        --loan-red: #b52b22;
        --loan-red-dark: #8f211b;
        --loan-gold: #f6b51d;
        --loan-green: #16803b;
        --loan-blue: #0f6ea8;
        --loan-amber: #b7791f;
        --loan-page: #f5f6f8;
        --loan-border: #e2e5ea;
        --loan-text: #1f2937;
        --loan-muted: #6b7280;
    }

    .loan-page {
        color: var(--loan-text);
    }

    .loan-page .loan-header-card {
        background: #ffffff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .05);
    }

    .loan-page .loan-title {
        color: var(--loan-red);
        font-weight: 700;
        letter-spacing: -.2px;
    }

    .loan-page .loan-subtitle {
        color: var(--loan-muted);
        font-size: 13px;
    }

    .loan-page .loan-primary-btn {
        background: var(--loan-red);
        color: #fff;
        border: 1px solid var(--loan-red);
        font-weight: 700;
        box-shadow: 0 4px 10px rgba(181, 43, 34, .16);
    }

    .loan-page .loan-primary-btn:hover {
        background: var(--loan-red-dark);
        border-color: var(--loan-red-dark);
        color: #fff;
    }

    .loan-page .loan-gold-btn {
        background: var(--loan-gold);
        color: #171717;
        border-color: var(--loan-gold);
        font-weight: 700;
    }

    .loan-page .loan-outline-btn {
        background: #fff;
        border: 1px solid #d7dbe1;
        color: #4b5563;
        font-weight: 600;
    }

    .loan-page .loan-outline-btn:hover {
        background: #f9fafb;
        color: var(--loan-red);
        border-color: #c7ccd4;
    }

    .loan-page .loan-kpi {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 12px;
        padding: 16px;
        min-height: 108px;
        position: relative;
        overflow: hidden;
    }

    .loan-page .loan-kpi::after {
        content: "";
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: rgba(181, 43, 34, .05);
        position: absolute;
        right: -18px;
        top: -18px;
    }

    .loan-page .loan-kpi-label {
        color: #6b7280;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .4px;
    }

    .loan-page .loan-kpi-value {
        color: #1f3864;
        font-size: 24px;
        line-height: 1.1;
        font-weight: 800;
        margin-top: 5px;
    }

    .loan-page .loan-kpi-meta {
        color: #6b7280;
        font-size: 12px;
        margin-top: 5px;
    }

    .loan-page .loan-filter-card,
    .loan-page .loan-table-card {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .04);
    }

    .loan-page .loan-filter-card {
        padding: 14px;
    }

    .loan-page .loan-label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: #4b5563;
        margin-bottom: 6px;
    }

    .loan-page .loan-input,
    .loan-page .loan-select {
        min-height: 41px;
        border-color: #d9dde4;
        border-radius: 9px;
        font-size: 13px;
    }

    .loan-page .loan-input:focus,
    .loan-page .loan-select:focus {
        border-color: var(--loan-red);
        box-shadow: 0 0 0 .18rem rgba(181, 43, 34, .10);
    }

    .loan-page .loan-chip-row {
        display: flex;
        flex-wrap: wrap;
        gap: 7px;
    }

    .loan-page .loan-filter-chip {
        border: 1px solid #dfe3e8;
        background: #fff;
        color: #4b5563;
        border-radius: 999px;
        padding: 7px 13px;
        font-size: 12px;
        font-weight: 700;
        transition: .15s ease;
    }

    .loan-page .loan-filter-chip:hover {
        border-color: var(--loan-red);
        color: var(--loan-red);
    }

    .loan-page .loan-filter-chip.active {
        color: #fff;
        background: var(--loan-red);
        border-color: var(--loan-red);
    }

    .loan-page .loan-table-wrap {
        overflow-x: auto;
        border-radius: 14px;
    }

    .loan-page table.loan-table {
        width: 100%;
        min-width: 1120px;
        border-collapse: separate;
        border-spacing: 0;
        margin: 0;
    }

    .loan-page .loan-table thead th {
        background: var(--loan-red);
        color: #fff;
        border: 0;
        padding: 12px 14px;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
        position: sticky;
        top: 0;
        z-index: 2;
    }

    .loan-page .loan-table thead th:first-child {
        border-top-left-radius: 12px;
    }

    .loan-page .loan-table thead th:last-child {
        border-top-right-radius: 12px;
    }

    .loan-page .loan-table tbody td {
        padding: 13px 14px;
        border-bottom: 1px solid #eef0f3;
        vertical-align: middle;
        font-size: 13px;
    }

    .loan-page .loan-table tbody tr:nth-child(even) {
        background: #fbfbfc;
    }

    .loan-page .loan-table tbody tr:hover {
        background: #fff8e7;
    }

    .loan-page .loan-account {
        color: #1f3864;
        font-weight: 800;
        font-size: 13px;
    }

    .loan-page .loan-name {
        font-weight: 700;
        color: #252c36;
    }

    .loan-page .loan-muted {
        color: #727985;
        font-size: 11px;
    }

    .loan-page .loan-type-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border-radius: 7px;
        background: #fff4d6;
        color: #805c00;
        font-weight: 700;
        font-size: 11px;
        white-space: nowrap;
    }

    .loan-page .loan-status {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
    }

    .loan-page .status-active { background: #e9f7ee; color: #16803b; }
    .loan-page .status-pending { background: #fff4df; color: #9a6300; }
    .loan-page .status-closed { background: #eef0f3; color: #6b7280; }
    .loan-page .status-returned { background: #fdeaea; color: #b3261e; }
    .loan-page .status-overdue { background: #fdeaea; color: #b3261e; }
    .loan-page .status-today { background: #fff4df; color: #b7791f; }
    .loan-page .status-upcoming { background: #edf4fa; color: #0f6ea8; }
    .loan-page .status-paid { background: #e9f7ee; color: #16803b; }

    .loan-page .loan-days-pill {
        font-size: 11px;
        font-weight: 800;
        border-radius: 999px;
        padding: 4px 8px;
    }

    .loan-page .loan-days-pill.danger { background: #fdeaea; color: #b3261e; }
    .loan-page .loan-days-pill.warn { background: #fff4df; color: #b7791f; }
    .loan-page .loan-days-pill.normal { background: #edf4fa; color: #0f6ea8; }

    .loan-page .loan-progress {
        min-width: 96px;
    }

    .loan-page .loan-progress-track {
        height: 6px;
        border-radius: 99px;
        background: #edf0f4;
        overflow: hidden;
    }

    .loan-page .loan-progress-bar {
        height: 100%;
        border-radius: 99px;
        background: var(--loan-green);
    }

    .loan-page .loan-action-btn {
        width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #dfe3e8;
        border-radius: 8px;
        color: #4b5563;
        background: #fff;
    }

    .loan-page .loan-action-btn:hover {
        color: var(--loan-red);
        border-color: #cfd4db;
        background: #fff9f8;
    }

    .loan-page .loan-loading {
        padding: 44px 20px;
        text-align: center;
        color: #7a818d;
    }

    .loan-page .loan-empty {
        padding: 60px 18px;
        text-align: center;
        color: #7a818d;
    }

    .loan-page .loan-empty-icon {
        width: 60px;
        height: 60px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 16px;
        background: #fff4d6;
        color: #9a6b00;
        font-size: 28px;
        margin-bottom: 12px;
    }

    .loan-page .loan-modal .modal-header {
        background: var(--loan-red);
        color: #fff;
        border-bottom: 0;
    }

    .loan-page .loan-modal .modal-title {
        font-weight: 700;
    }

    .loan-page .loan-modal .btn-close {
        filter: brightness(0) invert(1);
    }

    .loan-page .loan-step {
        border: 1px solid #e4e7eb;
        border-radius: 10px;
        padding: 12px;
        cursor: pointer;
        transition: .15s;
        background: #fff;
    }

    .loan-page .loan-step.active {
        border-color: var(--loan-red);
        background: #fff8f7;
        box-shadow: 0 0 0 2px rgba(181, 43, 34, .08);
    }

    .loan-page .loan-type-card {
        border: 1px solid #e0e4e8;
        border-radius: 12px;
        padding: 13px;
        height: 100%;
        cursor: pointer;
        background: #fff;
        transition: .15s;
    }

    .loan-page .loan-type-card:hover {
        border-color: var(--loan-red);
    }

    .loan-page .loan-type-card.active {
        border-color: var(--loan-red);
        background: #fff8f7;
        box-shadow: 0 0 0 2px rgba(181, 43, 34, .08);
    }

    .loan-page .loan-type-icon {
        width: 38px;
        height: 38px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        background: #fff4d6;
        color: #7e5c00;
        font-size: 20px;
        margin-bottom: 7px;
    }

    .loan-page .loan-advanced {
        background: #fafbfc;
        border: 1px solid #e8ebef;
        border-radius: 10px;
        padding: 12px;
    }

    .loan-page .loan-error {
        color: #b3261e;
        font-size: 11px;
        min-height: 16px;
        margin-top: 4px;
    }

    .loan-page .loan-pagination .page-link {
        border-radius: 8px !important;
        margin: 0 2px;
        color: var(--loan-red);
    }

    .loan-page .loan-pagination .active .page-link {
        background: var(--loan-red);
        border-color: var(--loan-red);
        color: #fff;
    }

    @media (max-width: 991.98px) {
        .loan-page .loan-title {
            font-size: 20px;
        }
    }

    @media (max-width: 767.98px) {
        .loan-page .loan-header-card {
            border-radius: 10px;
        }

        .loan-page .loan-kpi-value {
            font-size: 20px;
        }

        .loan-page .loan-filter-chip {
            padding: 6px 10px;
        }

        .loan-page .loan-modal .modal-dialog {
            margin: 10px;
        }
    }
</style>

<div
    class="container-fluid loan-page py-3"
    id="loanSchedulePage"
    data-loan-module="1"
>
    <div class="loan-header-card p-3 p-lg-4 mb-3">
        <div class="d-flex flex-column flex-xl-row align-items-xl-center justify-content-between gap-3">
            <div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <h4 class="loan-title mb-0">Loans &amp; Schedules</h4>
                    <span class="badge bg-light-danger text-danger fw-semibold">
                        Accounts &amp; Finance
                    </span>
                </div>

                <div class="loan-subtitle mt-1">
                    Central register, repayment schedule, calendar, payments and finance actions.
                </div>

                <div class="mt-2 small text-muted">
                    <i class="mdi mdi-home-outline me-1"></i>
                    Home
                    <span class="mx-1">/</span>
                    Accounts &amp; Finance
                    <span class="mx-1">/</span>
                    <span class="text-dark fw-semibold">Loans &amp; Schedules</span>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2 flex-wrap">
                <a
                    href="{{ route('accounts_finance.loans.calendar') }}"
                    class="btn loan-outline-btn"
                >
                    <i class="mdi mdi-calendar-month-outline me-1"></i>
                    Calendar
                </a>

                <button
                    type="button"
                    class="btn loan-primary-btn"
                    id="loanAddBtn"
                >
                    <i class="mdi mdi-plus me-1"></i>
                    Add Loan
                </button>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Total Outstanding</div>
                <div class="loan-kpi-value" id="loanKpiOutstanding">₹0</div>
                <div class="loan-kpi-meta" id="loanKpiOutstandingMeta">Active exposure</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Due This Week</div>
                <div class="loan-kpi-value" id="loanKpiDue">0</div>
                <div class="loan-kpi-meta" id="loanKpiDueMeta">₹0</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Overdue</div>
                <div class="loan-kpi-value text-danger" id="loanKpiOverdue">0</div>
                <div class="loan-kpi-meta" id="loanKpiOverdueMeta">₹0 outstanding dues</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Watchlist</div>
                <div class="loan-kpi-value" id="loanKpiWatch">0</div>
                <div class="loan-kpi-meta" id="loanKpiWatchMeta">Renewals + redemptions</div>
            </div>
        </div>
    </div>

    <div class="loan-filter-card mb-3">
        <div class="row g-3">
            <div class="col-12">
                <div class="loan-chip-row">
                    <button type="button" class="loan-filter-chip active" data-loan-type="">
                        All
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="vehicle">
                        <i class="mdi mdi-car-outline me-1"></i> Vehicle
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="term">
                        <i class="mdi mdi-file-document-outline me-1"></i> Term
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="jewel">
                        <i class="mdi mdi-diamond-stone me-1"></i> Jewel
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="cc">
                        <i class="mdi mdi-bank-outline me-1"></i> CC
                    </button>
                </div>
            </div>

            <div class="col-12">
                <div class="loan-chip-row">
                    <button type="button" class="loan-filter-chip active" data-loan-status="">
                        All Status
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="active">
                        Active
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="pending_approval">
                        Pending Approval
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="closed">
                        Closed
                    </button>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Entity</label>
                <select class="form-select loan-select" id="loanEntityFilter">
                    <option value="">All Entities</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Lender</label>
                <select class="form-select loan-select" id="loanLenderFilter">
                    <option value="">All Lenders</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Search</label>
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input
                        type="search"
                        class="form-control loan-input"
                        id="loanSearch"
                        placeholder="Account no., lender or loan name..."
                        autocomplete="off"
                    >
                    <button
                        class="btn btn-light border"
                        type="button"
                        id="loanClearSearch"
                        title="Clear search"
                    >
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Rows</label>
                <select class="form-select loan-select" id="loanPerPage">
                    <option value="25">25 rows</option>
                    <option value="50">50 rows</option>
                    <option value="75">75 rows</option>
                    <option value="100">100 rows</option>
                </select>
            </div>
        </div>
    </div>

    <div class="loan-table-card">
        <div class="p-3 border-bottom">
            <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap">
                <div>
                    <div class="fw-bold text-dark">Loan Register</div>
                    <div class="small text-muted">
                        Complete group-wise loan and credit facility register.
                    </div>
                </div>

                <div class="small text-muted" id="loanResultMeta">
                    Loading...
                </div>
            </div>
        </div>

        <div class="loan-table-wrap">
            <table class="loan-table">
                <thead>
                    <tr>
                        <th>Loan / Account</th>
                        <th>Type</th>
                        <th>Entity</th>
                        <th>Lender</th>
                        <th class="text-end">Outstanding</th>
                        <th class="text-end">EMI / Obligation</th>
                        <th>Next Due</th>
                        <th>Tenure</th>
                        <th>Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="loanTableBody">
                    <tr>
                        <td colspan="10">
                            <div class="loan-loading">
                                <div class="spinner-border text-danger mb-2"></div>
                                <div class="fw-semibold">Loading loan register...</div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="p-3 border-top">
            <div class="d-flex flex-column flex-md-row align-items-center justify-content-between gap-2">
                <div class="small text-muted" id="loanPaginationMeta"></div>
                <nav class="loan-pagination" aria-label="Loan pagination">
                    <ul class="pagination pagination-sm mb-0" id="loanPagination"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

{{-- Add / Edit Loan Modal --}}
<div
    class="modal fade loan-modal"
    id="loanFormModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="loanFormModalTitle">
                        Add Loan
                    </h5>
                    <div class="small opacity-75">
                        Fill the common details first, then complete the type-specific section.
                    </div>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                ></button>
            </div>

            <form id="loanForm">
                <div class="modal-body">
                    <input type="hidden" id="loanId" name="loan_id">

                    <div id="loanFormAlert" class="alert alert-danger d-none"></div>

                    <div class="mb-3">
                        <div class="row g-2">
                            <div class="col-12 col-md-4">
                                <div class="loan-step active">
                                    <div class="fw-bold">
                                        <span class="badge bg-danger me-1">1</span>
                                        Basic Details
                                    </div>
                                    <div class="small text-muted mt-1">
                                        Entity, lender, account and loan type
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4">
                                <div class="loan-step">
                                    <div class="fw-bold">
                                        <span class="badge bg-secondary me-1">2</span>
                                        Amounts &amp; Schedule
                                    </div>
                                    <div class="small text-muted mt-1">
                                        Finance values and repayment dates
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4">
                                <div class="loan-step">
                                    <div class="fw-bold">
                                        <span class="badge bg-secondary me-1">3</span>
                                        Type Specific
                                    </div>
                                    <div class="small text-muted mt-1">
                                        Vehicle, Jewel, CC or tranche details
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 bg-light mb-3">
                        <div class="card-body">
                            <div class="fw-bold text-dark mb-3">
                                Loan Type
                            </div>

                            <div class="row g-3" id="loanTypeCards">
                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="loan-type-card" data-loan-type-card="vehicle">
                                        <div class="loan-type-icon">
                                            <i class="mdi mdi-car-outline"></i>
                                        </div>
                                        <div class="fw-bold">Vehicle Loan</div>
                                        <div class="small text-muted">
                                            EMI loan against a vehicle.
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="loan-type-card" data-loan-type-card="term">
                                        <div class="loan-type-icon">
                                            <i class="mdi mdi-file-document-outline"></i>
                                        </div>
                                        <div class="fw-bold">Business Term</div>
                                        <div class="small text-muted">
                                            Business or project term borrowing.
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="loan-type-card" data-loan-type-card="jewel">
                                        <div class="loan-type-icon">
                                            <i class="mdi mdi-diamond-stone"></i>
                                        </div>
                                        <div class="fw-bold">Jewel Loan</div>
                                        <div class="small text-muted">
                                            Pledge with redemption deadline.
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="loan-type-card" data-loan-type-card="cc">
                                        <div class="loan-type-icon">
                                            <i class="mdi mdi-bank-outline"></i>
                                        </div>
                                        <div class="fw-bold">CC Limit</div>
                                        <div class="small text-muted">
                                            Working capital facility and renewal.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" id="loanTypeId" name="loan_type_id">
                            <div class="small text-danger loan-error" data-error="loan_type_id"></div>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-lg-4">
                            <label class="loan-label">
                                Entity
                            </label>
                            <select class="form-select loan-select" id="loanEntityId" name="entity_id">
                                <option value="">Select Entity</option>
                            </select>
                            <div class="loan-error" data-error="entity_id"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Lender <span class="text-danger">*</span>
                            </label>
                            <select class="form-select loan-select" id="loanLenderId" name="lender_id">
                                <option value="">Select Lender</option>
                            </select>
                            <div class="loan-error" data-error="lender_id"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Loan Account Number <span class="text-danger">*</span>
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanAccountNo"
                                name="account_no"
                                maxlength="120"
                                placeholder="Enter loan / facility account number"
                            >
                            <div class="loan-error" data-error="account_no"></div>
                        </div>

                        <div class="col-lg-8">
                            <label class="loan-label">
                                Loan Title
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanTitle"
                                name="title"
                                maxlength="220"
                                placeholder="Example: Bolero Vehicle Loan"
                            >
                            <div class="loan-error" data-error="title"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Interest Type
                            </label>
                            <select class="form-select loan-select" id="loanInterestType" name="interest_type">
                                <option value="reducing">Reducing Balance</option>
                                <option value="flat">Flat Rate</option>
                                <option value="simple">Simple Interest</option>
                            </select>
                            <div class="loan-error" data-error="interest_type"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Sanctioned / Limit Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanSanctioned"
                                name="sanctioned_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="sanctioned_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Disbursed Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanDisbursed"
                                name="disbursed_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="disbursed_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Outstanding Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanOutstanding"
                                name="outstanding_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="outstanding_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Interest Rate % <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.0001"
                                min="0"
                                max="100"
                                class="form-control loan-input"
                                id="loanRate"
                                name="interest_rate"
                                placeholder="Example: 9.50"
                            >
                            <div class="loan-error" data-error="interest_rate"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Start Date <span class="text-danger">*</span>
                            </label>
                            <input
                                type="date"
                                class="form-control loan-input"
                                id="loanStartDate"
                                name="start_date"
                            >
                            <div class="loan-error" data-error="start_date"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                First Due Date
                            </label>
                            <input
                                type="date"
                                class="form-control loan-input"
                                id="loanFirstDueDate"
                                name="first_due_date"
                            >
                            <div class="loan-error" data-error="first_due_date"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Tenure (Months)
                            </label>
                            <input
                                type="number"
                                class="form-control loan-input"
                                id="loanTenure"
                                name="tenure_months"
                                min="1"
                                max="360"
                                placeholder="60"
                            >
                            <div class="loan-error" data-error="tenure_months"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                EMI / Instalment
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanEmi"
                                name="emi_amount"
                                placeholder="Auto / manual"
                            >
                            <div class="loan-error" data-error="emi_amount"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Maturity Date
                            </label>
                            <input
                                type="date"
                                class="form-control loan-input"
                                id="loanMaturityDate"
                                name="maturity_date"
                            >
                            <div class="loan-error" data-error="maturity_date"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Moratorium (Months)
                            </label>
                            <input
                                type="number"
                                class="form-control loan-input"
                                id="loanMoratorium"
                                name="moratorium_months"
                                min="0"
                                max="120"
                                value="0"
                            >
                            <div class="loan-error" data-error="moratorium_months"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Security Details
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanSecurity"
                                name="security_details"
                                maxlength="5000"
                                placeholder="Vehicle / property / pledge / other"
                            >
                            <div class="loan-error" data-error="security_details"></div>
                        </div>
                    </div>

                    <div class="loan-advanced mt-3">
                        <div class="fw-bold text-dark mb-3">
                            Type Specific Details
                        </div>

                        <div id="loanVehiclePanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-3">
                                    <label class="loan-label">Registration No. <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleReg" name="registration_no" maxlength="60">
                                    <div class="loan-error" data-error="registration_no"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Make / Model</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleMake" name="make_model" maxlength="160">
                                    <div class="loan-error" data-error="make_model"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Chassis No.</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleChassis" name="chassis_no" maxlength="120">
                                    <div class="loan-error" data-error="chassis_no"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Engine No.</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleEngine" name="engine_no" maxlength="120">
                                    <div class="loan-error" data-error="engine_no"></div>
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Insurance Renewal</label>
                                    <input type="date" class="form-control loan-input" id="loanVehicleInsurance" name="insurance_renewal_date">
                                    <div class="loan-error" data-error="insurance_renewal_date"></div>
                                </div>
                                <div class="col-lg-4 d-flex align-items-end">
                                    <div class="form-check form-switch pb-2">
                                        <input class="form-check-input" type="checkbox" id="loanVehicleHypothecated" name="hypothecated_flag" value="1" checked>
                                        <label class="form-check-label fw-semibold" for="loanVehicleHypothecated">
                                            Hypothecated to lender
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="loanTermPanel" class="d-none">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <div class="small text-muted">
                                    Add actual disbursement tranches when the term loan is released in stages.
                                </div>
                                <button type="button" class="btn btn-sm loan-outline-btn" id="loanAddTrancheBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Tranche
                                </button>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;">#</th>
                                            <th>Disbursed Date</th>
                                            <th>Amount</th>
                                            <th>Remarks</th>
                                            <th style="width:60px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="loanTrancheRows"></tbody>
                                </table>
                            </div>
                        </div>

                        <div id="loanJewelPanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-4">
                                    <label class="loan-label">Pledge Receipt No.</label>
                                    <input type="text" class="form-control loan-input" id="loanPledgeReceipt" name="pledge_receipt_no" maxlength="120">
                                    <div class="loan-error" data-error="pledge_receipt_no"></div>
                                </div>

                                <div class="col-lg-4">
                                    <label class="loan-label">Interest Pattern</label>
                                    <select class="form-select loan-select" id="loanJewelInterestPattern" name="interest_pattern">
                                        <option value="monthly">Monthly Servicing</option>
                                        <option value="at_redemption">At Redemption</option>
                                    </select>
                                </div>

                                <div class="col-lg-4">
                                    <label class="loan-label">Redemption Due Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control loan-input" id="loanRedemptionDate" name="redemption_due_date">
                                    <div class="loan-error" data-error="redemption_due_date"></div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between mt-3 mb-2">
                                <div class="small fw-semibold text-dark">Pledged Items</div>
                                <button type="button" class="btn btn-sm loan-outline-btn" id="loanAddJewelBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Item
                                </button>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th style="width:55px;">#</th>
                                            <th>Description</th>
                                            <th>Gross Wt.</th>
                                            <th>Net Wt.</th>
                                            <th>Purity</th>
                                            <th style="width:60px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="loanJewelRows"></tbody>
                                </table>
                            </div>
                        </div>

                        <div id="loanCcPanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-3">
                                    <label class="loan-label">Sanctioned Limit</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcLimit" name="sanctioned_limit">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Margin %</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcMargin" name="margin_percent">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Drawing Power</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcDrawingPower" name="drawing_power">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">CC Interest Rate %</label>
                                    <input type="number" step="0.0001" class="form-control loan-input" id="loanCcRate" name="cc_interest_rate">
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Renewal Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control loan-input" id="loanCcRenewalDate" name="renewal_date">
                                    <div class="loan-error" data-error="renewal_date"></div>
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Stock Statement Day</label>
                                    <input type="number" min="1" max="31" class="form-control loan-input" id="loanCcStockDay" name="stock_statement_day">
                                </div>
                            </div>
                        </div>

                        <div id="loanNoTypePanel" class="text-muted small">
                            Select a loan type above to continue.
                        </div>
                    </div>

                    <div class="row g-3 mt-1">
                        <div class="col-12">
                            <label class="loan-label">Remarks</label>
                            <textarea
                                class="form-control loan-input"
                                id="loanRemarks"
                                name="remarks"
                                rows="3"
                                maxlength="5000"
                                placeholder="Add relevant notes, exceptions or business context..."
                            ></textarea>
                            <div class="loan-error" data-error="remarks"></div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        data-bs-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn loan-primary-btn"
                        id="loanSaveBtn"
                    >
                        <span class="loan-save-text">
                            <i class="mdi mdi-content-save-outline me-1"></i>
                            Submit for Approval
                        </span>
                        <span class="loan-save-loading d-none">
                            <span class="spinner-border spinner-border-sm me-1"></span>
                            Saving...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- View Loan Modal --}}
<div
    class="modal fade loan-modal"
    id="loanViewModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="loanViewTitle">Loan Details</h5>
                    <div class="small opacity-75" id="loanViewSubtitle"></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body" id="loanViewBody">
                <div class="text-center py-5">
                    <div class="spinner-border text-danger"></div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Approval Return Modal --}}
<div class="modal fade loan-modal" id="loanReturnModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <h5 class="modal-title">Return Loan to Maker</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="loanReturnForm">
                <div class="modal-body">
                    <input type="hidden" id="loanReturnId">

                    <label class="loan-label">
                        Remarks <span class="text-danger">*</span>
                    </label>

                    <textarea
                        class="form-control loan-input"
                        id="loanReturnRemarks"
                        rows="4"
                        maxlength="1000"
                        placeholder="Explain what needs correction..."
                    ></textarea>

                    <div class="loan-error" id="loanReturnError"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-danger">
                        Return to Maker
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Toast --}}
<div
    class="position-fixed bottom-0 start-50 translate-middle-x p-3"
    style="z-index:1095;"
>
    <div
        id="loanToast"
        class="toast align-items-center border-0 shadow"
        role="status"
        aria-live="polite"
        aria-atomic="true"
    >
        <div class="d-flex">
            <div class="toast-body" id="loanToastBody"></div>
            <button
                type="button"
                class="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
            ></button>
        </div>
    </div>
</div>

<script>
    window.LoanScheduleRoutes = {
        data: @json(route('accounts_finance.loans.data')),
        lookups: @json(route('accounts_finance.loans.lookups')),
        store: @json(route('accounts_finance.loans.store')),
        show: @json(route('accounts_finance.loans.data.show', ['loan' => '__ID__'])),
        update: @json(route('accounts_finance.loans.update', ['loan' => '__ID__'])),
        approve: @json(route('accounts_finance.loans.approve', ['loan' => '__ID__'])),
        return: @json(route('accounts_finance.loans.return', ['loan' => '__ID__'])),
        payment: @json(route('accounts_finance.loans.payments.store', ['loan' => '__ID__'])),
    };

    window.LoanSchedulePageConfig = {
        csrf: @json(csrf_token()),
        initialPerPage: 25
    };
</script>

<script src="{{ asset('assets/js/loans/loan-module.js') }}"></script>
@endsection
