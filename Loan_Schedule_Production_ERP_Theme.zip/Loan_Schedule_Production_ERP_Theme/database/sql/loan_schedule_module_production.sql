-- Elysium Groups ERP
-- Loan & Schedule Module - Production Database
-- MySQL 8.x
-- Fresh-install module spine aligned to PDD EIBS-PDD-EGLS-2026-001.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS loan_types (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    type_code VARCHAR(30) NOT NULL,
    type_name VARCHAR(120) NOT NULL,
    icon VARCHAR(50) DEFAULT NULL,
    description VARCHAR(255) DEFAULT NULL,
    display_order INT NOT NULL DEFAULT 1,
    status TINYINT NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive',
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_types_code (type_code),
    KEY idx_loan_types_status (status),
    KEY idx_loan_types_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_lenders (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    lender_name VARCHAR(180) NOT NULL,
    lender_type VARCHAR(40) DEFAULT 'bank',
    branch_name VARCHAR(180) DEFAULT NULL,
    contact_person VARCHAR(150) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    email VARCHAR(180) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_loan_lenders_name (lender_name),
    KEY idx_loan_lenders_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loans (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    entity_id BIGINT UNSIGNED DEFAULT NULL,
    lender_id BIGINT UNSIGNED NOT NULL,
    loan_type_id BIGINT UNSIGNED NOT NULL,
    loan_type VARCHAR(30) DEFAULT NULL,
    account_no VARCHAR(120) NOT NULL,
    title VARCHAR(220) DEFAULT NULL,
    sanctioned_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    disbursed_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    outstanding_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    interest_rate DECIMAL(8,4) NOT NULL DEFAULT 0.0000,
    interest_type VARCHAR(30) NOT NULL DEFAULT 'reducing',
    start_date DATE NOT NULL,
    first_due_date DATE DEFAULT NULL,
    tenure_months INT UNSIGNED DEFAULT NULL,
    emi_amount DECIMAL(18,2) DEFAULT NULL,
    maturity_date DATE DEFAULT NULL,
    moratorium_months INT UNSIGNED NOT NULL DEFAULT 0,
    security_details TEXT DEFAULT NULL,
    remarks TEXT DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'draft',
    approved_by BIGINT UNSIGNED DEFAULT NULL,
    approved_at DATETIME DEFAULT NULL,
    returned_by BIGINT UNSIGNED DEFAULT NULL,
    returned_at DATETIME DEFAULT NULL,
    closed_at DATETIME DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_loans_entity (entity_id),
    KEY idx_loans_lender (lender_id),
    KEY idx_loans_type (loan_type_id),
    KEY idx_loans_status (status),
    KEY idx_loans_account (account_no),
    KEY idx_loans_deleted_at (deleted_at),
    KEY idx_loans_next (status, maturity_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_vehicles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    registration_no VARCHAR(60) DEFAULT NULL,
    make_model VARCHAR(160) DEFAULT NULL,
    chassis_no VARCHAR(120) DEFAULT NULL,
    engine_no VARCHAR(120) DEFAULT NULL,
    hypothecated_flag TINYINT NOT NULL DEFAULT 1,
    insurance_renewal_date DATE DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_vehicle (loan_id),
    CONSTRAINT fk_loan_vehicle_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_tranches (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    tranche_no INT UNSIGNED NOT NULL,
    disbursed_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    remarks VARCHAR(500) DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_tranche_no (loan_id, tranche_no),
    KEY idx_loan_tranches_loan (loan_id),
    CONSTRAINT fk_loan_tranches_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_jewel_pledges (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    pledge_receipt_no VARCHAR(120) DEFAULT NULL,
    interest_pattern VARCHAR(30) NOT NULL DEFAULT 'monthly',
    redemption_due_date DATE DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pledged',
    released_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_jewel_pledge (loan_id),
    KEY idx_jewel_redemption_date (redemption_due_date),
    CONSTRAINT fk_jewel_pledge_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_jewel_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pledge_id BIGINT UNSIGNED NOT NULL,
    item_no INT UNSIGNED NOT NULL,
    description VARCHAR(255) NOT NULL,
    gross_weight DECIMAL(10,3) DEFAULT NULL,
    net_weight DECIMAL(10,3) DEFAULT NULL,
    purity VARCHAR(30) DEFAULT NULL,
    release_status VARCHAR(30) NOT NULL DEFAULT 'held',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_jewel_item_no (pledge_id, item_no),
    CONSTRAINT fk_jewel_item_pledge FOREIGN KEY (pledge_id) REFERENCES loan_jewel_pledges(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_cc_facilities (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    sanctioned_limit DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    margin_percent DECIMAL(8,4) DEFAULT NULL,
    drawing_power DECIMAL(18,2) DEFAULT NULL,
    interest_rate DECIMAL(8,4) DEFAULT NULL,
    renewal_date DATE DEFAULT NULL,
    stock_statement_day TINYINT UNSIGNED DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_cc_facility (loan_id),
    KEY idx_cc_renewal_date (renewal_date),
    CONSTRAINT fk_cc_facility_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_cc_utilisations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    facility_id BIGINT UNSIGNED NOT NULL,
    as_of_date DATE NOT NULL,
    utilised_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    interest_debit DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    drawing_power DECIMAL(18,2) DEFAULT NULL,
    remarks VARCHAR(500) DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_cc_utilisation_date (facility_id, as_of_date),
    KEY idx_cc_utilisation_date (as_of_date),
    CONSTRAINT fk_cc_utilisation_facility FOREIGN KEY (facility_id) REFERENCES loan_cc_facilities(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_schedules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    version_no INT UNSIGNED NOT NULL DEFAULT 1,
    schedule_label VARCHAR(180) NOT NULL,
    method VARCHAR(40) NOT NULL DEFAULT 'computed_reducing',
    principal_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    interest_rate DECIMAL(8,4) NOT NULL DEFAULT 0.0000,
    tenure_months INT UNSIGNED NOT NULL DEFAULT 0,
    effective_from DATE NOT NULL,
    is_active TINYINT NOT NULL DEFAULT 1,
    superseded_at DATETIME DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_schedule_version (loan_id, version_no),
    KEY idx_loan_schedule_active (loan_id, is_active),
    CONSTRAINT fk_loan_schedule_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_schedule_lines (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    schedule_id BIGINT UNSIGNED NOT NULL,
    installment_no INT UNSIGNED NOT NULL,
    due_date DATE NOT NULL,
    emi_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    principal_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    interest_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    closing_balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(30) NOT NULL DEFAULT 'due',
    paid_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_schedule_line_no (schedule_id, installment_no),
    KEY idx_schedule_line_due_date (due_date),
    KEY idx_schedule_line_status (status),
    CONSTRAINT fk_schedule_line_schedule FOREIGN KEY (schedule_id) REFERENCES loan_schedules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_obligations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    schedule_line_id BIGINT UNSIGNED DEFAULT NULL,
    obligation_type VARCHAR(40) NOT NULL,
    title VARCHAR(220) NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    paid_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    balance_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    action_label VARCHAR(100) DEFAULT NULL,
    metadata_json JSON DEFAULT NULL,
    snoozed_until DATETIME DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_obligations_loan_date (loan_id, due_date),
    KEY idx_obligations_due_date (due_date),
    KEY idx_obligations_status (status),
    KEY idx_obligations_type (obligation_type),
    CONSTRAINT fk_obligation_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_obligation_schedule_line FOREIGN KEY (schedule_line_id) REFERENCES loan_schedule_lines(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_payments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    obligation_id BIGINT UNSIGNED DEFAULT NULL,
    payment_type VARCHAR(30) NOT NULL DEFAULT 'regular',
    payment_date DATE NOT NULL,
    amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    principal_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    interest_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    penal_interest DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    bounce_charge DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    mode VARCHAR(30) NOT NULL DEFAULT 'NACH',
    reference_no VARCHAR(150) DEFAULT NULL,
    pay_from_account VARCHAR(180) DEFAULT NULL,
    notes VARCHAR(1000) DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_loan_payments_loan_date (loan_id, payment_date),
    KEY idx_loan_payments_obligation (obligation_id),
    CONSTRAINT fk_loan_payment_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_loan_payment_obligation FOREIGN KEY (obligation_id) REFERENCES loan_obligations(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_payment_allocations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    payment_id BIGINT UNSIGNED NOT NULL,
    obligation_id BIGINT UNSIGNED NOT NULL,
    amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_payment_obligation (payment_id, obligation_id),
    CONSTRAINT fk_payment_alloc_payment FOREIGN KEY (payment_id) REFERENCES loan_payments(id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_alloc_obligation FOREIGN KEY (obligation_id) REFERENCES loan_obligations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_change_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    change_type VARCHAR(40) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    requested_by BIGINT UNSIGNED DEFAULT NULL,
    approved_by BIGINT UNSIGNED DEFAULT NULL,
    effective_date DATE DEFAULT NULL,
    payload_json JSON DEFAULT NULL,
    remarks VARCHAR(1000) DEFAULT NULL,
    approved_at DATETIME DEFAULT NULL,
    rejected_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_change_loan_status (loan_id, status),
    CONSTRAINT fk_change_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_renewal_checklists (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    checklist_type VARCHAR(40) NOT NULL,
    renewal_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'documents_pending',
    submitted_at DATETIME DEFAULT NULL,
    renewed_at DATETIME DEFAULT NULL,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_renewal_loan_date (loan_id, renewal_date),
    CONSTRAINT fk_renewal_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_renewal_checklist_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    checklist_id BIGINT UNSIGNED NOT NULL,
    item_key VARCHAR(80) NOT NULL,
    item_label VARCHAR(180) NOT NULL,
    is_completed TINYINT NOT NULL DEFAULT 0,
    completed_by BIGINT UNSIGNED DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_renewal_item (checklist_id, item_key),
    CONSTRAINT fk_renewal_item_checklist FOREIGN KEY (checklist_id) REFERENCES loan_renewal_checklists(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_notification_rules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED DEFAULT NULL,
    obligation_type VARCHAR(40) DEFAULT NULL,
    lead_day INT NOT NULL DEFAULT 7,
    channel VARCHAR(30) NOT NULL DEFAULT 'in_app',
    escalation_day INT DEFAULT NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    updated_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notification_rule_lookup (loan_id, obligation_type, lead_day)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    obligation_id BIGINT UNSIGNED NOT NULL,
    rule_id BIGINT UNSIGNED DEFAULT NULL,
    channel VARCHAR(30) NOT NULL,
    recipient VARCHAR(180) NOT NULL,
    scheduled_for DATETIME NOT NULL,
    sent_at DATETIME DEFAULT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'queued',
    provider_message_id VARCHAR(180) DEFAULT NULL,
    error_message TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notification_schedule (scheduled_for, status),
    KEY idx_notification_obligation (obligation_id),
    CONSTRAINT fk_notification_obligation FOREIGN KEY (obligation_id) REFERENCES loan_obligations(id) ON DELETE CASCADE,
    CONSTRAINT fk_notification_rule FOREIGN KEY (rule_id) REFERENCES loan_notification_rules(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_documents (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED NOT NULL,
    document_name VARCHAR(220) NOT NULL,
    document_type VARCHAR(80) DEFAULT NULL,
    storage_disk VARCHAR(40) DEFAULT NULL,
    storage_path VARCHAR(500) DEFAULT NULL,
    mime_type VARCHAR(120) DEFAULT NULL,
    size_bytes BIGINT UNSIGNED DEFAULT NULL,
    uploaded_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_loan_documents_loan (loan_id),
    CONSTRAINT fk_loan_document_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_holidays (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    holiday_date DATE NOT NULL,
    label VARCHAR(180) NOT NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_by BIGINT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_loan_holiday_date (holiday_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS loan_audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    loan_id BIGINT UNSIGNED DEFAULT NULL,
    entity_type VARCHAR(60) NOT NULL,
    entity_id BIGINT UNSIGNED DEFAULT NULL,
    action VARCHAR(80) NOT NULL,
    summary VARCHAR(1000) NOT NULL,
    before_json JSON DEFAULT NULL,
    after_json JSON DEFAULT NULL,
    actor_user_id BIGINT UNSIGNED DEFAULT NULL,
    actor_name VARCHAR(180) DEFAULT NULL,
    actor_role VARCHAR(120) DEFAULT NULL,
    ip_address VARCHAR(64) DEFAULT NULL,
    user_agent VARCHAR(500) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_audit_loan_created (loan_id, created_at),
    KEY idx_audit_entity (entity_type, entity_id),
    CONSTRAINT fk_audit_loan FOREIGN KEY (loan_id) REFERENCES loans(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO loan_types (type_code, type_name, icon, description, display_order, status)
SELECT * FROM (
    SELECT 'vehicle', 'Vehicle Loan', 'mdi-car-outline', 'Vehicle-backed repayment loan', 1, 1
    UNION ALL
    SELECT 'term', 'Business Term Loan', 'mdi-file-document-outline', 'Business term / project borrowing', 2, 1
    UNION ALL
    SELECT 'jewel', 'Jewel Loan', 'mdi-diamond-stone', 'Gold/jewel pledge with redemption deadline', 3, 1
    UNION ALL
    SELECT 'cc', 'CC Limit', 'mdi-bank-outline', 'Cash credit facility with renewal cycle', 4, 1
) AS seed
WHERE NOT EXISTS (
    SELECT 1 FROM loan_types WHERE loan_types.type_code = seed.type_code
);

INSERT INTO loan_notification_rules (loan_id, obligation_type, lead_day, channel, escalation_day, status)
SELECT NULL, x.obligation_type, x.lead_day, x.channel, x.escalation_day, 1
FROM (
    SELECT 'emi' AS obligation_type, 7 AS lead_day, 'in_app' AS channel, 3 AS escalation_day
    UNION ALL SELECT 'emi', 1, 'email', 1
    UNION ALL SELECT 'renewal', 45, 'in_app', 5
    UNION ALL SELECT 'redemption', 30, 'in_app', 7
    UNION ALL SELECT 'redemption', 15, 'email', 7
    UNION ALL SELECT 'redemption', 7, 'in_app', 1
) x
WHERE NOT EXISTS (
    SELECT 1
    FROM loan_notification_rules r
    WHERE r.loan_id IS NULL
      AND r.obligation_type = x.obligation_type
      AND r.lead_day = x.lead_day
      AND r.channel = x.channel
);

SET FOREIGN_KEY_CHECKS = 1;
