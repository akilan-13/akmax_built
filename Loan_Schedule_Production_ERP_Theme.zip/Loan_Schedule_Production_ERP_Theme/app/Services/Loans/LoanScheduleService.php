<?php

namespace App\Services\Loans;

use App\Models\Loans\Loan;
use App\Models\Loans\LoanObligation;
use App\Models\Loans\LoanSchedule;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class LoanScheduleService
{
    public function emi(float $principal, float $annualRate, int $months): float
    {
        if ($principal <= 0 || $months <= 0) {
            throw new InvalidArgumentException('Principal and tenure must be greater than zero.');
        }

        $rate = $annualRate / 1200;

        if (abs($rate) < 0.00000001) {
            return round($principal / $months, 2);
        }

        $factor = pow(1 + $rate, $months);

        return round(($principal * $rate * $factor) / ($factor - 1), 2);
    }

    public function buildReducingSchedule(
        float $principal,
        float $annualRate,
        int $months,
        Carbon|string $firstDueDate
    ): array {
        if ($principal <= 0 || $months <= 0) {
            throw new InvalidArgumentException('Principal and tenure must be greater than zero.');
        }

        $date = $firstDueDate instanceof Carbon
            ? $firstDueDate->copy()
            : Carbon::parse($firstDueDate);

        $monthlyRate = $annualRate / 1200;
        $emi = $this->emi($principal, $annualRate, $months);
        $balance = $principal;
        $rows = [];

        for ($i = 1; $i <= $months; $i++) {
            $interest = $monthlyRate > 0
                ? round($balance * $monthlyRate, 2)
                : 0;

            $principalPart = min(
                round($emi - $interest, 2),
                $balance
            );

            $closing = max(
                0,
                round($balance - $principalPart, 2)
            );

            $rows[] = [
                'installment_no' => $i,
                'due_date' => $date->copy()->toDateString(),
                'emi_amount' => round($principalPart + $interest, 2),
                'principal_amount' => $principalPart,
                'interest_amount' => $interest,
                'closing_balance' => $closing,
                'status' => 'due',
            ];

            $balance = $closing;
            $date->addMonthNoOverflow();
        }

        return $rows;
    }

    public function buildFlatSchedule(
        float $principal,
        float $annualRate,
        int $months,
        Carbon|string $firstDueDate
    ): array {
        if ($principal <= 0 || $months <= 0) {
            throw new InvalidArgumentException('Principal and tenure must be greater than zero.');
        }

        $date = $firstDueDate instanceof Carbon
            ? $firstDueDate->copy()
            : Carbon::parse($firstDueDate);

        $totalInterest = round($principal * ($annualRate / 100) * ($months / 12), 2);
        $monthlyPrincipal = round($principal / $months, 2);
        $monthlyInterest = round($totalInterest / $months, 2);

        $balance = $principal;
        $rows = [];

        for ($i = 1; $i <= $months; $i++) {
            $principalPart = $i === $months
                ? $balance
                : min($monthlyPrincipal, $balance);

            $closing = max(
                0,
                round($balance - $principalPart, 2)
            );

            $rows[] = [
                'installment_no' => $i,
                'due_date' => $date->copy()->toDateString(),
                'emi_amount' => round($principalPart + $monthlyInterest, 2),
                'principal_amount' => $principalPart,
                'interest_amount' => $monthlyInterest,
                'closing_balance' => $closing,
                'status' => 'due',
            ];

            $balance = $closing;
            $date->addMonthNoOverflow();
        }

        return $rows;
    }

    public function activateSchedule(
        Loan $loan,
        array $rows,
        array $meta = []
    ): LoanSchedule {
        return DB::transaction(function () use ($loan, $rows, $meta) {
            LoanSchedule::where('loan_id', $loan->id)
                ->where('is_active', true)
                ->update([
                    'is_active' => false,
                    'superseded_at' => now(),
                ]);

            LoanObligation::where('loan_id', $loan->id)
                ->whereIn('status', ['pending', 'today', 'overdue', 'partial', 'snoozed'])
                ->whereNotNull('schedule_line_id')
                ->update([
                    'status' => 'superseded',
                    'updated_at' => now(),
                ]);

            $version = ((int) LoanSchedule::where('loan_id', $loan->id)->max('version_no')) + 1;

            $schedule = LoanSchedule::create([
                'loan_id' => $loan->id,
                'version_no' => $version,
                'schedule_label' => $meta['label'] ?? "v{$version} — computed",
                'method' => $meta['method'] ?? 'computed_reducing',
                'principal_amount' => $meta['principal_amount'] ?? $loan->outstanding_amount,
                'interest_rate' => $meta['interest_rate'] ?? $loan->interest_rate,
                'tenure_months' => count($rows),
                'effective_from' => $meta['effective_from'] ?? now()->toDateString(),
                'is_active' => true,
                'created_by' => auth()->user()->user_id ?? auth()->id(),
            ]);

            foreach ($rows as $row) {
                $line = $schedule->lines()->create($row);

                LoanObligation::create([
                    'loan_id' => $loan->id,
                    'schedule_line_id' => $line->id,
                    'obligation_type' => 'emi',
                    'title' => 'EMI #'.$line->installment_no,
                    'due_date' => $line->due_date,
                    'amount' => $line->emi_amount,
                    'paid_amount' => 0,
                    'balance_amount' => $line->emi_amount,
                    'status' => 'pending',
                    'action_label' => 'Record Payment',
                    'metadata_json' => [
                        'installment_no' => $line->installment_no,
                        'schedule_id' => $schedule->id,
                    ],
                    'created_by' => auth()->user()->user_id ?? auth()->id(),
                ]);
            }

            return $schedule->load('lines');
        });
    }

    public function generateForLoan(Loan $loan): ?LoanSchedule
    {
        if (!in_array($loan->loan_type, ['vehicle', 'term'], true) &&
            !$loan->type?->type_code) {
            return null;
        }

        $principal = (float) (
            $loan->outstanding_amount > 0
                ? $loan->outstanding_amount
                : ($loan->disbursed_amount > 0
                    ? $loan->disbursed_amount
                    : $loan->sanctioned_amount)
        );

        $months = (int) ($loan->tenure_months ?? 0);

        if ($principal <= 0 || $months <= 0) {
            return null;
        }

        $firstDueDate = $loan->first_due_date
            ? Carbon::parse($loan->first_due_date)
            : Carbon::parse($loan->start_date)->addMonthNoOverflow();

        $typeCode = $loan->loan_type ?: $loan->type?->type_code;
        $interestType = $loan->interest_type ?: 'reducing';

        $rows = $interestType === 'flat'
            ? $this->buildFlatSchedule($principal, (float) $loan->interest_rate, $months, $firstDueDate)
            : $this->buildReducingSchedule($principal, (float) $loan->interest_rate, $months, $firstDueDate);

        $emi = (float) ($rows[0]['emi_amount'] ?? 0);
        $maturityDate = $rows[count($rows) - 1]['due_date'] ?? null;

        $loan->update([
            'loan_type' => $typeCode,
            'emi_amount' => $emi,
            'maturity_date' => $maturityDate,
            'outstanding_amount' => $principal,
            'updated_by' => auth()->user()->user_id ?? auth()->id(),
        ]);

        return $this->activateSchedule(
            $loan,
            $rows,
            [
                'label' => 'v1 — original schedule',
                'method' => $interestType === 'flat' ? 'computed_flat' : 'computed_reducing',
                'principal_amount' => $principal,
                'interest_rate' => $loan->interest_rate,
                'effective_from' => $loan->start_date?->toDateString() ?? now()->toDateString(),
            ]
        );
    }

    public function syncSpecialObligations(Loan $loan): void
    {
        $actor = auth()->user()->user_id ?? auth()->id();

        if ($loan->loan_type === 'jewel' && $loan->jewelPledge?->redemption_due_date) {
            $exists = LoanObligation::where('loan_id', $loan->id)
                ->where('obligation_type', 'redemption')
                ->whereDate('due_date', $loan->jewelPledge->redemption_due_date)
                ->whereNotIn('status', ['superseded'])
                ->exists();

            if (!$exists) {
                LoanObligation::create([
                    'loan_id' => $loan->id,
                    'obligation_type' => 'redemption',
                    'title' => 'Jewel redemption deadline',
                    'due_date' => $loan->jewelPledge->redemption_due_date,
                    'amount' => $loan->outstanding_amount,
                    'paid_amount' => 0,
                    'balance_amount' => $loan->outstanding_amount,
                    'status' => 'pending',
                    'action_label' => 'Open Loan',
                    'metadata_json' => ['priority' => 'high'],
                    'created_by' => $actor,
                ]);
            }
        }

        if ($loan->loan_type === 'cc' && $loan->ccFacility) {
            if ($loan->ccFacility->renewal_date) {
                $exists = LoanObligation::where('loan_id', $loan->id)
                    ->where('obligation_type', 'renewal')
                    ->whereDate('due_date', $loan->ccFacility->renewal_date)
                    ->whereNotIn('status', ['superseded'])
                    ->exists();

                if (!$exists) {
                    LoanObligation::create([
                        'loan_id' => $loan->id,
                        'obligation_type' => 'renewal',
                        'title' => 'CC annual renewal',
                        'due_date' => $loan->ccFacility->renewal_date,
                        'amount' => 0,
                        'paid_amount' => 0,
                        'balance_amount' => 0,
                        'status' => 'pending',
                        'action_label' => 'Open Renewal',
                        'created_by' => $actor,
                    ]);
                }
            }

            if ($loan->ccFacility->stock_statement_day) {
                $this->ensureCurrentStockStatement($loan);
            }
        }
    }

    protected function ensureCurrentStockStatement(Loan $loan): void
    {
        if (!$loan->ccFacility?->stock_statement_day) {
            return;
        }

        $actor = auth()->user()->user_id ?? auth()->id();
        $today = now()->startOfDay();
        $day = min((int) $loan->ccFacility->stock_statement_day, $today->daysInMonth);

        $due = $today->copy()->day($day);

        if ($due->lt($today)) {
            $due->addMonthNoOverflow()->day(
                min((int) $loan->ccFacility->stock_statement_day, $due->daysInMonth)
            );
        }

        LoanObligation::firstOrCreate(
            [
                'loan_id' => $loan->id,
                'obligation_type' => 'stock_statement',
                'due_date' => $due->toDateString(),
            ],
            [
                'title' => 'CC stock statement',
                'amount' => 0,
                'paid_amount' => 0,
                'balance_amount' => 0,
                'status' => 'pending',
                'action_label' => 'Open Facility',
                'created_by' => $actor,
            ]
        );
    }
}
