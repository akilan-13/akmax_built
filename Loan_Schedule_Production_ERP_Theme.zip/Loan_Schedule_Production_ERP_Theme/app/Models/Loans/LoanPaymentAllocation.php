<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanPaymentAllocation extends Model
{
    protected $table = 'loan_payment_allocations';
    protected $primaryKey = 'id';
    public $timestamps = false;

    protected $fillable = ['payment_id','obligation_id','amount'];
    protected $casts = ['amount'=>'decimal:2'];

    public function payment() { return $this->belongsTo(LoanPayment::class, 'payment_id', 'id'); }
    public function obligation() { return $this->belongsTo(LoanObligation::class, 'obligation_id', 'id'); }
}