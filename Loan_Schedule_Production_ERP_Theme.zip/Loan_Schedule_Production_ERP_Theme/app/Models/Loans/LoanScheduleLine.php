<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanScheduleLine extends Model
{
    protected $table = 'loan_schedule_lines';
    protected $primaryKey = 'id';

    protected $fillable = [
        'schedule_id','installment_no','due_date','emi_amount','principal_amount',
        'interest_amount','closing_balance','status','paid_at',
    ];

    protected $casts = [
        'installment_no'=>'integer','due_date'=>'date','emi_amount'=>'decimal:2',
        'principal_amount'=>'decimal:2','interest_amount'=>'decimal:2','closing_balance'=>'decimal:2','paid_at'=>'datetime',
    ];

    public function schedule() { return $this->belongsTo(LoanSchedule::class, 'schedule_id', 'id'); }
    public function obligation() { return $this->hasOne(LoanObligation::class, 'schedule_line_id', 'id'); }
}