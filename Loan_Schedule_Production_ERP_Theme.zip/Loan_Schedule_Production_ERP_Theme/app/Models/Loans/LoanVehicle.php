<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanVehicle extends Model
{
    protected $table = 'loan_vehicles';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','registration_no','make_model','chassis_no','engine_no',
        'hypothecated_flag','insurance_renewal_date',
    ];

    protected $casts = [
        'hypothecated_flag' => 'boolean',
        'insurance_renewal_date' => 'date',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
}