<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanPayment extends Model
{
    protected $table = 'loan_payments';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = [
        'loan_id','obligation_id','payment_type','payment_date','amount','principal_amount',
        'interest_amount','penal_interest','bounce_charge','mode','reference_no',
        'pay_from_account','notes','created_by',
    ];

    protected $casts = [
        'payment_date'=>'date','amount'=>'decimal:2','principal_amount'=>'decimal:2',
        'interest_amount'=>'decimal:2','penal_interest'=>'decimal:2','bounce_charge'=>'decimal:2',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function obligation() { return $this->belongsTo(LoanObligation::class, 'obligation_id', 'id'); }
}