<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanHoliday extends Model
{
    protected $table = 'loan_holidays';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = ['holiday_date','label','status','created_by'];
    protected $casts = ['holiday_date'=>'date','status'=>'integer'];
}