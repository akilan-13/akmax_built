<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanRenewalChecklistItem extends Model
{
    protected $table = 'loan_renewal_checklist_items';
    protected $primaryKey = 'id';

    protected $fillable = [
        'checklist_id','item_key','item_label','is_completed','completed_by','completed_at',
    ];

    protected $casts = ['is_completed'=>'boolean','completed_at'=>'datetime'];

    public function checklist() { return $this->belongsTo(LoanRenewalChecklist::class, 'checklist_id', 'id'); }
}