<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanAuditLog extends Model
{
    protected $table = 'loan_audit_log';
    protected $primaryKey = 'id';
    public $updated_at = false;

    protected $fillable = [
        'loan_id','entity_type','entity_id','action','summary','before_json','after_json',
        'actor_user_id','actor_name','actor_role','ip_address','user_agent',
    ];

    protected $casts = ['before_json'=>'array','after_json'=>'array'];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
}