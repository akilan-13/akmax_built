<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanSchedule extends Model
{
    protected $table = 'loan_schedules';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','version_no','schedule_label','method','principal_amount',
        'interest_rate','tenure_months','effective_from','is_active','superseded_at','created_by',
    ];

    protected $casts = [
        'version_no'=>'integer','principal_amount'=>'decimal:2','interest_rate'=>'decimal:4',
        'tenure_months'=>'integer','effective_from'=>'date','is_active'=>'boolean','superseded_at'=>'datetime',
    ];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
    public function lines() { return $this->hasMany(LoanScheduleLine::class, 'schedule_id', 'id')->orderBy('installment_no'); }
}