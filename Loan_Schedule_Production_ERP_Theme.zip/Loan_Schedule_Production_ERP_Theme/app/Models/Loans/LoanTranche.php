<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanTranche extends Model
{
    protected $table = 'loan_tranches';
    protected $primaryKey = 'id';

    protected $fillable = [
        'loan_id','tranche_no','disbursed_date','amount','remarks','created_by','updated_by',
    ];

    protected $casts = ['tranche_no'=>'integer','disbursed_date'=>'date','amount'=>'decimal:2'];

    public function loan() { return $this->belongsTo(Loan::class, 'loan_id', 'id'); }
}