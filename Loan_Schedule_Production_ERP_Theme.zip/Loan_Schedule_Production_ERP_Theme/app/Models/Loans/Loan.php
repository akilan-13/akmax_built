<?php
namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Loan extends Model
{
    use SoftDeletes;

    protected $table = 'loans';
    protected $primaryKey = 'id';

    protected $fillable = [
        'entity_id','lender_id','loan_type_id','loan_type','account_no','title',
        'sanctioned_amount','disbursed_amount','outstanding_amount',
        'interest_rate','interest_type','start_date','first_due_date',
        'tenure_months','emi_amount','maturity_date','moratorium_months',
        'security_details','remarks','status','approved_by','approved_at',
        'returned_by','returned_at','closed_at','created_by','updated_by',
    ];

    protected $casts = [
        'entity_id' => 'integer',
        'lender_id' => 'integer',
        'loan_type_id' => 'integer',
        'sanctioned_amount' => 'decimal:2',
        'disbursed_amount' => 'decimal:2',
        'outstanding_amount' => 'decimal:2',
        'interest_rate' => 'decimal:4',
        'start_date' => 'date',
        'first_due_date' => 'date',
        'maturity_date' => 'date',
        'emi_amount' => 'decimal:2',
        'tenure_months' => 'integer',
        'moratorium_months' => 'integer',
        'approved_at' => 'datetime',
        'returned_at' => 'datetime',
        'closed_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    public function lender()
    {
        return $this->belongsTo(LoanLender::class, 'lender_id', 'id');
    }

    public function type()
    {
        return $this->belongsTo(LoanType::class, 'loan_type_id', 'id');
    }

    public function vehicle()
    {
        return $this->hasOne(LoanVehicle::class, 'loan_id', 'id');
    }

    public function tranches()
    {
        return $this->hasMany(LoanTranche::class, 'loan_id', 'id');
    }

    public function jewelPledge()
    {
        return $this->hasOne(LoanJewelPledge::class, 'loan_id', 'id');
    }

    public function ccFacility()
    {
        return $this->hasOne(LoanCcFacility::class, 'loan_id', 'id');
    }

    public function schedules()
    {
        return $this->hasMany(LoanSchedule::class, 'loan_id', 'id');
    }

    public function obligations()
    {
        return $this->hasMany(LoanObligation::class, 'loan_id', 'id');
    }

    public function payments()
    {
        return $this->hasMany(LoanPayment::class, 'loan_id', 'id');
    }

    public function documents()
    {
        return $this->hasMany(LoanDocument::class, 'loan_id', 'id');
    }

    public function changeRequests()
    {
        return $this->hasMany(LoanChangeRequest::class, 'loan_id', 'id');
    }

    public function auditLogs()
    {
        return $this->hasMany(LoanAuditLog::class, 'loan_id', 'id')->latest('created_at');
    }

    public function renewalChecklists()
    {
        return $this->hasMany(LoanRenewalChecklist::class, 'loan_id', 'id');
    }
}