# Elysium Groups ERP — Loan & Schedule Module

Production-oriented Laravel module based on the supplied EIBS-PDD-EGLS-2026-001 and the supplied Loan & Schedule prototype.

## UI direction

The module intentionally uses the existing Elysium ERP application language from the supplied ERP screenshot:
- red / maroon module emphasis
- yellow / gold primary accent
- Bootstrap + MDI
- white cards and table surfaces
- red table headers
- compact chips and responsive action buttons

The original prototype's financial status colours are retained for meaning:
- Upcoming: blue
- Due Today: amber
- Overdue: red
- Paid: green
- Renewal / watchlist: gold

The supplied prototype specifically defines Month / Week / List calendar navigation, type/status filters, click-to-detail actions and a "+ more" calendar expansion pattern. The PDD also defines a unified `loan_obligations` calendar concept for EMIs, interest dues, renewals, stock statements, redemptions and custom reminders.

## Package structure

database/sql/
  loan_schedule_module_production.sql

routes/
  loans.php
  routes_loans.php

app/Http/Controllers/accounts_finance/
  LoanScheduleController.php

app/Models/Loans/
  Loan.php
  LoanType.php
  LoanLender.php
  LoanVehicle.php
  LoanTranche.php
  LoanJewelPledge.php
  LoanJewelItem.php
  LoanCcFacility.php
  LoanCcUtilisation.php
  LoanSchedule.php
  LoanScheduleLine.php
  LoanObligation.php
  LoanPayment.php
  LoanPaymentAllocation.php
  LoanChangeRequest.php
  LoanRenewalChecklist.php
  LoanRenewalChecklistItem.php
  LoanNotificationRule.php
  LoanNotification.php
  LoanDocument.php
  LoanHoliday.php
  LoanAuditLog.php

app/Services/Loans/
  LoanScheduleService.php

resources/views/content/accounts_finance/loan_schedule/
  index.blade.php
  calendar.blade.php
  show.blade.php
  partials/_loan_rows.blade.php
  partials/_loan_form_notes.blade.php

resources/js/loans/
  loan-module.js
  loan-calendar.js

public/assets/js/loans/
  loan-module.js
  loan-calendar.js

## Installation

1. Import `database/sql/loan_schedule_module_production.sql` into the target MySQL database.

2. Copy models:
   `app/Models/Loans/*` → your Laravel `app/Models/Loans/`

3. Copy controller:
   `app/Http/Controllers/accounts_finance/LoanScheduleController.php`

4. Copy service:
   `app/Services/Loans/LoanScheduleService.php`

5. Copy Blade directory:
   `resources/views/content/accounts_finance/loan_schedule/`

6. Copy public JS:
   `public/assets/js/loans/`

7. Add the routes file to your application. The route group already uses:
   `auth:web`
   `throttle:120,1`
   prefix `accounts_finance/loans`
   names `accounts_finance.loans.*`

   Option A:
   `require base_path('routes/loans.php');`

   Option B:
   paste the contents of `routes/routes_loans.php` into `routes/web.php`.

8. Confirm the existing ERP layout contains Bootstrap and MDI Icons. No new CDN is required by this package.

## Existing ERP integration points

### Entity master

The controller reads:
`egc_entity`
with:
- `sno`
- `entity_name`
- active rows where `status = 0`

This matches the existing ERP patterns visible in the supplied Manage Staff code.

### User ID

The controller supports the ERP pattern:
`auth()->user()->user_id`

and falls back to:
`auth()->id()`

### RBAC

The controller provides hooks for:
- `hasPermission($permission)`
- Laravel Gate `can()`

Supported logical permissions:
- loan.view
- loan.create
- loan.edit
- loan.approve
- loan.payment
- loan.close
- loan.reminder

Wire these to the ERP's existing permission system rather than introducing a second RBAC implementation.

### Entity scope

If the authenticated user implements:
`loanEntityIds()`

the controller automatically restricts loan and calendar queries to those entity IDs.

## Important production behavior

### Maker-checker

The creator of a loan / prepayment / restructure cannot approve their own financial change.

Approval creates or activates the schedule after the loan is approved.

### Schedule versions

Active schedule rows are versioned in `loan_schedules`. A newly approved prepayment or restructure supersedes the old schedule instead of overwriting historical rows.

### Calendar

The calendar is driven by `loan_obligations`, not directly from the loan table.

That supports:
- EMI
- interest
- CC renewal
- stock statement
- jewel redemption
- custom reminder

Month, week and table-like list/agenda are supported.

### Payments

A payment may be linked to an obligation and is allocated through `loan_payment_allocations`.

Principal reduction is stored separately from interest and charges.

### Active-loan edits

Core financial fields cannot be changed directly on an active/restructured loan. Use prepayment or restructure workflows.

## Production hardening still expected in the host ERP

This package is designed to be integrated into an existing ERP, so the following should use your application's established infrastructure:
- final RBAC/policy definitions
- entity-scope service/policy
- document storage service / S3 integration
- queued notifier jobs
- idempotency for notification dispatch
- payment reversal as a new reversal transaction
- database backup and migration deployment process
- staging/UAT smoke tests

## Blade asset location

The Blade files use:

`{{ asset('assets/js/loans/loan-module.js') }}`

and:

`{{ asset('assets/js/loans/loan-calendar.js') }}`

Therefore the `public/assets/js/loans/` copies are the drop-in runtime versions.

## Route order

Keep these routes before `/{loan}`:
- `/`
- `/calendar`
- `/data`
- `/calendar/data`
- `/lookups`
- `/{loan}/data`

This prevents `/calendar`, `/data`, and `/lookups` from being captured as numeric loan IDs.

## Validation

The package should be syntax-checked after copying into the host Laravel project with:

`php -l app/Http/Controllers/accounts_finance/LoanScheduleController.php`

and:

`php -l app/Services/Loans/LoanScheduleService.php`

JavaScript can be checked with:

`node --check public/assets/js/loans/loan-module.js`

`node --check public/assets/js/loans/loan-calendar.js`
