<!-- resources/views/content/user_management/manage_users/add.blade.php -->
@extends('layouts/layoutMaster')

@section('title', 'Update Manage Users')

@section('vendor-style')
@vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('content')

  <div class="card">
    @php
        $helper = new \App\Helpers\Helpers();
    @endphp
    <div class="card-header border-bottom pb-1">
      <h5 class="card-title mb-1">Update Manage Users</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-chevron-double-right fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Users Management</a>
          </li>
        </ol>
      </nav>
    </div>

    <form id="userRolePermissionForm" action="{{ route('update_user_role_permission', ['id' => $role->sno]) }}"  method="POST" novalidate>
      @csrf
      <div class="card-body">
          <div class="row">
              <div class="col-lg-3 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Role <span class="text-danger">*</span></label>
                  <select id="role" name="role" class="select3 form-select">
                      <option value="">Select Role</option>
                      @php $get_role_list = $helper->get_role_list(); @endphp
                      @foreach ($get_role_list as $rlist)
                          <option value="{{ $rlist->sno }}" @if($role->role_id == $rlist->sno) selected @endif>
                              {{ $rlist->role_name }}
                          </option>
                      @endforeach
                  </select>
              </div>
                 <div class="col-lg-4 mb-2 " id="accessHeadDiv" style="display: none;">
                    <div class="card" style="background-color: #e7a368 !important;">
                        <div class="card-body">
                            <div class="row px-1">
                                <div class="col-lg-4 ">
                                    <input class="form-check-input " type="radio" name="access_head" id="view_rbh" value="1" @if($role->access_head == 1) checked @endif />
                                    <label class="text-black fs-6 fw-semibold" for="view_rbh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Regional Branch Head">RBH</label>
                                </div>
                                <div class="col-lg-4 ">
                                    <input class="form-check-input " type="radio" name="access_head" id="view_rfh" value="2" @if($role->access_head == 2) checked @endif />
                                    <label class="text-black fs-6 fw-semibold" for="view_rfh" data-bs-toggle="tooltip" data-bs-placement="bottom"  title="Regional Franchises Head">RFH</label>
                                </div>
                                <div class="col-lg-4 ">
                                    <input class="form-check-input " type="radio" name="access_head" id="view_gm" value="3" @if($role->access_head == 3) checked @endif />
                                    <label class="text-black fs-6 fw-semibold" for="view_gm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Global Head">GH</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 mb-2 ">
                    <div class="card" style="background-color: #e7a368 !important;">
                        <div class="card-body">
                            <div class="row px-1">
                                <div class="col-lg-6 ">
                                    <input class="form-check-input" type="radio" name="manage_branch" id="view_mm"
                                        value="2" @if($role->manage_branch == 2) checked @endif />
                                    <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi
                                        Manage</label>
                                </div>
                                <div class="col-lg-6 ">
                                    <input class="form-check-input" type="radio" name="manage_branch" id="view_sm"
                                        value="1" @if($role->manage_branch == 1) checked @endif />
                                    <label class="text-black fs-6 fw-semibold" for="view_sm"
                                        title="Single Manage">Single Manage</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

          </div>

          <div class="d-flex justify-content-end align-items-center py-4">
              <div class="form-check form-check-inline">
                  <input class="form-check-input select-all" type="checkbox" id="selectAllMain" />
                  <label class="text-black fs-6 fw-bold" for="selectAllMain">Select All</label>
              </div>
          </div>

          <div class="accordion" id="permissionsAccordion">
                @foreach ($menu['menu'] as $menuItem)
                    @if (isset($menuItem['name'], $menuItem['slug'])) <!-- Ensure 'name' and 'slug' exist -->
                        <div class="col-lg-12 mb-2">
                            <div class="card-header" style="background-color: #e7a368 !important;">
                                <div class="card-action-title d-flex justify-content-between align-items-center">
                                    <div class="form-check form-check-inline">
                                        <?php $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']); ?>
                                        <input class="form-check-input menu-checkbox" type="checkbox" id="{{ $menuItem['slug'] }}"
                                            @if(isset($flattenedPermissions[$menuKey]['menuChecked']) && $flattenedPermissions[$menuKey]['menuChecked'])
                                                checked
                                            @endif
                                        />
                                        <label class="text-black fs-6 fw-bold" for="{{ $menuItem['slug'] }}">{{ $menuItem['name'] }}</label>
                                    </div>
                                    <a class="dashboards_add" type="button" data-toggle="collapse" data-target="#collapseMenu{{ $menuItem['slug'] }}" aria-expanded="true" aria-controls="collapseMenu{{ $menuItem['slug'] }}">
                                        <i class="mdi mdi-chevron-down fs-3"></i>
                                    </a>
                                </div>
                            </div>

                            <div id="collapseMenu{{ $menuItem['slug'] }}" class="collapse border" aria-labelledby="headingMenu{{ $menuItem['slug'] }}" data-parent="#accordion">
                                <div class="card-body">
                                    @if(isset($menuItem) && $menuItem['name'] == 'Dashboard')
                                        <div class="row">
                                      @foreach(['Dashboard'] as $action)
                                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                                          <div class="form-check form-check-inline">
                                              <?php
                                                  $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                  $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                              ?>
                                              <input class="form-check-input submenu-action-checkbox"
                                                  type="checkbox" name="actions[]"
                                                  id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $menuItem['slug'] }}"
                                                  value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $menuItem['slug'] }}"
                                                  @if(isset($flattenedPermissions[$menuKey]['actions'])
                                                  && in_array($actionKey,
                                                  array_column($flattenedPermissions[$menuKey]['actions'], 'actionName'
                                                  )) &&
                                                  $flattenedPermissions[$menuKey]['actions'][array_search($actionKey,
                                                  array_column($flattenedPermissions[$menuKey]['actions'], 'actionName'
                                                  ))]['actionChecked']==1) checked @endif />
                                              <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                              data-bs-placement="bottom" title="{{ $action }}"
                                                  for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $menuItem['slug'] }}">{{
                                                  $action }}</label>
                                          </div>
                                      </div>
                                      @endforeach
                                      <div class="col-lg-4 mb-2">
                                          <div class="card" style="background-color: #e7a368 !important;">
                                              <div class="card-body">
                                                  <div class="row px-1">
                                                      <div class="col-lg-6">
                                                          <input class="form-check-input" type="radio"
                                                              name="radio_dashboard_{{ $menuItem['slug'] }}"
                                                              id="global_lead{{ $menuItem['slug'] }}"
                                                              value="global_lead" checked
                                                              @if(isset($flattenedPermissions[$menuKey]['radios'][0])
                                                              &&
                                                              $flattenedPermissions[$menuKey]['radios'][0]['radioValue']=='global_lead'
                                                              &&
                                                              $flattenedPermissions[$menuKey]['radios'][0]['checked']==1)
                                                              checked @endif />
                                                          <label class="text-black fs-6 fw-semibold"
                                                              for="global_lead{{ $menuItem['slug'] }}">Global</label>
                                                      </div>
                                                      <div class="col-lg-6">
                                                          <input class="form-check-input" type="radio"
                                                              name="radio_dashboard_{{ $menuItem['slug'] }}"
                                                              id="view_self_lead{{ $menuItem['slug'] }}"
                                                              value="view_self_lead"
                                                              @if(isset($flattenedPermissions[$menuKey]['radios'][0])
                                                              &&
                                                              $flattenedPermissions[$menuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                              &&
                                                              $flattenedPermissions[$menuKey]['radios'][0]['checked']==1)
                                                              checked @endif />
                                                          <label class="text-black fs-6 fw-semibold"
                                                              for="view_self_lead{{ $menuItem['slug'] }}">View
                                                              Self</label>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                    </div>
                                      
                                    @endif
                                    @if (isset($menuItem['submenu']))
                                        @foreach ($menuItem['submenu'] as $submenuName => $submenuItem)
                                            @if (isset($submenuItem['name'], $submenuItem['slug']))
                                            <?php $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']); ?>
                                            <?php $mainmenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']); ?>
                                                <div class="col-lg-12 mb-2">
                                                    <div class="card-header" style="background-color: #6fb7d5 !important;">
                                                        <div class="card-action-title d-flex justify-content-between align-items-center">

                                                            <div class="form-check form-check-inline">
                                                                 <input class="form-check-input submenu-checkbox" type="checkbox" id="{{ $submenuItem['slug'] }}"
                                                                  @if (isset($flattenedPermissions[$mainmenuKey]['submenu'][$submenuKey]['submenuChecked']) &&
                                                                      $flattenedPermissions[$mainmenuKey]['submenu'][$submenuKey]['submenuChecked'] == 1
                                                                  )
                                                                  checked
                                                                  @endif
                                                              />
                                                                <label class="text-black fs-6 fw-bold" for="{{ $submenuItem['slug'] }}">{{ $submenuItem['name'] }}</label>
                                                            </div>
                                                            <a class="dashboards_add" type="button" data-toggle="collapse" data-target="#collapseSubmenu{{ $submenuItem['slug'] }}" aria-expanded="true" aria-controls="collapseSubmenu{{ $submenuItem['slug'] }}">
                                                                <i class="mdi mdi-chevron-down fs-3"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseSubmenu{{ $submenuItem['slug'] }}" class="collapse border" aria-labelledby="headingSubmenu{{ $submenuItem['slug'] }}">
                                                        <div class="card-body">
                                                          {{-- Vasanth --}}
                                                          {{-- Marketing Management Start --}}
                                                            @if ($submenuItem['name'] == 'Marketing Campaign')
                                                              <div class="row">
                                                                  @foreach(['List', 'View'] as $action)
                                                                  <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                      <div class="form-check form-check-inline">
                                                                          <?php
                                                                              $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                              $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                              $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                          ?>
                                                                          <input class="form-check-input submenu-action-checkbox"
                                                                              type="checkbox" name="actions[]"
                                                                              id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                              && in_array($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              )) &&
                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              ))]['actionChecked']==1) checked @endif />
                                                                          <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                          data-bs-placement="bottom" title="{{ $action }}"
                                                                              for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                              $action }}</label>
                                                                      </div>
                                                                  </div>
                                                                  @endforeach
                                                                  <div class="col-lg-4 mb-2">
                                                                      <div class="card" style="background-color: #70e2ef !important;">
                                                                          <div class="card-body">
                                                                              <div class="row px-1">
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="global_lead{{ $submenuItem['slug'] }}"
                                                                                          value="global_lead" checked
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                  </div>
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                          value="view_self_lead"
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                          Self</label>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            @endif
                                                            @if ($submenuItem['name'] == 'Training Planner')
                                                              <div class="row">
                                                                  @foreach(['List','View'] as $action)
                                                                  <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                      <div class="form-check form-check-inline">
                                                                          <?php
                                                                              $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                              $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                              $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                          ?>
                                                                          <input class="form-check-input submenu-action-checkbox"
                                                                              type="checkbox" name="actions[]"
                                                                              id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                              && in_array($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              )) &&
                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              ))]['actionChecked']==1) checked @endif />
                                                                          <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                          data-bs-placement="bottom" title="{{ $action }}"
                                                                              for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                              $action }}</label>
                                                                      </div>
                                                                  </div>
                                                                  @endforeach
                                                                  <div class="col-lg-4 mb-2">
                                                                      <div class="card" style="background-color: #70e2ef !important;">
                                                                          <div class="card-body">
                                                                              <div class="row px-1">
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="global_lead{{ $submenuItem['slug'] }}"
                                                                                          value="global_lead" checked
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                  </div>
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                          value="view_self_lead"
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                          Self</label>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            @endif
                                                            @if ($submenuItem['name'] == 'Manage Events')
                                                              <div class="row">
                                                                  @foreach(['List', 'Export', 'Create Event', 'Filter','Map View','Scanner View','Send Whatsapp','Add Participant','Add Poster', 'View' ,'Edit','Delete'] as $action)
                                                                  <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                      <div class="form-check form-check-inline">
                                                                          <?php
                                                                              $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                              $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                              $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                          ?>
                                                                          <input class="form-check-input submenu-action-checkbox"
                                                                              type="checkbox" name="actions[]"
                                                                              id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                              && in_array($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              )) &&
                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                              array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                              ))]['actionChecked']==1) checked @endif />
                                                                          <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                          data-bs-placement="bottom" title="{{ $action }}"
                                                                              for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                              $action }}</label>
                                                                      </div>
                                                                  </div>
                                                                  @endforeach
                                                                  <div class="col-lg-4 mb-2">
                                                                      <div class="card" style="background-color: #70e2ef !important;">
                                                                          <div class="card-body">
                                                                              <div class="row px-1">
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="global_lead{{ $submenuItem['slug'] }}"
                                                                                          value="global_lead" checked
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                  </div>
                                                                                  <div class="col-lg-6">
                                                                                      <input class="form-check-input" type="radio"
                                                                                          name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                          id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                          value="view_self_lead"
                                                                                          @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                          &&
                                                                                          $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                          checked @endif />
                                                                                      <label class="text-black fs-6 fw-semibold"
                                                                                          for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                          Self</label>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                            @endif
                                                            {{-- Marketing Management end --}}
                                                            {{-- Branch Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Company')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete','Filter'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-bold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-bold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-bold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Entity')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete', 'Filter'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-bold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-bold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-bold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Branch')
                                                                <div class="row">
                                                                    @foreach(['List', 'Add', 'Edit', 'View', 'Delete' ,'Export' ,'Center Head Assign', 'Assign CUG', 'Assign CUG Edit' ,'Add Staff', 'Filter'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                            ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="{{ $action }}"
                                                                                for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                $action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Set Goal')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Update'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #70e2ef !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Target')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Filter','Set Target'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #70e2ef !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Branch Target')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Filter'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #70e2ef !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Branch Campaign')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add Campaign', 'Edit', 'View', 'Delete' ,'Export','Verify Activity', 'Verify Activity Edit'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox"
                                                                                    type="checkbox" name="actions[]"
                                                                                    id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                    && in_array($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    )) &&
                                                                                    $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                    ))]['actionChecked']==1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom" title="{{ $action }}"
                                                                                    for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                    $action }}</label>
                                                                            </div>
                                                                        </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #70e2ef !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                                &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                                checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Training')
                                                                  <div class="row">
                                                                      @foreach(['List', 'Add Training', 'Edit', 'View', 'Delete','Attendance'] as $action)
                                                                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                          <div class="form-check form-check-inline">
                                                                              <?php
                                                                                  $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                  $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                  $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                              ?>
                                                                              <input class="form-check-input submenu-action-checkbox"
                                                                                  type="checkbox" name="actions[]"
                                                                                  id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                  && in_array($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  )) &&
                                                                                  $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  ))]['actionChecked']==1) checked @endif />
                                                                              <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                              data-bs-placement="bottom" title="{{ $action }}"
                                                                                  for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                  $action }}</label>
                                                                          </div>
                                                                      </div>
                                                                      @endforeach
                                                                      <div class="col-lg-4 mb-2">
                                                                          <div class="card" style="background-color: #70e2ef !important;">
                                                                              <div class="card-body">
                                                                                  <div class="row px-1">
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="global_lead{{ $submenuItem['slug'] }}"
                                                                                              value="global_lead" checked
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                      </div>
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                              value="view_self_lead"
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                              Self</label>
                                                                                      </div>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'QR Promotion')
                                                                  <div class="row">
                                                                      @foreach(['List', 'Add', 'Edit', 'Delete','Qr Download'] as $action)
                                                                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                          <div class="form-check form-check-inline">
                                                                              <?php
                                                                                  $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                  $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                  $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                              ?>
                                                                              <input class="form-check-input submenu-action-checkbox"
                                                                                  type="checkbox" name="actions[]"
                                                                                  id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                  && in_array($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  )) &&
                                                                                  $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  ))]['actionChecked']==1) checked @endif />
                                                                              <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                              data-bs-placement="bottom" title="{{ $action }}"
                                                                                  for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                  $action }}</label>
                                                                          </div>
                                                                      </div>
                                                                      @endforeach
                                                                      <div class="col-lg-4 mb-2">
                                                                          <div class="card" style="background-color: #70e2ef !important;">
                                                                              <div class="card-body">
                                                                                  <div class="row px-1">
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="global_lead{{ $submenuItem['slug'] }}"
                                                                                              value="global_lead" checked
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                      </div>
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                              value="view_self_lead"
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                              Self</label>
                                                                                      </div>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'QR Coupon')
                                                                  <div class="row">
                                                                      @foreach(['List', 'Reedem'] as $action)
                                                                      <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                          <div class="form-check form-check-inline">
                                                                              <?php
                                                                                  $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                  $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                  $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                              ?>
                                                                              <input class="form-check-input submenu-action-checkbox"
                                                                                  type="checkbox" name="actions[]"
                                                                                  id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                  @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                  && in_array($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  )) &&
                                                                                  $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                  array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                  ))]['actionChecked']==1) checked @endif />
                                                                              <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip"
                                                                              data-bs-placement="bottom" title="{{ $action }}"
                                                                                  for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{
                                                                                  $action }}</label>
                                                                          </div>
                                                                      </div>
                                                                      @endforeach
                                                                      <div class="col-lg-4 mb-2">
                                                                          <div class="card" style="background-color: #70e2ef !important;">
                                                                              <div class="card-body">
                                                                                  <div class="row px-1">
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="global_lead{{ $submenuItem['slug'] }}"
                                                                                              value="global_lead" checked
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                      </div>
                                                                                      <div class="col-lg-6">
                                                                                          <input class="form-check-input" type="radio"
                                                                                              name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                              id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                              value="view_self_lead"
                                                                                              @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                              &&
                                                                                              $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                              checked @endif />
                                                                                          <label class="text-black fs-6 fw-semibold"
                                                                                              for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                              Self</label>
                                                                                      </div>
                                                                                  </div>
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                @endif
                                                                
                                                            {{-- Branch Management End --}}

                                                            {{-- Sales Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Lead')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add Lead', 'Add Spam' ,'Edit', 'View', 'Followup', 'Delete',  'Import', 'Export','Filter', 'Bulk Transfer', 'Raw Lead','Lead Bank','Lead','Spam Lead','Dead lead','Internal Calls Lead', 'Today Followup','Add Requirement','Add Appoinment','Add Internal Calls'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Lead Appointment')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View', 'Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Followup')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Today Followup', 'Closed Followup' ,'Reschedule Followup', 'UnFollowup'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Lead Requirments')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View' ,'Assign Staff','Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                 @if ($submenuItem['name'] == 'Manage Proposal')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View', 'Filter','Send Proposal','Revised Proposal','Print','Create Invoive','Verify Proposal'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Calls')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Filter', 'Location'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Cloud Call')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Audio'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Coupon')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Usage History', 'Filter', 'Create Coupons', 'Delete','Custom', 'Unlimited', 'Public', 'No Expiry'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Lead Calendar')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Lead Source')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_lead{{ $submenuItem['slug'] }}" value="global_lead" checked
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_lead{{ $submenuItem['slug'] }}" value="view_self_lead"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_lead{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Sales Management End --}}

                                                            {{-- Team Management Start --}}
                                                                @if ($submenuItem['name'] == 'Team Lead')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Set Lead Limit'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Followup')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Appointment')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Call')
                                                                    <div class="row">
                                                                        @foreach(['List','Location'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Cloud Call')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Goal Set')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Team Promise')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Today', 'Comparison'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Team Management End --}}

                                                            {{-- WhatsApp Management Start --}}
                                                                @if ($submenuItem['name'] == 'Lead Chat')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Customer Chat')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif 
                                                                @if ($submenuItem['name'] == 'Unknown Chat')
                                                                    <div class="row">
                                                                        @foreach(['List'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif   
                                                            {{-- WhatsApp Management End --}}

                                                            {{-- Customer Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Customer')
                                                                <div class="row">
                                                                    @foreach(['List', 'Add Service', 'Edit', 'View', 'Payment', 'Pass Locker'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Not Started Customer')
                                                                <div class="row">
                                                                    @foreach(['List', 'View'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Post Sale Customer')
                                                                <div class="row">
                                                                    @foreach(['List', 'View'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Customer Appointment')
                                                                <div class="row">
                                                                    @foreach(['List','Add','Edit','View','Status Change'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Review')
                                                                <div class="row">
                                                                    @foreach(['List','Add','Edit'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Issue')
                                                                <div class="row">
                                                                    @foreach(['List','Add','View','Status Change'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage NDA')
                                                                <div class="row">
                                                                    @foreach(['List', 'View','Print','Download'] as $action)
                                                                        <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                            <div class="form-check form-check-inline">
                                                                                <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                ?>
                                                                                <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                            {{-- Customer Management End --}}
                                                            
                                                            
                                                            {{-- Service Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Services')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Assign Staff', 'Call Confirmation','View'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Deliverables')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Service Management End --}}
                                                            {{-- Production Management Start --}}
                                                                 @if ($submenuItem['name'] == 'Manage Work Order')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add Task', 'Add Requirement', 'View', 'Status Change', 'Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Production')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Task Completed', 'View','Timer','Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_self_production{{ $submenuItem['slug'] }}" id="global_production{{ $submenuItem['slug'] }}" value="global_production"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_production' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_production{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_self_production{{ $submenuItem['slug'] }}" id="view_self_production{{ $submenuItem['slug'] }}" value="view_self_production"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_production{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Task')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Edit', 'View', 'Delete', 'Filter', 'Status Change'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Appointment')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View','Assign Staff', 'Status Change', 'Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Requirments')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View','Assign Staff', 'Status Change', 'Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Production Management End --}}
                                                            
                                                            {{-- Journal Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Journal')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Edit', 'View', 'Subimit Journal'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Journal Booklet')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Filter'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Journal Monitor')
                                                                    <div class="row">
                                                                        @foreach(['List', 'View', 'Status Change'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Journal Management End --}}
                                                            
                                                            {{-- Payment Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Payment')
                                                                <div class="row">
                                                                    @foreach(['List', 'Pay', 'Transactions', 'Low Paid', 'Payment'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Low MPC')
                                                                <div class="row">
                                                                    @foreach(['List'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Payment History')
                                                                <div class="row">
                                                                    @foreach(['List','Status Change', 'Print', 'Send Receipt', 'Download Receipt'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                            {{-- Payment Management End --}}
                                                            
                                                            
                                                            {{-- Product Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Products')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete', 'Status Change', 'Add Variant', 'Edit Variant'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Packages')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete','Status Change'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Add-On')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete', 'Status Change'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Facility')
                                                                    <div class="row">
                                                                        @foreach(['List', 'Add', 'Edit', 'View', 'Delete', 'Status Change'] as $action)
                                                                            <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                        $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                        $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                        $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input class="form-check-input submenu-action-checkbox" type="checkbox" name="actions[]" id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}" value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                    @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) && in_array($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey, array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))]['actionChecked'] == 1) checked @endif />
                                                                                    <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card" style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="global_cus{{ $submenuItem['slug'] }}" value="global_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="global_cus{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input" type="radio" name="view_lead_{{ $submenuItem['slug'] }}" id="view_self_cus{{ $submenuItem['slug'] }}" value="view_self_cus"
                                                                                            @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_cus' && $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label class="text-black fs-6 fw-semibold" for="view_self_cus{{ $submenuItem['slug'] }}">View Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Product Management End --}}
                                                            
                                                            {{-- Support Management Start --}}      
                                                                @if ($submenuItem['name'] == 'View Customer')
                                                                    <div class="row">
                                                                        @foreach (['List', 'Filter', 'Export', 'View'] as $action)
                                                                            <div
                                                                                class="col-lg-2 mb-2 d-flex align-items-center">
                                                                                <div class="form-check form-check-inline">
                                                                                    <?php
                                                                                    $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                    $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                    $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                    ?>
                                                                                    <input
                                                                                        class="form-check-input submenu-action-checkbox"
                                                                                        type="checkbox" name="actions[]"
                                                                                        id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                        value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                        @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions']) &&
                                                                                                in_array(
                                                                                                    $actionKey,
                                                                                                    array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName')) &&
                                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][
                                                                                                    array_search(
                                                                                                        $actionKey,
                                                                                                        array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'))
                                                                                                ]['actionChecked'] == 1) checked @endif />
                                                                                    <label
                                                                                        class="text-black fs-6 fw-semibold text-truncate w-125px"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="{{ $action }}"
                                                                                        for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{ $action }}</label>
                                                                                </div>
                                                                            </div>
                                                                        @endforeach
                                                                        <div class="col-lg-4 mb-2">
                                                                            <div class="card"
                                                                                style="background-color: #e7a368 !important;">
                                                                                <div class="card-body">
                                                                                    <div class="row px-1">
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input"
                                                                                                type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="global_lead{{ $submenuItem['slug'] }}"
                                                                                                value="global_lead" checked
                                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) &&
                                                                                                        $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'global_lead' &&
                                                                                                        $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label
                                                                                                class="text-black fs-6 fw-semibold"
                                                                                                for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                        </div>
                                                                                        <div class="col-lg-6">
                                                                                            <input class="form-check-input"
                                                                                                type="radio"
                                                                                                name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                                id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                                value="view_self_lead"
                                                                                                @if (isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]) &&
                                                                                                        $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue'] == 'view_self_lead' &&
                                                                                                        $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked'] == 1) checked @endif />
                                                                                            <label
                                                                                                class="text-black fs-6 fw-semibold"
                                                                                                for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                                Self</label>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            {{-- Support Management End --}}
                                                            
                                                            {{-- Hr Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Staff')
                                                                <div class="row">
                                                                    @foreach(['List', 'Add',  'Edit', 'View','Filter'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Manage Attendance')
                                                                <div class="row">
                                                                    @foreach(['List', 'Add Attendance', 'Edit', 'View', 'Export', 'Add Monthly Attendance', 'Filter'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                            {{-- Hr Management end --}}

                                                            {{-- Accounts Management Start --}}
                                                                @if ($submenuItem['name'] == 'Daily Accounts')
                                                                <div class="row">
                                                                    @foreach(['List', 'Add account', 'Edit', 'Delete', 'Filter', 'Export'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Profit & Loss')
                                                                <div class="row">
                                                                    @foreach(['List', 'Export'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'Trial Balance')
                                                                <div class="row">
                                                                    @foreach(['List','View', 'Export'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                            {{-- Accounts Management End --}}
                                                            {{-- User Management Start --}}
                                                                @if ($submenuItem['name'] == 'Manage Users')
                                                                <div class="row">
                                                                    @foreach(['List','Add','View','Edit','Delete'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                            ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                                @if ($submenuItem['name'] == 'User Role')
                                                                <div class="row">
                                                                    @foreach(['List','Add','Edit','Delete','Export'] as $action)
                                                                    <div class="col-lg-2 mb-2 d-flex align-items-center">
                                                                        <div class="form-check form-check-inline">
                                                                            <?php
                                                                                                            $menuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $menuItem['name']);
                                                                                                            $submenuKey = preg_replace('/[^a-zA-Z0-9_]/', '', $submenuItem['name']);
                                                                                                            $actionKey = preg_replace('/[^a-zA-Z0-9_]/', '', $action);
                                                                                                        ?>
                                                                            <input class="form-check-input submenu-action-checkbox"
                                                                                type="checkbox" name="actions[]"
                                                                                id="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                value="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}"
                                                                                @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'])
                                                                                && in_array($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                )) &&
                                                                                $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'][array_search($actionKey,
                                                                                array_column($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['actions'], 'actionName'
                                                                                ))]['actionChecked']==1) checked @endif />
                                                                            <label class="text-black fs-6 fw-semibold text-truncate w-125px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $action }}" for="{{ strtolower(str_replace(' ', '_', $action)) }}_{{ $submenuItem['slug'] }}">{{$action }}</label>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                    <div class="col-lg-4 mb-2">
                                                                        <div class="card" style="background-color: #e7a368 !important;">
                                                                            <div class="card-body">
                                                                                <div class="row px-1">
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="global_lead{{ $submenuItem['slug'] }}"
                                                                                            value="global_lead" checked
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='global_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="global_lead{{ $submenuItem['slug'] }}">Global</label>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <input class="form-check-input" type="radio"
                                                                                            name="view_lead_{{ $submenuItem['slug'] }}"
                                                                                            id="view_self_lead{{ $submenuItem['slug'] }}"
                                                                                            value="view_self_lead"
                                                                                            @if(isset($flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0])
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['radioValue']=='view_self_lead'
                                                                                            &&
                                                                                            $flattenedPermissions[$menuKey]['submenu'][$submenuKey]['radios'][0]['checked']==1)
                                                                                            checked @endif />
                                                                                        <label class="text-black fs-6 fw-semibold"
                                                                                            for="view_self_lead{{ $submenuItem['slug'] }}">View
                                                                                            Self</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endif
                                                            {{-- User Management End --}}
                                                          {{-- Vasanth --}}
                                                        </div>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
          </div>

          <div class="d-flex justify-content-end align-items-center mt-4 mb-4 px-3">
            <a href="/users/manage_users" class="btn btn-secondary me-3">Cancel</a>
            <a href="javascript:;" class="btn btn-primary" id="submitForm" >Update Manage Users</a>
          </div>
      </div>
  </form>
    <div class="modal fade" id="kt_modal_confirm_create_manage_users" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
      <div class="modal-dialog modal-m">
        <div class="modal-content rounded">
          <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
            <div class="swal2-icon-content">?</div>
          </div>
          <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Update Manage Users ?
            <div class="d-block fw-bold fs-5 py-2 text-danger">
              <label id="role_confirm"></label>
              <!--<div id="permissions_confirm">Permissions: </div>-->
            </div>
          </div>
          <div class="d-flex justify-content-center align-items-center pt-8">
            <a href="javascript:;" type="button" class="btn btn-primary" id="confirmSubmit">Yes</a>&nbsp;
            <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
          </div><br><br>
        </div>
      </div>
    </div>


  </div>

<div class="modal fade" id="kt_modal_confirm_create_manage_users" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <div class="modal-dialog modal-m">


          <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
              <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Create Manage Users ?
              <div class="d-block fw-bold fs-5 py-2 text-danger">
                <label id="role_confirm"></label>
                {{-- <span class="ms-2 me-2">-</span> --}}
                <!--<div id="permissions_confirm">Permissions: </div>-->
                {{-- <label id="branch_confirm"></label>
                <label id="franchise_confirm"></label> --}}
              </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
              <a href="javascript:;" type="button" class="btn btn-primary" id="confirmSubmit">Yes</a>&nbsp;
              <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div><br><br>
          </div>

  </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>

 /* Customize Toastr notification */
 .toast-success {
            background-color: green;
        }
  .toast-error {
      background-color: red;
  }
  .error_msg {
      border: solid 2px red !important;
      border-color: red !important;
  }
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif


</script>

<script>
$(document).ready(function() {
    // Handle the "Select All" checkbox
    $('#selectAllMain').on('change', function() {
        $('.menu-checkbox').prop('checked', $(this).prop('checked')).trigger('change');
    });

    // Handle the submenu checkboxes based on the parent menu checkbox
    $('.menu-checkbox').on('change', function() {
        let menuSlug = $(this).attr('id');
        $(`#collapseMenu${menuSlug} .submenu-checkbox`).prop('checked', $(this).prop('checked')).trigger('change');
    });

    // Handle the submenu checkboxes
    $('.submenu-checkbox').on('change', function() {
        let submenuSlug = $(this).attr('id');
        $(`#collapseSubmenu${submenuSlug} .submenu-action-checkbox`).prop('checked', $(this).prop('checked'));
    });

    // Handle the submenu action checkboxes
    $('.submenu-action-checkbox').on('change', function() {
        let actionSlug = $(this).attr('id').split('_')[0];
        if ($(this).prop('checked')) {
            $(this).val(`${actionSlug}_checked`);
        } else {
            $(this).val(`${actionSlug}_unchecked`);
        }
    });
});

// $(document).ready(function() {
//   // Handle the "Select All" checkbox
//   $('#selectAllMain').on('change', function() {
//       const isChecked = $(this).prop('checked');
//       $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox, .radio-input').prop('checked', isChecked).trigger('change');
//   });

//   // Handle the menu checkboxes
//   $('.menu-checkbox').on('change', function() {
//       const menuSlug = $(this).attr('id');
//       const isChecked = $(this).prop('checked');
//       $(`#collapseMenu${menuSlug} .submenu-checkbox, #collapseMenu${menuSlug} .submenu-action-checkbox, #collapseMenu${menuSlug} .radio-input`).prop('checked', isChecked).trigger('change');
//   });

//   // Handle the submenu checkboxes
//   $('.submenu-checkbox').on('change', function() {
//       const submenuSlug = $(this).attr('id');
//       const isChecked = $(this).prop('checked');
//       $(`#collapseSubmenu${submenuSlug} .submenu-action-checkbox, #collapseSubmenu${submenuSlug} .radio-input`).prop('checked', isChecked);
//   });

//   // Handle the submenu action checkboxes
//   $('.submenu-action-checkbox').on('change', function() {
//       const actionSlug = $(this).attr('id').split('_')[0];
//       if ($(this).prop('checked')) {
//           $(this).val(`${actionSlug}_checked`);
//       } else {
//           $(this).val(`${actionSlug}_unchecked`);
//       }
//   });

//   // Handle the radio buttons
//   $('.radio-input').on('change', function() {
//       const radioName = $(this).attr('name');
//       $(`input[name=${radioName}]`).not(this).prop('checked', false);
//   });

//   // Initialize checkboxes and radio buttons based on the permissions data
//   function initializePermissions(permissions) {
//       for (const [menu, data] of Object.entries(permissions)) {
//           if (data.actions) {
//               data.actions.forEach(action => {
//                   const checkbox = $(`#${menu}_${action.actionName.replace(/\s+/g, '_')}`);
//                   if (checkbox.length) {
//                       checkbox.prop('checked', action.actionChecked === 1);
//                   }
//               });
//           }
//           if (data.radios) {
//               data.radios.forEach(radio => {
//                   const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                   if (radioButton.length) {
//                       radioButton.prop('checked', radio.checked === 1);
//                   }
//               });
//           }
//           if (data.submenu) {
//               for (const [submenu, submenuData] of Object.entries(data.submenu)) {
//                   if (submenuData.actions) {
//                       submenuData.actions.forEach(action => {
//                           const checkbox = $(`#${menu}_${submenu}_${action.actionName.replace(/\s+/g, '_')}`);
//                           if (checkbox.length) {
//                               checkbox.prop('checked', action.actionChecked === 1);
//                           }
//                       });
//                   }
//                   if (submenuData.radios) {
//                       submenuData.radios.forEach(radio => {
//                           const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                           if (radioButton.length) {
//                               radioButton.prop('checked', radio.checked === 1);
//                           }
//                       });
//                   }
//               }
//           }
//       }

//       // Check if all checkboxes are checked to initialize the "Select All" checkbox
//       const allChecked = $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox, .radio-input').length === $('.menu-checkbox:checked, .submenu-checkbox:checked, .submenu-action-checkbox:checked, .radio-input:checked').length;
//       $('#selectAllMain').prop('checked', allChecked);
//   }




//   // Call the function to initialize the checkboxes and radio buttons
//   initializePermissions(permissions);
// });

// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);
//                     }
//                 });
//             }
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);
//                     }
//                 });
//             }
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Check if all checkboxes are checked to initialize the "Select All" checkbox
//         const allChecked = $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').length === $('.menu-checkbox:checked, .submenu-checkbox:checked, .submenu-action-checkbox:checked').length;
//         $('#selectAllMain').prop('checked', allChecked);
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);
//                     }
//                 });
//             }
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);
//                     }
//                 });
//             }
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     const submenuCheckbox = $(`#${submenu}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     }

//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${submenu}_${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Check if all checkboxes are checked to initialize the "Select All" checkbox
//         const allChecked = $('.menu-checkbox:checked, .submenu-checkbox:checked, .submenu-action-checkbox:checked').length === $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').length;
//         $('#selectAllMain').prop('checked', allChecked);
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     initializePermissions(permissions);
// });

// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);
//                     }
//                 });
//             }
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);
//                     }
//                 });
//             }
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${menu}_${submenu}_${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Check if all checkboxes are checked to initialize the "Select All" checkbox
//         const allChecked = $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').length === $('.menu-checkbox:checked, .submenu-checkbox:checked, .submenu-action-checkbox:checked').length;
//         $('#selectAllMain').prop('checked', allChecked);
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);
//                     }
//                 });
//             }
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);
//                     }
//                 });
//             }
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${menu}_${submenu}_${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         document.querySelectorAll('.submenu-checkbox').forEach(checkbox => {
//             checkbox.addEventListener('change', function () {
//                 const isChecked = checkbox.checked;
//                 const submenu = document.querySelector(`#collapseSubmenu${checkbox.id}`);
//                 if (submenu) {
//                     isChecked ? $(submenu).collapse('show') : $(submenu).collapse('hide');
//                 }
//             });
//         });

//         // Handle Submenu Action Checkbox Changes
//         document.querySelectorAll('.submenu-action-checkbox').forEach(checkbox => {
//             checkbox.addEventListener('change', function () {
//                 // Handle checkbox state changes here
//             });
//         });
//         // Check if all checkboxes are checked to initialize the "Select All" checkbox
//         const allChecked = $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').length === $('.menu-checkbox:checked, .submenu-checkbox:checked, .submenu-action-checkbox:checked').length;
//         $('#selectAllMain').prop('checked', allChecked);
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     initializePermissions(permissions);

//     // Handle "Select All" functionality
//     $('#selectAllMain').change(function() {
//         const isChecked = $(this).is(':checked');
//         $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//     });

//     // Handle individual menu checkbox changes
//     $('.menu-checkbox').change(function() {
//         const menuSlug = $(this).attr('id');
//         const isChecked = $(this).is(':checked');
//         $(`.submenu-checkbox[id^="${menuSlug}"]`).prop('checked', isChecked);
//         $(`.submenu-action-checkbox[id^="${menuSlug}_"]`).prop('checked', isChecked);
//     });

//     // Handle individual submenu checkbox changes
//     $('.submenu-checkbox').change(function() {
//         const submenuSlug = $(this).attr('id');
//         const isChecked = $(this).is(':checked');
//         $(`.submenu-action-checkbox[id^="${submenuSlug}_"]`).prop('checked', isChecked);
//     });
// });

// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             // Set the main menu checkbox based on data
//             const menuCheckbox = $(`#${menu}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.checked === 1);
//             }

//             // Handle actions for the menu
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);
//                     }
//                 });
//             }

//             // Handle radio buttons for the menu
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${menu}_${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);
//                     }
//                 });
//             }

//             // Handle submenus
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     const submenuCheckbox = $(`#${submenu}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.checked === 1);
//                     }

//                     // Handle actions for the submenu
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }

//                     // Handle radio buttons for the submenu
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${menu}_${submenu}_${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }

//                     // Collapse submenu based on its checkbox state
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.change(function () {
//                             const isChecked = $(this).is(':checked');
//                             $(`#collapseSubmenu${submenu}`).collapse(isChecked ? 'show' : 'hide');
//                         });
//                         submenuCheckbox.trigger('change');
//                     }
//                 });
//             }

//             // Collapse the main menu based on the main menu checkbox state
//             menuCheckbox.change(function() {
//                 const isChecked = $(this).is(':checked');
//                 $(`#collapseMenu${menu}`).collapse(isChecked ? 'show' : 'hide');
//             });
//             menuCheckbox.trigger('change');
//         });

//         // Handle "Select All" functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         // Handle individual menu checkbox changes
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-checkbox[id^="${menuSlug}"]`).prop('checked', isChecked).trigger('change');
//             $(`.submenu-action-checkbox[id^="${menuSlug}_"]`).prop('checked', isChecked);
//         });

//         // Handle individual submenu checkbox changes
//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-action-checkbox[id^="${submenuSlug}_"]`).prop('checked', isChecked);
//         });
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             // Set the main menu checkbox based on data
//             const menuCheckbox = $(`#${menu}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);  // Fixed to use `menuChecked`
//             }

//             // Handle actions for the menu
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);  // Fixed to use `actionChecked`
//                     }
//                 });
//             }

//             // Handle radio buttons for the menu
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${menu}_${radio.radioName}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);  // Fixed to use `checked`
//                     }
//                 });
//             }

//             // Handle submenus
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     const submenuCheckbox = $(`#${submenu}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);  // Fixed to use `submenuChecked`
//                     }

//                     // Handle actions for the submenu
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenu}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);  // Fixed to use `actionChecked`
//                             }
//                         });
//                     }

//                     // Handle radio buttons for the submenu
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${menu}_${submenu}_${radio.radioName}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);  // Fixed to use `checked`
//                             }
//                         });
//                     }

//                     // Collapse submenu based on its checkbox state
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.change(function () {
//                             const isChecked = $(this).is(':checked');
//                             $(`#collapseSubmenu${submenu}`).collapse(isChecked ? 'show' : 'hide');
//                         });
//                         submenuCheckbox.trigger('change');
//                     }
//                 });
//             }

//             // Collapse the main menu based on the main menu checkbox state
//             menuCheckbox.change(function() {
//                 const isChecked = $(this).is(':checked');
//                 $(`#collapseMenu${menu}`).collapse(isChecked ? 'show' : 'hide');
//             });
//             menuCheckbox.trigger('change');
//         });

//         // Handle "Select All" functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         // Handle individual menu checkbox changes
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-checkbox[id^="${menuSlug}"]`).prop('checked', isChecked).trigger('change');
//             $(`.submenu-action-checkbox[id^="${menuSlug}_"]`).prop('checked', isChecked);
//         });

//         // Handle individual submenu checkbox changes
//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-action-checkbox[id^="${submenuSlug}_"]`).prop('checked', isChecked);
//         });
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     // Initialize permissions based on data
//     function initializePermissions(permissions) {
//         // Iterate over each menu
//         $.each(permissions, function(menu, data) {
//             // Set the main menu checkbox based on data
//             const menuCheckbox = $(`#${menu}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);  // Fixed to use `menuChecked`
//             }

//             // Handle actions for the menu
//             if (data.actions) {
//                 data.actions.forEach(action => {
//                     const actionName = action.actionName.replace(/\s+/g, '_');
//                     const checkbox = $(`#${menu}_${actionName}`);
//                     if (checkbox.length) {
//                         checkbox.prop('checked', action.actionChecked === 1);  // Fixed to use `actionChecked`
//                     }
//                 });
//             }

//             // Handle radio buttons for the menu
//             if (data.radios) {
//                 data.radios.forEach(radio => {
//                     const radioButton = $(`#${menu}_${radio.radioValue}`);
//                     if (radioButton.length) {
//                         radioButton.prop('checked', radio.checked === 1);  // Fixed to use `checked`
//                     }
//                 });
//             }

//             // Handle submenus
//             if (data.submenu) {
//                 $.each(data.submenu, function(submenu, submenuData) {
//                     const submenuCheckbox = $(`#${submenuData.slug}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);  // Fixed to use `submenuChecked`
//                     }

//                     // Handle actions for the submenu
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${menu}_${submenuData.slug}_${actionName}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);  // Fixed to use `actionChecked`
//                             }
//                         });
//                     }

//                     // Handle radio buttons for the submenu
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${menu}_${submenuData.slug}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);  // Fixed to use `checked`
//                             }
//                         });
//                     }

//                     // Collapse submenu based on its checkbox state
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.change(function () {
//                             const isChecked = $(this).is(':checked');
//                             $(`#collapseSubmenu${submenuData.slug}`).collapse(isChecked ? 'show' : 'hide');
//                         });
//                         submenuCheckbox.trigger('change');
//                     }
//                 });
//             }

//             // Collapse the main menu based on the main menu checkbox state
//             menuCheckbox.change(function() {
//                 const isChecked = $(this).is(':checked');
//                 $(`#collapseMenu${menu}`).collapse(isChecked ? 'show' : 'hide');
//             });
//             menuCheckbox.trigger('change');
//         });

//         // Handle "Select All" functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         // Handle individual menu checkbox changes
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-checkbox[id^="${menuSlug}"]`).prop('checked', isChecked).trigger('change');
//             $(`.submenu-action-checkbox[id^="${menuSlug}_"]`).prop('checked', isChecked);
//         });

//         // Handle individual submenu checkbox changes
//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`.submenu-action-checkbox[id^="${submenuSlug}_"]`).prop('checked', isChecked);
//         });
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });

// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         $.each(permissions, function(menu, data) {
//             const menuCheckbox = $(`#${menu}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     const submenuCheckbox = $(`#${submenuData.slug}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     }

//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${actionName}_${submenuData.slug}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }

//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${submenuData.slug}_${radio.radioValue}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     console.log('Menu Data:', permissions[menu]);
//     console.log('Submenu Data:', permissions[menu][submenuName]);
//     console.log('Submenu Checkbox:', $(`#${submenuData.slug}`));
//     console.log('Action Checkbox:', $(`#${actionName}_${submenuData.slug}`));
//     console.log('Radio Button:', $(`#${radio['radioValue']}_${submenuData.slug}`));

//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         console.log('Starting to initialize permissions...');
//         $.each(permissions, function(menuName, data) {
//             console.log('Menu:', menuName, data);

//             const menuCheckbox = $(`#${menuName}`);
//             console.log('Menu Checkbox:', menuCheckbox);  // Debugging statement
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     console.log('Submenu:', submenuName, submenuData);  // Debugging statement

//                     const submenuCheckbox = $(`#${submenuData.slug}`);
//                     console.log('Submenu Checkbox:', submenuCheckbox);  // Debugging statement
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     }

//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${actionName}_${submenuData.slug}`);
//                             console.log('Action Checkbox:', checkbox);  // Debugging statement
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             }
//                         });
//                     }

//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioValue}_${submenuData.slug}`);
//                             console.log('Radio Button:', radioButton);  // Debugging statement
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             }
//                         });
//                     }
//                 });
//             }
//         });
//     }

//     // Example of how to call the initializePermissions function
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);

//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         if (!permissions) {
//             console.error('No permissions data provided');
//             return;
//         }

//         console.log('Starting to initialize permissions...');
//         $.each(permissions, function(menuName, data) {
//             console.log('Menu:', menuName, data);

//             // Check if menuName exists in the permissions data
//             const menuCheckbox = $(`#${menuName}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             } else {
//                 console.warn(`Checkbox for menu "${menuName}" not found.`);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     console.log('Submenu:', submenuName, submenuData);

//                     // Ensure submenuData has a slug
//                     const submenuCheckbox = $(`#${submenuName.replace(/\s+/g, '_')}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     } else {
//                         console.warn(`Checkbox for submenu "${submenuName}" not found.`);
//                     }

//                     // Handle submenu actions
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/\s+/g, '_');
//                             const checkbox = $(`#${actionName}_${submenuName.replace(/\s+/g, '_')}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             } else {
//                                 console.warn(`Checkbox for action "${actionName}_${submenuName.replace(/\s+/g, '_')}" not found.`);
//                             }
//                         });
//                     }

//                     // Handle submenu radios
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioValue}_${submenuName.replace(/\s+/g, '_')}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             } else {
//                                 console.warn(`Radio button for "${radio.radioValue}_${submenuName.replace(/\s+/g, '_')}" not found.`);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Ensure menu and submenu checkboxes affect their collapsible states
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseMenu${menuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseSubmenu${submenuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         // Select All functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         $('.menu-checkbox').each(function() {
//             $(this).trigger('change');
//         });

//         $('.submenu-checkbox').each(function() {
//             $(this).trigger('change');
//         });
//     }


//     // Call initializePermissions function with correct data
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });
// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         if (!permissions) {
//             console.error('No permissions data provided');
//             return;
//         }

//         console.log('Starting to initialize permissions...');
//         $.each(permissions, function(menuName, data) {
//             console.log('Menu:', menuName, data);

//             // Escape special characters for IDs
//             const menuSlug = menuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//             const menuCheckbox = $(`#${menuSlug}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             } else {
//                 console.warn(`Checkbox for menu "${menuName}" not found.`);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     console.log('Submenu:', submenuName, submenuData);

//                     // Escape special characters for IDs
//                     const submenuSlug = submenuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                     const submenuCheckbox = $(`#${submenuSlug}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     } else {
//                         console.warn(`Checkbox for submenu "${submenuName}" not found.`);
//                     }

//                     // Handle submenu actions
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                             const checkbox = $(`#${actionName}_${submenuSlug}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             } else {
//                                 console.warn(`Checkbox for action "${actionName}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }

//                     // Handle submenu radios
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioValue}_${submenuSlug}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             } else {
//                                 console.warn(`Radio button for "${radio.radioValue}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Ensure menu and submenu checkboxes affect their collapsible states
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseMenu${menuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseSubmenu${submenuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         // Select All functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         $('.menu-checkbox').each(function() {
//             $(this).trigger('change');
//         });

//         $('.submenu-checkbox').each(function() {
//             $(this).trigger('change');
//         });
//     }


//     // Call initializePermissions function with correct data
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });


// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         if (!permissions) {
//             console.error('No permissions data provided');
//             return;
//         }

//         console.log('Starting to initialize permissions...');
//         $.each(permissions, function(menuName, data) {
//             console.log('Menu:', menuName, data);

//             // Escape special characters for IDs
//             const menuSlug = menuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//             const menuCheckbox = $(`#${menuSlug}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             } else {
//                 console.warn(`Checkbox for menu "${menuName}" not found.`);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     console.log('Submenu:', submenuName, submenuData);

//                     // Escape special characters for IDs
//                     const submenuSlug = submenuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                     const submenuCheckbox = $(`#${submenuSlug}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     } else {
//                         console.warn(`Checkbox for submenu "${submenuName}" not found.`);
//                     }

//                     // Handle submenu actions
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                             const checkbox = $(`#${actionName}_${submenuSlug}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             } else {
//                                 console.warn(`Checkbox for action "${actionName}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }

//                     // Handle submenu radios
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioValue}_${submenuSlug}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             } else {
//                                 console.warn(`Radio button for "${radio.radioValue}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Ensure menu and submenu checkboxes affect their collapsible states
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseMenu${menuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseSubmenu${submenuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         // Select All functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         $('.menu-checkbox').each(function() {
//             $(this).trigger('change');
//         });

//         $('.submenu-checkbox').each(function() {
//             $(this).trigger('change');
//         });
//     }

//     // Call initializePermissions function with correct data
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });

// $(document).ready(function() {
//     function initializePermissions(permissions) {
//         if (!permissions) {
//             console.error('No permissions data provided');
//             return;
//         }

//         console.log('Starting to initialize permissions...');
//         $.each(permissions, function(menuName, data) {
//             console.log('Processing Menu:', menuName, data);

//             // Escape special characters for IDs
//             const menuSlug = menuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//             const menuCheckbox = $(`#${menuSlug}`);
//             if (menuCheckbox.length) {
//                 menuCheckbox.prop('checked', data.menuChecked === 1);
//             } else {
//                 console.warn(`Checkbox for menu "${menuName}" not found.`);
//             }

//             if (data.submenu) {
//                 $.each(data.submenu, function(submenuName, submenuData) {
//                     console.log('Processing Submenu:', submenuName, submenuData);

//                     // Escape special characters for IDs
//                     const submenuSlug = submenuName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                     const submenuCheckbox = $(`#${submenuSlug}`);
//                     if (submenuCheckbox.length) {
//                         submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                     } else {
//                         console.warn(`Checkbox for submenu "${submenuName}" not found.`);
//                     }

//                     // Handle submenu actions
//                     if (submenuData.actions) {
//                         submenuData.actions.forEach(action => {
//                             const actionName = action.actionName.replace(/[\s&]/g, '_').replace(/[^\w\-]/g, '');
//                             const checkbox = $(`#${actionName}_${submenuSlug}`);
//                             if (checkbox.length) {
//                                 checkbox.prop('checked', action.actionChecked === 1);
//                             } else {
//                                 console.warn(`Checkbox for action "${actionName}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }

//                     // Handle submenu radios
//                     if (submenuData.radios) {
//                         submenuData.radios.forEach(radio => {
//                             const radioButton = $(`#${radio.radioValue}_${submenuSlug}`);
//                             if (radioButton.length) {
//                                 radioButton.prop('checked', radio.checked === 1);
//                             } else {
//                                 console.warn(`Radio button for "${radio.radioValue}_${submenuSlug}" not found.`);
//                             }
//                         });
//                     }
//                 });
//             }
//         });

//         // Ensure menu and submenu checkboxes affect their collapsible states
//         $('.menu-checkbox').change(function() {
//             const menuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseMenu${menuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         $('.submenu-checkbox').change(function() {
//             const submenuSlug = $(this).attr('id');
//             const isChecked = $(this).is(':checked');
//             $(`#collapseSubmenu${submenuSlug}`).collapse(isChecked ? 'show' : 'hide');
//         });

//         // Select All functionality
//         $('#selectAllMain').change(function() {
//             const isChecked = $(this).is(':checked');
//             $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//             $('.menu-checkbox').trigger('change');
//         });

//         $('.menu-checkbox').each(function() {
//             $(this).trigger('change');
//         });

//         $('.submenu-checkbox').each(function() {
//             $(this).trigger('change');
//         });
//     }

//     // Call initializePermissions function with correct data
//     const permissions = @json($flattenedPermissions);
//     console.log('Permissions Data:', permissions);
//     initializePermissions(permissions);
// });

//  $(document).ready(function() {
//      function initializePermissions(permissions) {
//          console.log('Starting to initialize permissions...');
//          $.each(permissions, function(menuName, menuData) {
//               Process menu checkbox
//              const menuSlug = menuName.replace(/\s+/g, '_').replace(/[^\w\-]/g, '');
//              const menuCheckbox = $(`#${menuSlug}`);
//              if (menuCheckbox.length) {
//                  menuCheckbox.prop('checked', menuData.menuChecked === 1);
//              } else {
//                  console.warn(`Menu checkbox for "${menuName}" not found.`);
//              }

//             //   Process submenu
//              if (menuData.submenu) {
//                  $.each(menuData.submenu, function(submenuName, submenuData) {
//                      const submenuSlug = submenuName.replace(/\s+/g, '_').replace(/[^\w\-]/g, '');
//                      const submenuCheckbox = $(`#${submenuSlug}`);
//                      if (submenuCheckbox.length) {
//                          submenuCheckbox.prop('checked', submenuData.submenuChecked === 1);
//                      } else {
//                          console.warn(`Submenu checkbox for "${submenuName}" not found.`);
//                      }

//                      if (submenuData.actions) {
//                          $.each(submenuData.actions, function(index, action) {
//                              const actionName = action.actionName.replace(/\s+/g, '_').replace(/[^\w\-]/g, '');
//                              const actionCheckbox = $(`#${actionName}_${submenuSlug}`);
//                              if (actionCheckbox.length) {
//                                  actionCheckbox.prop('checked', action.actionChecked === 1);
//                              } else {
//                                  console.warn(`Checkbox for action "${actionName}_${submenuSlug}" not found.`);
//                              }
//                          });
//                      }

//                      if (submenuData.radios) {
//                          $.each(submenuData.radios, function(index, radio) {
//                              const radioButton = $(`#${radio.radioValue}_${submenuSlug}`);
//                              if (radioButton.length) {
//                                  radioButton.prop('checked', radio.checked === 1);
//                              } else {
//                                  console.warn(`Radio button for "${radio.radioValue}_${submenuSlug}" not found.`);
//                              }
//                          });
//                      }
//                  });
//              }
//          });

//         //   Set up event handlers
//          $('.menu-checkbox').change(function() {
//              const menuSlug = $(this).attr('id');
//              const isChecked = $(this).is(':checked');
//              $(`#collapseMenu${menuSlug}`).collapse(isChecked ? 'show' : 'hide');
//          });

//          $('.submenu-checkbox').change(function() {
//              const submenuSlug = $(this).attr('id');
//              const isChecked = $(this).is(':checked');
//              $(`#collapseSubmenu${submenuSlug}`).collapse(isChecked ? 'show' : 'hide');
//          });

//          $('#selectAllMain').change(function() {
//              const isChecked = $(this).is(':checked');
//              $('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').prop('checked', isChecked);
//              $('.menu-checkbox').trigger('change');
//          });

//          $('.menu-checkbox').each(function() {
//              $(this).trigger('change');
//          });

//          $('.submenu-checkbox').each(function() {
//              $(this).trigger('change');
//          });
//      }

//      const permissions = @json($flattenedPermissions);
//      console.log('Permissions Data:', permissions);
//      initializePermissions(permissions);
//  });




</script>



<script>


  // here branch is no use
//   document.addEventListener('DOMContentLoaded', function() {
//       $('#submitForm').on('click', function() {
//           // Gather form data
//           const branchType = $('#branch_type').val();
//           const branch = $('#branch').val();
//           const franchise = $('#franchise').val();
//           const role = $('#role').val();
//           const roleName = $('#role option:selected').text();
//           let branchName = '';
//           let franchiseName = '';

//           if (branchType === 'branch') {
//               branchName = $('#branch option:selected').text();
//           } else if (branchType === 'franchise') {
//               franchiseName = $('#franchise option:selected').text();
//           }

//           let permissions = [];
//           $('.menu-checkbox').each(function() {
//               if ($(this).is(':checked')) {
//                   const menuName = $(this).next('label').text();
//                   const submenu = [];
//                   $(this).closest('.card-header').siblings('.collapse').find('.submenu-checkbox').each(function() {
//                       if ($(this).is(':checked')) {
//                           const submenuName = $(this).next('label').text();
//                           const actions = [];
//                           $(this).closest('.card-header').siblings('.collapse').find('.form-check input:checkbox').each(function() {
//                               if ($(this).is(':checked')) {
//                                   actions.push($(this).next('label').text());
//                               }
//                           });
//                           submenu.push({ name: submenuName, actions });
//                       }
//                   });
//                   if (submenu.length > 0) {
//                       permissions.push({ menu: menuName, submenu });
//                   } else {
//                       // No submenus, just actions
//                       const actions = [];
//                       $(this).closest('.card-header').siblings('.collapse').find('.form-check input:checkbox').each(function() {
//                           if ($(this).is(':checked')) {
//                               actions.push($(this).next('label').text());
//                           }
//                       });
//                       if (actions.length > 0) {
//                           permissions.push({ menu: menuName, actions });
//                       }
//                   }
//               }
//           });

//           console.log('Permissions:', permissions);
//           console.log('Permissions:', JSON.stringify(permissions));

//           $('#role_confirm').text('Role: ' + roleName);
//           $('#branch_confirm').text(branchType === 'branch' ? 'Branch: ' + branchName : '');
//           $('#franchise_confirm').text(branchType === 'franchise' ? 'Franchise: ' + franchiseName : '');
//           $('#permissions_confirm').text('Permissions: ' + JSON.stringify(permissions));

//           $('#kt_modal_confirm_create_manage_users').modal('show');

//           $('#confirmSubmit').off('click').on('click', function() {
//               $('#userRolePermissionForm input[name="permissions"]').remove();
//               $('#userRolePermissionForm').append($('<input>').attr({
//                   type: 'hidden',
//                   name: 'permissions',
//                   value: JSON.stringify(permissions)
//               }));
//               $('#userRolePermissionForm').submit();
//           });
//       });


//   });

document.addEventListener('DOMContentLoaded', function() {
    $('#submitForm').on('click', function() {
        // Gather form data
        const branchType = $('#branch_type').val();
        const branch = $('#branch').val();
        const franchise = $('#franchise').val();
        const role = $('#role').val();
        const manage_branch = $('#manage_branch').val();
        const roleName = $('#role option:selected').text();
        let branchName = '';
        let franchiseName = '';

        if (branchType === 'branch') {
            branchName = $('#branch option:selected').text();
        } else if (branchType === 'franchise') {
            franchiseName = $('#franchise option:selected').text();
        }

        let permissions = [];

        $('.menu-checkbox').each(function() {
            const menuName = $(this).next('label').text();
            const menuChecked = $(this).is(':checked') ? 1 : 0;
            const submenu = [];
            const actions = [];
            const radios = [];

            $(this).closest('.card-header').siblings('.collapse').find('.submenu-checkbox').each(function() {
                const submenuName = $(this).next('label').text();
                const submenuChecked = $(this).is(':checked') ? 1 : 0;
                const actions = [];
                const submenuRadios = [];

                $(this).closest('.card-header').siblings('.collapse').find('.submenu-action-checkbox').each(function() {
                    const actionName = $(this).next('label').text();
                    const actionChecked = $(this).is(':checked') ? 1 : 0;
                    actions.push({ actionName, actionChecked });
                });

                $(this).closest('.card-header').siblings('.collapse').find('input[type="radio"]:checked').each(function() {
                    const radioName = $(this).attr('name');
                    const radioValue = $(this).val();
                    submenuRadios.push({ radioName, radioValue, checked: 1 });
                });

                if (submenuChecked || actions.length > 0 || submenuRadios.length > 0) {
                    submenu.push({ submenuName, submenuChecked, actions, radios: submenuRadios });
                }
            });

            if (menuName === 'Dashboard') {
                $(this).closest('.card-header').siblings('.collapse').find('.submenu-action-checkbox').each(function() {
                    const actionName = $(this).next('label').text();
                    const actionChecked = $(this).is(':checked') ? 1 : 0;
                    actions.push({ actionName, actionChecked });
                });

                $(this).closest('.card-header').siblings('.collapse').find('input[type="radio"]:checked').each(function() {
                    const radioName = $(this).attr('name');
                    const radioValue = $(this).val();
                    radios.push({ radioName, radioValue, checked: 1 });
                });

                permissions.push({ menuName, menuChecked, actions, radios });
            } else {
                if (menuChecked || submenu.length > 0) {
                    permissions.push({ menuName, menuChecked, submenu });
                }
            }
        });

        console.log('Permissions:', permissions);
        console.log('Permissions:', JSON.stringify(permissions));

        $('#role_confirm').text('Role: ' + roleName);
        $('#branch_confirm').text(branchType === 'branch' ? 'Branch: ' + branchName : '');
        $('#franchise_confirm').text(branchType === 'franchise' ? 'Franchise: ' + franchiseName : '');
        // $('#permissions_confirm').text('Permissions: ' + JSON.stringify(permissions));

        $('#kt_modal_confirm_create_manage_users').modal('show');

        $('#confirmSubmit').off('click').on('click', function() {
            $('#userRolePermissionForm input[name="permissions"]').remove();
            $('#userRolePermissionForm').append($('<input>').attr({
                type: 'hidden',
                name: 'permissions',
                value: JSON.stringify(permissions)
            }));
            $('#userRolePermissionForm').submit();
        });
    });

    // Handle select all
    document.getElementById('selectAllMain').addEventListener('change', (event) => {
        const isChecked = event.target.checked;
        document.querySelectorAll('.menu-checkbox').forEach(checkbox => checkbox.checked = isChecked);
        document.querySelectorAll('.submenu-checkbox').forEach(checkbox => checkbox.checked = isChecked);
        document.querySelectorAll('.submenu-action-checkbox').forEach(checkbox => checkbox.checked = isChecked);
        checkSelectAllStatus();  // Update the main select all checkbox status
    });

    // Handle checkbox changes
    document.querySelectorAll('.menu-checkbox, .submenu-checkbox, .submenu-action-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', checkSelectAllStatus);
    });

    function checkSelectAllStatus() {
        const allChecked = Array.from(document.querySelectorAll('.menu-checkbox')).every(checkbox => checkbox.checked) &&
                           Array.from(document.querySelectorAll('.submenu-checkbox')).every(checkbox => checkbox.checked) &&
                           Array.from(document.querySelectorAll('.submenu-action-checkbox')).every(checkbox => checkbox.checked);
        document.getElementById('selectAllMain').checked = allChecked;
    }
});

  document.addEventListener('DOMContentLoaded', (event) => {
    const selectAllCheckbox = document.getElementById('selectAllMain');
    const menuCheckboxes = document.querySelectorAll('.menu-checkbox');
    const submenuCheckboxes = document.querySelectorAll('.submenu-checkbox');
    const submenuActionCheckboxes = document.querySelectorAll('.submenu-action-checkbox');

    // Handle select all
    selectAllCheckbox.addEventListener('change', (event) => {
        const isChecked = event.target.checked;
        menuCheckboxes.forEach(checkbox => checkbox.checked = isChecked);
        submenuCheckboxes.forEach(checkbox => checkbox.checked = isChecked);
        submenuActionCheckboxes.forEach(checkbox => checkbox.checked = isChecked);
    });

    // Handle menu checkbox change
    menuCheckboxes.forEach(menuCheckbox => {
        menuCheckbox.addEventListener('change', () => {
            checkSelectAllStatus();
        });
    });

    // Handle submenu checkbox change
    submenuCheckboxes.forEach(submenuCheckbox => {
        submenuCheckbox.addEventListener('change', () => {
            checkSelectAllStatus();
        });
    });

    // Handle submenu action checkbox change
    submenuActionCheckboxes.forEach(submenuActionCheckbox => {
        submenuActionCheckbox.addEventListener('change', () => {
            checkSelectAllStatus();
        });
    });

    // Check select all status
    function checkSelectAllStatus() {
        const allChecked = Array.from(menuCheckboxes).every(checkbox => checkbox.checked) &&
                           Array.from(submenuCheckboxes).every(checkbox => checkbox.checked) &&
                           Array.from(submenuActionCheckboxes).every(checkbox => checkbox.checked);
        selectAllCheckbox.checked = allChecked;
    }
  });
</script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
      const dashboardButtons = document.querySelectorAll('.dashboards_add');

      dashboardButtons.forEach(button => {
          button.addEventListener('click', function(event) {
              event.preventDefault();
              const targetId = this.getAttribute('data-target');
              const targetElement = document.querySelector(targetId);

              if (targetElement.classList.contains('show')) {
                  $(targetId).collapse('hide');
              } else {
                  $(targetId).collapse('show');
              }

              // Toggle class mdi-chevron-down & mdi-chevron-up
              this.querySelector('i').classList.toggle('mdi-chevron-down');
              this.querySelector('i').classList.toggle('mdi-chevron-up');
          });
      });
  });


</script>
<script>
    $(document).ready(function() {
        // Hide or show the div based on the selected radio button
        $('input[name="manage_branch"]').on('change', function() {
            if ($('#view_mm').is(':checked')) {
                $('#accessHeadDiv').show(); // Show the div when "Multi Manage" is selected
            } else {
                $('#accessHeadDiv').hide(); // Hide the div when "Single Manage" is selected
            }
        });
  
        // Trigger change event on page load to check the initial state
        $('input[name="manage_branch"]:checked').trigger('change');
    });
</script>


@endsection
