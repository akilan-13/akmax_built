<table class="table table-bordered">
    <thead>
        <tr class="text-start align-center  fw-bold fs-6 gs-0 bg-primary">
            <th>Staff Name</th>
            <th>Old ID</th>
            <th>New ID</th>
        </tr>
    </thead>
    <tbody>
        @foreach($staff as $s)
        <tr>
            <td>{{ $s->staff_name }}</td>
            <td>{{ $s->staff_id }}</td>
            <td>
                <input type="text"
                       class="form-control staff-id-input"
                       data-sno="{{ $s->sno }}"
                       value="{{ $s->staff_id }}">
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
