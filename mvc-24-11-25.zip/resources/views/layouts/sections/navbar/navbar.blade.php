@php
$containerNav = $containerNav ?? 'container-fluid';
$navbarDetached = ($navbarDetached ?? '');
@endphp
<style>
.navbar-search-wrapper {
  position: relative;
  width: 250px; /* adjust width as needed */
}

.navbar-search-wrapper input.form-control {
  width: 100%;
  padding-left: 40px; /* space for the icon */
  border-radius: 12px;
  background: rgba(153, 152, 152, 0.2);
  border-right: 1px solid #eee;
  /* backdrop-filter: blur(8px);
  border: 1px solid rgba(0,0,0,0.2); */
  color: #000;
}

.navbar-search-wrapper i.mdi {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none; /* so click goes to input */
  color: black;
}
</style>



<!-- Navbar -->
@if(isset($navbarDetached) && $navbarDetached == 'navbar-detached')
<nav class="layout-navbar {{$containerNav}} navbar navbar-expand-xl {{$navbarDetached}} align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
  @endif
  @if(isset($navbarDetached) && $navbarDetached == '')
<nav class="layout-navbar navbar navbar-expand-xl align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
  <div class="{{$containerNav}}">
    @endif

    <!--  Brand demo (display only for navbar-full and hide on below xl) -->
    @if(isset($navbarFull))
      <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
        <a href="{{url('/')}}" class="app-brand-link gap-2">
        <img src="{{asset('assets/common/logo_full.png')}}" class="app-brand-logo demo" alt="EGC Logo">
        <span class="app-brand-text demo menu-text fw-bold">EGC</span>
      </a>
      @if(isset($menuHorizontal))
        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
          <i class="mdi mdi-close align-middle"></i>
        </a>
      @endif
    </div>
    @endif
   
    
          <!-- ! Not required for layout-without-menu -->
          @if(!isset($navbarHideToggle))
          <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0{{ isset($menuHorizontal) ? ' d-xl-none ' : '' }} {{ isset($contentNavbar) ?' d-xl-none ' : '' }}">
            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
              <i class="mdi mdi-menu mdi-24px"></i>
            </a>
          </div>
          @endif

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

      <ul class="navbar-nav flex-row align-items-center ms-auto mx-4 px-2">
          <!-- Search -->
          
          <!-- /Search -->
                <!-- Notification -->
        <li class="nav-item me-2 me-xl-1">
          <a href="{{ url('/settings/general_settings') }}" aria-expanded="false" >
            <i class="mdi mdi-cog-outline fs-3 text-black"></i>
          </a>
        </li>
        <!--/ Notification -->

        <!-- Notification -->
        <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
          <a href="javascript:void(0);" aria-expanded="false" data-bs-toggle="offcanvas" data-bs-target="#notification_tab">
            <!-- <img id="envelope" src="{{ url('assets/egc_images/notification/envelope.png') }}" alt="bell" class="bell" width="25" height="25" /> -->
            <img id="envelope" src="{{ url('assets/egc_images/notification/unread_msg_1.gif') }}" alt="bell" class="bell" width="40" height="40" />            
          </a>  
        </li>
        <!--/ Notification -->

        <!-- User -->
        <li class="nav-item navbar-dropdown dropdown-user dropdown">
          <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
            <div class="avatar avatar-online" style="width: 40px; height: 40px;">
               @if(Auth::user()->staff->company_type==1)
                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                @else
                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                @endif
            </div>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li>
              <a class="dropdown-item" href="javascript:;">
                <div class="d-flex">
                  <div class="flex-shrink-0 me-3">
                    <div class="avatar avatar-online">
                        @if(Auth::user()->staff->company_type==1)
                        <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                        @else
                        <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                        @endif
                    </div>
                  </div>
                  <div class="flex-grow-1">
                    <span class="fw-medium d-block">
                      @if (Auth::check())
                      {{ Auth::user()->name }}
                      @else
                      Super Admin
                      @endif
                    </span>
                    <small class="text-muted">Admin</small>
                  </div>
                </div>
              </a>
            </li>
            <li>
              <div class="dropdown-divider"></div>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_profile">
                <!-- <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="Loading" style="width: 30px; height: auto;"> -->
                 <i class="mdi mdi-account-circle-outline text-black fs-3"></i>
                <span class="align-middle">My Profile</span>
              </a>
            </li>
           
            @if (Auth::check())
                  <li>
                      <a class="dropdown-item" href="{{ route('logout') }}"
                          onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                          <i class='mdi mdi-logout fs-3'></i>
                          <span class="align-middle">Logout</span>
                      </a>
                  </li>
                  <form method="POST" id="logout-form" action="{{ route('logout') }}">
                      @csrf
                  </form>
              @else
                  <li>
                      <a class="dropdown-item" href="{{ Route::has('login') ? route('login') : url('auth/login-basic') }}">
                          <i class='mdi mdi-login me-2'></i>
                          <span class="align-middle">Login</span>
                      </a>
                  </li>
              @endif
           
            
          </ul>
        </li>
        <!--/ User -->
      </ul>
    </div>
    @if(!isset($navbarDetached))
  </div>
  @endif
</nav>
<!-- / Navbar -->

<!--begin::Modal - Profile Update -->
<div class="modal fade" id="kt_modal_profile" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog">
    <!--begin::Modal content-->
    <div class="modal-content rounded-3 shadow-lg position-relative ">
    <form method="POST" action="{{ route('update_profile') }}" enctype="multipart/form-data">
              @csrf
      <div class="card__img">
        <img src="{{ url('assets/common/egc-image.jpg') }}" alt="background-image" class="bg-image" />
        <div class="profile-wrapper text-center position-absolute translate-middle" style="top: 120px; left:70px;">
          <div class="d-inline-block position-relative">
              @if(Auth::user()->staff->company_type==1)
            <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
            @else
            <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
            @endif
            <div id="imagePreview" class="preview-box">
              <img id="previewImage" src="" alt="Preview" />
            </div>
            <label for="profileImageUpload"
              class="position-absolute bottom-0 end-0 bg-white p-2 rounded-circle "
              style="cursor: pointer;">
              <i class="fas fa-camera text-primary"></i>
            </label>
          </div>
          <input type="file" name="staff_image" id="profileImageUpload" class="d-none upload_staff_image" />
        </div>
        <div class="d-flex align-items-start justify-content-center flex-column px-10 px-lg-20 mx-2">
          <label class="card__title" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Name">Super Admin</label>
          <label class="card__subtitle text-center mt-0 pt-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Role">Super Admin</label>
        </div>
      </div>
      <div class="modal-body pt-0 mt-5 pb-4 px-10 px-xl-20 bg-white">
        <div class="mb-4">
            <label class="fw-bold text-black">Username</label>
            <div class="form-control bg-light border-0">{{ Auth::user()->staff->user_name }}</div>
            <label class="fw-bold text-muted">Password</label>
            <div class="input-group">
                <input type="password" name="staff_password" class="form-control" id="passwordInput" placeholder="Enter New Password" value="{{ Auth::user()->staff->password }}">
                <span class="input-group-text toggle-password" style="cursor: pointer;">
                    <i class="fas fa-eye-slash"></i>
                </span>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="d-flex justify-content-between align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4" data-bs-dismiss="modal">Update Profile</button>
        </div>
          <!--end::Profile Form-->
      </div>
     </form>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Profile Update -->


<!--begin:: Notification Offcanvan-->
<div class="offcanvas offcanvas-end" id="notification_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <div class="offcanvas-header border-bottom d-block bg-label-white">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <div class="d-flex align-items-center gap-1">
        <h5 class="offcanvas-title text-dark fw-bold">Notifications</h5>
        <span id="notificationCount" class="badge rounded-pill bg-danger text-white">0 New</span>
      </div>
      <button type="button" class="btn-close text-reset rounded-pill custom-bg-orange modal_close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>
      <div class="d-flex align-items-center justify-content-between">
          <label class="clear-all hover-badge">
              <span class="fs-6 fw-semibold ">Clear All</span>
          </label>
          <label class="mark-all-read hover-badge">
              <span class="fs-6 fw-semibold ">Mark all as read</span>
          </label>
      </div>

  </div>
  <div class="offcanvas-body flex-grow-1">
    <ul class="list-group list-group-flush list-unstyled scrollable-container notification-list" >

    </ul>
  </div>
</div>
<!--End:: Notification Offcanvan-->

<style>


  .preview-box {
      position: absolute;
      top: 50px; /* Moved higher */
      left: 100%;
      transform: translateX(-50%) scale(0.5);
      opacity: 0;
      transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
      background: #fed240;
      border-radius: 12px;
      padding: 8px;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.25);
      z-index: 10;
  }

    .preview-box img {
        width: 100px;  /* Increased size */
        height: 100px; /* Increased size */
        border-radius: 10px;
    }
    .profile-image {
        border: 8px solid white;      /* sets border thickness and color */
        border-radius: 100% !important; /* keeps it circular */
        background-color: white;
        /* box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);  */
      }
    .profile-image:hover + .preview-box,
    .profile-image:focus + .preview-box {
        transform: translateX(-50%) scale(1);
        opacity: 1;
    }
    /*.card__img {*/
    /*  height: 192px;*/
    /*  width: 100%;*/
    /*  position: relative;*/
    /*  overflow: visible;*/
    /*}*/
   /* Remove border-radius from .card__img */
    .card__img {
      height: 192px;
      width: 100%;
      position: relative;
      overflow: visible; /* allow the image to extend beyond */
      /* border-radius removed here */
    }

    /* Glassmorphic background image for modal */
    .bg-image {
      width: 100%;
      height: 100px;             /* Fixed height */
      object-fit: cover;         /* Cover the container without stretching */
      display: block;
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;
      
      /* Glassmorphism effect */
      backdrop-filter: blur(8px);       /* Blur the background behind */
      background-color: rgba(255, 255, 255, 0.25); /* Semi-transparent overlay */
      border: 1px solid rgba(255, 255, 255, 0.18); /* Optional subtle border */
    }

    /* Apply full radius to modal content */
    .modal-content {
      border-radius: 12px !important;
      overflow: hidden; /* Ensures all modal contents respect the border radius */
    }


    .card__title {
      margin-top: 50px;
      margin-bottom: 0px;
      font-weight: 600;
      font-size: 25px;
      color: black;
      padding: 0px 10px;
    }

    .card__subtitle {
      font-weight: 400;
      font-size: 18px;
      color: black;
      padding: 10px;
    }

    .profile-wrapper {
      z-index: 5;
      margin-top: -20px; /* pushes it up over SVG */

    }

    .card__icons {
    display: flex;
    justify-content: center;
    gap: 10px; /* Adds space between icons */
    margin-top: 10px;
  }

 .card__icons a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px; /* Fixed width for consistent sizing */
    height: 40px; /* Fixed height */
    border-radius: 50%; /* Circular icons */
    background-color: #1877F2; /* Facebook blue, you can customize */
    transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth transitions for color and scale */
  }

  .card__icons a:hover {
    background-color: #0e5bcf; /* Slightly darker shade on hover */
    transform: scale(1.1); /* Slightly larger on hover */
  }

  .card__icons i {
    font-size: 24px; /* Icon size */
  }

  .card__icons a[data-bs-toggle="tooltip"]:hover {
    text-decoration: none; /* Ensures no underlining on hover */
  }
</style>
<!-- Script -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
      let profileImage = document.getElementById('uploadedstaffimage');
      let previewBox = document.getElementById('imagePreview');
      let previewImage = document.getElementById('previewImage');

      profileImage.addEventListener("mouseenter", function () {
          previewImage.src = profileImage.src;
          previewBox.style.opacity = "1";
          previewBox.style.transform = "translateX(-50%) scale(1)";
      });

      profileImage.addEventListener("mouseleave", function () {
          previewBox.style.opacity = "0";
          previewBox.style.transform = "translateX(-50%) scale(0.5)";
      });
  });
    document.addEventListener('DOMContentLoaded', () => {
      let staff_add = document.getElementById('uploadedstaffimage');
      const staff_add_fileInput = document.querySelector('.upload_staff_image');
      if (staff_add) {
          const staff_add_resetImage = staff_add.src;
          staff_add_fileInput.onchange = () => {
              if (staff_add_fileInput.files[0]) {
                  staff_add.src = window.URL.createObjectURL(staff_add_fileInput.files[0]);
              }
          };
      }
  });
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script>
  document.addEventListener("DOMContentLoaded", function () {
      const passwordInput = document.getElementById("passwordInput");
      const togglePassword = document.querySelector(".toggle-password i");

      document.querySelector(".toggle-password").addEventListener("click", function () {
          if (passwordInput.type === "password") {
              passwordInput.type = "text";
              togglePassword.classList.remove("mdi-eye-off");
              togglePassword.classList.add("mdi-eye");
          } else {
              passwordInput.type = "password";
              togglePassword.classList.remove("mdi-eye");
              togglePassword.classList.add("mdi-eye-off");
          }
      });
  });
  </script>