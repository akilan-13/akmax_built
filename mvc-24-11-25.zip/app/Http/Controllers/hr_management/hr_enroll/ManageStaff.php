<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ManageStaff extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
     $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';


    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', '>', 1);
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        if($company_fill != ''){
          if($company_fill == 'egc'){
             $staffData->where('egc_staff.company_type',1);
          }else{
            $staffData->where('egc_staff.company_id', 'LIKE', $company_fill);
          }
            
        }

        if ($entity_fill) {
          $staffData->where('egc_staff.entity_id', $entity_fill);
        }

        
        if ($department_fill) {
            $staffData->where('egc_staff.department_id', $department_fill);
        }

        if ($division_fill) {
            $staffData->where('egc_staff.division_id', $division_fill);
        }

        if ($job_role_fill) {
          $staffData->where('egc_staff.job_role_id', $job_role_fill);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
            }
          }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);
        
        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
            
           $educations = DB::table('egc_staff_education_info')
            ->select('egc_education.education')
            ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
            ->where('egc_staff_education_info.staff_id', $staff->sno) 
            ->where('egc_staff_education_info.status', 0)
            ->pluck('egc_education.education');
            $staff->education=$educations;
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staffData->currentPage(),
                'last_page' => $staffData->lastPage(),
                'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.manage_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }
  
   public function AddOldStaff(Request $request)
  {

    // return $request;
    // Validate incoming request
    $helper = new \App\Helpers\Helpers();
    $validator = Validator::make($request->all(), [
      'staff_company_name' => 'required',
      'staff_entity_name' => 'required',
      'staff_branch_name' => 'required'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = $request->user()->user_id ?? 1;
    
    $company_type=2;
    $company_id=$request->staff_company_name;
    $entity_id=$request->staff_entity_name;
    $branch_id=$request->staff_branch_name;
    $staffData = json_decode($request->staff_data_payload, true); 

    $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

      if (!$entity_url) {
          return response()->json([
              'status'  => 404,
              'message' => 'Entity URL not found for the given entity ID.',
          ], 200);
      }

      // 🧩 Step 3: Call external API using Http facade
      $verify_key = 'egcsecret2030datagetapierp';
      $api_url = rtrim($entity_url, '/') . '/api/staff_data_get';

      try {
          $response = Http::get($api_url, ['auth_key' => $verify_key]);

          if (!$response->successful()) {
              return response()->json([
                  'status'  => 500,
                  'message' => 'Failed to fetch Staff from entity API.',
                  'error'   => $response->body(),
              ], 200);
          }

          $StaffData = $response->json()['data'] ?? [];
          $filteredStaffData = array_filter($StaffData, function($staff) {
              return $staff['external_uuid'] == null;
          });
          $filteredStaffData = array_values($filteredStaffData);

          // return $filteredStaffData;


          if (empty($StaffData)) {
              return response()->json([
                  'status'  => 404,
                  'message' => 'No user roles found in API response.',
              ], 200);
          }

          // 🧩 Step 4: Loop and insert roles
          foreach ($StaffData as $staff) {

              $staff_name = $staff['staff_name'] ?? null;
              if (!$staff_name) continue;

              $staff_mobile = $staff['mobile_no'] ?? null;
              if (!$staff_mobile) continue;

              $company_type = 2;

              // 🔍 Check if role already exists
              $chk = StaffModel::where('mobile_no', $staff_mobile)
                  ->where('status', '!=', 2)
                  ->first();

              if ($chk) continue; // skip duplicates

              $erp_staff_id = $staff['sno'] ?? 0;
              $alternative_no = $staff['alternative_no'] ?? NULL;
              $email_id = $staff['email_id'] ?? NULL;
              $work_exp_type = $staff['exp_type'] ?? 1;
              $gender = $staff['gender'] ?? 1;
              $dob = $staff['dob'] ?? NULL;
              $date_of_joining = $staff['date_of_joining'] ?? NULL;
              $contact_person_name = [$staff['contact_person_name']] ?? NULL;
              $contact_person_name = $contact_person_name ? json_encode($contact_person_name) : NULL;
              $contact_person_no = [$staff['contact_person_no']] ?? NULL;
              $contact_person_no = $contact_person_no ? json_encode($contact_person_no) : NULL;
              $marital_status = $staff['martial_status'] ?? 1;
              $address = $staff['address'] ?? NULL;
              $nick_name = $staff['nick_name'] ?? NULL;
              $description = $staff['description'] ?? NULL;
              $basic_salary = $staff['basic_salary'] ?? 0;
              $per_hr_cost = $staff['per_hour_cost'] ?? 0;
              $user_name = $staff['user_name'] ?? NULL;
              $password = $staff['password'] ?? NULL;

              $erp_department_id = $staff['department_id'] ?? 0;
              $erp_division_id = $staff['sub_department_id'] ?? 0;
              $erp_role_id = $staff['role_id'] ?? 0;
              $erp_job_role_id = $staff['position_role'] ?? 0;

              $role_id = $helper->get_sno_by_erpId($erp_role_id, 'egc_user_role', 'erp_role_id');
              $role_id = $role_id ?? 0;

              $department_id = $helper->get_sno_by_erpId($erp_department_id, 'egc_department', 'erp_department_id');
              $department_id = $department_id ?? 0;

              $division_id = $helper->get_sno_by_erpId($erp_division_id, 'egc_division', 'erp_division_id');
              $division_id = $division_id ?? 0;

              $job_role_id = $helper->get_sno_by_erpId($erp_job_role_id, 'egc_job_role', 'erp_job_role_id');
              $job_role_id = $job_role_id ?? 0;

              // Handle staff image upload
              $staff_image_url = $staff['staff_image'] ?? null;
              $staff_image = null;

              if ($staff_image_url) {
                  // Determine file extension
                  $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION);
                  if (!$ext) {
                      $ext = 'jpg';
                  }

                  // Define target folder
                  $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");

                  // Ensure the folder exists
                  if (!File::exists($folderPath)) {
                      File::makeDirectory($folderPath, 0777, true, true);
                  }
                  // ✅ Find the next available image number in this folder
                  $existingFiles = File::files($folderPath);
                  $maxNumber = 0;

                  foreach ($existingFiles as $file) {
                      // Match filenames like staff_image_5.jpg
                      if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                          $num = (int) $matches[1];
                          if ($num > $maxNumber) {
                              $maxNumber = $num;
                          }
                      }
                  }

                  // Next available number
                  $nextNumber = $maxNumber + 1;

                  // Create new filename
                  $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                  $savePath = $folderPath . '/' . $staff_image_name;

                  // Download and save the image
                  try {
                      $imageData = @file_get_contents($staff_image_url);
                      if ($imageData !== false) {
                          file_put_contents($savePath, $imageData);
                          $staff_image = $staff_image_name;
                      } else {
                          $staff_image = null;
                      }
                  } catch (Exception $e) {
                      $staff_image = null;
                  }
              }

              // 🧩 Step 5: Generate next Staff_id
                $staff_company_check = StaffModel::where('company_id',$company_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $company_sno =$staff_company_check ? $staff_company_check->sno + 1 : 1;
                $prefix_num = 1 + (int)$company_id; // company_id=1→2, company_id=2→3
                $staff_id = sprintf("EGC%02d%03d", $prefix_num, $company_sno);

                $add_staff = new StaffModel();
                $add_staff->staff_id = $staff_id;
                $add_staff->company_type = $company_type;
                $add_staff->company_id = $company_id;
                $add_staff->erp_staff_id    = $erp_staff_id;
                $add_staff->entity_id    = $entity_id;
                $add_staff->branch_id    = $branch_id;
                $add_staff->division_id = $division_id ?? 0;
                $add_staff->department_id = $department_id ?? 0;
                $add_staff->role_id = $role_id;
                $add_staff->job_role_id = $job_role_id;
                $add_staff->staff_name = $staff_name;
                $add_staff->mobile_no = $staff_mobile;
                $add_staff->alternative_no = $alternative_no;
                $add_staff->email_id = $email_id;
                $add_staff->exp_type = $work_exp_type;
                $add_staff->total_company_shift = 0;
                $add_staff->total_experience = 0;
                $add_staff->gender = $gender;
                $add_staff->dob = $dob;
                $add_staff->date_of_joining = $date_of_joining;
                $add_staff->contact_person_name = $contact_person_name;
                $add_staff->contact_person_no = $contact_person_no;
                $add_staff->martial_status = $marital_status ?? null;
                $add_staff->address = $address ?? null;
                $add_staff->staff_image = $staff_image ?? null;
                $add_staff->attachment = null;
                $add_staff->nick_name = $nick_name ?? null;
                $add_staff->description = $description ?? null;
                $add_staff->basic_salary = $basic_salary;
                $add_staff->per_hour_cost = $per_hr_cost;
                $add_staff->user_name = $user_name;
                $add_staff->password  = $password;
                $add_staff->created_by = $request->user()->user_id;
                $add_staff->updated_by = $request->user()->user_id;

                $add_staff->save();

                if ($add_staff) {

                  // Add User for login credentials
                    User::create([
                      'user_id' => $add_staff->sno,
                      'company_type' => $add_staff->company_type,
                      'company_id' => $add_staff->company_id,
                      'entity_id' => $add_staff->entity_id,
                      'role_id' => $add_staff->role_id ?? 0,
                      'branch_id' =>  $add_staff->branch_id,
                      'name' => $user_name,
                      'password' => Hash::make($password),
                      'email' => $add_staff->email_id,
                      'created_by' => $request->user()->user_id ?? 1,
                      'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    
                      // Handle work information
                          if ($work_exp_type == 2 && isset($staff['staff_work_info']) && is_array($staff['staff_work_info'])) {
                                foreach ($staff['staff_work_info'] as $work) {
                                    StaffWorkInfoModel::create([
                                        'staff_id' => $add_staff->sno,
                                        'staff_type' => $work_exp_type,
                                        'position' => $work['position'] ?? null, // Default to null if 'position' is not set
                                        'year_of_experience' => $work['year_of_experience'] ?? 0, // Default to 0 if 'year_of_experience' is not set
                                        'company_name' => $work['company_name'] ?? null, // Default to null if 'company_name' is not set
                                        'start_date' => isset($work['work_start_date']) ? date('Y-m-d', strtotime($work['work_start_date'])) : null, // Handle missing 'work_start_date'
                                        'end_date' => isset($work['work_end_date']) ? date('Y-m-d', strtotime($work['work_end_date'])) : null, // Handle missing 'work_end_date'
                                        'created_by' => $request->user()->user_id ?? 1,
                                        'updated_by' => $request->user()->user_id ?? 1,
                                    ]);
                                }
                            }
      
                      // Handle education information
                      // foreach ($qualification_type as $key => $qualification) {
                      //   StaffEducationInfoModel::create([
                      //     'staff_id' => $add_staff->sno,
                      //     'qualification_type' => $qualification,
                      //     'degree_name' => $degree[$key],
                      //     'major' => $major[$key],
                      //     'university_name' => $univ_name[$key],
                      //     'year' => $pass_year[$key],
                      //     'created_by' => $request->user()->user_id,
                      //     'updated_by' => $request->user()->user_id,
                      //   ]);
                      // }

              
                      // // Handle staff credentials
                      // if ($credential_check == 1 && $request->has('credential')) {
                      //     foreach ($request->credential as $credential_id => $data) {
                      //         // Skip if username is empty
                      //         if (!empty($data['username'])) {
                      //             StaffCredentialModel::create([
                      //                 'staff_id'      => $add_staff->sno,
                      //                 'credential_id' => $credential_id,
                      //                 'user_name'     => $data['username'],
                      //                 'password'      => $data['password'] ?? null,
                      //                 'url_link'      => $data['url'] ?? null,
                      //                 'description'   => $data['description'] ?? null,
                      //                 'created_by'    => $request->user()->user_id,
                      //                 'updated_by'    => $request->user()->user_id,
                      //             ]);
                      //         }
                      //     }
                      // }
                        
                   $this->dispatchUpdateWebhooks($add_staff, $user_id=1,'Update_Staff_uuid');
                }
                 
              
          }

          return response()->json([
              'status'  => 200,
              'message' => 'Business Staff imported successfully.',
          ]);

      } catch (\Throwable $e) {
          // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
          return response()->json([
              'status'  => 500,
              'message' => 'Something went wrong while fetching Department.',
              'error'   => $e->getMessage(),
          ], 200);
      }
  }



  public function staff_add()
  {
      

      $firstLanguages = ['Hindi','Malayalam','English','Tamil'];
      $fieldList = "'" . implode("','", $firstLanguages) . "'";
      $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $staff_list = StaffModel::where('egc_staff.status', 0)
      ->select('egc_staff.*','egc_entity.entity_name','egc_entity.entity_short_name','egc_job_role.job_position_name as job_role_name')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno','>',1)
      ->orderBy('egc_staff.sno', 'ASC')
      ->get();

      $CourseTag = CourseTagModel::where('status', '!=', 2)->pluck('course_tag_name');
      $skillTagList = SkillTagModel::where('status', '!=', 2)->pluck('skill_tag_name');
      $hobbyList = HobbyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $relationshipList = RelationshipModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $jobPositionlist = JobpositionModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $documentTypeList = DocumentModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $documentCheckList = DocumentCheckListModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $qualificationList = QualificationModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $languageList = LanguageModel::where('status', 0)
          ->orderByRaw("FIELD(name, $fieldList) DESC") 
          ->orderBy('name', 'ASC')
          ->get();
     $credential_list = CredentialModel::where('status', 0)->orderBy('sno', 'ASC')->get(); 
     $management_department = DepartmentModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $management_user_role = UserRoleModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $questions = HrQuestionnaireModel::with(['depends' => function($q) {
        $q->where('status', 0);
    }])->where('status', 0)->get();
    $unique_id = 'Staff_' . Str::uuid();
    return view('content.hr_management.hr_enroll.manage_staff.add_staff',[
        'social_media_list' => $social_media_list,
        'company_list' => $company_list,
        'CourseTag' => $CourseTag,
        'skillTagList' => $skillTagList,
        'source_list' => $source_list,
        'documentTypeList' => $documentTypeList,
        'jobPositionlist' => $jobPositionlist,
        'qualificationList' => $qualificationList,
        'languageList' => $languageList,
        'management_department' => $management_department,
        'management_user_role' => $management_user_role,
        'documentCheckList' => $documentCheckList,
        'credential_list' => $credential_list,
        'hobbyList' => $hobbyList,
        'relationshipList' => $relationshipList,
        'questions' => $questions,
        'unique_id' => $unique_id,
        'staff_list' => $staff_list,
        ]);
  }

  public function Add(Request $request)
  {

    // return $request;
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      // 'staff_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = $request->user()->user_id;
    // return $request;
    // Determine staff serial number
    

      $company_type = $request->company ?? 1;
      $company_id   = $request->staff_company_name ?? 0;
      $entity_id    = $request->entity_name ?? 0;
      $branch_id    = $request->branch_id ?? 0;
       $staff_check = StaffModel::where('company_type',1)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();
       $sno = $staff_check ? $staff_check->sno + 1 : 1;
    
      // Generate staff ID
      if ($company_type == 1) {
          // Example: EGC01001, EGC01002 ...
          $staff_id = sprintf("EGC01%03d", $sno);
      } elseif ($company_type == 2) {
         $staff_company_check = StaffModel::where('company_id',$company_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();
           $company_sno =$staff_company_check ? $staff_company_check->sno + 1 : 1;
          $prefix_num = 1 + (int)$company_id; // company_id=1→2, company_id=2→3
          $staff_id = sprintf("EGC%02d%03d", $prefix_num, $company_sno);
      } else {
          // Default / fallback
          $staff_id = sprintf("EGC01%03d", $sno);
      }

      // return $request;
    // Stage 1 Base Details
    // Handle staff image upload
    $staff_image = '';
    if ($request->hasFile('staff_add_icon')) {
        $image = $request->file('staff_add_icon');
        $extension = $image->extension();

       if ($company_type == 1) {
          $folderPath = public_path('staff_images/Management');
      } else {
          $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");
      }
       // Create directory if not exists
        if (!File::exists($folderPath)) {
            File::makeDirectory($folderPath, 0777, true, true);
        }
          // Build file name
            $staff_imageName = 'staff_' . $sno . '.' . $extension;
          // Move uploaded image
            $image->move($folderPath, $staff_imageName);
             $staff_image = $staff_imageName;
    }

    $staff_name = $request->staff_name;
    $completion_percentage = $request->completion_percentage;
    $mobile_no = $request->mobile_no;
    $gender = $request->gender ?? 1;
    $dob = $request->dob ? date('Y-m-d', strtotime($request->dob)) : NULL;
    $email_id = $request->email_id ?? NULL;
    $mother_tongue = $request->mother_tongue ?? NULL;
    $languages = $request->Languages ? json_encode($request->Languages) : NULL;
    $hobby = $request->hobby ? json_encode($request->hobby) : NULL;
    $description = $request->description ?? NULL;

    // Stage 2 Family Details
      $father_name = $request->father_name;
      $father_occup = $request->father_occup;
      $mother_name = $request->mother_name ?? NULL;
      $mother_occup = $request->mother_occup ?? NULL;
      $marital_status = $request->marital_status ?? 2;
      $anniversary_date = $request->anniversary_date ? date('Y-m-d', strtotime($request->anniversary_date)) : NULL;
      $spouse_name = $request->spouse_name ?? NULL;
      $spouse_mobile = $request->spouse_mobile ?? NULL;
      $spouse_is_working = $request->is_working ?? 'No';
      $spouse_dob = $request->spouse_dob ? date('Y-m-d', strtotime($request->spouse_dob)) : NULL;
      $spouse_designation = $request->spouse_designation ?? NULL;
      $spouse_company_name = $request->spouse_company_name ?? NULL;
      $spouse_salary = $request->spouse_salary ?? NULL;
      $has_children = $request->has_children ?? NULL;
      $childrenCount = $request->childrenCount ?? 0;
      $child_name = $request->child_name ??  NULL;
      $child_dob = $request->child_dob ??  NULL;
      $child_std = $request->child_std ??  NULL;
      $child_year = $request->child_year ?? NULL;
      $has_Siblings = $request->has_Siblings ?? 0;
      $siblings_detail = $request->siblings_detail ?? Null;

      // Handle children details
      $children_details = null;
      if (!empty($childrenCount) && $childrenCount > 0) {
          $children_details_array = [];

          for ($i = 0; $i < $childrenCount; $i++) {
              $children_details_array[] = [
                  'child_name' => $child_name[$i] ?? null,
                  'child_dob' => isset($child_dob[$i]) ? date('Y-m-d', strtotime($child_dob[$i])) : null,
                  'child_std' => $child_std[$i] ?? null,
                  'child_year' => $child_year[$i] ?? null,
              ];
          }

          $children_details = json_encode($children_details_array);
      }


    // Stage 3 Contact Details
      $permanent_address =$request->permanent_address ?? Null;
      $residential_address = $request->residential_address ?? NULL;
      $staff_location_url = $request->staff_location_url ?? NULL;
      $staff_latitude = $request->staff_latitude ?? NULL;
      $staff_longitude = $request->staff_longitude ?? NULL;
      $contact_person_name = $request->contact_person_name ? json_encode($request->contact_person_name) : NULL;
      $contact_person_no = $request->contact_person_no ? json_encode($request->contact_person_no) : NULL;
      $contact_person_relation = $request->contact_person_relation ? json_encode($request->contact_person_relation) : NULL;

      // foreach ($request->contact_person_name as $index => $file) {

      // }
    
      // Stage 4 social Media Detils
      $socialMediaData = $request->social_media;
         $socialMediaData = array_filter($socialMediaData, function($value) {
            return !is_null($value) && $value !== '';
        });
      $socialMediaData = $socialMediaData ? json_encode($socialMediaData) : Null;

      // stage 5 Educational Details 
        $qualification_type = $request->qualification_type ?? [];
        $degree = $request->degree ?? [];
        $major = $request->major ?? [];
        $univ_name = $request->univ_name ?? [];
        $pass_year = $request->pass_year ?? [];
        $is_Course = $request->is_Course ?? NULL;
        $course_tag = $request->course_tag ?? NULL;

      // stage 6 Work Exp Details
        $work_exp_type = $request->work_type ?? 1;
        $total_company_shift = $request->total_company_shift ?? 1;
        $total_experience = $request->total_experience ?? 1;
        $work_company_name = $request->company_name ?? [];
        $work_position = $request->position ?? [];
        $work_exp_yrs = $request->exp_yrs ?? [];
        $work_salary = $request->salary ?? [];
        $work_st_date = $request->work_st_date ?? [];
        $work_end_date = $request->work_end_date ?? [];
        $exit_reason = $request->ExitReason ?? [];

      
        // ✅ Stage 6: Handle attachments properly
          
        
       // stage 7 Company Details
          if($company_type == 1){
            $department_id = $request->management_depart ?? 0;
            $division_id = $request->management_division ?? 0;
            $role_id = $request->management_user_role ?? 0;
            $job_role_id = $request->management_job_role ?? 0;
          }else{
            $department_id = $request->business_depart ?? 0;
            $division_id = $request->business_division ?? 0;
            $role_id = $request->business_user_role ?? 0;
            $job_role_id = $request->business_job_role ?? 0;
          }

            $erp_branch_id = $request->erp_branch_id ?? 0;
            $erp_department_id = $request->erp_department_id ?? 0;
            $erp_division_id = $request->erp_division_id ?? 0;
            $erp_job_role_id = $request->erp_job_role_id ?? 0;
            $erp_role_id = $request->erp_role_id ?? 0;
            $erp_under_role_id = $request->erp_under_role_id ?? 0;
          
          $nick_name = $request->pseudo_name ?? NULL;
          $doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : NULL;
          $basic_salary = $request->basic_salary ?? 0;
          $per_hr_cost = $request->per_hr_cost ?? 0;
          $skill_tag = $request->skill_tag ? json_encode($request->skill_tag) : NULL;
          $loginuser_name = $request->loginuser_name ?? Null;
          $loginpassword = $request->loginpassword ?? Null;
          $credential_check = $request->other_access ?? 0;

        // Other credential

      // stage 8 Application Details

          $applied_position = $request->applied_position ? json_encode($request->applied_position) : NULL;
          $interview_company = $request->interview_company ? json_encode($request->interview_company) : NULL;
          $source_id = $request->source_id;
          $source_details = $request->source_details ?? Null;

          $data = $request->all();
          // initialize arrays
          $questions = [];
          $dependents = [];
          // loop through request inputs
          foreach ($data as $key => $value) {
              // 🎯 Handle main question inputs (like q_1, q_2)
              if (preg_match('/^q_(\d+)$/', $key, $matches)) {
                  $questionId = $matches[1];
                  $questions[$questionId] = $value ?? null;
              }
              // 🎯 Handle dependent question inputs (like depend_1, depend_2)
              if (preg_match('/^depend_(\d+)$/', $key, $matches)) {
                  $dependId = $matches[1];
                  $dependents[$dependId] = $value ?? null;
              }
          }
          // Combine both into one structured JSON
          $application_details = [
              'questions' => (object) $questions,
              'dependents' => (object) $dependents,
          ];

      // return $application_details;


      // stage 8 Document Checklist Details
          $document_checked =$request->document_checked ? json_encode($request->document_checked) : NULL;
   
        // Create new staff record
        $add_staff = new StaffModel();
        $add_staff->staff_id = $staff_id;
        $add_staff->company_type = $company_type;
        $add_staff->company_id = $company_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->branch_id    = $branch_id;
        $add_staff->division_id = $division_id ?? 0;
        $add_staff->department_id = $department_id ?? 0;
        $add_staff->role_id = $role_id;
        $add_staff->job_role_id = $job_role_id;
        $add_staff->staff_name = $request->staff_name;
        $add_staff->mobile_no = $request->mobile_no;
        // $add_staff->alternative_no = $request->alternative_no;
        $add_staff->email_id = $request->email_id;
        $add_staff->exp_type = $work_exp_type;
        $add_staff->total_company_shift = $total_company_shift;
        $add_staff->total_experience = $total_experience;
        $add_staff->gender = $request->gender;
        $add_staff->hobby = $hobby ;
        $add_staff->mother_tongue = $mother_tongue;
        $add_staff->languages = $languages;
        $add_staff->dob = date('Y-m-d', strtotime($request->dob));
        $add_staff->date_of_joining = $doj;
        $add_staff->contact_person_name = $contact_person_name;
        $add_staff->contact_person_no = $contact_person_no;
        $add_staff->contact_person_relation = $contact_person_relation;
        $add_staff->martial_status = $marital_status ?? null;
        $add_staff->address = $permanent_address ?? null;
        $add_staff->residential_address = $residential_address ?? null;
        $add_staff->location_url = $staff_location_url ?? null;
        $add_staff->latitude = $staff_latitude ?? null;
        $add_staff->longitude = $staff_longitude ?? null;
        $add_staff->staff_image = $staff_image ?? null;
        $add_staff->nick_name = $nick_name ?? null;
        $add_staff->applied_position = $applied_position ?? null;
        $add_staff->source_id = $source_id ?? null;
        $add_staff->source_details = $source_details ?? null;
        $add_staff->applied_company_ids = $interview_company ?? null;
        $add_staff->description = $description ?? null;
        $add_staff->basic_salary = $basic_salary;
        $add_staff->per_hour_cost = $per_hr_cost;
        $add_staff->knowledge_tag = $skill_tag;
        $add_staff->credential = $credential_check;
        $add_staff->user_name = $loginuser_name;
        $add_staff->password  = $loginpassword;
        $add_staff->completion_percentage  = $completion_percentage;
        $add_staff->social_media_details  = $socialMediaData;
        $add_staff->document_checklist  = $document_checked;
        $add_staff->application_details = json_encode($application_details, JSON_PRETTY_PRINT);
        $add_staff->created_by = $request->user()->user_id;
        $add_staff->updated_by = $request->user()->user_id;

        $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {

      // Save family details
      $add_family = new StaffFamilyModel();
      $add_family->staff_id = $add_staff->sno;
      $add_family->father_name = $father_name;
      $add_family->father_occup = $father_occup;
      $add_family->mother_name = $mother_name;
      $add_family->mother_occup = $mother_occup;
      $add_family->marital_status = $marital_status;
      $add_family->anniversary_date = $anniversary_date;
      $add_family->spouse_name = $spouse_name;
      $add_family->spouse_mobile = $spouse_mobile;
      $add_family->spouse_dob = $spouse_dob;
      $add_family->spouse_working = $spouse_is_working;
      $add_family->spouse_designation = $spouse_designation;
      $add_family->spouse_company_name = $spouse_company_name;
      $add_family->spouse_salary = $spouse_salary ?? 0;
      $add_family->has_children = $has_children;
      $add_family->children_count = $childrenCount;
      $add_family->children_details = $children_details;
      $add_family->has_siblings = $has_Siblings;
      $add_family->siblings_detail = $siblings_detail;
      $add_family->created_by = $request->user()->user_id ?? 1;
      $add_family->updated_by = $request->user()->user_id ?? 1;
      $add_family->save();

      $update_staff = StaffModel::where('sno', $add_staff->sno)->first();
      $doc_types = $request->doc_type ?? [];  // Default to empty array if doc_type is not set in the request
      $attachments = [];  // Array to hold all attachment names
      $attachments_url = [];  // Array to hold URLs of the uploaded files
      if($doc_types){
        // Check if uploaded_files is an array or a JSON string
        $uploadedFiles = $request->input('uploaded_files');

        // If JSON string → decode it
        if (is_string($uploadedFiles)) {
            $uploadedFiles = json_decode($uploadedFiles, true);
        }
        // After decode, it MUST be array
        if (!is_array($uploadedFiles)) {
        }
        // Ensure doc_type is an array, in case it's a string
        $docType = is_array($request->input('doc_type')) ? $request->input('doc_type') : [];

        // Check for mismatch between the count of document types and uploaded files
        if (count($docType) !== count($uploadedFiles)) {
        }
        foreach ($uploadedFiles as $index => $files) {
            $docTypeId = $docType[$index] ?? null;  // Get the corresponding doc type for this set of files
            
            if (!$docTypeId) {
                continue;
            }
            if (is_string($files)) {
                $files = json_decode($files, true);  // Decode the string to an actual array
            }

            // Ensure there are files to process
            if (is_array($files) && count($files) > 0) {
                foreach ($files as $filename) {
                    
                    // Define the temp and final paths
                    $tempPath = public_path("staff_attachments/temp/$filename");
                    
                    // Modify final path to include staff_id and doc_type_id
                    $finalPath = public_path("staff_attachments/$add_staff->sno/$docTypeId/");

                    if (!file_exists($finalPath)) {
                        mkdir($finalPath, 0777, true);  
                    }

                    // Move the file from the temp folder to the permanent location
                    if (file_exists($tempPath)) {
                        rename($tempPath, $finalPath . $filename);  // Move the file
                        // Log::info("Moved file from $tempPath to $finalPath");

                        // Append the file name to the attachment array
                        $attachments[] = $filename;

                        // Generate the relative URL for the file and append to the URL array
                        $attachments_url[] = asset("staff_attachments/$add_staff->sno/$docTypeId/$filename");  
                        

                        $staffAttachment = StaffAttachmentModel::updateOrCreate(
                          [
                              'staff_id' => $add_staff->sno,
                              'document_id' => $docTypeId,  
                          ],
                          [
                              'attachment_name' => json_encode($attachments), 
                              'created_by' => $user_id, 
                              'updated_by' => $user_id, 
                          ]
                      );
                    } 
                }
            }
        }

        if (count($attachments) > 0) {
            $update_staff->attachment = json_encode($attachments);  
            $update_staff->update();
        } 
      }

      // Add User for login credentials
        User::create([
          'user_id' => $add_staff->sno,
          'company_type' => $add_staff->company_type,
          'company_id' => $add_staff->company_id,
          'entity_id' => $add_staff->entity_id,
          'role_id' => $add_staff->role_id ?? 0,
          'branch_id' =>  $add_staff->branch_id,
          'name' => $loginuser_name,
          'password' => Hash::make($loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id ?? 1,
          'updated_by' => $request->user()->user_id ?? 1,
        ]);
      
      
      // Handle education information
      
        foreach ($qualification_type as $key => $qualification) {
          StaffEducationInfoModel::create([
            'staff_id' => $add_staff->sno,
            'qualification_type' => $qualification,
            'degree_name' => $degree[$key],
            'major' => $major[$key],
            'university_name' => $univ_name[$key],
            'year' => $pass_year[$key],
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      //  return $request;
      // Handle work information
      if ($work_exp_type == 2) {
        foreach ($work_company_name as $key => $company) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $work_exp_type,
            'position' => $work_position[$key],
            'year_of_experience' => $work_exp_yrs[$key] ?? 0,
            'company_name' => $company,
            'salary' => $work_salary[$key],
            'exit_reason' => $exit_reason[$key],
            'start_date' => $work_st_date[$key] ? date('Y-m-d', strtotime($work_st_date[$key])) : null,
            'end_date' => $work_end_date[$key] ? date('Y-m-d', strtotime($work_end_date[$key])) : null,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }


      // Handle staff credentials
      if ($credential_check == 1 && $request->has('credential')) {
          foreach ($request->credential as $credential_id => $data) {
              // Skip if username is empty
              if (!empty($data['username'])) {
                  StaffCredentialModel::create([
                      'staff_id'      => $add_staff->sno,
                      'credential_id' => $credential_id,
                      'user_name'     => $data['username'],
                      'password'      => $data['password'] ?? null,
                      'url_link'      => $data['url'] ?? null,
                      'description'   => $data['description'] ?? null,
                      'created_by'    => $request->user()->user_id,
                      'updated_by'    => $request->user()->user_id,
                  ]);
              }
          }
      }
        
      if($company_type == 2){
           $contact_person_name_first=$request->contact_person_name[0];
           $contact_person_no_first=$request->contact_person_no[0];
           if($add_staff->staff_image){
              $staff_image_url=url("staff_images/Buisness/{$add_staff->company_id}/{$add_staff->entity_id}/{$add_staff->staff_image}");
           }else{
                $staff_image_url=NULL;
           }

          $payload=[
            'sno' => $add_staff->sno,
            'entity_id' => $add_staff->entity_id,
            'staff_id' => $staff_id,
            'branch_id' => 1,
            'shift_time_id' => 1,
            'multi_branch_access'    => '',
            'sub_department_id' => $erp_division_id ?? 0,
            'department_id' => $erp_department_id ?? 0,
            'role_id' => $erp_role_id,
            'under_role_id' => $erp_under_role_id,
            'exp_type' => $work_exp_type,
            'staff_name' => $add_staff->staff_name,
            'mobile_no' => $add_staff->mobile_no,
            'alternative_no' => NULL,
            'email_id' => $add_staff->email_id,
            'gender' => $add_staff->gender,
            'dob' => $add_staff->dob,
            'date_of_joining' => $add_staff->date_of_joining,
            'contact_person_name' => $contact_person_name_first,
            'contact_person_no' => $contact_person_no_first,
            'martial_status' => $marital_status ?? null,
            'address' => $add_staff->address ?? null,
            'staff_image' => $staff_image_url ?? null,
            'attachment' =>  $attachments_url ?? null,
            'nick_name' => $add_staff->nick_name ?? null,
            'position_role' => $erp_job_role_id ?? null,
            'description' => $add_staff->description ?? null,
            'basic_salary' => $add_staff->basic_salary ?? null,
            'per_hour_cost' => $add_staff->per_hour_cost ?? null,
            'login_access' => 1,
            'employee_skill_id' => 0,
            'user_name' => $add_staff->user_name,
            'password'  => $add_staff->password,
            'work_company_name'  => $work_company_name,
            'work_position'  => $work_position,
            'work_exp_yrs'  => $work_exp_yrs,
            'work_salary'  => $work_salary,
            'exit_reason'  => $exit_reason,
            'work_st_date'  => $work_st_date,
            'work_end_date'  => $work_end_date,
            'credentials'  => $request->credential,
            'qualification_type'  => $qualification_type,
            'degree'  => $degree,
            'major'  => $major,
            'univ_name'  => $univ_name,
            
          ];
            $this->dispatchWebhooks($payload, 1);
      }

        $response = [
            'status' => 200,
            'message' => 'Staff added successfully',
            'staff_id' => $staff_id,
            'attachments' => $attachments_url,
        ];

        if ($request->ajax()) {
            return response()->json($response);
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff added Successfully!'
        ]);
        return redirect('hr_enroll/manage_staff');
    } else {
      if ($request->ajax()) {
            return response()->json([
                'status' => 500,
                'message' => 'Could not add the Staff!',
            ]);
        }

        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Staff !'
        ]);
        return redirect('hr_enroll/manage_staff');
    }
   
  }

  // unq Check add
  public function checkunique_user_name()
  {
    $username = request()->input('value');
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }

  public function checkStaffMobileExists(Request $request)
  {
    $staff_mobile = $request->input('mobile');

    // Assuming you have a Lead model with a mobile field
    // $exists = StaffModel::where('mobile_no', $staff_mobile)->exists();
    $staff = StaffModel::where('mobile_no', $staff_mobile)
      ->where('status', '!=', 2)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff Mobile Number already assigned!',
        'data'    => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'mobile no available!',
        'data'    => 0,
      ], 200);
    }
  }



  public function edit($id,Request $request)
  {
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

      // Check if decryption failed
      if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }

      $staffId=$decryptedValue;

      $staffData = StaffModel::where('egc_staff.status', '!=', 2)->where('egc_staff.sno', $staffId)->first();
      $staffFamily = StaffFamilyModel::where('status', '!=', 2)->where('staff_id', $staffId)->first();
      $staffEducation = StaffEducationInfoModel::where('status', '!=', 2)->where('staff_id', $staffId)->get();
      $staffWork = StaffWorkInfoModel::where('staff_id', $staffId)->where('status', '!=', 2)->get();
      $attachments = StaffAttachmentModel::where('staff_id', $staffId)->where('status', '!=', 2)->get();
      $staffCredntial = StaffCredentialModel::where('staff_id', $staffId)->where('status', '!=', 2)->get();

      $CourseTag = CourseTagModel::where('status', '!=', 2)->pluck('course_tag_name');
      $skillTagList = SkillTagModel::where('status', '!=', 2)->pluck('skill_tag_name');
     
      
    $firstLanguages = ['Hindi','Malayalam','English','Tamil'];
      $fieldList = "'" . implode("','", $firstLanguages) . "'";
      $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $hobbyList = HobbyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $relationshipList = RelationshipModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $jobPositionlist = JobpositionModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $documentTypeList = DocumentModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $documentCheckList = DocumentCheckListModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $qualificationList = QualificationModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      $languageList = LanguageModel::where('status', 0)
          ->orderByRaw("FIELD(name, $fieldList) DESC") 
          ->orderBy('name', 'ASC')
          ->get();
     $credential_list = CredentialModel::where('status', 0)->orderBy('sno', 'ASC')->get(); 
     $management_department = DepartmentModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $management_user_role = UserRoleModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $questions = HrQuestionnaireModel::with(['depends' => function($q) {
        $q->where('status', 0);
    }])->where('status', 0)->get();

    
    return view('content.hr_management.hr_enroll.manage_staff.edit_staff',[
      'staffData' => $staffData,
      'staffFamily' => $staffFamily,
      'staffWork' => $staffWork,
      'attachments' => $attachments,
      'staffEducation' => $staffEducation,
      'staffEducation' => $staffEducation,
      'staffCredntial' => $staffCredntial,
      'CourseTag' => $CourseTag,
       'skillTagList' => $skillTagList,
      'social_media_list' => $social_media_list,
        'company_list' => $company_list,
        'source_list' => $source_list,
        'documentTypeList' => $documentTypeList,
        'jobPositionlist' => $jobPositionlist,
        'qualificationList' => $qualificationList,
        'languageList' => $languageList,
        'management_department' => $management_department,
        'management_user_role' => $management_user_role,
        'documentCheckList' => $documentCheckList,
        'credential_list' => $credential_list,
        'hobbyList' => $hobbyList,
        'relationshipList' => $relationshipList,
        'questions' => $questions
    ]);
  }

    // unq esit chk username
  public function checkunique_user_name_edit()
  {
    $username = request()->input('value');
    $id = request()->input('id');
    // return $id;
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => $staff,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }
  // unq esit chk username
  public function checkStaffMobileExists_edit()
  {
    $staff_mobile = request()->input('mobile');
    $id           = request()->input('id');
    // return $id;
    $staff = StaffModel::where('mobile_no', $staff_mobile)
      ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff Mobile Number already assigned!',
        'data'    => $staff,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Mobile Number available!',
        'data'    => 0,
      ], 200);
    }
  }

  public function exit_staff()
  {
    return view('content.hr_management.hr_enroll.manage_staff.exit_staff_list');
  }


  public function Status($id, Request $request)
  {

    $staff =  StaffModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_StaffModel = StaffModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }


public function uploadTempDocument(Request $request)
{
    try {
        // ✅ Validate the upload
        $request->validate([
            'file' => 'required|file|max:20480', // 20 MB max
        ]);

        $file = $request->file('file');
        $originalName = preg_replace('/\s+/', '_', $file->getClientOriginalName());
        $filename = time() . '_' . $originalName;

        $destinationPath = public_path('staff_attachments/temp');

        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0777, true);
        }

        // ✅ Move uploaded file
        $file->move($destinationPath, $filename);

        // ✅ Respond with a clear success JSON
        return response()->json([
            'status'   => true,
            'message'  => 'File uploaded successfully',
            'filename' => $filename,
            'path'     => asset("staff_attachments/temp/{$filename}"),
        ], 200);

    } catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'status'  => false,
            'message' => $e->validator->errors()->first(),
        ], 422);
    } catch (\Exception $e) {
        return response()->json([
            'status'  => false,
            'message' => 'Server error: ' . $e->getMessage(),
        ], 500);
    }
}

  public function deleteTempDocument(Request $request)
  {
      try {
          $filename = $request->input('filename');

          if (!$filename) {
              return response()->json([
                  'status' => false,
                  'message' => 'Missing filename parameter'
              ], 400);
          }

          $filePath = public_path("staff_attachments/temp/{$filename}");

          if (file_exists($filePath)) {
              unlink($filePath);
              return response()->json([
                  'status' => true,
                  'message' => 'File deleted successfully'
              ]);
          }

          return response()->json([
              'status' => false,
              'message' => 'File not found'
          ], 404);

      } catch (\Exception $e) {
          return response()->json([
              'status' => false,
              'message' => 'Server error: ' . $e->getMessage()
          ], 500);
      }
  }

 


  public function UpdateStaffStage(Request $request)
  {

   
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'stage' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 401);
    }

    $user_id = $request->user()->user_id;
    $stage = $request->stage;
    // return $request;
    // Determine staff serial number

    // 
    $completion_percentage = $request->completion_percentage;
    if($stage){
        $edit_id = $request->edit_id;
        $update_staff = StaffModel::where('sno', $edit_id)->first();
        if($update_staff){
          if($stage == 1){
          
            $mobile_no = $request->mobile_no;
            // Stage 1 Base Details
            $staff_name = $request->staff_name;
            
            
            $gender = $request->gender ?? 1;
            $dob = $request->dob ? date('Y-m-d', strtotime($request->dob)) : NULL;
            $email_id = $request->email_id ?? NULL;
            $mother_tongue = $request->mother_tongue ?? NULL;
            $languages = $request->Languages ? json_encode($request->Languages) : NULL;
            $hobby = $request->hobby ? json_encode($request->hobby) : NULL;
            $description = $request->description ?? NULL;
            // Handle staff image upload
            $staff_image = '';
            if ($request->hasFile('staff_add_icon')) {
                $image = $request->file('staff_add_icon');
                $extension = $image->extension();

              if ($company_type == 1) {
                  $folderPath = public_path('staff_images/Management');
              } else {
                  $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");
              }
              // Create directory if not exists
                if (!File::exists($folderPath)) {
                    File::makeDirectory($folderPath, 0777, true, true);
                }
                  // Build file name
                    $staff_imageName = 'staff_' . $sno . '.' . $extension;
                  // Move uploaded image
                    $image->move($folderPath, $staff_imageName);
                    $staff_image = $staff_imageName;
            } else {
              $staff_image = $request->old_staff_image;
            }

              $update_staff->staff_name = $request->staff_name;
              $update_staff->mobile_no = $request->mobile_no;
              $update_staff->email_id = $request->email_id;
              $update_staff->gender = $request->gender;
              $update_staff->hobby = $hobby ;
              $update_staff->mother_tongue = $mother_tongue;
              $update_staff->languages = $languages;
              $update_staff->staff_image = $staff_image ?? null;
              $update_staff->dob = date('Y-m-d', strtotime($request->dob));
              $update_staff->description =$description;
              $update_staff->update();
              if($update_staff){
                return response()->json([
                    'status' => 200,
                    'message' => 'Staff Stage '.$stage.' Updated successfully',
                    'error_msg' => null,
                    'stage' => $stage,
                  ], 200);
              }
          }elseif($stage == 2){

             // Stage 2 Family Details
              $father_name = $request->father_name;
              $father_occup = $request->father_occup;
              $mother_name = $request->mother_name ?? NULL;
              $mother_occup = $request->mother_occup ?? NULL;
              $marital_status = $request->marital_status ?? 2;
              $anniversary_date = $request->anniversary_date ? date('Y-m-d', strtotime($request->anniversary_date)) : NULL;
              $spouse_name = $request->spouse_name ?? NULL;
              $spouse_mobile = $request->spouse_mobile ?? NULL;
              $spouse_is_working = $request->is_working ?? 'No';
              $spouse_dob = $request->spouse_dob ? date('Y-m-d', strtotime($request->spouse_dob)) : NULL;
              $spouse_designation = $request->spouse_designation ?? NULL;
              $spouse_company_name = $request->spouse_company_name ?? NULL;
              $spouse_salary = $request->spouse_salary ?? NULL;
              $has_children = $request->has_children ?? NULL;
              $childrenCount = $request->childrenCount ?? 0;
              $child_name = $request->child_name ??  NULL;
              $child_dob = $request->child_dob ??  NULL;
              $child_std = $request->child_std ??  NULL;
              $child_year = $request->child_year ?? NULL;
              $has_Siblings = $request->has_Siblings ?? 0;
              $siblings_detail = $request->siblings_detail ?? Null;

              // Handle children details
              $children_details = null;
              if (!empty($childrenCount) && $childrenCount > 0) {
                  $children_details_array = [];

                  for ($i = 0; $i < $childrenCount; $i++) {
                      $children_details_array[] = [
                          'child_name' => $child_name[$i] ?? null,
                          'child_dob' => isset($child_dob[$i]) ? date('Y-m-d', strtotime($child_dob[$i])) : null,
                          'child_std' => $child_std[$i] ?? null,
                          'child_year' => $child_year[$i] ?? null,
                      ];
                  }

                  $children_details = json_encode($children_details_array);
              }
              $update_staffFamily = StaffFamilyModel::where('staff_id', $edit_id)->first();
              if($update_staffFamily){

                  $update_staff->martial_status = $marital_status ?? null;
                  $update_staff->update();

                  $update_staffFamily->father_name = $father_name;
                  $update_staffFamily->father_occup = $father_occup;
                  $update_staffFamily->mother_name = $mother_name;
                  $update_staffFamily->mother_occup = $mother_occup;
                  $update_staffFamily->marital_status = $marital_status;
                  $update_staffFamily->anniversary_date = $anniversary_date;
                  $update_staffFamily->spouse_name = $spouse_name;
                  $update_staffFamily->spouse_mobile = $spouse_mobile;
                  $update_staffFamily->spouse_dob = $spouse_dob;
                  $update_staffFamily->spouse_working = $spouse_is_working;
                  $update_staffFamily->spouse_designation = $spouse_designation;
                  $update_staffFamily->spouse_company_name = $spouse_company_name;
                  $update_staffFamily->spouse_salary = $spouse_salary ?? 0;
                  $update_staffFamily->has_children = $has_children;
                  $update_staffFamily->children_count = $childrenCount;
                  $update_staffFamily->children_details = $children_details;
                  $update_staffFamily->has_siblings = $has_Siblings;
                  $update_staffFamily->siblings_detail = $siblings_detail;
                  $update_staffFamily->updated_by = $user_id ?? 1;
                  $update_staffFamily->update();

                  if($update_staffFamily){
                    return response()->json([
                        'status' => 200,
                        'message' => 'Staff Stage '.$stage.' Updated successfully',
                        'error_msg' => null,
                        'stage' => $stage,
                      ], 200);
                  }

              }else{
                $update_staff->martial_status = $marital_status ?? null;
                $update_staff->update();

                $add_family = new StaffFamilyModel();
                $add_family->staff_id = $edit_id;
                $add_family->father_name = $father_name;
                $add_family->father_occup = $father_occup;
                $add_family->mother_name = $mother_name;
                $add_family->mother_occup = $mother_occup;
                $add_family->marital_status = $marital_status;
                $add_family->anniversary_date = $anniversary_date;
                $add_family->spouse_name = $spouse_name;
                $add_family->spouse_mobile = $spouse_mobile;
                $add_family->spouse_dob = $spouse_dob;
                $add_family->spouse_working = $spouse_is_working;
                $add_family->spouse_designation = $spouse_designation;
                $add_family->spouse_company_name = $spouse_company_name;
                $add_family->spouse_salary = $spouse_salary ?? 0;
                $add_family->has_children = $has_children;
                $add_family->children_count = $childrenCount;
                $add_family->children_details = $children_details;
                $add_family->has_siblings = $has_Siblings;
                $add_family->siblings_detail = $siblings_detail;
                $add_family->created_by = $request->user()->user_id ?? 1;
                $add_family->updated_by = $request->user()->user_id ?? 1;
                $add_family->save();

                if($add_family){
                    return response()->json([
                        'status' => 200,
                        'message' => 'Staff Stage '.$stage.' Updated successfully',
                        'error_msg' => null,
                        'stage' => $stage,
                      ], 200);
                  }
              }

          }elseif($stage == 3){
            $permanent_address =$request->permanent_address ?? Null;
            $residential_address = $request->residential_address ?? NULL;
            $staff_location_url = $request->staff_location_url ?? NULL;
            $staff_latitude = $request->staff_latitude ?? NULL;
            $staff_longitude = $request->staff_longitude ?? NULL;
            $contact_person_name = $request->contact_person_name ? json_encode($request->contact_person_name) : NULL;
            $contact_person_no = $request->contact_person_no ? json_encode($request->contact_person_no) : NULL;
            $contact_person_relation = $request->contact_person_relation ? json_encode($request->contact_person_relation) : NULL;

              $update_staff->address = $permanent_address ?? null;
              $update_staff->residential_address = $residential_address ?? null;
              $update_staff->location_url = $staff_location_url ?? null;
              $update_staff->latitude = $staff_latitude ?? null;
              $update_staff->longitude = $staff_longitude ?? null;
              $update_staff->contact_person_name = $contact_person_name;
              $update_staff->contact_person_no = $contact_person_no;
              $update_staff->contact_person_relation = $contact_person_relation;
              $update_staff->update();

              if($update_staff){
                return response()->json([
                    'status' => 200,
                    'message' => 'Staff Stage '.$stage.' Updated successfully',
                    'error_msg' => null,
                    'stage' => $stage,
                  ], 200);
              }

          }elseif($stage == 4){
            // Stage 4 social Media Detils
            $socialMediaData = $request->social_media;
              $socialMediaData = array_filter($socialMediaData, function($value) {
                  return !is_null($value) && $value !== '';
              });
            $socialMediaData = $socialMediaData ? json_encode($socialMediaData) : Null;

            $update_staff->social_media_details  = $socialMediaData;
            $update_staff->update();

              if($update_staff){
                return response()->json([
                    'status' => 200,
                    'message' => 'Staff Stage '.$stage.' Updated successfully',
                    'error_msg' => null,
                    'stage' => $stage,
                  ], 200);
              }

          }elseif($stage == 5){
              $qualification_type = $request->qualification_type ?? [];
              $degree = $request->degree ?? [];
              $major = $request->major ?? [];
              $univ_name = $request->univ_name ?? [];
              $pass_year = $request->pass_year ?? [];
              $is_Course = $request->is_Course ?? NULL;
              if($is_Course == 'Yes'){
                $course_tag = $request->course_tag ? json_encode($request->course_tag) : NULL;
              }else{
                $course_tag = NULL;
              }
              
              $existingQualification = StaffEducationInfoModel::where('staff_id', $edit_id)->get();
              $existingqualifyIds = $existingQualification->pluck('qualification_type')->toArray();
              $newQualifyId = $qualification_type;
              $removedQualifyId = array_diff($existingqualifyIds, $newQualifyId);
              foreach ($removedQualifyId as $qualifyId) {
                  $qualifyToRemove = StaffEducationInfoModel::where('staff_id', $edit_id)
                      ->where('qualification_type', $qualifyId)
                      ->first();

                  if ($qualifyToRemove) {
                      $qualifyToRemove->status = 2;
                      $qualifyToRemove->save();
                  }
              }

              foreach ($qualification_type as $key => $qualification) {
                StaffEducationInfoModel::updateOrCreate(
                  [
                      'staff_id' => $edit_id,
                      'qualification_type' => $qualification, 
                  ],
                  [
                    'degree_name' => $degree[$key],
                    'major' => $major[$key],
                    'university_name' => $univ_name[$key],
                    'year' => $pass_year[$key],
                    'created_by' => $request->user()->user_id,
                    'updated_by' => $request->user()->user_id,
                  ]
                );
              }

              
              
              $update_staff->is_Course=$is_Course;
              $update_staff->course_tag=$course_tag;
              $update_staff->update();

              if($update_staff){
                  return response()->json([
                    'status' => 200,
                    'message' => 'Staff Stage '.$stage.' Updated successfully',
                    'error_msg' => null,
                    'stage' => $stage,
                  ], 200);
              }
              


          }elseif($stage == 6){

            // stage 6 Work Exp Details
            $work_exp_type = $request->work_type ?? 1;
            $total_company_shift = $request->total_company_shift ?? 1;
            $total_experience = $request->total_experience ?? 1;
            $edit_exp_id = $request->edit_exp_id ?? [];
            $work_company_name = $request->company_name ?? [];
            $work_position = $request->position ?? [];
            $work_exp_yrs = $request->exp_yrs ?? [];
            $work_salary = $request->salary ?? [];
            $work_st_date = $request->work_st_date ?? [];
            $work_end_date = $request->work_end_date ?? [];
            $exit_reason = $request->ExitReason ?? [];

             $edit_exp_idFilter = array_filter($edit_exp_id, function($value) {
                  return !is_null($value) && $value !== '';
              });
              $existingWorkInfo = StaffWorkInfoModel::where('staff_id', $edit_id)->get();
              $existingWorkIds = $existingWorkInfo->pluck('sno')->toArray();
              $newWorkId = $edit_exp_idFilter;
              $removedWorkId = array_diff($existingWorkIds, $newWorkId);
              foreach ($removedWorkId as $workId) {
                  $workToRemove = StaffWorkInfoModel::where('sno', $workId)
                      ->first();

                  if ($workToRemove) {
                      $workToRemove->status = 2;
                      $workToRemove->save();
                  }
              }

             

              if ($work_exp_type == 2) {
                foreach ($request->edit_exp_id as $key => $expId) {
                    if ($expId) {
                        // UPDATE EXISTING
                        StaffWorkInfoModel::where('sno', $expId)->update([
                            'staff_type' => $work_exp_type,
                            'company_name' => $request->company_name[$key],
                            'position' => $request->position[$key],
                            'year_of_experience' => $request->exp_yrs[$key],
                            'salary' => $request->salary[$key],
                            'start_date' => $request->work_st_date[$key] ? date('Y-m-d', strtotime($request->work_st_date[$key])) : null,
                            'end_date' => $request->work_end_date[$key] ? date('Y-m-d', strtotime($request->work_end_date[$key])) : null,
                            'exit_reason' => $request->ExitReason[$key],
                            'updated_by' => $request->user()->user_id ?? 1,
                        ]);
                    } else {
                        // CREATE NEW
                        StaffWorkInfoModel::create([
                            'staff_id' => $edit_id,
                            'staff_type' => $work_exp_type,
                            'company_name' => $request->company_name[$key],
                            'position' => $request->position[$key],
                            'year_of_experience' => $request->exp_yrs[$key],
                            'salary' => $request->salary[$key],
                            'start_date' => $request->work_st_date[$key],
                            'end_date' => $request->work_end_date[$key],
                            'exit_reason' => $request->ExitReason[$key],
                            'created_by' => $request->user()->user_id ?? 1,
                            'updated_by' => $request->user()->user_id ?? 1,
                        ]);
                    }
                }
              }

           

            $update_staff->exp_type = $work_exp_type;
            $update_staff->total_company_shift = $total_company_shift;
            $update_staff->total_experience = $total_experience;
            $update_staff->update();

            // Initialize doc_types from the request
            $doc_types = $request->doc_type ?? [];
            $uploadedFiles = $request->input('uploaded_files');

            // Decode uploaded_files if JSON
            if (is_string($uploadedFiles)) {
                $uploadedFiles = json_decode($uploadedFiles, true);
            }

            if (!is_array($uploadedFiles)) {
                $uploadedFiles = [];
            }

            $docType = is_array($doc_types) ? $doc_types : [];

            foreach ($uploadedFiles as $index => $files) {

                $docTypeId = $docType[$index] ?? null;
                if (!$docTypeId) continue;

                // Decode file list if still JSON
                if (is_string($files)) {
                    $files = json_decode($files, true);
                }

                if (!is_array($files) || count($files) == 0) continue;

                /*  
                --------------------------------------------------------------
                  FIX 1: Reset attachments per DOCUMENT (not globally)
                --------------------------------------------------------------
                */
                $attachments = [];

                $finalPath = public_path("staff_attachments/$edit_id/$docTypeId/");
                if (!file_exists($finalPath)) {
                    mkdir($finalPath, 0777, true);
                }

                foreach ($files as $filename) {

                    $tempPath = public_path("staff_attachments/temp/$filename");

                    if (!file_exists($tempPath)) {
                        Log::error("File not found in temp: $tempPath");
                        continue;
                    }

                    // Move file
                    rename($tempPath, $finalPath . $filename);

                    $attachments[] = $filename; // Only THIS doc type's files
                }

                /*
                --------------------------------------------------------------
                  FIX 2: Save DB row ONCE per document type
                --------------------------------------------------------------
                */
                StaffAttachmentModel::updateOrCreate(
                    [
                        'staff_id'    => $edit_id,
                        'document_id' => $docTypeId
                    ],
                    [
                        'attachment_name' => json_encode($attachments),
                        'created_by'      => $user_id,
                        'updated_by'      => $user_id,
                    ]
                );
            }

            /*
            --------------------------------------------------------------
              FIX 3: Mark removed document types as inactive
            --------------------------------------------------------------
            */
            $existingDocIds = StaffAttachmentModel::where('staff_id', $edit_id)
                ->pluck('document_id')
                ->toArray();

            $newDocIds = $docType;
            $removedDocIds = array_diff($existingDocIds, $newDocIds);

            foreach ($removedDocIds as $docId) {
                StaffAttachmentModel::where('staff_id', $edit_id)
                    ->where('document_id', $docId)
                    ->update(['status' => 2]);
            }

            /*
            --------------------------------------------------------------
              FIX 4: Save global attachment if needed
            --------------------------------------------------------------
            */
            $update_staff->attachment = json_encode($uploadedFiles);
            $update_staff->update();

            return response()->json([
                'status'  => 200,
                'message' => 'Staff Stage ' . $stage . ' Updated successfully'
            ], 200);
          }elseif($stage == 7){

              $company_type = $request->company ?? 1;
              $company_id   = $request->staff_company_name ?? 0;
              $entity_id    = $request->entity_name ?? 0;
              $branch_id    = $request->branch_id ?? 0;

            if($company_type == 1){
              $department_id = $request->management_depart ?? 0;
              $division_id = $request->management_division ?? 0;
              $role_id = $request->management_user_role ?? 0;
              $job_role_id = $request->management_job_role ?? 0;
            }else{
              $department_id = $request->business_depart ?? 0;
              $division_id = $request->business_division ?? 0;
              $role_id = $request->business_user_role ?? 0;
              $job_role_id = $request->business_job_role ?? 0;
            }

              $erp_branch_id = $request->erp_branch_id ?? 0;
              $erp_department_id = $request->erp_department_id ?? 0;
              $erp_division_id = $request->erp_division_id ?? 0;
              $erp_job_role_id = $request->erp_job_role_id ?? 0;
              $erp_role_id = $request->erp_role_id ?? 0;
              $erp_under_role_id = $request->erp_under_role_id ?? 0;
            
              $nick_name = $request->pseudo_name ?? NULL;
              $doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : NULL;
              $basic_salary = $request->basic_salary ?? 0;
              $per_hr_cost = $request->per_hr_cost ?? 0;
              $skill_tag = $request->skill_tag ? json_encode($request->skill_tag) : NULL;
              $loginuser_name = $request->loginuser_name ?? Null;
              $loginpassword = $request->loginpassword ?? Null;
              $credential_check = $request->other_access ?? 0;
              $update_staff->company_type = $company_type;
              $update_staff->company_id = $company_id;
              $update_staff->entity_id    = $entity_id;
              $update_staff->entity_id    = $entity_id;
              $update_staff->branch_id    = $branch_id;
              $update_staff->division_id = $division_id ?? 0;
              $update_staff->department_id = $department_id ?? 0;
              $update_staff->role_id = $role_id;
              $update_staff->job_role_id = $job_role_id;
              $update_staff->date_of_joining = $doj;
              $update_staff->nick_name = $nick_name ?? null;
              $update_staff->basic_salary = $basic_salary;
              $update_staff->per_hour_cost = $per_hr_cost;
              $update_staff->knowledge_tag = $skill_tag;
              $update_staff->credential = $credential_check;
              $update_staff->user_name = $loginuser_name;
              $update_staff->password  = $loginpassword;
              $update_staff->update();

              User::updateOrCreate(
                [
                  'user_id' => $edit_id,
                ],
                [
                'company_type' => $update_staff->company_type,
                'company_id' => $update_staff->company_id,
                'entity_id' => $update_staff->entity_id,
                'role_id' => $update_staff->role_id ?? 0,
                'branch_id' =>  $update_staff->branch_id,
                'name' => $loginuser_name,
                'password' => Hash::make($loginpassword),
                'email' => $update_staff->email_id,
                'created_by' => $request->user()->user_id ?? 1,
                'updated_by' => $request->user()->user_id ?? 1,
              ]);

              if ($credential_check == 1 && $request->has('credential')) {
                     $existingCrendential = StaffCredentialModel::where('staff_id', $edit_id)
                          ->pluck('credential_id')
                          ->toArray();

                      $newCrendIds = $request->credential;
                      $removedCredential = array_diff($existingCrendential, $newCrendIds);

                      foreach ($removedCredential as $credenId) {
                          StaffCredentialModel::where('staff_id', $edit_id)
                              ->where('credential_id', $credenId)
                              ->update(['status' => 2]);
                      }
                      
                  foreach ($request->credential as $credential_id => $data) {
                    
                      // Skip if username is empty
                      if (!empty($data['username'])) {
                          StaffCredentialModel::updateOrCreate(
                            [
                              'staff_id'      => $edit_id,
                              'credential_id' => $credential_id,
                            ],
                            [
                             
                              'user_name'     => $data['username'],
                              'password'      => $data['password'] ?? null,
                              'url_link'      => $data['url'] ?? null,
                              'description'   => $data['description'] ?? null,
                              'created_by'    => $request->user()->user_id,
                              'updated_by'    => $request->user()->user_id,
                          ]);
                      }
                  }
              }

              return response()->json([
                'status'  => 200,
                'message' => 'Staff Stage ' . $stage . ' Updated successfully'
            ], 200);

          }elseif($stage == 8){

            $applied_position = $request->applied_position ? json_encode($request->applied_position) : NULL;
            $interview_company = $request->interview_company ? json_encode($request->interview_company) : NULL;
            $source_id = $request->source_id;
            $source_details = $request->source_details ?? Null;

            $data = $request->all();
            // initialize arrays
            $questions = [];
            $dependents = [];
            // loop through request inputs
            foreach ($data as $key => $value) {
                // 🎯 Handle main question inputs (like q_1, q_2)
                if (preg_match('/^q_(\d+)$/', $key, $matches)) {
                    $questionId = $matches[1];
                    $questions[$questionId] = $value ?? null;
                }
                // 🎯 Handle dependent question inputs (like depend_1, depend_2)
                if (preg_match('/^depend_(\d+)$/', $key, $matches)) {
                    $dependId = $matches[1];
                    $dependents[$dependId] = $value ?? null;
                }
            }
            // Combine both into one structured JSON
            $application_details = [
                'questions' => (object) $questions,
                'dependents' => (object) $dependents,
            ];

            $update_staff->applied_position = $applied_position ?? null;
            $update_staff->source_id = $source_id ?? null;
            $update_staff->source_details = $source_details ?? null;
            $update_staff->applied_company_ids = $interview_company ?? null;
            $update_staff->application_details = !empty($application_details) ? json_encode($application_details, JSON_PRETTY_PRINT) : null; 
            $update_staff->update();

            return response()->json([
                'status'  => 200,
                'message' => 'Staff Stage ' . $stage . ' Updated successfully'
            ], 200);

          }elseif($stage == 9){
            $document_checked =$request->document_checked ? json_encode($request->document_checked) : NULL;
            $update_staff->document_checklist = $document_checked; 
            $update_staff->update();

            return response()->json([
                'status'  => 200,
                'message' => 'Staff Stage ' . $stage . ' Updated successfully'
            ], 200);
          }elseif($stage == 10){
            // $update_staff->application_details = !empty($application_details) ? json_encode($application_details, JSON_PRETTY_PRINT) : null; 
            // $update_staff->update();

            return response()->json([
                'status'  => 200,
                'message' => 'Staff Stage ' . $stage . ' Updated successfully'
            ], 200);
          }

        }else{
          return response()->json([
            'status' => 401,
            'message' => 'Staff Not Found',
            'error_msg' => 'Staff Not Found',
            'data' => null,
          ], 401);
        }
      
    }else{
       return response()->json([
        'status' => 401,
        'message' => 'Something is Wrong Please Try Again',
        'error_msg' => 'Stage is Required',
        'data' => null,
      ], 401);
    }
    
      return $request;
    

      // stage 8 Document Checklist Details
       
   
        // Create new staff record
        $add_staff = new StaffModel();
        $add_staff->staff_id = $staff_id;
        $add_staff->company_type = $company_type;
        $add_staff->company_id = $company_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->branch_id    = $branch_id;
        $add_staff->division_id = $division_id ?? 0;
        $add_staff->department_id = $department_id ?? 0;
        $add_staff->role_id = $role_id;
        $add_staff->job_role_id = $job_role_id;
        $add_staff->staff_name = $request->staff_name;
        $add_staff->mobile_no = $request->mobile_no;
        // $add_staff->alternative_no = $request->alternative_no;
        $add_staff->email_id = $request->email_id;
        $add_staff->exp_type = $work_exp_type;
        $add_staff->total_company_shift = $total_company_shift;
        $add_staff->total_experience = $total_experience;
        $add_staff->gender = $request->gender;
        $add_staff->hobby = $hobby ;
        $add_staff->mother_tongue = $mother_tongue;
        $add_staff->languages = $languages;
        $add_staff->dob = date('Y-m-d', strtotime($request->dob));
        $add_staff->date_of_joining = $doj;
        $add_staff->contact_person_name = $contact_person_name;
        $add_staff->contact_person_no = $contact_person_no;
        $add_staff->contact_person_relation = $contact_person_relation;
        $add_staff->martial_status = $marital_status ?? null;
        $add_staff->address = $permanent_address ?? null;
        $add_staff->residential_address = $residential_address ?? null;
        $add_staff->location_url = $staff_location_url ?? null;
        $add_staff->latitude = $staff_latitude ?? null;
        $add_staff->longitude = $staff_longitude ?? null;
        $add_staff->staff_image = $staff_image ?? null;
        $add_staff->attachment = !empty($attachments) ? json_encode($attachments) : null;
        $add_staff->nick_name = $nick_name ?? null;
        $add_staff->applied_position = $applied_position ?? null;
        $add_staff->source_id = $source_id ?? null;
        $add_staff->source_details = $source_details ?? null;
        $add_staff->description = $description ?? null;
        $add_staff->basic_salary = $basic_salary;
        $add_staff->per_hour_cost = $per_hr_cost;
        $add_staff->knowledge_tag = $skill_tag;
        $add_staff->credential = $credential_check;
        $add_staff->user_name = $loginuser_name;
        $add_staff->password  = $loginpassword;
        $add_staff->completion_percentage  = $completion_percentage;
        $add_staff->social_media_details  = $socialMediaData;
        $add_staff->document_checklist  = $document_checked;
        $add_staff->application_details = json_encode($application_details, JSON_PRETTY_PRINT);
        $add_staff->created_by = $request->user()->user_id;
        $add_staff->updated_by = $request->user()->user_id;

        $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {

      


      // Add User for login credentials
        User::create([
          'user_id' => $add_staff->sno,
          'company_type' => $add_staff->company_type,
          'company_id' => $add_staff->company_id,
          'entity_id' => $add_staff->entity_id,
          'role_id' => $add_staff->role_id ?? 0,
          'branch_id' =>  $add_staff->branch_id,
          'name' => $loginuser_name,
          'password' => Hash::make($loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id ?? 1,
          'updated_by' => $request->user()->user_id ?? 1,
        ]);
      
      
      
      //  return $request;
      // Handle work information
      if ($work_exp_type == 2) {
        foreach ($work_company_name as $key => $company) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $work_exp_type,
            'position' => $work_position[$key],
            'year_of_experience' => $work_exp_yrs[$key] ?? 0,
            'company_name' => $company,
            'salary' => $work_salary[$key],
            'exit_reason' => $exit_reason[$key],
            'start_date' => $work_st_date[$key] ? date('Y-m-d', strtotime($work_st_date[$key])) : null,
            'end_date' => $work_end_date[$key] ? date('Y-m-d', strtotime($work_end_date[$key])) : null,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }


      // Handle staff credentials
      if ($credential_check == 1 && $request->has('credential')) {
          foreach ($request->credential as $credential_id => $data) {
              // Skip if username is empty
              if (!empty($data['username'])) {
                  StaffCredentialModel::create([
                      'staff_id'      => $add_staff->sno,
                      'credential_id' => $credential_id,
                      'user_name'     => $data['username'],
                      'password'      => $data['password'] ?? null,
                      'url_link'      => $data['url'] ?? null,
                      'description'   => $data['description'] ?? null,
                      'created_by'    => $request->user()->user_id,
                      'updated_by'    => $request->user()->user_id,
                  ]);
              }
          }
      }
        
      if($company_type == 2){
           $contact_person_name_first=$request->contact_person_name[0];
           $contact_person_no_first=$request->contact_person_no[0];
           if($add_staff->staff_image){
              $staff_image_url=url("staff_images/Buisness/{$add_staff->company_id}/{$add_staff->entity_id}/{$add_staff->staff_image}");
           }else{
                $staff_image_url=NULL;
           }

          $payload=[
            'sno' => $add_staff->sno,
            'entity_id' => $add_staff->entity_id,
            'staff_id' => $staff_id,
            'branch_id' => 1,
            'shift_time_id' => 1,
            'multi_branch_access'    => '',
            'sub_department_id' => $erp_division_id ?? 0,
            'department_id' => $erp_department_id ?? 0,
            'role_id' => $erp_role_id,
            'under_role_id' => $erp_under_role_id,
            'exp_type' => $work_exp_type,
            'staff_name' => $add_staff->staff_name,
            'mobile_no' => $add_staff->mobile_no,
            'alternative_no' => NULL,
            'email_id' => $add_staff->email_id,
            'gender' => $add_staff->gender,
            'dob' => $add_staff->dob,
            'date_of_joining' => $add_staff->date_of_joining,
            'contact_person_name' => $contact_person_name_first,
            'contact_person_no' => $contact_person_no_first,
            'martial_status' => $marital_status ?? null,
            'address' => $add_staff->address ?? null,
            'staff_image' => $staff_image_url ?? null,
            'attachment' =>  $attachments_url,
            'nick_name' => $add_staff->nick_name ?? null,
            'position_role' => $erp_job_role_id ?? null,
            'description' => $add_staff->description ?? null,
            'basic_salary' => $add_staff->basic_salary ?? null,
            'per_hour_cost' => $add_staff->per_hour_cost ?? null,
            'login_access' => 1,
            'employee_skill_id' => 0,
            'user_name' => $add_staff->user_name,
            'password'  => $add_staff->password,
            'work_company_name'  => $work_company_name,
            'work_position'  => $work_position,
            'work_exp_yrs'  => $work_exp_yrs,
            'work_salary'  => $work_salary,
            'exit_reason'  => $exit_reason,
            'work_st_date'  => $work_st_date,
            'work_end_date'  => $work_end_date,
            'credentials'  => $request->credential,
            'qualification_type'  => $qualification_type,
            'degree'  => $degree,
            'major'  => $major,
            'univ_name'  => $univ_name,
            
          ];
            $this->dispatchWebhooks($payload, 1);
      }

        $response = [
            'status' => 200,
            'message' => 'Staff added successfully',
            'staff_id' => $staff_id,
            'attachments' => $attachments_url,
        ];

        if ($request->ajax()) {
            return response()->json($response);
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Staff added Successfully!'
        ]);
        return redirect('hr_enroll/manage_staff');
    } else {
      if ($request->ajax()) {
            return response()->json([
                'status' => 500,
                'message' => 'Could not add the Staff!',
            ]);
        }

        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Staff !'
        ]);
        return redirect('hr_enroll/manage_staff');
    }
   
  }

// dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module','Staff_Add_Hook')->where('entity_id',$broadcast['entity_id'])->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\StaffModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

          // broadcast creation once
          broadcast(new WebhookDispatchedEvent($dispatch));

          // enqueue the job
          SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks'); 
        }
          
  }

   protected function dispatchUpdateWebhooks(StaffModel $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast->entity_id)->first();
          if($webhook){
              $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => get_class($broadcast),
                'dispatchable_id' => $broadcast->sno,
                'message_uuid' => $broadcast->sno,
                'payload' => $broadcast->toArray(),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // broadcast creation once
            // broadcast(new WebhookDispatchedEvent($dispatch));

            // enqueue the job
            SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            
          }
     
  }


public function getCompanyStaff(Request $request)
{
    $companyId = $request->company_id;

    $staff = StaffModel::where('egc_staff.company_id', $companyId)
        ->where('egc_staff.status', '!=', 2)
        ->select(
            'egc_staff.*',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name'
        )
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_staff.sno', '>', 1)
        ->orderBy('egc_staff.staff_name', 'ASC')
        ->get();

    $html = view('content.hr_management.hr_enroll.manage_staff.company_staff_list_table', compact('staff'))->render();

    return response()->json([
        'staff_html' => $html
    ]);
}

public function bulkUpdateStaffId(Request $request)
{
    foreach ($request->updates as $row) {
        StaffModel::where('sno', $row['sno'])
                  ->update(['staff_id' => $row['staff_id']]);
    }

    return response()->json(['success' => true]);
}
}