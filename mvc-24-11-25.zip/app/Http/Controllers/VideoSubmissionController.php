<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VideoSubmission;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class VideoSubmissionController extends Controller
{
    // Show recording page
    public function show($token)
    {
        $submission = VideoSubmission::where('token', $token)->firstOrFail();
        return view('record', compact('submission'));
    }

    // Handle video upload
    public function upload(Request $request)
    {
        $request->validate([
            'video' => 'required|file|mimes:webm,mp4,mov,avi|max:204800', // max 200MB
            'token' => 'required'
        ]);

        $submission = VideoSubmission::where('token', $request->token)->firstOrFail();

        // Store video in public/videos
        $path = $request->file('video')->store('videos', 'public');

        $submission->update([
            'video_path' => $path,
        ]);

        return response()->json(['success' => true, 'path' => $path]);
    }

    // Generate new link manually (for admin use)
    public function createLink(Request $request)
    {
        $token = Str::uuid()->toString();
        $submission = VideoSubmission::create([
            'token' => $token,
            'user_id' => $request->user_id ?? null,
        ]);

        $link = url("/record/{$token}");
        return response()->json(['link' => $link]);
    }
}
