<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\User;

class Country extends Controller
{
//   protected static $branch_id = 1;
  public function index()
  {
    return view('content.settings.common.country.country_list');
  }
  public function List()
  {
    $Country = CountryModel::where('status', 0)->orderBy('id')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Country
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'country_code' => 'required|max:255',

    ]);
      
    

    
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $country_name       = $request->country_name;
      $country_code       = $request->country_code;
      
    //   $user_id                    = $request->user()->user_id;
      $chk = CountryModel::where('name', ucwords($country_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = CountryModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_category_id = "CC-0001/" . $year;
        } else {

          $data = $category_check->category_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("CC-%04d", $next_number);

          $year = substr(date("y"), -2);
          $category_id = $request . '/' . $year;
        }


        $add_category = new CountryModel();
        // $add_category->job_category_id         = $job_category_id;
        $add_category->name       = Ucfirst($country_name);
        $add_category->sortname      = $country_code;
      
        
        
        $add_category->save();
        
        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Country Successfully added!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Country!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function Edit($id)
  {
    
    $editcategory = CountryModel::where('id', $id)->first();
    
    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editcategory
    ], 200);
  }

  public function Update($id, Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'category_name' => 'required|max:255',
      'edit_country_code' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 401);
    } else {
      $category_name = $request->category_name;
      $edit_country_code = $request->edit_country_code;

      $upd_CategoryModel =  CountryModel::where('id', $id)->first();
      
      if (!$upd_CategoryModel) {
        return response([
          'status'    => 404,
          'message'   => ' category not found',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      }

      $chk = CountryModel::where('name', ucwords($category_name))
        ->where('status', '!=', 2)
        ->where('id', '!=', $id)
        ->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {

        $upd_CategoryModel->name = ucfirst($category_name);
        $upd_CategoryModel->sortname = $edit_country_code;
        $upd_CategoryModel->update();
      }

      if ($upd_CategoryModel) {
        $result = response([
          'status'    => 200,
          'message'   => 'Successfully Updated!',
          'error_msg' => null,
          'data'      => null,
        ], 200);
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CategoryModel =  CountryModel::where('id', $id)->first();
    $upd_CategoryModel->status  = 2;
    $upd_CategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_JobCategoryModel =  CountryModel::where('id', $id)->first();
    $upd_JobCategoryModel->status = $request->input('status', 0);
    $upd_JobCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
