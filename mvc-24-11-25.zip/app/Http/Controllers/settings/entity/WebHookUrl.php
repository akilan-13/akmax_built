<?php

namespace App\Http\Controllers\settings\entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\SubErpWebhookModel;
use App\Models\ManageEntityModel;



class WebHookUrl extends Controller
{
  

public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $level = SubErpWebhookModel::where('egc_sub_erp_webhooks.status', '!=', 2)
                ->select('egc_sub_erp_webhooks.*',
                    'egc_entity.entity_name',
                    'egc_company.company_name',
                    'egc_company.company_base_color',
                    )
                ->join('egc_company', 'egc_sub_erp_webhooks.company_id', 'egc_company.sno')
                ->join('egc_entity', 'egc_sub_erp_webhooks.entity_id', 'egc_entity.sno');
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%");
                      
              });
          }
        $level=$level->orderBy('egc_sub_erp_webhooks.sno', 'desc')
         ->paginate($perpage);

          

        if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'company_base_color' => $item->company_base_color,
                    'entity_name' => $item->entity_name,
                    'company_name' => $item->company_name,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }
        $entity_list = ManageEntityModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        return view('content.settings.entity.webhook_url.webhook_url', [
          'level' => $level,
          'perpage' => $perpage,
          'entity_list' => $entity_list,
            'search_filter' => $search_filter
        ]);
    }

    public function list()
    {
        $knowledge_level = SubErpWebhookModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $knowledge_level,
        ], 200);
    }

    public function Add(Request $request)
{
    // Step 1: Validate input
    $validator = Validator::make($request->all(), [
        'url_endpoint' => 'required|string|max:255',
        'hook_module'  => 'required|string|max:255',
        'entity_ids'   => 'required|array|min:1',
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    // Step 2: Get input data
    $urlEndpoint = $request->url_endpoint;
    $hookModule  = $request->hook_module;
    $entityIds   = $request->entity_ids;
    $userId      = $request->user()->user_id ?? 1;

    // Step 3: Get entities
    $entities = ManageEntityModel::whereIn('sno', $entityIds)
        ->where('status', 0)
        ->get();

    if ($entities->isEmpty()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'No valid entities found.',
        ]);
        return redirect()->back();
    }

    // Step 4: Generate next secret code
    $lastWebhook = SubErpWebhookModel::orderBy('sno', 'DESC')->first();
    $nextSecretNum = 1;
    if ($lastWebhook && preg_match('/(\d+)$/', $lastWebhook->secret, $matches)) {
        $nextSecretNum = intval($matches[1]) + 1;
    }

    $createdCount = 0;

    // Step 5: Loop through each entity and create webhook
    foreach ($entities as $entity) {
        $secret = 'egc_hook_secret' . str_pad($nextSecretNum++, 4, '0', STR_PAD_LEFT);

        $webhook = new SubErpWebhookModel();
        $webhook->name            = $entity->entity_short_name ?? 'Unknown';
        $webhook->company_id      = $entity->company_id ?? null;
        $webhook->entity_id       = $entity->sno;
        $webhook->webhook_module  = $hookModule;
        $webhook->url             = rtrim($entity->entity_base_url, '/') . '/api/webhooks/' . $urlEndpoint;
        $webhook->secret          = $secret;
        $webhook->headers         = null;
        $webhook->status          = 0;
        $webhook->created_by      = $userId;
        $webhook->updated_by      = $userId;

        $webhook->save();
        $createdCount++;
    }

    if ($createdCount > 0) {
        session()->flash('toastr', [
            'type' => 'success',
            'message' => "$createdCount Webhook(s) added successfully!",
        ]);
    } else {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add any Webhook!',
        ]);
    }

    return redirect()->back()->with('success', 'Webhook(s) Created successfully!');
}


    public function Edit($id)
    {
        $credential = SubErpWebhookModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $credential,
        ], 200);
    }

    public function Update($id, Request $request)
    {
        // ✅ Step 1: Validate input
        $validator = Validator::make($request->all(), [
            'hook_module'  => 'required|string|max:255',
            'url_endpoint' => 'required|string|max:255',
            'entity_ids'   => 'required|array|min:1',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        // ✅ Step 2: Get existing webhook
        $webhook = SubErpWebhookModel::where('sno', $id)->first();
        if (!$webhook) {
            return response([
                'status'  => 404,
                'message' => 'Webhook not found',
                'data'    => null,
            ], 404);
        }

        $userId = $request->user()->user_id ?? 1;
        $hookModule = $request->hook_module;
        $urlEndpoint = $request->url_endpoint;
        $entityIds = $request->entity_ids;

        // ✅ Step 3: Fetch valid entities
        $entities = ManageEntityModel::whereIn('sno', $entityIds)
            ->where('status', 0)
            ->get();

        if ($entities->isEmpty()) {
            return response([
                'status'  => 404,
                'message' => 'No valid active entities found!',
                'data'    => null,
            ], 404);
        }

        $updatedCount = 0;

        // ✅ Step 4: Loop through entities and update or clone
        foreach ($entities as $entity) {
            // Update existing webhook for first entity, then duplicate for others
            if ($updatedCount === 0) {
                $targetWebhook = $webhook;
            } else {
                $targetWebhook = $webhook->replicate();
                $targetWebhook->created_at = now();
            }

            $targetWebhook->name           = $entity->entity_short_name ?? $targetWebhook->name;
            $targetWebhook->company_id     = $entity->company_id ?? $targetWebhook->company_id;
            $targetWebhook->entity_id      = $entity->sno;
            $targetWebhook->webhook_module = $hookModule;
            $targetWebhook->url            = rtrim($entity->entity_base_url, '/') . '/api/webhooks/' . $urlEndpoint;
            $targetWebhook->updated_by     = $userId;
            $targetWebhook->updated_at     = now();

            $targetWebhook->save();
            $updatedCount++;
        }

        // ✅ Step 5: Response
        return response([
            'status'  => 200,
            'message' => "Webhook updated for {$updatedCount} entity(s) successfully!",
            'data'    => $webhook,
        ], 200);
    }


    public function Delete($id)
    {
        $upd_CourseCategoryModel = SubErpWebhookModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel = SubErpWebhookModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
