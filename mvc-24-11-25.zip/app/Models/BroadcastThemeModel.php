<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BroadcastThemeModel extends Model
{
    use HasFactory;
    public $table      = "egc_broadcast_theme";
    public $primaryKey = 'sno';


    protected $fillable = [
        'theme_style',
        'theme_name',
        'created_by',
        'created_at',
        'status'
    ];
}