<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffAttendanceModel extends Model
{
    use HasFactory;
    public $table      = "egc_staff_attendance";
    public $primaryKey = 'sno';


    protected $fillable = [
        'staff_attendance_id',
        'branch_id',
        'date',
        'staff_id',
        'attendance',
        'time_start',
        'time_end',
        'type',
        'reason',
        'created_by',
        'updated_by',
        'status',
    ];
}
