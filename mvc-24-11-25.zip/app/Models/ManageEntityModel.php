<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ManageEntityModel extends Model
{
    use HasFactory;
    public $table      = 'egc_entity';
    public $primaryKey = 'sno';
    protected $fillable = [
        'sno',
        'company_id',
        'entity_id',
        'entity_name',
        'entity_type',
        'entity_mail',
        'entity_ct_person',
        'entity_ct_number',
        'entity_website',
        'entity_base_url',
        'entity_location_url',
        'entity_in_menu',
        'social_media_details',
        'entity_short_name',
        'entity_logo',
        'entity_country',
        'entity_state',
        'entity_city',
        'entity_area',
        'entity_door_no',
        'entity_pincode',
        'entity_gst',
        'entity_cin',
        'entity_pan',
        'entity_tax',
        'entity_desc',
        'entity_bank_name',
        'entity_bank_branch',
        'entity_acc_holder',
        'entity_acc_no',
        'entity_ifsc',
        'created_by',
        'updated_by',
        'status'
    ];
}
