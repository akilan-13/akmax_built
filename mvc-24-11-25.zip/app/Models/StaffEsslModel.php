<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffEsslModel extends Model
{
    use HasFactory;
    public $table      = "egc_staff_essl";
    public $primaryKey = 'sno';


    protected $fillable = [
        'employee_id',
        'date',
        'essl_status',
        'staff_id',
        'ot_duration',
        'in_time',
        'out_time',
        'company',
        'work_duration',
        'total_duration',
        'created_by',
        'updated_by',
        'status',
    ];
}
