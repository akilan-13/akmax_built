@php
$containerNav = $containerNav ?? 'container-fluid';
$navbarDetached = ($navbarDetached ?? '');
@endphp
<style>
.navbar-search-wrapper {
  position: relative;
  width: 250px; /* adjust width as needed */
}

.navbar-search-wrapper input.form-control {
  width: 100%;
  padding-left: 40px; /* space for the icon */
  border-radius: 12px;
  background: rgba(153, 152, 152, 0.2);
  border-right: 1px solid #eee;
  /* backdrop-filter: blur(8px);
  border: 1px solid rgba(0,0,0,0.2); */
  color: #000;
}

.navbar-search-wrapper i.mdi {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none; /* so click goes to input */
  color: black;
}
</style>

  @php
      $menuName ='Settings';
  @endphp
  @php
      
  @endphp

<!-- Navbar -->
@if(isset($navbarDetached) && $navbarDetached == 'navbar-detached')
<nav class="layout-navbar {{$containerNav}} navbar navbar-expand-xl {{$navbarDetached}} align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
  @endif
  @if(isset($navbarDetached) && $navbarDetached == '')
<nav class="layout-navbar navbar navbar-expand-xl align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
  <div class="{{$containerNav}}">
    @endif

    <!--  Brand demo (display only for navbar-full and hide on below xl) -->
    @if(isset($navbarFull))
      <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
        <a href="{{url('/')}}" class="app-brand-link gap-2">
        <img src="{{asset('assets/common/logo_full.png')}}" class="app-brand-logo demo" alt="EGC Logo">
        <span class="app-brand-text demo menu-text fw-bold">EGC</span>
      </a>
      @if(isset($menuHorizontal))
        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
          <i class="mdi mdi-close align-middle"></i>
        </a>
      @endif
    </div>
    @endif
   
    
          <!-- ! Not required for layout-without-menu -->
          @if(!isset($navbarHideToggle))
          <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0{{ isset($menuHorizontal) ? ' d-xl-none ' : '' }} {{ isset($contentNavbar) ?' d-xl-none ' : '' }}">
            <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
              <i class="mdi mdi-menu mdi-24px"></i>
            </a>
          </div>
          @endif

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

      <ul class="navbar-nav flex-row align-items-center ms-auto mx-4 px-2">
          <!-- Search -->
           <li class="nav-item me-2 me-xl-1">
              <form id="switch-erp-form" action="{{ route('switch.erp.portal') }}" method="POST" style="display:none;">
                  @csrf
                  <input type="hidden" name="switch_entity_id" id="switch_entity_id">
              </form>
              @if(Auth::user()->staff->company_type == 2)
              <button type="button" id="switch-erp-btn-self" class="btn btn-sm btn-primary" onclick="switchErp('{{Auth::user()->staff->entity_id}}')">
                <span class="me-2"><i class="mdi mdi-home-switch-outline"></i></span>
                  Switch ERP
              </button>
              @else
              <div class="position-relative">
                 @if(Auth::user()->staff->role_id == 1)
                <button type="button" id="switch-erp-btn" class="btn btn-sm btn-primary " data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                  <span class="me-2"><i class="mdi mdi-home-switch-outline"></i></span>
                    Switch ERP 
                </button>
                @endif
                <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                    <button type="button" class="dropdown-item" onclick="switchErp('1')">ETPL</button>
                    <button type="button" class="dropdown-item" onclick="switchErp('2')">EAPL</button>
                    <button type="button" class="dropdown-item" onclick="switchErp('3')">EIBS</button>
                </div>
              </div>
              @endif

            </li>
          <!-- /Search -->
                <!-- Notification -->
        @if(auth()->user()->hasPermission($menuName)) 
        <li class="nav-item me-2 me-xl-1">
          <a href="{{ url('/settings/general_settings') }}" aria-expanded="false" >
            <i class="mdi mdi-cog-outline fs-3 text-black"></i>
          </a>
        </li>
        @endif
        <!--/ Notification -->

        <!-- Notification -->
        <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
          <a href="javascript:void(0);" aria-expanded="false" data-bs-toggle="offcanvas" data-bs-target="#notification_tab">
            <!-- <img id="envelope" src="{{ url('assets/egc_images/notification/envelope.png') }}" alt="bell" class="bell" width="25" height="25" /> -->
            <img id="envelope" src="{{ url('assets/egc_images/notification/unread_msg_1.gif') }}" alt="bell" class="bell" width="40" height="40" />            
          </a>  
        </li>
        <!--/ Notification -->
        <!-- Notification -->
        <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
          <a href="javascript:void(0);" aria-expanded="false" data-bs-toggle="offcanvas" data-bs-target="#chat_tab">
            <span class="mdi mdi-chat-processing-outline fs-2 text-dark"></span>
            <!-- <img id="chatbot" src="{{ url('assets/egc_images/notification/unread_msg_1.gif') }}" alt="bell" class="bell" width="40" height="40" />             -->
          </a>  
        </li>
        <!--/ Notification -->

        <!-- User -->
        <li class="nav-item navbar-dropdown dropdown-user dropdown">
          <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
            <div class="avatar avatar-online" style="width: 40px; height: 40px;">
               @if(Auth::user()->staff->company_type==1)
                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                @else
                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                @endif
            </div>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li>
              <a class="dropdown-item" href="javascript:;">
                <div class="d-flex">
                  <div class="flex-shrink-0 me-3">
                    <div class="avatar avatar-online">
                        @if(Auth::user()->staff->company_type==1)
                        <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                        @else
                        <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                        @endif
                    </div>
                  </div>
                  <div class="flex-grow-1">
                    <span class="fw-medium d-block">
                      @if (Auth::check())
                      {{ Auth::user()->name }}
                      @else
                      Super Admin
                      @endif
                    </span>
                    <small class="text-muted">Admin</small>
                  </div>
                </div>
              </a>
            </li>
            <li>
              <div class="dropdown-divider"></div>
            </li>
            <li>
              <a class="dropdown-item" href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_profile">
                <!-- <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="Loading" style="width: 30px; height: auto;"> -->
                 <i class="mdi mdi-account-circle-outline text-black fs-3"></i>
                <span class="align-middle">My Profile</span>
              </a>
            </li>
           
            @if (Auth::check())
                  <li>
                      <a class="dropdown-item" href="{{ route('logout') }}"
                          onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                          <i class='mdi mdi-logout fs-3'></i>
                          <span class="align-middle">Logout</span>
                      </a>
                  </li>
                  <form method="POST" id="logout-form" action="{{ route('logout') }}">
                      @csrf
                  </form>
              @else
                  <li>
                      <a class="dropdown-item" href="{{ Route::has('login') ? route('login') : url('auth/login-basic') }}">
                          <i class='mdi mdi-login me-2'></i>
                          <span class="align-middle">Login</span>
                      </a>
                  </li>
              @endif
           
            
          </ul>
        </li>
        <!--/ User -->
      </ul>
    </div>
    @if(!isset($navbarDetached))
  </div>
  @endif
</nav>
<!-- / Navbar -->

<!--begin::Modal - Profile Update -->
<div class="modal fade" id="kt_modal_profile" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog">
    <!--begin::Modal content-->
    <div class="modal-content rounded-3 shadow-lg position-relative ">
    <form method="POST" action="{{ route('update_profile') }}" enctype="multipart/form-data">
              @csrf
      <div class="card__img">
        <img src="{{ url('assets/common/egc-image.jpg') }}" alt="background-image" class="bg-image" />
        <div class="profile-wrapper text-center position-absolute translate-middle" style="top: 120px; left:70px;">
          <div class="d-inline-block position-relative">
              @if(Auth::user()->staff->company_type==1)
            <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
            @else
            <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
            @endif
            <div id="imagePreview" class="preview-box">
              <img id="previewImage" src="" alt="Preview" />
            </div>
            <label for="profileImageUpload"
              class="position-absolute bottom-0 end-0 bg-white p-2 rounded-circle "
              style="cursor: pointer;">
              <i class="fas fa-camera text-primary"></i>
            </label>
          </div>
          <input type="file" name="staff_image" id="profileImageUpload" class="d-none upload_staff_image" />
        </div>
        <div class="d-flex align-items-start justify-content-center flex-column px-10 px-lg-20 mx-2">
          <label class="card__title" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Name">Super Admin</label>
          <label class="card__subtitle text-center mt-0 pt-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Role">Super Admin</label>
        </div>
      </div>
      <div class="modal-body pt-0 mt-5 pb-4 px-10 px-xl-20 bg-white">
        <div class="mb-4">
            <label class="fw-bold text-black">Username</label>
            <div class="form-control bg-light border-0">{{ Auth::user()->staff->user_name }}</div>
            <label class="fw-bold text-muted">Password</label>
            <div class="input-group">
                <input type="password" name="staff_password" class="form-control" id="passwordInput" placeholder="Enter New Password" value="{{ Auth::user()->staff->password }}">
                <span class="input-group-text toggle-password" style="cursor: pointer;">
                    <i class="fas fa-eye-slash"></i>
                </span>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="d-flex justify-content-between align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4" data-bs-dismiss="modal">Update Profile</button>
        </div>
          <!--end::Profile Form-->
      </div>
     </form>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Profile Update -->


<!--begin:: Notification Offcanvan-->
<div class="offcanvas offcanvas-end" id="notification_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <div class="offcanvas-header border-bottom d-block bg-label-white">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <div class="d-flex align-items-center gap-1">
        <h5 class="offcanvas-title text-dark fw-bold">Notifications</h5>
        <span id="notificationCount" class="badge rounded-pill bg-danger text-white">0 New</span>
      </div>
      <button type="button" class="btn-close text-reset rounded-pill custom-bg-orange modal_close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>
      <div class="d-flex align-items-center justify-content-between">
          <label class="clear-all hover-badge">
              <span class="fs-6 fw-semibold ">Clear All</span>
          </label>
          <label class="mark-all-read hover-badge">
              <span class="fs-6 fw-semibold ">Mark all as read</span>
          </label>
      </div>

  </div>
  <div class="offcanvas-body flex-grow-1">
    <ul class="list-group list-group-flush list-unstyled scrollable-container notification-list" >

    </ul>
  </div>
</div>
<div class="offcanvas offcanvas-end" id="chat_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <div class="offcanvas-header border-bottom d-block bg-label-white">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <div class="d-flex align-items-center gap-1">
        <h5 class="offcanvas-title fw-bold d-flex gap-2 align-items-center"><span class="mdi mdi-robot-happy text-primary fs-3 fw-semibold"></span> <span>Chat Bot</span> </h5>
      </div>
      <button type="button" class="btn-close text-reset rounded-pill custom-bg-orange modal_close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

    </div>
      <div class="d-flex align-items-center justify-content-end">
          <label class="clear-all-chat hover-badge-chat">
              <span class="fs-6 fw-semibold ">Clear All</span>
          </label>
      </div>

  </div>
  <div class="offcanvas-body flex-grow-1">
    <div id="historyLoader" class="text-center text-muted small">
      Loading previous messages...
    </div>

    <div id="chatmessages" class="scrollable-container"></div>
  </div>
  <div class="chat-input d-flex gap-2 py-3 px-2 border border-top-1">
        <textarea id="inputchat" rows="1" class="form-control" placeholder="Type your message..." oninput="adjustTextareaHeight(this)"></textarea>
        <span class="mdi mdi-send-circle cursor-pointer text-success fs-1 align-self-center" id="sendchat"></span>
        
    </div>
</div>
<!--End:: Notification Offcanvan-->

<style>
    .offcanvas-body {
        display: flex;
        flex-direction: column;
        padding: 0;
    }

    .hover-badge-chat {
          padding: 5px 10px;
          border-radius: 12px;
          transition: background-color 0.3s, color 0.3s;
      }

      /* Hover effect for the badge */
      .hover-badge-chat:hover {
          background-color: #f36f7c; /* or any preferred color */
          color: white;
          cursor: pointer;
      }

      .hover-badge-chat:hover span {
          color: white; /* Ensures text turns white on hover */
      }
    

  .message {
      max-width: 75%;
      margin-bottom: 16px;
      padding: 12px 16px;
      border-radius: 12px;
      line-height: 1.5;
     white-space: normal;
      word-break: break-word;
      white-space: pre-line;
  }
  #chatmessages {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    display: flex;
    flex-direction: column;
}
  .message.user {
      background: #fba919;
      color:black;
      align-self: flex-end;
  }

  .message.ai {
      background: #ab2b22;
      color:white;
      align-self: flex-start;
  }

  /* .chat-input {
      border-top: 1px solid #1e293b;
      padding: 16px;
      display: flex;
      gap: 10px;
  } */

  /* .chat-input textarea {
      flex: 1;
      resize: none;
      border-radius: 8px;
      padding: 10px;
      border: none;
      outline: none;
      font-size: 14px;
  } */

  /* .chat-input button {
      background: #22c55e;
      border: none;
      color: #022c22;
      padding: 0 20px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
  } */

  .chat-input #sendchat:disabled {
      background: #64748b;
      cursor: not-allowed;
  }

  .ai-chat-loader {
      font-size: 13px;
      opacity: 0.6;
      margin-bottom: 10px;
  }
</style>

<script>
  let auth_login_user_id="{{ auth()->user()->user_id }}";
  let isFirstLoad = true;
  let isLoadingAiChat = false;
  let hasMoreAiChat = true;
  let lastIdAiChat = null;
  const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
  const sendBtn = document.getElementById('sendchat');
  const input = document.getElementById('inputchat');
  const messages = document.getElementById('chatmessages');
  let historyLoader = document.getElementById('historyLoader');

  function adjustTextareaHeight(textarea) {
      textarea.style.height = 'auto';  // Reset height to auto to calculate the new height
      textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';  // Set new height but limit it to 200px
  }

  function trimMessages() {
      while (messages.children.length > 200) {
          messages.removeChild(messages.lastChild);
      }
  }

  function addMessage(text, type) {
      const div = document.createElement('div');
      div.className = `message ${type}`;
      text = escapeHTML(text);
      text = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
      text = text.replace(/\*(.*?)\*/g, '<b>$1</b>');
      div.innerHTML  = text;
      messages.appendChild(div);
      messages.scrollTo({
          top: messages.scrollHeight,
          behavior: 'smooth'
      });
      trimMessages();
  }

  sendBtn.onclick = async () => {
      const text = input.value.trim();
      if (!text) return;

      addMessage(text, 'user');
      input.value = '';
      sendBtn.disabled = true;

      const loader = document.createElement('div');
      loader.className = 'ai-chat-loader';
      loader.textContent = 'AI is thinking...';
      messages.appendChild(loader);

      try {
          const res = await fetch('{{ url('/ai/chat') }}', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': '{{ csrf_token() }}'
              },
              body: JSON.stringify({ message: text })
          });

          const data = await res.json();
          loader.remove();

          if (!res.ok) {
              addMessage(data.message || data.error || 'Error', 'ai');
          } else {
              addMessage(data.reply, 'ai');
          }

      } catch (e) {
          loader.remove();
          addMessage('Network error. Try again.', 'ai');
      }

      sendBtn.disabled = false;
  };

  input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendBtn.click();
      }
  });

async function loadChatHistory() {
    if (isLoadingAiChat || !hasMoreAiChat) return;

    isLoadingAiChat = true;
    historyLoader.style.display = 'block';

    const res = await fetch(`/aichat/history?last_id=${lastIdAiChat ?? ''}`);
    const json = await res.json();

    historyLoader.style.display = 'none';

    if (json.data.length === 0) {
        hasMoreAiChat = false;
        isLoadingAiChat = false;
        return;
    }

    // Always work oldest -> newest
    const chats = json.data.reverse();

    if (isFirstLoad) {
        // FIRST LOAD → append & scroll to bottom
        chats.forEach(chat => {
            if (chat.user_message) addMessage(chat.user_message, 'user');
            if (chat.ai_reply) addMessage(chat.ai_reply, 'ai');
            lastIdAiChat = chat.sno;
        });

        messages.scrollTo({
            top: messages.scrollHeight,
            behavior: 'smooth'
        });
        isFirstLoad = false;
    } else {
        // SCROLL UP → prepend & preserve scroll
        const previousScrollHeight = messages.scrollHeight;

        chats.forEach(chat => {
            if (chat.user_message) prependMessage(chat.user_message, 'user');
            if (chat.ai_reply) prependMessage(chat.ai_reply, 'ai');
            lastIdAiChat = chat.sno;
        });

        messages.scrollTop = messages.scrollHeight - previousScrollHeight;
    }

    hasMoreAiChat = json.has_more;
    isLoadingAiChat = false;
}



// async function loadChatHistory() {
//     if (isLoadingAiChat || !hasMoreAiChat) return;

//     isLoadingAiChat = true;
//    historyLoader.style.display = 'block';

//     const res = await fetch(`/aichat/history?last_id=${lastIdAiChat ?? ''}`);
//     const json = await res.json();

//     historyLoader.style.display = 'none';
//     if (json.data.length === 0) {
//         hasMoreAiChat = false;
//         return;
//     }

//     const previousScrollHeight = messages.scrollHeight;

//     json.data.reverse().forEach(chat => {
//       if (chat.user_message) prependMessage(chat.user_message, 'user');
//       if (chat.ai_reply) prependMessage(chat.ai_reply, 'ai');
//        lastIdAiChat = chat.sno;
//   });

    
//     messages.scrollTop = messages.scrollHeight - previousScrollHeight;

//     hasMoreAiChat = json.has_more;
//     isLoadingAiChat = false;
// }

function prependMessage(text, type) {
    const div = document.createElement('div');
    div.className = `message ${type}`;
    text = escapeHTML(text);
    
    text = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    text = text.replace(/\*(.*?)\*/g, '<b>$1</b>');
    div.innerHTML  = text;
   
    messages.prepend(div);
    trimMessages();
}

function escapeHTML(str) {
    return str.replace(/[&<>"']/g, m => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[m]));
}


document.getElementById('chat_tab').addEventListener('shown.bs.offcanvas', () => {
    if (!lastIdAiChat) {
        loadChatHistory();
    }
});
document.getElementById('chat_tab').addEventListener('hidden.bs.offcanvas', () => {
    messages.innerHTML = '';
    lastIdAiChat = null;
    hasMoreAiChat = true;
    isLoadingAiChat = false;
    isFirstLoad = true;
});
let scrollTimeout;
messages.addEventListener('scroll', () => {
    if (scrollTimeout) return;
    scrollTimeout = setTimeout(() => {
        scrollTimeout = null;
        if (messages.scrollTop === 0) loadChatHistory();
    }, 200);
});
 
      document.querySelector('.clear-all-chat').addEventListener('click', () => {
          fetch(`/aichat-clear-all/${auth_login_user_id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': csrfToken
              }
          })
          .then(response => response.json())
          .then(data => {
            toastr.success("All Chat Cleared");
            messages.innerHTML = '';
            lastIdAiChat = null;
            hasMoreAiChat = true;
            isLoadingAiChat = false;
            isFirstLoad = true;
              loadChatHistory();
          })
          .catch(error =>{
            console.error('Error clearing notifications:', error);
            toastr.error('Error clearing notifications:', error);

          } );
      });
</script>

<style>


  .preview-box {
      position: absolute;
      top: 50px; /* Moved higher */
      left: 100%;
      transform: translateX(-50%) scale(0.5);
      opacity: 0;
      transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
      background: #fed240;
      border-radius: 12px;
      padding: 8px;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.25);
      z-index: 10;
  }

    .preview-box img {
        width: 100px;  /* Increased size */
        height: 100px; /* Increased size */
        border-radius: 10px;
    }
    .profile-image {
        border: 8px solid white;      /* sets border thickness and color */
        border-radius: 100% !important; /* keeps it circular */
        background-color: white;
        /* box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);  */
      }
    .profile-image:hover + .preview-box,
    .profile-image:focus + .preview-box {
        transform: translateX(-50%) scale(1);
        opacity: 1;
    }
    /*.card__img {*/
    /*  height: 192px;*/
    /*  width: 100%;*/
    /*  position: relative;*/
    /*  overflow: visible;*/
    /*}*/
   /* Remove border-radius from .card__img */
    .card__img {
      height: 192px;
      width: 100%;
      position: relative;
      overflow: visible; /* allow the image to extend beyond */
      /* border-radius removed here */
    }

    /* Glassmorphic background image for modal */
    .bg-image {
      width: 100%;
      height: 100px;             /* Fixed height */
      object-fit: cover;         /* Cover the container without stretching */
      display: block;
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;
      
      /* Glassmorphism effect */
      backdrop-filter: blur(8px);       /* Blur the background behind */
      background-color: rgba(255, 255, 255, 0.25); /* Semi-transparent overlay */
      border: 1px solid rgba(255, 255, 255, 0.18); /* Optional subtle border */
    }

    /* Apply full radius to modal content */
    .modal-content {
      border-radius: 12px !important;
      overflow: hidden; /* Ensures all modal contents respect the border radius */
    }


    .card__title {
      margin-top: 50px;
      margin-bottom: 0px;
      font-weight: 600;
      font-size: 25px;
      color: black;
      padding: 0px 10px;
    }

    .card__subtitle {
      font-weight: 400;
      font-size: 18px;
      color: black;
      padding: 10px;
    }

    .profile-wrapper {
      z-index: 5;
      margin-top: -20px; /* pushes it up over SVG */

    }

    .card__icons {
    display: flex;
    justify-content: center;
    gap: 10px; /* Adds space between icons */
    margin-top: 10px;
  }

 .card__icons a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px; /* Fixed width for consistent sizing */
    height: 40px; /* Fixed height */
    border-radius: 50%; /* Circular icons */
    background-color: #1877F2; /* Facebook blue, you can customize */
    transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth transitions for color and scale */
  }

  .card__icons a:hover {
    background-color: #0e5bcf; /* Slightly darker shade on hover */
    transform: scale(1.1); /* Slightly larger on hover */
  }

  .card__icons i {
    font-size: 24px; /* Icon size */
  }

  .card__icons a[data-bs-toggle="tooltip"]:hover {
    text-decoration: none; /* Ensures no underlining on hover */
  }
</style>
<!-- Script -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
      let profileImage = document.getElementById('uploadedstaffimage');
      let previewBox = document.getElementById('imagePreview');
      let previewImage = document.getElementById('previewImage');

      profileImage.addEventListener("mouseenter", function () {
          previewImage.src = profileImage.src;
          previewBox.style.opacity = "1";
          previewBox.style.transform = "translateX(-50%) scale(1)";
      });

      profileImage.addEventListener("mouseleave", function () {
          previewBox.style.opacity = "0";
          previewBox.style.transform = "translateX(-50%) scale(0.5)";
      });
  });
    document.addEventListener('DOMContentLoaded', () => {
      let staff_add = document.getElementById('uploadedstaffimage');
      const staff_add_fileInput = document.querySelector('.upload_staff_image');
      if (staff_add) {
          const staff_add_resetImage = staff_add.src;
          staff_add_fileInput.onchange = () => {
              if (staff_add_fileInput.files[0]) {
                  staff_add.src = window.URL.createObjectURL(staff_add_fileInput.files[0]);
              }
          };
      }
  });
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script>
  document.addEventListener("DOMContentLoaded", function () {
      const passwordInput = document.getElementById("passwordInput");
      const togglePassword = document.querySelector(".toggle-password i");

      document.querySelector(".toggle-password").addEventListener("click", function () {
          if (passwordInput.type === "password") {
              passwordInput.type = "text";
              togglePassword.classList.remove("mdi-eye-off");
              togglePassword.classList.add("mdi-eye");
          } else {
              passwordInput.type = "password";
              togglePassword.classList.remove("mdi-eye");
              togglePassword.classList.add("mdi-eye-off");
          }
      });
  });
  </script>



<style>
#loader-text {
  position: relative;
  color: black;
  padding: 5px 0px;
  font-family: monospace;
  font-size: 1rem;
  text-align: center;
  z-index: 10000;
}

</style>


<!-- Tunnel Overlay -->
<div id="switch-animation" class="switch-animation" style="display:none; ">
    <div class="loading" id="loadingScreen"  style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999; ">
      <div class="loading-content" style="text-align: center; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);">
          <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; height:100%">
          <div id="loader-text"></div>
          <div class="d-block">
            <div class="dot red"></div>
            <div class="dot orange"></div>
            <div class="dot yellow"></div>
            <div class="dot green"></div>
            <div class="dot teal"></div>
            <div class="dot blue"></div>
            <div class="dot violet"></div>
          </div>
      </div>
    </div>
</div>



<script>
// ---------- Button Trigger ----------
function switchErp(entity_id){
    $('#switch_entity_id').val(entity_id);
      
      animation_2()
    setTimeout(()=>{ document.getElementById("switch-erp-form").submit(); },4000);
    setTimeout(()=>{ document.getElementById("switch-animation").style.display='none'; },120000);
}



 document.getElementById("switch-animation").style.display='none';

</script>




<script>
  function animation_2(){
   
    // Texte glitch dynamique
    const loaderText = document.getElementById('loader-text');
    // const messages = [
    //   "Initializing system . . .",
    //   "Loading core modules . . .",
    //   "Verifying user permissions . . . ",
    //   "Compiling source code . . .",
    //   "Running diagnostics . . .",
    //   "Establishing secure connection . . ."
    // ];
    const messages = [
      "Failure to maintain punctuality is considered disrespectful behavior.",
        "The value of the company is my value.",
        "The customer is our asset; I will satisfy their needs.",
        "I will not spend my time for the negative thoughts.",
        "I will respect other employees and work with them collaboratively.",
        "I won't Come up with my own likes and dislikes into the company.",
        "I won't interfere unnecessarily in the work of my colleagues.",
        "I will utilize my time for new innovations and knowledge development.",
        "I will obey to the laws and regulations of the company.",
        "I will devote my services to the development of the company.",
    ];

     let index = 0;
    
    // Immediately display the first message
    loaderText.textContent = messages[index];
    index++;

    // Set interval to display the rest of the messages every 1 second
    const interval = setInterval(() => {
        if (index < messages.length) {
            loaderText.textContent = messages[index];
            index++;
        } else {
            clearInterval(interval); // Stop the interval once all messages are displayed
        }
    }, 1500); // 1 second interval for subsequent messages

   
        document.getElementById("switch-animation").style.display = 'block';
}
</script>

<!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>
