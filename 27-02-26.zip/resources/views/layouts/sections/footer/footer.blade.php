@php
$containerFooter = ($configData['contentLayout'] === 'compact') ? 'container-xxl' : 'container-fluid';
@endphp

<!-- Footer-->
<footer class="content-footer footer bg-footer-theme">
  <div class="{{ $containerFooter }}">
    <div class="footer-container d-flex align-items-center justify-content-between py-3 flex-md-row flex-column">
      <div class="mb-2 mb-md-0">
        © <script>document.write(new Date().getFullYear())</script>,
        Elysium Groups of Company
      </div>
    </div>
  </div>
</footer>
@php
    $helper = new \App\Helpers\Helpers();
    $branch_id = auth()->user()->branch_id ?? 1;
    $role_id   = auth()->user()->role_id ?? 1;
    $settings  = $helper->showTicker($branch_id, $role_id);
   
@endphp
@if($settings)
    <div id="section_contain">
        <div id="ent_wrapper_preview_cust"></div>
    </div>

    <script>
        $(document).ready(function () {
            var settings = @json($settings);

            $("#ent_wrapper_preview_cust").empty();
            $("#ent_wrapper_preview_cust").easyNewsTicker(settings);
        });
    </script>
@endif
<style>
      
    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap');

    :root {
      --black-color: #151515;
      --dark-gray-color: #232323;
      --gray-color: #3f3f3f;
      --light-color: #8a8a8a;
      --white-color: #E1E8EB;
      --violet-color: #7952B3;
      --yellow-color: #FFC107;
    }

    /* #section_contain{
      position: fixed;
      width:100%;
      bottom:0;
      z-index:1000;
    } */
    .mfw_wrapper {
      margin-top: 20px;
    }

    .mfw_wrapper,
    .mfw_wrapper * {
      font-family: 'Roboto', sans-serif;
      box-sizing: border-box;
    }




    #section_contain h2 {
      position: relative;
      margin: 10px 0;
      font-family: 'Roboto', sans-serif;
      font-size: 28px;
      line-height: 28px;
      font-weight: 900;
      color: #232323;
    }

    #section_contain h4 {
      position: relative;
      margin: 10px 0;
      font-family: 'Roboto', sans-serif;
      font-size: 18px;
      line-height: 18px;
      font-weight: 900;
      color: #232323;
    }

    /* GRID */

    .mfw_row {
      display: grid; 
      grid-template-columns: 1fr 1fr;
      grid-column-gap: 10px;
    }

    .mfw_row.mfw_input_field {
      grid-template-columns: 1fr 1fr;
    }

    .mfw_col {
      padding: 10px 0;
    }

    .mfw_input_field {
      border-bottom: 1px solid var(--black-color);
    }

    .mfw_col:nth-child(2) {
      align-self: center;
      text-align: right;
    }

    .mfw_heading {
      position: relative;
      margin-bottom: 2px;
      font-size: 16px;
      font-weight: 700;
      line-height: 18px;
      color: Black;
      cursor: pointer;
    }

    .mfw_heading:hover {
      text-decoration: underline;
      text-decoration-color: var(--yellow-color);
    }

    .mfw_tooltip {
      position: relative;
      display: inline-block;
      width: 16px;
      height: 16px;
      margin-left: 10px;
      margin-top: 1px;
      padding: 0;
      font-size: 10px;
      font-weight: 700;
      line-height: 18px;
      font-style: normal;
      background: var(--black-color);
      color: var(--light-color);
      border-radius: 8px;
      text-align: center;
      cursor: help;
      vertical-align: top;
      z-index: 100;
    }

    .mfw_tooltip:hover {
      background-color: var(--yellow-color);
      color: var(--black-color);
    }

    .mfw_tooltip span {
      position: absolute;
      display: none;
      width: auto;
      height: auto;
      top: 50%;
      left: 24px;
      padding: 10px;
      font-size: 12px;
      font-weight: 400;
      line-height: 16px;
      background: var(--yellow-color);
      color: var(--black-color);
      text-align: left;
      min-width: 200px;
      transform: translateY(-50%);
      border-radius: 5px;
      z-index: 100;
    }


    .mfw_tooltip span:before {
      position: absolute;
      content: "";
      top: 50%;
      left: -6px;
      width: 0;
      height: 0;
      border: 0 solid transparent;
      border-top-width: 4px;
      border-bottom-width: 4px;
      border-right: 6px solid var(--yellow-color);
      transform: translateY(-50%);
    }

    .mfw_tooltip:hover span {
      display: block;
    }

    .mfw_subheading {
      position: relative;
      font-size: 12px;
      font-weight: 400;
      line-height: 16px;
      color: var(--light-color);
    }

    .mfw_input_field select,
    .mfw_input_field select[multiple]{
      background: white;
    }

    .mfw_input_field input[type="text"],
    .mfw_input_field input[type="number"] {
        background: #f0f0f0;
    }

    .mfw_input_field select,
    .mfw_input_field select[multiple],
    .mfw_input_field input[type="text"],
    .mfw_input_field input[type="number"] {
      position: relative;
      width: auto;
      height: 30px;
      min-height: 30px;
      padding: 5px 10px;
      margin: 0;
      font-size: 16px;
      font-weight: 400;
      line-height: 18px;
      color: black;
      border: none;
      outline: none;
      border-radius: 5px;
      text-align: center;
    }

    .mfw_input_field select {
      padding: 4px 5px;
      text-align: left;
      border: 1px solid var(--black-color);
      appearance: auto;
      -webkit-appearance: auto;
    }

    .mfw_input_field select[multiple] {
      min-width: 100%;
      border: 1px solid var(--black-color);
      -webkit-appearance: none;
      padding: 0;
      text-align: left;
      height: 150px;
      cursor: auto;
      opacity: 0;
    }

    .mfw_select_multiple_wrapper {
      border: 1px solid var(--black-color);
      height: 150px;
      border-radius: 5px;
      overflow: hidden;
      overflow-y: scroll;
    }


    .mfw_input_field .mfw_select_multiple_wrapper:active,
    .mfw_input_field .mfw_select_multiple_wrapper:focus {
      border: 1px solid var(--yellow-color);
    }

    .mfw_select_multiple {
      text-align: left;
      margin: 0;
      padding: 0;
      list-style-type: none;
    }

    .mfw_select_multiple li {
      height: 30px;
      background: var(--black-color);
      text-align: left;
      margin: 0;
      padding: 5px 10px;
      list-style-type: none;
      font-size: 16px;
      font-weight: 400;
      line-height: 18px;
      color: var(--light-color);
      border-bottom: 1px solid var(--dark-gray-color);
      cursor: pointer;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .mfw_select_multiple li:hover {
      /* color: var(--white-color); */
    }

    .mfw_select_multiple li.selected {
      color: var(--black-color);
      background: var(--yellow-color);
    }


    .mfw_input_field select:after {
      position: absolute;
      content: '';
      top: 50%;
      left: 50%;
      padding: 4px;
      margin: 0;
      border-color: inherit;
      border-style: solid;
      border-width: 0 3px 3px 0;
    }

    .mfw_input_field input[type="text"].mddl,
    .mfw_input_field input[type="number"].mddl {
      width: 200px;
    }

    .mfw_input_field select:hover,
    .mfw_input_field input[type="text"]:hover,
    .mfw_input_field input[type="number"]:hover {
      /* color: var(--white-color); */
    }

    .mfw_input_field select:focus {
      border: 1px solid #fba919;
      /* color: var(--white-color); */
      box-shadow: none !important;
    }
    .mfw_input_field input[type="text"]:focus,
    .mfw_input_field input[type="number"]:focus {
      color: black;
      box-shadow: none !important;
    }


    .mfw_checkbox_handle {
      position: relative;
      display: inline-block;
      width: 50px;
      height: 20px;
      border-radius: 10px;
      background: #969696;
      cursor: pointer;
    }

    .mfw_checkbox_handle input {
      display: none;
    }

    .mfw_checkbox {
      position: absolute;
      display: block;
      width: 14px;
      height: 14px;
      top: 3px;
      left: 3px;
      border-radius: 10px;
      background: var(--gray-color);
      cursor: pointer;
      z-index: 2;
      transition: all 250ms cubic-bezier(0.33, 1, 0.68, 1);
    }

    .mfw_checkbox_handle input:checked + .mfw_checkbox {
      left: 33px;
      background: #fba919;
    }


    .mfw_image_browse {
      position: relative;
      display: inline-block;
      width: 80px;
      height: 36px;
      vertical-align: middle;
    }


    .mfw_image_browse img{
      position: relative;
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 1;
      transition: all 250ms cubic-bezier(0.33, 1, 0.68, 1);
      border-radius: 5px;
      z-index: 1;
      transform: scale(1);
    }

    .mfw_image_browse:hover img{
      opacity: 0.5;
    }

    .mfw_remove_image {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      cursor: pointer;
      z-index: 10;
    }

    .mfw_remove_image:before,
    .mfw_remove_image:after {
      position: absolute;
      content: "";
      width: 4px;
      height: 20px;
      top: 50%;
      left: 50%;
      background: var(--white-color);
      border-radius: 2px;
      transition: all 250ms cubic-bezier(0.33, 1, 0.68, 1);
      transform: translate(-50%, -50%) rotate(180deg);
      opacity: 0;
    }

    .mfw_image_browse:hover .mfw_remove_image:before {
      transform: translate(-50%, -50%) rotate(45deg);
      opacity: 1;
    }

    .mfw_image_browse:hover .mfw_remove_image:after {
      transform: translate(-50%, -50%) rotate(-45deg);
      opacity: 1;
    }

    .mfw_image_browse.noimage img {
      opacity: 0;
      transform: scale(2);
      pointer-events: none;
    }

    .mfw_image_browse.noimage .mfw_remove_image,
    .mfw_image_browse.noimage .mfw_remove_image {
      pointer-events: none;
    }

    .mfw_image_browse.noimage .mfw_remove_image:before,
    .mfw_image_browse.noimage .mfw_remove_image:after {
      opacity: 0;
      transform: translate(-50%, -50%) rotate(180deg);
    }

    .mfw_image_browse .mfw_browse_button {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      transform: scale(0);
      transition: all 250ms cubic-bezier(0.33, 1, 0.68, 1);
    }

    .mfw_image_browse.noimage .mfw_browse_button {
      transform: scale(1);
    }

    /* TABS */
    .mfw_tabs_wrapper {
      position: relative;
      width: auto;
      height: auto;
      overflow: hidden;
      border-radius: 5px;
    }

    .mfw_header {
      position: relative;
      width: 100%;
      background: #ab2b22;
    }

    .mfw_tabs-nav {
      position: relative;
      display: flex;
      margin: 0;
      padding: 0;
      list-style-type: none;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: flex-start;
      align-items: center;
      z-index: 2;
    }

    .mfw_tabs-nav-item {
      position: relative;
      max-width: 100%;
      margin: 0;
      padding: 10px;
      font-size: 18px;
      line-height: 20px;
      font-weight: 700;
      text-align: center;
      color: var(--white-color);
      cursor: pointer;
      flex: 1 1 100%;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .mfw_tabs-nav-item:hover {
      background:  #ffffff;
      color: #ab2b22;
      border:1px solid #ab2b22;
    }

    .mfw_tabs-nav-item.active {
      color: var(--white-color);
    }

    .mfw_tabs-nav-item.active:hover {
      background: transparent;
      color: white;
    }

    .mfw_tabs-nav_hightlight {
      position: absolute;
      width: auto;
      height: 100%;
      top: 0;
      left: 0;
      background: #fba919;
      z-index: 1;
    }

    .mfw_content {
      position: relative;
      width: 100%;
      height: auto;
      overflow: hidden;
      background: white;
    }

    .mfw_tabs_container {
      position: relative;
      width: 100%;
      height: auto;
      margin: 0;
      padding: 0;
      list-style-type: none;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: stretch;
      align-items: flex-start;
    }

    .mfw_tab {
      position: relative;
      width: 100%;
      height: auto;
      margin: 0;
      padding: 0 10px;
      flex: 0 0 100%;
    }

    .mfw_tab h2 {
      font-size: 1.3em;
      font-weight: 700;
      margin: 0;
      padding: 10px 0;
      color: var(--violet-color);
      border-bottom: 1px solid var(--black-color);
    }

    .mfw_accordion_toggle {
      cursor: pointer;
    }

    .mfw_accordion_toggle:hover {
      color: var(--yellow-color);
    }

    .mfw_accordion_toggle.open {
      color: var(--yellow-color);
    }

    .mfw_accordion_toggle + .mfw_row {
      display: none;
    }
    .mfw_accordion_toggle.open + .mfw_row {
      display: grid;
    }

    .mfw_footer {
      position: relative;
      width: 100%;
      height: auto;
      padding: 10px;
      background: #ab2b22;
      text-align: right;
    }

    .mfw_button {
      position: relative;
      width: auto;
      height: auto;
      margin: 0;
      padding: 10px;
      font-size: 16px;
      font-weight: 700;
      line-height: 18px;
      background: #fba919;
      color: white;
      border-radius: 5px;
      border: none !important;
      outline: none !important;
      cursor: pointer;
      transition: all 150ms cubic-bezier(0.33, 1, 0.68, 1);
    }

    .mfw_button:hover {
      transform: scale(1.1) !important;
    }

    .mfw_button:active {
      transform: scale(.9) !important;
    }

    .mfw_browse_button {
      height: 30px;
      padding: 5px 10px;
      background: var(--violet-color);
      color: var(--white-color);
      vertical-align: middle;
    }

    .mfw_container {
      position: relative;
      background: var(--white-color);
      border-radius: 5px;
      margin-top: 10px;
      padding: 0;
    }

    .mfw_container .mfw_header {
      padding: 0 10px;
      background: var(--dark-gray-color);
      border-radius: 5px 5px 0 0;
    }

    .mfw_container .mfw_content {
      position: relative;
      display: inline-block;
      background: var(--white-color);
      overflow: visible;
      border-radius: 0 0 5px 5px;
    }

    #ent_preview {
      position: relative;
    }

    #ent_preview .mfw_button{
      background: var(--violet-color);
      color: var(--white-color);
    }

    .mfw_container h2 {
      color: var(--white-color);
      margin: 10px 0;
    }


    #ent_preview #ent_wrapper_preview_cust {
      z-index: 1;
    }
    .ent_wrapper {
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: stretch;
      align-items: center;
      overflow: hidden;
      z-index: 99999999999999;
    }

    /* SHADOW */
    .ent_wrapper.shadow_type_01 {
      box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    }
    .ent_wrapper.shadow_type_02 {
      box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
    }
    .ent_wrapper.shadow_type_03 {
      box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
    }
    .ent_wrapper.shadow_type_04 {
      box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
    }
    .ent_wrapper.shadow_type_05 {
      box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);
    }
    /* REVERSE */
    .ent_wrapper.shadow_type_01.reverse {
      box-shadow: 0 -1px 3px rgba(0,0,0,0.12), 0 -1px 2px rgba(0,0,0,0.24);
    }
    .ent_wrapper.shadow_type_02.reverse {
      box-shadow: 0 -3px 6px rgba(0,0,0,0.16), 0 -3px 6px rgba(0,0,0,0.23);
    }
    .ent_wrapper.shadow_type_03.reverse {
      box-shadow: 0 -10px 20px rgba(0,0,0,0.19), 0 -6px 6px rgba(0,0,0,0.23);
    }
    .ent_wrapper.shadow_type_04.reverse {
      box-shadow: 0 -14px 28px rgba(0,0,0,0.25), 0 -10px 10px rgba(0,0,0,0.22);
    }
    .ent_wrapper.shadow_type_05.reverse {
      box-shadow: 0 -19px 38px rgba(0,0,0,0.30), 0 -15px 12px rgba(0,0,0,0.22);
    }

    .ent_wrapper * {
      box-sizing: border-box;
    }

    .ent_wrapper .ent_label {
      position: relative;
      width: auto;
      height: 100%;
      order: 0;
      flex: 0 1 auto;
      align-self: auto;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: stretch;
      align-items: center;
    }

    .ent_wrapper .ent_label span {
      position: relative;
      display: block;
    }

    .ent_wrapper .ent_label .ent_logo {
      position: relative;
      display: block;
      height: 100%;
    }

    .ent_wrapper .ent_news_wrapper {
      position: relative;
      width: auto;
      order: 0;
      flex: 1 1 auto;
      align-self: auto;
      overflow: hidden;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container {
      position: relative;
      width: auto;
      height: auto;
      margin: 0;
      padding: 0;
      list-style-type: none;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news {
      position: relative;
      width: 100%;
      margin: 0;
      padding: 0;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url {
      position: relative;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: stretch;
      align-items: center;
      text-decoration: none;
      white-space: nowrap;
      outline: none !important;
      box-shadow: none !important;
      background: none !important;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url .ent_date,
    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url .ent_prefix {
      margin-right: 10px;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url .ent_date,
    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url .ent_heading {
      min-width: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .ent_wrapper .ent_news_wrapper .ent_news_container .ent_news .ent_news_url:hover .ent_heading {
      text-decoration: underline;
    }

    .ent_wrapper .ent_navigation {
      position: relative;
      height: 100%;
      order: 0;
      flex: 0 1 auto;
      align-self: auto;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      justify-content: flex-start;
      align-content: stretch;
      align-items: center;
    }

    .ent_wrapper .ent_navigation .ent_prev_news,
    .ent_wrapper .ent_navigation .ent_next_news {
      position: relative;
      width: 20px;
      height: 25px;
      cursor: pointer;
    }

    .ent_wrapper .ent_navigation .ent_prev_news:after,
    .ent_wrapper .ent_navigation .ent_next_news:after {
      position: absolute;
      content: '';
      top: 50%;
      left: 50%;
      padding: 4px;
      margin: 0;
      border-color: inherit;
      border-style: solid;
      border-width: 0 3px 3px 0;
      pointer-events: none;
      transition: all 100ms cubic-bezier(0.25, 1, 0.5, 1);
    }

    .ent_wrapper .ent_navigation .ent_prev_news:hover:after,
    .ent_wrapper .ent_navigation .ent_next_news:hover:after {
      padding: 6px;
    }
    .ent_wrapper .ent_navigation .ent_prev_news:active:after,
    .ent_wrapper .ent_navigation .ent_next_news:active:after {
      padding: 2px;
    }

    .ent_wrapper .ent_navigation .ent_prev_news:after {
      transform: translate(-50%, -50%) rotate(135deg);
    }

    .ent_wrapper .ent_navigation .ent_next_news:after {
      transform: translate(-50%, -50%) rotate(-45deg);
    }


    /* EFFECTS */

    /* SCROLL */
    .ent_wrapper.scroll-effect .ent_news_container {
      display: inline-flex;
    }

    .ent_wrapper.scroll-effect .ent_news_container .ent_news {
      flex: 0 1 auto;
    }

    .ent_wrapper.scroll-effect .ent_news_container .ent_news_url {
      padding: 0 0 0 40px !important;
    }

    .ent_wrapper.scroll-effect .ent_news_container .ent_news:before {
      position: absolute;
      content: '';
      top: 50%;
      left: 15px;
      transform: translateY(-50%);
    }

    /* SLIDE HORIZONTAL */
    .ent_wrapper.slide-horizontal-effect .ent_news_container {
      display: flex;
    }

    .ent_wrapper.slide-horizontal-effect .ent_news_container .ent_news {
      flex: 1 0 100%;
    }

    /* FADE */
    .ent_wrapper.fade-effect .ent_news {
      display: none;
    }
    .ent_wrapper.fade-effect .ent_news.active {
      display: block;
    }

    /* navigation */
    .ent_wrapper.autohide-navigation .ent_navigation {
      position: absolute;
      top: 0;
      right: 0;
      opacity: 0;
      transition: all 500ms ease-in-out;
      z-index: 100;
    }

    .ent_wrapper.autohide-navigation:hover .ent_navigation {
      opacity: 1;
    }

    .ent_wrapper.autohide-navigation .ent_news_wrapper,
    .ent_wrapper.autohide-label .ent_news_wrapper{
      z-index: 1;
    }
</style>
<!--/ Footer-->
