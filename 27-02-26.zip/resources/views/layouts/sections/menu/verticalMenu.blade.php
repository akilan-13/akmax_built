@php

  
  $currentRouteName = Route::currentRouteName();
  $menuJson = \App\Helpers\Helpers::getMenuJson();
  $menuCollection = collect($menuJson);

  $menusOff = $menuCollection->whereIn('slug', [
      'dashboard','my-self','hrm-hr-management', 'accounts-finance', 'corporate-admin', 'it-support', 'control-panel'
  ])->values();

  $menusOn = $menuCollection->whereIn('slug', [
      'dashboard', 'etpl', 'eapl', 'eibs', 'ees'
  ])->values();

  // Example: get portal state from session (you can also use cookie)
    if (!session()->has('portalState')) {
        if(auth()->user()->hasPermission('Switch Portal','Management')){
            session(['portalState' => 'off']);
        } else {
            session(['portalState' => 'on']);
        }
    }

    $portalState = session('portalState');
  
@endphp

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" style="background-color:#AB2B22!important;">
    <!-- ! Hide app brand if navbar-full -->
  @if(!isset($navbarFull))
  <div class="app-brand demo">
    <a href="{{url('/dashboard')}}" class="app-brand-link bg-white rounded px-1 py-0">
      <?php if(isset($logoUrl)): ?>
          <img id="logo-left" src="<?= $logoUrl ?>" class="app-brand-logo demo" width="180px" height="50px" alt="EGC Logo">
          <img id="logo-right" src="<?= $favUrl ?>" class="app-brand-logo demo" width="45" alt="EGC Logo" style="display: none;">
      <?php else: ?>
          <img id="logo-left" src="{{asset('assets/common/logo_full.png')}}" class="app-brand-logo demo" width="180px" height="50px" alt="EGC Logo">
          <img id="logo-right" src="{{asset('assets/common/logo_small.png')}}" class="app-brand-logo demo" width="45" alt="EGC Logo" style="display: none;">
      <?php endif; ?>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto" style="  border: 2px solid rgba(255, 255, 255, 0.8);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.2);
      transition: all 0.3s ease;">
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.4854 4.88844C11.0081 4.41121 10.2344 4.41121 9.75715 4.88844L4.51028 10.1353C4.03297 10.6126 4.03297 11.3865 4.51028 11.8638L9.75715 17.1107C10.2344 17.5879 11.0081 17.5879 11.4854 17.1107C11.9626 16.6334 11.9626 15.8597 11.4854 15.3824L7.96672 11.8638C7.48942 11.3865 7.48942 10.6126 7.96672 10.1353L11.4854 6.61667C11.9626 6.13943 11.9626 5.36568 11.4854 4.88844Z" fill="#ffffff"/>
        <path d="M15.8683 4.88844L10.6214 10.1353C10.1441 10.6126 10.1441 11.3865 10.6214 11.8638L15.8683 17.1107C16.3455 17.5879 17.1192 17.5879 17.5965 17.1107C18.0737 16.6334 18.0737 15.8597 17.5965 15.3824L14.0778 11.8638C13.6005 11.3865 13.6005 10.6126 14.0778 10.1353L17.5965 6.61667C18.0737 6.13943 18.0737 5.36568 17.5965 4.88844C17.1192 4.41121 16.3455 4.41121 15.8683 4.88844Z" fill="#ffffff"/>
      </svg>
    </a>
  </div>
  @endif
  <ul class="menu-inner py-1">
    {{-- Dashboard --}}


          {{-- Switch Portal Toggle --}}
          <li class="menu-item">
            <form method="POST" action="{{ route('portal.switch') }}" >
              @csrf
                  @php
                      $menuName ='Switch Portal';
                  @endphp
                  @php
                      $options = [];
                      if(auth()->user()->hasPermission($menuName,'Management')) $options[] = 'management';
                      if(auth()->user()->hasPermission($menuName,'Business')) $options[] = 'business';
                  @endphp
                @if(auth()->user()->hasPermission($menuName))
                  <label class="toggle-wrapper" id="left-portal">
                      <input type="checkbox" name="portal_state" {{ $portalState === 'on' ? 'checked' : '' }}>
                      <span class="toggle {{ count($options) === 1 ? 'single' : '' }}">
                        @foreach($options as $option)
                            <span class="toggle-option {{ $option }}">{{ ucfirst($option) }}</span>
                        @endforeach
                    </span>
                      
                  </label>
                  <label class="toggle-wrapper-mini" id="right-portal" style="display: none;">
                      <input type="checkbox" name="portal_state" {{ $portalState === 'on' ? 'checked' : '' }}>
                      <span class="toggle-mini">
                          @if($portalState === 'on')
                            @if(auth()->user()->hasPermission($menuName,'Business'))
                            <span class="toggle-option business">B</span>
                            @endif
                          @else
                            @if(auth()->user()->hasPermission($menuName,'Management'))
                            <span class="toggle-option management">M</span>
                            @endif
                          @endif
                      </span>
                  </label>
                @endif
            </form>
          </li>

          {{-- Menus --}}
          {{-- Menus --}}
          @if ($portalState === 'on')
              @foreach ($menusOn as $menu)
                  @php
                      $menuName = $menu->name ?? $menu->menuName ?? null;
                  @endphp

                  @if(auth()->user()->hasPermission($menuName))
                      @include('layouts.sections.menu.menu_item', ['menu' => $menu])
                  @endif
              @endforeach
          @else
              @foreach ($menusOff as $menu)
                  @php
                      $menuName = $menu->name ?? $menu->menuName ?? null;
                  @endphp

                  @if(auth()->user()->hasPermission($menuName))
                      @include('layouts.sections.menu.menu_item', ['menu' => $menu])
                  @endif
              @endforeach
          @endif


  </ul>

</aside>

<style>
  .toggle-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
    height: 45px;
    cursor: pointer;
  }
   .toggle-wrapper input {
    display: none;
  }
  .toggle-wrapper-mini {
    position: relative;
    display: inline-block;
    width: 100%;
    height: 45px;
    cursor: pointer;
  }
  .toggle-wrapper-mini input {
    display: none;
  }

  .toggle-mini::before {
    content: '';
    position: absolute;
    top: 4px;
    left: 4px;
    width: 90%;
    height: calc(100% - 8px);
    background: #4e4e4e;
    border-radius: 6px;
    transition: 0.4s ease;
  }

  .toggle-mini {
    position: relative;
    width: 100%;
    height: 100%;
    background: #fab845ff; /* Base purple */
    border: 2px solid #ab2b22;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 5px;
    /* margin-left: 10px; */
    color: white;
    font-weight: 600;
    font-size: 16px;
    transition: background 0.3s ease;
    overflow: hidden;
  }

 

  .toggle {
    position: relative;
    width: 93%;
    height: 100%;
    background: #fab845ff; /* Base purple */
    border: 2px solid #ab2b22;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 5px;
    margin-left: 10px;
    color: white;
    font-weight: 600;
    font-size: 16px;
    transition: background 0.3s ease;
    overflow: hidden;
  }

  .toggle::before {
    content: '';
    position: absolute;
    top: 4px;
    left: 4px;
    width: 47%;
    height: calc(100% - 8px);
    background: #4e4e4e;
    border-radius: 6px;
    transition: 0.4s ease;
  }
  .toggle.single::before {
      width: 96%;
      left: 5px;
  }

  .toggle-option {
    position: relative;
    z-index: 2;
    flex: 1;
    text-align: center;
    transition: color 0.3s ease;
  }

  /* Default state → Management active */
  .toggle-wrapper input:not(:checked) + .toggle .management {
    color: #fff;
  }

  .toggle-wrapper input:not(:checked) + .toggle .business {
    color: #000;
  }

  /* Checked state → Business active */
  .toggle-wrapper input:checked + .toggle::before {
    left: 49%;
  }

  .toggle-wrapper input:checked + .toggle.single::before {
      left: 2%;
  }

  .toggle-wrapper input:checked + .toggle .business {
    color: #fff;
  }

  .toggle-wrapper input:checked + .toggle .management {
    color: #000;
  }
</style>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("switch-portal-toggle");
    const portalName = document.getElementById("portal_name");
    const sidebar = document.getElementById("layout-menu");

    if (!toggle) {
        // console.warn('Toggle element #switch-portal-toggle not found.');
        return;
    }
    // Load persisted state
    const portalState = localStorage.getItem("portalState") || "off";
    toggle.checked = portalState === "on";
    updateMenus();

    toggle.addEventListener("change", () => {
      const state = toggle.checked ? "on" : "off";
      localStorage.setItem("portalState", state);
      updateMenus();
    });

    function updateMenus() {
      if (toggle.checked) {
        sidebar.classList.add("portal-on");
        portalName.textContent = "Business";
      } else {
        sidebar.classList.remove("portal-on");
        portalName.textContent = "Management";
      }
    }
  });
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const toggleInput = document.querySelector('.toggle-wrapper input[type="checkbox"]');
    const form = toggleInput.closest('form');

    toggleInput.addEventListener('change', function() {
        form.submit(); // Auto-submit when toggled
    });
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const html = document.documentElement;
  const toggleButton = document.querySelector('.layout-menu-toggle');
  const logoLeft = document.getElementById('logo-left');   // big
  const logoRight = document.getElementById('logo-right'); // small

  const portalLeft = document.getElementById('left-portal');   // big
  const portalRight = document.getElementById('right-portal'); // small

  if (!logoLeft || !logoRight) return;
  if (!portalLeft || !portalRight) return;

  // Decide which logo to show based on classes:
  // - if NOT collapsed -> big logo
  // - if collapsed AND hovered (layout-menu-hover) -> big logo
  // - if collapsed AND NOT hovered -> small logo
  function updateLogos() {
    const collapsed = html.classList.contains('layout-menu-collapsed');
    const hovered = html.classList.contains('layout-menu-hover');

    if (!collapsed) {
      // expanded -> show big
      logoLeft.style.display = 'block';
      logoRight.style.display = 'none';

      portalLeft.style.display = 'block';
      portalRight.style.display = 'none';
    } else {
      // collapsed
      if (hovered) {
       // collapsed but hovered -> show big
        logoLeft.style.display = 'block';
        logoRight.style.display = 'none';

        portalLeft.style.display = 'block';
        portalRight.style.display = 'none';

      } else {
         // collapsed and not hovered -> show small
        logoLeft.style.display = 'none';
        logoRight.style.display = 'block';

        portalLeft.style.display = 'none';
        portalRight.style.display = 'block';
      }
    }
  }

  // Initial set
  updateLogos();

  // Toggle button may change classes after an animation; allow slight delay
  if (toggleButton) {
    toggleButton.addEventListener('click', function () {
      setTimeout(updateLogos, 120); // small delay to let template update classes
    });
  }

  // MutationObserver to watch for class changes on <html>
  const mo = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'class') {
        updateLogos();
        break;
      }
    }
  });

  mo.observe(html, { attributes: true, attributeFilter: ['class'] });

  // Optional: clean up when page unloads
  window.addEventListener('beforeunload', () => mo.disconnect());
});
</script>
