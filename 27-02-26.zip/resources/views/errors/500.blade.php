<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Server Error</title>
</head>
<body>
    <div class="error-page">

        {{-- Error Image --}}
        <img src="{{ asset('assets/egc_images/bg_image/500-Error-Page.png') }}" 
             alt="500 Server Error" 
             class="error-image" />

        {{-- Heading --}}
        <h1 class="error-title">Oops! Something Went Wrong</h1>

        {{-- Sub Text --}}
        <p class="error-subtitle">
            We’re sorry, but an unexpected error occurred.<br>
            Please try again later or contact the developer.
        </p>

        {{-- Small Error Message (optional) --}}
        @if(!empty($message))
            <p class="error-message">
                {{ $message }}
            </p>
        @endif

        {{-- Buttons --}}
        <div class="button-group">
            <a href="{{ url('/dashboard') }}" class="btn btn-primary">Back to Dashboard</a>
            <!-- <a href="mailto:developer@example.com" class="btn btn-secondary">Contact Developer</a> -->
        </div>

    </div>
</body>

<style>
/* Layout */
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    overflow: hidden; /* Prevent scroll */
}

/* Layout */
.error-page {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    height: 100vh;
    width: 100%;
    box-sizing: border-box;
    padding: 20px;
    background-color: #f8f9fa;
}

/* Image */
.error-image {
    max-width: 70%;
    max-height: 35vh; /* Reduce image height */
    object-fit: contain;
    /* margin-bottom: 15px; */
}

/* Text */
.error-title {
    font-size: 36px;
    font-weight: 800;
    color: #ab2b22; /* primary */
    margin-bottom: 10px;
}

.error-subtitle {
    font-size: 18px;
    color: #333;
    margin-bottom: 15px;
    line-height: 1.5;
}

.error-message {
    font-size: 12px;
    color: #888;
    max-width: 70%;
    margin-bottom: 20px;
    word-break: break-all;
}

/* Buttons */
.button-group {
    display: flex;
    gap: 10px;
}

.btn {
    padding: 10px 22px;
    font-size: 15px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 700;
    text-transform: uppercase;
}

/* Primary Button */
.btn-primary {
    background-color: #ab2b22;
    color: white;
    border: 2px solid #ab2b22;
}

.btn-primary:hover {
    background-color: #fba919;
    border-color: #fba919;
    color: black;
}

/* Secondary Button */
.btn-secondary {
    background-color: transparent;
    color: #ab2b22;
    border: 2px solid #ab2b22;
}

.btn-secondary:hover {
    background-color: #fba919;
    border-color: #fba919;
    color: black;
}

@media (max-width: 600px) {
    .error-title { font-size: 28px; }
    .error-subtitle { font-size: 16px; }
    .button-group { flex-direction: column; }
}

</style>
</html>
