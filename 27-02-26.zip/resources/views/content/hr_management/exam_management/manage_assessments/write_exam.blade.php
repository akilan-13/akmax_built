@extends('layouts/blankLayout')

@section('title', 'Staff Exam Panel')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/scss/pages/page-auth.scss',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/auto-focus.js',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/autosize/autosize.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/form-wizard-numbered.js'])
@vite(['resources/assets/js/forms_extras.js'])
@endsection

@section('content')

@php
$helper = new \App\Helpers\Helpers();
@endphp
<style>
    .exam-card {
      max-width: 360px;
      width: 100%;
      padding: 2rem;
      border-radius: 1rem;
      background: white;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
      text-align: center;
      animation: fadeInUp 0.6s ease forwards;
      display: contents;
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(20px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }
</style>
<!-- Users List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 pt-1">
        <div class="card-action-title mt-2">
            <label class="text-black mb-1 fs-5 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                title="Exam Name">{{$exam->exam_name ?? '-'}}
            </label>
            <div class="d-block text-dark fs-7 fw-bold">
                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="Exam Level">
                    @if($exam->level_id == 0)
                        Beginner
                    @elseif ($exam->level_id == 1)
                        Intermediate
                    @elseif ($exam->level_id == 2)
                        Expert
                    @else
                        -
                    @endif
                </label>
            </div>
        </div>
        <div class="card-action-element d-flex align-items-center mt-2">
            <div class="d-flex  px-1">
                <div class="symbol symbol-35px me-2">
                    @if ($user_details->staff_image != '' && file_exists(public_path('staff_images/' .$user_details->staff_image)))
                        <div class="image-input image-input-circle" data-kt-image-input="true">
                            <div class="image-input image-input-circle" data-kt-image-input="true" >
                                <img src="{{ asset('staff_images/' . $user_details->staff_image) }}" class="w-45px h-45px rounded-circle border border-gray-400" id="uploadedlogo"  />
                            </div>
                        </div>
                    @else
                        <div class="symbol symbol-35px me-2">
                            @php
                            $initial = strtoupper(substr($user_details->staff_name, 0, 1)); // Only keeps and
                            // capitalizes the first
                            echo $helper->name_image($initial, $user_details->gender);
                            @endphp
                        </div>
                    @endif
                </div>
                <div class="mb-0">
                    <label class="fs-5 text-primary fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Staff Name">{{$user_details->staff_name ?? '-' }}</label>
                    <div class="d-block">
                        <div class="text-dark fs-7 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Job Role">{{$user_details->job_position_name ?? '-' }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @php
        $examProcesssts = $examProcess->status ?? '';
        $examProcess_sno = $examProcess->sno ?? 0;
    @endphp
    
    @if($examProcesssts == 2)
        <div class="exam-card">
            <div class="d-flex justify-content-center align-items-center pt-8">
                <img src="{{ asset('assets/egc_images/exam-com.png') }}" class="w-100px h-100px" alt="Exam">
            </div>
            <h2>Exam Completed!</h2>
            <p>Congratulations on finishing your exam. You can now view your results.</p>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <a href="javascript:;" class="btn btn-primary me-3"  rel="noopener noreferrer" onclick="exam_close()" >
                 View Result
                </a>
            </div>
        </div>
    @elseif($exam->exam_attempt == 1)
        @php
            $staff_id = auth()->user()->user_id;
            $new_limit = $helper->get_new_exam_limits($exam->sno,$staff_id);
            if($new_limit){
                $exam->attempts = $new_limit;
            }
        @endphp
        @if($exam->attempts <= $attempted_count)
            <div class="exam-card">
            <div class="d-flex justify-content-center align-items-center pt-8">
                <img src="{{ asset('assets/egc_images/exam-com.png') }}" class="w-100px h-100px" alt="Exam">
            </div>
            <h2>Exam Completed!</h2>
            <p>Congratulations on finishing your exam. You can now view your results.</p>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
              <!--  <a href="/manage-assessments" class="btn btn-primary me-3" target="_self" rel="noopener noreferrer">-->
              <!--   View Result-->
              <!--</a>-->
              <a href="javascript:;" class="btn btn-primary me-3"  rel="noopener noreferrer" onclick="exam_close()" >
                 View Result
                </a>
            </div>
        </div>
        @else
            <div class="card-body">
            <div class="row">
                <div class="col-lg-3 mb-2">
                    <div class="row px-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12">
                                        <label class="text-black mb-1 fs-5 fw-bold">Question Status</label>
                                    </div>
                                </div>
                                @php
                                $questionStatuses = [];
                            
                                foreach ($question_list as $ii => $question) {
                                        $savedAnswer = collect($savedAnswers)->firstWhere('question_id', (string)$question->sno);
                                        $isAnswered = false;
                                        
                                        if ($savedAnswer && isset($savedAnswer['answer'])) {
                                            $submitted = $savedAnswer['answer'];
                                        
                                            if (is_array($submitted)) {
                                                // Checkbox: mark attempted only if at least one non-null/non-empty value exists
                                                $isAnswered = count(array_filter($submitted, fn($val) => $val !== null && $val !== '')) > 0;
                                            } else {
                                                // Radio / single choice
                                                $isAnswered = $submitted !== null && $submitted !== '';
                                            }
                                        }
                                        
                                        if ($isAnswered) {
                                            $questionStatuses[$question->sno] = 'attempted';
                                        } elseif ($savedAnswer) {
                                            $questionStatuses[$question->sno] = 'not_attempted';
                                        } else {
                                            $questionStatuses[$question->sno] = 'to_be_viewed';
                                        }
    
                                    }
                                @endphp
                                <div
                                    class="d-flex justify-content-start align-items-center flex-wrap mb-4 scroll-y max-h-300px">
                                    @if($question_list)
                                        @foreach($question_list as $indexs => $ql)
                                        
                                        @php
                                            $status = $questionStatuses[$ql->sno] ?? 'to_be_viewed';
                                            $badgeClass = match($status) {
                                                'attempted' => 'bg-label-success border border-success',
                                                'not_attempted' => 'bg-label-danger border border-danger',
                                                'to_be_viewed' => 'bg-label-dark border border-dark',
                                                default => 'bg-label-secondary border border-secondary',
                                            };
                                        @endphp
                                            <!-- success info  danger dark-->
                                            <div class="mb-2 me-2">
                                                <a href="javascript:;" class="badge {{ $badgeClass }}  fs-6 fw-bold  rounded w-50px h-25px" id="badge-{{ $ql->sno }}">{{ str_pad($indexs + 1, 2, '0', STR_PAD_LEFT) }}</a>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                                <div class="row flex-wrap">
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-success fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Answered</div>
                                    </div>
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-danger fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Not Answered</div>
                                    </div>
                                    <!--<div class="col-lg-6 d-flex align-items-center mb-3">-->
                                    <!--    <div class="badge badge-dot text-bg-info fs-2 me-1">-->
                                    <!--    </div>-->
                                    <!--    <div class="text-black fs-6 fw-bold">Viewed</div>-->
                                    <!--</div>-->
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-secondary fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Not Viewed</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 mb-2">
                    <div class="row px-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="bs-stepper wizard-numbered shadow-none">
                                            <div class="bs-stepper-header px-0 py-0 border-bottom-0 h-1px">
                                                @if($question_list)
                                                    @foreach($question_list as $iq => $question)
                                                        <div class="step" data-target="#question_{{ $iq }}">
                                                            <button type="button" class="step-trigger"></button>
                                                        </div>
                                                    @endforeach
                                                @endif
                                            </div>
                                            <input type="hidden" id="exam_sno" value="{{$exam->sno ?? 0}}">
                                            <input type="hidden" id="examProcess_sno" value="{{$examProcess->sno ?? 0}}">
                                            <input type="hidden" id="examProcesssts" value="{{$examProcess->status ?? 0}}">
                                            
                                            <div class="bs-stepper-content px-0 py-0">
                                                <form onsubmit="return false">
                                                    @if($question_list)
                                                    
                                                        @foreach($question_list as $index => $question)
                                                            <div id="question_{{ $index }}" class="content">
                                                                <div class="row">
                                                                    <!-- Question Text -->
                                                                    <div class="col-10 fw-semibold fs-6 text-black mb-1">
                                                                        {{ $index + 1 }}. {!! $question->question !!}
                                                                        <input type="hidden"  name="question_id_{{ $question->sno }}" value="{{ $question->sno }}"> <!-- Unique name for each question -->
                                                                    </div>
                                                                    
                                                                    <!-- Hint / Explanation / Case Study Icons -->
                                                                    <div class="col-2 d-flex justify-content-end align-items-center mb-1">
                                                                        @if($exam->tips_check == 1)
                                                                            @if(!empty($question->tips))
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Hint"
                                                                                   onclick="toggleBox(this, 'hint')">
                                                                                    <i class="mdi mdi-lightbulb-on-outline fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                        @if($exam->explanation_check == 1)
                                                                            @if(!empty($question->explanation))
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Explanation"
                                                                                   onclick="toggleBox(this, 'exp')">
                                                                                    <i class="mdi mdi-brain fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                        @if($exam->case_study_check == 1)
                                                                            @if(!empty($question->case_study) && $question->case_study_check == 1)
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Case Study"
                                                                                   onclick="toggleBox(this, 'case')">
                                                                                    <i class="mdi mdi-book-search-outline fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                    
                                                                    <!-- Tips / Explanation / Case Study Boxes -->
                                                                    <div class="col-12 mb-6">
                                                                        <div class="d-block fw-semibold text-dark mb-1">
                                                                            <div class="row">
                                                                                @if(!empty($question->tips))
                                                                                    <div class="col-12 card bg-label-success mb-3 mt-1 hint_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Tips:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->tips !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                @if(!empty($question->explanation))
                                                                                    <div class="col-12 card bg-label-danger mb-3 mt-1 exp_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Explanation:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->explanation !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                @if(!empty($question->case_study) && $question->case_study_check == 1)
                                                                                    <div class="col-12 card bg-label-info mb-3 mt-1 case_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Case Study:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->case_study !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                <!-- Options -->
                                                                                <div class="row mt-4">
                                                                                    @php
                                                                                        $options = json_decode($question->option); // Question options
                                                                                        $savedAnswer = collect($savedAnswers)->firstWhere('question_id', (string)$question->sno); // Saved answer
                                                                                    @endphp
                                                                                    
                                                                                    @if(is_array($options))
                                                                                        <div class="row">
                                                                                            @foreach($options as $optIndex => $option)
                                                                                                @php
                                                                                                    // Determine if this option should be checked
                                                                                                    $checked = false;
                                                                                    
                                                                                                    if($savedAnswer) {
                                                                                                        if($question->option_type == 0) {
                                                                                                            // Radio: single answer
                                                                                                            $checked = ((string)$savedAnswer['answer'] === (string)$optIndex);
                                                                                                        } elseif($question->option_type == 1) {
                                                                                                            // Checkbox: multiple answers
                                                                                                            $answersArray = (array)$savedAnswer['answer'];
                                                                                                            $answersArray = array_map('strval', $answersArray); // normalize to string
                                                                                                            $checked = in_array((string)$optIndex, $answersArray);
                                                                                                        }
                                                                                                    }
                                                                                                @endphp
                                                                                    
                                                                                                <div class="col-12 border rounded px-2 py-2 ms-4 mb-2">
                                                                                                    <div class="form-check form-check-inline me-3">
                                                                                                        <input
                                                                                                            class="form-check-input"
                                                                                                            type="{{ $question->option_type == 0 ? 'radio' : 'checkbox' }}"
                                                                                                            id="option_{{ $question->sno }}_{{ $optIndex }}"
                                                                                                            name="options[{{ $question->sno }}]{{ $question->option_type == 1 ? '[]' : '' }}"
                                                                                                            value="{{ $optIndex }}"
                                                                                                            {{ $checked ? 'checked' : '' }}
                                                                                                        >
                                                                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">{{ $option }}</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                    
                                                                                                @if(($optIndex) % 2 == 0 && $optIndex < count($options))
                                                                                                    </div><div class="row">
                                                                                                @endif
                                                                                            @endforeach
                                                                                        </div>
                                                                                    @endif
    
                                                                                    
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    
                                    
                                                                    <!-- Navigation Buttons -->
                                                                    <div class="col-12 d-flex justify-content-between">
                                                                        <button type="button" class="btn btn-outline-secondary btn-prev" {{ $index === 0 ? 'disabled' : '' }}>
                                                                              <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                                                                              <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                                          </button>
                                                                         @if($examProcess)
                                                                            {{-- If it's the last question, show "Complete" button; otherwise, show "Next" button --}}
                                                                              @if ($index === count($question_list) - 1 && $examProcess->status == 1)
                                                                                  <button type="button" class="btn btn-primary btn-complete btn-next" data-bs-toggle="modal" data-bs-target="#kt_modal_cfm_exam_status">
                                                                                      <span class="align-middle d-sm-inline-block d-none me-sm-1">Complete</span> <i class="mdi mdi-check"></i>
                                                                                  </button>
                                                                              @elseif ($examProcess->status == 1)
                                                                                  <button type="button" class="btn btn-primary btn-next">
                                                                                      <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right"></i>
                                                                                  </button>
                                                                              @else
                                                                                
                                                                            @endif
                                                                         @else
                                                                            @if ($index === count($question_list) - 1)
                                                                                <button type="button" class="btn btn-success btn-complete btn-next" data-bs-toggle="modal" data-bs-target="#kt_modal_cfm_exam_status">
                                                                                    <span class="align-middle d-sm-inline-block d-none me-sm-1">Complete</span> <i class="mdi mdi-check"></i>
                                                                                </button>
                                                                            @else
                                                                              <button type="button" class="btn btn-primary btn-next">
                                                                                  <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right"></i>
                                                                              </button>
                                                                            @endif
                                                                         @endif
                                                                    </div>
                                    
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 mb-2">
                    
                    <div class="row px-2 mb-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-center">
                                        <div class="badge bg-danger text-white mb-1 fs-3 fw-bold w-125px"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Time Duration">
                                            <label class="text-center" id="time"></label>
                                        </div>
                                    </div>
                                    <hr class="mt-1 mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-start mb-2">
                                        <a href="javascript:;" class="btn btn-icon me-2 btn-outline-success"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">
                                            <i class="mdi mdi-timer-outline fs-3 text-black"></i>
                                        </a>
                                        <div class="fw-semibold fs-6 text-black">{{$exam->duration}} Minutes</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-start mb-2">
                                        <a href="javascript:;" class="btn btn-icon me-2 btn-outline-success"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Questions Count">
                                            <i class="mdi mdi-newspaper-variant-outline fs-3 text-black"></i>
                                        </a>
                                        <div class="fw-semibold fs-6 text-black">{{ count(json_decode($question_list ?? '[]')) }} Questions</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                    <div class="row px-2 mb-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12 fs-5 fw-semibold text-black">
                                        Overview
                                    </div>
                                    <hr class="mt-1 mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Total Questions</div>
                                        <div class="fw-bold fs-6 text-black">{{ count(json_decode($question_list ?? '[]')) }}</div>
                                    </div>
                                    <!--<div class="col-12 d-flex align-items-center justify-content-between mb-2">-->
                                    <!--    <div class="fw-semibold fs-6 text-black">Viewed</div>-->
                                    <!--    <div class="fw-bold fs-6 text-black">40</div>-->
                                    <!--</div>-->
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Not Viewed</div>
                                        <div class="fw-bold fs-6 text-black" id="viewed_count">0</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Answered</div>
                                        <div class="fw-bold fs-6 text-black" id="atten_count">0</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Not Answered</div>
                                        <div class="fw-bold fs-6 text-black" id="not_att_count">0</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    @elseif($exam->exam_attempt == 0)
        @if($attempted_count >= 10000)
            <div class="exam-card">
            <div class="d-flex justify-content-center align-items-center pt-8">
                <img src="{{ asset('assets/egc_images/exam-com.png') }}" class="w-100px h-100px" alt="Exam">
            </div>
            <h2>Exam Completed!</h2>
            <p>Congratulations on finishing your exam. You can now view your results.</p>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <a href="javascript:;" class="btn btn-primary me-3"  rel="noopener noreferrer" onclick="exam_close()" >
                 View Result
                </a>
            </div>
        </div>
        @else
            <div class="card-body">
            <div class="row">
                <div class="col-lg-3 mb-2">
                    <div class="row px-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12">
                                        <label class="text-black mb-1 fs-5 fw-bold">Question Status</label>
                                    </div>
                                </div>
                                @php
                                $questionStatuses = [];
                            
                                foreach ($question_list as $ii => $question) {
                                        $savedAnswer = collect($savedAnswers)->firstWhere('question_id', (string)$question->sno);
                                        $isAnswered = false;
                                        
                                        if ($savedAnswer && isset($savedAnswer['answer'])) {
                                            $submitted = $savedAnswer['answer'];
                                        
                                            if (is_array($submitted)) {
                                                // Checkbox: mark attempted only if at least one non-null/non-empty value exists
                                                $isAnswered = count(array_filter($submitted, fn($val) => $val !== null && $val !== '')) > 0;
                                            } else {
                                                // Radio / single choice
                                                $isAnswered = $submitted !== null && $submitted !== '';
                                            }
                                        }
                                        
                                        if ($isAnswered) {
                                            $questionStatuses[$question->sno] = 'attempted';
                                        } elseif ($savedAnswer) {
                                            $questionStatuses[$question->sno] = 'not_attempted';
                                        } else {
                                            $questionStatuses[$question->sno] = 'to_be_viewed';
                                        }
    
                                    }
                                @endphp
                                <div
                                    class="d-flex justify-content-start align-items-center flex-wrap mb-4 scroll-y max-h-300px">
                                    @if($question_list)
                                        @foreach($question_list as $indexs => $ql)
                                        
                                        @php
                                            $status = $questionStatuses[$ql->sno] ?? 'to_be_viewed';
                                            $badgeClass = match($status) {
                                                'attempted' => 'bg-label-success border border-success',
                                                'not_attempted' => 'bg-label-danger border border-danger',
                                                'to_be_viewed' => 'bg-label-dark border border-dark',
                                                default => 'bg-label-secondary border border-secondary',
                                            };
                                        @endphp
                                            <!-- success info  danger dark-->
                                            <div class="mb-2 me-2">
                                                <a href="javascript:;" class="badge {{ $badgeClass }}  fs-6 fw-bold  rounded w-50px h-25px" id="badge-{{ $ql->sno }}">{{ str_pad($indexs + 1, 2, '0', STR_PAD_LEFT) }}</a>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                                <div class="row flex-wrap">
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-success fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Answered</div>
                                    </div>
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-danger fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Not Answered</div>
                                    </div>
                                    <!--<div class="col-lg-6 d-flex align-items-center mb-3">-->
                                    <!--    <div class="badge badge-dot text-bg-info fs-2 me-1">-->
                                    <!--    </div>-->
                                    <!--    <div class="text-black fs-6 fw-bold">Viewed</div>-->
                                    <!--</div>-->
                                    <div class="col-lg-6 d-flex align-items-center mb-3">
                                        <div class="badge badge-dot text-bg-secondary fs-2 me-1">
                                        </div>
                                        <div class="text-black fs-6 fw-bold">Not Viewed</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 mb-2">
                    <div class="row px-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="bs-stepper wizard-numbered shadow-none">
                                            <div class="bs-stepper-header px-0 py-0 border-bottom-0 h-1px">
                                                @if($question_list)
                                                    @foreach($question_list as $iq => $question)
                                                        <div class="step" data-target="#question_{{ $iq }}">
                                                            <button type="button" class="step-trigger"></button>
                                                        </div>
                                                    @endforeach
                                                @endif
                                            </div>
                                            <input type="hidden" id="exam_sno" value="{{$exam->sno ?? 0}}">
                                            <input type="hidden" id="examProcess_sno" value="{{$examProcess->sno ?? 0}}">
                                            <input type="hidden" id="examProcesssts" value="{{$examProcess->status ?? 0}}">
                                            
                                            <div class="bs-stepper-content px-0 py-0">
                                                <form onsubmit="return false">
                                                    @if($question_list)
                                                        @foreach($question_list as $index => $question)
                                                            <div id="question_{{ $index }}" class="content">
                                                                <div class="row">
                                                                    <!-- Question Text -->
                                                                    <div class="col-10 fw-semibold fs-6 text-black mb-1">
                                                                        {{ $index + 1 }}. {!! $question->question !!}
                                                                        <input type="hidden" name="question_id_{{ $question->sno }}" value="{{ $question->sno }}"> <!-- Unique name for each question -->
                                                                    </div>
                                    
                                                                    <!-- Hint / Explanation / Case Study Icons -->
                                                                    <div class="col-2 d-flex justify-content-end align-items-center mb-1">
                                                                        @if($exam->tips_check == 1)
                                                                            @if(!empty($question->tips))
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Hint"
                                                                                   onclick="toggleBox(this, 'hint')">
                                                                                    <i class="mdi mdi-lightbulb-on-outline fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                        @if($exam->explanation_check)
                                                                            @if(!empty($question->explanation))
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Explanation"
                                                                                   onclick="toggleBox(this, 'exp')">
                                                                                    <i class="mdi mdi-brain fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                        @if($exam->explanation_check)
                                                                            @if(!empty($question->case_study) && $question->case_study_check == 1)
                                                                                <a href="javascript:;" class="fw-semibold fs-6 text-black me-2"
                                                                                   data-bs-toggle="tooltip" data-bs-placement="bottom" title="Case Study"
                                                                                   onclick="toggleBox(this, 'case')">
                                                                                    <i class="mdi mdi-book-search-outline fs-3"></i>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                        
                                                                    </div>
                                    
                                                                    <!-- Tips / Explanation / Case Study Boxes -->
                                                                    <div class="col-12 mb-6">
                                                                        <div class="d-block fw-semibold text-dark mb-1">
                                                                            <div class="row">
                                                                                @if(!empty($question->tips))
                                                                                    <div class="col-12 card bg-label-success mb-3 mt-1 hint_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Tips:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->tips !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                @if(!empty($question->explanation))
                                                                                    <div class="col-12 card bg-label-danger mb-3 mt-1 exp_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Explanation:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->explanation !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                @if(!empty($question->case_study) && $question->case_study_check == 1)
                                                                                    <div class="col-12 card bg-label-info mb-3 mt-1 case_tbox" style="display: none;">
                                                                                        <div class="card-body px-2 py-2">
                                                                                            <div class="fw-semibold fs-7 text-black mb-1"><u>Case Study:</u></div>
                                                                                            <div class="d-block fw-semibold fs-8 text-black mb-1">{!! $question->case_study !!}</div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endif
                                    
                                                                                <!-- Options -->
                                                                                <div class="row mt-4">
                                                                                    @php
                                                                                        $options = json_decode($question->option); // Question options
                                                                                        $savedAnswer = collect($savedAnswers)->firstWhere('question_id', (string)$question->sno); // Saved answer
                                                                                    @endphp
                                                                                    
                                                                                    @if(is_array($options))
                                                                                        <div class="row">
                                                                                            @foreach($options as $optIndex => $option)
                                                                                                @php
                                                                                                    // Determine if this option should be checked
                                                                                                    $checked = false;
                                                                                    
                                                                                                    if($savedAnswer) {
                                                                                                        if($question->option_type == 0) {
                                                                                                            // Radio: single answer
                                                                                                            $checked = ((string)$savedAnswer['answer'] === (string)$optIndex);
                                                                                                        } elseif($question->option_type == 1) {
                                                                                                            // Checkbox: multiple answers
                                                                                                            $answersArray = (array)$savedAnswer['answer'];
                                                                                                            $answersArray = array_map('strval', $answersArray); // normalize to string
                                                                                                            $checked = in_array((string)$optIndex, $answersArray);
                                                                                                        }
                                                                                                    }
                                                                                                @endphp
                                                                                    
                                                                                                <div class="col-12 border rounded px-2 py-2 ms-4 mb-2">
                                                                                                    <div class="form-check form-check-inline me-3">
                                                                                                        <input
                                                                                                            class="form-check-input"
                                                                                                            type="{{ $question->option_type == 0 ? 'radio' : 'checkbox' }}"
                                                                                                            id="option_{{ $question->sno }}_{{ $optIndex }}"
                                                                                                            name="options[{{ $question->sno }}]{{ $question->option_type == 1 ? '[]' : '' }}"
                                                                                                            value="{{ $optIndex }}"
                                                                                                            {{ $checked ? 'checked' : '' }}
                                                                                                        >
                                                                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">{{ $option }}</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                    
                                                                                                @if(($optIndex) % 2 == 0 && $optIndex < count($options))
                                                                                                    </div><div class="row">
                                                                                                @endif
                                                                                            @endforeach
                                                                                        </div>
                                                                                    @endif
    
                                                                                    
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    
                                    
                                                                    <!-- Navigation Buttons -->
                                                                    <div class="col-12 d-flex justify-content-between">
                                                                        <button type="button" class="btn btn-outline-secondary btn-prev" {{ $index === 0 ? 'disabled' : '' }}>
                                                                              <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                                                                              <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                                          </button>
                                                                         @if($examProcess)
                                                                            {{-- If it's the last question, show "Complete" button; otherwise, show "Next" button --}}
                                                                              @if ($index === count($question_list) - 1 && $examProcess->status == 1)
                                                                                  <button type="button" class="btn btn-primary btn-complete btn-next" data-bs-toggle="modal" data-bs-target="#kt_modal_cfm_exam_status">
                                                                                      <span class="align-middle d-sm-inline-block d-none me-sm-1">Complete</span> <i class="mdi mdi-check"></i>
                                                                                  </button>
                                                                              @elseif ($examProcess->status == 1)
                                                                                  <button type="button" class="btn btn-primary btn-next">
                                                                                      <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right"></i>
                                                                                  </button>
                                                                              @else
                                                                                
                                                                            @endif
                                                                         @else
                                                                            @if ($index === count($question_list) - 1)
                                                                                <button type="button" class="btn btn-success btn-complete btn-next" data-bs-toggle="modal" data-bs-target="#kt_modal_cfm_exam_status">
                                                                                    <span class="align-middle d-sm-inline-block d-none me-sm-1">Complete</span> <i class="mdi mdi-check"></i>
                                                                                </button>
                                                                            @else
                                                                              <button type="button" class="btn btn-primary btn-next">
                                                                                  <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="mdi mdi-arrow-right"></i>
                                                                              </button>
                                                                            @endif
                                                                         @endif
                                                                    </div>
                                    
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 mb-2">
                    <div class="row px-2 mb-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-center">
                                        <div class="badge bg-danger text-white mb-1 fs-3 fw-bold w-125px"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Time Duration">
                                            <label class="text-center" id="time"></label>
                                        </div>
                                    </div>
                                    <hr class="mt-1 mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-start mb-2">
                                        <a href="javascript:;" class="btn btn-icon me-2 btn-outline-success"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Duration">
                                            <i class="mdi mdi-timer-outline fs-3 text-black"></i>
                                        </a>
                                        <div class="fw-semibold fs-6 text-black">{{$exam->duration}} Minutes</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-start mb-2">
                                        <a href="javascript:;" class="btn btn-icon me-2 btn-outline-success"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Questions Count">
                                            <i class="mdi mdi-newspaper-variant-outline fs-3 text-black"></i>
                                        </a>
                                        <div class="fw-semibold fs-6 text-black">{{ count(json_decode($question_list ?? '[]')) }} Questions</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                    <div class="row px-2 mb-2">
                        <div class="border rounded">
                            <div class="card-body px-2 py-3">
                                <div class="row mb-2">
                                    <div class="col-12 fs-5 fw-semibold text-black">
                                        Overview
                                    </div>
                                    <hr class="mt-1 mb-2">
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Total Questions</div>
                                        <div class="fw-bold fs-6 text-black">{{ count(json_decode($question_list ?? '[]')) }}</div>
                                    </div>
                                    <!--<div class="col-12 d-flex align-items-center justify-content-between mb-2">-->
                                    <!--    <div class="fw-semibold fs-6 text-black">Viewed</div>-->
                                    <!--    <div class="fw-bold fs-6 text-black">40</div>-->
                                    <!--</div>-->
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Not Viewed</div>
                                        <div class="fw-bold fs-6 text-black" id="viewed_count">0</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Answered</div>
                                        <div class="fw-bold fs-6 text-black" id="atten_count">0</div>
                                    </div>
                                    <div class="col-12 d-flex align-items-center justify-content-between mb-2">
                                        <div class="fw-semibold fs-6 text-black">Not Answered</div>
                                        <div class="fw-bold fs-6 text-black" id="not_att_count">0</div>
                                    </div>
                                </div>
    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
    @endif
</div>


<!--begin::Modal - Confirm Exam Completed Status-->
<div class="modal fade" id="kt_modal_cfm_exam_status" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Completed the<br> <b class="text-success fs-5 fw-bold">{{$exam->exam_name ?? '-'}}</b> <br>  Exam ?</div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="button"  class="btn btn-primary me-3"  onclick="openExamResultAndReload()">Yes</button>
        <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirm Exam Completed Status-->


<script>
function exam_close() {

    // Redirect to Laravel URL directly
    window.location.replace("/manage-assessments");
}
</script>
<script>
  // To store the start time of each question
  var questionStartTimes = {};

  // Function to handle question navigation (Previous and Next)
  $('.btn-next').click(function() {
      
      
    var question_id = $(this).closest('.content').find("input[name^='question_id_']").val();  // This selects the correct question ID input field
    // alert(question_id);
    var answer_data = {};  // Collect the answer for this question

    // Get the selected answer(s) for the current question
    var selectedAnswer = null;

    // Handle radio buttons
    if ($(`input[name='options[${question_id}]']:checked`).length > 0) {
        selectedAnswer = $(`input[name='options[${question_id}]']:checked`).val();
    }
    // Handle checkboxes (multiple options)
    else if ($(`input[name='options[${question_id}][]']:checked`).length > 0) {
        selectedAnswer = $(`input[name='options[${question_id}][]']:checked`).map(function() {
          return $(this).val();
        }).get();
    }
    // Handle text fields
    else if ($(`textarea[name='options[${question_id}]']`).length > 0) {
        selectedAnswer = $(`textarea[name='options[${question_id}]']`).val();
    }
    
    
    // Save the selected answer
    answer_data.answer = selectedAnswer;
   var exm_id = {{ $exam->sno }};
    // Capture time spent for this question
    
    var endTime = new Date().getTime();  // Get the current time when user navigates away
    console.log("End Time: ", endTime);  // Debugging: log the end time
    // alert(endTime)
    var startTime = questionStartTimes[question_id];
    // alert(startTime)
    console.log("Start Time: ", startTime);  // Debugging: log the start time
    
    var timeSpent = (endTime - startTime) / 1000 ;  // Time in seconds
    console.log("Time Spent (in seconds): ", timeSpent);  // Debugging: log the time spent
    
    answer_data.time_spent = timeSpent;  // Assign the time spent to answer data
    console.log("Answer Data Time Spent: ", answer_data.time_spent);  // Debugging: log the answer data time spent


    // Send data via AJAX to save it (send question_id, answer, and time_spent)
    $.ajax({
        url: '/save-exam-answer',  // Your route to save data
        method: 'POST',
        data: {
            question_id: question_id,  // Using the correct question_id from the hidden input
            answer_data: answer_data,
            exam_id: exm_id,
            _token: $('meta[name="csrf-token"]').attr('content')  // CSRF token for security
        },
        success: function(response) {
            // alert(response.Exam_process.sno);
            $('#examProcess_sno').val(response.Exam_process.sno);
            $('#examProcesssts').val(response.Exam_process.status);
            
            console.log('Answer and time saved');
            console.log(response);
            refreshQuestionStatuses()
        },
        error: function(error) {
            console.log('Error saving answer and time');
            refreshQuestionStatuses()
        }
    });
  });

  // Track start time when user starts a question (on page load or first visit)
  $(document).ready(function() {
    $('.content').each(function() {
        var question_id = $(this).find("input[name^='question_id_']").val();  // Get the correct question_id based on the updated name
        console.log('loop',question_id);
        questionStartTimes[question_id] = new Date().getTime();  // Store start time for each question
    });
  });
</script>

<script>
function padTwoDigits(num) {
  return num.toString().padStart(2, '0');
}

  function refreshQuestionStatuses() {
    var f = 0;
    //   console.log("Refreshing question statuses...");
      $.ajax({
          url: "{{ route('examgetQuestionStatuses') }}",
          type: "POST",
          cache: false,
          data: {
              sno: $('#examProcess_sno').val(),
              savedAnswers: @json($savedAnswers),
              _token: "{{ csrf_token() }}"
          },
          success: function(response) {
            //   console.log("Received statuses:", response);
              var countnext = response.countsaved + 1;

              $("#countchange").val(countnext).trigger('input');
              
              // Example if your backend sends total questions count
            $('#atten_count').html(padTwoDigits(response.attemptedCount));
            $('#not_att_count').html(padTwoDigits(response.notAttemptedCount));
            
            var total_ques = {{ count(json_decode($question_list ?? '[]')) }};
            var viewedCount = total_ques - (response.attemptedCount + response.notAttemptedCount);
            $('#viewed_count').html(padTwoDigits(viewedCount));


            
              
              // Update each badge according to the response statuses
              @foreach ($question_list as $question)
                  var status = response.questionStatuses['{{ $question->sno }}'] ?? 'to_be_viewed';
                  var badge = $('#badge-{{ $question->sno }}');
                // alert()
                  // Update badge class dynamically
                  badge.removeClass().addClass('badge fs-6 fw-bold  rounded w-50px h-25px'); // Reset classes
                                            
                  switch (status) {
                      case 'attempted':
                          badge.addClass('bg-label-success border border-success');
                          break;
                      case 'not_attempted':
                          badge.addClass('bg-label-danger border border-danger');
                          break;
                      case 'to_be_viewed':
                          badge.addClass('bg-label-dark border border-dark');
                          break;
                      default:
                          badge.addClass('bg-label-secondary border border-secondary');
                  }
              @endforeach
          },
          error: function(xhr, status, error) {
              console.error("Error refreshing question statuses:", error);
          }
      });
  }

  // Refresh question statuses every second (1000 milliseconds)
//   setInterval(refreshQuestionStatuses, 1000);
</script>

<script>
    function toggleBox(element, type) {
        const parent = element.closest('.row');
        const boxClass = type === 'hint' ? 'hint_tbox' : (type === 'exp' ? 'exp_tbox' : 'case_tbox');
        const box = parent.querySelector(`.${boxClass}`);
        if(box) box.style.display = box.style.display === 'none' ? 'block' : 'none';
    }
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Laravel data
    const examDuration = {{ $exam->duration }} * 60;
    const examId = {{ $exam->sno }};
    const userId = {{ $user_details->sno }};
    const Process = $('#examProcess_sno').val() || 0;

    // Define keys
    const startTimeKey = `exam_start_time_${userId}_${examId}`;
    const userKey = `exam_user_id_${examId}`;
    const questionIndexKey = `exam_question_index_${userId}_${examId}`;
    const processKey = `exam_process_id_${userId}_${examId}`;
    const examIdKey = `exam_id_${userId}`;

    // Save info to localStorage
    localStorage.setItem(userKey, userId);
    localStorage.setItem(examIdKey, examId);
    localStorage.setItem(processKey, Process);

    const csrfToken = $('meta[name="csrf-token"]').attr('content');

    function clearExamLocalStorage() {
        // 🔥 Remove all possible exam-related localStorage keys for this user
        Object.keys(localStorage).forEach(key => {
            if (key.includes(`exam_`) || key.includes(`question_index_`)) {
                localStorage.removeItem(key);
            }
        });
        console.log('✅ Cleared all exam localStorage keys');
    }

    function startTimer(duration, display) {
        let timer = duration, hours, minutes, seconds;

        const interval = setInterval(function () {
            hours = Math.floor(timer / 3600);
            minutes = Math.floor((timer % 3600) / 60);
            seconds = timer % 60;

            // Format time
            hours = hours < 10 ? "0" + hours : hours;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            display.textContent = `${hours}:${minutes}:${seconds}`;
            var dis_timer = `${hours}:${minutes}:${seconds}`;
            if (--timer < 0) {
                clearInterval(interval);
                handleExamCompletion(display);
                var dis_timer = `0:0:0`;
            }
            const Processids = $('#examProcess_sno').val() || 0;
            $.post('/exam-time-save', {
                exam_id: examId,
                user_id: userId,
                process_id: Processids,
                balance_time: `${hours}:${minutes}:${seconds}`,
                _token: csrfToken
            });
        }, 1000);
    }

    function handleExamCompletion(display) {
        display.textContent = "Time's up!";
        display.classList.add('animation-blink');

        clearExamLocalStorage();

        const id = $('#exam_sno').val();
        if (!id) return;

        // Save timeout
        $.post('/time-out', {
            exam_id: examId,
            user_id: userId,
            process_id: id,
            _token: csrfToken
        });

        // Redirect to result page
        $.post('/ids/encrypt', { values: id, _token: csrfToken })
            .done(function(encrypted_id) {
                if (encrypted_id) {
                    window.open('/exam-result/' + encrypted_id, '_blank');
                    location.reload();
                    exam_close();
                }
            });
    }

    // 🕒 Timer setup
    const display = document.querySelector('#time');
    let startTime = localStorage.getItem(startTimeKey);
    const process_status = $('#examProcesssts').val();

    if (!startTime) {
        startTime = Date.now();
        localStorage.setItem(startTimeKey, startTime);
    }

    const elapsedSeconds = Math.floor((Date.now() - parseInt(startTime)) / 1000);
    const remainingTime = examDuration - elapsedSeconds;

    if (remainingTime > 0 && process_status !== '2') {
        startTimer(remainingTime, display);
    } else {
        handleExamCompletion(display);
    }

    // ✅ Final manual submission
    window.openExamResultAndReload = function() {
        const id = $('#exam_sno').val();
        const examProcess_sno = $('#examProcess_sno').val() || 0;
        if (!id) {
            alert('Exam ID is missing!');
            return;
        }

        // Save timeout
        $.post('/time-out', {
            exam_id: examId,
            user_id: userId,
            process_id: examProcess_sno,
            _token: csrfToken
        }).always(() => {
            // Redirect to result
            // return;
            $.post('/ids/encrypt', { values: id, _token: csrfToken })
                .done(function(encrypted_id) {
                    
                    if (encrypted_id) {
                        clearExamLocalStorage(); // 🧹 clear all localStorage
                        const newTab = window.open('/exam-result/' + encrypted_id, '_blank');
                        if (!newTab) console.warn('Popup blocked');
                        location.reload();
                        exam_close();
                    }
                })
                .fail(() => console.error('Failed to encrypt exam ID.'));
        });
    };
});
</script>


<script>
     // Disable right-click context menu
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  // Disable copy, cut, paste
  document.addEventListener('copy', function(e) {
    e.preventDefault();
  });
  document.addEventListener('cut', function(e) {
    e.preventDefault();
  });
  document.addEventListener('paste', function(e) {
    e.preventDefault();
  });

  // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U (view source), Ctrl+S (save)
  document.addEventListener('keydown', function(e) {
    // F12 key
    if (e.key === "F12") {
      e.preventDefault();
    }
    // Ctrl+Shift+I or Cmd+Option+I (DevTools)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'i') {
      e.preventDefault();
    }
    // Ctrl+Shift+J or Cmd+Option+J (Console)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'j') {
      e.preventDefault();
    }
    // Ctrl+U or Cmd+U (View source)
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'u') {
      e.preventDefault();
    }
    // Ctrl+S or Cmd+S (Save page)
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
    }
  });

  // Optional: Detect if DevTools is open (not 100% reliable)
  let devtoolsOpen = false;
  setInterval(() => {
    const threshold = 160;
    const widthThreshold = window.outerWidth - window.innerWidth > threshold;
    const heightThreshold = window.outerHeight - window.innerHeight > threshold;
    if (widthThreshold || heightThreshold) {
      if (!devtoolsOpen) {
        alert("Developer tools are disabled on this site.");
      }
      devtoolsOpen = true;
    } else {
      devtoolsOpen = false;
    }
  }, 1000);
  
  (function() {
  const threshold = 160;  // threshold for detection (can adjust)

  function detectDevTools() {
    const widthThreshold = window.outerWidth - window.innerWidth > threshold;
    const heightThreshold = window.outerHeight - window.innerHeight > threshold;
    return widthThreshold || heightThreshold;
  }

  function handleDevTools() {
    if (detectDevTools()) {
      alert("Developer tools detected! Access to this page is restricted.");
      // Clear page content
      location.reload();
      // Or redirect to another page, e.g.,
      // window.location.href = "about:blank";
    }
  }

  // Run check every 1 second (you can adjust timing)
  setInterval(handleDevTools, 1000);
})();
</script>




@endsection