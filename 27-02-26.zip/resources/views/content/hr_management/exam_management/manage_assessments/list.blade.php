@extends('layouts/layoutMaster')

@section('title', 'Manage Assessments')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp

<style>
    .exam-card {
        transition: all 0.3s ease;
        border-left: 4px solid #4e73df !important;
    }
    
    .exam-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1) !important;
    }
    
    .exam-title {
        color: #2e3a59;
        font-weight: 600;
        line-height: 1.3;
    }
    
    .stat-item {
        transition: all 0.2s ease;
        border: 1px solid transparent;
    }
    
    .stat-item:hover {
        background-color: rgba(78, 115, 223, 0.05);
        border-color: rgba(78, 115, 223, 0.2);
    }
    
    .exam-dates .vr {
        height: 16px;
        opacity: 0.3;
    }
    
    .attempt-progress .progress {
        border-radius: 10px;
    }
    
    .btn {
        border-radius: 6px;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    
    .x-small {
        font-size: 0.7rem;
    }
    
    .badge-container {
        text-align: center;
        padding: 1rem;
    }
    
    .badge-image {
        width: 75px;
        height: 75px;
        object-fit: contain;
        margin-bottom: 0.5rem;
    }
    
    .badge-name {
        display: block;
        font-weight: 500;
        margin-bottom: 0.25rem;
    }
    
    .badge-category {
        display: block;
        font-size: 0.8rem;
    }
    
    .exam-status-badge {
        font-size: 0.75rem;
        padding: 0.35em 0.65em;
    }
    
    @media (max-width: 992px) {
        .border-end-lg {
            border-right: none !important;
            border-bottom: 1px solid #e3e6f0;
            padding-bottom: 1rem;
            margin-bottom: 1rem;
        }
        
        .ps-lg-4 {
            padding-left: 0 !important;
        }
    }
    
    .progress {
        height: 6px;
    }
    
    .exam-meta-item {
        display: flex;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    
    .exam-meta-item i {
        margin-right: 0.5rem;
        width: 16px;
    }
    
    .status-pass {
        background-color: #d4edda;
        color: #28a745;
        border: 1px solid #28a745;
        border-radius: 4px;
        padding: 5px;
    }
    
    .status-fail {
        background-color: #f8d7da;
        color: #dc3545;
        border: 1px solid #dc3545;
        border-radius: 4px;
        padding: 5px;
    }
    
    .status-schedule {
        background-color: #cce5ff;
        color: #007bff;
        border: 1px solid #007bff;
        border-radius: 4px;
        padding: 5px;
    }
    
    .status-not-started {
        background-color: #e2e3e5;
        color: #6c757d;
        border: 1px solid #6c757d;
        border-radius: 4px;
        padding: 5px;
    }
    
    .status-in-progress {
        background-color: #fff3cd;
        color: #fd7e14;
        border: 1px solid #fd7e14;
        border-radius: 4px;
        padding: 5px;
    }
    
    .status-expired {
        background-color: #d6d8db;
        color: #343a40;
        border: 1px solid #343a40;
        border-radius: 4px;
        padding: 5px;
    }
    
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Assessments</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Assessment Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    
    <div class="card-body">
        <!-- Filters Section -->
        <div class="row mb-4">
            @php $perpage_count = $perpage ? $perpage : 10; @endphp
            <div class="col-lg-2">
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                    @php
                    $options = [10, 25, 100, 500];
                    @endphp
                    @foreach ($options as $option)
                    <option value="{{ $option }}" {{ $perpage_count == $option ? 'selected' : '' }}>
                        {{ $option }}
                    </option>
                    @endforeach
                </select>
            </div>
            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                <form id="search_form" method="POST" action="/manage-assessments">
                    @csrf
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div>
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="0">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ? $perpage : 10 }}" />
                            <input type="text" class="form-control" id="search_fill" name="search_fill" value="{{ $search_fill ?? '' }}" placeholder="Enter Search" />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Assessments List -->
        @if(!isset($lists) || count($lists) === 0)
            <div class="text-center py-5">
                <i class="mdi mdi-clipboard-text-off-outline fs-1 text-muted"></i>
                <h5 class="mt-3 text-muted">No assessments at the moment</h5>
                <p class="text-muted">Check back later for new assessments or contact your administrator.</p>
            </div>
        @endif
        
       @foreach($lists as $list)
        <div class="col-lg-12 mb-4">
            <div class="card exam-card h-100 border-0 rounded-lg shadow-sm">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <!-- Left Section -->
                        <div class="col-lg-5 col-xl-7 border-end-lg pe-lg-4 mb-3 mb-lg-0">

                            @php
                                $staff_id = auth()->user()->user_id;
                                $new_limit = $helper->get_new_exam_limits($list->sno,$staff_id);
                                if($new_limit){
                                    $list->attempts = $new_limit;
                                }
                            @endphp
        
                            @php
                                // Start and end date calculation
                                $startDateObj = new DateTime($user_details->date_of_joining);
                                $sch_duration = $list->sch_duration;
                                $unit = strtolower(trim($list->unit));
        
                                switch($unit) {
                                    case 'day': case 'days':
                                        $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}D"));
                                        break;
                                    case 'month': case 'months':
                                        $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}M"));
                                        break;
                                    case 'year': case 'years':
                                        $endDateObj = (clone $startDateObj)->add(new DateInterval("P{$sch_duration}Y"));
                                        break;
                                    default:
                                        $endDateObj = clone $startDateObj;
                                        break;
                                }
        
                                $startdate = $startDateObj->format('d-M-Y');
                                $enddate = $endDateObj->format('d-M-Y');
                                $currentdate = new DateTime();
        
                                $Process_status = $list->last_process_data->status ?? 0;
                                $Process_pass_fail = $list->last_process_data->pass_fail ?? 0;
        
                                // Decode exam answers
                                $answers = !empty($list->last_process_data->exam_question_answers_datas) 
                                    ? json_decode($list->last_process_data->exam_question_answers_datas, true)
                                    : [];
        
                                // Marks calculation
                                $positiveMarks  = $list->positive_mark;
                                $negativeMarks  = $list->negative_mark;
                                $totalQuestions = $list->question_count;
                                $correctCount   = collect($answers)->where('correctness', 'correct')->count();
                                $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();
        
                                $marksScored = max(0, ($positiveMarks * $correctCount) - ($negativeMarks * $incorrectCount));
                                $totalMarks = $positiveMarks * $totalQuestions;
                                $marksPercentage = $totalMarks > 0 ? min(100, ($marksScored / $totalMarks) * 100) : 0;
                                $isPassed = $marksScored >= $list->pass_mark;
        
                                // Time calculation (balance stored in DB)
                                $totalDurationInSeconds = ($list->duration ?? 0) * 60;
                                $balanceDuration = $list->last_process_data->total_attended_duration ?? '0:0:0';
                                [$h, $m, $s] = array_map('intval', explode(':', $balanceDuration));
                                $balanceSeconds = ($h*3600)+($m*60)+$s;
                                $balanceSeconds = min($balanceSeconds, $totalDurationInSeconds);
                                $usedSeconds = max(0, $totalDurationInSeconds - $balanceSeconds);
                                $usedMinutes = floor($usedSeconds/60);
                                $usedRemainSeconds = $usedSeconds % 60;
                                $usedTime = sprintf("%d Mins %d Sec", $usedMinutes, $usedRemainSeconds);
                                $timePercentage = $totalDurationInSeconds > 0 ? min(100, ($usedSeconds/$totalDurationInSeconds)*100) : 0;
                                
                                // Completed Date
                                $CompletedDate = !empty($list->last_process_data->completed_date) 
                                                ? new DateTime($list->last_process_data->completed_date) 
                                                : '';
                                                
                                // Schedule / expiry check
                                $scheduleDate = !empty($list->last_process_data->next_schedule) 
                                                ? new DateTime($list->last_process_data->next_schedule) 
                                                : null;
                                                
                                $isExpired = $scheduleDate ? $currentdate > $scheduleDate : false;
        
                                $hasSchedule = $list->schedule_id != 0;
                                $limitReached = ($list->exam_attempt == 1 && ($list->attempted_count ?? 0) >= ($list->attempts ?? 0));
                                
                                $currentDateStr = (new DateTime())->format('Y-m-d');
                                $scheduleDateStr = !empty($list->last_process_data->next_schedule) 
                                                    ? (new DateTime($list->last_process_data->next_schedule))->format('Y-m-d') 
                                                    : null;
                            
                                $isExpired = $scheduleDateStr && $currentDateStr > $scheduleDateStr;
                                $isToday = $scheduleDateStr && $currentDateStr == $scheduleDateStr;
                            @endphp
        
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h4 class="exam-title mb-1 text-truncate" title="{{ $list->exam_name ?? 'Untitled' }}">
                                    {{ $list->exam_name ?? 'Untitled Assessment' }}
                                </h4>
        
                                <!-- Status Badge -->
                                <div>
                                    @if($Process_status == 1)
                                        <span class="status-in-progress">In Progress</span>
                                    @elseif($isPassed)
                                        <span class="status-pass">Pass</span>
                                    @elseif($isExpired)
                                        <span class="status-expired">Expired</span>
                                    @elseif(!empty($scheduleDate) && $currentdate < $scheduleDate)
                                        <span class="status-schedule">Scheduled</span>
                                    @else
                                         @if($list->last_process_data)
                                         <span class="status-fail">Fail</span>
                                         @else
                                         <span class="status-not-started">Not Started</span>
                                         @endif
                                    @endif
                                    
                                    
                                </div>
                                
                            </div>
                            @if($list->last_process_data)
                            <!-- Time Used Progress -->
                            <div class="mb-2">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted small">Time Used</span>
                                    <span class="small fw-medium">{{ $usedTime }} / {{ $list->duration }} Mins</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-info" style="width: {{ $timePercentage }}%"></div>
                                    <div class="progress-bar bg-light" style="width: {{ 100-$timePercentage }}%"></div>
                                </div>
                                <span class="fs-7 fw-bold">{{ round($timePercentage) }}%</span>
                            </div>
        
                            <!-- Score Progress -->
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted small">Score</span>
                                    <span class="small fw-medium">{{ $marksScored }} / {{ $totalMarks }}</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar {{ $marksPercentage >= 100 ? 'bg-success' : 'bg-warning' }}" 
                                         style="width: {{ $marksPercentage }}%"></div>
                                </div>
                                <span class="fs-7 fw-bold">{{ round($marksPercentage) }}%</span>
                            </div>
                            @else
                            <!-- Time Used Progress -->
                            <div class="mb-2">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted small">Time Used</span>
                                    <span class="small fw-medium">- / {{ $list->duration }} Mins</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" style="background-color:#c7b3f2; width: {{ 100 }}%"></div>
                                    <div class="progress-bar bg-light" style="width: {{ 100-100 }}%"></div>
                                </div>
                                <span class="fs-7 fw-bold">{{ round(100) }}%</span>
                            </div>
        
                            <!-- Score Progress -->
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted small">Score</span>
                                    <span class="small fw-medium">- / {{ $totalMarks }}</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar " style="background-color:#d1fde5; width: {{ 100 }}%"></div>
                                </div>
                                <span class="fs-7 fw-bold">{{ round(100) }}%</span>
                            </div>
                            @endif
                            <!-- Dates -->
                            <div class="d-flex justify-content-between gap-2">
                            @if($hasSchedule)
                                <div class="d-flex gap-3">
                                    <i class="mdi mdi-calendar-start text-primary"></i>
                                    <span class="text-muted small">Starts: {{ $startdate }}</span>
                                    <div class="vr"></div>
                                    <i class="mdi mdi-calendar-end text-danger"></i>
                                    <span class="text-muted small">Ends: {{ $enddate }}</span>
                                </div>
                            @elseif(!empty($scheduleDate))
                                <div class="text-muted small"><i class="mdi mdi-calendar text-warning "></i> Scheduled: {{ $scheduleDate->format('d-M-Y') }}</div>
                            @else
                            
                                <div class="text-muted small"><i class="mdi mdi-calendar-start text-success "></i> Any Time</div>
                                
                            @endif
                            @if($CompletedDate)
                                <div class="text-dark fs-7 fw-bold"> Completed Date & Time: {{ $CompletedDate  ? $CompletedDate->format('d-M-Y - h:i A') : '' }}</div>
                            @endif
                            </div>
                        </div>
        
                        <!-- Badge Section -->
                        <div class="col-lg-3 col-xl-2 border-end-lg pe-lg-4 mb-3 mb-lg-0 text-center">
                            @if($list->exam_attempt == 1)
                                <img src="{{ $list->badge_check == 1 
                                    ? asset('exam/badges/' . $list->badge_image) 
                                    : asset('assets/egc_images/Badge-Awaited.png') }}" 
                                    alt="badge" class="badge-image" />
                                <div class="badge-name">{{ $list->badge_name ?? 'No Badge' }}</div>
                                <div class="badge-category text-muted">{{ $list->badge_cat ?? '' }}</div>
                            @else
                                <img src="{{ asset('assets/egc_images/No-Badges.png') }}" 
                                    alt="badge" class="badge-image" />
                                <div class="badge-name">{{ 'No Badge' }}</div>
                            @endif
                        </div>
        
                        <!-- Right Section: Stats + Action -->
                        <div class="col-lg-4 col-xl-3 ps-lg-4">
                            <div class="exam-stats mb-3 row g-2 text-center">
                                <div class="col-4">
                                    <i class="mdi mdi-chat-question-outline fs-4 text-primary mb-1"></i>
                                    <div class="fw-semibold small">{{ count(json_decode($list->question_ids ?? '[]')) }}</div>
                                    <div class="text-muted x-small">Questions</div>
                                </div>
                                <div class="col-4">
                                    <i class="mdi mdi-timer-outline fs-4 text-info mb-1"></i>
                                    <div class="fw-semibold small">{{ $list->duration }}</div>
                                    <div class="text-muted x-small">Minutes</div>
                                </div>
                                <div class="col-4">
                                    @if($list->exam_attempt == 1)
                                        <i class="mdi mdi-sync fs-4 text-warning mb-1"></i>
                                        <div class="fw-semibold small">{{ $list->attempted_count ?? 0 }}/{{ $list->attempts ?? 0 }}</div>
                                        <div class="text-muted x-small">Attempts</div>
                                    @else
                                        <i class="mdi mdi-infinity fs-4 text-success mb-1"></i>
                                        <div class="fw-semibold small">∞</div>
                                        <div class="text-muted x-small">Trail</div>
                                    @endif
                                </div>
                            </div>

                            
        
                            @php
                                $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                                $view_url = url('/exam-result/' . $encryptedValue);
                                // $enc_id = $list->sno .'~'. auth()->user()->user_id .'~'.$list->last_process_data->sno;
                                // $encryptedValue2 = $helper->encrypt_decrypt($enc_id,'encrypt');
                                // $cert_url = url('/assesment_certificate_download/' . $encryptedValue2);
                                $currentDateStr = (new DateTime())->format('Y-m-d');
                                // Next schedule date
                                $nextScheduleStr = !empty($list->last_process_data->next_schedule) 
                                                    ? (new DateTime($list->last_process_data->next_schedule))->format('Y-m-d') 
                                                    : null;
                            
                                // End date only if schedule_id != 0
                                $endDateStr = ($list->schedule_id != 0) ? (new DateTime($enddate))->format('Y-m-d') : null;
                            
                                // Status checks
                                $isToday = ($nextScheduleStr && $currentDateStr == $nextScheduleStr) 
                                           || ($endDateStr && $currentDateStr <= $endDateStr && !$nextScheduleStr);
                            
                                $isExpired = ($nextScheduleStr && $currentDateStr > $nextScheduleStr) 
                                             || ($endDateStr && $currentDateStr > $endDateStr);
                            
                                $limitReached = ($list->exam_attempt == 1 && ($list->attempted_count ?? 0) >= ($list->attempts ?? 0));
                            @endphp
        
        
                            
                            @php
                                $questionCount = count(json_decode($list->question_ids ?? '[]'));
                            @endphp
                            
                            @if($isPassed)
                                @if($list->exam_attempt == 0)
                                    @if($Process_status == 1)
                                        <button class="btn btn-danger w-100" disabled>
                                            <i class="mdi mdi-clock-alert-outline me-2"></i>Assessment In Progress
                                        </button>
                                    @else
                                        <button class="btn btn-success w-100 mb-2" 
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_start_exam"
                                                onclick="ExamGuide('{{ $list->sno }}','{{ $list->exam_name }}','{{ $questionCount }}','{{ $list->duration }}')">
                                            <i class="mdi mdi-image-edit-outline me-2"></i>Trial Assessment
                                        </button>
                                    @endif
                                    <a href="javascript:;" class="btn btn-primary w-100 btn-history" 
                                       data-id="{{ $list->sno }}" data-bs-toggle="modal" data-bs-target="#kt_modal_view_history" 
                                       onclick="examLog('{{ $list->sno }}')">
                                      <i class="mdi mdi-history me-2"></i>View History
                                    </a>
                                @elseif($list->exam_attempt == 1)
                                    <a href="{{ $view_url }}" class="btn btn-primary w-100">
                                        <i class="mdi mdi-eye-check-outline me-2"></i>View Result
                                    </a>
                                    @if($isPassed)
                                    @php
                                    $enc_id = $list->sno .'~'. auth()->user()->user_id .'~'.$list->last_process_data->sno;
                                    $encryptedValue2 = $helper->encrypt_decrypt($enc_id,'encrypt');
                                    // $cert_url = url('/assesment_certificate_download/' . $encryptedValue2);
                                    @endphp
                                        <a href="javascript:;" class="btn btn-success w-100 mt-2" data-bs-toggle="modal" data-bs-target="#kt_modal_preview_certificate" onclick="viewPreviewModel('{{ $encryptedValue2 }}')">
                                            <i class="mdi mdi-certificate-outline me-2"></i> Preview Certificate
                                        </a>
                                    @endif
                                @endif
                            @elseif($limitReached)
                                <div class="d-grid gap-2">
                                    @if($Process_status == 1)
                                        <button class="btn btn-danger w-100" disabled>
                                            <i class="mdi mdi-clock-alert-outline me-2"></i>Assessment In Progress
                                        </button>
                                    @else
                                        <button class="btn btn-danger w-100">
                                            <i class="fas fa-thumbs-down error-icon me-2"></i>Failed
                                        </button>
                                        @if($list->exam_attempt == 0)
                                            <a href="javascript:;" class="btn btn-primary w-100 btn-history" 
                                               data-id="{{ $list->sno }}" data-bs-toggle="modal" data-bs-target="#kt_modal_view_history" 
                                               onclick="examLog('{{ $list->sno }}')">
                                              <i class="mdi mdi-history me-2"></i>View History
                                            </a>
                                        @endif
                                    @endif
                                </div>
                            @elseif($isToday)
                                <button class="btn btn-success w-100" 
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_start_exam"
                                        onclick="ExamGuide('{{ $list->sno }}','{{ $list->exam_name }}','{{ $questionCount }}','{{ $list->duration }}')">
                                    <i class="mdi mdi-image-edit-outline me-2"></i>Start Assessment
                                </button>
                            @elseif(!$isToday && !$isExpired && ($nextScheduleStr || $endDateStr))
                                <button class="btn btn-info w-100" disabled>
                                    <i class="mdi mdi-calendar me-2"></i>Assessment Scheduled
                                </button>
                            @elseif($isExpired)
                                <button class="btn btn-danger w-100" disabled>
                                    <i class="mdi mdi-clock-alert-outline me-2"></i>Assessment Expired
                                </button>
                            @elseif($Process_status == 1)
                                <button class="btn btn-danger w-100" disabled>
                                    <i class="mdi mdi-clock-alert-outline me-2"></i>Assessment In Progress
                                </button>
                            @else
                                {{-- Anytime / No schedule --}}
                                @if($list->last_process_data)
                                    @if($list->exam_attempt == 0)
                                        <button class="btn btn-success w-100" 
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_start_exam"
                                                onclick="ExamGuide('{{ $list->sno }}','{{ $list->exam_name }}','{{ $questionCount }}','{{ $list->duration }}')">
                                            <i class="mdi mdi-image-edit-outline me-2"></i>Trial Assessment
                                        </button>
                                        @if($list->exam_attempt == 0)
                                            <a href="javascript:;" class="btn btn-primary w-100 btn-history mt-2" 
                                               data-id="{{ $list->sno }}" data-bs-toggle="modal" data-bs-target="#kt_modal_view_history" 
                                               onclick="examLog('{{ $list->sno }}')">
                                              <i class="mdi mdi-history me-2"></i>View History
                                            </a>
                                        @endif
                                    @else
                                        <button class="btn btn-warning w-100" 
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_start_exam"
                                                onclick="ExamGuide('{{ $list->sno }}','{{ $list->exam_name }}','{{ $questionCount }}','{{ $list->duration }}')">
                                            <i class="mdi mdi-image-edit-outline me-2"></i>Re-Taken Assessment
                                        </button>
                                    @endif
                                @else
                                    <button class="btn btn-success w-100" 
                                            data-bs-toggle="modal" data-bs-target="#kt_modal_start_exam"
                                            onclick="ExamGuide('{{ $list->sno }}','{{ $list->exam_name }}','{{ $questionCount }}','{{ $list->duration }}')">
                                        <i class="mdi mdi-image-edit-outline me-2"></i>Start Assessment
                                    </button>
                                @endif
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach


        
        <!-- Pagination -->
        @if(isset($lists) && count($lists) > 0)
        <div class="mt-4">
            {{ $lists->appends(request()->except(['page', '_token']))->links() }}
        </div>
        @endif
    </div>
</div>

<!-- Start Exam Modal -->
<div class="modal fade" id="kt_modal_start_exam" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header border-bottom">
                <div>
                    <h4 class="modal-title fw-bold" id="exampleModalLabel">Welcome
                        <span class="text-primary fw-bold">{{$user_details->staff_name ?? ''}}</span>
                    </h4>
                    <div class="d-block text-dark fw-semibold fs-6 " id="exam_name">-</div>
                </div>
                <div>
                    <div class="justify-content-start">
                        <label class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total No of Questions">
                            <i class="mdi mdi-counter fs-4 text-black"></i>
                        </label>
                        <label class="fs-7 align-items-center text-black fw-semibold badge px-1 py-1 border border-red bg-label-danger border border-danger rounded">
                            <span class="" id="qus_count">0</span>
                        </label>
                    </div>
                    <div class="justify-content-start">
                        <label class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Allocated Hours">
                            <i class="mdi mdi-clipboard-clock-outline fs-4 text-black"></i>
                        </label>
                        <label class="fs-6 align-items-center text-black fw-semibold">
                            <span class="" id="qus_dur">0 </span>Mins
                        </label>
                    </div>
                </div>
            </div>
            <input type="hidden" id="exam_id" >
            <div class="modal-body pt-4 pb-10 px-10 px-xl-20">
                <h4 class="mb-4 text-center fw-bold text-info"><u>Assessments Writing Protocols</u></h4>
                <div class="mb-8 scroll-y max-h-500px px-3 py-1 mb-4">
                    {!! $guide_line->exam_guidelines ?? '-' !!}
                </div>

                <div class="d-flex justify-content-center align-items-center mt-6">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="reset" class="btn btn-primary" onclick="StartExam()">Start Assessment</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - View History-->
<div class="modal fade" id="kt_modal_view_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black fw-bold">
                        <label>
                            <span class="mb-2 fs-2 fw-semibold d-block">Exam Log</span>
                            <span class="bg-danger text-white fw-bold fs-5 px-2 py-1 mt-4"
                                id="exam_log_exam_name">-</span>
                        </label>
                    </h3>
                </div>

                <div class="row mx-3">
                    <div class="col-lg-12">
                        <div class="table-responsive shadow-sm">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
                                <thead>
                                    <tr class="text-start align-middle fw-bold fs-6 bg-primary text-white">
                                        <th class="min-w-50px px-3 py-2">sno</th>
                                        <th class="min-w-125px px-3 py-2">Staff Name</th>
                                        <th class="min-w-80px px-3 py-2">Start Time</th>
                                        <th class="min-w-80px px-3 py-2">End Time</th>
                                        <th class="min-w-80px px-3 py-2">Duration</th>
                                        <th class="min-w-80px px-3 py-2">Total Marks</th>
                                        <th class="min-w-80px px-3 py-2">Scored Marks</th>
                                        <th class="min-w-80px px-3 py-2">Result</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-700 fw-semibold fs-7" id="exam_log_container">
                                    <!-- AJAX WILL POPULATE HERE -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View History-->


<!--begin::Modal - Payment Confirmation-->
<div class="modal fade" id="kt_modal_preview_certificate" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!-- begin::Modal dialog -->
  <div class="modal-dialog  modal-xl">
    <!-- begin::Modal content -->
    <div class="modal-content rounded">
        <div class="modal-header justify-content-end border-0 pb-0">
            {{-- <div class="d-flex justify-content-end align-items-center pt-0">
                <button type="button" class="btn btn-primary me-3" onclick="SendCertificate()">Send Certificate My WhatsApp<i class="mdi mdi-whatsapp ms-2"></i></button>
            </div> --}}
            <!-- HTML: wrapper with button + hidden loader -->
            <div class="d-flex justify-content-end align-items-center pt-0">
              <div id="btnWrapper" style="position:relative; display:inline-block;">
                <button id="sendBtn" type="button" class="btn btn-primary me-3" onclick="SendCertificate()">
                  Send Certificate My WhatsApp <i class="mdi mdi-whatsapp ms-2"></i>
                </button>

                <!-- loader box hidden initially — will be sized to match button -->
                <div id="btnLoaderBox" style="display:none; position:absolute; top:0; left:0;">
                  <div id="btnLoaderInner" style="
                        width:100%; height:100%; border-radius:6px; overflow:hidden;
                        border:2px solid #128C7E; background:#fff; position:relative;">

                      <div id="btnWaterFill" style="
                          width:0%; height:100%;
                          background: linear-gradient(120deg, #25D366, #128C7E);
                          transition: width .35s ease-in-out;">
                      </div>

                      <span id="btnLoaderLabel" style="
                          position:absolute;
                          top:50%; left:50%;
                          transform:translate(-50%, -50%);
                          font-size:13px; font-weight:600;
                          color:#065c3d;
                          display:flex;
                          align-items:center;
                          gap:6px;">
                          Sending... <i class="mdi mdi-whatsapp" style="font-size:18px; color:#25D366;"></i>
                      </span>
                  </div>
                </div>

              </div>
            </div>
           <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
        
        <div class="modal-body " style="display:flex;  justify-content:center;">
          
        </div>
        <input type="hidden" class="process_id_preview" id="process_id_preview_confirm" value="">
      
    </div>
    <!-- end::Modal content -->
  </div>
  <!-- end::Modal dialog -->
</div>
<!--end::Modal - Payment Confirmation-->



<!-- Toastr -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    .toast {
        background-color: #39484f;
    }
    .toast-success {
        background-color: green;
    }
    .toast-error {
        background-color: red;
    }

    /* optional: small visual polish */
    #btnWrapper { line-height: 1; }
    /* make sure icons don't shift */
    #sendBtn i { vertical-align: middle; }
</style>
<script>
    function viewPreviewModel(sno) {
        $('.process_id_preview').val(sno);  // sets hidden input
        const modalBody = $('#kt_modal_preview_certificate .modal-body');
        modalBody.html('<div class="text-center p-5">Loading preview...</div>');
    
        $.ajax({
            url: '/assesment_certificate_preview/' + sno,
            type: 'GET',
            success: function (response) {
                modalBody.html(response); // Replace modal body with the preview HTML
            },
            error: function (xhr) {
                modalBody.html('<div class="text-danger text-center">Failed to load preview. Please try again later.</div>');
            }
        });
    }
    // function SendCertificate() {
    //     var encid = $('#process_id_preview_confirm').val(); 
    //     if(encid != ''){    
    //         $.ajax({
    //             url: '/staff_certificate_send/' + encid,
    //             type: 'GET',
    //             success: function (response) {
    //                console.log(response)
    //             },
    //             error: function (xhr) {
    //                 console.error(xhr)
    //             }
    //         });
    //     }
    // }
     // JS (requires jQuery)
function showBtnLoader() {
  const $btn = $("#sendBtn");
  const $loaderBox = $("#btnLoaderBox");

  // measure button (including margins/paddings) and apply to loader wrapper
  const btnWidth = $btn.outerWidth();
  const btnHeight = $btn.outerHeight();

  $loaderBox.css({
    width: btnWidth + "px",
    height: btnHeight + "px",
    display: "block"
  });

  // hide original button (keeps space because loader is absolute inside wrapper)
  $btn.hide();

  // start water fill animation (reset first)
  $("#btnWaterFill").css("width", "0%");
  // gradually fill to 90% (AJAX will complete to 100% on success)
  setTimeout(() => $("#btnWaterFill").css("width", "20%"), 50);
  setTimeout(() => $("#btnWaterFill").css("width", "45%"), 350);
  setTimeout(() => $("#btnWaterFill").css("width", "70%"), 800);
  setTimeout(() => $("#btnWaterFill").css("width", "90%"), 1600);
}

function hideBtnLoader(success = true) {
  // complete fill if success, then restore button
  if (success) {
    $("#btnWaterFill").css("width", "100%");
    setTimeout(() => {
      $("#btnLoaderBox").hide();
      $("#btnWaterFill").css("width", "0%");
      $("#sendBtn").show();
    }, 350); // allow final fill animation to be seen
  } else {
    // quickly hide and show button back
    $("#btnLoaderBox").hide();
    $("#btnWaterFill").css("width", "0%");
    $("#sendBtn").show();
  }
}

function SendCertificate() {
  var encid = $('#process_id_preview_confirm').val();

  if (!encid) {
    toastr.error("Missing process id.");
    return;
  }

  // replace button with loader
  showBtnLoader();

  // optional: disable repeated clicks while request pending
  $("#sendBtn").prop("disabled", true);

  $.ajax({
    url: '/staff_certificate_send/' + encid,
    type: 'GET',
    success: function (response) {
      console.log(response);

      // optional: show success toast
      toastr.success("Certificate sent!");
      setTimeout(() => {
          $('#kt_modal_preview_certificate').modal('hide');
      }, 600);
      // close modal (if needed)


      // hide loader and restore button
      hideBtnLoader(true);

      // re-enable button
      $("#sendBtn").prop("disabled", false);
    },
    error: function (xhr) {
      console.error(xhr);
      toastr.error("Failed to send certificate!");

      // hide loader, restore button
      hideBtnLoader(false);
      $("#sendBtn").prop("disabled", false);
    }
  });
}

    
</script>

<!-- EXAM LOG -->
<script>
    function examLog(id) {
        $.ajax({
            url: `/exam_log/${id}`,
            method: 'GET',
            success: function (response) {
                if(response.data.length > 0) {
                    const exams = response.data;
                    const examLogContainer = $('#exam_log_container');
                    let html = '';
                    examLogContainer.empty();

                    $('#exam_log_exam_name').html(response.exam_name);

                    exams.forEach((exam, index) => {
                        if(exam.isPassed){
                            var pass_fail = `<span class="bg-success text-black px-2 py-1 fs-6 rounded fw-semibold">Pass</span>`;
                        }else{
                            var pass_fail = `<span class="bg-danger text-black px-2 py-1 fs-6 rounded fw-semibold">Fail</span>`;
                        }
                        html += ` <tr class="align-middle bg-white rounded-3 my-2" style="box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
                            <td class="px-4 py-3 text-center fw-semibold text-primary border-0">${index + 1}</td>
                            <td class="px-4 py-3 fw-bold text-dark border-0">${exam.staff_name}</td>
                            <td class="px-4 py-3 text-secondary border-0">${formatDateTime(exam.created_at)}</td>
                            <td class="px-4 py-3 text-secondary border-0">${formatDateTime(exam.completed_date)}</td>
                            <td class="px-4 py-3 text-center text-dark fw-medium border-0">${exam.total_attended_duration}</td>
                            <td class="px-3 py-2 text-center border-0">
                                <div class="score-card bg-info bg-opacity-10 border border-info rounded px-2 py-1">
                                    <div class="fw-bold text-info fs-5">${exam.total_marks}</div>
                                </div>
                            </td>
                            <td class="px-3 py-2 text-center border-0">
                                <div class="score-card bg-success bg-opacity-10 border border-success rounded px-2 py-1">
                                    <div class="fw-bold text-success fs-5">${exam.staff_marks}</div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-center border-0">
                                ${pass_fail}
                            </td>
                        </tr>`;
                    });
                    examLogContainer.html(html);
                }
            },
            error: function (err) {
                console.error('Error Fetching Data Due To : ' + err);
            }
        })
    }

    function formatDateTime(datetimeStr) {
        const months = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
        const dateObj = new Date(datetimeStr);

        const day = String(dateObj.getDate()).padStart(2, '0');
        const month = months[dateObj.getMonth()];
        const year = dateObj.getFullYear();

        let hours = dateObj.getHours();
        const minutes = String(dateObj.getMinutes()).padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12 || 12; // convert 0 to 12 for 12AM

        return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
    }
</script>

 
<script>
    // Display Toastr messages
    @if (Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
    @endif
    
    function ExamGuide(id,name,count,dur){
        $('#exam_name').html(name);
        $('#qus_count').html(count);
        $('#qus_dur').html(dur);
        $('#exam_id').val(id);
    }
    
    function StartExam(){
        var id = $('#exam_id').val();
        if(id){
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: '/ids/encrypt',
                type: 'POST',
                data: {
                    values: id,
                    _token: csrfToken
                },
                success: function(encrypted_id) {
                    window.open('/manage-assessments/write_exam/' + encrypted_id, '_blank');
                    location.reload();
                },
                error: function(xhr) {
                    toastr.error('Failed to start assessment. Please try again.');
                }
            });
        }
    }
    
    function sort_filter(value) {
        $('#sorting_filter').val(value);
        $('#search_form').submit();
    }
    
    function search_filter_func() {
        $('#search_form').submit();
    }
</script>
@endsection