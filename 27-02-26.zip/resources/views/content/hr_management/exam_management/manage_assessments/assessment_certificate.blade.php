@extends('layouts/blankLayout')

@section('title', 'Certificate')

@section('content')
    <style>
        
        @font-face {
            font-family: 'Mustica Pro';
            src: url('/fonts/MusticaPro-Regular.woff2') format('woff2'),
                url('/fonts/MusticaPro-Regular.woff') format('woff'),
                url('/fonts/MusticaPro-Regular.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        @font-face {
            font-family: 'Mustica Pro';
            src: url('/fonts/MusticaPro-Bold.woff2') format('woff2'),
                url('/fonts/MusticaPro-Bold.woff') format('woff'),
                url('/fonts/MusticaPro-Bold.ttf') format('truetype');
            font-weight: bold;
            font-style: normal;
        }

        body {
            background: transparent !important;
            font-family: 'Mustica Pro' !important;
        }

        p {
            margin: 0px !important;
        }

        .ft_wgt {
            font-weight: 600;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table tr,
        td,
        th {
            border: 1px solid #acaaaa;
        }

        .fw-semi_bold {
            font-family: 500 !important;
        }

        .shadow_lg {
            box-shadow: 0.rem 0.625rem 0.7rem 0.575rem rgba(0, 0, 0, 0.1) !important;
        }

        .bg_img {
            background-image: url('../../../../assets/egc_images/assessement_certificate/exam_certificate.jpg');
            background-size: contain !important;
            background-repeat: no-repeat;
            position: sticky;
            top: 100%;
        }

        @media (max-width: 991.98px) {
            .w-md-100 {
                width: 100% !important;
            }
        }

        @media (min-width: 992px) {
            .w-lg-100 {
                width: 100% !important;
            }

            .mt-lg-8 {
                margin-top: 2.2rem !important;
            }
        }

        /* @page { */
        /* size: A4; */
        /* width: 794px; */
        /* 210mm at 96 DPI */
        /* height: 1147px; */
        /* 297mm at 96 DPI */
        /* } */

        /* @media print { */
        /* * { */
        /* box-sizing: border-box; */
        /* Ensure padding and border are included in element's total width and height */
        /* }// */

        /* @page { */
        /* width: 794px; */
        /* 210mm at 96 DPI */
        /* height: 1123px; */
        /* 297mm at 96 DPI */
        /* }/ */
        /* } */

        @page {
            size: A4;
            margin: 10mm;
        }

        @media print {

            /* Ensure background colors & images print */
            body {
                -webkit-print-color-adjust: exact !important;
                /* Chrome, Safari */
                print-color-adjust: exact !important;
                /* Other browsers */
                color-adjust: exact !important;
                /* General fallback */
                margin: 0 !important;
                background: inherit !important;
            }

            /* You might want to explicitly hide elements for print */
            .no-print {
                display: none !important;
            }
        }
          .event-name {
            display: block;
            width: 100%;
            font-weight: bold;
            letter-spacing: 2px;
            white-space: nowrap;
            overflow: hidden;
            font-size: clamp(14px, 2vw, 24px); /* auto-resize between 14px and 24px */
            }
    </style>
    @php
        $staffLevel = $view->level_id;
        switch ($staffLevel) {
            case 0:
                $level = 'Beginner';
                break;
            case 1:
                $level = 'Intermediate';
                break;
            case 2:
                $level = 'Expert';
                break;
            default:
                $level = 'Unknown';
                break;
        }
    @endphp
    @php
        $marksScored = 0;
        $totalMarks = 0;

        if (isset($process[0])) {
            $p = $process[0];
            $answers = json_decode($p->exam_question_answers_datas, true) ?? [];
            $positiveMarks = $view->positive_mark ?? 1;
            $negativeMarks = $view->negative_mark ?? 0;
            $totalQuestions = $view->question_count ?? 0;

            $correctCount = collect($answers)->where('correctness', 'correct')->count();
            $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();

            $totalMarks = $positiveMarks * $totalQuestions;
            $marksScored = max(0, $positiveMarks * $correctCount - $negativeMarks * $incorrectCount);
            // Check if exam is passed
            $isPassed = $marksScored >= $view->pass_mark;
        }
    @endphp
    <center>
        <div class="bg_img" style="width: 794px !important;height: 1123px !important;font-family:'Mustica Pro' !important;">
            <div class="d-flex align-items-center">
                <div style="width:25% !important;padding-top: 209px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:75% !important;padding-top: 209px !important;font-size:21px !important;">
                    {{ $process[0]->staff_name ?? '' }}</div>
                <div style="width:5% !important;padding-top: 209px !important;"></div>
            </div>
            <div class="d-flex align-items-center">
                <div style="width: 48% !important;padding-top: 2px !important;"></div>
                <div class="fw-bold text-info text-start event-name" style="width: 52% !important;padding-top: 2px !important;">
                    {{ $view->exam_name ?? '' }}</div>
            </div>
            <div class="d-flex align-items-center">
                <div style="width:25% !important;padding-top: 0px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:5% !important;padding-top: 0px !important;font-size:21px !important;">
                    {{ $process[0]->completed_date ? date('d', strtotime($process[0]->completed_date)) : '' }}</div>
                <div style="width:2% !important;padding-top: 0px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:3% !important;padding-top: 0px !important;font-size:21px !important;">
                    {{ $process[0]->completed_date ? date('m', strtotime($process[0]->completed_date)) : '' }}</div>
                <div style="width:2% !important;padding-top: 0px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:7% !important;padding-top: 0px !important;font-size:21px !important;">
                    {{ $process[0]->completed_date ? date('Y', strtotime($process[0]->completed_date)) : '' }}</div>
                <div style="width:18% !important;padding-top: 0px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:13% !important;padding-top: 0px !important;font-size:21px !important;">{{ $level }}
                </div>
                <div style="width:21% !important;padding-top: 0px !important;"></div>
            </div>

            <div class="d-flex align-items-center">
                <div style="width: 29% !important;padding-top: 13px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width: 71% !important;padding-top: 13px !important;font-size:21px !important;">

                    @if ($view->prize_id == 1 && $view->gift)
                        {{ $view->gift ?? 'Gift' }}
                    @elseif($view->prize_id == 2 && $view->points)
                        + {{ $view->points }} Points
                    @elseif($view->prize_id == 3 && $view->promotion_id)
                        {{ $view->job_position_name ?? 'Career Advancement' }}
                    @else
                        Achievement Unlocked
                    @endif
                </div>
            </div>
            <div class="d-flex align-items-center">
                <div style="width: 48% !important;padding-top: 47px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:5% !important;padding-top: 52px !important;font-size:21px !important;">
                    {{ str_pad($marksScored, 2, '0', STR_PAD_LEFT) }}</div>
                <div style="width:2% !important;padding-top: 47px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:5% !important;padding-top: 52px !important;font-size:21px !important;">
                    {{ str_pad($totalMarks, 2, '0', STR_PAD_LEFT) }}</div>
                <div style="width:41% !important;padding-top: 47px !important;"></div>
            </div>
            <div class="d-flex align-items-center">
                <div class="fw-bold text-info text-center"
                    style="width:30% !important;padding-top: 0px !important;font-size:21px !important;">
                    {{-- <img src="{{ asset('assets/eapl_images/certificate_badge.png') }}" alt="Signature Image" style="width: auto; max-width: 105px; height: 60px;" /> --}}
                    @if ($view->badge_check == 1 && $isPassed)
                        <img src="{{ asset('exam/badges/' . $view->badge_image) }}" alt="Badge Image"
                            style="width: auto; max-width: 105px; height: 75px;" />
                    @endif
                </div>
                <div style="width:30% !important;padding-top: 0px !important;"></div>
                <div class="fw-bold text-info text-center"
                    style="width:30% !important;padding-top: 0px !important;padding-left: 80px !important;font-size:21px !important;">
                    <img src="{{ asset('assets/egc_images/assessement_certificate/assesment_authority.png') }}"
                        alt="Signature Image" style="width: 100%; max-width: 150px; height: 90px;" />
                </div>
            </div>
        </div>
    </center>
    <script>
        function fitTextToContainer(elementId, minFontSize = 12, maxFontSize = 28) {
            const el = document.getElementById(elementId);
            if (!el) return;
        
            let fontSize = maxFontSize;
            el.style.fontSize = fontSize + "px";
        
            // Reduce font size until it fits
            while (el.scrollWidth > el.offsetWidth && fontSize > minFontSize) {
                fontSize--;
                el.style.fontSize = fontSize + "px";
            }
        }
        
        // Run after page load
        window.addEventListener("load", () => fitTextToContainer("event-name"));
    </script>

@endsection
