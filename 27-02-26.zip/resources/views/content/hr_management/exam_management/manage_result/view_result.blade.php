@extends('layouts/layoutMaster')

@section('title', 'Exam Result')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss'])
@endsection


@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/nouislider/nouislider.js', 'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js', 'resources/assets/vendor/js/dropdown-hover.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>
    
    <style>
        :root {
            --primary: #099dda;
            --primary-light: #e6f4ff;
            --success: #28a745;
            --success-light: #e8f5e8;
            --success-gradient: linear-gradient(135deg, #28a745, #20c997);
            --danger: #dc3545;
            --danger-light: #fde8e8;
            --danger-gradient: linear-gradient(135deg, #dc3545, #e83e8c);
            --warning: #ffc107;
            --warning-light: #fff8e1;
            --info: #17a2b8;
            --info-light: #e3f2fd;
            --dark: #343a40;
            --light: #f8f9fa;
            --border-radius: 12px;
            --box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        .card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 20px;
            transition: var(--transition);
            border: none;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), #0b7bb5);
            color: white;
            padding: 25px;
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: "";
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.1);
            transform: rotate(30deg);
        }

        .card-header h1 {
            font-size: 28px;
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .breadcrumb {
            display: flex;
            list-style: none;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.9);
            position: relative;
            z-index: 1;
        }

        .breadcrumb li {
            display: flex;
            align-items: center;
        }

        .breadcrumb li:not(:last-child)::after {
            content: "›";
            margin: 0 12px;
            font-size: 16px;
        }

        .breadcrumb a {
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: var(--transition);
        }

        .breadcrumb a:hover {
            color: white;
            text-decoration: underline;
        }

        .card-body {
            padding: 30px;
        }

        .exam-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .info-section {
            background: var(--light);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 600;
            color: var(--dark);
        }

        .info-value {
            font-weight: 500;
            text-align: right;
        }

        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-success {
            background-color: var(--success-light);
            color: var(--success);
            border: 1px solid var(--success);
        }

        .badge-danger {
            background-color: var(--danger-light);
            color: var(--danger);
            border: 1px solid var(--danger);
        }

        .badge-warning {
            background-color: var(--warning-light);
            color: #856404;
            border: 1px solid var(--warning);
        }

        .badge-info {
            background-color: var(--info-light);
            color: var(--info);
            border: 1px solid var(--info);
        }

        .badge-primary {
            background-color: var(--primary-light);
            color: var(--primary);
            border: 1px solid var(--primary);
        }

        .badge-secondary {
            background-color: #e9ecef;
            color: #6c757d;
            border: 1px solid #ced4da;
        }

        .tabs-container {
            margin-top: 30px;
        }

        .tabs-header {
            display: flex;
            overflow-x: auto;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
        }

        .tab-button {
            padding: 12px 24px;
            background: none;
            border: none;
            font-weight: 600;
            color: #666;
            cursor: pointer;
            transition: var(--transition);
            border-bottom: 3px solid transparent;
            white-space: nowrap;
        }

        .tab-button.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .tab-button:hover:not(.active) {
            color: var(--primary);
            background-color: rgba(9, 157, 218, 0.05);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .result-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
            padding: 20px;
            background-color: var(--light);
            border-radius: var(--border-radius);
        }

        .summary-item {
            text-align: center;
            padding: 20px;
            border-radius: var(--border-radius);
            background: white;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: var(--transition);
        }

        .summary-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .summary-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .summary-label {
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .questions-container {
            margin-top: 30px;
        }

        .question-card {
            margin-bottom: 25px;
            border-radius: var(--border-radius);
            border: 1px solid #e0e0e0;
            overflow: hidden;
            transition: var(--transition);
        }

        .question-card:hover {
            border-color: var(--primary);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .question-header {
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .question-number {
            font-weight: 600;
            color: var(--dark);
        }

        .question-status {
            font-size: 14px;
            font-weight: 600;
        }

        .question-body {
            padding: 20px;
        }

        .question-text {
            font-size: 16px;
            margin-bottom: 15px;
            font-weight: 500;
            line-height: 1.5;
        }

        .options-container {
            margin-bottom: 15px;
        }

        .option {
            padding: 12px 15px;
            margin-bottom: 10px;
            border-radius: var(--border-radius);
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            transition: var(--transition);
        }

        .option.correct {
            background-color: var(--success-light);
            border-color: var(--success);
        }

        .option.incorrect {
            background-color: var(--danger-light);
            border-color: var(--danger);
        }

        .option.selected {
            border-width: 2px;
        }

        .option input {
            margin-right: 10px;
        }

        .question-footer {
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
        }

        .time-taken {
            color: #666;
        }

        /* Mini Popup Styles */
        .mini-popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .mini-popup.active {
            opacity: 1;
            visibility: visible;
        }

        .popup-content {
            background: white;
            border-radius: var(--border-radius);
            padding: 40px;
            text-align: center;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            transform: translateY(20px) scale(0.95);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .mini-popup.active .popup-content {
            transform: translateY(0) scale(1);
        }

        .popup-icon {
            font-size: 70px;
            margin-bottom: 20px;
        }

        .popup-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .popup-message {
            font-size: 18px;
            margin-bottom: 10px;
            color: #555;
            line-height: 1.6;
        }

        .popup-button {
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: var(--border-radius);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 10px;
        }

        .popup-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .badge-display {
            margin-top: 20px;
            padding: 30px;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 15px;
            border: 2px dashed #ced4da;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .badge-display:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        
        .badge-content {
            text-align: center;
            padding: 20px;
        }
        
        .badge-image {
            max-width: 120px;
            margin: 0 auto 15px;
            display: block;
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
            transition: transform 0.3s ease;
        }
        
        .badge-image:hover {
            transform: scale(1.05);
        }
        
        .badge-label {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.2rem;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .prize-section {
            padding: 20px;
        }
        
        .prize-card {
            display: flex;
            align-items: center;
            padding: 25px;
            border-radius: 12px;
            background: white;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border-left: 4px solid;
        }
        
        .prize-card:hover {
            transform: translateX(5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        
        .prize-gift {
            border-left-color: #e74c3c;
            background: linear-gradient(135deg, #fff, #fdf2f2);
        }
        
        .prize-points {
            border-left-color: #f39c12;
            background: linear-gradient(135deg, #fff, #fef9f2);
        }
        
        .prize-promotion {
            border-left-color: #27ae60;
            background: linear-gradient(135deg, #fff, #f2fdf5);
        }
        
        .prize-default {
            border-left-color: #3498db;
            background: linear-gradient(135deg, #fff, #f2f9fd);
        }
        
        .prize-icon {
            font-size: 2.5rem;
            margin-right: 20px;
            flex-shrink: 0;
        }
        
        .prize-content h4 {
            margin: 0 0 8px 0;
            color: #2c3e50;
            font-weight: 700;
        }
        
        .prize-description {
            color: #7f8c8d;
            margin-bottom: 12px;
            font-size: 0.95rem;
        }
        
        .points-display {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: white;
            padding: 8px 16px;
            border-radius: 25px;
            font-weight: 700;
        }
        
        .points-value {
            font-size: 1.3rem;
            margin-right: 5px;
        }
        
        .points-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .gift-name, .promotion-name {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .badge-display {
                padding: 20px;
            }
            
            .prize-card {
                flex-direction: column;
                text-align: center;
                padding: 20px;
            }
            
            .prize-icon {
                margin-right: 0;
                margin-bottom: 15px;
            }
            
            .badge-content {
                padding: 10px;
            }
            
            .badge-label {
                font-size: 1.1rem;
            }
        }
        
        /* Animation for new badge */
        @keyframes badgePop {
            0% {
                transform: scale(0.8);
                opacity: 0;
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        .badge-display {
            animation: badgePop 0.6s ease-out;
        }

        /* Pass Popup Specific Styles */
        #passMiniPopupModel .popup-content {
            border-top: 5px solid var(--success);
        }

        #passMiniPopupModel .popup-icon {
            color: var(--success);
        }

        #passMiniPopupModel .popup-title {
            color: var(--success);
        }

        #passMiniPopupModel .popup-button {
            background: var(--success-gradient);
        }

        /* Fail Popup Specific Styles */
        #failMiniPopup .popup-content {
            border-top: 5px solid var(--danger);
        }

        #failMiniPopup .popup-icon {
            color: var(--danger);
        }

        #failMiniPopup .popup-title {
            color: var(--danger);
        }

        #failMiniPopup .popup-button {
            background: var(--danger-gradient);
        }

        /* Fail SCH Popup Specific Styles */
        #failSchduleMiniPopup .popup-content {
            border-top: 5px solid var(--warning);
        }

        #failSchduleMiniPopup .popup-icon {
            color: var(--warning);
        }

        #failSchduleMiniPopup .popup-title {
            color: var(--warning);
        }

        #failSchduleMiniPopup .popup-button {
            background: var(--warning-gradient);
        }

        /* Score Highlight */
        .score-highlight {
            font-size: 22px;
            font-weight: 700;
            padding: 8px 15px;
            border-radius: var(--border-radius);
            display: inline-block;
            margin: 10px 0;
        }

        .pass-score {
            background-color: var(--success-light);
            color: var(--success);
        }

        .fail-score {
            background-color: var(--danger-light);
            color: var(--danger);
        }

        .fail-sch-score {
            background-color: var(--warning-light);
            color: var(--warning);
        }

        /* Enhanced Badge Animation Styles */
        .fly-badge {
            z-index: 1000;
            width: 120px;
            height: 120px;
            transition: all 3s ease-in-out;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid #FFD700;
            box-shadow: 0 0 30px rgba(255, 215, 0, 0.8);
        }

        .fly-badge.fly {
            transform: translate(var(--x), var(--y)) scale(0.1) rotateY(1080deg);
            opacity: 0;
            box-shadow: 0 0 100px rgba(255, 215, 0, 1);
        }

        /* Shining star effect */
        .shining-star {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: 3;
        }

        .star {
            position: absolute;
            width: 4px;
            height: 4px;
            background: white;
            border-radius: 50%;
            opacity: 0;
            animation: twinkle 1.5s infinite;
        }

        @keyframes twinkle {
            0%, 100% {
                opacity: 0;
                transform: scale(0.5);
            }
            50% {
                opacity: 1;
                transform: scale(1.5);
            }
        }

        /* Sound Button Styles */
        #enableSoundBtn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            padding: 14px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 30px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            opacity: 1;
            transform: translateY(0) scale(1);
            animation:
                slideIn 1s ease-out,
                gentleBounce 3s 1s infinite,
                pulseGlow 4s 2s infinite;
        }

        #enableSoundBtn:hover {
            transform: scale(1.08);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.5);
            animation-play-state: paused;
        }

        /* Keyframe Animations */
        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateY(100px) scale(0.7);
            }
            70% {
                opacity: 1;
                transform: translateY(-10px) scale(1.05);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes gentleBounce {
            0%, 100% {
                transform: translateY(0) scale(1);
            }
            50% {
                transform: translateY(-8px) scale(1.02);
            }
        }

        @keyframes pulseGlow {
            0%, 100% {
                box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
            }
            50% {
                box-shadow: 0 6px 30px rgba(102, 126, 234, 0.7);
            }
        }

        @media (max-width: 768px) {
            .exam-info-grid {
                grid-template-columns: 1fr;
            }
            .result-summary {
                grid-template-columns: 1fr;
            }
            .question-header,
            .question-footer {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .popup-content {
                padding: 25px;
            }
            .popup-title {
                font-size: 26px;
            }
        }
        .section-progress {
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #eaeaea;
        }
        
        .section-progress:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .section-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
        }
        
        .progress-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            color: #666;
        }
        
        .progress-bar-container {
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        .section-1-progress {
            background-color: #4caf50;
        }
        
        .section-2-progress {
            background-color: #2196f3;
        }
        
        .total-progress-container {
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid #eaeaea;
        }
        
        .total-progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        .total-progress-bar {
            height: 12px;
            background-color: #e9ecef;
            border-radius: 6px;
            overflow: hidden;
        }
        
        .total-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4caf50, #2196f3);
            border-radius: 6px;
            transition: width 0.5s ease;
        }
        
        .scroll-y-200px {
            max-height: 200px;
            overflow-y: auto;
            padding-right: 10px;
        }
        
        .scroll-y-200px::-webkit-scrollbar {
            width: 6px;
        }
        
        .scroll-y-200px::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }
        
        .scroll-y-200px::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }
        
        .scroll-y-200px::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
    </style>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1 class="d-flex align-items-center">
                    <span class="text-white fw-bold">&nbsp;{{ $view->exam_name }} Result</span>
                </h1>
            </div>
            <div class="card-body">
                <!-- Exam Information -->
                <div class="exam-info-grid">
                    <div class="info-section">
                        
                        <div class="info-item">
                            <span class="info-label">
                                <div class="fs-7 text-black fw-semibold">Staff</div>
                            </span>
                            <div class="info-value">
                                @if (isset($view->staff_image) && $view->staff_image != '' && file_exists(public_path('staff_images/' .$view->staff_image)))
                                    <div>
                                        <img src="{{ asset('staff_images/' . $view->staff_image) }}" alt="user-avatar" class="staff-avatar w-20 h-100 rounded" />
                                    </div>
                                @else
                                    <div>
                                        @php
                                            $initial = strtoupper(substr($view->nick_name, 0, 1));
                                        @endphp
                                        <span class="staff-initial">{{ $initial }}</span>
                                    </div>
                                @endif 
                                <div class="mb-0">
                                    <div class="fs-7 text-black fw-semibold">{{ $view->staff_names }}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Exam Level</span>
                            <span class="info-value">
                                @php
                                    $staffLevel = $view->level_id;
                                    switch ($staffLevel) {
                                        case 0:
                                            $level = 'Beginner';
                                            break;
                                        case 1:
                                            $level = 'Intermediate';
                                            break;
                                        case 2:
                                            $level = 'Expert';
                                            break;
                                        default:
                                            $level = 'Unknown';
                                            break;
                                    }
                                @endphp
                                {{ $level }}
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Badge</span>
                            <span class="info-value">{{ $view->badge_check == 0 ? 'No' : 'Yes' }}</span>
                        </div>
                    </div>


                    <div class="info-section">
                        <div class="info-item">
                            <span class="info-label">Exam Attempt</span>
                            <span class="info-value">
                                {{ $view->exam_attempt == 0 ? 'Trial' : 'Limited' }}
                                    <span class="badge badge-secondary ms-1">{{ str_pad(count($process ?? []), 2, '0', STR_PAD_LEFT) }}</span>
                                @if ($view->exam_attempt == 1)
                                    @php
                                        $new_limit = $helper->get_new_exam_limits($view->sno,$view->staff_id);
                                        if($new_limit){
                                            $view->attempts = $new_limit;
                                        }
                                    @endphp
                                    <span class="badge badge-danger ms-1">{{ str_pad($view->attempts, 2, '0', STR_PAD_LEFT) }}</span>
                                    @else
                                    <span class="badge badge-danger ms-1">∞</span>
                                @endif
                            </span>
                        </div>

                        <div class="info-item">
                            <span class="info-label">Positive Mark Per Question</span>
                            <span class="info-value">
                                <span class="badge badge-warning">{{ str_pad($view->positive_mark, 2, '0', STR_PAD_LEFT) }}</span>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Question Count</span>
                            <span class="badge badge-info">{{ str_pad($view->question_count, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                        
                    </div>

                    <div class="info-section">
                        <div class="info-item">
                            <span class="info-label">Job Role</span>
                            <span class="info-value">{{ $view->role_name }}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Negative Mark Per Question</span>
                            <span class="info-value">
                                <span class="badge badge-danger">{{ str_pad($view->negative_mark, 2, '0', STR_PAD_LEFT) }}</span>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Pass Mark</span>
                            <span class="badge badge-success">{{ str_pad($view->pass_mark, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                </div>

                <!-- Tabs for Multiple Attempts -->
                <div class="tabs-container">
                    <div class="tabs-header">
                        @if ($view->exam_attempt == 1 || $view->exam_attempt == 0)
                            @php
                                $last = count($process) - 1;
                                $last_ex_apt = count($process);
                            @endphp
                            @foreach ($process as $index => $p)
                                <button class="tab-button {{ $index == $last ? 'active' : '' }}" data-tab="tab-{{ $index + 1 }}">
                                    Assessment {{ str_pad($index + 1, 2, '0', STR_PAD_LEFT) }}
                                </button>
                            @endforeach
                        @else
                            @php $last=0; $last_ex_apt = 0; @endphp
                        @endif
                    </div>
                    
                     @php
                        $last_sno = 0;
                        $last_next_schedule = '';
                        $last_badge = 0;
                    @endphp

                    @foreach ($process as $index => $p)
                        @php
                            $staff_name = $p->staff_name ?? '';
                            $answers = json_decode($p->exam_question_answers_datas, true);
                            $positiveMarks = $view->positive_mark;
                            $negativeMarks = $view->negative_mark;
                            $totalQuestions = $view->question_count;
                            $correctCount = collect($answers)->where('correctness', 'correct')->count();
                            $incorrectCount = collect($answers)->where('correctness', 'incorrect')->count();
                            $totalMarks = $positiveMarks * $totalQuestions;
                            $marksScored = $positiveMarks * $correctCount - $negativeMarks * $incorrectCount;

                            // Ensure marksScored doesn't go below 0
                            $marksScored = max(0, $marksScored);
                            
                            // Calculate remaining time
                            $viewDuration = $view->duration * 60;
                            $attendedDuration = $p->total_attended_duration;
                            [$hours, $minutes, $seconds] = explode(':', $attendedDuration);
                            $attendedDurationInSeconds = $hours * 3600 + $minutes * 60 + $seconds;
                            $remainingDurationInSeconds = $viewDuration - $attendedDurationInSeconds;
                            $remainingMinutes = floor($remainingDurationInSeconds / 60);
                            $remainingSeconds = $remainingDurationInSeconds % 60;
                            $remainingTime = $remainingMinutes . ' Mins';
                            if ($remainingSeconds > 0) {
                                $remainingTime .= ' ' . $remainingSeconds . ' Sec';
                            }

                            // Check if exam is passed
                            $isPassed = $marksScored >= $view->pass_mark;
                        @endphp

                        <div class="tab-content {{ $index == $last ? 'active' : '' }}" id="tab-{{ $index + 1 }}">
                            <!-- Result Summary -->
                            <div class="row ">
                                <div class="col-lg-8">
                                    <div class="row">
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value text-success">
                                                {{ str_pad($correctCount, 2, '0', STR_PAD_LEFT) }}</div>
                                            <div class="summary-label">Correct Answers</div>
                                        </div>
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value text-danger">
                                                {{ str_pad($incorrectCount, 2, '0', STR_PAD_LEFT) }}</div>
                                            <div class="summary-label">Incorrect Answers</div>
                                        </div>
                                        
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value text-warning">{{ $remainingTime }}</div>
                                            <div class="summary-label">Completed Time</div>
                                        </div>
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value text-info">{{ $view->duration }} mins</div>
                                            <div class="summary-label">Duration</div>
                                        </div>
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value text-primary">
                                                {{ str_pad($marksScored, 2, '0', STR_PAD_LEFT) }}/{{ str_pad($totalMarks, 2, '0', STR_PAD_LEFT) }}
                                            </div>
                                            <div class="summary-label">Marks Scored</div>
                                        </div>
                                        <div class="summary-item col-lg-6 mb-2">
                                            <div class="summary-value 
                                            @if ($isPassed) text-success
                                            @else
                                                text-danger @endif">
        
                                                <i class="fas 
                                                @if ($isPassed) fa-thumbs-up
                                                @else
                                                    fa-thumbs-down @endif 
                                                me-2">
                                                </i>
                                                <strong>
                                                    @if ($isPassed)
                                                        Pass
                                                    @else
                                                        Fail
                                                    @endif
                                                </strong>
                                            </div>
        
                                            <div class="summary-label">Result</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="card mb-2">
                                        <div class="fs-5 fw-bold mt-1 text-center">Section Report</div>
                                        <div class="card-body" style="min-height: 330px !important;">
                                            <div class="scroll-y-200px">
                                                @foreach($p->section_data as $section)
                                                    @php
                                                        $total = max($section['question_count'], 1); // prevent divide-by-zero
                                                        $correct = $section['correct_count'];
                                                        $percentage = round(($correct / $total) * 100, 2);
                                                        $totalQuestions = collect($p->section_data)->sum('question_count');
                                                        $totalCorrect   = collect($p->section_data)->sum('correct_count');
                                                        $totalPercent   = $totalQuestions > 0 ? round(($totalCorrect / $totalQuestions) * 100, 2) : 0;
                                                    @endphp
                                                    <div class="section-progress">
                                                        <div class="section-title">{{ $section['section_name'] }}</div>
                                                        <div class="progress-details">
                                                            <span>Passed: {{ $correct }}/{{ $total }} questions</span>
                                                            <span>{{ $percentage }}%</span>
                                                        </div>
                                                        <div class="progress-bar-container">
                                                            <div class="progress-bar section-1-progress" style="width: {{ $percentage }}%"></div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                                
                                            <div class="total-progress-container">
                                                <div class="total-progress-label">
                                                    <span>Total Progress</span>
                                                    <span>{{ $totalPercent }}%</span>
                                                </div>
                                                <div class="total-progress-bar">
                                                    <div class="total-progress-fill" style="width: {{ $totalPercent }}%"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Badge Display if Passed -->
                            @if ($view->badge_check == 1 && $isPassed)
                                <div class="badge-display">
                                <div class="row align-items-center">
                                    <div class="col-lg-6">
                                        <div class="badge-content">
                                            <img src="{{ asset('exam/badges/' . $view->badge_image) }}" alt="Badge" class="badge-image">
                                            <div class="badge-label">Congratulations! {{$staff_name}} earned a badge</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="prize-section">
                                            @if($view->prize_id == 1 && $view->gift)
                                            <div class="prize-card prize-gift">
                                                <div class="prize-icon">🎁</div>
                                                <div class="prize-content">
                                                    <h4>Gift Reward</h4>
                                                    <p class="prize-description">You've earned a special gift!</p>
                                                    <div class="prize-details">
                                                        <span class="gift-name">{{ $view->gift }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($view->prize_id == 2 && $view->points)
                                            <div class="prize-card prize-points">
                                                <div class="prize-icon">⭐</div>
                                                <div class="prize-content">
                                                    <h4>Points Earned</h4>
                                                    <p class="prize-description">Great job! Points added to your account</p>
                                                    <div class="points-display">
                                                        <span class="points-value">+{{ $view->points }}</span>
                                                        <span class="points-label">Points</span>
                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($view->prize_id == 3 && $view->promotion_id)
                                            <div class="prize-card prize-promotion">
                                                <div class="prize-icon">🚀</div>
                                                <div class="prize-content">
                                                    <h4>Promotion Unlocked</h4>
                                                    <p class="prize-description">New opportunity unlocked!</p>
                                                    <div class="promotion-details">
                                                        <span class="promotion-name">
                                                            {{$view->job_position_name ?? 'Career Advancement'}}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            @else
                                            <div class="prize-card prize-default">
                                                <div class="prize-icon">🏆</div>
                                                <div class="prize-content">
                                                    <h4>Achievement Unlocked</h4>
                                                    <p class="prize-description">You've completed this challenge successfully!</p>
                                                </div>
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif

                            <!-- Questions Review -->
                            <!--@ if($view->detailed_view == 1)-->
                                <div class="">
                                @php
                                    $questionIndex = 0;
                                @endphp
                                @foreach ($sections as $questionId => $section)
                                    @php
                                        $questionIndex++;
                                        $answerData = $answersMap[$questionId] ?? null;
                                        $timeSpentSeconds = isset($answerData['time_spent'])
                                            ? (float) $answerData['time_spent'] * 60
                                            : 0;
                                        $minutesSpent = floor($timeSpentSeconds / 60);
                                        $secondsSpent = round($timeSpentSeconds % 60);
                                        $correctness = $answerData['correctness'] ?? null;
                                        $useranswer = $answerData['answer'] ?? null;
                                        $isNotAnswered =
                                            is_null($useranswer) ||
                                            (is_array($useranswer) && count($useranswer) === 0) ||
                                            $useranswer === '';

                                        $options = json_decode($section->option ?? '[]', true);
                                        $optionAnswer = json_decode($section->option_answer ?? '[]', true);

                                        if (!is_array($options)) {
                                            $options = [];
                                        }
                                        if (!is_array($optionAnswer)) {
                                            $optionAnswer = [];
                                        }

                                        $optionType =
                                            $section->option_type == 0
                                                ? 'radio'
                                                : ($section->option_type == 1
                                                    ? 'checkbox'
                                                    : 'Unknown');
                                    @endphp

                                    <div class="question-card">
                                        <div class="question-header">
                                            <div class="question-number">Question {{ $questionIndex }}</div>
                                            <div class="question-status">
                                                @if ($isNotAnswered)
                                                    <span class="badge badge-info">Not Answered</span>
                                                @elseif ($correctness === 'correct')
                                                    <span class="badge badge-success">Correct</span>
                                                @elseif ($correctness === 'incorrect')
                                                    <span class="badge badge-danger">Incorrect</span>
                                                @else
                                                    <span class="badge badge-info">Not Answered</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="question-body">
                                            <div class="question-text">{{ $section->question }}</div>
                                            <div class="options-container">
                                                @foreach ($options as $key => $answer)
                                                    @php
                                                        $isCorrect = in_array((string) $key, $optionAnswer);
                                                        $userAnswers = is_array($useranswer)
                                                            ? $useranswer
                                                            : [$useranswer];
                                                        $checked = in_array((string) $key, $userAnswers);
                                                        $optionClass = '';
                                                        if ($isCorrect) {
                                                            $optionClass = 'correct';
                                                        }
                                                        if ($checked && !$isCorrect) {
                                                            $optionClass = 'incorrect';
                                                        }
                                                        if ($checked) {
                                                            $optionClass .= ' selected';
                                                        }
                                                    @endphp

                                                    <div class="option {{ $optionClass }}">
                                                        <input type="{{ $optionType }}" {{ $checked ? 'checked' : '' }} disabled>
                                                        <span>{{ $answer }}</span>
                                                        @if ($checked)
                                                            @if ($isCorrect)
                                                                <img src="{{ asset('assets/egc_images/tick.png') }}" class="ms-auto" alt="Correct" style="width: 20px; height: 20px;">
                                                            @else
                                                                <img src="{{ asset('assets/egc_images/cross.png') }}" class="ms-auto" alt="Incorrect" style="width: 20px; height: 20px;">
                                                            @endif
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <!--@ else-->
                                <!--<div class="questions-container" style="display:@if ($isPassed) block @else none @endif;"></div>-->
                            <!--@ endif-->
                        </div>
                        @if ($loop->last)
                            @php
                            $last_sno = $p->sno;
                            $last_next_schedule = $p->next_schedule ?? '';
                            $last_badge = $p->badge_claim;
                            @endphp
                        @endif
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tab functionality
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const tabId = button.getAttribute('data-tab');

                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));

                    button.classList.add('active');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        });
    </script>
@endsection