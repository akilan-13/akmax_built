@extends('layouts/layoutMaster')

@section('title', 'Update Question')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection

@section('content')
<!-- Staff Add -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Question</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Question Bank</a>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Question Bank Basic Information -->
<div class="card mb-2 px-4 py-2">
    <!-- <h5 class="title mt-4 fw-bold">Basic Information</h5> -->
    <div class="row">
        <div class="col-lg-6 mt-4">
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Name</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-100 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{$view->bank_name ?? ''}}">{{$view->bank_name ?? ''}}</div>
                </div>
            </div>
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Level</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                
                <div class="col-7">
                    @if($view->level_id == 0)
                     <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Beginner">Beginner</div>
                    @elseif ($view->level_id == 1)
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Intermediate">Intermediate</div>
                    @elseif ($view->level_id == 2)
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Expert">Expert</div>
                    @else
                        <div class="text-black">N/A</div>
                    @endif
                    
                </div>
            </div>
        </div>
        <div class="col-lg-6 mt-2">
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Category</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{$view->category_name ?? ''}}">{{$view->category_name ?? ''}}</div>
                </div>
            </div>

            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Description</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{$view->description ?? ''}}">{{$view->description ?? ''}}</div>
                </div>
            </div>

        </div>
    </div>
    <form method="POST" action="{{ route('update_quesions') }}" id="add_form">
        @csrf
        <div class="row">
            <input type="hidden" name="bank_id" value="{{$view->sno}}">
            <!-- <div class="col-lg-4 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Section<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Section" />
            </div> -->
            <div class="col-lg-4 mb-3">
                <label class="text-dark fs-6 fw-semibold">Section</label>
                <div class="text-truncate max-w-75 text-black fs-6 fw-bold mt-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$Section->section_name ?? ''}}">{{$Section->section_name ?? ''}}</div>
                <input type="hidden" name="section_id" id="section_id" value="{{$Section->sno}}">
                <div class="section_id_err text-danger fw-semibold mt-1 fs-7"></div>
            </div>
        </div>
        <div class="row">
            <label class="text-info fw-bold fs-5 mb-4">Update Question</label>
            <div class="mb-4">
                @if(isset($Section_list))
                    @foreach($Section_list as $index => $sec)
                        <div class="form-repeater_section Delete_div">
                            <div data-repeater-list="group-a_sec">
                                <div data-repeater-item>
                                    <div class="row mb-4">
                                        <div class="col-lg-11">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="card rounded">
                                                        <div class="card-action">
                                                            <div class="card-header  bg-gray-200 px-3 py-2 collapsed pb-2">
                                                                <div class="card-action-title">
                                                                    <div class="row w-100">
                                                                       <div class="col-lg-12 mb-3">
                                                                          <div class="form-check form-check-inline mt-2">
                                                                            <input class="form-check-input case_study_valid" type="checkbox" id="addcasestudy_{{$index}}" name="addcasestudy_{{$index}}" value="1" onclick="addcasestudy_change({{$index}})" @if($sec->case_study_check == 1) checked @endif/>
                                                                            <label class="text-black mb-1 fs-6 fw-semibold">Add Case Study</label>
                                                                          </div>
                                                                          <textarea id="caseStudyDesc_{{$index}}" name="caseStudy_{{$index}}" class="form-control case_study_text" rows="3" placeholder="Enter Case Study" style="display:@if($sec->case_study_check == 1) block @else none @endif;">{{$sec->case_study}}</textarea>
                                                                          <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                        </div>
        
                                                                        <div class="col-lg-9">
                                                                            <label class="text-black mb-1 fs-6 fw-semibold">
                                                                                Question <span class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control title_case question_valid" placeholder="Enter Question" name="question[]" id="question_{{$index}}" value="{{$sec->question}}"/>
                                                                            <input type="hidden" class="index_no" value="{{$index}}">
                                                                            <input type="hidden" name="edit_question_ids[]" value="{{$sec->sno}}" >
                                                                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                            <div class="error_msg2 text-danger fw-semibold mt-1 fs-7"></div>
                                                                        </div>
                                                                        <div class="col-lg-3">
                                                                            <label
                                                                                class="text-black mb-1 fs-6 fw-semibold d-block">Option
                                                                                Type
                                                                                <span class="text-danger">*</span>
                                                                            </label>
                                                                            <div class="mt-3">
                                                                                <div class="form-check form-check-inline">
                                                                                    <input class="form-check-input" type="radio" name="option_type_{{$index}}" id="radioOption_{{$index}}" @if($sec->option_type == 0) checked @endif onclick="toggleOptionType({{$index}})" value="0"/>
                                                                                    <label class="form-check-label"
                                                                                        for="radioOption">Radio</label>
                                                                                </div>
                                                                                <div class="form-check form-check-inline">
                                                                                    <input class="form-check-input" type="radio" name="option_type_{{$index}}" id="checkboxOption_{{$index}}" @if($sec->option_type == 1) checked @endif onclick="toggleOptionType({{$index}})" value="1"/>
                                                                                    <label class="form-check-label"
                                                                                        for="checkboxOption">Check
                                                                                        Box</label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="card-action-element d-flex align-items-center">
                                                                    <ul class="list-inline mb-0">
                                                                        <li class="list-inline-item">
                                                                            <a href="javascript:;" class="toggle-change">
                                                                                <i class="mdi mdi-chevron-down fs-3 rotate-icon"></i>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="collapse option-add border show">
                                                            <div class="card-body">
                                                                <label class="text-info fw-bold fs-6 mb-2">Options</label>
                                                                <div class="form-repeater_topic">
                                                                    <div data-repeater-list="group-a_topic">
                                                                        <div data-repeater-item class="option-body">
                                                                            @php
                                                                            $options = json_decode($sec->option , true) ?? [];
                                                                            $optionAnswer = json_decode($sec->option_answer, true);
                                                                            @endphp
                                                                            @if($options)
                                                                                @foreach($options as $key => $op)
                                                                                
                                                                                @php
                                                                                    $isCorrect =  in_array((string)$key, $optionAnswer);
                                                                                @endphp
                                                                                <div class="row mb-3">
                                                                                    <div class="col-lg-9">
                                                                                        <input type="text" class="form-control title_case option_valid" placeholder="Enter Option" id="options_{{$index}}[]" name="options_{{$index}}[]" value="{{$op}}" />
                                                                                        <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                                    </div>
                                                                                    <div class="col-lg-1">
                                                                                        <div class="form-check form-check-inline">
                                                                                            <input class="form-check-input Answer_{{$index}}" type="{{ $sec->option_type == 0 ? 'radio' : 'checkbox' }}"  name="answer_{{$index}}[]" id="Answer_{{$index}}" {{ $isCorrect ? 'checked' : '' }} value="{{$key}}" />
                                                                                            <label class="form-check-label text-black fs-6 fw-semibold">Answer</label>
                                                                                        </div>
                                                                                    </div>
                                                                                    @if($key > 0)
                                                                                        <div class="col-lg-2">
                                                                                            <a href="javascript:;" class="btn btn-outline-danger px-1 py-1 que_butt_del" id="que_butt_del_{{$index}}">
                                                                                                <i class="mdi mdi-delete fs-4"></i>
                                                                                            </a>
                                                                                        </div>
                                                                                    @endif
                                                                                </div>
                                                                                @endforeach
                                                                            @else
                                                                            <div class="row mb-3">
                                                                                <div class="col-lg-9">
                                                                                    <input type="text" class="form-control title_case option_valid" placeholder="Enter Option" id="options_{{$index}}[]" name="options_{{$index}}[]"  />
                                                                                    <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                                </div>
                                                                                <div class="col-lg-1">
                                                                                    <div class="form-check form-check-inline">
                                                                                        <input class="form-check-input Answer_{{$index}}" type="{{ $sec->option_type == 0 ? 'radio' : 'checkbox' }}"  name="answer_{{$index}}[]" id="Answer_{{$index}}" value="0" />
                                                                                        <label class="form-check-label text-black fs-6 fw-semibold">Answer</label>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            @endif
                                                                            <div class="option_append_div"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="mb-1 mt-3">
                                                                    <button
                                                                        type="button"
                                                                        class="btn btn-sm btn-primary que_butt_add fs-8 px-2 py-1 question_add_option" id="que_butt_add_{{$index}}" data-option-id="{{$index}}">
                                                                        <i class="mdi mdi-plus me-1"></i>Add Option
                                                                    </button>
                                                                </div>
                                                                <div>
                                                                    <div class="row mt-4">
                                                                        <div class="col-lg-6">
                                                                            <label class="text-black mb-1 fs-6 fw-semibold">Tips<span class="text-danger">*</span></label>
                                                                            <div class="page_editor_class scroll-y tip_editor" style="max-height: 100px; overflow-y: auto;" id="tips_editor_{{$index}}">{!! $sec->tips !!}</div>
                                                                            <input type="hidden" id="tips_editor_hidden_{{$index}}" name="tips_editor_hidden_{{$index}}">
                                                                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                        </div>
                                                                        <div class="col-lg-6">
                                                                            <label class="text-black mb-1 fs-6 fw-semibold">Explanation<span class="text-danger">*</span></label>
                                                                            <div class="page_editor_class scroll-y exp_editor" style="max-height: 100px; overflow-y: auto;" id="exp_editor_{{$index}}">{!! $sec->explanation !!}</div>
                                                                            <input type="hidden" id="exp_editor_hidden_{{$index}}" name="exp_editor_hidden_{{$index}}">
                                                                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-1 mb-3">
                                            @if($index > 0)
                                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 que_bank_butt_del" id="que_bank_butt_del">
                                                    <i class="mdi mdi-delete fs-4"></i>
                                                </a>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif
                <div id="Add_more_append_div"></div>
            </div>
            <div class="mb-1 mt-1">
                <button type="button" class="btn btn-sm btn-primary fs-8 px-2 py-1" id="que_bank_butt_add">
                    <i class="mdi mdi-plus me-1"></i>Add More
                </button>
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-4">
            <span class="text-danger fw-semibold mt-1 fs-7 all_error"></span>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-4">
            <a href="{{url ('/question-bank')}}" class="btn btn-secondary me-3">Cancel</a>
            <button type="button" class="btn btn-primary"id="submit_btn" onclick="AddValidation()">Update Section</button>
        </div>
    </form>
</div>

<input type="hidden" id="Edit_ai" value="{{$Section_list ? count($Section_list) : 0}}">

<!-- End  Question Bank Basic Information -->
<script>
    window.addEventListener('input', function (e) {
        if (e.target.classList.contains('title_case')) {
            e.target.value = e.target.value
                .toLowerCase()
                .replace(/\b\w/g, char => char.toUpperCase());
        }
    });
</script>
<script>
    $(document).on('click', '.toggle-change', function() {
        const icon = $(this).find('.rotate-icon');
        const body = $(this).closest('.card').find('.card-body');
        body.slideToggle(200);
        icon.toggleClass('mdi-chevron-down mdi-chevron-up');
    });
</script>
<!-- Include Quill JS -->
<script>
    // Define your custom toolbar (if you need more options, customize this array)
    const CreatefullToolbar_Page = [
        [{
            'font': []
        }, {
            'size': []
        }],
        ['bold', 'italic', 'underline', 'strike'],
        [{
            'color': []
        }, {
            'background': []
        }],
        [{
            'script': 'sub'
        }, {
            'script': 'super'
        }],
        [{
            'header': [1, 2, 3, 4, 5, 6, false]
        }],
        [{
            'list': 'ordered'
        }, {
            'list': 'bullet'
        }],
        [{
            'indent': '-1'
        }, {
            'indent': '+1'
        }],
        [{
            'direction': 'rtl'
        }],
        [{
            'align': []
        }],
        ['blockquote'],
        ['image'],
        ['clean']
    ];
    window.onload = function() {
        const editors = document.querySelectorAll('.page_editor_class');
        editors.forEach((el) => {
            new Quill(el, {
                bounds: el,
                placeholder: 'Type Something...',
                modules: {
                    formula: true,
                    toolbar: CreatefullToolbar_Page
                },
                theme: 'snow'
            });
        });
    };
</script>

<script>
    function AddValidation() {
    let isValid = 0; // default: valid+
    
    var section_id = $('#section_id').val();
    
    if(section_id == ''){
        isValid = 1;
        $('.section_id_err').html('Select Section is required.');
    }else{
        $('.section_id_err').html('');
    }
    
    
    $('.case_study_valid').each(function(index) {
        var $checkbox = $(this);
        var $container = $checkbox.closest('.col-lg-12'); // get the main container div
    
        if ($checkbox.is(':checked')) {
            var content = $container.find('.case_study_text').val();
            var errorMsg = $container.find('.error_msg');
    
            if (!content) {
                isValid = 0;
                if (errorMsg.length) errorMsg.html('Case study is required.');
            } else {
                if (errorMsg.length) errorMsg.html('');
            }
        } else {
            var errorMsg = $container.find('.error_msg');
            if (errorMsg.length) errorMsg.html('');
        }
    });



    
        
    
    $('.question_valid').each(function(index) {
        var content = $(this).val().trim();
        var errorMsg = $(this).siblings('.error_msg');
        var errorMsg2 = $(this).siblings('.error_msg2');
    
        if (!content || content === '<p><br></p>') {
            isValid = 1;
            if(errorMsg.length) errorMsg.html('Question is required.');
        } else {
            if(errorMsg.length) errorMsg.html(''); // clear previous error
        }
        
        // Get the index_no properly (assumed input or text element)
        var index_no = $(this).siblings('.index_no').val() || $(this).siblings('.index_no').text();
        index_no = index_no.trim();
    
        // Check if any radio or checkbox in the group is selected
        var selectedAnswer = $('[name="answer_' + index_no + '[]"]:checked').length;
    
        if (selectedAnswer === 0) {
            isValid = 1;
            // Show error message for answer validation (create an error element or reuse errorMsg)
            if (errorMsg2.length) {
                errorMsg2.html('Please select at least one answer.');
            } 
        } else {
            // Clear previous error if any
            if (errorMsg2.length) {
                errorMsg2.html('');
            }
        }
    });

    
    $('.option_valid').each(function(index) {
        var content = $(this).val().trim();
        var errorMsg = $(this).siblings('.error_msg');

        if (!content || content === '<p><br></p>') {
            isValid = 1;
            if(errorMsg.length) errorMsg.html('Option is required.');
        } else {
            if(errorMsg.length) errorMsg.html(''); // clear previous error
        }
    });
    
    
    // Handle all tip editors
    $('.tip_editor').each(function(index) {
        var content = $(this).find('.ql-editor').html().trim();
        var hiddenInput = $(this).siblings('input[type="hidden"]'); // better: find sibling hidden input
        var errorMsg = $(this).siblings('.error_msg');

        if (!content || content === '<p><br></p>') {
            isValid = 1;
            hiddenInput.val('');
            if(errorMsg.length) errorMsg.html('Tips content is required.');
        } else {
            hiddenInput.val(content);
            if(errorMsg.length) errorMsg.html(''); // clear previous error
        }
    });

    // Handle all explanation editors
    $('.exp_editor').each(function(index) {
        var content = $(this).find('.ql-editor').html().trim();
        var hiddenInput = $(this).siblings('input[type="hidden"]');
        var errorMsg = $(this).siblings('.error_msg');

        if (!content || content === '<p><br></p>') {
            isValid = 1;
            hiddenInput.val('');
            if(errorMsg.length) errorMsg.html('Explanation content is required.');
            
        } else {
            hiddenInput.val(content);
            if(errorMsg.length) errorMsg.html('');
        }
    });

    // Submit form if everything is valid
    if (isValid === 0) {
        $('#add_form').submit();
        $('#submit_btn').prop('disabled', true);  // disables the button after submit
    } else {
        $('.all_error').html('Please fill the required field, it is mandatory.');
    }

}
</script>


<script>
    document.addEventListener('click', function (e) {
        const addButton = e.target.closest('.question_add_option');
    
        if (addButton) {
            const checklistId = addButton.getAttribute('data-option-id');
            const container = addButton.closest('.option-add').querySelector('.option_append_div');
            
            const newoption = `
                <div class="row mb-3">
                    <div class="col-lg-9">
                        <input type="text" class="form-control title_case option_valid" placeholder="Enter Option" id="options_${checklistId}[]" name="options_${checklistId}[]" />
                        <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                    </div>
                    <div class="col-lg-1">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input Answer_${checklistId}" type="radio" name="answer_${checklistId}[]" />
                            <label class="form-check-label text-black fs-6 fw-semibold">Answer</label>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <a href="javascript:;" class="btn btn-outline-danger px-1 py-1 que_butt_del" id="que_butt_del_${checklistId}">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>`;
    
            if (container) {
                container.insertAdjacentHTML('beforeend', newoption);
                reindexOptions(checklistId);
                toggleOptionType(checklistId);
            }
        }
    });

    // Deleting Task Checklist
    document.addEventListener('click', function (e) {
        if (e.target.closest('.que_butt_del')) {
            const row = e.target.closest('.row');
            const checklistId = row.querySelector('.form-check-input').className.match(/Answer_(\d+)/)[1];
            row.remove();
            reindexOptions(checklistId);
        }
    });
    
    // Function to reindex option values after add/delete
    function reindexOptions(checklistId) {
        const options = document.querySelectorAll(`.Answer_${checklistId}`);
        options.forEach((opt, index) => {
            opt.value = index; // reset value in sequence 0,1,2...
        });
    }


</script>

<script>
    let AutoCounter = $('#Edit_ai').val();

    document.getElementById('que_bank_butt_add').addEventListener('click', function() {

        AutoCounter++;
        const uid = AutoCounter;

        const newAddmore = `<div class="form-repeater_section Delete_div">
                <div data-repeater-list="group-a_sec">
                    <div data-repeater-item>
                        <div class="row mb-4">
                            <div class="col-lg-11">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card rounded">
                                            <div class="card-action">
                                                <div class="card-header bg-gray-200 px-3 py-2 collapsed pb-2">
                                                    <div class="card-action-title">
                                                        <div class="row w-100">
                                                            <div class="col-lg-12 mb-3">
                                                                <div class="form-check form-check-inline mt-2">
                                                                    <input class="form-check-input case_study_valid" type="checkbox" id="addcasestudy_${uid}" name="addcasestudy_${uid}" value="1" onclick="addcasestudy_change(${uid})"/>
                                                                    <label class="text-black mb-1 fs-6 fw-semibold">Add Case Study</label>
                                                                </div>
                                                                <textarea id="caseStudyDesc_${uid}" name="caseStudy_${uid}" class="form-control case_study_text" rows="3" placeholder="Enter Case Study" style="display:none;"></textarea>
                                                                <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                  
                                                            </div>
                                                            <div class="col-lg-9">
                                                                <label class="text-black mb-1 fs-6 fw-semibold">Question <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control title_case question_valid" placeholder="Enter Question" name="question[]" id="question_${uid}" />
                                                                <input type="hidden" name="edit_question_ids[]" value="0" >
                                                                <input type="hidden" class="index_no" value="${uid}">
                                                                <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                <div class="error_msg2 text-danger fw-semibold mt-1 fs-7"></div>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <label
                                                                    class="text-black mb-1 fs-6 fw-semibold d-block">Option
                                                                    Type
                                                                    <span class="text-danger">*</span>
                                                                </label>
                                                                <div class="mt-3">
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input" type="radio"
                                                                            name="option_type_${uid}" id="radioOption_${uid}" value="0"
                                                                            checked onclick="toggleOptionType(${uid})"/>
                                                                        <label class="form-check-label"
                                                                            for="radioOption">Radio</label>
                                                                    </div>
                                                                    <div class="form-check form-check-inline">
                                                                        <input class="form-check-input" type="radio"
                                                                            name="option_type_${uid}" id="checkboxOption_${uid}" value="1" onclick="toggleOptionType(${uid})"/>
                                                                        <label class="form-check-label"
                                                                            for="checkboxOption">Check
                                                                            Box</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-action-element d-flex align-items-center">
                                                        <ul class="list-inline mb-0">
                                                            <li class="list-inline-item">
                                                                <a href="javascript:;" class="toggle-change">
                                                                    <i class="mdi mdi-chevron-down fs-3 rotate-icon"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="collapse option-add border show">
                                                <div class="card-body">
                                                    <label class="text-info fw-bold fs-6 mb-2">Options</label>
                                                    <div class="form-repeater_topic">
                                                        <div data-repeater-list="group-a_topic">
                                                            <div data-repeater-item>
                                                                <div class="row mb-3">
                                                                    <div class="col-lg-9">
                                                                        <input type="text" class="form-control title_case option_valid"
                                                                            placeholder="Enter Option" id="options_${uid}[]" name="options_${uid}[]" />
                                                                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                                    </div>
                                                                    <div class="col-lg-1">
                                                                        <div class="form-check form-check-inline">
                                                                            <input class="form-check-input Answer_${uid}" type="radio" checked name="answer_${uid}[]" id="Answer_${uid}" value="0" />
                                                                            <label class="form-check-label text-black fs-6 fw-semibold">Answer</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="option_append_div"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1 mt-3">
                                                        <button
                                                            type="button"
                                                            class="btn btn-sm btn-primary que_butt_add fs-8 px-2 py-1 question_add_option" id="que_butt_add_${uid}" data-option-id="${uid}">
                                                            <i class="mdi mdi-plus me-1"></i>Add Option
                                                        </button>
                                                    </div>
                                                    <div>
                                                        <div class="row mt-4">
                                                            <div class="col-lg-6">
                                                                <label class="text-black mb-1 fs-6 fw-semibold">Tips<span class="text-danger">*</span></label>
                                                                <div class="page_editor_class scroll-y tip_editor" style="max-height: 100px; overflow-y: auto;" id="tips_editor_${uid}"></div>
                                                                <input type="hidden" id="tips_editor_hidden_${uid}" name="tips_editor_hidden_${uid}">
                                                                <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="text-black mb-1 fs-6 fw-semibold">Explanation<span class="text-danger">*</span></label>
                                                                <div class="page_editor_class scroll-y exp_editor" style="max-height: 100px; overflow-y: auto;" id="exp_editor_${uid}"></div>
                                                                <input type="hidden" id="exp_editor_hidden_${uid}" name="exp_editor_hidden_${uid}">
                                                                <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1 mb-3">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 que_bank_butt_del"
                                    id="que_bank_butt_del">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;

        document.getElementById('Add_more_append_div').insertAdjacentHTML('beforeend', newAddmore);
            const tipsEl = document.getElementById(`tips_editor_${uid}`);
            const expEl  = document.getElementById(`exp_editor_${uid}`);
        
            new Quill(tipsEl, {
                bounds: tipsEl,
                placeholder: 'Type Something...',
                modules: {
                    formula: true,
                    toolbar: CreatefullToolbar_Page
                },
                theme: 'snow'
            });
        
            new Quill(expEl, {
                bounds: expEl,
                placeholder: 'Type Something...',
                modules: {
                    formula: true,
                    toolbar: CreatefullToolbar_Page
                },
                theme: 'snow'
            });

    });
    document.addEventListener('click', function(e) {
        if (e.target.closest('.que_bank_butt_del')) {
            e.target.closest('.Delete_div').remove();
        }
    });
</script>


<script>

    function toggleOptionType(id) {
        var radioOption = document.getElementById('radioOption_' + id);
        var checkboxOption = document.getElementById('checkboxOption_' + id);
        var $answer = $('.Answer_' + id); // jQuery reference
    
        if (radioOption && radioOption.checked) {
            $answer.attr('type', 'radio');
        } else if (checkboxOption && checkboxOption.checked) {
            $answer.attr('type', 'checkbox');
        }
    }


</script>

<script>
    function addcasestudy_change(id){
        var addCaseStudyCheckbox = document.getElementById('addcasestudy_'+id);
        var caseStudyDesc = document.getElementById('caseStudyDesc_'+id);
        
         if (addCaseStudyCheckbox.checked) {
            caseStudyDesc.style.display = 'block';
            // $('#caseStudyDesc_'+id).val('');
        } else {
            caseStudyDesc.style.display = 'none';
            // $('#caseStudyDesc_'+id).val('');
        }
    }
</script>
@endsection