@extends('layouts/layoutMaster')

@section('title', 'View Question bank')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection

@section('content')
<!-- Staff Add -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Question Bank</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Question Bank</a>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Question Bank Basic Information -->
<div class="card mb-2 px-4 py-2">
    <!-- <h5 class="title mt-4 fw-bold">Basic Information</h5> -->
    <div class="row">
        <div class="col-lg-6 mt-4">
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Name</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-100 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{ $view->bank_name }}">{{ $view->bank_name }}</div>
                </div>
            </div>
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Level</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    @php
                        $level = match($view->level_id) {
                                0 => 'Beginner',
                                1 => 'Intermediate',
                                2 => 'Expert',
                                default => '',
                            }
                    @endphp
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{ $level }}">
                        {{ $level }}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 mt-2">
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Question Bank Category</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{ $view->category_name }}">{{ $view->category_name }}</div>
                </div>
            </div>

            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Description</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <div class="col-7">
                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="{{ $view->description ?? '-' }}">{{ $view->description ?? '-' }}</div>
                </div>
            </div>

        </div>
    </div>
    <label class="text-info fw-bold fs-5 mb-4">Section Based Question</label>
    @foreach($questions as $sectionId => $sectionQuestions)
    @php
        $firstQuestion = $sectionQuestions->first();
        $questionCount = $sectionQuestions->count();
        $sectionSlug = Str::slug($firstQuestion->section_name);
        $sectionCollapseId = 'collapse-' . $sectionSlug . '-' . $sectionId;
    @endphp
    
    <div class="col-lg-12 mb-4">
        <div class="card">
            <div class="card-header bg-light-primary border-bottom">
                <div class="d-flex align-items-center justify-content-between py-2">
                    <div class="d-flex align-items-center">
                        <h5 class="text-dark fw-bold mb-0 me-3">{{ $firstQuestion->section_name }}</h5>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="badge bg-primary rounded-pill fs-6 px-3 py-2 me-3">
                            {{ str_pad($questionCount, 2, '0', STR_PAD_LEFT) }} Questions
                        </span>
                        <button class="btn btn-sm btn-icon" 
                                type="button"
                                data-bs-toggle="collapse" 
                                data-bs-target="#{{ $sectionCollapseId }}"
                                aria-expanded="true"
                                aria-controls="{{ $sectionCollapseId }}">
                            <i class="mdi mdi-chevron-up fs-4 toggle-icon text-primary"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="collapse show" id="{{ $sectionCollapseId }}">
                <div class="card-body p-0">
                    @foreach($sectionQuestions as $questionIndex => $question)
                        @php
                            $options = json_decode($question->option, true) ?? [];
                            $answers = json_decode($question->option_answer, true) ?? [];
                            $answerIndices = array_map('intval', $answers);
                        @endphp
                        
                        <div class="question-item {{ !$loop->last ? 'border-bottom' : '' }} p-4">
                            <div class="row mb-3">
                                <div class="col-md-11">
                                    <div class="d-flex align-items-center mb-2">
                                        <span class="badge bg-label-primary fs-6 fw-semibold px-3 py-2 me-3">
                                            Question {{ $questionIndex + 1 }}
                                        </span>
                                        <span class="badge bg-label-{{ $question->option_type == 0 ? 'info' : 'warning' }} border border-{{ $question->option_type == 0 ? 'info' : 'warning' }} rounded fs-7 fw-semibold">
                                            {{ ucfirst($question->option_type == 0 ? 'Single Choice' : 'Multiple Choice') }}
                                        </span>
                                    </div>
                                    <h5 class="text-dark fs-5 fw-bold mb-0">{{ $question->question }}</h5>
                                </div>
                            </div>

                            <div class="row">
                                {{-- Options Column --}}
                                <div class="col-lg-6 pe-lg-4">
                                    <div class="options-container">
                                        @if(!empty($options))
                                            @foreach($options as $optionIndex => $optionText)
                                                <div class="option-item mb-3 p-3 rounded border {{ in_array($optionIndex, $answerIndices) ? 'border-success bg-light-success' : 'border-light' }}">
                                                    <div class="d-flex align-items-center">
                                                        <span class="badge bg-label-secondary rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 24px; height: 24px;">
                                                            {{ chr(65 + $optionIndex) }}
                                                        </span>
                                                        <span class="fs-6 fw-semibold {{ in_array($optionIndex, $answerIndices) ? 'text-success' : 'text-dark' }}">
                                                            {{ $optionText }}
                                                        </span>
                                                        @if(in_array($optionIndex, $answerIndices))
                                                            <i class="mdi mdi-check-circle text-success ms-2 fs-5"></i>
                                                        @endif
                                                    </div>
                                                </div>
                                            @endforeach
                                        @else
                                            @for($i = 0; $i < 4; $i++)
                                                <div class="option-item mb-3 p-3 rounded border border-light">
                                                    <div class="d-flex align-items-center">
                                                        <span class="badge bg-label-secondary rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 24px; height: 24px;">
                                                            {{ chr(65 + $i) }}
                                                        </span>
                                                        <span class="fs-6 fw-semibold text-muted">
                                                            Option {{ $i + 1 }}
                                                        </span>
                                                    </div>
                                                </div>
                                            @endfor
                                        @endif
                                    </div>
                                </div>

                                {{-- Content Column --}}
                                <div class="col-lg-6 ps-lg-4 border-start">
                                    {{-- Case Study --}}
                                    <div class="content-section mb-4">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="mdi mdi-book-open-page-variant text-primary me-2 fs-5"></i>
                                            <h6 class="text-primary mb-0 fw-semibold">Case Study</h6>
                                        </div>
                                        <div class="bg-light rounded p-3">
                                            <p class="text-dark fw-medium mb-0 fs-6">
                                                {!! $question->case_study ?? '<span class="text-muted">No case study available.</span>' !!}
                                            </p>
                                        </div>
                                    </div>

                                    {{-- Tips --}}
                                    <div class="content-section mb-4">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="mdi mdi-lightbulb-on-outline text-warning me-2 fs-5"></i>
                                            <h6 class="text-primary mb-0 fw-semibold">Tips</h6>
                                        </div>
                                        <div class="bg-light rounded p-3">
                                            <p class="text-dark fw-medium mb-0 fs-6">
                                                {!! $question->tips ?? '<span class="text-muted">No tips available.</span>' !!}
                                            </p>
                                        </div>
                                    </div>

                                    {{-- Explanation --}}
                                    <div class="content-section">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="mdi mdi-comment-text-outline text-info me-2 fs-5"></i>
                                            <h6 class="text-primary mb-0 fw-semibold">Explanation</h6>
                                        </div>
                                        <div class="bg-light rounded p-3">
                                            <p class="text-dark fw-medium mb-0 fs-6">
                                                {!! $question->explanation ?? '<span class="text-muted">No explanation available.</span>' !!}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endforeach

<style>
.question-item {
    transition: all 0.3s ease;
}

.question-item:hover {
    background-color: #f8f9fa;
}

.option-item {
    transition: all 0.2s ease;
}

.option-item:hover {
    transform: translateX(5px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.content-section {
    border-radius: 8px;
}

.border-light-primary {
    border-color: #e3f2fd !important;
}

.bg-light-success {
    background-color: #e8f5e8 !important;
}

.card-header {
    transition: all 0.3s ease;
}

.card-header:hover {
    background-color: #e3f2fd !important;
}
</style>

<script>
// Add smooth collapse animation
document.addEventListener('DOMContentLoaded', function() {
    const collapseButtons = document.querySelectorAll('[data-bs-toggle="collapse"]');
    
    collapseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const target = document.querySelector(this.getAttribute('data-bs-target'));
            const icon = this.querySelector('.toggle-icon');
            
            if (target.classList.contains('show')) {
                icon.classList.remove('mdi-chevron-up');
                icon.classList.add('mdi-chevron-down');
            } else {
                icon.classList.remove('mdi-chevron-down');
                icon.classList.add('mdi-chevron-up');
            }
        });
    });
});
</script>
</div>
<!-- End  Question Bank Basic Information -->

<style>
    .toggle-icon {
        transition: transform 0.3s ease;
    }

    .collapsed .toggle-icon {
        transform: rotate(180deg);
    }
</style>


@endsection