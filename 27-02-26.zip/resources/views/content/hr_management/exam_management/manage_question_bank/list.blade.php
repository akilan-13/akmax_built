@extends('layouts/layoutMaster')

@section('title', 'Manage Question Bank')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
$helper = new \App\Helpers\Helpers();
@endphp
    <!-- Users List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Question Bank</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                    <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" title="Filter">
                        <span><i class="mdi mdi-filter-outline text-center text-center"></i></span>
                    </a> -->
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_question_bank" >
                        <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Question Bank
                    </a>
                    <!--<a href="/question-bank/add" class="btn btn-sm fw-bold btn-primary text-white">-->
                    <!--    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Question Bank-->
                    <!--</a>-->
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="row mb-4">
                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                            onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <form id="search_form" method="POST" action="/question-bank">
                            @csrf
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="0">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                        value="@php echo $perpage ? $perpage : 10; @endphp" />
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="search_filter_func()">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Question Bank Name</th>
                                <th class="min-w-80px">Category</th>
                                <th class="min-w-80px">Question Bank Level</th>
                                <th class="min-w-100px text-center">No of Section / Question</th>
                                <th class="min-w-80px">Status</th>
                                <th class="min-w-100px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            @foreach($lists as $list)
                                <tr>
                                    <td>
                                        <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="{{ $list->bank_name }}">{{ $list->bank_name }}
                                        </div>

                                    </td>
                                    <td>
                                        <div class="text-black">{{ $list->category_name }}
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        @if($list->level_id == 0)
                                            <div class="text-black">Beginner</div>
                                        @elseif ($list->level_id == 1)
                                            <div class="text-black">Intermediate</div>
                                        @elseif ($list->level_id == 2)
                                            <div class="text-black">Expert</div>
                                        @else
                                            <div class="text-black">No Such Level</div>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @php
                                            $sec_count = $helper->get_Qbank_section_count($list->sno) ?? 0;
                                        @endphp
                                        <label class="badge bg-success border border-success rounded text-black fs-7 fw-semibold">{{ str_pad($sec_count, 2, '0', STR_PAD_LEFT) }}</label>
                                        <label class="badge bg-info border border-info rounded text-white fs-7 fw-semibold">{{ str_pad($list->question_count, 2, '0', STR_PAD_LEFT) }}</label>
                                    </td>

                                    <td>
                                        <label class="switch switch-square">
                                            <input type="checkbox" class="switch-input" {{ $list->status == 0 ? 'checked' : '' }}  onchange="statusChange('{{ $list->sno }}', this.checked)" />
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        @php                                        
                                            $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt');
                                            $view_url = url('/question-bank/view/' . $encryptedValue);
                                            $add_url = url('/question-bank/section_add/' . $encryptedValue);
                                        @endphp
                                           <div class="text-start">
                                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="{{ $view_url }}"  class="dropdown-item">
                                                        <span> <i
                                                                class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span></a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_edit_question_bank" onclick="populateUpdateModal({{$list->sno}})">
                                                        <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                                    </a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_add_question_import" onclick="ImportQuestion({{$list->sno}})">
                                                        <span> <i class="mdi mdi-database-import-outline fs-3 text-black me-1"></i>
                                                            Import Json Question
                                                        </span>
                                                    </a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_add_session" onclick="createSection({{$list->sno}})">
                                                        <span> <i class="mdi mdi-format-list-group-plus fs-3 text-black me-1"></i>
                                                            Add Section
                                                        </span>
                                                    </a>
                                                    <a href="{{ $add_url }}"  class="dropdown-item">
                                                        <span><i class="mdi mdi-folder-plus-outline fs-3 text-black me-1"></i>Add
                                                            Question</span>
                                                    </a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_edit_session" onclick="SectionEdit({{$list->sno}})">
                                                        <span><i class="mdi mdi-folder-edit-outline fs-3 text-black me-1"></i>Edit
                                                            Question</span>
                                                    </a>
                                                </div>
                                            </div>
                                    </td>
                                </tr>
                            @endforeach            
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    {{ $lists->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>

    
    
    <!--begin::Modal - Add Question Bank-->
    <div class="modal fade" id="kt_modal_add_question_bank" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Question Bank</h3>
                    </div>
                    <form method="POST" action="{{ route('add_quesion_bank') }}" id="add_form">
                    @csrf
                        <div class="row">
                            <div class="row mb-3 mt-2">
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Question Bank Name" id="bank_name" name="bank_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Category<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="category_id" name="category_id">
                                        <option value="">Select Question Bank Category</option>
                                        @if (isset($Cat_list))
                                            @foreach ($Cat_list as $c_list)
                                                <option value="{{ $c_list->sno }}">{{ $c_list->category_name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Level<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="level_id" name="level_id">
                                        <option value="">Select Question Bank Level</option>
                                        <option value="0">Beginner</option>
                                        <option value="1">Intermediate</option>
                                        <option value="2">Expert</option>
                                    </select>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" placeholder="Enter Description" id="description" name="description"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="add_submit" onclick="AddvalidateForm()">Create Question Bank</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Question Bank-->
    
    
    <!--begin::Modal - Add Question Bank-->
    <div class="modal fade" id="kt_modal_edit_question_bank" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Question Bank</h3>
                    </div>
                    <form method="POST" action="{{ route('edit_quesion_bank') }}" id="edit_form">
                    @csrf
                        <div class="row">
                            <div class="row mb-3 mt-2">
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Question Bank Name" id="edit_bank_name" name="bank_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                                    <input type="hidden" id="edit_id" name="edit_id">
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Category<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="edit_category_id" name="category_id">
                                        <option value="">Select Question Bank Category</option>
                                        @if (isset($Cat_list))
                                            @foreach ($Cat_list as $c_list)
                                                <option value="{{ $c_list->sno }}">{{ $c_list->category_name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Question Bank Level<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="edit_level_id" name="level_id">
                                        <option value="">Select Question Bank Level</option>
                                        <option value="0">Beginner</option>
                                        <option value="1">Intermediate</option>
                                        <option value="2">Expert</option>
                                    </select>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" placeholder="Enter Description" id="edit_description" name="description"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="edit_submit" onclick="EditvalidateForm()">Update Question Bank</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Question Bank-->
    
    <!--begin::Modal - Update Session-->
    <div class="modal fade" id="kt_modal_edit_session" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Section</h3>
                    </div>
                    <div class="row mt-2">
                        <input type="hidden" name="sec_edit_id" id="sec_edit_id">
                        <div class="col-lg-12">
                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Name</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-6">
                                    <div class="text-black fs-6 fw-bold" id="sec_edit_bank_name">-</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-6">
                                    <div class="text-black fs-6 fw-bold" id="sec_edit_category_id">-</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Level</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-6">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="sec_edit_level_id">-</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Section<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="sec_section_id" name="sec_section_id">
                                        <option value="">Select Section</option>
                                    </select>
                                    <div class="text-danger fs-semibold fs-7 sec_section_id_err"></div>
                                </div>
                            </div>
                        </div>
    
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary me-3" onclick="SectionUpdate()">Update Section</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Session-->
    <!--begin::Modal - Add Session-->
    <div class="modal fade" id="kt_modal_add_session" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Section</h3>
                    </div>
                    <form action="{{ route('create_exam_section') }}" method="POST" id="add_section_form">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12">
                                <input type="hidden" name="question_bank_id" id="question_bank_id">
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Name</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_bank_name">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Level</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_level_name">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Category</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_question_cat">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <div class="col-lg-12">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Section <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="section_id" id="section_id" placeholder="Enter Section" />
                                        <div id="section_id_err" class="text-danger fw-semibold fs-7 mt-1"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Create Section</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Session-->
    
    
    <!--begin::Modal - Add Session-->
    <div class="modal fade" id="kt_modal_add_question_import" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Json Questions</h3>
                    </div>
                    <form action="{{ route('questions_import') }}" method="POST" id="importForm"  enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12">
                                <input type="hidden" name="bank_id_import" id="bank_id_import">
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Name</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_bank_name_imp">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Level</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_level_name_imp">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Question Bank Category</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <div class="col-6">
                                        <div class="text-black fs-6 fw-bold" id="section_question_cat_imp">-</div>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    <div class="mb-3">
                                        <label class="col-5 text-dark fs-6 fw-semibold">Upload JSON File <span class="text-danger">*</span></label>
                                        <input type="file" name="file" id="file" class="form-control mt-2" accept=".json" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" id="importBtn" class="btn btn-primary">
                                Import Questions
                            </button>
                        
                            <!-- Loader label -->
                            <button type="button" id="btnLoader" class="ms-2 d-none btn btn-primary" disabled>
                                Questions Importing...
                                <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Session-->

    
    <!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
<!-- Toastr Ends -->
<script>
    const form = document.getElementById('importForm');
    const btn = document.getElementById('importBtn');
    const loaderLabel = document.getElementById('btnLoader');
    const spinner = loaderLabel.querySelector('.spinner-border');

    form.addEventListener('submit', function() {
        // Disable submit button
        btn.disabled = true;
        btn.classList.add('d-none');
        loaderLabel.classList.remove('d-none');
        // Show loader
        spinner.classList.remove('d-none');
    });
</script>


<script>
    function createSection(ID) {
        
        fetch(`/question-bank/edit/${ID}`)
        .then(response => {
            // Check if response is OK
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // This returns a promise
        })
        .then(data => {
            // Check if data contains the expected structure
            if (data.status === 200 && data.data) {
                const datas = data.data;
                $("#question_bank_id").val(datas.sno)
                $('#section_bank_name').html(datas.bank_name);

                if(datas.level_id == 0) {
                    $('#section_level_name').html('Beginner');
                } else if(datas.level_id == 1) {
                    $('#section_level_name').html('Intermediate');
                } else {
                    $('#section_level_name').html('Expert');
                }
                $('#section_question_cat').html(datas.category_name);
               
            } else {
                console.error('Error fetching category:', data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
    }

    $('#add_section_form').on('submit', function (e) {
        $('#section_id_err').text('');

        if($('#section_id').val() === '') {
            e.preventDefault();
            $('#section_id_err').text('Section is required.');
        }
    })

    $('#section_id').on('input', () => {
        $('#section_id_err').text('');
    })
    
    function ImportQuestion(ID) {
        
        fetch(`/question-bank/edit/${ID}`)
        .then(response => {
            // Check if response is OK
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // This returns a promise
        })
        .then(data => {
            // Check if data contains the expected structure
            if (data.status === 200 && data.data) {
                const datas = data.data;
                $("#bank_id_import").val(datas.sno)
                $('#section_bank_name_imp').html(datas.bank_name);

                if(datas.level_id == 0) {
                    $('#section_level_name_imp').html('Beginner');
                } else if(datas.level_id == 1) {
                    $('#section_level_name_imp').html('Intermediate');
                } else {
                    $('#section_level_name_imp').html('Expert');
                }
                $('#section_question_cat_imp').html(datas.category_name);
               
            } else {
                console.error('Error fetching category:', data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
    }
</script>

<script>
    function SectionUpdate(){
        var sec_id = $('#sec_section_id').val();
        var bank_id = $('#sec_edit_id').val();
        var val = sec_id + '~' + bank_id;
        if(sec_id == ''){
            $('.sec_section_id_err').html('Select Section is required.');
        }else{
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                  values: val,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_id) {
                // Redirect to the desired route with the encrypted ID
                window.location.href = '/question-bank/section_edit/' + encrypted_id;
             },
             error: function(xhr) {
                 
             }
         });
        }
    }
</script>

<script>
    function AddvalidateForm() {
        let isValid = 0;

        // Clear all previous errors
        document.querySelectorAll('.error_msg').forEach(div => {
            div.innerText = '';
        });

        // Helper to set error
        function setError(id, message) {
            document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
            isValid = 1;
        }

        // Required fields validation
        const requiredFields = [{
                id: 'bank_name',
                name: 'Enter Question Bank Name'
            },
            {
                id: 'category_id',
                name: 'Select Question Bank Category'
            },
            {
                id: 'level_id',
                name: 'Select Question Bank Level'
            }
        ];

        requiredFields.forEach(field => {
            const value = document.getElementById(field.id).value.trim();
            if (value === '') {
                setError(field.id, `${field.name} is required.`);
            }
        });

        
        if (isValid == 0) {
            $('#add_form').submit();
        }
    }
    function EditvalidateForm() {
        let isValid = 0;

        // Clear all previous errors
        document.querySelectorAll('.error_msg').forEach(div => {
            div.innerText = '';
        });

        // Helper to set error
        function setError(id, message) {
            document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
            isValid = 1;
        }

        // Required fields validation
        const requiredFields = [{
                id: 'edit_bank_name',
                name: 'Enter Question Bank Name'
            },
            {
                id: 'edit_category_id',
                name: 'Select Question Bank Category'
            },
            {
                id: 'edit_level_id',
                name: 'Select Question Bank Level'
            }
        ];

        requiredFields.forEach(field => {
            const value = document.getElementById(field.id).value.trim();
            if (value === '') {
                setError(field.id, `${field.name} is required.`);
            }
        });

        
        if (isValid == 0) {
            $('#edit_form').submit();
        }
    }
    
    function populateUpdateModal(ID) {
        
        fetch(`/question-bank/edit/${ID}`)
        .then(response => {
            // Check if response is OK
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // This returns a promise
        })
        .then(data => {
            // Check if data contains the expected structure
            if (data.status === 200 && data.data) {
                const datas = data.data;
                $("#edit_id").val(datas.sno)
                $('#edit_bank_name').val(datas.bank_name);
                $('#edit_description').val(datas.description);
                $('#edit_level_id').val(datas.level_id).trigger('change');
                $('#edit_category_id').val(datas.category_id).trigger('change');
               
            } else {
                console.error('Error fetching category:', data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
    }
    function SectionEdit(ID) {
    fetch(`/question-bank/edit/${ID}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Response data:', data);

            if (data.status === 200 && data.data) {
                const datas = data.data;

                $("#sec_edit_id").val(datas.sno);
                $('#sec_edit_bank_name').html(datas.bank_name);

                // Map level_id to text
                let level = '';
                if (datas.level_id == 0) level = 'Beginner';
                else if (datas.level_id == 1) level = 'Intermediate';
                else if (datas.level_id == 2) level = 'Expert';

                $('#sec_edit_level_id').html(level);
                $('#sec_edit_category_id').html(datas.category_name);

                const roles = data.sections;
                console.log('Sections:', roles);

                const roleId = $('#sec_section_id');
                roleId.empty();
                roleId.append('<option value="">Select Section</option>');
                if (roles && roles.length > 0) {
                    

                    roles.forEach(role => {
                        roleId.append(`<option value="${role.section_id}">${role.section_name}</option>`);
                    });
                }
            } else {
                console.error('Error fetching category:', data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
}

</script>
<!-- Sort Filter -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>



<!-- Status Change -->
<script>
    function statusChange(sno, isChecked) {
        const status = isChecked ? 0 : 1;

        fetch(`/question_bank_status/${sno}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Question Bank Status Changed Succesfully !');
            } else {
                toastr.error('Question Bank Status Changing Failed !');
            }
        })
        .catch(error => {
            console.log('Error Changing Status :', error);
        });
    }
</script>

@endsection
