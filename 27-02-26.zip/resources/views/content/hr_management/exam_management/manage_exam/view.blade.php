@extends('layouts/layoutMaster')

@section('title', 'View Exam')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('content')
<!-- Staff Add -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Exam</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center">
                        <i class="mdi mdi-home-outline text-body fs-4"></i>
                    </a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Exam Management</a>
                </li>
                <span class="text-black opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Exam</a>
                </li>
            </ol>
        </nav>
    </div>
</div>

<style>
    :root {
        --primary-color: #3a86ff;
        --secondary-color: #8338ec;
        --success-color: #06d6a0;
        --warning-color: #ffd166;
        --danger-color: #ef476f;
        --light-bg: #f8f9fa;
        --card-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        --border-radius: 10px;
    }
    
    .exam-header {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        border-radius: var(--border-radius);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--card-shadow);
    }
    
    .info-card {
        background-color: white;
        border-radius: var(--border-radius);
        box-shadow: var(--card-shadow);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        transition: transform 0.3s ease;
    }
    
    .info-card:hover {
        transform: translateY(-5px);
    }
    
    .info-label {
        color: #6c757d;
        font-weight: 500;
        font-size: 0.9rem;
    }
    
    .info-value {
        color: #212529;
        font-weight: 600;
        font-size: 1rem;
    }
    
    .badge-custom {
        font-size: 0.8rem;
        padding: 0.4rem 0.8rem;
        border-radius: 20px;
    }
    
    .question-card {
        border-left: 4px solid var(--primary-color);
        background-color: white;
        border-radius: var(--border-radius);
        box-shadow: var(--card-shadow);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
    }
    
    .option-correct {
        background-color: rgba(6, 214, 160, 0.1);
        border: 1px solid var(--success-color);
        border-radius: 8px;
        padding: 0.8rem;
        margin-bottom: 0.5rem;
    }
    
    .option-incorrect {
        background-color: rgba(239, 71, 111, 0.05);
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 0.8rem;
        margin-bottom: 0.5rem;
    }
    
    .section-title {
        color: var(--primary-color);
        font-weight: 600;
        border-bottom: 2px solid var(--primary-color);
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
    }
    
    .stats-card {
        text-align: center;
        padding: 1rem;
    }
    
    .stats-value {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }
    
    .stats-label {
        font-size: 0.9rem;
        color: #6c757d;
    }
    
    .badge-image {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        border: 3px solid var(--warning-color);
        object-fit: cover;
    }
    
    .collapse-toggle {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
    }
    
    .collapse-toggle:hover {
        color: var(--secondary-color);
    }
    
    .max-h-500px {
        max-height: 500px;
        overflow-y: auto;
    }
    
    .scroll-y {
        overflow-y: auto;
    }
    
    /* Custom icon styles for Material Design Icons */
    .mdi-correct {
        color: var(--success-color);
    }
    
    .mdi-incorrect {
        color: #6c757d;
    }
    
    .mdi-case-study {
        color: var(--primary-color);
    }
    
    .mdi-tips {
        color: var(--warning-color);
    }
    
    .mdi-explanation {
        color: var(--info-color);
    }
</style>

<div class="container py-4">
    <!-- Exam Header -->
    <div class="exam-header">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="display-6 fw-bold mb-2" style="color:#FFD700;">{{ $view->exam_name }}</h1>
                 @php
                    $levelId = $view->level_id;
                    switch ($levelId) {
                        case 0:
                            $content = 'All';
                            break;
                        case 1:
                            $content = 'Beginner';
                            break;
                        case 2:
                            $content = 'Intermediate';
                            break;
                        case 3:
                            $content = 'Expert';
                            break;
                        default:
                            $content = '';
                            break;
                    }
                @endphp
                
            </div>
            <div class="col-md-4 text-md-end">
                {{$content}}
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Basic Information -->
        <div class="col-lg-4">
            <div class="info-card  h-100">
                <h5 class="section-title">Assessment Information</h5>
                
                <!-- Job Role -->
                <div class="mb-3">
                    <div class="info-label">Job Role</div>
                    <div class="info-value">{{ $view->role_name ?? 'N/A' }}</div> <!-- Assuming role_names is now a string -->
                </div>
                
                <!-- Pass Mark -->
                <div class="mb-3">
                    <div class="info-label">Pass Mark</div>
                    <div class="info-value">{{ $view->pass_mark }}</div>
                </div>
                
                <!-- Question Generation -->
                <div class="mb-3">
                    <div class="info-label">Question Generation</div>
                    <div class="info-value">{{ $view->question_generate == 0 ? 'Random' : 'Sequence' }}</div>
                </div>
                
                <!-- Exam Attempt -->
                <div class="mb-3">
                    <div class="info-label">Exam Attempt</div>
                    <div class="info-value">
                        {{ $view->exam_attempt == 0 ? 'Trial' : 'Limited (' . str_pad($view->attempts, 2, '0', STR_PAD_LEFT) . ')' }}
                    </div>
                </div>
                
                <!-- Exam Schedule -->
                <div class="mb-3">
                    <div class="info-label">Exam Schedule</div>
                    <div class="info-value">{{ $view->schedule_name }} ({{ $view->schedule_duration }} {{ $view->schedule_unit }})</div>
                </div>
                
                <!-- Badge Information -->
                <div class="mb-3">
                    <div class="info-label">Badge</div>
                    <div class="info-value">{{ $view->badge_check == 0 ? 'No' : 'Yes' }}</div>
                </div>
                
                <!-- Badge Image (if Badge is enabled) -->
                @if($view->badge_check == 1)
                    <div class="mb-3">
                        <div class="info-label">Badge Image</div>
                        <div class="mt-2 text-center">
                            <img src="{{ asset('exam/badges/' . $view->badge_image) }}" alt="Badge" class="badge-image">
                        </div>
                        <div class="info-value text-center">{{ $view->badge_name }}</div>
                    </div>
                @endif
            </div>
        </div>

        
        <!-- Exam Statistics -->
        <div class="col-lg-4">
            <div class="info-card h-100">
                <h5 class="section-title">Exam Statistics</h5>
                
                <div class="row text-center">
                    <div class="col-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-value text-primary">{{ str_pad($view->question_count, 2, '0', STR_PAD_LEFT) }}</div>
                            <div class="stats-label">Questions</div>
                        </div>
                    </div>
                    <div class="col-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-value text-success">{{ str_pad($view->duration, 2, '0', STR_PAD_LEFT) }} Mins</div>
                            <div class="stats-label">Duration</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stats-card">
                            <div class="stats-value text-info">{{ str_pad($view->positive_mark, 2, '0', STR_PAD_LEFT) }}</div>
                            <div class="stats-label">Positive Mark</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stats-card">
                            <div class="stats-value text-danger">{{ str_pad($view->negative_mark, 2, '0', STR_PAD_LEFT) }}</div>
                            <div class="stats-label">Negative Mark</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Additional Details -->
        <div class="col-lg-4">
            <div class="info-card h-100">
                <h5 class="section-title">Additional Details</h5>
                
                <div class="mb-3">
                    <div class="info-label">Question Generation Type</div>
                    <div class="info-value">
                        <span class="badge bg-primary badge-custom">
                            {{ $view->question_generate == 0 ? 'Random' : 'Sequence' }}
                        </span>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="info-label">Exam Attempt Type</div>
                    <div class="info-value">
                        <span class="badge bg-info badge-custom">
                            {{ $view->exam_attempt == 0 ? 'Trial' : 'Limited (' . str_pad($view->attempts, 2, '0', STR_PAD_LEFT) . ')' }}
                        </span>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="info-label">Schedule</div>
                    <div class="info-value">
                        <span class="badge bg-warning text-dark badge-custom">
                            {{ $view->schedule_name }} ( {{$view->schedule_duration}} {{ $view->schedule_unit }} )
                        </span>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="info-label">Badge Status</div>
                    <div class="info-value">
                        <span class="badge {{ $view->badge_check == 0 ? 'bg-secondary' : 'bg-success' }} badge-custom">
                            {{ $view->badge_check == 0 ? 'No Badge' : 'Badge Enabled' }}
                        </span>
                    </div>
                </div>
                
                <div class="mt-4 p-3 bg-light rounded">
                    <div class="info-label">Description</div>
                    <div class="info-value mt-2">{{ $view->description ?? 'No description provided' }}</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Questions Section -->
    <div class="info-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="section-title mb-0">Exam Questions</h5>
            <span class="badge bg-danger badge-custom">{{ count($sections) }} Questions</span>
        </div>
        
        <div class="reasearch_foundation_body_view border rounded p-3">
            <div class="scroll-y max-h-500px">
                @php $i = 1; @endphp
                @foreach($sections as $index => $section)
                    <div class="question-card">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h6 class="text-primary fw-bold">Question {{ $i }}</h6>
                            <div>
                                @php
                                    if ($section->option_type == 0) {
                                        $optionType = 'Single Choice';
                                        $badgeClass = 'bg-primary';
                                    } elseif ($section->option_type == 1) {
                                        $optionType = 'Multiple Choice';
                                        $badgeClass = 'bg-info';
                                    } else {
                                        $optionType = 'Unknown';
                                        $badgeClass = 'bg-secondary';
                                    }
                                @endphp
                                <span class="badge {{ $badgeClass }} badge-custom">{{ $optionType }}</span>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="info-label mb-1">Question Bank & Section</div>
                            <div class="d-flex align-items-center flex-wrap">
                                <span class="badge bg-light text-dark me-2">{{ $section->bank_name }}</span>
                                <i class="mdi mdi-arrow-right text-muted mx-1"></i>
                                <span class="badge bg-light text-dark">{{ $section->section_name }}</span>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="info-label mb-1">Question</div>
                            <p class="info-value">{{ $section->question }}</p>
                        </div>
                        
                        <div class="mb-3">
                            <div class="info-label mb-2">Options</div>
                            @php
                                $options = json_decode($section->option, true);
                                $optionAnswer = json_decode($section->option_answer, true);
                                
                                if (!is_array($options)) $options = [];
                                if (!is_array($optionAnswer)) $optionAnswer = [];
                            @endphp
                            
                            <div class="row">
                                @forelse($options as $key => $answer)
                                    @php
                                        $isCorrect = in_array((string)$key, $optionAnswer);
                                    @endphp
                                    <div class="col-lg-6 mb-2">
                                        <div class="{{ $isCorrect ? 'option-correct' : 'option-incorrect' }}">
                                            <div class="d-flex align-items-center">
                                                @if($isCorrect)
                                                    <i class="mdi mdi-check-circle mdi-correct me-2"></i>
                                                @else
                                                    <i class="mdi mdi-checkbox-blank-circle-outline mdi-incorrect me-2"></i>
                                                @endif
                                                <span>{{ $answer }}</span>
                                            </div>
                                        </div>
                                    </div>
                                @empty
                                    <div class="col-12 text-muted">No options available.</div>
                                @endforelse
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            @if($section->case_study_check && !empty($section->case_study))
                            <div class="col-lg-4 mb-3">
                                <div class="info-label mb-1">
                                    <i class="mdi mdi-book-open-page-variant mdi-case-study me-1"></i> Case Study
                                </div>
                                <div class="info-value small">{{ $section->case_study }}</div>
                            </div>
                            @endif
                            
                            <div class="col-lg-4 mb-3">
                                <div class="info-label mb-1">
                                    <i class="mdi mdi-lightbulb-on mdi-tips me-1"></i> Tips
                                </div>
                                <div class="info-value small">{!! $section->tips !!}</div>
                            </div>
                            
                            <div class="col-lg-4 mb-3">
                                <div class="info-label mb-1">
                                    <i class="mdi mdi-information mdi-explanation me-1"></i> Explanation
                                </div>
                                <div class="info-value small">{!! $section->explanation !!}</div>
                            </div>
                        </div>
                    </div>
                    @php $i++; @endphp
                @endforeach
            </div>
        </div>
    </div>
</div>

@endsection