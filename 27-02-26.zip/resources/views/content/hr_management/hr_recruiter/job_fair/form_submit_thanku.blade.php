@extends('layouts/blankLayout')
@section('title', 'Application Submitted')
@section('content')

<style>
    body {
        background: #f0f2f5;
        font-family: 'Helvetica Neue', Arial, sans-serif;
    }

    .confirmation-card {
        max-width: 600px;
        background: linear-gradient(135deg, #ffffff, #f9f9f9);
        padding: 50px 35px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        margin: 80px auto;
        text-align: center;
        transition: transform 0.4s ease, box-shadow 0.4s ease;
    }

    .confirmation-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.12);
    }

    .confirmation-img {
        width: 180px;
        /* margin-bottom: 25px; */
        animation: popIn 0.8s ease-out;
    }

    @keyframes popIn {
        0% { transform: scale(0); opacity: 0; }
        70% { transform: scale(1.1); opacity: 1; }
        100% { transform: scale(1); }
    }

    .confirmation-title {
        font-size: 32px;
        font-weight: 700;
        color: #01AF31;
        margin-bottom: 20px;
    }

    .confirmation-message {
        font-size: 16px;
        color: #555;
        line-height: 1.6;
    }

    .confirmation-message b {
        color: #333;
    }

    @media (min-width: 768px) {
        .confirmation-img {
            width: 250px;
        }

        .confirmation-card {
            padding: 60px 50px;
        }
    }
</style>

<div class="confirmation-card">
    <img src="{{ asset('assets/egc_images/tick_mark.gif') }}" alt="Success" class="confirmation-img">
    <h6 class="confirmation-title">Registration Submitted!</h6>
    <p class="confirmation-message">
        Thank you, <b>{{ $applicant->applicant_name ?? 'Candidate' }}</b>, for submitting your registration.<br>
        Our HR team will review your application carefully and you will be updated on the next steps soon.
    </p>
    <p class="confirmation-message">
        Wishing you the very best in your career journey!
    </p>
</div>
<script src="https://cdn.jsdelivr.net/npm/@tsparticles/confetti@3.0.3/tsparticles.confetti.bundle.min.js"></script>
<audio id="clapSound" preload="auto">
    <source src="{{ asset('assets/audio/clap.mp3') }}" type="audio/mpeg">
</audio>
<script>
document.addEventListener("DOMContentLoaded", function () {

    const duration = 6* 1000; // 10 seconds
    const end = Date.now() + duration;

   

    // Confetti animation loop
    (function frame() {
        confetti({
            particleCount: 5,
            angle: 60,
            spread: 80,
            origin: { x: 0 }
        });

        confetti({
            particleCount: 5,
            angle: 120,
            spread: 80,
            origin: { x: 1 }
        });

        if (Date.now() < end) {
            requestAnimationFrame(frame);
        } else {
            sound.pause();
            sound.currentTime = 0; // stop sound after 10s
        }
    })();


    const sound = document.getElementById("clapSound");

    function playClapForFiveSeconds() {
        sound.currentTime = 0;
        sound.play().catch(() => {
            console.log("Autoplay blocked");
        });

        // Stop after 5 seconds
        setTimeout(() => {
            sound.pause();
            sound.currentTime = 0;
            sound.remove(); // completely remove audio element
        }, 5000);
    }

    // Try autoplay
    sound.play().then(() => {
        sound.pause();
        playClapForFiveSeconds();
    }).catch(() => {
        // If blocked, wait for first click
        document.body.addEventListener("click", playClapForFiveSeconds, { once: true });
    });



});
</script>

@endsection
