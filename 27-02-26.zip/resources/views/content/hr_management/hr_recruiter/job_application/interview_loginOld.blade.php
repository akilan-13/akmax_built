@extends('layouts/blankLayout')

@section('title', 'EGC Job Application')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

    <style>
body {
    background: radial-gradient(circle at top, #ff8c00 0%, #ab2b22 45%, #8f1f18 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Inter', system-ui, sans-serif;
}

.login-wrapper {
    max-width: 980px;
    width: 100%;
}

.login-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 40px 80px rgba(0,0,0,.25);
    /* overflow: hidden; */
}

.login-left {
    background: linear-gradient(160deg, #ab2b22, #ff8c00);
    color: #fff;
    padding: 70px 55px;
    display:flex;
    flex-direction:column;
    justify-content:start;
    align-items:center;
}

.login-left h2 {
    font-weight: 700;
    line-height: 1.2;
}

.login-left p {
    font-size: 15px;
    opacity: .95;
    margin-top: 16px;
}

.login-right {
    padding: 60px 55px;
    background: #fff;
}

.login-box {
    background: #ffffff;
    border-radius: 16px;
    padding: 40px;
    /* box-shadow: 0 20px 40px rgba(0,0,0,.08); */
}

.logo {
    max-width: 170px;
    margin-bottom: 20px;
}

.form-control {
    height: 52px;
    border-radius: 12px;
    font-size: 14px;
}

.form-control:focus {
    border-color: #ff8c00;
    box-shadow: 0 0 0 4px rgba(255,140,0,.2);
}

.btn-main {
    height: 52px;
    border-radius: 12px;
    font-weight: 600;
    background: linear-gradient(135deg, #ab2b22, #ff8c00);
    border: none;
    color: #fff;
}

.btn-main:disabled {
    opacity: .7;
}

.link-btn {
    font-size: 13px;
    color: #ab2b22;
    cursor: pointer;
    font-weight: 500;
}

.error-text {
    font-size: 13px;
    color: #d93025;
    margin-top: 8px;
}

.footer-text {
    font-size: 12px;
    color: #888;
    margin-top: 25px;
}
.reset_container{
    position: absolute;
    top: 40%;
    right: 15px;
     transform: translateY(50%);
    
}
.reset_otp_timer {
    font-size: 13px;
    padding: 2px 6px;
    background: #f1f1f1;
    border-radius: 6px;
   
}
.resent-otp-btn {
    cursor:pointer;
    right: 15px;
    font-size: 13px;
    padding: 2px 6px;
    background: #f1f1f1;
    border-radius: 6px;
}

   #job_description h1,h2,h3,h4,h5,{
        font-size: 0.6rem !important;
        margin-bottom:4px !important;
        
    }
    h3{
        color:white !important
    }

    .hide-scrollbar {
        scrollbar-width: none;          
        -ms-overflow-style: none;       
    }

    .hide-scrollbar::-webkit-scrollbar {
        display: none;                 
    }
.login-wrapper{
    display:flex;
    justify-content:center; 
    align-items:center;
}
.login-card{
    width:100%;
    height:100vh;
}
.logo_right{
    display:none;
}
@media (max-width: 1024px) {
    .login-card{
        width:100%;
        height:100vh;
    }

    #job_description h1,h2,h3,h4,h5{
        font-size: 0.6rem !important;
        margin-bottom:4px !important;
        
    }
}
@media (max-width: 767px) {
    .login-left {
        display: none;
    }
    .login-card{
        width:100%;
    }
    .logo_right{
        display:block;
    }
    .login-right {
        padding: 30px 20px;
    }
    .login-box {
        padding: 30px 22px;
    }
}

h3,h4{
   font-size: 0.9rem !important; 
}
</style>



@section('content')
<div class="login-wrapper container px-3">
    <div class="login-card row g-0">

        <!-- LEFT -->
        <div class="col-md-6 login-left px-6" id="leftBlock">

            <div class="leftLogo mt-8">
               @if ($schedule->entity_logo)
                    <img src="{{ asset('Entity_logos/' . $schedule->company_id . '/' . $schedule->entity_logo) }}"
                        class="logo bg-white px-2 py-1 rounded" alt="Logo">
                @else
                    <img src="{{ asset('assets/common/logo_full.png') }}" class="logo bg-white rounded" alt="Logo">
                @endif
                 
                
            </div>
            <span class="text-white fs-3 fw-bold">{{$schedule->job_role_name}}</span>
            <span class="text-white fs-4 fw-semibold">{{$schedule->interview_category_name}}</span>
            
            <div class="job-description mt-2 py-2 px-4"> 
                <div class="text-justify mt-3 text-white hide-scrollbar" style="max-height: 350px; overflow-y: auto;">
                    <div id="job_description" class="mb-1 text-white" style="font-size: 0.9rem; line-height: 1.5; word-wrap: break-word;">
                        {!! $schedule->job_description !!} 
                    </div>
                </div>
            </div>
            
        </div>

        <!-- RIGHT -->
        <div class="col-md-6 login-right align-self-center">
            <div class="login-box text-center">
                <div class="d-flex justify-content-center">
                @if ($schedule->entity_logo)
                    <img src="{{ asset('Entity_logos/' . $schedule->company_id . '/' . $schedule->entity_logo) }}"
                        class="logo logo_right" alt="Logo">
                @else
                    <img src="{{ asset('assets/common/logo_full.png') }}"
                        class="logo logo_right" alt="Logo">
                @endif
                </div>
                <h5 class="mb-4 fw-semibold">{{$schedule->interview_category_name}}</h5>
                <h6 class="mb-4 fw-semibold text-primary">{{$schedule->job_role_name}}</h6>
                
                
                <!-- LOGIN FORM -->
                <form id="loginForm">
                    @csrf

                    <!-- <div class="mb-3 text-start">
                        <label class="form-label">Full Name</label>
                        <input type="text" id="full_name" class="form-control" placeholder="Enter your full name" oninput="this.value=this.value.replace(/^\w/, txt=>txt.toUpperCase());" Autocomplete="off">
                        <div class="error-text d-none" id="errorMsg_name"></div>
                    </div> -->
                    <input type="hidden" id="job_request_id" name="job_request_id" value="{{ $schedule->sno }}">
                    <input type="hidden" id="interview_schedule_id" name="interview_schedule_id" value="{{ $schedule->schedule_id }}">
                    <input type="hidden" id="interview_schedule_stage_id" name="interview_schedule_stage_id" value="{{ $schedule->schedule_stage_id }}">
                    <div class="mb-3 text-start">
                        <label class="form-label">Mobile Number</label>
                        <input type="text" id="mobile" class="form-control" placeholder="Enter mobile number" maxLength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                         <div class="error-text d-none" id="errorMsg_mobile"></div>
                    </div>

                    <!-- <div class="mb-3 text-start">
                        <label class="form-label">Email Address</label>
                        <input type="email" id="email" class="form-control" placeholder="Enter email address" oninput="this.value=this.value.toLowerCase();">
                        <div class="error-text d-none" id="errorMsg_email"></div>
                    </div> -->

                    <!-- OTP FIELD -->
                    <div class="mb-3 text-start position-relative d-none" id="otpBlock">
                        <div>
                            <label class="form-label">OTP</label>
                            <input type="text" id="otp" class="form-control" placeholder="Enter OTP">
                            <div class="d-flex justify-content-between align-items-center reset_container">
                                
                                <div id="otpTimerBlock" class="reset_otp_timer d-none">
                                    <span id="otpTimer" class="fw-bold text-primary ">01:00</span>
                                </div>
                                <span class="link-btn text-primary resent-otp-btn" id="resendOtp" style="cursor:pointer; display:none;">
                                    Resend
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="error-text d-none" id="errorMsg_otp"></div>
                    <div class="error-text d-none" id="errorMsg"></div>

                    <button type="button" class="btn btn-main w-100 mt-3 text-white fw-bold border border-none" id="actionBtn">
                        Send OTP
                    </button>

                    
                </form>


                <div class="footer-text">
                    © {{ date('Y') }} EGC. All rights reserved.
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let otpSent = false;
let timerInterval;

// Function to handle the 60-second countdown
function startTimer() {
    let timeLeft = 60;
    const timerBlock = document.getElementById('otpTimerBlock');
    const resendBtn = document.getElementById('resendOtp');

    timerBlock.classList.add('active');
    resendBtn.classList.remove('d-none');
    resendBtn.style.display = 'none';

    clearInterval(timerInterval);

    timerInterval = setInterval(() => {
      timeLeft--;
      const min = Math.floor(timeLeft / 60);
      const sec = timeLeft % 60;
      timerBlock.textContent = `${min < 10 ? '0' : ''}${min}:${sec < 10 ? '0' : ''}${sec}`;

      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        timerBlock.textContent = '';
        timerBlock.classList.remove('active');
        resendBtn.style.display = 'inline';
      }
    }, 1000);
  }

// Resend OTP Click Event
$('#resendOtp').on('click', function() {
    const mobile = $('#mobile').val().trim();
    // const email = $('#email').val().trim();

    $(this).hide(); // Prevent multiple clicks
    
    $.ajax({
        url: '{{ route("interview.sendOtp") }}',
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',
            mobile: mobile,
             job_request_id: $('#job_request_id').val().trim(),
            interview_schedule_id: $('#interview_schedule_id').val().trim(),
            // email: email,
            resend: true // Optional flag for your backend
        },
        success(res) {
            startTimer(); // Restart timer on success
            $('#errorMsg_otp').addClass('d-none').text('');
        },
        error(xhr) {
            $('#resendOtp').show();
            showError('#errorMsg_otp', 'Failed to resend OTP. Try again.');
        }
    });
});

// Main Action Button (Send / Verify)
$('#actionBtn').on('click', function () {
   $('#errorMsg_name').addClass('d-none').text('');
    $('#errorMsg').addClass('d-none').text('');
    $('#errorMsg_mobile').addClass('d-none').text('');
    // $('#errorMsg_email').addClass('d-none').text('');
    $('#errorMsg_otp').addClass('d-none').text('');

    const interview_schedule_id = $('#interview_schedule_id').val().trim();
    const job_request_id = $('#job_request_id').val().trim();
    // const fullName = $('#full_name').val().trim();
    const mobile   = $('#mobile').val().trim();
    // const email    = $('#email').val().trim();
    const otp      = $('#otp').val().trim();

    // if (!fullName) return showError('#errorMsg_name','Please enter your full name');
    if (!mobile || !/^[6-9]\d{9}$/.test(mobile)) return showError('#errorMsg_mobile','Please enter valid mobile number');
    // if (!email || !/^\S+@\S+\.\S+$/.test(email)) return showError('#errorMsg_email','Please enter valid email address');
    if (otpSent && !otp){
         return showError('#errorMsg_otp','Please enter OTP');
    }
       
     
    const data = {
        _token: '{{ csrf_token() }}',
        // full_name: fullName,
        job_request_id: $('#job_request_id').val().trim(),
        interview_schedule_id: $('#interview_schedule_id').val().trim(),
        schedule_stage_id: $('#interview_schedule_stage_id').val().trim(),
        mobile: mobile,
        // email: email,
        otp: otp
    };

    $('#actionBtn').prop('disabled', true).text('Please wait...');

    $.ajax({
        url: otpSent ? '{{ route("interview.verifyOtp") }}' : '{{ route("interview.sendOtp") }}',
        type: 'POST',
        data: data,
        success(res) {
            if (!otpSent) {
                otpSent = true;
                $('#otpBlock').removeClass('d-none');
                $('#actionBtn').prop('disabled', false).text("Let's Start");
                startTimer(); // Start timer when first OTP is sent
            } else {
                window.location.href = res.redirect;
            }
        },
        error(xhr) {
            showError('#errorMsg', xhr.responseJSON?.message || 'Something went wrong');
            $('#actionBtn').prop('disabled', false).text(otpSent ? "Let's Start" : 'Send OTP');
        }
    });
});

function showError(id, msg) {
    $(id).removeClass('d-none').text(msg);
}
</script>

@endsection
