@extends('layouts/blankLayout')

<title>Offer Accepted | Elysium Groups</title>

<style>
:root {
    --primary: #b0302b;
    --secondary: #f59e0b;
    --success: #22c55e;
    --bg: #eef1f6;
    --card-radius: 26px;
}

body {
    background: var(--bg);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
}

/* WRAPPER */
.mobile-wrap {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
}

/* CARD */
.mobile-card {
    width: 100%;
    max-width: 360px;
    background: #fff;
    border-radius: var(--card-radius);
    box-shadow: 0 14px 40px rgba(0,0,0,.16);
    overflow: hidden;
}

/* HEADER */
.mobile-header {
    background: linear-gradient(160deg, var(--primary), var(--secondary));
    padding: 18px 16px 42px;
    text-align: center;
}

.mobile-header img {
    background: #fff;
    padding: 6px 14px;
    border-radius: 14px;
}

/* SUCCESS BADGE */
.success-badge {
    width: 76px;
    height: 76px;
    border-radius: 50%;
    background: #ecfdf5;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: -38px auto 10px;
}

.success-badge i {
    font-size: 36px;
    color: var(--success);
}

/* BODY */
.mobile-body {
    padding: 18px 18px 24px;
    text-align: center;
}

/* TEXT */
.title {
    font-size: 22px;
    font-weight: 700;
    color: var(--success);
    margin-bottom: 6px;
}

.subtitle {
    font-size: 14px;
    color: #6b7280;
    margin-bottom: 18px;
}

/* SECTION CARD */
.section {
    background: #f9fafb;
    border-radius: 18px;
    padding: 16px;
    text-align: left;
    font-size: 14px;
    margin-bottom: 14px;
}

.section strong {
    display: block;
    margin-bottom: 6px;
}

/* HR CARD */
.hr-card {
    background: #fff;
    border-radius: 18px;
    padding: 16px;
    border: 1px solid #fde68a;
}

.hr-card strong {
    display: block;
    margin-bottom: 8px;
    color: #92400e;
}

.hr-item {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 6px;
}

.hr-item a {
    color: #92400e;
    text-decoration: none;
    font-weight: 600;
}

/* FOOTER */
.mobile-footer {
    text-align: center;
    font-size: 12px;
    color: #6b7280;
    padding: 14px 10px 16px;
}

@media (max-width: 576px) {
    .hr-item {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 4px;
    }
    
    .hr-item a {
        color: #92400e;
        text-decoration: none;
        font-weight: 400;
        font-size: 12px;
    }
}

@media (min-width: 768px) {
    .mobile-card {
        width: 100%;
        max-width: 480px;
        background: #fff;
        border-radius: var(--card-radius);
        box-shadow: 0 14px 40px rgba(0,0,0,.16);
        overflow: hidden;
    }
}
</style>

@section('content')
<div class="mobile-wrap">
    <div class="mobile-card">

        {{-- HEADER --}}
        <div class="mobile-header">
            <img src="{{ asset('assets/common/logo_full.png') }}" height="34">
        </div>

        {{-- SUCCESS ICON --}}
        <div class="success-badge">
            <i class="mdi mdi-check-circle-outline"></i>
        </div>

        {{-- BODY --}}
        <div class="mobile-body">

            <div class="title">
                Welcome to Elysium Groups!
            </div>

            <div class="subtitle">
                We’re excited to begin your onboarding journey with us.
            </div>

            <div class="section">
                <strong>What happens next?</strong>
                Our HR team will contact you shortly with onboarding details,
                documentation, and next instructions.
            </div>

            <div class="hr-card">
                <strong>Need help? Contact HR</strong>

                <div class="hr-item">
                    📞 <a href="tel:{{ $hr_mobile }}">{{ $hr_mobile }}</a>
                </div>

                <div class="hr-item">
                    ✉️ <a href="mailto:{{ $hr_email }}" class="text-wrap">{{ $hr_email }}</a>
                </div>
            </div>

        </div>

        {{-- FOOTER --}}
        <div class="mobile-footer">
            © {{ date('Y') }} Elysium Groups
        </div>

    </div>
</div>
@endsection
