@extends('layouts/layoutMaster')

@section('title', 'Manage Training')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<!-- TOAST UI Image Editor CSS -->
<link rel="stylesheet"
      href="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.css"/>

<!-- Font Awesome (optional but recommended) -->
<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>
    #tui-image-editor-container {
        width: 100%;
        height: 100vh !important;
        border: 1px solid #e5e5e5;
        border-radius: 8px;
        overflow: hidden;
    }
    .tui-image-editor-main-container{
        background-color:white !important;
    }
    .tui-image-editor-header-logo{
        visibility:hidden;
    }
    .tui-image-editor-download-btn{
        display:none !important;
    }
</style>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Image Editor</h5>
    </div>

    <div class="card-body">
        <div class="mb-2">
            <input type="file" id="imageInput" class="form-control" accept="image/*">
        </div>

        <div id="tui-image-editor-container" ></div>

        <div class="mt-3 text-end">
            <button id="downloadBtn" class="btn btn-success">
                <i class="fa fa-download"></i> Download Edited Image
            </button>
        </div>
    </div>
</div>

<!-- ✅ REQUIRED: Fabric.js (MUST be before image editor) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js"></script>

<!-- TOAST UI Image Editor JS -->
<script src="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.js"></script>
<!-- TUI dependencies -->
<link rel="stylesheet" href="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.css">
<link rel="stylesheet" href="https://uicdn.toast.com/tui-color-picker/latest/tui-color-picker.css">

<script src="https://uicdn.toast.com/tui.code-snippet/latest/tui-code-snippet.js"></script>
<script src="https://uicdn.toast.com/tui-color-picker/latest/tui-color-picker.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js"></script>
<script src="https://uicdn.toast.com/tui-image-editor/latest/tui-image-editor.js"></script>


<script>
    let imageEditor = null;

    document.getElementById('imageInput').addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = function (event) {
            // Destroy previous instance
            if (imageEditor) {
                imageEditor.destroy();
                imageEditor = null;
            }

            imageEditor = new tui.ImageEditor('#tui-image-editor-container', {
                includeUI: {
                    loadImage: {
                        path: event.target.result,
                        name: file.name
                    },
                    theme: {},
                    menu: [
                        'crop',
                        'flip',
                        'rotate',
                        'draw',
                        'shape',
                        'icon',
                        'text',
                        'filter'
                    ],
                    initMenu: 'filter',
                    menuBarPosition: 'bottom'
                },
                cssMaxWidth: 1000,
                cssMaxHeight: 1000,
                usageStatistics: false
            });
        };

        reader.readAsDataURL(file);
    });

    document.getElementById('downloadBtn').addEventListener('click', function () {
        if (!imageEditor) {
            alert('Please upload and edit an image first.');
            return;
        }

        const dataURL = imageEditor.toDataURL({
            format: 'png',
            quality: 1
        });

        const link = document.createElement('a');
        link.href = dataURL;
        link.download = 'edited_image.png';
        link.click();
    });
</script>

@endsection