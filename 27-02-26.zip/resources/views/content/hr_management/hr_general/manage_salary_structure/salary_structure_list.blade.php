@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header pb-0 border-bottom d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Manage Salary Structure</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR General
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> --}}
            <a  href="{{ url('/hr_general/manage_salary_struture/add') }}" class="btn btn-sm fw-bold btn-primary text-white" >
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Salary Structure
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row gap-3">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12 ">
                <div class="d-flex align-items-center justify-content-between gap-2">
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input class="searchQueryInput" type="text" name="searchQueryInput"
                                placeholder="Enter Job Role/ Department" value=""
                                oninput="toggleIcons(this)" />
                            <a href="{{url('/hr_enroll/manage_staff')}}"
                            class="searchQuerySubmit searchIcon">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22"
                                        d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                        C16,11.11 15.41,12.59 14.44,13.73
                                        L14.71,14H15.5L20.5,19L19,20.5
                                        L14,15.5V14.71L13.73,14.44
                                        C12.59,15.41 11.11,16
                                        9.5,16A6.5,6.5 0 0,1 3,9.5
                                        A6.5,6.5 0 0,1 9.5,3
                                        M9.5,5C7,5 5,7 5,9.5
                                        C5,12 7,14 9.5,14
                                        C12,14 14,12 14,9.5
                                        C14,7 12,5 9.5,5Z"/>
                                </svg>
                            </a>
                            <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22"
                                        d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                        A8,8 0 0,0 4,12H1L4.89,16.89
                                        L9,12H6A6,6 0 0,1 12,6
                                        C13.66,6 15.14,6.69 16.22,7.78
                                        L17.65,6.35M19.11,7.11L15,12
                                        H18A6,6 0 0,1 12,18
                                        C10.34,18 8.86,17.31 7.78,16.22
                                        L6.35,17.65C7.8,19.1 9.79,20
                                        12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                  <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                      <thead>
                          <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                              <th class="min-w-50px">S.No</th>
                              <th class="min-w-50px">Job Role</th>
                              <th class="min-w-50px">Department</th>
                              <th class="min-w-50px">Division</th>
                              <th class="min-w-50px">Status</th>
                              <th class="min-w-50px">Action</th>
                          </tr>
                      </thead>
                      <tbody>
                          <tr>
                              <td>
                                  <label class="fw-medium fs-7">1</label>
                              </td>
                              <td>
                                  <label class="fs-7 fw-medium">Accounts Executive</label>
                                  <a href="javascipt:;" data-bs-toggle="tooltip"
                                      data-bs-placement="right" title="-">
                                      <i class="mdi mdi mdi-help-circle text-dark"></i>
                                  </a>
                              </td>
                              <td>
                                  <label class="fw-medium fs-7 text-black">Accounts and Finance Department</label>
                              </td>
                              <td>
                                  <label class="fw-medium fs-7 text-black">Accounts and Finance</label>
                              </td>
                              <td>
                                  <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                          <span class="switch-on"></span>
                                          <span class="switch-off"></span>
                                      </span>
                                  </label>
                              </td>
                              <td>
                                  <span class="text-end">
                                      <a href="{{ url('/hr_general/manage_salary_struture/edit/1') }}"
                                          data-bs-toggle="tooltip" data-bs-placement="bottom"
                                          title="Edit">
                                          <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                      </a>
                                      <a href="javascript:;" class="btn btn-icon btn-sm"
                                          data-bs-toggle="modal"
                                          data-bs-target="#kt_modal_delete_salary_structure"
                                          data-bs-toggle="tooltip" data-bs-placement="bottom"
                                          title="Delete">
                                          <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                      </a>
                                  </span>
                              </td>
                          </tr>
                          <tr>
                              <td>
                                  <label class="fw-medium fs-7">2</label>
                              </td>
                              <td>
                                  <label class="fs-7 fw-medium">HR VP</label>
                                  <a href="javascipt:;" data-bs-toggle="tooltip"
                                      data-bs-placement="right" title="-">
                                      <i class="mdi mdi mdi-help-circle text-dark"></i>
                                  </a>
                              </td>
                              <td>
                                  <label class="fw-medium fs-7 text-black">HR Department</label>
                              </td>
                              <td>
                                  <label class="fw-medium fs-7 text-black">HR General</label>
                              </td>
                              <td>
                                  <label class="switch switch-square">
                                      <input type="checkbox" class="switch-input" checked />
                                      <span class="switch-toggle-slider">
                                          <span class="switch-on"></span>
                                          <span class="switch-off"></span>
                                      </span>
                                  </label>
                              </td>
                              <td>
                                  <span class="text-end">
                                      <a href="{{ url('/hr_general/manage_salary_struture/edit/1') }}"
                                          data-bs-toggle="tooltip" data-bs-placement="bottom"
                                          title="Edit">
                                          <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                      </a>
                                      <a href="javascript:;" class="btn btn-icon btn-sm"
                                          data-bs-toggle="modal"
                                          data-bs-target="#kt_modal_delete_salary_structure"
                                          data-bs-toggle="tooltip" data-bs-placement="bottom"
                                          title="Delete">
                                          <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                      </a>
                                  </span>
                              </td>
                          </tr>
                      </tbody>
                  </table>
              </div>
        </div>
    </div>
</div>



<!--begin::Modal - Add Salary Structure -->
<div class="modal fade" id="kt_modal_add_salary_structure" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Salary Structure</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="row">
                    <!-- Basic -->
                        <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Company</label>
                          <select id="Company" name="Company" class="select3 form-select required-field">
                              <option value="">Select Company</option>
                              <option value="1">EAPL</option>
                              <option value="2">ETPL</option>
                              <option value="3">EIBS</option>
                              <option value="4">EPRO</option>
                          </select>
                        </div>
                        <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                          <select id="Entity" name="Entity" class="select3 form-select required-field">
                              <option value="">Select Entity</option>
                              <option value="1">Phdizone</option>
                              <option value="2">Click My Project</option>
                              <option value="3">My Project Bazaar</option>
                          </select>
                        </div>
                        <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Department</label>
                          <select id="dept" name="dept" class="select3 form-select required-field">
                              <option value="">Select Department</option>
                              <option value="1">HR Department</option>
                              <option value="2">Corporate Administration Department</option>
                              <option value="3">IT Department</option>
                              <option value="4">Accounts and Finance Department</option>
                          </select>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division</label>
                            <select id="division" name="division" class="select3 form-select required-field">
                                <option value="">Select Division</option>
                                <option value="1">HR Recruitment</option>
                                <option value="2">HR Training</option>
                                <option value="3">HR Operation</option>
                                <option value="4">Maintenance</option>
                            </select>
                        </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job role<span class="text-danger">*</span></label>
                        <select id="job_role" name="job_role" class="select3 form-select required-field">
                            <option value="">Select Job Role</option>
                            <option value="1">HR Executive</option>
                            <option value="2">HR Recruiter</option>
                            <option value="3">Senior HR Executive</option>
                            <option value="4">HR Manager</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2">
                        <div id="component_container" class="scroll-y max-h-250px" style="overflow-x: hidden;">
                            <div class="component-block col-lg-12 mb-2">
                                <div class="row">
                                    <div class="col-lg-10 mb-1">
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Component</label>
                                                <select name="component[]" class="form-select">
                                                    <option value="">Select Component</option>
                                                    <option value="Basic">Basic</option>
                                                    <option value="HRA">HRA</option>
                                                    <option value="PF">PF</option>
                                                    <option value="ESI">ESI</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Type</label>
                                                <select name="type[]" class="form-select">
                                                    <option value="">Select Type</option>
                                                    <option value="Earning">Earning</option>
                                                    <option value="Deduction">Deduction</option>
                                                    <option value="Variable">Variable</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Calculation Type</label>
                                                <select name="calc_type[]" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="Fixed">Fixed</option>
                                                    <option value="%Basic">% Basic</option>
                                                    <option value="%Gross">% Gross</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Value</label>
                                                <input type="text" name="value[]" class="form-control" placeholder="Enter Value">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 d-flex align-items-center justify-content-center">
                                        <button type="button" class="btn btn-danger btn-sm delete-row">
                                            <i class="mdi mdi-trash-can-outline fs-7 text-white"></i>
                                        </button>
                                    </div>
                                </div>
                                <hr>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary btn-sm" id="add_row_btn">
                                <i class="mdi mdi-plus fs-7 text-white"></i> Add More
                            </button>
                        </div>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex justify-content-between align-items-center">
                        <label class="fw-semibold fs-5">Salary Rules</label>
                        <button type="button" class="btn btn-primary btn-sm" id="add_rule_map_btn">
                            <i class="mdi mdi-plus"></i> Add Rule
                        </button>
                    </div>
                    <div class="col-lg-12 scroll-y max-h-200px" id="rule_map_container">
                        <div class="row rule-map-row mb-2">
                            <div class="col-lg-5">
                                <label class="fw-semibold">Rule</label>
                                <select class="form-select rule-select">
                                    <option value="">Select Rule</option>
                                    <option value="1">Late Count Rule</option>
                                    <option value="2">Overtime Rule</option>
                                    <option value="3">Travel Allowance Rule</option>
                                </select>
                            </div>
                            <div class="col-lg-3">
                                <label class="fw-semibold">Priority</label>
                                <input type="number" class="form-control priority" value="1">
                            </div>
                            <div class="col-lg-2 d-flex align-items-end justify-content-center">
                                <button class="btn btn-danger btn-sm delete-rule-map">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary" data-bs-dismiss="modal">Create Salary Structure</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Salary Structure-->


<!--begin::Modal - Update Salary Structure -->
<div class="modal fade" id="kt_modal_edit_salary_structure" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Salary Structure</h3>
                </div>
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">✕</div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row">
                    <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Company</label>
                      <select id="CompanyEdit" name="CompanyEdit" class="select3 form-select required-field">
                          <option value="">Select Company</option>
                          <option value="1">EAPL</option>
                          <option value="2"selected>ETPL</option>
                          <option value="3">EIBS</option>
                          <option value="4">EPRO</option>
                      </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                      <select id="EntityEdit" name="EntityEdit" class="select3 form-select required-field">
                          <option value="">Select Entity</option>
                          <option value="1"selected>Phdizone</option>
                          <option value="2">Click My Project</option>
                          <option value="3">My Project Bazaar</option>
                      </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="fw-semibold">Department</label>
                        <select class="form-select">
                            <option value="1">HR Department</option>
                            <option value="2" selected>Corporate Administration</option>
                            <option value="3">IT Department</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="fw-semibold">Division</label>
                        <select class="form-select">
                            <option value="1">HR Recruitment</option>
                            <option value="2" selected>HR Training</option>
                            <option value="3">HR Operation</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="fw-semibold">Job Role</label>
                        <input type="text" class="form-control" value="HR Executive">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="fw-semibold">Description</label>
                        <textarea class="form-control">Default structure</textarea>
                    </div>
                    <hr>
                    <div class="col-lg-12">
                        <label class="fs-6 fw-semibold text-black">Salary Components</label>
                        <div id="edit_component_container" class="scroll-y max-h-250px" style="overflow-x:hidden;">
                            <div class="edit-component-block col-lg-12 mb-2">
                                <div class="row">
                                    <div class="col-lg-10">
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Component</label>
                                                <select name="component[]" class="form-select">
                                                    <option value="Basic" selected>Basic</option>
                                                    <option value="HRA">HRA</option>
                                                    <option value="PF">PF</option>
                                                    <option value="ESI">ESI</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Type</label>
                                                <select name="type[]" class="form-select">
                                                    <option value="Earning" selected>Earning</option>
                                                    <option value="Deduction">Deduction</option>
                                                    <option value="Variable">Variable</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Calculation Type</label>
                                                <select name="calc_type[]" class="form-select">
                                                    <option value="Fixed" selected>Fixed</option>
                                                    <option value="%Basic">% Basic</option>
                                                    <option value="%Gross">% Gross</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="fw-semibold">Value</label>
                                                <input type="text" name="value[]" class="form-control" value="25000">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 d-flex align-items-center justify-content-center">
                                        <button type="button" class="btn btn-danger btn-sm edit-delete-row">
                                            <i class="mdi mdi-trash-can-outline text-white"></i>
                                        </button>
                                    </div>
                                </div>
                                <hr>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm mt-2" id="edit_add_row_btn">
                            <i class="mdi mdi-plus text-white"></i> Add More
                        </button>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex justify-content-between align-items-center">
                        <label class="fw-semibold fs-5">Salary Rules</label>
                        <button type="button" class="btn btn-primary btn-sm" id="edit_rule_map_btn">
                            <i class="mdi mdi-plus"></i> Add Rule
                        </button>
                    </div>
                    <div class="col-lg-12 scroll-y max-h-200px" id="rule_map_container_edit">
                        <div class="row rule-map-row mb-2">
                            <div class="col-lg-5">
                                <label class="fw-semibold">Rule</label>
                                <select class="form-select rule-select">
                                    <option value="">Select Rule</option>
                                    <option value="1">Late Count Rule</option>
                                    <option value="2">Overtime Rule</option>
                                    <option value="3">Travel Allowance Rule</option>
                                </select>
                            </div>
                            <div class="col-lg-3">
                                <label class="fw-semibold">Priority</label>
                                <input type="number" class="form-control priority" value="1">
                            </div>
                            <div class="col-lg-2 d-flex align-items-end justify-content-center">
                                <button class="btn btn-danger btn-sm delete-rule-map">
                                    <i class="mdi mdi-trash-can-outline"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between mt-4">
                    <button type="reset" class="btn btn-outline-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary">Update Salary Structure</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::Modal - Update Salary Structure-->

<!--begin::Modal - Delete Salary Structure-->
<div class="modal fade" id="kt_modal_delete_salary_structure" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">HR Executive </b>
                    Salary Structure ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Salary Structure-->




<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr CSS from CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>

<script>
    $(document).ready(function () {

        $('#add_row_btn').click(function () {

            let block = $('.component-block:first').clone();

            block.find('select').val('');
            block.find('input').val('');

            $('#component_container').append(block);
        });

        $(document).on('click', '.delete-row', function () {

            if ($('.component-block').length > 1) {
                $(this).closest('.component-block').remove();
            } else {
                alert('At least one row required');
            }

        });
    });

    $('#edit_add_row_btn').click(function () {

        let block = $('.edit-component-block:first').clone();

        block.find('select').val('');
        block.find('input').val('');

        $('#edit_component_container').append(block);
    });


    // DELETE ROW (EDIT)
    $(document).on('click', '.edit-delete-row', function () {

        if ($('.edit-component-block').length > 1) {
            $(this).closest('.edit-component-block').remove();
        } else {
            alert('At least one row required');
        }

    });
</script>

<script>
    $(document).ready(function () {

        // Add Rule Map
        $('#add_rule_map_btn').on('click', function () {
            let $container = $('#rule_map_container');
            let $clone = $container.find('.rule-map-row').first().clone();

            $clone.find('select').val('');
            $clone.find('input').val('1');

            $container.append($clone);
        });

        // Delete Rule Map
        $(document).on('click', '.delete-rule-map', function () {
            let $container = $('#rule_map_container');

            if ($container.find('.rule-map-row').length > 1) {
                $(this).closest('.rule-map-row').remove();
            }
        });

    });
</script>

<script>
    $(document).ready(function () {

        // Add Rule Map
        $('#edit_rule_map_btn').on('click', function () {
            let $container = $('#rule_map_container_edit');
            let $clone = $container.find('.rule-map-row').first().clone();

            $clone.find('select').val('');
            $clone.find('input').val('1');

            $container.append($clone);
        });

        // Delete Rule Map
        $(document).on('click', '.delete-rule-map', function () {
            let $container = $('#rule_map_container_edit');

            if ($container.find('.rule-map-row').length > 1) {
                $(this).closest('.rule-map-row').remove();
            }
        });

    });
</script>

@endsection
