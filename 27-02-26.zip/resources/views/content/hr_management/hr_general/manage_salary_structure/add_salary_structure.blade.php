@extends('layouts/layoutMaster')

@section('title', 'Add Staff')

@section('vendor-style')
@vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
    'resources/assets/vendor/libs/dropzone/dropzone.scss',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/sortablejs/sortable.js',
    'resources/assets/vendor/libs/dropzone/dropzone.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
@endsection

@section('content')

<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    /* Completed step */
    .bs-stepper-header .step.crossed .step-trigger .avatar .avatar-initial {
        background-color: #28a745 !important;
        color: #fff !important;
    }

    /* Active/current step */
    .bs-stepper-header .step.active .step-trigger .avatar .avatar-initial {
        background-color: #0d6efd !important;
    }

    /* Pending step */
    .bs-stepper-header .step.disabled .step-trigger .avatar .avatar-initial {
        background-color: #e9ecef;
        color: #6c757d;
        pointer-events: none;
    }
</style>

<div class="card card-action mb-2">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Add Salary Structure</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR General
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="card mb-2">
  <div class="card-body ">
      <div class="row">
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Company</label>
          <select id="Company" name="Company" class="select3 form-select required-field">
              <option value="">Select Company</option>
              <option value="1">EAPL</option>
              <option value="2">ETPL</option>
              <option value="3">EIBS</option>
              <option value="4">EPRO</option>
          </select>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
          <select id="Entity" name="Entity" class="select3 form-select required-field">
              <option value="">Select Entity</option>
              <option value="1">Phdizone</option>
              <option value="2">Click My Project</option>
              <option value="3">My Project Bazaar</option>
          </select>
        </div>
        <div class="col-lg-4 mb-3">
          <label class="text-black mb-1 fs-6 fw-semibold">Department</label>
          <select id="dept" name="dept" class="select3 form-select required-field">
              <option value="">Select Department</option>
              <option value="1">HR Department</option>
              <option value="2">Corporate Administration Department</option>
              <option value="3">IT Department</option>
              <option value="4">Accounts and Finance Department</option>
          </select>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-black mb-1 fs-6 fw-semibold">Division</label>
            <select id="division" name="division" class="select3 form-select required-field">
                <option value="">Select Division</option>
                <option value="1">HR Recruitment</option>
                <option value="2">HR Training</option>
                <option value="3">HR Operation</option>
                <option value="4">Maintenance</option>
            </select>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Job role<span class="text-danger">*</span></label>
            <select id="job_role" name="job_role" class="select3 form-select required-field">
                <option value="">Select Job Role</option>
                <option value="1">HR Executive</option>
                <option value="2">HR Recruiter</option>
                <option value="3">Senior HR Executive</option>
                <option value="4">HR Manager</option>
            </select>
        </div>
        <div class="col-lg-4 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
            <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
        </div>
      </div>
  </div>
</div>


<div class="card mb-2">
  <div class="card-body ">
      <div class="row">
        <div class="col-lg-12 mb-2 d-flex justify-content-between align-items-center">
            <label class="fw-semibold fs-5">Salary Component</label>
            <button type="button" class="btn btn-primary btn-sm" id="add_row_btn">
                <i class="mdi mdi-plus fs-7 text-white"></i> Add More
            </button>
        </div>
        <div class="col-lg-12 mb-2">
            <div id="component_container" class="scroll-y max-h-250px" style="overflow-x: hidden;">
                <div class="component-block col-lg-12 mb-2">
                    <div class="row">
                        <div class="col-lg-10 mb-1">
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label class="fw-semibold">Component</label>
                                    <select name="component[]" class="form-select">
                                        <option value="">Select Component</option>
                                        <option value="Basic">Basic</option>
                                        <option value="HRA">HRA</option>
                                        <option value="PF">PF</option>
                                        <option value="ESI">ESI</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="fw-semibold">Type</label>
                                    <select name="type[]" class="form-select">
                                        <option value="">Select Type</option>
                                        <option value="Earning">Earning</option>
                                        <option value="Deduction">Deduction</option>
                                        <option value="Variable">Variable</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="fw-semibold">Calculation Type</label>
                                    <select name="calc_type[]" class="form-select">
                                        <option value="">Select</option>
                                        <option value="Fixed">Fixed</option>
                                        <option value="%Basic">% Basic</option>
                                        <option value="%Gross">% Gross</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="fw-semibold">Value</label>
                                    <input type="text" name="value[]" class="form-control" placeholder="Enter Value">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 d-flex align-items-center justify-content-center">
                            <button type="button" class="btn btn-danger btn-sm delete-row">
                                <i class="mdi mdi-trash-can-outline fs-7 text-white"></i>
                            </button>
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
            {{-- <div class="mt-2">
                <button type="button" class="btn btn-primary btn-sm" id="add_row_btn">
                    <i class="mdi mdi-plus fs-7 text-white"></i> Add More
                </button>
            </div> --}}
        </div>
      </div>
  </div>
</div>


<div class="card mb-2">
  <div class="card-body ">
      <div class="row">
        <div class="col-lg-12 mb-2 d-flex justify-content-between align-items-center">
            <label class="fw-semibold fs-5">Salary Rules</label>
            <button type="button" class="btn btn-primary btn-sm" id="add_rule_map_btn">
                <i class="mdi mdi-plus"></i> Add Rule
            </button>
        </div>
        <div class="col-lg-12 scroll-y max-h-200px" id="rule_map_container">
            <div class="row rule-map-row mb-2">
                <div class="col-lg-6">
                    <label class="fw-semibold">Rule</label>
                    <select class="form-select rule-select">
                      <option value="">Select Rule</option>
                      <option value="1">Late Count Rule</option>
                      <option value="2">Overtime Rule</option>
                      <option value="3">Travel Allowance Rule</option>
                    </select>
                </div>
                <div class="col-lg-4">
                    <label class="fw-semibold">Priority</label>
                    <input type="number" class="form-control priority" value="1">
                </div>
                <div class="col-lg-2 d-flex align-items-end justify-content-center">
                    <button class="btn btn-danger btn-sm delete-rule-map">
                        <i class="mdi mdi-trash-can-outline"></i>
                    </button>
                </div>
                <hr class="my-5">
            </div>

        </div>
      </div>

  </div>

</div>

  <div class="d-flex justify-content-between align-items-center mt-4">
    <a href="{{ url('/hr_general/manage_salary_struture') }}">
      <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
    </a>
    <a href="{{ url('/hr_general/manage_salary_struture') }}">
      <button type="button" id="create_sms_btn" class="btn btn-primary" data-bs-dismiss="modal">Create Salary Structure</button>
    </a>
  </div>


<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr CSS from CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>

<script>
    $(document).ready(function () {

        $('#add_row_btn').click(function () {

            let block = $('.component-block:first').clone();

            block.find('select').val('');
            block.find('input').val('');

            $('#component_container').append(block);
        });

        $(document).on('click', '.delete-row', function () {

            if ($('.component-block').length > 1) {
                $(this).closest('.component-block').remove();
            } else {
                alert('At least one row required');
            }

        });
    });

    $('#edit_add_row_btn').click(function () {

        let block = $('.edit-component-block:first').clone();

        block.find('select').val('');
        block.find('input').val('');

        $('#edit_component_container').append(block);
    });


    // DELETE ROW (EDIT)
    $(document).on('click', '.edit-delete-row', function () {

        if ($('.edit-component-block').length > 1) {
            $(this).closest('.edit-component-block').remove();
        } else {
            alert('At least one row required');
        }

    });
</script>

<script>
    $(document).ready(function () {

        // Add Rule Map
        $('#add_rule_map_btn').on('click', function () {
            let $container = $('#rule_map_container');
            let $clone = $container.find('.rule-map-row').first().clone();

            $clone.find('select').val('');
            $clone.find('input').val('1');

            $container.append($clone);
        });

        // Delete Rule Map
        $(document).on('click', '.delete-rule-map', function () {
            let $container = $('#rule_map_container');

            if ($container.find('.rule-map-row').length > 1) {
                $(this).closest('.rule-map-row').remove();
            }
        });

    });
</script>

<script>
    $(document).ready(function () {

        // Add Rule Map
        $('#edit_rule_map_btn').on('click', function () {
            let $container = $('#rule_map_container_edit');
            let $clone = $container.find('.rule-map-row').first().clone();

            $clone.find('select').val('');
            $clone.find('input').val('1');

            $container.append($clone);
        });

        // Delete Rule Map
        $(document).on('click', '.delete-rule-map', function () {
            let $container = $('#rule_map_container_edit');

            if ($container.find('.rule-map-row').length > 1) {
                $(this).closest('.rule-map-row').remove();
            }
        });

    });
</script>


@endsection
