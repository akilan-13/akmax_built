<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Employee Payslip - Elysium Group</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap"
        rel="stylesheet" />

    <style>
        body {
            font-family: 'Public Sans', sans-serif;
            /* background-color: #f8f6f6; */
        }

        .primary-bg {
            background-color: #96261E !important;
        }

        .primary-text {
            color: #96261E !important;
        }

        .summary-box {
            border: 1px solid #dee2e6;
            border-radius: 12px;
            padding: 20px;
        }

        .print-container {
            /* background: #ffffff; */
            border-radius: 16px;
            overflow: hidden;
            padding-top: 110px !important;
            background-image: url('{{ asset("assets/egc_images/payslip_bg.jpg") }}') !important;
            background-size: 100% 100% !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
        }

        @page {
            size: A4;
            margin: 0;
        }

        /* ================= PRINT STYLES ================= */
        @media print {

            html,
            body {
                height: 100%;
                width: 100%;
            }

            body {
                margin: 0 !important;
                padding: 0 !important;
                zoom: 0.78 !important;

                background-image: url('{{ asset("assets/egc_images/payslip_bg.jpg") }}') !important;
                background-size: 100% 100% !important;
                background-position: center !important;
                background-repeat: no-repeat !important;

                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* REMOVE BOOTSTRAP CONTAINER PADDING */
            .container {
                max-width: 100% !important;
                padding: 0 !important;
            }

            /* REMOVE ROW NEGATIVE MARGINS */
            .row {
                margin-left: 0 !important;
                margin-right: 0 !important;
            }

            .print-container {
                box-shadow: none !important;
                background: transparent !important;
                margin-top: 150px;
                width: 100% !important;
                padding-top: 0px !important;
            }

            /* Reduce vertical paddings */
            .p-4 { padding: 10px !important; }
            .py-3 { padding-top: 8px !important; padding-bottom: 8px !important; }

            /* Reduce row gaps */
            .g-4 { row-gap: 10px !important; column-gap: 10px !important; }

            /* Reduce table spacing */
            .table td, 
            .table th {
                padding: 6px 8px !important;
            }

            /* Reduce heading sizes */
            h3 { font-size: 22px !important; }
            .fs-4 { font-size: 18px !important; }
            .fs-3 { font-size: 20px !important; }

            /* Avoid page breaks */
            .print-container,
            .row,
            table {
                page-break-inside: avoid !important;
            }
        }
    </style>
</head>

<body>
    <div class="container py-3">
        <div class="print-container shadow-lg px-4">
            <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="fw-bold mb-1" style="font-size: 28px;">PAYSLIP</h3>
                    <p class="text-muted mb-0">Jan 2026</p>
                </div>
                <div class="text-end">
                    <span class="badge rounded-pill px-4 py-2 fw-bold"
                        style="background-color: rgba(150,38,30,0.1); color:#96261E;">
                        PAID
                    </span>
                </div>
            </div>
            <div class="row g-2 p-4 bg-light">
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Employee Name</small>
                    <div class="fw-bold">Paviyaa</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Employee ID</small>
                    <div class="fw-bold">EGC001201</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Department</small>
                    <div class="fw-bold">Production</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Designation</small>
                    <div class="fw-bold">Developer</div>
                </div>
            </div>
            <div class="row g-2 p-4">
                <div class="col-4">
                    <div class="summary-box">
                        <small class="text-muted fw-bold">Gross Salary</small>
                        <div class="fw-bold fs-4">₹ 6,000.00</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="summary-box">
                        <small class="text-muted fw-bold">Total Deductions</small>
                        <div class="fw-bold fs-4">₹ 175.00</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="summary-box primary-bg text-white">
                        <small class="fw-bold">Net Payable</small>
                        <div class="fw-bold fs-3">₹ 5,825.00</div>
                    </div>
                </div>
            </div>
            <div class="px-4 pb-4">
                <div class="row g-2">
                    <div class="col-6">
                        <small class="text-uppercase text-muted fw-bold">Earnings</small>
                        <table class="table table-bordered mt-2">
                            <tr>
                                <td>Base Salary</td>
                                <td class="text-end">₹ 5,000.00</td>
                            </tr>
                            <tr>
                                <td>Monthly Incentive</td>
                                <td class="text-end">₹ 500.00</td>
                            </tr>
                            <tr>
                                <td>Travel Allowance</td>
                                <td class="text-end">₹ 200.00</td>
                            </tr>
                            <tr class="fw-bold">
                                <td>Total Earnings</td>
                                <td class="text-end text-success">₹ 6,000.00</td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-6">
                        <small class="text-uppercase text-muted fw-bold">Deductions</small>
                        <table class="table table-bordered mt-2">
                            <tr>
                                <td>LOP</td>
                                <td class="text-end">₹ 100.00</td>
                            </tr>
                            <tr>
                                <td>Professional Tax</td>
                                <td class="text-end">₹ 50.00</td>
                            </tr>
                            <tr>
                                <td>Other</td>
                                <td class="text-end">₹ 25.00</td>
                            </tr>
                            <tr class="fw-bold">
                                <td>Total Deductions</td>
                                <td class="text-end text-danger">₹ 175.00</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="mx-4 mb-4 p-3 border rounded text-center"
                style="background-color: rgba(150,38,30,0.05);">
                <div class="row">
                    <div class="col-3">
                        <small class="text-muted fw-bold">Present</small>
                        <div class="fw-bold primary-text">21 / 22</div>
                    </div>
                    <div class="col-3">
                        <small class="text-muted fw-bold">Late</small>
                        <div class="fw-bold">01</div>
                    </div>
                    <div class="col-3">
                        <small class="text-muted fw-bold">LOP</small>
                        <div class="fw-bold text-danger">01</div>
                    </div>
                    <div class="col-3">
                        <small class="text-muted fw-bold">Overtime</small>
                        <div class="fw-bold text-success">0.0 Hrs</div>
                    </div>
                </div>
            </div>
            <div class="p-4 border-top">
                <div class="row text-center">
                    <div class="col-6">
                        <canvas width="400" height="50"></canvas>
                        <div class="pt-2">
                            <div class="fw-bold">Paviyaa</div>
                            <small class="text-muted text-uppercase">Employee Signature</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <canvas width="400" height="50"></canvas>
                        <div class="pt-2">
                            <div class="fw-bold">Kani Mithra</div>
                            <small class="text-muted text-uppercase">Authorized Signatory</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>