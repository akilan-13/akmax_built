@extends('layouts/layoutMaster')

@section('title', 'Manage Payroll')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
//  'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
//  'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'],)
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js'])
@endsection

@section('content')

<style>
    .sticky_table thead th:not(:first-child):not(:last-child) {
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
        line-height: 1.2;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a {
        display: flex;
        flex-direction: column;
        text-decoration: none;
        color: inherit;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:first-child {
        font-weight: 600;
        font-size: 14px;

    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:last-child {
        font-size: 12px;
        color: #ccc;

    }

    .sticky_table tbody td {
        vertical-align: middle;
    }

    .sticky_table tbody td:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #fff;
    }

    .sticky_table thead th:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ab2b22;
    }


    .sticky_table tbody td:last-child {
        position: sticky;
        right: 0;
        z-index: 2;
        background: #fff;
    }

    .sticky_table thead th:last-child {
        position: sticky;
        right: 0;
        z-index: 2;
        background: #ab2b22;
    }

    .sticky_table tbody td:nth-last-child(2) {
        position: sticky;
        right: 100px;
        z-index: 3;
        background: #fff;
    }

    .sticky_table thead th:nth-last-child(2) {
        position: sticky;
        right: 100px;
        z-index: 3;
        background: #ab2b22;
    }

    .sticky_table tbody td:nth-last-child(3) {
        position: sticky;
        right: 200px;
        z-index: 3;
        background: #fff;
    }

    .sticky_table thead th:nth-last-child(3) {
        position: sticky;
        right: 200px;
        z-index: 3;
        background: #ab2b22;
    }
</style>

<style>
.attendance-cards .card-attendance {
width: 150px; /* fixed width for all cards */
min-width: 150px;
max-width: 150px;
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
padding: 0.5rem; /* smaller padding */
gap: 0.25rem;
}

.attendance-cards .percent-value {
font-size: 1.2rem; /* reduced font */
line-height: 1.2;
word-wrap: break-word;
}
</style>

<style>
.team-card {
width: 180px;
background-color: #fff;
border-radius: 0.4rem;
border: 1px solid #e0e0e0;
transition: transform 0.2s, box-shadow 0.2s;
cursor: pointer;
}


.role-indicator {
width: 40px;
height: 40px;
}

.role-abbr {
font-size: 0.8rem;
}

.team-info .fs-6 {
margin-bottom: 0.1rem;
font-size: 0.95rem !important;
}

.team-info .fs-8 {
font-size: 0.75rem;
color: #6c757d;
}
</style>


<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
            <h5 class="card-title mb-1">Manage Payroll</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element mb-1 gap-2 text-center">
            <div class="d-flex justify-content-end align-items-center flex-wrap gap-2 mb-1">
                <div class="d-flex flex-row align-items-center justify-content-between gap-2">
                    <ul class="nav nav-pills justify-content-end" role="tablist">
                        <li class="nav-item me-1">
                            <a class="nav-link px-3" href="#" id="prevMonth">
                            <div class="text-center">
                                <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                            </div>
                            </a>
                        </li>
                        <li class="nav-item me-1 mt-1">
                            <a class="nav-link active px-3" href="#">
                            <div class="text-center">
                                <span class="fs-6 fw-semibold text-white text-capitalize" id="currentMonth"><?php echo date('M-Y') ?></span>
                            </div>
                            </a>
                        </li>
                        <li class="nav-item me-1">
                            <a class="nav-link px-3" href="#" id="nextMonth">
                            <div class="text-center">
                                <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                            </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-2">
        <div class="row pt-4">
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Company<span
                                class="text-danger">*</span></label>
                        <select class="select3 form-select" id="Company">
                            <option value="">Select Company</option>
                            <option value="1">Elysium Technologies</option>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Entity<span
                                class="text-danger">*</span></label>
                        <select class="select3 form-select" id="Entity">
                            <option value="">Select Entity</option>
                            <option value="1">PhDiZone</option>
                            <option value="2">EIBS</option>
                            <option value="3">Academy</option>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white fs-7 mt-6" data-bs-toggle="modal" data-bs-target="#kt_modal_generate_payroll">
                            Generate Payroll
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 attendance-cards d-flex align-items-center justify-content-end gap-2">
                <div class="d-flex flex-column gap-1 mb-0 border border-success p-2 rounded bg-label-success text-center card-attendance">
                    <label class="fw-bold text-black percent-value">51</label>
                    <label class="text-black fw-semibold fs-8">Total Staff</label>
                </div>
                <div class="d-flex flex-column gap-1 mb-0 border border-danger p-2 rounded bg-label-danger text-center card-attendance">
                    <label class="fw-bold text-black percent-value">₹ 7,02,500</label>
                    <label class="text-black fw-semibold fs-8">Total Amount</label>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-12 mt-2">
                <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                            <th class="min-w-100px">Staff</th>
                            <th class="min-w-50px">Present <br>(Days)</th>
                            <th class="min-w-50px">Late<br>(Days)</th>
                            <th class="min-w-50px">LOP<br>(Days)</th>
                            <th class="min-w-50px">OD<br>(₹)</th>
                            <th class="min-w-50px">Travel<br>(₹)</th>
                            <th class="min-w-50px">Incentive<br>(₹)</th>
                            <th class="min-w-50px">Increment<br>(₹)</th>
                            <th class="min-w-50px">Deduction<br>(₹)</th>
                            <th class="min-w-50px">Net Salary<br>(₹)</th>
                            <th class="min-w-100px">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7 attendance-body">
                        <tr>
                            <td>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="avatar-xl mt-3">
                                        <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user image"
                                            class="w-px-50 h-auto rounded-circle ">
                                    </div>
                                    <div
                                        class=" d-flex flex-column justify-content-between align-items-start gap-1">
                                        <a href="javascript:;" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_individual_staff_attendance">
                                            <span class="fs-7 me-1 text-black">Arun MK</span>
                                        </a>
                                        <span class="badge bg-warning text-white fs-8 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Department Name">Production</span>
                                        <div>
                                            <span class="badge bg-dark text-white fs-8"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Overall Percentage">96%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">24</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">04</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">01</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 800</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 2000</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 1000</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-danger fs-7">₹ 3,961</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-success fs-7">₹ 35,339</label>
                            </td>
                            <td>
                                <span class="d-flex gap-1">
                                    <a href="javascript:;" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_attendance">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="View"><i
                                                class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                    </a>
                                    <a href="{{ url('/hr_general/payslip/1') }}">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Edit" data-bs-original-title="Pay Slip Print"><i class="mdi mdi-printer-outline fs-3 text-black me-1"></i></span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="avatar-xl mt-3">
                                        <img src="{{ asset('assets/egc_images/auth/user_7.png') }}" alt="user image"
                                            class="w-px-50 h-auto rounded-circle ">
                                    </div>
                                    <div
                                        class=" d-flex flex-column justify-content-between align-items-start gap-1">
                                        <a href="javascript:;" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_individual_staff_attendance">
                                            <span class="fs-7 me-1 text-black">Banupriya G</span>
                                        </a>
                                        <span class="badge bg-warning text-white fs-8 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Department Name">Sales Executive</span>
                                        <div>
                                            <span class="badge bg-dark text-white fs-8"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Overall Percentage">95%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">23</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">02</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">00</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 200</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 1500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 0</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-danger fs-7">₹ 2,340</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-success fs-7">₹ 28,660</label>
                            </td>
                            <td>
                                <span class="d-flex gap-1">
                                    <a href="javascript:;" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_attendance">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="View"><i
                                                class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                    </a>
                                    <a href="{{ url('/hr_general/pay_slip_print') }}">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Edit" data-bs-original-title="Pay Slip Print"><i class="mdi mdi-printer-outline fs-3 text-black me-1"></i></span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="avatar-xl mt-3">
                                        <img src="{{ asset('assets/egc_images/auth/user_4.png') }}" alt="user image"
                                            class="w-px-50 h-auto rounded-circle ">
                                    </div>
                                    <div
                                        class=" d-flex flex-column justify-content-between align-items-start gap-1">
                                        <a href="javascript:;" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_individual_staff_attendance">
                                            <span class="fs-7 me-1 text-black">Karthik R</span>
                                        </a>
                                        <span class="badge bg-warning text-white fs-8 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Department Name">Accounts Manager</span>
                                        <div>
                                            <span class="badge bg-dark text-white fs-8"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Overall Percentage">88%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">22</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">05</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">02</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 0</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 300</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 1000</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-danger fs-7">₹ 4,120</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-success fs-7">₹ 24,880</label>
                            </td>
                            <td>
                                <span class="d-flex gap-1">
                                    <a href="javascript:;" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_attendance">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="View"><i
                                                class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                    </a>
                                    <a href="{{ url('/hr_general/pay_slip_print') }}">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Edit" data-bs-original-title="Pay Slip Print"><i class="mdi mdi-printer-outline fs-3 text-black me-1"></i></span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="avatar-xl mt-3">
                                        <img src="{{ asset('assets/egc_images/auth/user_7.png') }}" alt="user image"
                                            class="w-px-50 h-auto rounded-circle ">
                                    </div>
                                    <div
                                        class=" d-flex flex-column justify-content-between align-items-start gap-1">
                                        <a href="javascript:;" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_view_individual_staff_attendance">
                                            <span class="fs-7 me-1 text-black">Meena v R</span>
                                        </a>
                                        <span class="badge bg-warning text-white fs-8 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Department Name">Sales Manager</span>
                                        <div>
                                            <span class="badge bg-dark text-white fs-8"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Overall Percentage">97%</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">25</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">01</label>
                            </td>
                            <td>
                                <label class="fw-semibold text-black fs-7">00</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 1,200</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 600</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 3,500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-black fs-7">₹ 1,500</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-danger fs-7">₹ 3,780</label>
                            </td>
                            <td class="text-end">
                                <label class="fw-semibold text-white badge bg-success fs-7">₹ 41,220</label>
                            </td>
                            <td>
                                <span class="d-flex gap-1">
                                    <a href="javascript:;" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_attendance">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="View"><i
                                                class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                    </a>
                                    <a href="{{ url('/hr_general/pay_slip_print') }}">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Edit" data-bs-original-title="Pay Slip Print"><i class="mdi mdi-printer-outline fs-3 text-black me-1"></i></span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal Generate Payroll--->
<div class="modal fade" id="kt_modal_generate_payroll" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Generate Payroll</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2 border rounded border-success p-2 bg-label-success d-flex align-items-center gap-2">
                        <img src="{{ asset('assets/egc_images/loader.gif') }}" style="width:30px;height:30px;">
                        <span class="text-black fs-7 fw-semibold">Attendance Days is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-success p-2 bg-label-success d-flex align-items-center justify-content-start gap-2">
                        <img src="{{ asset('assets/egc_images/loader.gif') }}" style="width:30px;height:30px;">
                        <span class="text-black fs-7 fw-semibold">PF is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-success p-2 bg-label-success d-flex align-items-center justify-content-start gap-2">
                        <img src="{{ asset('assets/egc_images/loader.gif') }}" style="width:30px;height:30px;">
                        <span class="text-black fs-7 fw-semibold">Loss of Pay is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-gray-300 p-2 bg-gray-100 d-flex align-items-center justify-content-start gap-2">
                        <span><i class="mdi mdi-alpha-x-circle-outline text-black fs-7"></i></span>
                        <span class="text-black fs-7 fw-semibold">OD Charges is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-gray-300 p-2 bg-gray-100 d-flex align-items-center justify-content-start gap-2">
                        <span><i class="mdi mdi-alpha-x-circle-outline text-black fs-7"></i></span>
                        <span class="text-black fs-7 fw-semibold">Travel Claim Charges is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-gray-300 p-2 bg-gray-100 d-flex align-items-center justify-content-start gap-2">
                        <span><i class="mdi mdi-alpha-x-circle-outline text-black fs-7"></i></span>
                        <span class="text-black fs-7 fw-semibold">Incentive is Calculating...</span>
                    </div>
                    <div class="col-lg-12 mb-2 border rounded border-gray-300 p-2 bg-gray-100 d-flex align-items-center justify-content-start gap-2">
                        <span><i class="mdi mdi-alpha-x-circle-outline text-black fs-7"></i></span>
                        <span class="text-black fs-7 fw-semibold">Increment is Calculating...</span>
                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Generate Payroll-->



<script>
$(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
        "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
        "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
        ">" +

        "<'table-responsive'tr>" +

        "<'row'" +
        "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
        ">"
});
$(".list_page_empty").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
        "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
        // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
        ">" +

        "<'table-responsive'tr>" +

        "<'row'" +
        // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
        ">"
});
</script>

@endsection