@extends('layouts/layoutMaster')

@section('title', 'User Role Permission')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>
@php
    $helper = new \App\Helpers\Helpers();
@endphp
@php
    $module_name = 'Users Management';
    $menu_name   = 'Manage Users';
@endphp
    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">User Role & Permission</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                User Management
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <a href="/user_management/manage_permission" class="btn btn-sm fw-bold btn-primary">
                    <span class="me-2"><i class="mdi mdi-swap-horizontal-bold"></i></span>Management User Permission
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="{{ url('user_management/manage_permission/create_manage_users') }}" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add User Permission
                </a>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                               <th class="min-w-150px">Role</th>
                               <th class="min-w-150px">Company / <br> Entity</th>
                                <th class="min-w-100px">Status</th>
                                <th class="min-w-50px"><span class="text-end">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            @if(isset($userpermission))
                            @foreach($userpermission as $category)
                            <tr>
                            <td style="position:relative;">
                                 <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:{{$category->company_base_color ?? ''}};"></div>
                               <span>
                                    {{ $category->role_name }}
                                </span>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="{{$category->company_name ?? '-'}}">
                                        {{$category->company_name ?? '-'}}
                                    </label>

                                    <label class="fw-semibold fs-7 text-truncate badge d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: {{$category->company_base_color}};"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="{{$category->entity_name ?? '-'}}">
                                        {{$category->entity_short_name ?? '-'}}
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                <input type="checkbox" class="switch-input"
                                    {{ $category->status == 0 ? 'checked' : '' }}
                                    onchange="updateRoleStatus('{{ $category->sno }}', this.checked)" />
                                <span class="switch-toggle-slider ">
                                    <span class="switch-on"></span>
                                    <span class="switch-off"></span>
                                </span>
                                </label>
                            </td>
                            <td>
                                @php
                
                                    $encryptedValue = $helper->encrypt_decrypt($category->sno, 'encrypt');
                                    $url = url('/users/view_manage_users/' . $encryptedValue);
                
                                    $edit_url = url(
                                        '/user_management/manage_permission/update_role_permision/' . $encryptedValue,
                                    );
                                @endphp
                                <span class="text-end">
                                    @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))  
                                     @endif
                                    <a href="{{$url}}"  class="btn btn-icon btn-sm me-2" title="View">
                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i>
                                    </a>
                                   
                                    @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                     @endif
                                    <a  href="{{$edit_url}}" class="btn btn-icon btn-sm me-2" title="Edit">
                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                    </a>
                                   
                                    @if(auth()->user()->hasPermission($module_name, 'Delete', $menu_name))
                                    @endif
                                    <a href="#" onclick="confirmDelete('{{ $category->sno }}', '{{ $category->role_name }}', '{{ $category->role_id }}')"
                                        class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_delete_manage_users" data-bs-placement="bottom" title="Delete">
                                        <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                    </a>
                                    
                                </span>
                                
                            </td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                                <th ></th>
                                <th >No data available</th>
                                <th ></th>
                            </tr>
                        @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">CEO</b> Role ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "pageLength": 25,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                 //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
