@extends('layouts.contentNavbarLayout')

@section('title', 'Whatsapp Template Log')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

 <style>
  .whatsapp-preview {
        background: #ece5dd;
        padding: 20px;
        max-height: 400px;
        overflow: scroll;
        border-radius: 10px;
    }

    .chat-bubble {
        background: #fff;
        max-width: 270px;
        border-radius: 8px;
        /* overflow: hidden; */
        font-size: 12px;
        line-height: 1.4;
        position:relative;
    }
    .wa-reaction_emoji {
        position: absolute;
        bottom: -10px;
        background: #fff;
        padding: 4px 6px;
        border-radius: 50%;
        font-size: 12px;
        left: 8px;
    }
    #fetch_content {
        background: #ffffff52;
        max-width: 300px;
        max-height: 500px;
        border-radius: 8px;
         overflow: auto;
        font-size: 12px;
        line-height: 1.4;
    }

    .wa-doc-card {
        display: flex;
        align-items: center;
        padding: 10px 12px;
        gap: 12px;
        border-bottom: 1px solid #e9edef;
    }
    .wa-body a.wa-link {
        color: #126eda;
        text-decoration: none;
        font-weight: 500;
    }
 
    .wa-body a.wa-link:hover {
        text-decoration: underline;
    }
    .wa-doc-icon {
        font-size: 28px;
    }

    .wa-doc-info {
        display: flex;
        flex-direction: column;
    }

    .wa-doc-name {
        font-weight: 600;
        font-size: 13px;
        color: #111b21;
    }

    .wa-doc-type {
        font-size: 11px;
        color: #667781;
        text-transform: uppercase;
    }


    .wa-header img {
        width: 100%;
        display: block;
    }

    .wa-body {
        padding: 12px 15px;
        white-space: pre-line;
    }

    .wa-footer {
        padding: 0 15px 10px;
        font-size: 12px;
        color: #667781;
    }

    .wa-buttons {
        border-top: 1px solid #e9edef;
    }

    .wa-button {
        text-align: center;
        padding: 10px;
        font-weight: 500;
        color: #00a884;
        cursor: pointer;
        border-top: 1px solid #e9edef;
    }

    .template-meta {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 6px;
        font-size: 13px;
    }

    .wa-meta-card {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 16px 18px;
        margin-bottom: 16px;
        border: 1px solid #e5e7eb;
    }

    .wa-meta-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .wa-phone {
        font-weight: 600;
        font-size: 15px;
        color: #111827;
    }

    .wa-meta-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px 16px;
    }

    .wa-meta-grid .label {
        display: block;
        font-size: 11px;
        text-transform: uppercase;
        color: #6b7280;
        margin-bottom: 2px;
    }

    .wa-meta-grid .value {
        font-size: 13px;
        font-weight: 500;
        color: #111827;
    }

 </style>

    <div class="card">
        <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">Whatsapp Template Log</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring Tools</a>
                      </li>
                    </ol>
                  </nav>
                </div>
                <div>
                    <a href="/whatsapp_template_history_log" class="btn btn-sm fw-bold btn-primary">
                        <span class="me-2"><i class="mdi mdi-swap-horizontal-bold"></i></span>History Log
                    </a>
                </div>
              </div>
            </div>

        </div>
        @php
            $helper = new \App\Helpers\Helpers();
            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
        @endphp
        <div class="card-body">
          <div class="row mb-1">
            <div class="col-md-3 mb-2">
                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            $user_id = auth()->user()->user_id;
                            $branch_data = $helper->get_branch_control_list_user($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <label class="text-dark mb-1 fs-6 fw-semibold">Branch</label>
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                            <option value="0" selected>All Branches</option>
                            @if ($branches->isNotEmpty())
                                <optgroup label="Branches">
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                            {{ $branch->branch_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                    @elseif($role_permission->manage_branch == 1)
                        @if($branch_common)
                            <div class="d-flex align-items-center mt-2">
                                <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                <div>
                                    <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                    <small class="text-muted">{{ $branch_common->branch_name }}</small>
                                </div>
                            </div>
                        @endif
                    @endif
                @endif
            </div>
            <div class="col-md-3 mb-2">
                <label class="text-dark mb-1 fs-6 fw-semibold">Template</label>
              <select id="templateTypeFilter" class="select3 form-select">
                <option value="">All</option>
                @if(isset($whatsappTempList))
                @foreach($whatsappTempList as $templt)
                    <option value="{{$templt->whatsapp_title_name}}">{{$templt->whatsapp_title_name}}</option>
                @endforeach
                @endif
              </select>
            </div>

            <div class="col-lg-3 mb-2">
                <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                <select class="select3 form-select" name="dt_fill_issue_rpt"
                    id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                    <option value="all" >All</option>
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="monthly" selected>This Month</option>
                    <option value="yearly">This Year</option>
                    <option value="custom_date">Custom Date</option>
                </select>
            </div>
            <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text bg-gray-200"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                        class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                    />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text bg-gray-200"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                        class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                    />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text bg-gray-200"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                        class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                    />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="lead_this_month_dt_fill"
                        placeholder="Select Date" class="form-control this_month_dt_fill"
                        value="<?php echo date("M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="yearly_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">This Year</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="lead_this_month_dt_fill"
                        placeholder="Select Date" class="form-control this_month_dt_fill"
                        value="<?php echo date("Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" placeholder="Select Date" readonly name="from_date_fillter_textbox"  class="form-control common_date_class"
                    value="<?php echo date(" d-M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i
                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text"  placeholder="Select Date"
                        class="form-control common_date_class" readonly name="to_date_fillter_textbox"  value="<?php echo date(" d-M-Y"); ?>" />
                </div>
            </div>

            <div class="col-md-2 mt-6 mb-2">
              <button id="filterBtn" class="btn btn-primary w-50">Search</button>
            </div>
            
          </div>
        
          <div class="row">
            <div class="col-lg-12">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page" id="loginLogTable">
                <thead>
                  <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                    <th>Template Name</th>
                    <th>Total</th>
                    <th>Sent</th>
                    <th>Delivered</th>
                    <th>Read</th>
                    <th>Failed</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="logTableBody">
                  <tr>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td class="text-center text-muted">Loading...</td>
                      <td></td>
                      <td></td>
                      <td></td>
                  </tr>
                </tbody>
              </table>
        
              <nav>
                <ul class="pagination justify-content-end mt-3" id="pagination"></ul>
              </nav>
            </div>
          </div>
        </div>
    </div>
    <!-- Modal -->

    <div class="modal fade" id="kt_modal_whatsapp_template_content_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">View WhatsApp Template</h3>
                    </div>
                    <div class="row">
                        <div id="template_meta" class="mb-4"></div>
                        <div class="whatsapp-preview">
                            <div class="d-flex justify-content-center">
                                <div>
                                    <h5>Sample Template</h5>
                                    <div class="chat-bubble">
                                        <div id="wa_header"></div>
                                        <div id="wa_body"></div>
                                        <div id="wa_footer"></div>
                                        <div id="wa_buttons"></div>
                                        <div id="wa_reaction"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>

                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <div class="modal fade" id="kt_modal_whatsapp_template_log_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">View WhatsApp Template Log</h3>
                    </div>
                    <div class="row">
                        <div id="template_meta_log" class="mb-4"></div>
                        <div class="message_list">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1" id="listMessageTable">
                                <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                                    <th>Receiver</th>
                                    <th>Sent Date/Time</th>
                                    <th>Delivered Date/Time</th>
                                    <th>Read Date/Time</th>
                                    <th>Failed Date/Time</th>
                                </tr>
                                </thead>
                                <tbody id="viewlogTableBody" class="h-max-450px">
                                <tr>
                                    <td colspan="5" class="text-center text-muted">Loading...</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>

                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }

</style>



<script>

$(document).ready(function() {
    let currentPage = 1;

    function loadLogs(page = 1) {
        const search = $('#searchInput').val();
        const dt_fill_issue_rpt = $('#dt_fill_issue_rpt').val();
        const from_date_fillter_textbox = $('#from_date_fillter_textbox').val();
        const to_date_fillter_textbox = $('#to_date_fillter_textbox').val();
        const type = $('#typeFilter').val();
        const branch_id = $('#branchSelectsgoal').val();
        const templateTypeFilter = $('#templateTypeFilter').val();
        $('#logTableBody').html(`<tr><td colspan="7" class="text-center text-muted">Loading...</td></tr>`);

        $.ajax({
            url: `/whatsapp_template_log/template_list?page=${page}`,
            type: 'GET',
            data: { search, type, branch_id, templateTypeFilter,to_date_fillter_textbox,from_date_fillter_textbox,dt_fill_issue_rpt},
            success: function(res) {
                if (res.status === 200) {
                    const data = res.data.data;
                    let rows = '';

                    if (data.length === 0) {
                        rows = `<tr><td colspan="7" class="text-center text-muted">No Records Found</td></tr>`;
                    } else {
                        data.forEach(log => {
                            const badgeClass = log.message_status == 'sent' ? 'bg-secondary':(log.message_status == 'delivered' ? 'bg-info' :(log.message_status == 'read' ? 'bg-success' : 'bg-danger') );
                            // ðŸ‘‡ Hide password if Success, show if Failed
                            const branchBadgeClass = (log.branch_name === 'Unknown' || !log.branch_name)
                                ? 'bg-danger text-white'
                                : 'bg-info';
                                let templateModules = log.template_modules
                                ? JSON.parse(log.template_modules).map(tag => 
                                    `<span class='badge bg-warning text-black fw-bold fs-8'>${tag.value}</span>`).join(' ')
                                : '';
                            rows += `
                                <tr>
                                    <td>
                                        <div>
                                            <span class="fs-7 text-black fw-bold"> ${log.whatsapp_template_name ?? '-'}</span>
                                            <label data-bs-toggle="dropdown">
                                                    <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 cursor-pointer"
                                                        title="Template Modules">
                                                    </span>
                                                </label>
                                            <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                                <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                                    <u>Template Modules</u>
                                                </div>

                                                <div class="mb-2">
                                                    ${templateModules}
                                                </div>
                                            </div>
                                        </div>
                                        <span class="fs-8 text-dark fw-semibold"> ${log.template_name ?? '-'}</span>
                                    </td>
                                    <td>
                                        <span class="fs-6 cursor-pointer badge bg-secondary text-white fw-semibold rounded"  data-bs-toggle="modal"  data-bs-target="#kt_modal_whatsapp_template_log_view" onclick="view_message_log('${log.sno}','all','${log.template_name}')">
                                           ${log.total_count < 10 ? '0'+log.total_count : log.total_count}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-6 cursor-pointer badge bg-warning text-black fw-semibold rounded" data-bs-toggle="modal"  data-bs-target="#kt_modal_whatsapp_template_log_view" onclick="view_message_log('${log.sno}','sent','${log.template_name}')">
                                            ${log.sent_count < 10 ? '0'+log.sent_count : log.sent_count}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-6 cursor-pointer badge bg-info text-white fw-semibold rounded" data-bs-toggle="modal"  data-bs-target="#kt_modal_whatsapp_template_log_view" onclick="view_message_log('${log.sno}','delivered','${log.template_name}')">
                                            ${log.delivered_count < 10 ? '0'+log.delivered_count : log.delivered_count}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-6 cursor-pointer badge bg-success text-white fw-semibold rounded"data-bs-toggle="modal"  data-bs-target="#kt_modal_whatsapp_template_log_view" onclick="view_message_log('${log.sno}','read','${log.template_name}')" >
                                           ${log.read_count < 10 ? '0'+log.read_count : log.read_count}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-6 cursor-pointer badge bg-danger text-white fw-semibold rounded" data-bs-toggle="modal"  data-bs-target="#kt_modal_whatsapp_template_log_view" onclick="view_message_log('${log.sno}','failed','${log.template_name}')">
                                           ${log.failed_count < 10 ? '0'+log.failed_count : log.failed_count}
                                        </span>
                                    </td>
                                    <td>
                                    <span class="text-end">
                                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                            <a href="javascript:;" 
                                            class="dropdown-item view-message"
                                            data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_whatsapp_template_content_view" 
                                            data-template="${encodeURIComponent(JSON.stringify(log.template_content))}">
                                                <i class="mdi mdi-eye-outline fs-3 text-black"></i> View Message
                                            </a>
                                        </div>
                                    </span>
                                    </td>
                                </tr>
                            `;
                        });
                    }

                    $('#logTableBody').html(rows);
                    renderPagination(res.data);
                }
            },
            error: function() {
                $('#logTableBody').html(`<tr><td colspan="7" class="text-center text-danger">Error loading data</td></tr>`);
            }
        });
    }

    // ðŸ‘‡ Smart Pagination Function
    function renderPagination(pagination) {
        let pagHtml = '';
        const total = pagination.last_page;
        const current = pagination.current_page;

        if (total <= 1) {
            $('#pagination').html('');
            return;
        }

        let start = Math.max(1, current - 2);
        let end = Math.min(total, current + 2);

        // Always show first and last pages when far away
        if (start > 1) {
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
            if (start > 2) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }

        for (let i = start; i <= end; i++) {
            pagHtml += `<li class="page-item ${i === current ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>`;
        }

        if (end < total) {
            if (end < total - 1) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${total}">${total}</a></li>`;
        }

        // Previous / Next
        let prevDisabled = current === 1 ? 'disabled' : '';
        let nextDisabled = current === total ? 'disabled' : '';
        pagHtml = `<li class="page-item ${prevDisabled}">
                        <a class="page-link" href="#" data-page="${current - 1}">Previous</a>
                    </li>` + pagHtml +
                   `<li class="page-item ${nextDisabled}">
                        <a class="page-link" href="#" data-page="${current + 1}">Next</a>
                    </li>`;

        $('#pagination').html(pagHtml);
    }

    // Event bindings
    $('#filterBtn').click(function() {
        currentPage = 1;
        loadLogs();
    });

    $('#pagination').on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (!page || $(this).parent().hasClass('disabled') || $(this).parent().hasClass('active')) return;
        currentPage = page;
        loadLogs(page);
    });
    $('#branchSelectsgoal').change(function() {
        currentPage = 1;
        loadLogs();
    });
    // Initial load
    loadLogs();
    
    
});

    function view_message_log(id,status,name) {
        const badgeClass = status == 'sent' ? 'bg-warning text-black':(status == 'delivered' ? 'bg-info text-white' :(status == 'read' ? 'bg-success text-white' : ( status == 'all' ? 'bg-secondary text-white' :'bg-danger text-white') ) );
        const search = $('#searchInput').val();
        const dt_fill_issue_rpt = $('#dt_fill_issue_rpt').val();
        const from_date_fillter_textbox = $('#from_date_fillter_textbox').val();
        const to_date_fillter_textbox = $('#to_date_fillter_textbox').val();
        const type = $('#typeFilter').val();
        const templateTypeFilter = $('#templateTypeFilter').val();
                $('#template_meta_log').html(`
                    <div class="wa-meta-card">
                        <div class="wa-meta-grid">
                            <div>
                                <span class="label">Template Name</span>
                                <span class="value">${name ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Message Status</span>
                                <span class="value fs-7 badge ${badgeClass}"> ${status.charAt(0).toUpperCase() + status.slice(1)}</span>
                            </div>

                            <div>
                                <span class="label">Month</span>
                                <span class="value">${dt_fill_issue_rpt}</span>
                            </div>
                            
                        </div>
                    </div>
                `);
        $('#viewlogTableBody').html(`<tr><td colspan="6" class="text-center text-muted">Loading...</td></tr>`);

        $.ajax({
            url: `/whatsapp_template_log_by_id`,
            type: 'GET',
            data: { name, status,to_date_fillter_textbox,from_date_fillter_textbox,dt_fill_issue_rpt},
            success: function(res) {
                if (res.status === 200) {
                    const data = res.data.data;
                    let rows = '';

                    if (data.length === 0) {
                        rows = `<tr><td colspan="5" class="text-center text-muted">No Records Found</td></tr>`;
                    } else {
                        data.forEach(log => {
                            const badgeClass = log.message_status == 'sent' ? 'bg-secondary':(log.message_status == 'delivered' ? 'bg-info' :(log.message_status == 'read' ? 'bg-success' : 'bg-danger') );
                            // ðŸ‘‡ Hide password if Success, show if Failed
                            const branchBadgeClass = (log.branch_name === 'Unknown' || !log.branch_name)
                                ? 'bg-danger text-white'
                                : 'bg-info';

                            rows += `
                                <tr>
                                    <td>
                                        <div class="fw-bold fs-7">${log.receiver_no}</div>
                                            ${log.receiver_name ?
                                            `<span class="text-primary fs-7 fw-semibold">${log.receiver_name}</span>`
                                            :''
                                            }
                                            <div>
                                            <span class="fs-8 badge bg-info text-white fw-semibold" >
                                                ${log.branch_name}
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fs-8 badge bg-warning text-black fw-semibold rounded" >
                                             ${log.message_date_time ?? '-'} 
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-8 badge bg-info text-white fw-semibold rounded" >
                                            ${ status =='all' ? (log.message_status === 'delivered' || log.message_status === 'read'? log.delivered_date_time :'-') : (status === 'delivered' || status === 'read'? log.delivered_date_time :'-')}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-8 badge bg-success text-white fw-semibold rounded" >
                                            ${ status =='all' ? (log.message_status === 'read'? log.read_date_time :'-') :  (status === 'read'? log.read_date_time :'-')}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="fs-8 badge bg-danger text-white fw-semibold rounded" >
                                            ${ status =='all' ? (log.message_status === 'failed'? log.failed_date_time :'-') : (status =='failed' ? log.failed_date_time :'-')}
                                        </span>
                                    </td>
                                    
                                </tr>
                            `;
                        });
                    }

                    $('#viewlogTableBody').html(rows);
                }
            },
            error: function() {
                $('#viewlogTableBody').html(`<tr><td colspan="5" class="text-center text-danger">Error loading data</td></tr>`);
            }
        });
    }
</script>        
        <script>
            function viewContent(template) {

                // ---- META ----
                $('#template_meta').html(`
                    <div class="wa-meta-card">
                        <div class="wa-meta-grid">
                            <div>
                                <span class="label">Template Name</span>
                                <span class="value">${template.name ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Parameter Format</span>
                                <span class="value">${template.parameter_format ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Category</span>
                                <span class="value">${template.category ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Language</span>
                                <span class="value">${template.language ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Status</span>
                                <span class="value">${template.status ?? '-'}</span>
                            </div>
                        </div>
                    </div>
                `);

                // ---- CLEAR UI ----
                $('#wa_header, #wa_body, #wa_footer, #wa_buttons').html('');

                // ---- RAW PAYLOAD ----
                $('#fetch_content').html(
                    '<pre>' + JSON.stringify(template.components, null, 2) + '</pre>'
                );

                template.components.forEach(component => {

                    // ===== HEADER =====
                    if (component.type === "HEADER") {

                        // IMAGE
                        if (component.format === "IMAGE") {
                            const img = component.example?.header_handle?.[0];
                            if (img) {
                                $('#wa_header').html(`
                                    <div class="wa-header">
                                        <img src="${img}">
                                    </div>
                                `);
                            }
                        }

                        // TEXT
                        if (component.format === "TEXT") {
                            $('#wa_header').html(`
                                <div class="wa-body"><b>${component.text}</b></div>
                            `);
                        }

                        if (component.format === "DOCUMENT") {
                            const docUrl = component.example?.header_handle?.[0];

                            // Force WhatsApp sample filename
                            // const fileName = "sampleddocs";
                            const fileName = component.example?.filename || "sample_document.pdf";

                            if (docUrl) {
                                $('#wa_header').html(`
                                    <div class="wa-header">
                                        <div class="wa-doc-card">
                                            <div class="wa-doc-icon">📄</div>

                                            <div class="wa-doc-info">
                                                <div class="wa-doc-name">${fileName}</div>
                                                <div class="wa-doc-type">pdf</div>
                                            </div>
                                        </div>
                                    </div>
                                `);
                            }
                        }
                    }



                    // ===== BODY =====
                    if (component.type === "BODY") {

                        let bodyText = component.text;

                        // Replace params only if examples exist
                        if (component.example) {
                            let examples = [];

                            if (template.parameter_format === "NAMED") {
                                examples = component.example.body_text_named_params || [];
                            } else {
                                examples = component.example.body_text?.[0] || [];
                            }

                            bodyText = replaceParams(bodyText, template.parameter_format, examples);
                        }
                        bodyText = bodyText.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
 
                        bodyText = bodyText.replace(/\*(.*?)\*/g, '<b>$1</b>');
 
                        bodyText = bodyText.replace(
                            /(https?:\/\/[^\s]+)/g,
                            '<a href="$1" target="_blank" class="wa-link">$1</a>'
                        );
                        

                        $('#wa_body').html(`<div class="wa-body">${bodyText}</div>`);
                    }

                    // ===== FOOTER =====
                    if (component.type === "FOOTER") {
                        $('#wa_footer').html(`
                            <div class="wa-footer">${component.text}</div>
                        `);
                    }

                    // ===== BUTTONS =====
                    if (component.type === "BUTTONS") {

                        let btnHtml = '';

                        component.buttons.forEach(btn => {

                            // URL BUTTON
                            if (btn.type === "URL") {
                                btnHtml += `
                                    <div class="wa-button" onclick="window.open('${btn.url}','_blank')">
                                        ${btn.text}
                                    </div>
                                `;
                            }

                            // QUICK REPLY BUTTON
                            if (btn.type === "QUICK_REPLY") {
                                btnHtml += `
                                    <div class="wa-button">
                                        ${btn.text}
                                    </div>
                                `;
                            }

                        });

                        $('#wa_buttons').html(`<div class="wa-buttons">${btnHtml}</div>`);
                    }

                });
            }
        </script>


        <script>
            function replaceParams(text, format, exampleParams) {
                if (format === "NAMED") {
                    exampleParams.forEach(p => {
                        let value = (p.example.toLowerCase() === "sundaresh") ? "Alex" : p.example;
                        const regex = new RegExp('\\{\\{' + p.param_name + '\\}\\}', 'g');
                        text = text.replace(regex, value);
                    });
                }

                if (format === "POSITIONAL") {
                    exampleParams.forEach((value, index) => {
                        value = (value.toLowerCase() === "sundaresh") ? "Alex" : value;
                        const regex = new RegExp('\\{\\{' + (index + 1) + '\\}\\}', 'g');
                        text = text.replace(regex, value);
                    });
                }

                return text;
            }
        </script>
        <script>
            $(document).on('click', '.view-message', function () {
                try {
                    const template = JSON.parse(
                        decodeURIComponent(this.dataset.template)
                    );
                    viewContent(template);

                } catch (err) { 
                    console.error('Payload parse failed', err);

                }
            });
        </script>
        <script>
            date_fill_issue_rpt()
            function date_fill_issue_rpt() {
                var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
                var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
                var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
                var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
                var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
                var yearly_dt_iss_rpt = document.getElementById('yearly_dt_iss_rpt');
                var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
                var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
                var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
                var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

                if (dt_fill_issue_rpt == "today") {
                    today_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    yearly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "week") {
                    today_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "block";
                    week_to_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    yearly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";

                    var curr = new Date; // get current date
                    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                    var last = first + 6; // last day is the first day + 6

                    var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                    firstday = firstday.split("-").reverse().join("-");
                    var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                    lastday = lastday.split("-").reverse().join("-");
                    $('#lead_week_st_dt_fill').val(firstday);
                    $('#lead_week_ed_dt_fill').val(lastday);

                } else if (dt_fill_issue_rpt == "monthly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "block";
                    yearly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }else if (dt_fill_issue_rpt == "yearly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    yearly_dt_iss_rpt.style.display = "block";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "custom_date") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    yearly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "block";
                    to_dt_iss_rpt.style.display = "block";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    yearly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }
            }
        </script>
@endsection
