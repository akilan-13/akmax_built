@extends('layouts.contentNavbarLayout')

@section('title', 'Whatsapp Template History Log')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<style>
    .template-status-badge {
        cursor: pointer;
    }
 
    .template-status-tooltip {
        position: absolute;
        top: 120%;
        left: 50%;
        transform: translateX(-50%);
        background: #fff;
        border-radius: 8px;
        padding: 8px 12px;
        width: 160px;
        font-size: 12px;
        opacity: 0;
        visibility: hidden;
        transition: all 0.2s ease;
        z-index: 1000;
        border: 1px solid #e5e5e5;
    }
 
    .template-status-tooltip::before {
        content: "";
        position: absolute;
        top: -6px;
        left: 50%;
        transform: translateX(-50%);
        border-width: 6px;
        border-style: solid;
        border-color: transparent transparent #fff transparent;
    }
 
    .template-status-badge:hover .template-status-tooltip {
        opacity: 1;
        visibility: visible;
        transform: translateX(-50%) translateY(4px);
    }
 
    .tooltip-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 2px;
    }
 
    .tooltip-row .label {
        color: #6c757d;
    }
 
 
    .template-status-tooltip {
        text-align: left;
    }
 
    .tooltip-header {
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 600;
        margin-bottom: 6px;
        color: #dc3545;
    }
 
    .error-icon {
        font-size: 14px;
    }
 
    .tooltip-item {
        margin-bottom: 6px;
    }
 
    .tooltip-item .label {
        display: block;
        font-size: 11px;
        color: #6c757d;
    }
 
    .tooltip-item .value {
        font-size: 12px;
        color: #212529;
        line-height: 1.4;
    }
 
    .error-code {
        font-weight: 600;
        color: #dc3545;
    }
 
    .view-docs-link {
        display: inline-block;
        font-size: 12px;
        color: #007bff;
        text-decoration: none;
        font-weight: 500;
    }
 
    .view-docs-link:hover {
        text-decoration: underline;
        color: #0056b3;
    }
</style>

 <style>
  .whatsapp-preview {
        background: #ece5dd;
        padding: 20px;
        max-height: 400px;
        overflow: scroll;
        border-radius: 10px;
    }

    .chat-bubble {
        background: #fff;
        max-width: 270px;
        border-radius: 8px;
        /* overflow: hidden; */
        font-size: 12px;
        line-height: 1.4;
        position:relative;
    }
    .wa-reaction_emoji {
        position: absolute;
        bottom: -10px;
        background: #fff;
        padding: 4px 6px;
        border-radius: 50%;
        font-size: 12px;
        left: 8px;
    }
    #fetch_content {
        background: #ffffff52;
        max-width: 300px;
        max-height: 500px;
        border-radius: 8px;
         overflow: auto;
        font-size: 12px;
        line-height: 1.4;
    }
    .wa-body a.wa-link {
        color: #126eda;
        text-decoration: none;
        font-weight: 500;
    }
 
    .wa-body a.wa-link:hover {
        text-decoration: underline;
    }
    .wa-doc-card {
        display: flex;
        align-items: center;
        padding: 10px 12px;
        gap: 12px;
        border-bottom: 1px solid #e9edef;
    }

    .wa-doc-icon {
        font-size: 28px;
    }

    .wa-doc-info {
        display: flex;
        flex-direction: column;
    }

    .wa-doc-name {
        font-weight: 600;
        font-size: 13px;
        color: #111b21;
    }

    .wa-doc-type {
        font-size: 11px;
        color: #667781;
        text-transform: uppercase;
    }


    .wa-header img {
        width: 100%;
        display: block;
    }

    .wa-body {
        padding: 12px 15px;
        white-space: pre-line;
    }

    .wa-footer {
        padding: 0 15px 10px;
        font-size: 12px;
        color: #667781;
    }

    .wa-buttons {
        border-top: 1px solid #e9edef;
    }

    .wa-button {
        text-align: center;
        padding: 10px;
        font-weight: 500;
        color: #00a884;
        cursor: pointer;
        border-top: 1px solid #e9edef;
    }

    .template-meta {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 6px;
        font-size: 13px;
    }

    .wa-meta-card {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 16px 18px;
        margin-bottom: 16px;
        border: 1px solid #e5e7eb;
    }

    .wa-meta-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .wa-phone {
        font-weight: 600;
        font-size: 15px;
        color: #111827;
    }

    .wa-meta-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px 16px;
    }

    .wa-meta-grid .label {
        display: block;
        font-size: 11px;
        text-transform: uppercase;
        color: #6b7280;
        margin-bottom: 2px;
    }

    .wa-meta-grid .value {
        font-size: 13px;
        font-weight: 500;
        color: #111827;
    }

 </style>

    <div class="card">
        <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">Whatsapp Template History Log</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Monitoring Tools</a>
                      </li>
                    </ol>
                  </nav>
                </div>

                <div>
                    <a href="/whatsapp_template_log" class="btn btn-sm fw-bold btn-primary">
                        <span class="me-2"><i class="mdi mdi-swap-horizontal-bold"></i></span>Template Log
                    </a>
                </div>
                
              </div>
            </div>

        </div>
        @php
            $helper = new \App\Helpers\Helpers();
            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
        @endphp
        <div class="card-body">
          <div class="row mb-3">
            <div class="col-md-3">
                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            $user_id = auth()->user()->user_id;
                            $branch_data = $helper->get_branch_control_list_user($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                            <option value="0" selected>All Branches</option>
                            @if ($branches->isNotEmpty())
                                <optgroup label="Branches">
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                            {{ $branch->branch_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                    @elseif($role_permission->manage_branch == 1)
                        @if($branch_common)
                            <div class="d-flex align-items-center mt-2">
                                <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                <div>
                                    <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                    <small class="text-muted">{{ $branch_common->branch_name }}</small>
                                </div>
                            </div>
                        @endif
                    @endif
                @endif
            </div>
            <div class="col-md-3">
              <select id="templateTypeFilter" class="select3 form-select">
                <option value="">All</option>
                @if(isset($whatsappTempList))
                @foreach($whatsappTempList as $templt)
                    <option value="{{$templt->whatsapp_title_name}}">{{$templt->whatsapp_title_name}}</option>
                @endforeach
                @endif
              </select>
            </div>
            <div class="col-md-2">
              <select id="typeFilter" class="select3 form-select">
                <option value="">All</option>
                <option value="sent">Sent</option>
                <option value="delivered">Delivered</option>
                <option value="read">Read</option>
                <option value="failed">Failed</option>
              </select>
            </div>
            <div class="col-md-2">
              <input type="text" id="searchInput" class="form-control" placeholder="Search Template/Name">
            </div>
            <div class="col-md-2">
              <button id="filterBtn" class="btn btn-primary w-50">Search</button>
            </div>
            
          </div>
        
          <div class="row">
            <div class="col-lg-12">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page" id="loginLogTable">
                <thead>
                  <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary text-white">
                    <th>Receiver</th>
                    <th>Template Name</th>
                    <th>Date/Time</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="logTableBody">
                  <tr>
                      <td  class="text-center text-muted"></td>
                      <td  class="text-center text-muted"></td>
                      <td  class="text-center text-muted">Loading...</td>
                      <td  class="text-center text-muted"></td>
                      <td  class="text-center text-muted"></td>
                  </tr>
                </tbody>
              </table>
        
              <nav>
                <ul class="pagination justify-content-end mt-3" id="pagination"></ul>
              </nav>
            </div>
          </div>
        </div>
    </div>
    <!-- Modal -->

<div class="modal fade" id="kt_modal_whatsapp_template_content_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">View WhatsApp Template</h3>
                        </div>
                        <div class="row">
                            <div id="template_meta" class="mb-4"></div>
                            <div class="whatsapp-preview">
                                <div class="d-flex justify-content-center">
                                    <div>
                                        <h5>Sample Template</h5>
                                        <div class="chat-bubble">
                                            <div id="wa_header"></div>
                                            <div id="wa_body"></div>
                                            <div id="wa_footer"></div>
                                            <div id="wa_buttons"></div>
                                            <div id="wa_reaction"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }

</style>



<script>

$(document).ready(function() {
    let currentPage = 1;

    function loadLogs(page = 1) {
        const search = $('#searchInput').val();
        const type = $('#typeFilter').val();
        const branch_id = $('#branchSelectsgoal').val();
        const templateTypeFilter = $('#templateTypeFilter').val();
        $('#logTableBody').html(`<tr><td colspan="5" class="text-center text-muted">Loading...</td></tr>`);

        $.ajax({
            url: `/whatsapp_template_log/list?page=${page}`,
            type: 'GET',
            data: { search, type, branch_id, templateTypeFilter },
            success: function(res) {
                if (res.status === 200) {
                    const data = res.data.data;
                    let rows = '';

                    if (data.length === 0) {
                        rows = `<tr><td colspan="5" class="text-center text-muted">No Records Found</td></tr>`;
                    } else {
                        data.forEach(log => {
                            const badgeClass = log.message_status == 'sent' ? 'bg-secondary':(log.message_status == 'delivered' ? 'bg-info' :(log.message_status == 'read' ? 'bg-success' : 'bg-danger') );
                            // ðŸ‘‡ Hide password if Success, show if Failed
                            const branchBadgeClass = (log.branch_name === 'Unknown' || !log.branch_name)
                                ? 'bg-danger text-white'
                                : 'bg-info';

                            rows += `
                                <tr>
                                    <td>
                                        <div class="fw-bold fs-7">${log.receiver_no}</div>
                                        ${log.receiver_name ?
                                        `<span class="text-primary fs-7 fw-semibold">${log.receiver_name}</span>`
                                        :''
                                        }
                                        <div>
                                        <span class="fs-8 badge bg-info text-white fw-semibold" >
                                            ${log.branch_name}
                                        </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fs-7 text-black fw-bold"> ${log.whatsapp_template_name ?? '-'}</span>
                                        <span class="fs-8 d-block text-dark fw-semibold"> ${log.template_name ?? '-'}</span>
                                        ${log.template_module ? 
                                        `
                                        <div> <span class="fs-8  badge bg-warning text-black fw-lighter"> ${log.template_module ?? '-'}</span></div>
                                        ` :''}
                                       
                                    </td>
                                    <td>
                                      ${log.message_date_time ?? '-'} 
                                    </td>
                                    <td>
                                   <span class="template-status-badge position-relative">
                                            <span class="badge ${badgeClass} text-capitalize">${log.message_status}</span>
                                            ${log.message_status == 'failed' ?
                                            `<div class="template-status-tooltip shadow-sm">
                                                <div class="tooltip-header">
                                                    <span class="error-icon">⚠️</span>
                                                    <span class="error-title">Message Failed</span>
                                                </div>
 
                                                <div class="tooltip-item">
                                                    <span class="label">Error Code</span>
                                                    <span class="value error-code">${log.errorData?.code || '-'}</span>
                                                </div>
 
                                                <div class="tooltip-item">
                                                    <span class="label">Message</span>
                                                    <span class="value text-black fw-bold">${log.errorData?.message || '-'}</span>
                                                </div>
 
                                                <div class="tooltip-item">
                                                    <span class="label">Details</span>
                                                    <span class="value text-black fw-bold">
                                                        ${log.errorData?.error_data?.details || '-'}
                                                    </span>
                                                </div>
 
                                                <hr class="my-1">
                                                <div class="tooltip-item">
                                                    <a href="${log.errorData?.href || '#'}" class="view-docs-link" target="_blank">View Docs</a>
                                                </div>
                                            </div>
                                            `
                                            :
                                            ''
                                            }
                                           
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-end">
                                            <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                                aria-haspopup="true" aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                                <a href="javascript:;" 
                                                class="dropdown-item view-message"
                                                data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_whatsapp_template_content_view"
                                                data-logdata="${encodeURIComponent(JSON.stringify(log))}"
                                                data-template="${encodeURIComponent(JSON.stringify(log.template_payload))}"
                                                data-payload="${encodeURIComponent(JSON.stringify(log.payload))}">
                                                    <i class="mdi mdi-eye-outline fs-3 text-black"></i> View Message
                                                </a>
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                            `;
                        });
                    }

                    $('#logTableBody').html(rows);
                    renderPagination(res.data);
                }
            },
            error: function() {
                $('#logTableBody').html(`<tr><td colspan="5" class="text-center text-danger">Error loading data</td></tr>`);
            }
        });
    }

    // ðŸ‘‡ Smart Pagination Function
    function renderPagination(pagination) {
        let pagHtml = '';
        const total = pagination.last_page;
        const current = pagination.current_page;

        if (total <= 1) {
            $('#pagination').html('');
            return;
        }

        let start = Math.max(1, current - 2);
        let end = Math.min(total, current + 2);

        // Always show first and last pages when far away
        if (start > 1) {
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`;
            if (start > 2) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }

        for (let i = start; i <= end; i++) {
            pagHtml += `<li class="page-item ${i === current ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>`;
        }

        if (end < total) {
            if (end < total - 1) pagHtml += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
            pagHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${total}">${total}</a></li>`;
        }

        // Previous / Next
        let prevDisabled = current === 1 ? 'disabled' : '';
        let nextDisabled = current === total ? 'disabled' : '';
        pagHtml = `<li class="page-item ${prevDisabled}">
                        <a class="page-link" href="#" data-page="${current - 1}">Previous</a>
                    </li>` + pagHtml +
                   `<li class="page-item ${nextDisabled}">
                        <a class="page-link" href="#" data-page="${current + 1}">Next</a>
                    </li>`;

        $('#pagination').html(pagHtml);
    }

    // Event bindings
    $('#filterBtn').click(function() {
        currentPage = 1;
        loadLogs();
    });

    $('#pagination').on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (!page || $(this).parent().hasClass('disabled') || $(this).parent().hasClass('active')) return;
        currentPage = page;
        loadLogs(page);
    });
    $('#branchSelectsgoal').change(function() {
        currentPage = 1;
        loadLogs();
    });
    // Initial load
    loadLogs();
    
     $.ajax({
        // route from hr_directory web.php
        url: "{{ route('department') }}"
        , type: "GET"
        , success: function(response) {
            console.warn(response);
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched hr directory
                var selectDropdown = $('select[name="department_fill"]');
                selectDropdown.empty();
                selectDropdown.append($('<option value="">Select Department</option>'));
                response.data.forEach(function(dpt_list) {
                    var option = $('<option></option>').attr('value', dpt_list.sno)
                        .text(dpt_list.department_name);
                    selectDropdown.append(option);
                });
            }
        }
        , error: function(error) {
            console.error('Error fetching Department:', error);
        }
    });
});
</script>

<script>
$(document).ready(function () {

    // 🧩 Open Modal
    $('#clearLog').on('click', function () {
        $('#monthSelect').val('');
        $('#clearLogModal').modal('show');
    });

    // 🗑 Confirm Clear
    $('#confirmClear').on('click', function () {
        const months = $('#monthSelect').val();

        if (!months) {
            alert('Please select how many months to clear.');
            return;
        }

        if (!confirm(`Are you sure you want to delete logs older than ${months} month(s)?`)) {
            return;
        }

        $.ajax({
            url: '/logs/clear',
            type: 'POST',
            data: {
                months: months,
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {
                $('#confirmClear').prop('disabled', true).text('Clearing...');
            },
            success: function (response) {
                $('#clearLogModal').modal('hide');
                toastr.success(response.message);

                // ✅ Refresh the table after deletion
                if (typeof loadLogs === 'function') {
                    loadLogs();
                } else {
                    console.warn('⚠️ loadLogs() function not found.');
                }
            },
            error: function (xhr) {
                alert('Error clearing logs: ' + (xhr.responseJSON?.message || 'Unknown error'));
            },
            complete: function () {
                $('#confirmClear').prop('disabled', false).text('Clear Logs');
            }
        });
    });
});
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
         "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            // "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

</script>
        <script>
            // function viewContent(template ,payload) {
                
            //     const components = payload?.template?.components || [];
            //     // ---- META ----
            //     $('#template_meta').html(`
            //         <div class="template-meta">
            //             <b>Name:</b> ${template.name}<br>
            //             <b>Parameter Format:</b> ${template.parameter_format}<br>
            //             <b>Category:</b> ${template.category}<br>
            //             <b>Language:</b> ${template.language}<br>
            //             <b>Status:</b> ${template.status}
            //         </div>
            //     `);
            //     console.log(components);

            //     // ---- CLEAR UI ----
            //     $('#wa_header, #wa_body, #wa_footer, #wa_buttons').html('');

            //     const payloadMap = buildPayloadParamMap(
            //             payloadComponents,
            //             template.parameter_format
            //         );

            //     // if(!payload){

            //     // }else{
            //         template.components.forEach(component => {

            //             // ===== HEADER =====
            //             if (component.type === "HEADER") {

            //                 // IMAGE
            //                 if (component.format === "IMAGE") {
            //                     const img = component.example?.header_handle?.[0];
            //                     if (img) {
            //                         $('#wa_header').html(`
            //                             <div class="wa-header">
            //                                 <img src="${img}">
            //                             </div>
            //                         `);
            //                     }
            //                 }

            //                 // TEXT
            //                 if (component.format === "TEXT") {
            //                     $('#wa_header').html(`
            //                         <div class="wa-body"><b>${component.text}</b></div>
            //                     `);
            //                 }

            //                 if (component.format === "DOCUMENT") {
            //                     const docUrl = component.example?.header_handle?.[0];

            //                     // Force WhatsApp sample filename
            //                     // const fileName = "sampleddocs";
            //                     const fileName = component.example?.filename || "sample_document.pdf";

            //                     if (docUrl) {
            //                         $('#wa_header').html(`
            //                             <div class="wa-header">
            //                                 <div class="wa-doc-card">
            //                                     <div class="wa-doc-icon">📄</div>

            //                                     <div class="wa-doc-info">
            //                                         <div class="wa-doc-name">${fileName}</div>
            //                                         <div class="wa-doc-type">pdf</div>
            //                                     </div>
            //                                 </div>
            //                             </div>
            //                         `);
            //                     }
            //                 }
            //             }



            //             // ===== BODY =====
            //             if (component.type === "BODY") {

            //                 let bodyText = component.text;

            //                 // Replace params only if examples exist
            //                 if (component.example) {
            //                     let examples = [];

            //                     if (template.parameter_format === "NAMED") {
            //                         examples = component.example.body_text_named_params || [];
            //                     } else {
            //                         examples = component.example.body_text?.[0] || [];
            //                     }

            //                     bodyText = replaceParams(bodyText, template.parameter_format, examples);
            //                 }

            //                 $('#wa_body').html(`<div class="wa-body">${bodyText}</div>`);
            //             }

            //             // ===== FOOTER =====
            //             if (component.type === "FOOTER") {
            //                 $('#wa_footer').html(`
            //                     <div class="wa-footer">${component.text}</div>
            //                 `);
            //             }

            //             // ===== BUTTONS =====
            //             if (component.type === "BUTTONS") {

            //                 let btnHtml = '';

            //                 component.buttons.forEach(btn => {

            //                     // URL BUTTON
            //                     if (btn.type === "URL") {
            //                         btnHtml += `
            //                             <div class="wa-button" onclick="window.open('${btn.url}','_blank')">
            //                                 ${btn.text}
            //                             </div>
            //                         `;
            //                     }

            //                     // QUICK REPLY BUTTON
            //                     if (btn.type === "QUICK_REPLY") {
            //                         btnHtml += `
            //                             <div class="wa-button">
            //                                 ${btn.text}
            //                             </div>
            //                         `;
            //                     }

            //                 });

            //                 $('#wa_buttons').html(`<div class="wa-buttons">${btnHtml}</div>`);
            //             }

            //         });
            //     // }

                
            // }

            // function viewContent(template, payload) {

            //     const payloadComponents = payload?.template?.components || [];

            //     // META
            //     $('#template_meta').html(`
            //         <div class="template-meta">
            //             <b>Name:</b> ${template.name}<br>
            //             <b>Parameter Format:</b> ${template.parameter_format}<br>
            //             <b>Category:</b> ${template.category}<br>
            //             <b>Language:</b> ${template.language}<br>
            //             <b>Status:</b> ${template.status}
            //         </div>
            //     `);

            //     // CLEAR UI
            //     $('#wa_header, #wa_body, #wa_footer, #wa_buttons').html('');

            //     // Build payload map ONCE
            //     const payloadMap = buildPayloadParamMap(
            //         payloadComponents,
            //         template.parameter_format
            //     );

            //     // Render ONLY from template
            //     template.components.forEach(component => {

            //         // ===== HEADER =====
            //         if (component.type === 'HEADER') {

            //             if (component.format === 'IMAGE') {
            //                 const img = component.example?.header_handle?.[0];
            //                 if (img) {
            //                     $('#wa_header').html(`
            //                         <div class="wa-header">
            //                             <img src="${img}">
            //                         </div>
            //                     `);
            //                 }
            //             }

            //             if (component.format === 'TEXT') {
            //                 $('#wa_header').html(`<div class="wa-body"><b>${component.text}</b></div>`);
            //             }

            //             if (component.format === 'DOCUMENT') {
            //                 $('#wa_header').html(`
            //                     <div class="wa-header">
            //                         <div class="wa-doc-card">
            //                             <div class="wa-doc-icon">📄</div>
            //                             <div class="wa-doc-info">
            //                                 <div class="wa-doc-name">sampleddocs</div>
            //                                 <div class="wa-doc-type">PDF</div>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 `);
            //             }
            //         }

            //         // ===== BODY =====
            //         if (component.type === 'BODY') {

            //             let examples = [];
            //             if (component.example) {
            //                 examples = template.parameter_format === 'NAMED'
            //                     ? component.example.body_text_named_params || []
            //                     : component.example.body_text?.[0] || [];
            //             }

            //             const bodyText = replaceFromPayload(
            //                 component.text,
            //                 template.parameter_format,
            //                 payloadMap,
            //                 examples
            //             );

            //             $('#wa_body').html(`<div class="wa-body">${bodyText}</div>`);
            //         }

            //         // ===== FOOTER =====
            //         if (component.type === 'FOOTER') {
            //             $('#wa_footer').html(`<div class="wa-footer">${component.text}</div>`);
            //         }

            //         // ===== BUTTONS =====
            //         if (component.type === 'BUTTONS') {
            //             let btnHtml = '';

            //             component.buttons.forEach(btn => {
            //                 btnHtml += `<div class="wa-button">${btn.text}</div>`;
            //             });

            //             $('#wa_buttons').html(`<div class="wa-buttons">${btnHtml}</div>`);
            //         }
            //     });
            // }

        </script>


        <!-- <script>
            function replaceParams(text, format, exampleParams) {
                if (format === "NAMED") {
                    exampleParams.forEach(p => {
                        let value = (p.example.toLowerCase() === "sundaresh") ? "Alex" : p.example;
                        const regex = new RegExp('\\{\\{' + p.param_name + '\\}\\}', 'g');
                        text = text.replace(regex, value);
                    });
                }

                if (format === "POSITIONAL") {
                    exampleParams.forEach((value, index) => {
                        value = (value.toLowerCase() === "sundaresh") ? "Alex" : value;
                        const regex = new RegExp('\\{\\{' + (index + 1) + '\\}\\}', 'g');
                        text = text.replace(regex, value);
                    });
                }

                return text;
            }
        </script> -->

        <script>
            function buildPayloadParamMap(payloadComponents = [], format) {
                const named = {};
                const positional = [];

                payloadComponents.forEach(comp => {

                    // HEADER
                    if (comp.type === 'header') {
                        comp.parameters?.forEach(p => {
                            if (p.type === 'text') {
                                format === 'NAMED'
                                    ? named[p.parameter_name] = p.text
                                    : positional.push(p.text);
                            }
                        });
                    }

                    // BODY
                    if (comp.type === 'body') {
                        comp.parameters?.forEach(p => {
                            if (p.type === 'text') {
                                format === 'NAMED'
                                    ? named[p.parameter_name] = p.text
                                    : positional.push(p.text);
                            }
                        });
                    }

                    // BUTTONS (URL / QUICK_REPLY)
                    if (comp.type === 'button') {
                        comp.parameters?.forEach(p => {
                            if (p.type === 'text') {
                                positional.push(p.text);
                            }
                        });
                    }
                });

                return format === 'NAMED' ? named : positional;
            }


            function replaceFromPayload(text, format, payloadMap, fallbackExamples = []) {
                // NAMED
                if (format === 'NAMED') {

                    // First replace from payload
                    Object.keys(payloadMap).forEach(key => {
                        const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
                        text = text.replace(regex, payloadMap[key]);
                    });

                    // Fallback → template example
                    fallbackExamples.forEach(p => {
                        const regex = new RegExp(`\\{\\{${p.param_name}\\}\\}`, 'g');
                        text = text.replace(regex, p.example);
                    });
                }

                // POSITIONAL
                if (format === 'POSITIONAL') {

                    payloadMap.forEach((value, index) => {
                        const regex = new RegExp(`\\{\\{${index + 1}\\}\\}`, 'g');
                        text = text.replace(regex, value);
                    });

                    // Fallback example
                    fallbackExamples.forEach((value, index) => {
                        const regex = new RegExp(`\\{\\{${index + 1}\\}\\}`, 'g');
                        text = text.replace(regex, value);
                    });
                }

                return text;
            }


            function getPayloadComponent(payloadComponents, type) {
                return payloadComponents.find(c => c.type === type.toLowerCase());
            }

            function getButtonPayload(payloadComponents, index) {
                return payloadComponents.find(
                    c => c.type === 'button' && c.index === index
                );
            }


            function viewContent(template, payload,logData) {

                    const badgeClass = logData.message_status == 'sent' ? 'bg-secondary':(logData.message_status == 'delivered' ? 'bg-info' :(logData.message_status == 'read' ? 'bg-success' : 'bg-danger') );
                            
                    const branchBadgeClass = (logData.branch_name === 'Unknown' || !logData.branch_name)
                        ? 'bg-danger text-white'
                        : 'bg-info';

                $('#template_meta').html(`
                    <div class="wa-meta-card">
                        <div class="wa-meta-header">
                            <span class="wa-phone">${logData.receiver_no}</span>
                            <span class="badge ${badgeClass}">${logData.message_status}</span>
                        </div>

                        <div class="wa-meta-grid">
                            <div>
                                <span class="label">Receiver</span>
                                <span class="value">${logData.receiver_name ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Branch</span>
                                <span class="badge ${branchBadgeClass}">
                                    ${logData.branch_name ?? '-'}
                                </span>
                            </div>

                            <div>
                                <span class="label">Template</span>
                                <span class="value">${logData.template_name ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Sent At</span>
                                <span class="value">${logData.message_date_time ?? '-'}</span>
                            </div>

                            <div>
                                <span class="label">Delivered</span>
                                <span class="value">
                                    ${logData.message_status === 'delivered' || logData.message_status === 'read'
                                        ? logData.delivered_date_time
                                        : '-'}
                                </span>
                            </div>

                            <div>
                                <span class="label">Read</span>
                                <span class="value">
                                    ${logData.message_status === 'read'
                                        ? logData.read_date_time
                                        : '-'}
                                </span>
                            </div>

                            <div>
                                <span class="label">Failed</span>
                                <span class="value text-danger">
                                    ${logData.message_status === 'failed'
                                        ? logData.failed_date_time
                                        : '-'}
                                </span>
                            </div>
                        </div>
                    </div>
                `);


                // ---------- HARD GUARDS ----------
                if (!template || typeof template !== 'object') {
                    console.error('Invalid template object', template);
                    return;
                }

                if (!Array.isArray(template.components)) {
                    console.error('Template components missing', template);
                    return;
                }

                const payloadComponents = payload?.template?.components;
                const format = template.parameter_format || 'NAMED';

                const payloadMap = Array.isArray(payloadComponents)
                    ? buildPayloadParamMap(payloadComponents, format)
                    : (format === 'NAMED' ? {} : []);

                // reset UI
                $('#wa_header, #wa_body, #wa_footer, #wa_buttons').html('');

                // ---------- TEMPLATE RENDER ----------
                template.components.forEach(component => {

                    /* ================= HEADER ================= */
                    if (component.type === 'HEADER') {

                        const payloadHeader = payloadComponents?.find(c => c.type === 'header');

                        // IMAGE / DOCUMENT
                        if (component.format === 'IMAGE' || component.format === 'DOCUMENT') {

                            const img =
                                payloadHeader?.parameters?.[0]?.image?.link ||
                                component.example?.header_handle?.[0];

                            if (img) {
                                $('#wa_header').html(`
                                    <div class="wa-header">
                                        <img src="${img}">
                                    </div>
                                `);
                            }
                        }

                        // TEXT
                        if (component.format === 'TEXT') {
                            const text =
                                payloadHeader?.parameters?.[0]?.text ||
                                component.text ||
                                '';

                            $('#wa_header').html(`<div class="wa-body"><b>${text}</b></div>`);
                        }
                    }

                    /* ================= BODY ================= */
                    if (component.type === 'BODY') {

                        let examples = [];

                        if (component.example) {
                            examples = format === 'NAMED'
                                ? component.example.body_text_named_params || []
                                : component.example.body_text?.[0] || [];
                        }

                        let bodyText = replaceFromPayload(
                            component.text || '',
                            format,
                            payloadMap,
                            examples
                        );
                        bodyText = bodyText.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
 
                        bodyText = bodyText.replace(/\*(.*?)\*/g, '<b>$1</b>');
 
                        bodyText = bodyText.replace(
                            /(https?:\/\/[^\s]+)/g,
                            '<a href="$1" target="_blank" class="wa-link">$1</a>'
                        );

                        $('#wa_body').html(`<div class="wa-body">${bodyText}</div>`);
                    }

                    /* ================= FOOTER ================= */
                    if (component.type === 'FOOTER') {
                        $('#wa_footer').html(
                            `<div class="wa-footer">${component.text || ''}</div>`
                        );
                    }

                    /* ================= BUTTONS ================= */
                    if (component.type === 'BUTTONS' && Array.isArray(component.buttons)) {

                        let btnHtml = '';

                        component.buttons.forEach((btn, index) => {

                            let url = btn.url || '#';

                            const payloadBtn = payloadComponents?.find(
                                c => c.type === 'button' && c.index === index
                            );

                            if (payloadBtn?.parameters?.[0]?.text) {
                                url = url.replace(
                                    /\{\{\d+\}\}/g,
                                    payloadBtn.parameters[0].text
                                );
                            }

                            btnHtml += `
                                <div class="wa-button"
                                    onclick="window.open('${url}','_blank')">
                                    ${btn.text || ''}
                                </div>
                            `;
                        });

                        $('#wa_buttons').html(`<div class="wa-buttons">${btnHtml}</div>`);
                        if(logData.reaction_emoji){
                            $('#wa_reaction').html(`<div class="wa-reaction_emoji">${logData.reaction_emoji}</div>`);
                        }else{
                            $('#wa_reaction').empty();
                        }
                        
                    }
                });
            }


            $(document).on('click', '.view-message', function () {
                try {
                    const template = JSON.parse(
                        decodeURIComponent(this.dataset.template)
                    );

                    const payload = JSON.parse(
                        decodeURIComponent(this.dataset.payload)
                    );
                    const logData = JSON.parse(
                        decodeURIComponent(this.dataset.logdata)
                    );
                    // const logData =$(this).data('logdata');
                    console.log(logData)
                    viewContent(template, payload,logData);

                } catch (err) { console.error('Payload parse failed', err);
                        console.error('Template raw:', this.dataset.template);
                        console.error('Payload raw:', this.dataset.payload);
                }
            });

        </script>

        
@endsection
