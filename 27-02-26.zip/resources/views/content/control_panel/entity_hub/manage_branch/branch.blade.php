@extends('layouts/layoutMaster')

@section('title', 'Manage Branch')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
  @vite(['resources/assets/js/form-wizard-icons.js'])
@endsection


@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Branch</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a  href="{{ url('/branch/add') }}" class="btn btn-sm fw-bold btn-primary text-white" >
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Branch
                    </a>
                     {{-- <a  href="#" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_add_branch" >
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Branch
                    </a> --}}
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Branch..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Branch</th>
                                <th class="min-w-100px">Business Mob No / Email</th>
                                <th class="min-w-100px">Center Head Mob No / Email</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-start">Action</th>
                            </tr>
                        </thead>
                        <tbody  id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Add Branch -->
    <div class="modal fade" id="kt_modal_add_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Add Branch</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                  <div class="bs-stepper wizard-vertical vertical wizard-vertical-icons-example wizard-vertical-icons mt-2 gap-3 ">
                    <div class="bs-stepper-header gap-lg-2">
                      {{-- new --}}
                      <div class="step" data-target="#Branch">
                        <button type="button" class="step-trigger">

                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-code-branch"></i>
                            </span>
                          </span>

                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Branch Information</span>
                            <span class="bs-stepper-subtitle">Setup Branch Information</span>
                          </span>
                        </button>
                      </div>

                       <div class="step" data-target="#location">
                        <button type="button" class="step-trigger">

                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-code-branch"></i>
                            </span>
                          </span>

                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Address And Location</span>
                            <span class="bs-stepper-subtitle">Setup Address And Location</span>
                          </span>
                        </button>
                      </div>

                      <div class="step" data-target="#Contact">
                        <button type="button" class="step-trigger">
                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-phone"></i>
                            </span>
                          </span>
                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Contact & Online Presence</span>
                            <span class="bs-stepper-subtitle">Setup Contact & Online Presence</span>
                          </span>
                        </button>
                      </div>

                      <div class="step" data-target="#Compliance">
                        <button type="button" class="step-trigger">
                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-handshake"></i>
                            </span>
                          </span>
                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Compliance & Agreements</span>
                            <span class="bs-stepper-subtitle">Setup Compliance & Agreements</span>
                          </span>
                        </button>
                      </div>

                      <div class="step" data-target="#Collection">
                        <button type="button" class="step-trigger">
                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-grip"></i>
                            </span>
                          </span>
                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Collection Info</span>
                            <span class="bs-stepper-subtitle">Setup Collection Info</span>
                          </span>
                        </button>
                      </div>

                      <div class="step" data-target="#Banking">
                        <button type="button" class="step-trigger">
                          <span class="avatar">
                            <span class="avatar-initial rounded-2">
                              <i class="fa-solid fa-building-columns"></i>
                            </span>
                          </span>
                          <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Banking & Authorization</span>
                            <span class="bs-stepper-subtitle">Setup Banking & Authorization</span>
                          </span>
                        </button>
                      </div>
                    </div>
                    <div class="bs-stepper-content">
                      <form onSubmit="return false">
                        {{-- new --}}

                        <div id="Branch" class="content">
                          <div class="row">
                            <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                                  <select class="select3 form-select">
                                      <option value="">Select Company</option>
                                      <option value="1">Elysium Technologies Pvt Ltd</option>
                                  </select>
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                                  <select class="select3 form-select">
                                      <option value="">Select Entity</option>
                                      <option value="1">phdizone</option>
                                      <option value="1">Elysium Pro</option>
                                      <option value="1">MyProjectBazaar</option>
                                      <option value="1">ClickMyProject</option>
                                  </select>
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Branch Name" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Branch Category<span
                                          class="text-danger">*</span></label>
                                  <select class="select3 form-select">
                                      <option value="">Select Branch Category</option>
                                      <option value="1">Branch - CICO</option>
                                      <option value="2">Branch - CIFO</option>
                                      <option value="3">Branch - FICO</option>
                                      <option value="3">Branch - FIFO</option>
                                  </select>
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Share (as %)<span class="text-danger">*</span></label>
                                  <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                      title="Share For Brand In Percentage"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
                                  <input type="text" class="form-control" placeholder="Enter Share (as %)" />
                              </div>
                          </div>
                        </div>

                        <div id="location" class="content">
                          <div class="row">

                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                                    <select class="select3 form-select">
                                        <option value="">Select Country</option>
                                        <option value="1">USA</option>
                                        <option value="2">UAE</option>
                                        <option value="3">India</option>
                                        <option value="4">South Africa</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                                    <select class="select3 form-select">
                                        <option value="">Select State</option>
                                        <option value="1">Tamilnadu</option>
                                        <option value="2">Andhra Pradesh</option>
                                        <option value="3">Kerala</option>
                                        <option value="4">Karnataka</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                                    <select class="select3 form-select">
                                        <option value="">Select City</option>
                                        <option value="1">Madurai</option>
                                        <option value="2">Virudhunagar</option>
                                        <option value="3">Thirunelveli</option>
                                        <option value="4">Coimbatore</option>
                                        <option value="5">Chennai</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Area / Street" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Pincode" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter City Short Code" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Latitude" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Longitude" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                                    <select class="select3 form-select">
                                        <option value="">Select Time Zone</option>
                                        <option value="1">India (UTC +05:30)</option>
                                        <option value="2">United States (UTC -04:00)</option>
                                        <option value="3">United Kingdom (UTC +01:00)</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span
                                          class="text-danger">*</span></label>
                                  <select class="select3 form-select">
                                      <option value="">Select Currency Format</option>
                                      <option value="1">INR - &#8377;</option>
                                  </select>
                              </div>
                              </div>

                        </div>

                        <div id="Contact" class="content">
                          <div class="row">
                            <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                                  <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span
                                          class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Business Mobile No" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span
                                          class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Business Email ID" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span
                                          class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Communication Email ID" />
                              </div>
                              <div class="row">
                                <div class="col-lg-12">
                                  <div class="divider text-start-center">
                                    <div class="divider-text text-black fs-5">Online Presence</div>
                                  </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Location URL" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Website URL" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                                    <input type="text" class="form-control" placeholder="Enter Facebook Link" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                                    <input type="text" class="form-control" placeholder="Enter Instagram Link" />
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                                    <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code" />
                                </div>
                              </div>

                          </div>
                        </div>
                        <div id="Compliance" class="content">
                          <div class="row">
                            <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                                  <input type="text" class="form-control" placeholder="Enter CIN No" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                                  <input type="text" class="form-control" placeholder="Enter GST No" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                                  <input type="text" class="form-control" placeholder="Enter PAN No" />
                              </div>
                              <div class="row">
                                <div class="col-lg-12">
                                  <div class="divider text-start-center">
                                    <div class="divider-text text-black fs-5">Agreement Info</div>
                                  </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="agree_stdt" placeholder="Select Date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="agree_eddt" placeholder="Select Date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="open_dt" placeholder="Select Date" class="form-control">
                                    </div>
                                </div>
                              </div>

                          </div>
                        </div>
                        <div id="Collection" class="content">
                          <div class="row">
                            <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span
                                          class="text-danger">*</span></label>
                                  <div class="input-group input-group-merge">
                                      <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                      <input type="text" id="cllt_cl_dt" placeholder="Select Date" class="form-control">
                                  </div>
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span
                                          class="text-danger">*</span></label>
                                  <div class="input-group input-group-merge">
                                      <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                      <input type="text" id="reg_cl_dt" placeholder="Select Date" class="form-control">
                                  </div>
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span
                                          class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Minimum Amount Receive" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <input class="form-check-input" type="checkbox" id="bus_cls_dt" onclick="bus_cls_dt_func();" />
                                  <label class="text-black mb-1 fs-6 fw-semibold" id="bus_cls_dt_txt">Business Closing Date (In
                                      Count)<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" id="bus_cls_dt_tbox"
                                      placeholder="Enter Business Closing Date(In Count)" />
                              </div>
                              <div class="row">
                                <div class="col-lg-12">
                                  <div class="divider text-start-center">
                                    <div class="divider-text text-black fs-5">API Details</div>
                                  </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                                    <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key"></textarea>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control h-auto" rows="1" placeholder="Enter Description"></textarea>
                                </div>
                              </div>

                          </div>
                        </div>
                        <div id="Banking" class="content">
                          <div class="row">
                            <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Bank Name" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                          class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Account Holder" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter Account No" />
                              </div>
                              <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                              </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Submit</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Branch-->

    <!--begin::Modal - Center Head Assignee -->
    <div class="modal fade" id="kt_modal_center_head_assign" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Add Center Head Assignee</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row mb-6">
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Person Name<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Person Name </option>
                                <option value="1" selected>Muthumari A</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                            <input type="text" class="form-control" placeholder="Enter Mobile Number" value="9944049888" readonly />
                        </div>
                        <div class="col-lg-4 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Position</label>
                            <input type="text" class="form-control" placeholder="Enter Position" value="Center Head" readonly />
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Assign</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -Center Head Assignee-->

    <!--begin::Modal - Assign CUG & Mail -->
    <div class="modal fade" id="kt_modal_assign_cug_mail" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Communication</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row mb-6">
                    <div class="col-lg-8 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Communication Staff<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Communication Staff</option>
                            <option value="1" selected>Anusha E - Process Co-Ordinator (PC)</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Mobile No</label>
                        <input type="text" class="form-control" placeholder="Enter Mobile Number" value="8870200389" readonly />
                    </div>
                </div>
                <div class="form-repeater_cug_mob_mail">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-4">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                                            <select id="" class="select3 form-select">
                                                <option value="">Select Staff</option>
                                                <option value="1">Gurumoorthi S - Senior Sales Executive</option>
                                                <option value="2">Palaniyammal D - Sales Coordinator</option>
                                                <option value="3">Arulmozhi E - Sales Team Lead</option>
                                                <option value="4" selected>Monisha K - Sales Executive</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black fs-6 fw-semibold">Mobile No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Mobile No" />
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <div class="mb-1">
                                                <input class="form-check-input" type="checkbox" id="email_chk" onclick="email_func();" />
                                                <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: none !important;" id="email_req">*</span></label>
                                            </div>
                                            <input type="text" class="form-control" id="email_tbox" placeholder="Enter Email ID" style="display: none !important;" />
                                        </div>
                                        <div class="col-lg-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 cug_mail_mail_del" id="cug_mail_mail_del" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-1 mt-1">
                    <button class="btn btn-sm btn-primary cug_mob_mail_add px-2 py-1" data-repeater-create id="cug_mob_mail_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Assign</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -Assign CUG & Mail-->

    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Phdizone Madurai Branch</b>
                        Branch ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deletebranch()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->

    <!--begin::Modal View Branch--->
    <div class="modal fade" id="kt_modal_view_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                      <div class="avatar-stack">
                              <img src="{{ asset('assets/newImgs/company-buildingNew1.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/newImgs/company-building.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/newImgs/apartment.png') }}" alt="user-avatar" class="avatar-img" />
                        </div>
                        <div class="row mb-2">
                            <h3 class="text-black">View Branch</h3>
                        </div>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="row mb-3">
                        <div class="nav-align-top nav-tabs-shadow mb-3">
                            <ul class="nav nav-tabs" role="tablist">
                                  <li class="nav-item">
                                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#Branchhh" aria-controls="Branchhh"
                                        aria-selected="false">
                                       Branch
                                    </button>
                                  </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#bankinfo" aria-controls="bankinfo"
                                        aria-selected="false">
                                        Bank Info
                                    </button>
                                </li>

                                 <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#API" aria-controls="API"
                                        aria-selected="false">
                                        API Details
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#Communication" aria-controls="Communication"
                                        aria-selected="false">
                                        Communication Details
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="Branchhh" role="tabpanel">
                               <div class="row">
                                   <div class="col-lg-8">
                                      <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <label class="col-6 text-black fs-6 fw-semibold">PhDiZone Madurai</label>
                                      </div>
                                      <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Branch Category</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <label class="col-6 text-black fs-6 fw-semibold">Branch - CIFO</label>
                                      </div>
                                      <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">City Short Code</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <label class="col-6 text-black fs-6 fw-semibold">MDU</label>
                                      </div>
                                      <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Opening Date</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <label class="col-6 text-black fs-6 fw-semibold">01-Jan-2026</label>
                                      </div>
                                    </div>


                                <div class="col-lg-4 ">
                                  <div class="d-flex flex-column justify-content-center align-items-center gap-2">
                                      <div class="symbol symbol-35px me-2">
                                          <div class="image-input image-input-circle" data-kt-image-input="true">
                                              <img src="{{ asset('assets/egc_images/auth/user_3.png') }}"
                                                  alt="user-avatar" class="w-px-100 h-auto rounded-circle"
                                                  id="uploadedlogo" style="border: 2px solid #ab2b22;" />
                                          </div>
                                      </div>
                                      <div class="text-center d-flex flex-column">
                                          <label class="fs-6 text-black fw-semibold text-primary"  data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Center Head">Arun MK</label>
                                          <label class="fs-6 text-black fw-semibold text-secondary">7484571296</label>
                                      </div>

                                  </div>
                                </div>


                                <div class="row mt-1">

                                  <div class="col-lg-6">
                                     <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Facebook Link</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold ">
                                        <div class="text-truncate max-w-75"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="https://www.facebook.com/PhDiZone">
                                          <a href="https://www.facebook.com/PhDiZone" > https://www.facebook.com/PhDiZone</a>
                                        </div>

                                      </label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                     <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Instagram Link</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold">
                                       <div class="text-truncate max-w-75"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="instagram.com/phdizoneresearch/">
                                        <a href="instagram.com/phdizoneresearch/"> instagram.com/phdizoneresearch/</a>
                                      </div>
                                      </label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                     <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Website Link</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold">
                                        <div  class="text-truncate max-w-75"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="https://phdizone.com/"><a href="https://phdizone.com/"> https://phdizone.com/ </a></div>
                                      </label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Latitude</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold"> 9.930456964894685</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Longitude</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold">78.14626761197358</label>
                                    </div>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-lg-12 mb-3">
                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-black fw-semibold">Legal & Tax</div>
                                    </div>
                                  </div>
                                      <div class="col-lg-6">
                                         <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="27AABCU9603R1ZV">
                                                    27AABCU9603R1ZV</div>
                                            </div>
                                        </div>
                                      </div>
                                      <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="U12345MH2005PTC123456">U12345MH2005PTC123456
                                                </div>
                                            </div>
                                        </div>
                                      </div>
                                      <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="AABCU9603R">
                                                    AABCU9603R</div>
                                            </div>
                                        </div>
                                      </div>
                                      <div class="col-lg-6">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Tax No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="1234567890">
                                                    1234567890</div>
                                            </div>
                                        </div>
                                      </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 mb-3">
                                      <div class="divider text-start-center">
                                        <div class="divider-text fs-5 text-black fw-semibold">Collection Info</div>
                                      </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-4">
                                          <label class="col-5 text-dark fs-7 fw-semibold">Collection Closing Data</label>
                                          <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                          <label class="col-6 text-black fs-6 fw-semibold">30-Nov-2026</label>
                                      </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-4">
                                          <label class="col-5 text-dark fs-7 fw-semibold">Registeration Closing Data</label>
                                          <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                          <label class="col-6 text-black fs-6 fw-semibold">01-Sep-2026</label>
                                      </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-4">
                                          <label class="col-5 text-dark fs-7 fw-semibold">Minimum Amount Receive</label>
                                          <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                          <label class="col-6 text-black fs-6 fw-semibold">2000</label>
                                      </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-4">
                                          <label class="col-5 text-dark fs-7 fw-semibold">Business Closing Data</label>
                                          <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                          <label class="col-6 text-black fs-6 fw-semibold">-</label>
                                      </div>
                                    </div>
                                </div>
                               </div>
                              </div>
                            <div class="tab-pane fade" id="bankinfo" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row">
                                          <div class="col-lg-6">
                                              <div class="row mb-4">
                                                  <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                                  <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                  <label class="col-6 text-black fs-6 fw-semibold">HDFC</label>
                                              </div>
                                          </div>
                                          <div class="col-lg-6">
                                              <div class="row mb-4">
                                                  <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                                  <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                  <label class="col-6 text-black fs-6 fw-semibold">Anna Nagar</label>
                                              </div>
                                          </div>
                                          <div class="col-lg-6">
                                              <div class="row mb-4">
                                                <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-6 fw-semibold">HDFC0002027</label>
                                              </div>
                                          </div>
                                          <div class="col-lg-6">
                                            <div class="row mb-4">
                                                <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                <label class="col-6 text-black fs-6 fw-semibold">Elysium Intelligence Business
                                                    Solutions</label>
                                            </div>
                                          </div>
                                          <div class="col-lg-6">
                                             <div class="row mb-4">
                                                  <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                                  <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                                  <label class="col-6 text-black fs-6 fw-semibold">8574854578452</label>
                                              </div>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="API" role="tabpanel">
                              <div class="row">
                                <div class="col-lg-6">
                                  <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Cloud Call API Key</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold">-</label>
                                  </div>
                                </div>
                                <div class="col-lg-6">
                                   <div class="row mb-4">
                                      <label class="col-5 text-dark fs-7 fw-semibold">Description</label>
                                      <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                      <label class="col-6 text-black fs-6 fw-semibold">-</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="tab-pane fade" id="Communication" role="tabpanel">
                              <div class="row">
                                <div class="col-lg-12">
                                  <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                                        <thead>
                                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communication Staff</th>
                                                <th class="min-w-200px">Position</th>
                                                <th class="min-w-100px">Mobile No</th>
                                                <th class="min-w-100px">Email ID</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                            <tr>
                                               <td>
                                                    <div class="d-flex align-items-center justify-content-start">
                                                        <div class="border border-gray-400i rounded me-2">
                                                                <img src="{{ asset('assets/newImgs/user_3.png') }}" alt="user image" class="w-px-40 h-auto rounded-circle">

                                                        </div>
                                                        <div class="mb-0">
                                                            <div class="text-truncate max-w-175px fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Anusha E">Anusha E</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label class=" fw-semibold fs-7 text-black">Process Co Ordinator (PC)	</label>
                                                </td>
                                                <td>
                                                     <label class=" fw-semibold fs-7 text-black">8870200389	</label>
                                                </td>
                                                <td>
                                                     <label class=" fw-semibold fs-7 text-black">presale@phdizone.com</label>
                                                </td>
                                            </tr>
                                            <tr>
                                               <td>
                                                    <div class="d-flex align-items-center justify-content-start">
                                                        <div class="border border-gray-400i rounded me-2">
                                                                <img src="{{ asset('assets/newImgs/user_3.png') }}" alt="user image" class="w-px-40 h-auto rounded-circle">

                                                        </div>
                                                        <div class="mb-0">
                                                            <div class="text-truncate max-w-175px fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Monisha K">Monisha K</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label class=" fw-semibold fs-7 text-black">Sales Executive (SE)</label>
                                                </td>
                                                <td>
                                                     <label class=" fw-semibold fs-7 text-black">9677722623	</label>
                                                </td>
                                                <td>
                                                     <label class=" fw-semibold fs-7 text-black">presale@phdizone.com</label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal View Branch-->


<!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
   <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#filter_form').submit();
            }
        }
    </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${data.company_base_color || ''};"></div>
                    <div class="d-flex align-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom"   title="${item.branch_name}">${item.branch_name}</div>
                            </div>
                        </div>
                        <label data-bs-toggle="modal" data-bs-target="#kt_modal_location_map">
                            <i class="mdi mdi-map-marker-radius fs-4 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom"  title="${item.branch_address} "></i>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <label class=" fw-semibold fs-7 text-black">${item.mobile}</label>
                            </div>
                            <div class="d-block">
                                <label class="text-secondary fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"   title="${item.mail}">${item.mail}</label>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center align-items-center gap-2">
                                <label class=" fw-semibold fs-7 text-black">${item.centerHead_name || '-'}</label>
                                <i class="fa-solid fa-at fs-5 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"   title="${item.centerHead_email || '-'}"></i>
                            </div>
                            <div class="d-block">
                                <label class="text-secondary fw-semibold fs-8">${item.centerHead_mobile|| '-'}</label>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)" />
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                  <span class="text-end">
                      <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-2 waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#kt_modal_view_branch" onclick="viewmodel('${item.sno}')">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="View" data-bs-original-title="View"><i class="mdi mdi-eye fs-3 text-black"></i></span>
                      </a>
                      <a href="{{url('/manage_staff/add_staff')}}" target="_blank" class="btn btn-icon btn-sm p-0 me-2 waves-effect waves-light" title="Staff Add">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Staff Add" data-bs-original-title="Staff Add"><i class="mdi mdi-account-plus-outline fs-3 text-black"></i></span>
                      </a>
                      <a class="btn btn-icon btn-sm p-0 me-2 waves-effect waves-light" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                      </a>
                      <div class="dropdown-menu dropdown-menu-end" style="width:200px;">
                          <a href="javascript:;" class="dropdown-item waves-effect" data-bs-toggle="modal" data-bs-target="#kt_modal_center_head_assign">
                              <span><i class="mdi mdi-account-group-outline fs-3 text-black me-1"></i></span>
                              <span>Center Head Assign</span>
                          </a>
                          <a href="javascript:;" class="dropdown-item waves-effect" data-bs-toggle="modal" data-bs-target="#kt_modal_assign_cug_mail">
                              <span><i class="mdi mdi-cellphone-message fs-3 text-black me-1"></i></span>
                              <span>Assign CUG &amp; Mail</span>
                          </a>
                          <a  href="{{ url('/branch/edit') }}" target="_blank" class="dropdown-item waves-effect">
                              <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                              <span>Edit</span>
                          </a>
                          <a href="javascript:;" class="dropdown-item waves-effect" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_branch" onclick="confirmDelete('${item.sno}','${item.branch_name}')">
                              <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                              <span>Delete</span>
                          </a>
                      </div>
                  </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/entity_hub/manage_branch?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(5));
            }
                 $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
        function updatelevelStatus(UniversityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/branch_status/${UniversityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Branch status Updated successfully!');
                        loadThemes(1);
                    } else {
                        toastr.error('Error updating Branch status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Branch status:', error);
                });
        }
    </script>
    <script>
        function confirmDelete(sno, name) {
            document.querySelector('#kt_modal_delete_branch .btn-danger').setAttribute(
                'data-id', sno);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Branch ?');
        }

        function deletebranch() {

            var universityId = document.querySelector('#kt_modal_delete_branch .btn-danger').getAttribute('data-id');

            fetch('/branch_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Branch Deleted successfully!');
                        location.reload();

                    } else if(data.status === 302) {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function viewmodel(id) {
             // Show skeleton loaders before fetch
            document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                skeleton.style.display = 'block'; // Show skeleton loaders
            });
        
            // Hide actual data elements
            document.querySelectorAll('.view-data').forEach(element => {
                element.style.display = 'none'; // Hide actual data until it is loaded
            });
            
            fetch('/branch_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                          var logoPath = com.entity_logo ? `/Entity_logos/${com.company_id}/${com.entity_logo}` : '/assets/common/logo_small.png';
                         
                        document.getElementById('view_entity_logo').src = logoPath;
                        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                            skeleton.style.display = 'none'; // Hide skeleton loaders
                        });
                        document.querySelectorAll('.view-data').forEach(element => {
                            element.style.display = 'block'; // Show actual data
                        });
                        
                        $('#view_entityname').html(com.entity_name).attr('title', com.entity_name);
                        $('#view_companyname').html(com.company_name).attr('title', com.company_name);
                        $('#view_emailid').html(com.entity_mail).attr('title', com.entity_mail);
                        $('#view_website').html(com.entity_website);
                        $('#view_website_tag').attr('title', com.entity_website).attr('href', com
                            .entity_website);
                        $('#view_websitelink').attr('href', com.entity_website); //entity_ct_person//entity_ct_number
                        $('#view_contactperson').html(com.entity_ct_person).attr('title', com.entity_ct_person);
                        $('#view_cp_mobileno').html(com.entity_ct_number);
                        $('#view_address').html(
                                              (com.entity_door_no || '') +', '+
                                              (com.entity_area || '') +', '+
                                              (com.citiesname || '') +', '+
                                              (com.statename || '') +', '+
                                              (com.name || '')
                                            );
                        $('#view_description').html(com.entity_desc||'-');
                        $('#view_gstno').html(com.entity_gst);
                        $('#view_cinno').html(com.entity_cin);
                        $('#view_panno').html(com.entity_pan);
                        $('#view_bank').html(com.entity_bank_name);
                        $('#view_branch').html(com.entity_bank_branch);
                        $('#view_accountholder').html(com.entity_acc_holder);
                        $('#view_accountno').html(com.entity_acc_no).attr('title', com.entity_acc_no);
                        $('#view_ifsccode').html(com.entity_ifsc);
                        
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
        
        
    </script>

<script>
    $('.cug_mob_mail_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_cug_mob_mail').length);
        let $clone = $('.form-repeater_cug_mob_mail').first().clone().hide();
        $clone.insertBefore('.form-repeater_cug_mob_mail:first').slideDown();
        if (bt == 1) {
            $('.cug_mail_mail_del').attr('style', 'display: block !important');
        } else {
            $('.cug_mail_mail_del').attr('style', 'display: block !important');
        }
    });
    $(document).on('click', '.form-repeater_cug_mob_mail .cug_mail_mail_del', e => {
        var bt = parseFloat($('.cug_mail_mail_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_cug_mob_mail').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.cug_mail_mail_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    function email_func() {
        var email_chk = document.getElementById("email_chk");
        var email_tbox = document.getElementById("email_tbox");
        var email_req = document.getElementById("email_req");
        if (email_chk.checked) {
            email_tbox.style.display = "block";
            email_req.style.display = "inline";
        } else {
            email_tbox.style.display = "none";
            email_req.style.display = "none";
        }
    }
</script>

@endsection
