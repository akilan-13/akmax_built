@extends('layouts/layoutMaster')

@section('title', 'Manage Entity')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Entity</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            {{-- <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                        <span><i class="mdi mdi-filter-outline"></i></span>
                    </a> -->
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_company">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Entity
                    </a>
                </div>
            </div> --}}
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                   <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Entity..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Entity</th>
                                <th class="min-w-150px">Company</th>
                                <th class="min-w-100px">Contact Person / Mobile</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>



    <!--begin::Modal - Create Department -->
    <div class="modal fade" id="kt_modal_add_department" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Department</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                            <div class="bg-label-primary border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="entity_display" name="entity_display">Phdizone</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Branch / Franchise</option>
                                <optgroup label="Branch">
                                    <option value="1">Phdizone Madurai Branch</option>
                                </optgroup>
                                <optgroup label="Franchise">
                                    <option value="1">Phdizone Virudhunagar</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Department Name" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Description" id="department_desc"
                                name="department_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Department</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Department-->


    <!--begin::Modal - Create Division -->
    <div class="modal fade" id="kt_modal_add_division" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Division</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity</label>
                            <div class="bg-label-primary border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                id="entity_display" name="entity_display">Elysium Technologies</div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span
                                    class="text-danger">*</span></label>
                            <select id="Branch/franchise" class="select3 form-select">
                                <option value="">Select Branch / Franchise</option>
                                <optgroup label="Branch">
                                    <option value="1">Phdizone Madurai Branch</option>
                                </optgroup>
                                <optgroup label="Franchise">
                                    <option value="1">Phdizone Virudhunagar</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                    class="text-danger">*</span></label>
                            <select id="DepartmentDivision" class="select3 form-select ">
                                <option value="">Select Department</option>
                                <option value="">Sales</option>
                                <option value="">Production</option>
                                <option value="">Support</option>
                                <option value="">Management</option>

                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" />
                        </div>

                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Description" id="department_desc"
                                name="department_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Division</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Division-->


    <!--begin::Modal - -->
    <div class="modal fade" id="" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">View Entity</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        {{-- <div class="col-lg-6 mt-4"> --}}
                        <div class="col-lg-4 mb-4" id="staff_view_div">
                            {{-- <label class="col-4 text-dark fs-6 fw-semibold">Entity</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="">PhDiZone
                                    </div>
                                </div> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">Entity</div>
                                <div class="fw-bold fs-5">PhDiZone</div>
                            </div>

                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="">Elysium Technologies Pvt Ltd
                                    </div>
                                </div> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">Company</div>
                                <div class="fw-bold fs-5">Elysium Technologies Pvt Ltd</div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-5 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="">
                                        presale@phdizone.com</div>
                                </div> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">Email ID</div>
                                <div class="fw-bold fs-5">presale@phdizone.com</div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">Website URL</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <div class="col-7">
                                    <a href="" target="_blank" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="">
                                        <div class="text-truncate max-w-75 text-black fs-5 fw-bold">
                                            https://phdizone.com/</div>
                                    </a>
                                </div> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">Website URL</div>
                                <div class="fw-bold fs-5"> https://phdizone.com/</div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">Contact Person</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-5 fw-bold" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="">Muthumari A</div>
                                </div> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">Contact Person</div>
                                <div class="fw-bold fs-5">Muthumari A</div>
                            </div>
                        </div>
                        {{-- </div> --}}
                        {{-- <div class="col-lg-6 mt-2"> --}}
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">GST No</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">29AAGFV1234M1Z6</label> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">GST No</div>
                                <div class="fw-bold fs-5">29AAGFV1234M1Z6</div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">CIN No</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">U67190KA2012LLP012345</label> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">CIN No</div>
                                <div class="fw-bold fs-5">U67190KA2012LLP012345</div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            {{-- <label class="col-4 text-dark fs-5 fw-semibold">PAN No</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">AAGFV1234M</label> --}}
                            <div class="border-start border-6 border-success ps-3">
                                <div class="text-primary small">PAN No</div>
                                <div class="fw-bold fs-5">AAGFV1234M</div>
                            </div>
                        </div>
                         {{-- <div class="row mb-4"> --}}
                    {{-- <label class="col-12 text-dark mb-2 fs-5 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-5 fw-bold">&emsp;&emsp;&emsp; - </label> --}}

                    <div class="col-lg-12 mb-4">
                        {{-- <label class="col-4 text-dark fs-5 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">229, Ist & IInd Floor, A, Block, Elysium
                                    Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</label> --}}
                        <div class="border-start border-6 border-success ps-3">
                            <div class="text-primary small">Address</div>
                            <div class="fw-bold fs-5"> 229, Ist & IInd Floor, A, Block, Elysium
                                Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</div>
                        </div>
                    </div>
                     <div class="col-lg-12 mb-4">
                        <div class="border-start border-6 border-success ps-3">
                            <div class="text-primary small">Description</div>
                            <div class="fw-bold fs-5"> PhDiZone leads PhD Guidance and assistance, thesis dissertation paper writing services and research methodology PhD Assistance in India.</div>
                        </div>
                    </div>
                        {{-- </div> --}}
                    </div>

                    {{-- </div> --}}
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row">

                            <div class="col-lg-4 mb-4">
                                {{-- <label class="col-4 text-dark fs-5 fw-semibold">Bank</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">HDFC</label> --}}

                                <div class="border-start border-6 border-success ps-3">
                                    <div class="text-primary small">Bank</div>
                                    <div class="fw-bold fs-5">HDFC</div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-4">
                                {{-- <label class="col-4 text-dark fs-5 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">Anna Nagar</label> --}}
                                <div class="border-start border-6 border-success ps-3">
                                    <div class="text-primary small">Branch</div>
                                    <div class="fw-bold fs-5">Anna Nagar</div>
                                </div>

                            </div>
                            <div class="col-lg-4 mb-4">
                                {{-- <label class="col-4 text-dark fs-5 fw-semibold">IFSC Code</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">HDFC0002027</label> --}}
                                <div class="border-start border-6 border-success ps-3">
                                    <div class="text-primary small">IFSC Code</div>
                                    <div class="fw-bold fs-5">HDFC0002027</div>
                                </div>

                            </div>
                            <div class="col-lg-4 mb-4">
                                {{-- <label class="col-4 text-dark fs-5 fw-semibold">Account Holder</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">phdizone</label> --}}

                                <div class="border-start border-6 border-success ps-3">
                                    <div class="text-primary small">Account Holder</div>
                                    <div class="fw-bold fs-5">phdizone</div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-4">
                                {{-- <label class="col-4 text-dark fs-5 fw-semibold">Account No</label>
                                <label class="col-1 text-black fs-5 fw-bold">:</label>
                                <label class="col-7 text-black fs-5 fw-bold">6523145278745</label> --}}

                                <div class="border-start border-6 border-success ps-3">
                                    <div class="text-primary small">Account No</div>
                                    <div class="fw-bold fs-5">6523145278745</div>
                                </div>
                            </div>
                        {{-- </div> --}}

                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal --->


    <!--begin::Modal - Update Entity -->
    <div class="modal fade" id="kt_modal_update_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Entity</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form method="POST" action="{{ route('update_entity') }}" id="edit_form_entity" autocomplete="off">
                        @csrf
                    <div class="row mb-6">
                        <input type="hidden" id="edit_id_entity" name="edit_id" />
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select " name="company_id" id="edit_company_id">
                                <option value="">Select Company</option>
                                 @if (isset($Company))
                                    @foreach ($Company as $type_list)
                                    <option value="{{ $type_list->sno }}">{{ $type_list->company_name }}
                                        </option>
                                    @endforeach
                                @endif
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" name="entity_name" id="entity_name_edit" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50" value="">
                            <div class="error_msg text-danger"></div>

                        </div>
                         <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Short Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Short Name"  name="entity_short_name" id="entity_short_name_edit" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="6"/>
                            <div class="error_msg text-danger" id="entity_short_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID"
                                value="" id="entity_mail_edit" name="entity_mail" oninput=" this.value = this.value.toLowerCase();" maxlength="50">
                                <div class="error_msg text-danger"></div>

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL"
                                value="" id="entity_website_url_edit" name="website_url" maxlength="80">
                                <div class="error_msg text-danger"></div>

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">ERP Base URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CRM URL" id="entity_base_url_edit" name="entity_base_url" >
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="location_url_edit" name="location_url"
                                placeholder="Enter Location URL" >
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" id="entity_ct_person_edit" name="ct_person"
                                value="Muthumari A">
                                <div class="error_msg text-danger"></div>

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                maxlength="10"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="entity_ct_per_mobile_no_edit" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>

                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select  class="select3 form-select " id="entity_countryId_edit" name="country">
                                <option value="">Select Country</option>

                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select  class="select3 form-select " id="entity_stateId_edit" name="state">
                                <option value="">Select State</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select  class="select3 form-select " id="entity_cityId_edit" name="city">
                                <option value="">Select City</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" 
                             id="entity_area_street_edit" name="area_street" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" value=""
                              id="entity_door_flat_no_edit" name="door_flat_no" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="entity_pincode_edit" name="pincode" maxlength="10" />
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                            <input type="text" class="form-control" placeholder="Enter GST No"
                               id="entity_gst_no_edit" name="gst_no" maxlength="30" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                            <input type="text" class="form-control" placeholder="Enter CIN No"
                                id="entity_cin_no_edit" name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" id="entity_pan_no_edit" name="pan_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description" id="entity_desc_edit" name="entity_desc" maxlength="80"></textarea>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <div class="row"> 
                            <input type="hidden" name="old_entity_image" id="old_entity_image">
                            <input type="hidden"  id="old_entity_image_path">
                                <label class="col-lg-1 text-black fs-6 fw-semibold">Logo<span class="text-danger">*</span></label>
                                <div class="col-lg-11 ps-5 ">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{asset('assets/common/logo_small.png')}}" alt="Fav Icon"
                                            class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                            id="enity_logo_update" />
                                        <div class="button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label for="fav_upload_edit" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Image">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" name="fav_icon" id="fav_upload_edit" class="file-in-edit"
                                                        hidden accept="image/png, image/jpeg" />
                                                </label>
                                                <button type="button" class="btn btn-sm btn-outline-danger file-reset-edit"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Fav Icon">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                        </div>
                                    </div>
                                    <div class="error_msg text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox"  name="entity_in_menu" id="entity_in_menu_edit" value="1"/>Entity Menu
                            </label>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" value="" id="entity_bank_name_edit" name="comapny_bank_name"  maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="entity_bank_branch_edit" name="comapny_bank_branch" maxlength="50"
                                value="" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder"
                               id="entity_acc_holder_edit" name="comapny_acc_holder" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No"
                                id="entity_acc_no_edit" name="comapny_acc_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                id="entity_bank_ifsc_edit" name="comapny_bank_ifsc" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Social Media</div>
                    </div>
                    <div class="row mb-6" id="socialRow1_edit">
                        @if(isset($social_media_list))
                            @foreach($social_media_list as $slist)
                            <div class="col-lg-4 mb-3">
                                <div class="form-check mb-2">
                                    <input class="form-check-input toggle-field-edit-entity" type="checkbox" id="edit_checkSocialMedia_entity_{{$slist->sno}}" data-target="#edit_socialMediaField_entity_{{$slist->sno}}">
                                    <label class="text-black mb-1 fs-6 fw-semibold" for="edit_checkSocialMedia_entity_{{$slist->sno}}">{{$slist->social_media_name}}</label>
                                </div>
                                <div id="edit_socialMediaField_entity_{{$slist->sno}}" class="d-none">
                                    <input type="text" class="form-control" name="social_media[{{$slist->sno}}]" placeholder="Enter {{$slist->social_media_name}} URL" />
                                </div>
                                <div class="error_msg text-danger"></div>
                            </div>
                            @endforeach
                        @endif
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="EditvalidateFormEntity()" id="update_entity_btn">Update Entity</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Entity-->


    <!--begin::Modal View Entity--->
    <div class="modal fade" id="kt_modal_view_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex align-items-center mb-2 gap-2">
                        <div class="avatar-stack">
                            <img src="{{ asset('assets/common/logo_small.png') }}" id="view_entity_logo" alt="user-avatar"
                                class="avatar-img" />
                        </div>
                        <div class="">
                            <span class="text-black fw-semibold fs-3">View Entity</span>
                        </div>
                    </div>
                </div>

                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <div class="row mb-3">
                        <div class="nav-align-top nav-tabs-shadow mb-3">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#basic_info_entity" aria-controls="basic_info_entity" aria-selected="true">
                                        Company Info
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#legaltax_entity" aria-controls="legaltax_entity" aria-selected="false">
                                        Legal / Tax
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#bankinfo_entity" aria-controls="bankinfo_entity"
                                        aria-selected="false">
                                        Bank Info
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="basic_info_entity" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5  text-dark fs-7 fw-semibold">Entity</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                 <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_entityname" style="display:none;">
                                                    Elysian Intelligence Business Solution
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Company</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_companyname_entity" style="display:none;">Private
                                                    Limited Company (Pvt Ltd)
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Email ID</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_emailid_entity" style="display:none;">info@eibsglobal.com</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-6 fw-semibold">Website URL</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <a href="" target="_blank"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" class="view-data-entity"
                                                    title="" id="view_website_tag_entity" style="display:none;">
                                                    <div class="text-truncate max-w-75 text-black fs-7  fw-semibold" id="view_website">
                                                        https://eibsglobal.com/</div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Contact Person</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_contactperson_entity" style="display:none;">
                                                    Sankar Ganesh</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">C.P. Mobile No</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" ></label>
                                            <label class="text-black fs-6 fw-semibold view-data-entity" id="view_cp_mobileno_entity" style="display:none;">9894444710</label>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <div class="col-6">
                                            <label class="skeleton-loader-view max-w-75" ></label>
                                            <label class="fw-semibold fs-6 text-black view-data-entity" id="view_description_entity" style="display:none;">-</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="legaltax_entity" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_gstno_entity" style="display:none;">
                                                    27AABCU9603R1ZV</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_cinno_entity" style="display:none;">U12345MH2005PTC123456
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_panno_entity" style="display:none;">
                                                    AABCU9603R</div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="bankinfo_entity" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" ></label>
                                                <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_bank_entity" style="display:none;">HDFC</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class="skeleton-loader-view max-w-75" ></label>
                                                <label class="text-black fs-6 fw-semibold view-data-entity" id="view_branch_entity" style="display:none;">Anna Nagar</label>
                                            </div>
                                           
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" ></label>
                                                <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_ifsccode_entity" style="display:none;">HDFC0002027</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" ></label>
                                                <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_accountholder_entity" style="display:none;">Elysium Intelligence Business
                                                Solutions</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75" ></label>
                                            <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_accountno_entity"style="display:none;">8574854578452</label>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -View Entity-->

    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">PhDiZone </b>
                        Entity ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deleteDepartmentCategory()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->

{{-- entity's social media --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field-edit-entity").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>

<!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
   <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#filter_form').submit();
            }
        }
    </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="text-truncate max-w-175px fw-medium fs-7" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" data-bs-original-title="${item.entity_name}">${item.entity_name}</div>
                        <a href="${item.entity_website}" target="_blank" class="ms-1"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Website URL"
                            data-bs-original-title="Website URL">
                            <i class="mdi mdi-web fs-4 text-dark"></i>
                        </a>
                    </div>
                    <div class="d-block">
                        <label class="fs-8 text-black fw-semibold">${item.entity_mail}</label>
                    </div>
                </td>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-175px fw-medium fs-7"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="${item.company_name}">${item.company_name}
                                </div>
                            </div>
                            <div class="d-block">
                                <label class="badge bg-warning fs-8 text-black fw-bold">${item.company_type_name} (${item.slug_name})</label>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <label>${item.entity_ct_person}</label>
                    <div class="d-block">
                        <label class="fs-8 text-black fw-semibold">${item.entity_ct_number}</label>
                    </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatusEntity('${item.sno}', this.checked)" />
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                    <div class="text-center">
                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1 waves-effect waves-light"
                            data-bs-toggle="modal" data-bs-target="#kt_modal_add_department">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                aria-label="Add Department" data-bs-original-title="Add Department"><i
                                    class="mdi mdi-file-tree fs-3 text-black"></i></span>
                        </a>
                        <a href="javascript:;" class="btn btn-icon btn-sm p-0 me-1 waves-effect waves-light"
                            data-bs-toggle="modal" data-bs-target="#kt_modal_add_division">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                aria-label="Add Division" data-bs-original-title="Add Division"><i
                                    class="mdi mdi-graph fs-4 text-black"></i></span>
                        </a>
                        <a class="btn btn-icon btn-sm waves-effect waves-light" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width:200px !important">
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_view_entity"  onclick="viewmodel('${item.sno}')">
                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_update_entity" onclick="editmodel('${item.sno}')">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_delete_entity" onclick="confirmDelete('${item.sno}','${item.entity_name}')">
                                <span><i
                                        class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/entity_hub/manage_entity?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(5));
            }
                 $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>
    <script>
        function updatelevelStatusEntity(UniversityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/entity_status/${UniversityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Entity status Updated successfully!');
                        loadThemes(1);
                    } else {
                        toastr.error('Error updating Entity status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Entity status:', error);
                });
        }
    </script>
    <script>
        function confirmDelete(sno, name) {
            document.querySelector('#kt_modal_delete_entity .btn-danger').setAttribute(
                'data-id', sno);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Entity ?');
        }

        function deleteDepartmentCategory() {

            var universityId = document.querySelector('#kt_modal_delete_entity .btn-danger').getAttribute('data-id');

            fetch('/entity_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Entity Deleted successfully!');
                        location.reload();

                    } else if(data.status === 302) {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function viewmodel(id) {
             // Show skeleton loaders before fetch
            document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                skeleton.style.display = 'block'; // Show skeleton loaders
            });
        
            // Hide actual data elements
            document.querySelectorAll('.view-data-entity').forEach(element => {
                element.style.display = 'none'; // Hide actual data until it is loaded
            });
            
            fetch('/entity_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                          var logoPath = com.entity_logo ? `/Entity_logos/${com.company_id}/${com.entity_logo}` : '/assets/common/logo_small.png';
                         
                        document.getElementById('view_entity_logo').src = logoPath;
                        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                            skeleton.style.display = 'none'; // Hide skeleton loaders
                        });
                        document.querySelectorAll('.view-data-entity').forEach(element => {
                            element.style.display = 'block'; // Show actual data
                        });
                        
                        $('#view_entityname').html(com.entity_name).attr('title', com.entity_name);
                        $('#view_companyname_entity').html(com.company_name).attr('title', com.company_name);
                        $('#view_emailid_entity').html(com.entity_mail).attr('title', com.entity_mail);
                        $('#view_website').html(com.entity_website);
                        $('#view_website_tag_entity').attr('title', com.entity_website).attr('href', com
                            .entity_website);
                        $('#view_websitelink').attr('href', com.entity_website); //entity_ct_person//entity_ct_number
                        $('#view_contactperson_entity').html(com.entity_ct_person).attr('title', com.entity_ct_person);
                        $('#view_cp_mobileno_entity').html(com.entity_ct_number);
                        $('#view_address').html(
                                              (com.entity_door_no || '') +', '+
                                              (com.entity_area || '') +', '+
                                              (com.citiesname || '') +', '+
                                              (com.statename || '') +', '+
                                              (com.name || '')
                                            );
                        $('#view_description_entity').html(com.entity_desc||'-');
                        $('#view_gstno_entity').html(com.entity_gst);
                        $('#view_cinno_entity').html(com.entity_cin);
                        $('#view_panno_entity').html(com.entity_pan);
                        $('#view_bank_entity').html(com.entity_bank_name);
                        $('#view_branch_entity').html(com.entity_bank_branch);
                        $('#view_accountholder_entity').html(com.entity_acc_holder);
                        $('#view_accountno_entity').html(com.entity_acc_no).attr('title', com.entity_acc_no);
                        $('#view_ifsccode_entity').html(com.entity_ifsc);
                        
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
        
        
    </script>
     <script>
        function editmodel(id) {
            fetch('/entity_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        $('#edit_id_entity').val(id);
                        $('#entity_name_edit').val(com.entity_name);
                        $('#entity_short_name_edit').val(com.entity_short_name);
                        $('#edit_company_id').val(com.company_id).change();
                        $('#entity_mail_edit').val(com.entity_mail);
                        $('#entity_website_url_edit').val(com.entity_website);
                        $('#entity_base_url_edit').val(com.entity_base_url);
                        $('#location_url_edit').val(com.entity_location_url);
                        $('#entity_ct_person_edit').val(com.entity_ct_person);
                        $('#entity_ct_per_mobile_no_edit').val(com.entity_ct_number);
                        // Fetch and populate countries
                        $.ajax({
                            url: "{{ route('country_ed_list') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdown = $('#entity_countryId_edit');
                                    countryDropdown.empty();
                                    countryDropdown.append(
                                        '<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>')
                                            .attr('value', country.id).text(country
                                                .name));
                                    });
                                    countryDropdown.val(com.entity_country).change();
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        // Event listener for country change
                        $('#entity_countryId_edit').on('change', function() {
                            var countryId = $(this).val();
                            var stateDropdown = $('#entity_stateId_edit');
                            var cityDropdown = $('#entity_cityId_edit');

                            stateDropdown.empty().append('<option value="">Select State</option>');
                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId) {
                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', state.id)
                                                    .text(state.name));
                                            });
                                            stateDropdown.val(com.entity_state).change();
                                        }
                                        
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        });
                        // Event listener for state change
                        $('#entity_stateId_edit').on('change', function() {
                            var stateId = $(this).val();
                            var countryId = $('#entity_countryId_edit').val();
                            var cityDropdown = $('#entity_cityId_edit');

                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId && stateId) {
                                // Fetch and populate cities based on selected state and country
                                $.ajax({
                                    url: "{{ route('city_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId,
                                        state_id: stateId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(city) {
                                                cityDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', city.id)
                                                    .text(city.name));
                                                cityDropdown.val(com
                                                        .entity_city)
                                                    .change();
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching cities:', error);
                                    }
                                });
                            }
                        });

                        if(com.entity_in_menu == 1){
                            $('#entity_in_menu_edit').prop('checked',true);
                        }else{
                            $('#entity_in_menu_edit').prop('checked',false);
                        }
                        
                        $('#entity_area_street_edit').val(com.entity_area);
                        $('#entity_door_flat_no_edit').val(com.entity_door_no);
                        $('#entity_pincode_edit').val(com.entity_pincode);
                        $('#entity_desc_edit').val(com.entity_desc);
                        $('#edit_entity_base_color').val(com.entity_base_color);
                        $('#entity_gst_no_edit').val(com.entity_gst);
                        $('#entity_cin_no_edit').val(com.entity_cin);
                        $('#entity_pan_no_edit').val(com.entity_pan);
                        $('#old_entity_image').val(com.entity_logo);
                        $('#entity_bank_name_edit').val(com.entity_bank_name);
                        $('#entity_bank_branch_edit').val(com.entity_bank_branch);
                        $('#entity_acc_holder_edit').val(com.entity_acc_holder);
                        $('#entity_acc_no_edit').val(com.entity_acc_no);
                        $('#entity_bank_ifsc_edit').val(com.entity_ifsc);
                         var logoPath = com.entity_logo ? `/Entity_logos/${com.company_id}/${com.entity_logo}` : '/assets/common/logo_small.png';
                        document.getElementById('enity_logo_update').src = logoPath;
                        document.getElementById('old_entity_image').value = com.entity_logo || '';
                        document.getElementById('old_entity_image_path').value = logoPath || '';
                        
                          
                        
                        if (com.social_media_details) {
                            const socialMediaDetails = JSON.parse(com.social_media_details);
                            Object.keys(socialMediaDetails).forEach(key => {
                                const checkbox = document.getElementById(`edit_checkSocialMedia_entity_${key}`);
                                if (checkbox) {
                                    checkbox.checked = true;  // Check the checkbox if URL exists
                                    const inputField = document.querySelector(`#edit_socialMediaField_entity_${key} input`);
                                    if (inputField) {
                                        inputField.value = socialMediaDetails[key]; // Set the URL in the input field
                                    }
                                    const target = document.querySelector(`#edit_socialMediaField_entity_${key}`);
                                    if (checkbox.checked) {
                                        target.classList.remove("d-none"); // Show the target if checked
                                    } else {
                                        target.classList.add("d-none"); // Hide the target if unchecked
                                    }
                                }
                            });
                        }
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function EditvalidateFormEntity() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'entity_name_edit',
                    name: 'Entity Name'
                },
                {
                    id: 'edit_company_id',
                    name: 'Company'
                },
                {
                    id: 'entity_mail_edit',
                    name: 'Email ID'
                },
                {
                    id: 'entity_website_url_edit',
                    name: 'Website URL'
                },
                {
                    id: 'location_url_edit',
                    name: 'Location URL'
                },
                {
                    id: 'entity_short_name_edit',
                    name: 'Entity Short Name'
                },
                {
                    id: 'entity_base_url_edit',
                    name: 'Entity Base URL'
                },
                {
                    id: 'entity_ct_person_edit',
                    name: 'Contact Person Name'
                },
                {
                    id: 'entity_ct_per_mobile_no_edit',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'entity_countryId_edit',
                    name: 'Country'
                },
                {
                    id: 'entity_stateId_edit',
                    name: 'State'
                },
                {
                    id: 'entity_cityId_edit',
                    name: 'City'
                },
                {
                    id: 'entity_area_street_edit',
                    name: 'Area / Street'
                },
                {
                    id: 'entity_door_flat_no_edit',
                    name: 'Door/Flat No'
                },
                {
                    id: 'entity_pincode_edit',
                    name: 'Pincode'
                },
                {
                    id: 'entity_gst_no_edit',
                    name: 'GST No'
                },
                {
                    id: 'entity_cin_no_edit',
                    name: 'CIN No'
                },
                {
                    id: 'entity_pan_no_edit',
                    name: 'PAN No'
                },
                {
                    id: 'entity_bank_name_edit',
                    name: 'Bank Name'
                },
                {
                    id: 'entity_bank_branch_edit',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'entity_acc_holder_edit',
                    name: 'Account Holder'
                },
                {
                    id: 'entity_acc_no_edit',
                    name: 'Account No'
                },
                {
                    id: 'entity_bank_ifsc_edit',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('entity_mail_edit').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('entity_mail_edit', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('entity_ct_per_mobile_no_edit').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('entity_ct_per_mobile_no_edit', 'Enter a valid 10-digit Mobile Number.');
            }
            
            // Logo upload validation
                const logoInput = document.getElementById('fav_upload_edit');
                const logoFile = logoInput.files[0]; // Get the uploaded file
                const oldLogo =$('#old_entity_image').val();
                if (!logoFile) {
                    if(!oldLogo){
                        setError('fav_upload_edit', 'Logo is required.');
                    }
                    
                } else {
                    // Check file format (JPG, PNG)
                    const allowedFormats = ['image/jpeg', 'image/png'];
                    if (!allowedFormats.includes(logoFile.type)) {
                        setError('fav_upload_edit', 'Allowed formats are JPG and PNG only.');
                    }
    
                    // Check file size (Max 800KB)
                    const maxSize = 800 * 1024; // 800KB in bytes
                    if (logoFile.size > maxSize) {
                        setError('fav_upload_edit', 'Logo file size must be less than 800KB.');
                    }
                }
            
            const socialMediaFields = document.querySelectorAll('.toggle-field-edit-entity:checked'); // Get all checked checkboxes
                socialMediaFields.forEach(checkbox => {
                    const socialMediaId = checkbox.getAttribute('id').replace('edit_checkSocialMedia_entity_', ''); // Get the social media ID
                    const urlInput = document.querySelector(`#edit_socialMediaField_entity_${socialMediaId} input`);
                    const url = urlInput.value.trim();
                    if (url === '') {
                        setError(`edit_checkSocialMedia_entity_${socialMediaId}`, `${checkbox.nextElementSibling.innerText} URL is required.`);
                    }
                });

            if (isValid == 0) {
                $('#edit_form_entity').submit();
            }
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
        const logoFileInputEdit = document.querySelector('.file-in-edit');
        const logoResetButtonEdit = document.querySelector('.file-reset-edit');
        


        logoResetButtonEdit.addEventListener('click', function() {
            const logoImage = document.getElementById('enity_logo_update');
            const oldImage = document.getElementById('old_entity_image_path');
            const resetLogoImage = '/assets/common/logo_small.png';  // Default image
            logoImage.src = oldImage.value ? oldImage.value :resetLogoImage;  // Reset the image to default
            logoFileInputEdit.value = null;  // Clear the file input
        });

        // Function to preview Update image
        logoFileInputEdit.addEventListener('change', function() {
            const logoImage = document.getElementById('enity_logo_update');
            if (this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    logoImage.src = e.target.result;  // Display the selected image
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
        
    });
    </script>
@endsection
