@extends('layouts/layoutMaster')
@section('style')
@section('title', 'AI Websites')

@section('vendor-style')
    @vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/tagify/tagify.scss',
    ])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
    @php
      $menuName ='Settings';
      $subMenuName ='Entity';
    @endphp
    <style>
        .credential-wrapper {
            min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
             width: 250px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
             align-items:center;
              gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                               
                    <div class="scroll-container" id="scrollContainer">
                        @if(auth()->user()->hasPermission($menuName,'General Settings')) 
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li> 
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Common'))        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link "
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Entity'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link active">
                                Entity
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'HRM'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Payroll'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/rule_category') }}" type="button" class="nav-link scroll-link ">
                                Payroll
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Recruitment'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Interview'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/interview_mode') }}" type="button"
                                class="nav-link scroll-link">
                                Interview
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Assessment'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                                class="nav-link scroll-link">
                                Assessment
                            </a>
                        </li>
                        @endif
                     @if(auth()->user()->hasPermission($menuName,'Management'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        @endif
                     @if(auth()->user()->hasPermission($menuName,'Business'))
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link ">
                                    Business
                                </a>
                            </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'API Config'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/api_config') }}" type="button"
                                class="nav-link scroll-link ">
                                API Config
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,'Webhook Moniter'))
                        <li class="nav-item">
                            <a href="{{ url('/admin/webhooks') }}" type="button"
                                class="nav-link scroll-link ">
                                Webhook Moniter
                            </a>
                        </li>
                        @endif
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="d-flex credential-wrapper">
                <!-- CONTENT -->
                <div class="tab-content flex-grow-1 position-relative">
                    <!-- Toggle Button -->
                    <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">AI Websites</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Entity </a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            AI Websites
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_ai_website">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add AI Website
                            </a>
                        </div>
                    </div>        
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between mb-4 ">
                                <div>
                                    <span>Show</span>
                                    <select id="perpage" class="form-select form-select-sm w-75px"
                                        onchange="loadThemes(1)">
                                        @php $options = [5,10, 25, 100, 500]; @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                                {{ $option }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input type="text" id="search_filter" class="searchQueryInput"
                                            placeholder="Search AI Websites"
                                            value="{{ $search_filter }}"/>
                                        
                                        <div class="searchAction">
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                                    <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                                </a>
                                                <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                                    <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-100px">AI Website</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                    <tr class="skeleton-loader" id="skeleton-loader">
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
                <!-- SIDEBAR -->
                <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                    <ul class="nav nav-tabs flex-column" role="tablist">
                         @if(auth()->user()->hasPermission($menuName,$subMenuName,'Credential Book')) 
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Credential Book</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Credential Book"><i class="mdi mdi-book-lock-open-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,$subMenuName,'Social Media'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/social_media') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Social Media</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Social Media"><i class="mdi mdi-web-plus fs-3"></i></span>
                                </label>
                                
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,$subMenuName,'Webhook URL'))
                        <li class="nav-item">
                            <a href="{{ url('/settings/webhook_url') }}" class="nav-link"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Webhook URL</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Webhook URL"><i class="mdi mdi-webhook fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,$subMenuName,'Grade'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/settings/grade') }}"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Grade</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Grade"><i class="mdi mdi-police-badge-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,$subMenuName,'Level'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/settings/level') }}"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Level</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Level"><i class="mdi mdi-podium-gold fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        @endif
                        @if(auth()->user()->hasPermission($menuName,$subMenuName,'AI Websites'))
                        <li class="nav-item">
                            <a class="nav-link active" href="{{ url('/settings/ai_websites') }}"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">AI Websites</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="AI Websites"><i class="mdi mdi-robot fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>

 <!--begin::Modal - Add  AI Website -->
    <div class="modal fade" id="kt_modal_add_ai_website" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create AI Website</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="addForm" action="{{ route('add_ai_websites') }}" method="POST"  enctype="multipart/form-data">
                      @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold"> AI Website Name<span class="text-danger error_cls">*</span></label>
                            <input type="text" class="form-control messg_cls" placeholder="Enter AI Website Name" id="ai_website_name" name='ai_website_name' oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50">
                             <div class="text-danger" id="ai_website_name_err"></div>
                            
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold"> AI Website URL<span class="text-danger error_cls">*</span></label>
                            <input type="text" class="form-control messg_cls" placeholder="Enter AI Website URL" id="ai_website_url" name='ai_website_url' maxlength="80">
                             <div class="text-danger" id="ai_website_url_err"></div>
                            
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Ai Slug</label>
                            <div class="form-floating form-floating-outline">
                                <input id="ai_website_slug" name="ai_website_slug" class="form-control h-auto" placeholder="Select Ai Slug" value="">
                                
                            </div>
                            <div class="text-danger" id="ai_website_slug_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control messg_cls" rows="1" id="" name='ai_website_desc' placeholder="Enter Description"></textarea>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                            <div class="align-items-sm-center gap-4">
                                <img src="https://placehold.net/default.png" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo" />
                                <div class="button-wrapper">
                                    <div class="d-flex align-items-start mt-2 mb-2">
                                        <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                            <i class="mdi mdi-tray-arrow-up"></i>
                                            <input type="file" id="upload" class="file-in" hidden name="ai_image" accept="image/png, image/jpeg" />
                                        </label>
                                    </div>
                                    <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                </div>
                                <div id="ai_image_err" class="text-danger mt-1"></div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="createbtn" class="btn btn-primary"  onclick="addValidateForm()">Create
                             AI Website</button>
                    </div>
                     </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add  AI Website-->


    <!--begin::Modal - Edit  AI Website -->
    <div class="modal fade" id="kt_modal_edit_ai_website" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update AI Website</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="editForm" action="{{ route('ai_websites_update') }}" method="POST"  enctype="multipart/form-data">
                         @csrf
                        <div class="row">
                            <input type="hidden" name="edit_ai_website_id" id="edit_ai_website_id" value="">
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold"> AI Website Name<span class="text-danger error_cls"></span></label>
                                <input type="text" class="form-control messg_cls" id="ai_website_name_edit" name="ai_website_name" placeholder="Enter AI Website Name" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50">
                                <div class="text-danger" id="ai_website_name_edit_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold"> AI Website URL<span class="text-danger error_cls">*</span></label>
                                <input type="text" class="form-control messg_cls" placeholder="Enter AI Website URL" id="ai_website_url_edit" name='ai_website_url_edit' maxlength="80">
                                <div class="text-danger" id="ai_website_url_edit_err"></div>
                                
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Ai Slug</label>
                                <div class="form-floating form-floating-outline">
                                    <input id="ai_website_slug_edit" name="ai_website_slug_edit" class="form-control h-auto" placeholder="Select Ai Slug" value="">
                                    
                                </div>
                                <div class="text-danger" id="ai_website_slug_edit_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control messg_cls" rows="1" id="ai_website_desc_edit" name='ai_website_desc' placeholder="Enter Description"></textarea>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Image<span class="text-danger">*</span></label>
                                <div class="align-items-sm-center gap-4">
                                    <img src="https://placehold.net/default.png" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogoimage" />
                                    <div class="button-wrapper">
                                        <div class="d-flex align-items-start mt-2 mb-2">
                                            <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                                <i class="mdi mdi-tray-arrow-up"></i>
                                                <input type="file" id="upload" class="file-in" hidden name="ai_edit_image" accept="image/png, image/jpeg" />
                                            </label>
                                        </div>
                                        <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                    </div>
                                    <div id="ai_image_edit_err" class="text-danger mt-1"></div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="updatebtn" class="btn btn-primary"  onclick="editValidateForm()" class="btn btn-primary" >Update AI Website</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit  AI Websites-->

    <!--begin::Modal - Delete  AI Website-->
    <div class="modal fade" id="kt_modal_delete_ai_website" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">WhatsApp </b>
                         AI Websites ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deletelevel()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete  AI Websites-->




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
<script>
            // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif

        
        </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
            <tr>
                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="image-container me-3">
                            <img src="${item.ai_website_logo}" class="rounded-circle" width="30" height="30" alt="AI Website Logo">
                        </div>
                        <div class="">
                            <label class="fs-7 fw-medium">${item.ai_website_name}</label>
                            <span class="cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="${item.ai_website_desc || '-' }">
                                <i class="mdi mdi mdi-help-circle text-dark"></i>
                            </span>
                            <div class="">
                            <span class="fs-8 fw-medium text-primary" >${item.ai_website_url}</span>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                        <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_edit_ai_website"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Edit" onclick="populateUpdateModal('${item.sno}')">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                        </button>
                        <button class="btn btn-icon btn-sm" type="button" 
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_ai_website"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Delete"  onclick="confirmDelete('${item.sno}', '${item.ai_website_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/ai_websites?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });
                }else{
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                    }
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function NoDataFound(){
            return `
                <tr><td colspan="4" class="text-center">No Data Found</td></tr>
                `;
        }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

        <script>
        function addValidateForm() {
            $("#createbtn").prop('disabled', true);
            var err = 0;
            // Validate knowledge Name
            var ai_website_name = document.getElementById("ai_website_name").value.trim();
            if (ai_website_name === "") {
                document.getElementById('ai_website_name_err').innerHTML = 'AI Websites Name is required...!';
                document.getElementById('ai_website_name').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('ai_website_name').classList.remove('error_msg');
                document.getElementById('ai_website_name_err').innerHTML = '';
            }

            const websiteUrl = document.getElementById('ai_website_url').value.trim();
            const urlPattern = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?$/i;
    
            if (websiteUrl !== '' && !urlPattern.test(websiteUrl)) {
                document.getElementById('ai_website_url_err').innerHTML = 'Enter a valid Website URL (e.g., https://example.com or www.example.com)';
                document.getElementById('ai_website_url').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('ai_website_url').classList.remove('error_msg');
                document.getElementById('ai_website_url_err').innerHTML = '';
            }

            if(err>0){
                $("#createbtn").prop('disabled', false);
                return false;
            }else{
                $("#createbtn").prop('disabled', true);
                $('#addForm').submit();
            }
        }

        // Add event listeners to clear error messages on input
        document.getElementById('ai_website_name').addEventListener('input', function() {
            document.getElementById('ai_website_name_err').innerHTML = '';
            this.classList.remove('error_msg');
        });

         function editValidateForm() {
            $("#updatebtn").prop('disabled', true);
            var err = 0;
            // Validate knowledge Name
            var ai_website_name = document.getElementById("ai_website_name_edit").value.trim();
            if (ai_website_name === "") {
                document.getElementById('ai_website_name_edit_err').innerHTML = 'AI Websites Name is required...!';
                document.getElementById('ai_website_name_edit').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('ai_website_name_edit').classList.remove('error_msg');
                document.getElementById('ai_website_name_edit_err').innerHTML = '';
            }

            const websiteUrl = document.getElementById('ai_website_url_edit').value.trim();
            const urlPattern = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?$/i;
    
            if (websiteUrl !== '' && !urlPattern.test(websiteUrl)) {
                document.getElementById('ai_website_url_edit_err').innerHTML = 'Enter a valid Website URL (e.g., https://example.com or www.example.com)';
                document.getElementById('ai_website_url_edit').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('ai_website_url_edit').classList.remove('error_msg');
                document.getElementById('ai_website_url_edit_err').innerHTML = '';
            }

            if(err>0){
                $("#updatebtn").prop('disabled', false);
                return false;
            }else{
                $("#updatebtn").prop('disabled', true);
                $('#editForm').submit();
            }
        }



        let currentCategoryId;
          let editTagify; 

        function populateUpdateModal(categoryId) {

            currentCategoryId = categoryId;
            fetch(`/ai_websites_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const credential = data.data;
          

                        document.getElementById('edit_ai_website_id').value = categoryId;
                        document.getElementById('ai_website_name_edit').value = credential.ai_website_name;
                        document.getElementById('ai_website_url_edit').value = credential.ai_website_url;
                        document.getElementById('ai_website_desc_edit').value = credential.ai_website_desc;
                        if (credential.logo) {
                             const imagePath = '/settings/ai/' + credential.logo;
                            $('#uploadedlogoimage').attr('src', imagePath);
                        } else {
                            $('#uploadedlogoimage').attr('src', "https://placehold.net/default.png");
                        }

                         let modules = JSON.parse(credential.ai_website_slug ?? '[]');
                            if(modules){
                                if (typeof modules === "string") {
                                    modules = JSON.parse(modules);
                                }
                            }
                            
                            console.log(modules);
                            editTagify.removeAllTags();
                            editTagify.whitelist = modules;
                            editTagify.addTags(modules);


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });
        }


        function updateSlotType() {
            const slottypeId = currentCategoryId;
            const newName = document.getElementById('ai_website_name_edit').value;
            const texta = document.getElementById('ai_website_desc_edit').value;


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/ai_websites_update/${slottypeId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        ai_website_name: newName,
                        ai_website_desc: texta,

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('AI Website Updated successfully!');
                        location.reload();
                    } else {
                        toastr.error('AI Website Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }

        // document.getElementById('updatelevelForm').addEventListener('submit', function(event) {
        //     event.preventDefault();
        //     updateSlotType();
        // });


        function confirmDelete(id, name) {
            document.querySelector('#kt_modal_delete_ai_website .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> AI Website ?');
        }

        function deletelevel() {

            var categoryId = document.querySelector('#kt_modal_delete_ai_website .btn-danger').getAttribute('data-id');

            fetch('/ai_websites_delete/' + categoryId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('AI Website Deleted successfully!');
                        location.reload();

                    } else {

                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function updatelevelStatus(categoryId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/ai_websites_status/${categoryId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('AI Website status Updated successfully!');
                         loadThemes(1); 
                    } else {
                        console.error('Error updating AI Website status:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error updating AI Website status:', error);
                });
        }

        </script>

<script>
    let logofile = document.getElementById('uploadedlogo');
    const fileInput = document.querySelector('.file-in'),
    resetFileInput = document.querySelector('.file-reset');

  if (logofile) {
    const resetImage = logofile.src;
    fileInput.onchange = () => {
      if (fileInput.files[0]) {
        logofile.src = window.URL.createObjectURL(fileInput.files[0]);
      }
    };
    if(resetFileInput){
        resetFileInput.onclick = () => {
            fileInput.value = '';
            logofile.src = resetImage;
        };
    }
    
  }
  
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        let logofile_edit = document.getElementById('uploadedlogoimage');
        const fileInput_edit = document.querySelector('.file-in_edit');
        const resetFileInput_edit = document.querySelector('.file-reset_edit');

        if (logofile_edit && fileInput_edit && resetFileInput_edit) {
            const resetImage_edit = logofile_edit.src;

            fileInput_edit.onchange = () => {
                if (fileInput_edit.files[0]) {
                    logofile_edit.src = window.URL.createObjectURL(fileInput_edit.files[0]);
                }
            };

            resetFileInput_edit.onclick = () => {
                fileInput_edit.value = '';
                logofile_edit.src = resetImage_edit;
            };
        }
    });
</script>
<script>
        $(document).ready(function() {
          // Basic
          //------------------------------------------------------
          const ai_website_slugEl = document.querySelector('#ai_website_slug');
          const ai_website_slugElEdit = document.querySelector('#ai_website_slug_edit');
          let whitelist = [];
          let whitelistEdit = [];
            initializeTagify(); 

          function initializeTagify() {
              // Inline initialization of Tagify
              let KnowledgeTag = new Tagify(ai_website_slugEl, {
                  whitelist: whitelist,
                  maxTags: 500, // allows to select max items
                  dropdown: {
                      maxItems: 1000, // display max items
                      classname: 'tags-inline', // Custom inline class
                      enabled: 0,
                      closeOnSelect: true
                  }
              });

              // Ensure the z-index is set correctly after initialization
              KnowledgeTag.DOM.dropdown.style.zIndex = '9999';
          }
          

          const edit_templateTagEl = document.querySelector('#ai_website_slug_edit');

                editTagify = new Tagify(edit_templateTagEl, {
                    whitelist: [],
                    maxTags: 100,
                    dropdown: {
                        maxItems: 50,
                        classname: 'tags-inline',
                        enabled: 0,
                        closeOnSelect: false
                    }
                });
        });
  </script>
@endsection
