@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Interview Question')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

  @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $role_id = auth()->user()->role_id ;
    $auth_id = auth()->user()->id ;
   @endphp
   
    <style>
        .credential-wrapper {
             min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
            width: 280px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
            align-items:center;
            gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>
    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li>        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link "
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link ">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/interview_mode') }}" type="button"
                                class="nav-link scroll-link active">
                                Interview
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                                class="nav-link scroll-link">
                                Assessment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link ">
                                    Business
                                </a>
                            </li>

                        <li class="nav-item">
                            <a href="{{ url('/settings/api_config') }}" type="button"
                                class="nav-link scroll-link ">
                                API Config
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/admin/webhooks') }}" type="button"
                                class="nav-link scroll-link ">
                                Webhook Moniter
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="d-flex credential-wrapper">
                <!-- CONTENT -->
                <div class="tab-content flex-grow-1 position-relative">
                    <!-- Toggle Button -->
                    <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Interview Question</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Interview</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Interview Question
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="{{url('/settings/intreview/intreview_question_add')}}" class="btn btn-sm fw-bold btn-primary" >
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Question
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between mb-4 ">
                                <div>
                                    <span>Show</span>
                                    <select id="perpage" class="form-select form-select-sm w-75px"
                                        onchange="loadThemes(1)">
                                        @php $options = [6,10, 25, 100, 500]; @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                                {{ $option }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input type="text" id="search_filter" class="searchQueryInput"
                                            placeholder="Search Role/Category/Question..."
                                            value="{{ $search_filter }}"/>
                                        
                                        <div class="searchAction">
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                                    <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                                </a>
                                                <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                                    <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                    <thead>
                                        <tr class="text-center align-middle fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-100px">Job Role</th>
                                            <th class="min-w-100px">Interview Category</th>
                                            <th class="min-w-100px">Question Count</th>
                                            <th class="min-w-100px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="list-table-body" class="text-black fw-semibold fs-7 text-center">
                                        <tr class="skeleton-loader" id="skeleton-loader">
                                            
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                         <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
                <!-- SIDEBAR -->
                <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                    <ul class="nav nav-tabs flex-column" role="tablist">
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/interview_mode') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Interview Mode</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Interview Mode"><i class="fa-solid fa-folder-open fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/interview_category') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Interview Category</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Interview Category"><i class="fa-solid fa-list-check  fs-3"></i></span>
                                </label>
                                
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/interview_question') }}" class="nav-link active"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Interview Question</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Interview Question"><i class="mdi mdi-file-question-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/feedback_section') }}" class="nav-link " role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Feedback Section</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Feedback Section"><i class="mdi mdi-comment-text-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/feedback_question') }}" class="nav-link " role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Feedback Question</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Feedback Question"><i class="mdi mdi-comment-question-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                       
                        
                      
                        
                    </ul>
                </div>
            </div>
            
        </div>
    </div>


    <!--begin::Modal - Add Document -->
    <div class="modal fade" id="kt_modal_add_document" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Document</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Document<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Document">
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create
                            Document</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add  Document-->


        <!--begin::Modal - Update Document -->
    <div class="modal fade" id="kt_modal_edit_document" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Document</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Document<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Document" value="10th Marksheet">
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1"  placeholder="Enter Description">-</textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Update Document</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update  Document-->




    <!--begin::Modal - Delete Document-->
    <div class="modal fade" id="kt_modal_delete_question" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Question </b>
                        ?</span>
                </div>
                <input type="hidden" name="delete_id" id="delete_id">
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="button" class="btn btn-danger me-3" onclick="deleteDepartmentCategory()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Document-->




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
    let auth_user_id =@json($user_id);
    let auth_role_id =@json($role_id);
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        let data = typeof item.data === 'string' ? item.data : JSON.stringify(item.data);
        // console.log(data)
        return `
            <tr id="rev_prop_hd_${item.job_role_id}_${item.interview_category_id}">
                <td style="position:relative;">
                   <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex align-items-center gap-2">
                        <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="border  rounded px-1 py-1 bg-primary text-white"  onclick='rev_prop_fuc("${item.job_role_id}","${item.interview_category_id}", ${data})'>
                                <i class="mdi mdi-plus fs-4" id="rev_prop_${item.job_role_id}_${item.interview_category_id}_plus_btton"></i>
                            </a>
                        </div>
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.job_role_name}">
                                    ${item.job_role_name}
                                </div>
                            </div>
                             <div class="d-block"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.entity_name}">
                                <span class="text-truncate max-w-150px badge fs-9" style="background:${item.entity_base_color || ''}">${item.entity_name}</span>
                            </div>
                        </div>
                    </div>
                </td>
                <td>${item.interview_category_name}</td>
                <td>
                    <div class="d-block ">
                        <label class="fs-7 badge bg-success text-white  rounded-circle fw-bold">${item.question_count}</label>
                    </div>
                </td>
                <td class="text-center">
                    <a href="{{ url('/settings/intreview/intreview_question_edit/${item.encrypted_id}')}}" class="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                        <i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>
                    </a>
                </td>
            </tr>
            <tr id="rev_prop_${item.job_role_id}_${item.interview_category_id}_tbox" style="display:none;background-color:#ccc;">
                <td colspan="6" class="">
                    <div class="table-responsive">
                        <table class="table align-middle gy-1 gs-2 indv_proposal " >
                        <thead >
                            <tr class="text-start align-middle fw-bold fs-6 gs-0 " style="background:#fab845">
                                <th class="min-w-250px text-black">Question</th>
                                <th class="min-w-100px text-black">Field</th>
                                <th class="min-w-50px text-black">Status</th>
                                ${ auth_role_id ==1 ?
                               `<th class="min-w-100px text-black text-center">Action</th>`
                                :''}
                            </tr>
                        </thead>
                            <tbody class="text-gray-600 fw-semibold fs-7 bg-white" id="question-table-body-${item.job_role_id}-${item.interview_category_id}">
                                <tr class="skeleton-loader" id="skeleton-loader-question-${item.job_role_id}-${item.interview_category_id} ">
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    ${ auth_role_id ==1 ?
                                    `<td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>`
                                    :''}
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/interview_question?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index+1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <script>
        function updatelevelStatus(UniversityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/interview_question_status_change/${UniversityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Question status Updated successfully!');
                        loadThemes(1);
                    } else {
                        toastr.error('Error updating Question status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Question status:', error);
                });
        }
    </script>
    <script>
        function confirmDelete(sno, name) {
                $('#delete_id').val(sno)

                $('#delete_message').html(
              'Are you sure you want to Delete Question ?<br><br> <b class="text-danger">' +
              name +
              '</b>');
        }

        function deleteDepartmentCategory() {

            var universityId = $('#delete_id').val();

            fetch('/interview_question_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Question Deleted successfully!');
                        location.reload();

                    } else if(data.status === 302) {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        
    </script>
<!-- status Change  & Delete-->

    <script>
        function rev_prop_fuc(role_id,cat_id,data) {
            var rev_prop_tbox = document.getElementById(`rev_prop_${role_id}_${cat_id}_tbox`);
            var plus_button = document.getElementById(`rev_prop_${role_id}_${cat_id}_plus_btton`);
            var header = document.getElementById(`rev_prop_hd_${role_id}_${cat_id}`);

            if (rev_prop_tbox.style.display === "none" || rev_prop_tbox.style.display === "") {
                rev_prop_tbox.style.display = "table-row";
                plus_button.classList.remove("mdi-plus");
                plus_button.classList.add("mdi-minus");
                header.style.backgroundColor = "#f9f3c5db";
                loadQuestion(role_id, cat_id, data);
            } else {
                rev_prop_tbox.style.display = "none";
                plus_button.classList.remove("mdi-minus");
                plus_button.classList.add("mdi-plus");
                header.removeAttribute("style");
            }
        }

        function loadQuestion(role_id, cat_id, data) {

            const tbodyId = `question-table-body-${role_id}-${cat_id}`;
            const tbody = document.getElementById(tbodyId);

            tbody.innerHTML = ''; // clear old data

            if (!data || data.length === 0) {
                tbody.insertAdjacentHTML('beforeend', NoDataFoundEnity());
                return;
            }

            data.forEach((item, index) => {
                tbody.insertAdjacentHTML('beforeend', buildRowEntity(item, index));
            });

            $('[data-bs-toggle="tooltip"]').tooltip();
        }


        function skeletenRowEntity(role_id,cat_id){
            return `
                <tr class="skeleton-loader" id="skeleton-loader-question-${role_id}-${cat_id}">
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                </tr>
                `;
        }

        function NoDataFoundEntity(){
            return `
                <tr><td colspan="4" class="text-center">No Data Found</td></tr>
                `;
        }

        function hexToRgba(hex, alpha = 0.2) {
            hex = hex.replace('#', '');

            if (hex.length === 3) {
                hex = hex.split('').map(c => c + c).join('');
            }

            const r = parseInt(hex.substring(0, 2), 16);
            const g = parseInt(hex.substring(2, 4), 16);
            const b = parseInt(hex.substring(4, 6), 16);

            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }

        function buildRowEntity(item,index) {
            var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
            return `
                <tr style="">
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="text-truncate max-w-225px fw-medium fs-7" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" data-bs-original-title="${item.field_name}">${item.field_name}</div>
                        </div>
                    </td>
                    <td>
                        <div class="d-flex allign-items-center gap-2">
                            <div>
                                <div class="d-flex align-items-center">
                                    <div class="text-truncate max-w-175px fw-medium fs-7"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                        title="${item.field_value}">${item.field_value}
                                        <span data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="${optionValue(item.field_option) || '-'}">
                                            <i class="mdi mdi mdi-help-circle text-dark"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <label class="switch switch-square">
                            <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)" />
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                    </td>
                    ${ auth_role_id ==1 ?
                        `<td>
                            <div class="text-center">
                                <a class="btn btn-icon btn-sm waves-effect waves-light" data-bs-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width:200px !important">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_delete_question" onclick='confirmDelete("${item.sno}","${item.field_name}")'>
                                        <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                    </a>
                                </div>
                            </div>
                        </td>`
                    :''
                    }
                </tr>
            `;
        }
    </script>

    <script>
        function optionValue(data){
            if (!data) return '-';
            try{
                const parsedData = JSON.parse(data);
                return parsedData?.map(item => item.label).join(', ') || '-';
            }catch(e){
                return '-';
            }
            
        }   
    </script>
@endsection
