@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Department')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <style>
        .credential-wrapper {
             min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
            width: 280px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
            align-items:center;
            gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li>        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link "
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link ">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/interview_mode') }}" type="button"
                                class="nav-link scroll-link ">
                                Interview
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                                class="nav-link scroll-link">
                                Assessment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link active">
                                    Business
                                </a>
                            </li>

                        <li class="nav-item">
                            <a href="{{ url('/settings/api_config') }}" type="button"
                                class="nav-link scroll-link ">
                                API Config
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/admin/webhooks') }}" type="button"
                                class="nav-link scroll-link ">
                                Webhook Moniter
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="d-flex credential-wrapper">
                <!-- CONTENT -->
                <div class="tab-content flex-grow-1 position-relative">
                    <!-- Toggle Button -->
                    <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Department</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Business </a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Department
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        @php
  
                            $helper = new \App\Helpers\Helpers();
                            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                            $user_id = auth()->user()->user_id ;
                            $auth_id = auth()->user()->id ;
                        @endphp
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            @if($user_id == 0)
                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_old_staff">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Old Data
                            </a>
                            @endif
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_Department">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Department
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between mb-4 ">
                                <div>
                                    <span>Show</span>
                                    <select id="perpage" class="form-select form-select-sm w-75px"
                                        onchange="loadThemes(1)">
                                        @php $options = [5,10, 25, 100, 500]; @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                                {{ $option }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input type="text" id="search_filter" class="searchQueryInput"
                                            placeholder="Search Department..."
                                            value="{{ $search_filter }}"/>
                                        
                                        <div class="searchAction">
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                                    <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                                </a>
                                                <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                                    <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-50px">Departments</th>
                                        <th class="min-w-50px">Company /<br>Entity</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                    <tr class="skeleton-loader" id="skeleton-loader">
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
                <!-- SIDEBAR -->
                <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                    <ul class="nav nav-tabs flex-column" role="tablist">
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/business/department') }}" class="nav-link active"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Department</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Department"><i class="mdi mdi-home-city-outline  fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/business/division') }}" class="nav-link"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Division</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Division"><i class="mdi mdi-lan  fs-3"></i></span>
                                </label>
                                
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/business/job_role') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Job Role</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Job Role"><i class="mdi mdi-account-arrow-left fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                       
                        
                    </ul>
                </div>
            </div>
            
        </div>
    </div>

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_old_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Add Old Department</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form  method="POST" enctype="multipart/form-data" autocomplete="off" id="addOldStaffForm">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="staff_data_payload" name="staff_data_payload"/>
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="staff_company_name" name="staff_company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            @if(isset($company_list))
                            @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="staff_entity_name" name="staff_entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff data :</label>
                        <span lass="text-black mb-1 fs-6 fw-semibold "id="total_Staff_data">0 </span>Record Found
                        <ul lass="text-black mb-1 fs-6 fw-semibold "id="total_Staff_list"></ul>
                      
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                    <button type="button" class="btn btn-primary me-3" id="submitStaffBtn" onclick="submit_form()">Add Old Department</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->
    <!--begin::Modal - Add Department -->
    <div class="modal fade" id="kt_modal_add_Department" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Department</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="addForm" action="{{ route('add_business_department') }}" method="POST" >
                    @csrf
                        <div class="row">
                            <!-- Basic -->
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Company<span
                                        class="text-danger">*</span></label>
                                <select id="company_id" name="company_id" class="select3 form-select ">
                                    <option value="">Select Company Name</option>
                                        @if(isset($company_list))
                                        @foreach($company_list as $clist)
                                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                        @endforeach
                                        @endif
                                </select>
                                <div class="text-danger" id="company_id_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Entity<span
                                        class="text-danger">*</span></label>
                                <select id="entity_id" name="entity_id" class="select3 form-select ">
                                    <option value="">Select Entity Name</option>
                                </select>
                                <div class="text-danger" id="entity_id_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Department (from <span id="entity_name"></span>)<span class="text-danger">*</span></label>
                                <select id="erp_department_name" name="erp_department_name" class="select3 form-select ">
                                    <option value="">Select Department</option>
                                    <option value="new_department">New</option>
                                </select>
                                <div class="text-danger" id="erp_department_name_err"></div>
                            </div>
                            <input type="hidden" name="department_name_hidden" id="department_name_hidden">
                            <input type="hidden" name="erp_department_id" id="erp_department_id">
                            <div class="col-lg-12 mb-3 d-none" id="new_department">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Department<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Department" name="department_name" id="department_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"maxlength="50" >
                                <div class="text-danger" id="department_name_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1"  placeholder="Enter Description" name="department_desc" id="department_desc"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="createbtn" class="btn btn-primary" onclick="addValidateForm()">Create Department</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add  Department-->


    <!--begin::Modal - Update Department -->
    <div class="modal fade" id="kt_modal_edit_Department" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Department</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="updateForm" action="{{ route('business_department_update') }}" method="POST" >
                    @csrf
                    <div class="row">
                        <!-- Basic -->
                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Department<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Department" name="department_name" id="department_name_edit"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"maxlength="50" >
                            <div class="text-danger" id="department_name_edit_err"></div>
                        </div>
                        
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="1"  placeholder="Enter Description" name="department_desc" id="department_desc_edit"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="updatebtn" class="btn btn-primary" onclick="editValidateForm()">Update Department</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update  Department-->


    <!--begin::Modal - Delete Department-->
    <div class="modal fade" id="kt_modal_delete_Department" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">HR Department</b>
                        Department ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="button" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Department-->




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
<script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
   

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <label class="fs-7 fw-medium">${index}</label>
                </td>
                <td>
                    <label class="fs-7 fw-medium">${item.department_name}</label>
                    <span data-bs-toggle="tooltip"
                        data-bs-placement="right" title="${item.department_desc || '-'}">
                        <i class="mdi mdi mdi-help-circle text-dark"></i>
                    </span>
                </td>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-200px fw-semibold fs-7"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="${item.company_name}">${item.company_name}
                                </div>
                            </div>
                            <div class="d-block">
                                <label class="badge  fs-8 text-white fw-bold" style="background:${item.company_base_color || 'yellow'};">${item.entity_name}</label>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                        <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_edit_Department"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Edit" onclick="openEditModal('${item.sno}', '${item.department_name}', '${item.department_desc || ''}')">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                        </button>
                        <button class="btn btn-icon btn-sm" type="button" 
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_Department"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Delete"  onclick="confirmDelete('${item.sno}', '${item.department_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/business/department?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow(3,5)); // Clear old data
        $('.skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('.skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('.skeleton-loader').hide();
                isLoading = false;
            });
    }

    // function skeletenRow(){
    //     return `
    //         <tr class="skeleton-loader" id="skeleton-loader">
    //             <td class="skeleton-cell">
    //                 <div class="skeleton"></div>
    //             </td>
    //             <td class="skeleton-cell">
    //                 <div class="skeleton"></div>
    //             </td>
    //             <td class="skeleton-cell">
    //                 <div class="skeleton"></div>
    //             </td>
    //             <td class="skeleton-cell">
    //                 <div class="skeleton"></div>
    //             </td>
    //             <td class="skeleton-cell">
    //                 <div class="skeleton"></div>
    //             </td>
    //         </tr>
    //         `;
    // }

    function skeletenRow(rowCount, colCount) {
        let rows = "";

        for (let r = 0; r < rowCount; r++) {
            let cols = "";
            for (let c = 0; c < colCount; c++) {
                cols += `
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                `;
            }

            rows += `
                <tr class="skeleton-loader">
                    ${cols}
                </tr>
            `;
        }

        return rows;
    }


    function NoDataFound(){
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/business_department_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(1);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id, name, sortname) {
  
          document.querySelector('#kt_modal_delete_Department .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Department ?<br> <b class="text-black fw-bold fs-4">' +
              name +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_Department .btn-danger').getAttribute('data-id');

          fetch('/business_department_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {

              });
      }
</script>

<!-- add validate -->
 <script>
    function addValidateForm() {
        let err = 0;

        if (!$('#company_id').val()) { $('#company_id_err').text('Company required'); err++; }
        else $('#company_id_err').text('');

        if (!$('#entity_id').val()) { $('#entity_id_err').text('Entity required'); err++; }
        else $('#entity_id_err').text('');

        let erp = $('#erp_department_name').val();
        if (!erp) { $('#erp_department_name_err').text('Department required'); err++; }
        else $('#erp_department_name_err').text('');

        if (erp == 'new_department') {
            if (!$('#department_name').val()) {
                $('#department_name_err').text('Department required'); err++;
            } else $('#department_name_err').text('');
        }

        if (err > 0) return false;

        $('#createbtn').prop('disabled', true);
        $('#addForm').submit();
    }
 </script>
  <!-- edit Validate -->
  <script>
  function openEditModal(id,name,desc) {
   
    $('#edit_id').val(id);
    $('#department_name_edit').val(name);
    $('#department_desc_edit').val(desc || '');

  }
  function editValidateForm(){
    var err =0;

    var company_id_edit = document.getElementById("company_id_edit").value.trim();
        if (company_id_edit === "") {
            document.getElementById('company_id_edit_err').innerHTML = ' Company is required...!';
            err++;
        } else {
            document.getElementById('company_id_edit_err').innerHTML = '';
        }
    var entity_id_edit = document.getElementById("entity_id_edit").value.trim();
        if (entity_id_edit === "") {
            document.getElementById('entity_id_edit_err').innerHTML = ' Entity is required...!';
            err++;
        } else {
            document.getElementById('entity_id_edit_err').innerHTML = '';
        }
    var department_name_edit = document.getElementById("department_name_edit").value.trim();
        if (department_name_edit === "") {
            document.getElementById('department_name_edit_err').innerHTML = ' Department Name is required...!';
            err++;
        } else {
            document.getElementById('department_name_edit_err').innerHTML = '';
        }

    if(err>0){
        $("#updatebtn").prop('disabled', false);
        return false;
       }else{
          $("#updatebtn").prop('disabled', true);
          $('#updateForm').submit();
       }
  }
 </script>

<script>
    $(document).ready(function() {

        $('#company_id').on('change', function() {
            let company = $(this).val();
            let entity = $('#entity_id');
            entity.empty().append('<option value="">Select Entity</option>');

            if (company) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: { company_id: company },
                    success: function(res) {
                        if (res.status === 200 && res.data) {
                            res.data.forEach(function(row) {
                                entity.append(
                                    $('<option></option>')
                                    .val(row.sno)
                                    .attr('data-baseurl', row.entity_base_url)
                                    .text(row.entity_name)
                                );
                            });
                        }
                    }
                });
            }
        });

        $('#entity_id').on('change', function() {
            
            let baseurl = $(this).find(':selected').data('baseurl');
            let dropdown = $('#erp_department_name');
            let entity_name = $(this).find(':selected').text();
            $('#entity_name').text(entity_name);

            dropdown.empty()
                .append('<option value="">Select Department</option>')
                .append('<option value="new_department">New</option>');

             const verify_key='egcsecret2030datagetapierp';

             

            if (baseurl) {
                console.log(baseurl)
                // var mainUrl = baseurl + 'api/department_data_get';

                $.ajax({
                    url: baseurl + 'api/department_data_get',
                    type: "GET",
                    data:{auth_key:verify_key},
                    success: function(res) {
                        if (res.status === 200 && res.data) {
                            res.data.forEach(function(depart) {
                                if(!depart.external_uuid){
                                    dropdown.append(
                                        $('<option></option>')
                                        .val(depart.sno)
                                        .attr('data-departmentname', depart.department_name) // ✅ FIXED
                                        .text(depart.department_name)
                                    );
                                }
                                
                            });

                            // set next ID if user selects other
                            $('#erp_department_id').val(res.nextId);
                        }
                    },
                    error: function(error){
                        console.error(error)
                    }
                });
            }
        });

        $('#erp_department_name').on('change', function() {
            if ($(this).val() == 'new_department') {
                $('#new_department').removeClass('d-none');
            } else {
                $('#new_department').addClass('d-none');

                // auto fill hidden name
                let name = $(this).find(':selected').data('departmentname') || $(this).find(':selected').text();
                $('#department_name_hidden').val(name);
            }
        });
    });
</script>
<script>
    function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: "{{ url('old-department-add') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.reload();
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }

    $(document).ready(function() {

        // When company changes
        $('#staff_company_name').on('change', function() {
            var companyId = $(this).val();
            var entityDropdown = $('#staff_entity_name');

            // Reset dropdown
            entityDropdown.empty().append('<option value="">Select Entity</option>');

            if (companyId) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: { company_id: companyId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                entityDropdown.append(
                                    $('<option></option>')
                                        .attr('value', entity.sno)
                                        .attr('data-baseurl', entity.entity_base_url)
                                        .text(entity.entity_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
        });

        // When entity changes
        $('#staff_entity_name').on('change', function() {
            $('#staff_add_btn').prop('disabled', true);
            $('#staff_data_payload').val('');
            $('#total_Staff_data').text('0');
            var entityId = $(this).val();
            const verify_key='egcsecret2030datagetapierp';
            
            
            var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
            if (baseurl) {
                var url = baseurl + 'api/department_data_get';
                $.ajax({
                    url: url,
                    type: "GET",
                    data:{auth_key:verify_key},
                    success: function(response) {
                        console.log('response:', response);
                        if (response.status === 200 && response.data) {
                            console.log(response.data);
                            var length=response.data.length;
                            var staffData =response.data;
                            
                            $('#total_Staff_data').text(length+' ')
                            // TODO: handle data display or form updates here
                            if(length > 0){
                                $('#staff_add_btn').prop('disabled', false);
                                // $('#staff_data_payload').val(JSON.stringify(staffData));
                            }else{
                                $('#staff_add_btn').prop('disabled', true);
                            }
                            loadDataView(staffData)
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching staff data:', error);
                    }
                });
            }
        });

    });

    function loadDataView(list) {

    let html = "";

    if (list.length === 0) {
        html += `<li  class="text-center text-danger">No attendance found</li>`;
    } else {
        list.forEach(a => {
            html += `
                    <li>
                        <label class="fw-semibold ">${a.sno} . ${a.department_name}</label>
                    </li>
            `;
        });
    }

    document.getElementById("total_Staff_list").innerHTML = html;
}

   </script>
@endsection
