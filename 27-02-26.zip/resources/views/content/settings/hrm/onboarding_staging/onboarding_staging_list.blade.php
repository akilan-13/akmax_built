@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Onboard Staging')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <style>
        .credential-wrapper {
            min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
            width: 280px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
            align-items:center;
            gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                               
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li>        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link "
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link ">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link active">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/interview_mode') }}" type="button"
                                class="nav-link scroll-link">
                                Interview
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                                class="nav-link scroll-link">
                                Assessment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link ">
                                    Business
                                </a>
                            </li>

                        <li class="nav-item">
                            <a href="{{ url('/settings/api_config') }}" type="button"
                                class="nav-link scroll-link ">
                                API Config
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/admin/webhooks') }}" type="button"
                                class="nav-link scroll-link ">
                                Webhook Moniter
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="d-flex credential-wrapper">
                <!-- CONTENT -->
                <div class="tab-content flex-grow-1 position-relative">
                    <!-- Toggle Button -->
                    <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Onboard Staging</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">HRM</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Onboard Staging
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_orientation_staging">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Onboard Staging
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between mb-4 ">
                                <div>
                                    <span>Show</span>
                                    <select id="perpage" class="form-select form-select-sm w-75px"
                                        onchange="loadThemes(1)">
                                        @php $options = [5,10, 25, 100, 500]; @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                                {{ $option }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input type="text" id="search_filter" class="searchQueryInput"
                                            placeholder="Search Document..."
                                            value="{{ $search_filter }}"/>
                                        
                                        <div class="searchAction">
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                                    <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                                </a>
                                                <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                                    <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-50px">Onboard Staging</th>
                                        <th class="min-w-50px">Schedule  Duration</th>
                                        <th class="min-w-50px">Score</th>
                                        <th class="min-w-50px">Emoji</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                    <tr class="skeleton-loader" id="skeleton-loader">
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
                <!-- SIDEBAR -->
                <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                    <ul class="nav nav-tabs flex-column" role="tablist">
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/document') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Documents</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Documents"><i class="fa-solid fa-folder-open  fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/document_checklist') }}" class="nav-link"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Document Checklist</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Document Checklist"><i class="fa-solid fa-list-check  fs-3"></i></span>
                                </label>
                                
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/onboarding_staging') }}" class="nav-link active"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Onboard Staging</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Onboard Staging"><i class="mdi mdi-calendar-account-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/questionnaire') }}" class="nav-link" role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">HR Questions</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="HR Questions"><i class="mdi mdi-file-question-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/onboarding_question') }}" class="nav-link" role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Onboarding Questions</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Onboarding Questions"><i class="mdi mdi-file-edit fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/metrics') }}" class="nav-link " role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text"> Metrics</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title=" Metrics"><i class="mdi mdi-pen-plus fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/onboarding') }}" class="nav-link " role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Onboard Checklist</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Onboard Checklist"><i class="mdi mdi-account-plus fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        
                      
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Add  Onboard Staging -->
    <div class="modal fade" id="kt_modal_add_orientation_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Onboard Staging</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-0 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Onboard Staging<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Onboard Staging">
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Schedule Duration<span
                                    class="text-danger">*</span></label>
                            <div class="input-group ">
                                <input type="text" class="form-control" placeholder="Enter Duration">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">Select</button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="#" selected>Day</a></li>
                                    <li><a class="dropdown-item" href="#">Hours</a></li>
                                    <li><a class="dropdown-item" href="#">Month</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" />Score
                            </label>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="fw-semibold mb-1 text-black">Emoji<span class="text-danger">*</span></label>
                            <div class="scroll-y max-h-200px">
                                <div class="d-flex flex-wrap gap-3 py-4 px-4">
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('box_smile');">
                                        <i class="mdi mdi-sticker-emoji fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_1" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_smile');">
                                        <i class="mdi mdi-emoticon-lol-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_2" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sad');">
                                        <i class="mdi mdi-emoticon-frown-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_3" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_angry');">
                                        <i class="mdi mdi-emoticon-confused-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_4" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cry');">
                                        <i class="mdi mdi-emoticon-cry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_5" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_feel');">
                                        <i class="mdi mdi-emoticon-sad-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_6" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sick');">
                                        <i class="mdi mdi-emoticon-sick-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_7" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_no_eye');">
                                        <i class="mdi mdi-emoticon-dead-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_8" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_kiss');">
                                        <i class="mdi mdi-emoticon-kiss-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_9" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_one_eye');">
                                        <i class="mdi mdi-emoticon-wink-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_10" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_angry');">
                                        <i class="mdi mdi-emoticon-angry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_11" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_devil');">
                                        <i class="mdi mdi-emoticon-devil-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_12" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_happy');">
                                        <i class="mdi mdi-emoticon-happy-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_13" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_all_close');">
                                        <i class="mdi mdi-emoticon-tongue-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_14" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_eye_up');">
                                        <i class="mdi mdi-emoticon-excited-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_15" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cooler');">
                                        <i class="mdi mdi-emoticon-cool-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_16" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_happy');">
                                        <i class="mdi mdi-emoticon-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_17" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_boy');">
                                        <i class="mdi mdi-face-man-shimmer-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_18" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4 py-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create
                            Onboard Staging</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add   Onboard Staging-->


    <!--begin::Modal - Edit  Onboard Staging -->
    <div class="modal fade" id="kt_modal_edit_onboard_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Onboard Staging</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-0 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Onboard Staging<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Onboard Staging" value="Training">
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Schedule Duration<span
                                    class="text-danger">*</span></label>
                            <div class="input-group ">
                                <input type="text" class="form-control" placeholder="Enter Duration" value="5">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">Select</button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="#" selected>Day</a></li>
                                    <li><a class="dropdown-item" href="#">Hours</a></li>
                                    <li><a class="dropdown-item" href="#">Month</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" checked/>Score
                            </label>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Emoji<span class="text-danger">*</span></label>
                            <div class="scroll-y max-h-200px">
                                <div class="d-flex flex-wrap gap-3 py-4 px-4">
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('box_smile');">
                                        <i class="mdi mdi-sticker-emoji fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_1" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_smile');">
                                        <i class="mdi mdi-emoticon-lol-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_2" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sad');">
                                        <i class="mdi mdi-emoticon-frown-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_3" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_angry');">
                                        <i class="mdi mdi-emoticon-confused-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_4" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cry');">
                                        <i class="mdi mdi-emoticon-cry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_5" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_feel');">
                                        <i class="mdi mdi-emoticon-sad-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_6" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sick');">
                                        <i class="mdi mdi-emoticon-sick-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_7" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_no_eye');">
                                        <i class="mdi mdi-emoticon-dead-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_8" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_kiss');">
                                        <i class="mdi mdi-emoticon-kiss-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_9" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_one_eye');">
                                        <i class="mdi mdi-emoticon-wink-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_10" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_angry');">
                                        <i class="mdi mdi-emoticon-angry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_11" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_devil');">
                                        <i class="mdi mdi-emoticon-devil-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_12" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_happy');">
                                        <i class="mdi mdi-emoticon-happy-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_13" style="display: block;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_all_close');">
                                        <i class="mdi mdi-emoticon-tongue-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_14" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_eye_up');">
                                        <i class="mdi mdi-emoticon-excited-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_15" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cooler');">
                                        <i class="mdi mdi-emoticon-cool-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_16" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_happy');">
                                        <i class="mdi mdi-emoticon-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_17" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_boy');">
                                        <i class="mdi mdi-face-man-shimmer-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_18" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4 py-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Update
                            Onboard Staging</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit   Onboard Staging-->

    <!--begin::Modal - Delete Onboard Staging-->
    <div class="modal fade" id="kt_modal_delete_onboard_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">HR Evaluation</b> Onboard Staging ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center py-4 mb-4">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black"
                        data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Onboard Staging-->

   

    <script>
        $(document).ready(function() {
            $('.metric_checkbox').change(function() {
                if ($(this).is(':checked')) {
                    $('.metric_div').slideDown(); // show with animation
                } else {
                    $('.metric_div').slideUp(); // hide with animation
                }
            });
        });
    </script>


    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

    <script>
        function emoji_func(val) {
            if (val == "box_smile") {
                document.getElementById("emj_1").style.display = "block";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_smile") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "block";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_sad") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "block";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_angry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "block";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_cry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "block";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_feel") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "block";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_sick") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "block";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_no_eye") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "block";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_kiss") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "block";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_one_eye") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "block";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_very_angry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "block";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_devil") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "block";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_happy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "block";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_all_close") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "block";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_eye_up") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "block";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_cooler") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "block";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_very_happy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "block";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_boy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "block";

            } else {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";
            }
        }
    </script>
    
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
                            
            <tr>
                <td>
                    <label class="fw-medium fs-7">${index}</label>
                </td>
                <td>
                    <label class="fs-7 fw-medium " data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="${item.onboarding_staging_name}">${item.onboarding_staging_name}</label>
                </td>
                <td align="center">
                    <label class="text-black fw-medium  fs-7 ">${item.schedule_duration || '-'}</label>
                </td>
                <td>
                    <label class="badge bg-label-success border border-success py-2 fw-semibold rounded-circle">
                        <i class="mdi mdi-check fs-6"></i>
                    </label>
                    <label class="badge bg-label-danger border border-danger py-2 fw-semibold rounded-circle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"><!-- Icon from Gridicons by Automattic - https://github.com/Automattic/gridicons/blob/trunk/LICENSE.md --><path fill="currentColor" d="M18.36 19.78L12 13.41l-6.36 6.37l-1.42-1.42L10.59 12L4.22 5.64l1.42-1.42L12 10.59l6.36-6.36l1.41 1.41L13.41 12l6.36 6.36z"/></svg>
                    </label>
                </td>
                <td>
                    <span><i class="mdi mdi-face-man-shimmer fs-2"></i></span>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                    <span class="text-end">
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_edit_onboard_staging"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" onclick="openEditModal('${item.sno}')">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                        </a>
                        <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_onboard_staging"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" onclick="confirmDelete('${item.sno}', '${item.onboarding_staging_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </a>
                    </span>
                </td>
            </tr>
            
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/onboarding_staging?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(7));
            }
                

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start =  total>0 ? (currentPage - 1) * perpage + 1 :0;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/document_status_change/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(1);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id, name) {
  
          document.querySelector('#kt_modal_delete_onboard_staging .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Document ?<br> <b class="text-black fw-bold fs-4">' +
              name +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_onboard_staging .btn-danger').getAttribute('data-id');

          fetch('/document_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {

              });
      }
</script>

<!-- add validate -->
 <script>
  function addValidateForm(){
    $("#createbtn").prop('disabled', true);
    var err =0;

         var document_name = document.getElementById("document_name").value.trim();
        if (document_name === "") {
            document.getElementById('document_name_err').innerHTML = 'Document Name is required...!';
            err++;
        } else {
            document.getElementById('document_name_err').innerHTML = '';
        }
      

    if(err>0){
        $("#createbtn").prop('disabled', false);
        return false;
       }else{
          $("#createbtn").prop('disabled', true);
          $('#addForm').submit();
       }
  }
 </script>
  <!-- edit Validate -->
  <script>
  function openEditModal(id,name,desc) {
   
    $('#edit_id').val(id);
    $('#document_edit_name').val(name);
    $('#document_edit_desc').val(desc || '');

  }
  function editValidateForm(){
    var err =0;

    var document_edit_name = document.getElementById("document_edit_name").value.trim();
        if (document_edit_name === "") {
            document.getElementById('document_edit_name_err').innerHTML = ' Document Name is required...!';
            err++;
        } else {
            document.getElementById('document_edit_name_err').innerHTML = '';
        }


    if(err>0){
        $("#updatebtn").prop('disabled', false);
        return false;
       }else{
          $("#updatebtn").prop('disabled', true);
          $('#updateForm').submit();
       }
  }
 </script>

@endsection
