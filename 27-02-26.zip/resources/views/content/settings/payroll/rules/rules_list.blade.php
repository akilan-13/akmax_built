@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Rule')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<!-- Users List Table -->
<div class="card">
    <div class="card-header pb-1">
        <ul class="nav nav-tabs flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                            class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                <div class="scroll-container" id="scrollContainer">
                    <li class="item nav-item">
                        <a href="{{ url('/settings/general_settings') }}" type="button" class="nav-link scroll-link"
                            role="tab">
                            General Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/sms_template') }}" type="button"
                            class="nav-link scroll-link ">
                            Common
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/credential_book') }}" type="button"
                            class="nav-link scroll-link">
                            Entity
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button"
                            class="nav-link scroll-link">
                            HRM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/applicant_status') }}" type="button"
                            class="nav-link scroll-link">
                            Recruitment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/rule_category') }}" type="button"
                            class="nav-link scroll-link active">
                            Payroll
                        </a>
                    </li>
                </div>
                <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                        class="mdi mdi-chevron-right fs-2 text-white"></i></button>
            </div>
        </ul>
    </div>
    <div class="card-body px-1 py-1">
        <div class="nav-align-right nav-tabs-shadow">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a href="{{ url('/settings/rule_category') }}" type="button" class="nav-link" role="tab">
                        <label class="fs-6 right_nav">
                            Rule Category
                            <span><i class="mdi mdi-clipboard-text-outline ms-2 fs-3"></i></span>
                        </label>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ url('/settings/rules') }}" type="button" class="nav-link active" role="tab">
                        <label class="fs-6 right_nav">
                            Rule
                            <span><i class="mdi mdi-clipboard-check-outline ms-2 fs-3"></i></span>
                        </label>
                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                    <div class="d-flex flex-column align-items-start">
                        <h5 class="card-title mb-1 text-black">Rule</h5>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb custom-breadcrumb">
                                <!-- Home -->
                                <li class="breadcrumb-item">
                                    <a href="{{ url('/dashboard') }}">
                                        <i class="mdi mdi-cog"></i> Settings
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="javascript:void(0);">Payroll </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <a href="javascript:void(0);" class="active-link">
                                        Rule
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                        <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_add_rule">
                            <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Rule
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                            <div>
                                <span>Show</span>
                                <br>
                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                                    <option value="10">10</option>
                                    <option value="25" selected>25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Rule" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/settings/rule')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-50px">Rules</th>
                                    <th class="min-w-50px">Rule Category</th>
                                    <th class="min-w-50px">Status</th>
                                    <th class="min-w-50px">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <label class="fw-medium fs-7">1</label>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium">Late</label>
                                        <a href="javascipt:;" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="-">
                                            <i class="mdi mdi mdi-help-circle text-dark"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium text-black">Attendance</label>
                                    </td>
                                    <td>
                                        <label class="switch switch-square">
                                            <input type="checkbox" class="switch-input" checked />
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <span class="text-end">
                                            <a href="#" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_update_rules"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Edit">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                            </a>
                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_delete_rules"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Delete">
                                                <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                            </a>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="fw-medium fs-7">2</label>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium">OD Charges</label>
                                        <a href="javascipt:;" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="-">
                                            <i class="mdi mdi mdi-help-circle text-dark"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium text-black">Payroll</label>
                                    </td>
                                    <td>
                                        <label class="switch switch-square">
                                            <input type="checkbox" class="switch-input" checked />
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <span class="text-end">
                                            <a href="#" data-bs-toggle="modal" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Edit"
                                                data-bs-target="#kt_modal_update_rules">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                            </a>
                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_delete_rules"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Delete">
                                                <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                            </a>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label class="fw-medium fs-7">3</label>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium">Travel Claim</label>
                                        <a href="javascipt:;" data-bs-toggle="tooltip"
                                            data-bs-placement="right" title="-">
                                            <i class="mdi mdi mdi-help-circle text-dark"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <label class="fs-7 fw-medium text-black">Payroll</label>
                                    </td>
                                    <td>
                                        <label class="switch switch-square">
                                            <input type="checkbox" class="switch-input" checked />
                                            <span class="switch-toggle-slider">
                                                <span class="switch-on"></span>
                                                <span class="switch-off"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <span class="text-end">
                                            <a href="#" data-bs-toggle="modal" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Edit"
                                                data-bs-target="#kt_modal_update_rules">
                                                <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                            </a>
                                            <a href="javascript:;" class="btn btn-icon btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_delete_rules"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="Delete">
                                                <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                            </a>
                                        </span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Add Rules -->
<div class="modal fade" id="kt_modal_add_rule" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <!-- Header -->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Rules</h3>
                </div>
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    ✕
                </div>
            </div>
            <!-- Body -->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row">
                    <!-- Rules -->
                    <div class="col-lg-6 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Rules<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Rules">
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Rule Category<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="rule_category">
                            <option value="">Select Rule Category</option>
                            <option value="1">Attendance</option>
                            <option value="2">Payroll</option>
                        </select>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                        <label class="fw-semibold text-black fs-5">Conditions</label>
                        <button class="btn btn-primary btn-sm" id="add_condition">
                            <i class="mdi mdi-plus"></i> Add Conditions
                        </button>
                    </div>
                    <div class="col-lg-12 mb-1 scroll-y max-h-250px" id="condition-container">
                        <div class="row condition-row">
                            <div class="col-lg-10 mb-2">
                                <div class="row">
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Field<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Field">
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Operator<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" id="rule_category">
                                            <option value="">Select Operator</option>
                                            <option value="1">Greater Than Equal To>=</option>
                                            <option value="2">Less Than Equal To <=</option>
                                            <option value="3">Less Than <</option>
                                            <option value="4">Greater Than ></option>
                                            <option value="5">Equal To ==</option>
                                            <option value="6">Not Equal To !=</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Value<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Value">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 mb-2 d-flex align-items-center justify-content-center">
                                <a href="javascript:;" class="btn btn-outline-danger delete-option p-1">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                        <label class="fw-semibold text-black fs-5">Penalities</label>
                        <button class="btn btn-primary btn-sm" id="add_penalty">
                            <i class="mdi mdi-plus"></i> Add Penalties
                        </button>
                    </div>
                    <div class="col-lg-12 mb-2 scroll-y max-h-250px" id="penalty-container">
                        <div class="row penalty-row">
                            <div class="col-lg-10 mb-2">
                                <div class="row">
                                    <div class="col-lg-6 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Field<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Field">
                                    </div>
                                    <div class="col-lg-6 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Value<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Value">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 mb-2 d-flex align-items-center justify-content-center">
                                <a href="javascript:;" class="btn btn-outline-danger delete-penalty p-1">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"></textarea>
                    </div>
                </div>
                <!-- Footer -->
                <div class="d-flex justify-content-between mt-4">
                    <button type="reset" class="btn btn-outline-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary">Create Rules</button>
                </div>

            </div>
        </div>
    </div>
</div>
<!--end::Modal - Add  Rules-->


<!--begin::Modal - Update Rules -->
<div class="modal fade" id="kt_modal_update_rules" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <!-- Header -->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Rules</h3>
                </div>
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded"
                    style="border: 2px solid #000;" data-bs-dismiss="modal">✕</div>
            </div>
            <!-- Body -->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row">
                    <!-- Rules -->
                    <div class="col-lg-6 mb-2">
                        <label class="fw-semibold">Rules<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Rules" value="Late">
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Rule Category<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="rule_category_edit">
                            <option value="">Select Rule Category</option>
                            <option value="1" selected>Attendance</option>
                            <option value="2">Payroll</option>
                        </select>
                    </div>  
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                        <label class="fw-semibold text-black fs-5">Conditions</label>
                        <button class="btn btn-primary btn-sm" id="add-condition-wrapper-edit">
                            <i class="mdi mdi-plus me-1"></i>Add Conditions
                        </button>
                    </div>
                    <div class="col-lg-12 mb-2 scroll-y max-h-250px" id="condition-container-edit">
                        <div class="row condition-row-edit">
                            <div class="col-lg-10 mb-2">
                                <div class="row">
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Field<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Field" value="Late Count">
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Operator<span class="text-danger">*</span></label>
                                        <select class="select3 form-select" id="rule_category">
                                            <option value="">Select Operator</option>
                                            <option value="1" selected>Greater Than Equal To>=</option>
                                            <option value="2">Less Than Equal To <=</option>
                                            <option value="3">Less Than <</option>
                                            <option value="4">Greater Than ></option>
                                            <option value="5">Equal To ==</option>
                                            <option value="6">Not Equal To !=</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Value<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Value" value="4">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 mb-2 d-flex align-items-center justify-content-center">
                                <a href="javascript:;" class="btn btn-outline-danger delete-option-edit p-1">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between gap-5">
                        <label class="fw-semibold text-black fs-5">Penalities</label>
                        <button class="btn btn-primary btn-sm" id="add-penalty-wrapper-edit">
                            <i class="mdi mdi-plus"></i> Add Penalties
                        </button>
                    </div>
                    <div class="col-lg-12 mb-2 scroll-y max-h-250px" id="penalty-container-edit">
                        <div class="row penalty-row-edit ">
                            <div class="col-lg-10 mb-2">
                                <div class="row">
                                    <div class="col-lg-6 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Field<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Field" value="Loss of Pay">
                                    </div>
                                    <div class="col-lg-6 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Value<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Enter Value" value="1 Day">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 mb-2 d-flex align-items-center justify-content-center">
                                <a href="javascript:;" class="btn btn-outline-danger delete-penalty-edit p-1">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Description -->
                    <div class="col-lg-12 mb-3">
                        <label class="fw-semibold">Description</label>
                        <textarea class="form-control" id="edit_description"></textarea>
                    </div>
                </div>
                <!-- Footer -->
                <div class="d-flex justify-content-between mt-4">
                    <button type="reset" class="btn btn-outline-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary">Update Rules</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::Modal -->


<!--begin::Modal - Delete Rules-->
<div class="modal fade" id="kt_modal_delete_rules" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Late </b>
                    Rules ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Rules-->



<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Toastr CSS from CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JavaScript from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }
</style>

<script>
    $(document).ready(function () {

        $('.condition-row .delete-option').first().hide();
        $('.penalty-row .delete-penalty').first().hide();

        $(document).off('click', '#add_condition').on('click', '#add_condition', function (e) {
            e.preventDefault();

            let $container = $('#condition-container');
            let $clone = $container.find('.condition-row').first().clone();

            $clone.find('input').val('');
            $clone.find('select').val('');
            $clone.find('.delete-option').show();

            $container.append($clone);
        });

        $(document).on('click', '.delete-option', function () {
            let $container = $('#condition-container');

            if ($container.find('.condition-row').length > 1) {
                $(this).closest('.condition-row').remove();
            }
        });

        $(document).off('click', '#add_penalty').on('click', '#add_penalty', function (e) {
            e.preventDefault();

            let $container = $('#penalty-container');
            let $clone = $container.find('.penalty-row').first().clone();

            $clone.find('input').val('');
            $clone.find('.delete-penalty').show();

            $container.append($clone);
        });

        $(document).on('click', '.delete-penalty', function () {
            let $container = $('#penalty-container');

            if ($container.find('.penalty-row').length > 1) {
                $(this).closest('.penalty-row').remove();
            }
        });
    });
</script>

<script>
    $(document).ready(function () {

        // Hide delete for first row
        $('#condition-container-edit .condition-row-edit .delete-option-edit').first().hide();

        // ADD CONDITION
        $(document).off('click', '#add-condition-wrapper-edit')
        .on('click', '#add-condition-wrapper-edit', function (e) {
            e.preventDefault();

            let $container = $('#condition-container-edit');
            let $clone = $container.find('.condition-row-edit').first().clone();

            // Clear values
            $clone.find('input').val('');
            $clone.find('select').val('').trigger('change');

            // Show delete button
            $clone.find('.delete-option-edit').show();

            // Append inside scroll container
            $container.append($clone);
        });

        // DELETE CONDITION
        $(document).on('click', '.delete-option-edit', function () {
            let $container = $('#condition-container-edit');

            if ($container.find('.condition-row-edit').length > 1) {
                $(this).closest('.condition-row-edit').remove();
            }
        });

        // Hide delete for first row
        $('#penalty-container-edit .penalty-row-edit .delete-penalty-edit').first().hide();

        // ADD PENALTY
        $(document).off('click', '#add-penalty-wrapper-edit')
        .on('click', '#add-penalty-wrapper-edit', function (e) {
            e.preventDefault();

            let $container = $('#penalty-container-edit');
            let $clone = $container.find('.penalty-row-edit').first().clone();

            // Clear values
            $clone.find('input').val('');

            // Show delete
            $clone.find('.delete-penalty-edit').show();

            // Append inside scroll container
            $container.append($clone);
        });

        // DELETE PENALTY
        $(document).on('click', '.delete-penalty-edit', function () {
            let $container = $('#penalty-container-edit');

            if ($container.find('.penalty-row-edit').length > 1) {
                $(this).closest('.penalty-row-edit').remove();
            }
        });

    });
</script>


@endsection
