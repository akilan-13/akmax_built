@extends('layouts/blankLayout')

@section('title', 'Cancellations and Refunds')

@section('content')
<div class="container-fluid d-flex justify-content-center" style="min-height:100vh;">
    <div class="container d-flex flex-column align-items-center" style="max-width:900px;">

        <!-- Logo -->
        @if(!empty($logoUrl))
            <div class="mb-4">
                <img src="{{ $logoUrl }}" alt="Company Logo" style="max-height:70px;">
            </div>
        @endif

        <!-- Header -->
        <div class="text-center mb-4">
            <h1 class="fw-bold">Cancellations & Refunds</h1>
            <p class="text-muted fs-5 mb-0">
                Our policies are designed to be transparent, fair, and customer-friendly.
            </p>
        </div>

        <!-- Content -->
        <div class="w-100">

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-cancel text-danger me-2"></i>
                    Cancellation Policy
                </h6>
                <p class="text-muted mb-0">
                    Cancellation requests must be raised within a limited time after placing the order.
                    Once the service, research work, or documentation process has started,
                    cancellations may not be possible.
                </p>
            </div>

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-cash-refund text-success me-2"></i>
                    Refund Policy
                </h6>
                <p class="text-muted mb-0">
                    Refunds are considered only if the service has not been initiated or delivered.
                    Eligible refunds will be processed after internal verification and credited
                    to the original payment method.
                </p>
            </div>

            <div class="mb-4">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-close-circle-outline text-warning me-2"></i>
                    Non-Refundable Services
                </h6>
                <p class="text-muted mb-0">
                    Customized services, completed work, consultation fees,
                    and delivered digital content are strictly non-refundable.
                </p>
            </div>

            <div class="mb-0">
                <h6 class="fw-semibold">
                    <i class="mdi mdi-email-outline text-primary me-2"></i>
                    Support & Queries
                </h6>
                <p class="text-muted mb-0">
                    For cancellation or refund-related queries, please contact our support team
                    through the official communication channels provided on our website.
                </p>
            </div>

        </div>

    </div>
</div>
@endsection
