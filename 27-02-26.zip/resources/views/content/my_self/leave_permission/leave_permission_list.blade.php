@extends('layouts/layoutMaster')

@section('title', 'Leave Permission')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn{
        width: 100%;
        height: 100%;
        display:none;
        color:black;
        background-color:rgba(0,0,0,0.2);
    }

    .document-thumbnail:hover .view-btn{
        display:flex;
        justify-content:center;
        align-items:center;
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>

<style>
    .flow-preview-box{
        display:flex;
        align-items:center;
        flex-wrap:wrap;
        gap:10px;
        min-height:60px;
    }

    .flow-node{
        padding:8px 14px;
        border-radius:999px;
        background:#eef2ff;
        font-weight:600;
        position:relative;
    }

    .flow-node.start{ background:#dcfce7; }
    .flow-node.hr{ background:#fee2e2; }
    .flow-node.manager{ background:#fef3c7; }

    .flow-arrow{
        font-size:18px;
        color:#9ca3af;
    }
</style>
<style>
    /* ===== MODERN HR LEAVE UI ===== */

    /* Card sections */
    .leave-card{
        background:#f9fafb;
        border-radius:16px;
        padding:18px;
        border:1px solid #e5e7eb;
        margin-bottom:18px;
    }

    /* request selector */
    .request-type-box{
        display:flex;
        gap:20px;
    }

    .type-card{
        flex:1;
        border:2px solid #e5e7eb;
        border-radius:14px;
        padding:10px;
        text-align:center;
        cursor:pointer;
        transition:.25s;
    }

    .type-card:hover{
        transform:translateY(-3px);
        box-shadow:0 12px 30px rgba(0,0,0,.08);
    }

    .type-card.active{
        border-color:#ab2b22;
        background:#fba91936;
    }

    .type-icon{
        font-size:32px;
        margin-bottom:10px;
    }

    /* date planner */
    .leave-date-input{
        background:#ffffff;
        border-radius:14px !important;
        border:1px solid #e5e7eb !important;
        transition:.2s;
    }

    .leave-date-input:hover{
        border-color:#ab2b22 !important;
    }

    /* summary */
    .leave-summary{
        background:#fba91952;
        color:#000000cc;
        border-radius:16px;
        padding:18px;
    }

</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Leave & Permission</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Operation
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                 <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-end">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_add_leave_request">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Leave Request
                </a>
               
            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
            
            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Status</option>
                        <option value="0">Pending</option>
                        <option value="1">Approved</option>
                        <option value="3">Rejected</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;"  class="filterSubmit" id="filterSubmit" >
                    <span class="btn btn-primary btn-sm" > Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                 <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Request Type</th>
                                <th class="min-w-150px">Leave / Permission Dates</th>
                                <th class="min-w-200px">Reason</th>
                                <th class="min-w-100px">Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3"  onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_add_leave_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>

            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black" id="request_title_name">Leave Request</h3>
                </div>

                <div class="modal-body pt-4 pb-5 px-4 px-xl-6">
                        <div class="row mb-3">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                                <div><span class="fw-semibold text-primary fs-7 fw-bold d-block">{{$staffProfile->staff_name}}</span></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                <div><span class="badge fs-7 fw-bold" style="background:{{$staffProfile->company_base_color ?? ''}};">{{$staffProfile->company_name}}</span></div>
                                
                            </div>
                            @if($staffProfile->company_id != 0)
                           
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                                <div><span class="badge fs-7 fw-bold" style="background:{{$staffProfile->entity_base_color ?? ''}};">{{$staffProfile->entity_name}}</span></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                <div><span class="badge bg-label-primary fs-7 fw-bold">{{$staffProfile->branch_name}}</span></div>
                            </div>
                         @endif
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                <div><span class="fw-semibold text-black fs-7 text-truncate d-block">{{$staffProfile->department_name}}</span></div>
                                
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Job Role Name</label>
                                <div><span class="fw-semibold text-black fs-7 text-truncate d-block">{{$staffProfile->job_role_name ?? 'N/A'}}</span></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">{{date('F')}} Leave Taken</label>
                                <div><span class="fw-semibold text-success fs-7 d-block">{{$staffProfile->current_month_leave_taken ?? 0}} days</span></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">{{date('F')}} Permission Taken</label>
                                <div><span class="fw-semibold text-info fs-7 d-block">{{$staffProfile->current_month_permission_taken ?? 0}} hours</span></div>
                            </div>
                        </div>
                        <div class="leave-card-title mb-3">
                            <label class="fw-semibold mb-2">Request Type</label>

                            <div class="request-type-box">
                                <div class="type-card" data-type="Leave">
                                    <div class="type-icon"></div>
                                    <h5>Leave</h5>
                                    <small>Full / Half day leave</small>
                                </div>

                                <div class="type-card" data-type="Permission">
                                    <div class="type-icon"></div>
                                    <h5>Permission</h5>
                                    <small>Short time permission</small>
                                </div>
                            </div>

                            <input type="hidden" name="request_type" id="request_type">
                        </div>
                        <div id="leave_dates_section">
                            <div class="leave-card mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="fw-semibold">Schedule Planner</label>
                                    <button type="button" class="btn btn-sm btn-primary" id="addRow">
                                        <i class="mdi mdi-plus"></i> Add
                                    </button>
                                </div>

                                <div id="plannerRows"></div>
                            </div>

                            <div class="leave-card mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="fw-semibold">Work Assigned</label>
                                    <button type="button" class="btn btn-sm btn-primary" id="addTaskRow">
                                        <i class="mdi mdi-plus"></i> Add
                                    </button>
                                </div>

                                <div id="plannerTaskRows"></div>
                            </div>

                            <div class="leave-card mt-3">
                                <div class="d-flex justify-content-between">
                                    <h5 class="mb-3">
                                        <i class="mdi mdi-sitemap-outline me-1"></i>
                                        Approval Preview
                                    </h5>
                                    <div id="liveSummary">No entries added</div>
                                </div>
                                <div id="approvalPreview" class="flow-preview-box">
                                    <div class="text-muted">Approval Hierarchy Not Set Yet</div>
                                </div>
                            </div>
                            <input type="hidden" name="staff_hidden_id" id="staff_hidden_id" value="{{$staffProfile->sno}}">
                            <div class="d-flex justify-content-end mt-4">
                                <button type="button" class="btn btn-primary" id="submitStaffBtn">
                                    <span id="submitText">Submit Request</span>
                                    <span id="submitLoader" style="display:none;" class="spinner-border spinner-border-sm"></span> <!-- Loader -->
                                </button>
                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>


<!-- <div class="modal fade" id="kt_modal_add_leave_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>

            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black" id="request_title_name">Leave Request</h3>
                </div>

                <div class="modal-body pt-4 pb-5 px-4 px-xl-6">
                    
                        <div class="leave-card-title mb-3">
                            <label class="fw-semibold mb-2">Request Type</label>

                            <div class="request-type-box">
                                <div class="type-card active" data-type="Leave">
                                    <div class="type-icon"></div>
                                    <h5>Leave</h5>
                                    <small>Full / Half day leave</small>
                                </div>

                                <div class="type-card" data-type="Permission">
                                    <div class="type-icon"></div>
                                    <h5>Permission</h5>
                                    <small>Short time permission</small>
                                </div>
                            </div>

                            <input type="hidden" name="request_type" id="request_type">
                        </div>
                        <div class="leave-card">
                            <div class="row mb-3">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                                    <div><span class="fw-semibold text-primary fs-7 fw-bold d-block">{{$staffProfile->staff_name}}</span></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                    <div><span class="badge fs-7 fw-bold" style="background:{{$staffProfile->company_base_color ?? ''}};">{{$staffProfile->company_name}}</span></div>
                                    
                                </div>
                                @if($staffProfile->company_id != 0)
                            
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                                    <div><span class="badge fs-7 fw-bold" style="background:{{$staffProfile->entity_base_color ?? ''}};">{{$staffProfile->entity_name}}</span></div>
                                </div>

                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                    <div><span class="badge bg-label-primary fs-7 fw-bold">{{$staffProfile->branch_name}}</span></div>
                                </div>
                            @endif
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                    <div><span class="fw-semibold text-black fs-7 text-truncate d-block">{{$staffProfile->department_name}}</span></div>
                                    
                                </div>
                            </div>

                            <div id="leave_dates_section">
                               

                                <div class=" mb-3">
                                    <div class="row">
                                        <div class="col-md-3" id="leave_from_div">
                                            <label class="fw-semibold">From date</label>
                                            <input type="text" class="form-control common_datepicker_leave" id="fromDate" placeholder="From Date" />
                                        </div>
                                        <div class="col-md-3 " id="leave_to_div">
                                            <label class="fw-semibold">To date</label>
                                            <input type="text" class="form-control common_datepicker_leave" id="toDate" placeholder="To Date" onchange="datechange()" />
                                        </div>
                                        <div class="col-md-3 " style="display:none;" id="permission_date_div">
                                            <label class="fw-semibold">Date</label>
                                            <input type="text" class="form-control common_datepicker_leave" id="permDate" placeholder="Date" />
                                        </div>
                                        <div class="col-md-2 permission_div" style="display:none;" id="permission_from_div">
                                            <label class="fw-semibold">From Time</label>
                                            <input type="text" class="form-control time-from-per" id="fromTime" placeholder="From">
                                        </div>
                                        <div class="col-md-2 permission_div" style="display:none;" id="permission_to_div">
                                            <label class="fw-semibold">To Time</label>
                                            <input type="text" class="form-control time-from-per" id="toDate" placeholder="To" />
                                        </div>
                                        <div class="col-md-6"  id="leave_reason_div">
                                            <label>Leave Purpose</label>
                                            <textarea name="leave_reason" id="leave_reason" class="form-control" placeholder="Enter Purpose" rows="1" ></textarea>
                                        </div>
                                        <div class="col-md-5" style="display:none;" id="permission_reason_div">
                                            <label>Permission Purpose</label>
                                            <textarea name="permission_reason" id="permission_reason" class="form-control" placeholder="Enter Purpose" rows="1" ></textarea>
                                        </div>
                                    </div>
                                    <div class="row my-3 px-4  scroll-y max-h-250px " id="leave_dates_div" style="display:none;">
                                        <label class="fw-semibold">Leave Dates</label>
                                        <div id="leaveSelection" class="mb-3 row"></div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center my-2">
                                        <label class="fw-semibold">Work Assigned</label>
                                        <button type="button" class="btn btn-sm btn-primary" id="addTaskRow">
                                            <i class="mdi mdi-plus"></i> Add Work Assigned
                                        </button>
                                    </div>

                                    <div id="plannerTaskRows"></div>
                                </div>


                                <div class="leave-summary">
                                    <div id="">
                                        <b>Total Leave Taken This Month:</b> <span id="totalLeaveThisMonth">01</span> days
                                    </div>
                                    <div id="liveSummary">No entries added</div>
                                </div>

                                <div class="leave-card mt-3">
                                    <h5 class="mb-3">
                                        <i class="mdi mdi-sitemap-outline me-1"></i>
                                        Approval Preview
                                    </h5>

                                    <div id="approvalPreview" class="flow-preview-box">
                                        <div class="text-muted">Approval Hierarchy Not Set Yet</div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end mt-4">
                                    <button type="button" class="btn btn-primary" id="submitStaffBtn" >Submit Request</button>
                                </div>
                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div> -->

<!--end::Modal - Filter-->
  


   

 

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
    function formatTimeCommon(time) {
        if (!time) {
            return '';
        }
        
        const [hours, minutes, seconds] = time.split(':');

        const date = new Date(0); 
        date.setHours(parseInt(hours)); 
        date.setMinutes(parseInt(minutes)); 
        date.setSeconds(parseInt(seconds)); 

        const options = {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true 
        };

        return date.toLocaleTimeString([], options);  
    }
   
    function buildRow(item,index) {    
        
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
  
        // let staff_image = '';
        // if (data.staff_image && data.staff_image.trim() !== '') {
        //     if (data.company_type == 1) {
        //         staff_image = `staff_images/Management/${data.staff_image}`;
        //     } else {
        //         staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
        //     }
        // } else {
        //     staff_image = data.gender == 1
        //         ? 'assets/egc_images/auth/user_2.png'
        //         : 'assets/egc_images/auth/user_2.png';
        // }
        // staff_image = `{{ asset('${staff_image}') }}`;
         
        return `
            <tr>
                <td style="position:relative;">
                    <div class="d-flex">
                        <div class="mb-0">
                            <label class="d-flex gap-1 no-wrap">
                                <span class="fs-7 me-1 text-black badge ${data.request_type == 'Leave' ? 'bg-warning ':'bg-info ' } text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${data.request_type || '-'}">${data.request_type}</span>
                            </label>
                             
                        </div>
                    </div>
                </td>
                <td>
                    ${data.request_type =='Leave' ? 
                        ` <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                            ${data.from_date ? formatDateCommon(data.from_date) : '-'}
                        </label> `
                        :
                        `
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                            ${data.from_date ? formatDateCommon(data.from_date) : '-'}
                        </label>
                        <div class="d-flex no-wrap gap-1">
                            <label class="fw-semibold text-success fs-7 d-block text-nowrap">
                                ${data.from_date ? formatTimeCommon(data.from_time) : '-'}
                            </label>
                        -
                            <label class="fw-semibold text-success fs-7 d-block text-nowrap">
                                ${data.from_date ? formatTimeCommon(data.to_time) : '-'}
                            </label>
                        </div>
                        `
                    }
                  
                </td>
                <td>
                    <label class="fw-bold fs-8 text-truncate text-black d-block"
                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title=" ${data.reason}">
                       ${data.reason}
                    </label>
                </td>
                <td>
                   <span class="badge border border-warning rounded bg-white text-black fw-semibold fs-7">
                        Pending
                    </span> 
                </td>
                <td>
                  <a href="javascript:;" class="fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${item.sno})">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"> <i class="mdi mdi-eye fs-3 text-dark "></i></span>
                    </a>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = "";
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;

        const url = `/my_self/leave_permission?page=${page}&sorting_filter=${perpage}&search_filter=${search}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
 
 
 
</script>

<script>
    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    let selectedDates = [];
    let totalLeaveDays = 0;
    let totalPermissionHours = 0;
</script>




 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

            result = result.trim();

            // Add "In" or "Ago"
            if (isFuture) {
                result = `In ${result}`;
            } else if (result !== '0 days') {
                // result += ' ago';
                result += '';
            }

            return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>

<script>
    function getOrdinalSuffix(number) {
        const suffixes = ["th", "st", "nd", "rd"];
        const remainder = number % 100;
        return suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    }

    function getInitials(name) {
        if (!name) return '';
        const words = name.trim().split(' ');
        
        return (words[0][0]).toUpperCase();
    }

    function getInitialAvatar(name){
        if(!name) name='?';

        let initials = name.trim().charAt(0).toUpperCase();
        let colors = ['#6366f1','#22c55e','#06b6d4','#f59e0b','#ef4444','#ab2b22'];
        let color = colors[name.length % colors.length];

        return `
        <div class="emp-avatar-img d-flex align-items-center justify-content-center"
            style="background:${color}">
            ${initials}
        </div>`;
    }

    function getAvatarColor(name) {
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }
    function escapeHtml(text){
        if(!text) return '';
        return text.replace(/'/g,"&#39;").replace(/"/g,"&quot;");
    }
    function replaceWithInitials(img, name) {
        console.log(img,name)
        const initials = getInitials(name);
        const color = getAvatarColor(name);
        console.log(name ,initials)
        const div = document.createElement('div');
        div.className = `rounded-circle ${color} text-white d-flex align-items-center justify-content-center me-3 fw-bold`;
        div.style.width = '50px';
        div.style.height = '50px';
        div.innerText = initials;

        img.replaceWith(div);
    }
</script>

<script>
    const planner = {
        type: null,
        rows: [],
        totalDays: 0,
        totalHours: 0
    };
    // refreshSummary();
    $(document).on('click','.type-card',function(){
        $('.type-card').removeClass('active');
        $(this).addClass('active');

        planner.type = $(this).data('type');
        $('#request_type').val(planner.type);
        $('#request_title_name').text(planner.type == 'Leave' ? 'Leave Request' : 'Permission Request');

        $('#plannerRows').empty();
        planner.rows = [];
        refreshSummary();
        addLeaveSchudle();
        // addWorkSchudle();
        // changeleaveDiv()
    });


    $('#addRow').on('click',()=>{
        addLeaveSchudle();
    });

    function addLeaveSchudle (){

        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }

        const id = Date.now();

        let html = `
        <div class="planner-row border rounded p-3 mb-2" data-id="${id}">
            <div class="row g-2 align-items-center">

                <div class="col-md-3">
                    <label>Date<span class="text-danger">*</span></label>
                    <input type="text" class="form-control row-date common_datepicker_leave" required placeholder ="Date">
                    <div class="text-danger error-message" ></div>
                </div>
        `;

        if(planner.type === 'Leave'){
            html += `
                <div class="col-md-3">
                    <label>Leave Type<span class="text-danger">*</span></label>
                    <select class="form-select select3 row-leave" id="leave_type_${id}" onchange="leave_type_change()">
                        <option value="">Select Half/Full</option>
                        <option value="Full">Full Day</option>
                        <option value="Morning Half">Morning Half</option>
                        <option value="Afternoon Half">Afternoon Half</option>
                    </select>
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-5">
                    <label>Reason<span class="text-danger">*</span></label>
                    <textarea class="form-control row-reason"  placeholder ="Enter Leave Purpose" rows="1" ></textarea>
                    <div class="text-danger error-message" ></div>
                </div>
            `;
        }else{
            // refreshLeaveSelection()
            html += `
                <div class="col-md-2">
                    <label>From<span class="text-danger">*</span></label>
                    <input type="text" class="form-control time-from" placeholder ="From Time">
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-2">
                    <label>To<span class="text-danger">*</span></label>
                    <input type="text" class="form-control time-to" placeholder ="To Time">
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-4">
                    <label>Reason<span class="text-danger">*</span></label>
                    <textarea class="form-control row-reason"  placeholder ="Enter Permission Purpose" rows="1" ></textarea>
                    <div class="text-danger error-message" ></div>
                </div>
            `;
        }

        html += `
                    <div class="col-md-1 text-end">
                            <button class="btn btn-danger btn-sm removeRow mt-4">✕</button>
                    </div>
                </div>
            </div>`;

        $('#plannerRows').append(html);
        
        $(".common_datepicker_leave").datepicker({
            format: "dd-M-yyyy",
            autoclose: true,
            beforeShowDay: function(date) {
                let options = { day: '2-digit', month: 'short', year: 'numeric' };
                let formattedDate = date.toLocaleDateString('en-GB', options).replace(/ /g, '-');
                return selectedDates.indexOf(formattedDate) === -1;
            },
            todayHighlight: true
        });

        $(".common_datepicker_leave").on('change', function() {
            var dateText = $(this).val();
            handleDateChange(dateText);
        });

        $(`#leave_type_${id}`).select2({
            width: '100%',
            dropdownParent: $(`#leave_type_${id}`).closest('.col-md-3'),
        });
        // $('.row-date').flatpickr({dateFormat:'d-M-Y'});
        $('.time-from,.time-to').flatpickr({enableTime:true,noCalendar:true,dateFormat:"h:i K"});
    }

    function leave_type_change(){
        refreshSummary();
    }
    $(document).on('change','.row-leave,.time-from,.time-to',refreshSummary);

    $(document).on('click','.removeRow',function(){
        $(this).closest('.planner-row').remove();
        refreshSummary();
    });


    function refreshSummary(){
        console.log("working")
        planner.totalDays = 0;
        planner.totalHours = 0;

        $('.planner-row').each(function(){

            if(planner.type === 'Leave'){
                let type=$(this).find('.row-leave').val();
                planner.totalDays += (type != '' ? (type==='Full'? 1:0.5) : 0);
            }
            else{
                let from=$(this).find('.time-from').val();
                let to=$(this).find('.time-to').val();
                if(from && to){
                    let diff=(new Date('1970-01-01 '+to)-new Date('1970-01-01 '+from))/3600000;
                    planner.totalHours+=diff;
                }
            }
        });

        let html = `<b>Type:</b> <span class="badge ${planner.type==='Leave' ? 'bg-danger':'bg-secondary'}">${planner.type || '-'}</span><br>`;

        if(planner.type==='Leave')
            html+=`<b>Total Days:</b> ${planner.totalDays} days`;
        else if(planner.type==='Permission')
            html+=`<b>Total Hours:</b> ${planner.totalHours.toFixed(2)} hrs`;

        $('#liveSummary').html(html);
    }

</script>

<script>
    $('#addTaskRow').on('click',()=>{
        addWorkSchudle();
    });
    
    function addWorkSchudle (){

        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }

        const id = Date.now();

        let html = `
        <div class="planner-task-row border rounded p-3 mb-2" data-id="${id}">
            <div class="row g-2 align-items-end">

                <div class="col-md-3">
                    <label>Task</label>
                    <textarea class="form-control work-task-name" placeholder="Enter Task name" rows="1"></textarea>
                </div>
                <div class="col-md-3">
                    <label>Assigned Staff</label>
                    <select class="form-select select3 work-leave" id="work_assigned_staff_${id}" >
                        <option value="">Select Staff</option>
                        
                    </select>
                </div>
        `;

        html += `
                    <div class="col-md-1 text-end">
                        <button class="btn btn-danger removeTaskRow">✕</button>
                    </div>
                </div>
            </div>`;

        $('#plannerTaskRows').append(html);
        
      

        $(`#work_assigned_staff_${id}`).select2({
            width: '100%',
            dropdownParent: $(`#work_assigned_staff_${id}`).closest('.col-md-3'),
        });
      
    }
    $(document).on('click','.removeTaskRow',function(){
        $(this).closest('.planner-task-row').remove();
    });
</script>

<script>
    let leveljson = @json($approve_level);
    let staffProfile = @json($staffProfile);
    if(leveljson){
        renderApprovalPreview(leveljson)
    }
    function renderApprovalPreview(levels){
       
        let html='';

        html+=`<div class="flow-node employee">${staffProfile.staff_name}</div>`;

        levels.forEach(level=>{
            console.log(level)
            html+=`<div class="flow-arrow"><i class="mdi mdi-arrow-right"></i></div>`;

            let roleClass='manager';

            if(level.role_type==='HR') roleClass='hr';
            if(level.role_type==='Director') roleClass='director';

            html+=`
            <div class="flow-node ${roleClass}">
                ${level.staff_name}
                <div class="small text-muted">${level.job_role_name}</div>
            </div>`;
        });

        $('#approvalPreview').html(html);
    }

    function handleDateChange(dateText) {
        if (selectedDates.indexOf(dateText) !== -1) {
            let index = selectedDates.indexOf(dateText);
            selectedDates.splice(index, 1);
        }
        selectedDates.push(dateText);
        
    }
</script>
<script>
    function validateLeaveSchedule() {
        let isValid = true;

        // Loop through each planner row and validate fields
        $('.planner-row').each(function() {
            let date = $(this).find('.row-date').val();
            let leaveType = $(this).find('.row-leave').val();
            let reason = $(this).find('.row-reason').val();
            let fromTime = $(this).find('.time-from').val();
            let toTime = $(this).find('.time-to').val();

            // Clear previous error messages
            $(this).find('.error-message').text('');

            // Validate required fields based on planner type
            if (!date) {
                $(this).find('.row-date').siblings('.error-message').text('Date is required').show();
                isValid = false;
            }
            console.log('planner.type ',planner.type ,'=',(planner.type == 'Leave' && leaveType ==''))
            console.log(leaveType)
            if (planner.type == 'Leave' && leaveType =='') {
                $(this).find('.row-leave').siblings('.error-message').text('Leave Type is required').show();
                isValid = false;
            }
            if (!reason) {
                $(this).find('.row-reason').siblings('.error-message').text('Reason is required').show();
                isValid = false;
            }
            if (planner.type === 'Permission' && (!fromTime || !toTime)) {
                if (!fromTime) {
                    $(this).find('.time-from').siblings('.error-message').text('Time is required').show();
                }
                if (!toTime) {
                    $(this).find('.time-to').siblings('.error-message').text('Time is required').show();
                }
                isValid = false;
            }
        });

        return isValid;
    }

    // On Submit
    $('#submitStaffBtn').click(function() {
        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }
        if (!validateLeaveSchedule()) {
            toastr.warning('Please fill all required fields.');
            return;
        }

        // Disable submit button and show loader
        $('#submitStaffBtn').prop('disabled', true);
        $('#submitLoader').show();
        $('#submitText').hide();
        console.log("exurt")
        let levels = [];
        let leaveData = [];
        let staff_id = $('#staff_hidden_id').val();
        // Collect Leave/Permission details
        $('.planner-row').each(function() {
            let date = $(this).find('.row-date').val();
            let type = $(this).find('.row-leave').val();
            let reason = $(this).find('.row-reason').val();
            let fromTime = $(this).find('.time-from').val();
            let toTime = $(this).find('.time-to').val();

            leaveData.push({
                date: date,
                type: type,
                reason: reason,
                fromTime: fromTime,
                toTime: toTime
            });
        });

        // AJAX to submit the data
        $.ajax({
            url: "{{ route('add_leave_perm_request_my') }}",
            type: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                leaveData: leaveData,
                approvalLevels: levels,
                request_type: planner.type,
                staff_id: staff_id,
            },
            success: function(response) {
                // toastr.success('Leave/Permission request submitted successfully.');
                // $('#kt_modal_add_leave_request').modal('hide'); // Close the modal
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
                 location.reload();
            },
            error: function(error) {
                toastr.error('Error while submitting request.');
                console.error('Error:', error);
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
            }
        });
    });

</script>
<!-- <script>
    // $('#fromDate, #toDate').on('change', function () {
    //     let fromDate = $('#fromDate').val();
    //     let toDate = $('#toDate').val();

    //     if (fromDate && toDate) {
    //         $('#leave_dates_div').show();
    //         generateLeaveDays(fromDate, toDate);
    //     }else{
    //         $('#leave_dates_div').hide();
    //     }
    // });
    function datechange(){
        let fromDate = $('#fromDate').val();
        let toDate = $('#toDate').val();

        if (fromDate && toDate) {
            $('#leave_dates_div').show();
            generateLeaveDays(fromDate, toDate);
        }else{
            refreshLeaveSelection()
        }
    }

function generateLeaveDaysIncludeSunday(fromDate, toDate) {
    console.log(fromDate);
    const start = new Date(fromDate);
    const end = new Date(toDate);
    const dates = [];

    // Helper function to format the date as dd-MMM-yyyy
    function formatDate(date) {
        const day = date.getDate().toString().padStart(2, '0'); // Add leading zero to day
        const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month name (e.g., "Feb")
        const year = date.getFullYear(); // Get full year (e.g., 2026)

        return `${day}-${month}-${year}`;
    }

    // Loop through the date range and push formatted dates
    for (let d = start; d <= end; d.setDate(d.getDate() + 1)) {
        dates.push(formatDate(new Date(d))); // Push formatted date
    }

    renderLeaveSelection(dates);
}

function generateLeaveDays(fromDate, toDate) {
    console.log(fromDate);
    const start = new Date(fromDate);
    const end = new Date(toDate);
    const dates = [];

    // Helper function to format the date as dd-MMM-yyyy
    function formatDate(date) {
        const day = date.getDate().toString().padStart(2, '0'); // Add leading zero to day
        const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month name (e.g., "Feb")
        const year = date.getFullYear(); // Get full year (e.g., 2026)

        return `${day}-${month}-${year}`;
    }

    // Loop through the date range and push formatted dates, skipping Sundays
    for (let d = start; d <= end; d.setDate(d.getDate() + 1)) {
        if (d.getDay() !== 0) {  // Skip Sundays (0 is Sunday)
            dates.push(formatDate(new Date(d))); // Push formatted date
        }
    }

    renderLeaveSelection(dates);
}

// Render leave type options for each date
function renderLeaveSelection(dates) {
    let html = '';
    dates.forEach(date => {
        html += `
            <div class="leave-type-row col-md-3 mb-2">
                <label>${date}</label>
                <select class="form-select select3 leave-type" id="#leave_type_date_${date}">
                    <option value="Full">Full Day</option>
                    <option value="Morning Half">Morning Half</option>
                    <option value="Afternoon Half">Afternoon Half</option>
                </select>
            </div>
        `;
       
    });
    $('#leaveSelection').html(html);

    dates.forEach(date => {
        $(`#leave_type_date_${date}`).select2({
            width: '100%',
            dropdownParent: $(`#leave_type_date_${date}`).closest('.leave-type-row'),
        });
    });
    
}
   $(".common_datepicker_leave").datepicker({
        format: "dd-M-yyyy",
        autoclose: true,
        todayHighlight: true
    });
    $('.time-from-per,.time-to-per').flatpickr({enableTime:true,noCalendar:true,dateFormat:"h:i K"});
</script>
<script>
    function changeleaveDiv(){
        if(planner.type == 'Leave'){
            $('#leave_from_div').show();
            $('#leave_to_div').show();
            $('#leave_reason_div').show();
            $('#permission_date_div').hide();
            $('#permission_from_div').hide();
            $('#permission_to_div').hide();
            $('#permission_reason_div').hide();
        }else{
            $('#leave_from_div').hide();
            $('#leave_to_div').hide();
            $('#leave_reason_div').hide();
            $('#permission_date_div').show();
            $('#permission_from_div').show();
            $('#permission_to_div').show();
            $('#permission_reason_div').show();
        }
    }
</script>
 <script>
    function refreshLeaveSelection() {
        $('#fromDate').val('');
        $('#toDate').val('');
        $('#leave_dates_div').hide();
        $('#leaveSelection').empty();
    }
 </script> -->

@endsection