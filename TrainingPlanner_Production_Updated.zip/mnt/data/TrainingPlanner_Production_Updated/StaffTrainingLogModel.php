<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaffTrainingLogModel extends Model
{
    protected $table = 'egc_staff_training_logs';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'training_planner_id',
        'training_planner_code',
        'staff_id',
        'training_name',
        'training_date',
        'training_mode',
        'trainer_id',
        'trainer_name',
        'attendance_status',
        'attendee_score',
        'trainer_score',
        'assessment_status',
        'assessment_score',
        'certificate_issued',
        'completed_at',
        'remarks',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'training_planner_id' => 'integer',
        'staff_id' => 'integer',
        'training_mode' => 'integer',
        'trainer_id' => 'integer',
        'attendance_status' => 'integer',
        'attendee_score' => 'decimal:2',
        'trainer_score' => 'decimal:2',
        'assessment_status' => 'integer',
        'assessment_score' => 'decimal:2',
        'certificate_issued' => 'boolean',
        'training_date' => 'date',
        'completed_at' => 'datetime',
    ];

    public function training()
    {
        return $this->belongsTo(TrainingPlannerModel::class, 'training_planner_id', 'sno');
    }

    public function staff()
    {
        return $this->belongsTo(StaffModel::class, 'staff_id', 'sno');
    }
}
