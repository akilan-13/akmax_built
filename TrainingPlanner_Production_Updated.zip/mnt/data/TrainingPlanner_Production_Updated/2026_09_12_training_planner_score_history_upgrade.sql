START TRANSACTION;

-- Training-level score configuration / outcome fields.
SET @col_exists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_training_planner' AND COLUMN_NAME = 'trainer_score');
SET @sql := IF(@col_exists = 0, 'ALTER TABLE egc_training_planner ADD COLUMN trainer_score DECIMAL(5,2) NULL AFTER assessment_pass_percentage', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_training_planner' AND COLUMN_NAME = 'attendee_score_default');
SET @sql := IF(@col_exists = 0, 'ALTER TABLE egc_training_planner ADD COLUMN attendee_score_default DECIMAL(5,2) NULL AFTER trainer_score', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Per-attendee score/remarks. Existing assessment_score remains for backward compatibility.
SET @col_exists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_training_planner_attendees' AND COLUMN_NAME = 'attendee_score');
SET @sql := IF(@col_exists = 0, 'ALTER TABLE egc_training_planner_attendees ADD COLUMN attendee_score DECIMAL(5,2) NULL AFTER assessment_score', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_training_planner_attendees' AND COLUMN_NAME = 'remarks');
SET @sql := IF(@col_exists = 0, 'ALTER TABLE egc_training_planner_attendees ADD COLUMN remarks VARCHAR(1000) NULL AFTER attendee_score', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Staff-centric training history used by employee view/update screens.
CREATE TABLE IF NOT EXISTS egc_staff_training_logs (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    training_planner_id BIGINT UNSIGNED NOT NULL,
    training_planner_code VARCHAR(100) NULL,
    staff_id BIGINT UNSIGNED NOT NULL,
    training_name VARCHAR(255) NOT NULL,
    training_date DATE NULL,
    training_mode TINYINT NULL,
    trainer_id BIGINT UNSIGNED NULL,
    trainer_name VARCHAR(255) NULL,
    attendance_status TINYINT NULL COMMENT '1=Present, 0=Absent',
    attendee_score DECIMAL(5,2) NULL,
    trainer_score DECIMAL(5,2) NULL,
    assessment_status TINYINT NULL COMMENT '1=Passed, 0=Failed',
    assessment_score DECIMAL(5,2) NULL,
    certificate_issued TINYINT(1) NOT NULL DEFAULT 0,
    completed_at DATETIME NULL,
    remarks VARCHAR(1000) NULL,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_staff_training_log (training_planner_id, staff_id),
    KEY idx_staff_training_log_staff (staff_id),
    KEY idx_staff_training_log_date (training_date),
    KEY idx_staff_training_log_trainer (trainer_id),
    KEY idx_staff_training_log_completed_at (completed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Backfill attendee_score from the existing assessment_score where possible.
UPDATE egc_training_planner_attendees
SET attendee_score = assessment_score
WHERE attendee_score IS NULL
  AND assessment_score IS NOT NULL;

-- Backfill staff-centric history for already completed training planners.
INSERT INTO egc_staff_training_logs (
    training_planner_id, training_planner_code, staff_id, training_name, training_date,
    training_mode, trainer_id, trainer_name, attendance_status, attendee_score, trainer_score,
    assessment_status, assessment_score, certificate_issued, completed_at, remarks,
    created_by, updated_by
)
SELECT
    tp.sno,
    tp.training_planner_id,
    a.staff_id,
    tp.training_planner_name,
    COALESCE(tp.schedule_date, tp.schedule_from_date),
    tp.training_mode,
    NULLIF(tp.trainer, 0),
    tp.trainer_name,
    a.attendance_status,
    a.attendee_score,
    tp.trainer_score,
    a.assessment_status,
    a.assessment_score,
    COALESCE(a.certificate_issued, 0),
    COALESCE(tp.completed_at, a.attendance_marked_at),
    a.remarks,
    tp.created_by,
    tp.updated_by
FROM egc_training_planner tp
INNER JOIN egc_training_planner_attendees a
    ON a.training_planner_id = tp.sno
LEFT JOIN egc_staff_training_logs l
    ON l.training_planner_id = tp.sno
   AND l.staff_id = a.staff_id
WHERE tp.status != 2
  AND tp.planner_status = 'completed'
  AND l.sno IS NULL;

COMMIT;
