# Training Planner — Production Upgrade

## Scope
This upgrade is isolated to the Training Planner module.

### Included changes
- Attendees are optional when creating/editing a training planner.
- Attendees can be assigned later through Manage Attendees.
- Historical/past training dates are allowed for old-entry creation and editing.
- Time Flatpickr uses static positioning to avoid jumping/repositioning inside the scrolling modal.
- Company → Entity → Branch selection preserves still-valid selections when the company scope changes.
- Attendance & Scores is a separate action from final Complete Training.
- Attendance & Scores is available from the training View modal.
- Trainer Score and Default Attendee Score are available in Add/Edit.
- Completion allows per-attendee scores and persists them separately from assessment score.
- Completion creates/updates staff-centric training history in `egc_staff_training_logs`.
- Existing completed planner/attendee records are backfilled into the new staff training history table.
- Staff history can be opened from the attendee list in the View modal.

## Files

- `app/Http/Controllers/hr_management/hr_training/ManageTraining.php`
- `app/Models/TrainingPlannerModel.php`
- `app/Models/TrainingPlannerAttendeeModel.php`
- `app/Models/StaffTrainingLogModel.php`
- `resources/views/content/hr_management/hr_training/manage_training/list.blade.php`
- `database/sql/2026_09_12_training_planner_score_history_upgrade.sql`
- `routes/training_planner_routes.php`

## Deployment

1. Back up the production database.
2. Run `database/sql/2026_09_12_training_planner_score_history_upgrade.sql` once.
3. Replace the existing Training Planner controller, models, and Blade using the same application paths.
4. Merge `routes/training_planner_routes.php` into the existing authenticated Training Planner route section. Do not replace unrelated routes.
5. Run:

```bash
php artisan optimize:clear
php artisan route:clear
php artisan view:clear
```

6. Smoke-test:
   - Create training without attendees.
   - Create a historical training date.
   - Open each time picker inside the modal.
   - Change Company and verify valid Entity/Branch selections remain.
   - Add attendees later.
   - Save Attendance & Scores without completing.
   - Complete a past training and verify attendee score + trainer score.
   - Open View → attendee History and verify staff training logs.

## Compatibility
The existing `assessment_score` column remains untouched for backward compatibility. A new `attendee_score` field is stored independently so general attendee scoring does not depend on whether assessment is enabled.

The staff history table is intentionally new so no unrelated HR table is modified.
