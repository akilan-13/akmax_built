<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingPlannerModel extends Model
{
    use HasFactory;

    protected $table = 'egc_training_planner';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'training_planner_id',
        'company_ids',
        'entity_ids',
        'branch_ids',
        'training_planner_name',
        'training_mode',
        'trainer',
        'trainer_name',
        'training_duration',
        'schedule_date',
        'schedule_time',
        'schedule_type',
        'schedule_sessions',
        'schedule_from_date',
        'schedule_to_date',
        'schedule_from_time',
        'schedule_to_time',
        'training_desc',
        'all_check',
        'staff_check',
        'attendance_status',
        'certificate_available',
        'assessment_required',
        'certificate_name',
        'assessment_pass_percentage',
        'trainer_score',
        'attendee_score_default',
        'planner_status',
        'cancelled_reason',
        'reschedule_reason',
        'completed_at',
        'cancelled_at',
        'created_by',
        'updated_by',
        'status',
    ];

    protected $casts = [
        'company_ids' => 'array',
        'entity_ids' => 'array',
        'branch_ids' => 'array',
        'schedule_sessions' => 'array',
        'staff_check' => 'array',
        'attendance_status' => 'array',
        'certificate_available' => 'boolean',
        'assessment_required' => 'boolean',
        'training_duration' => 'decimal:2',
        'trainer_score' => 'decimal:2',
        'attendee_score_default' => 'decimal:2',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function attendees()
    {
        return $this->hasMany(TrainingPlannerAttendeeModel::class, 'training_planner_id', 'sno');
    }
}
