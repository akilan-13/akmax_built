<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainingPlannerAttendeeModel extends Model
{
    protected $table = 'egc_training_planner_attendees';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'training_planner_id',
        'staff_id',
        'attendance_status',
        'attendance_marked_at',
        'certificate_issued',
        'assessment_status',
        'assessment_score',
        'attendee_score',
        'remarks',
        'assessment_passed_at',
    ];

    protected $casts = [
        'attendance_marked_at' => 'datetime',
        'certificate_issued' => 'boolean',
        'assessment_score' => 'decimal:2',
        'attendee_score' => 'decimal:2',
        'assessment_passed_at' => 'datetime',
    ];

    public function training()
    {
        return $this->belongsTo(TrainingPlannerModel::class, 'training_planner_id', 'sno');
    }

    public function staff()
    {
        return $this->belongsTo(StaffModel::class, 'staff_id', 'sno');
    }
}
