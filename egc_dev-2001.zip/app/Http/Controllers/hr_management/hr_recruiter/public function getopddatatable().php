public function getopddatatable()
    { 
        $dt_response = $this->patient_model->getAllopdRecord();       
        $fields      = $this->customfield_model->get_custom_fields('opd', 1);
        $dt_response = json_decode($dt_response);       
        $dt_data     = array();
        if (!empty($dt_response->data)) {
            foreach ($dt_response->data as $key => $value) {

                if($value->is_antenatal==1){
                    $is_antenatal = $this->lang->line('yes');
                }else{
                    $is_antenatal = $this->lang->line('no');
                }
                $row = array();
                //====================================
                $action = "<span class=''>";
                $action .= "<a href=" . base_url() . 'admin/patient/profile/' . $value->pid . " class='btn btn-default btn-xs'  data-toggle='tooltip' title='" . $this->lang->line('show') . "'><i class='fa fa-info-circle' aria-hidden='true'></i></a>";
                $action .= "</span>";
                $first_action = "<a href=" . base_url() . 'admin/patient/profile/' . $value->pid . ">";
                if($value->gender){
                    $gender = $this->lang->line(strtolower($value->gender));
                }else{
                    $gender = '';
                }
                
                //==============================
                $row[] = $first_action . $value->patient_name . "</a>" ;
                $row[] = $value->patientid ? $value->patientid: '-';
                $row[] = $value->guardian_name ? $value->guardian_name: '-';
                $row[] = $gender ? $gender: '-';
                $row[] = $value->mobileno ? $value->mobileno: '-';
                $row[] = composeStaffNameByString($value->generated_byname, $value->generated_bysurname, $value->generated_byemployee_id);
                $row[] = composeStaffNameByString($value->name, $value->surname, $value->employee_id);
                $row[] = $this->customlib->YYYYMMDDHisTodateFormat($value->last_visit, $this->time_format);                
				if ($this->rbac->hasPrivilege('opd_antenatal', 'can_view')) { 
                $row[]  = $is_antenatal;
				}
                $row[]     = $value->total_visit ;
                $row[]     = $action;
                $dt_data[] = $row;
            }
        }
        $json_data = array(
            "draw"            => intval($dt_response->draw),
            "recordsTotal"    => intval($dt_response->recordsTotal),
            "recordsFiltered" => intval($dt_response->recordsFiltered),
            "data"            => $dt_data,
        );
        echo json_encode($json_data);
    }