<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobRoleModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\ApplicantModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\JobQRScannerModel;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\JobRequestModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\InterviewScheduleModel;
use App\Models\InteviewCategoryModel;
use App\Models\InterviewQuestionModel;
use App\Models\InterviewSessionModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewCandidateModel;
use App\Models\InterviewAnswerModel;
use App\Models\InterviewOtpModel;
use App\Models\FeedbackQuestionModel;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use Google\Client;
use App\Services\GoogleDriveService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class JobController extends Controller
{

    protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
     $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', '>', 1);
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        if($company_fill != ''){
          if($company_fill == 'egc'){
             $staffData->where('egc_staff.company_type',1);
          }else{
            $staffData->where('egc_staff.company_id', 'LIKE', $company_fill);
          }
            
        }

        if ($entity_fill) {
          $staffData->where('egc_staff.entity_id', $entity_fill);
        }

        
        if ($department_fill) {
            $staffData->where('egc_staff.department_id', $department_fill);
        }

        if ($division_fill) {
            $staffData->where('egc_staff.division_id', $division_fill);
        }

        if ($job_role_fill) {
          $staffData->where('egc_staff.job_role_id', $job_role_fill);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
            }
          }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);
        
        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
            
           $educations = DB::table('egc_staff_education_info')
            ->select('egc_education.education')
            ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
            ->where('egc_staff_education_info.staff_id', $staff->sno) 
            ->where('egc_staff_education_info.status', 0)
            ->pluck('egc_education.education');
            $staff->education=$educations;
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staffData->currentPage(),
                'last_page' => $staffData->lastPage(),
                'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.manage_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }

 private function getValidSession(string $token)
  {
      return InterviewSessionModel::where('session_token', $token)
          ->where('status', 1)
          ->firstOrFail();
  }

 
 public function jobWelcomeScreen($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
     $qrcode=$request->qr;
     $decodeQr = $qrcode ? base64_decode($qrcode) : NULL;
    // return $this->getAIFromHuggingFace("are u there");
      if($decodeQr == 'EGCJOBQR'){
        $scanTracked = session('job_scan_tracked_' . $decodeId);
        if (!$scanTracked) {
            // Save the scan details if not tracked already
            $this->saveScanDetails($decodeId, $request);
    
            // Set a session flag to indicate that the scan has been tracked for this event
            session(['job_scan_tracked_' . $decodeId => true]);
        }
      }

     $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
     ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
     ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$decodeId)->first();

    return view('content.hr_management.hr_recruiter.job_application.welcome_screen',compact('jobRequest','decodeQr'));
  }
  
  public function jobApplication($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
     $qrcode=$request->qr;
     $decodeQr = base64_decode($qrcode);

      $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
     ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
     ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$decodeId)->first();
    
    return view('content.hr_management.hr_recruiter.job_application.job_application_form',compact('jobRequest','source_list'));
  }


  public function submitJobApplication(Request $request)
    {
       $request->validate([
            'fullName' => 'required',
            'mobile' => 'required',
            'email' => 'required',
            'gender'   => 'required|integer',
            'resume' => 'nullable|max:51200'
        ]);
      
        $resumeFile = null;
        $resumeUrl = null;
        $fullName        = $request->fullName;
        $mobile_no       = $request->mobile;
        $email_id        = $request->email;
        $gender          = $request->gender;
        $job_request_id  = $request->job_request_id;
        $job_role_id  = $request->job_role_id;
        $marital_status  = $request->marital_status;
        $qualification   = $request->qualification;
        $major           = $request->major;
        $exper_type      = $request->exper_type;
        $exper_count     = $request->exper_count ?? 0;
        $source          = $request->source;
        $description     = $request->about;
         $ipAddress = $request->ip();
        $resumeText = null;
        // ✅ Resume Upload
        $drive_data=[];

        //    return $resumeText;

        // ✅ Candidate check
        $candidate = InterviewCandidateModel::where('mobile', $mobile_no)->first();

         // Check if already applied (active applications only)
        $alreadyApplied = ApplicantModel::where('mobile', $mobile_no)
            ->where('job_role_id', $job_request_id)
            ->where('status', '!=', 2)
            ->exists();

        if ($alreadyApplied) {
            return response()->json([
                'status'  => 409,
                'message' => 'You have already applied for this job using this mobile number.',
            ], 409);
        }

        if ($candidate) {
            $candidate_id = $candidate->sno;
        } else {

            $newCandidate = InterviewCandidateModel::create([
                'full_name' => $fullName,
                'mobile'    => $mobile_no,
                'email'     => $email_id,
            ]);

            

            $candidate_id = $newCandidate->sno;
        }

        // ✅ Applicant ID generation
        $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
        $year = date('y');

        if (!$lastApplicant) {
            $applicant_id = "EGCJA-0001-{$year}";
        } else {
            preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
            $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
            $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
        }

        if ($request->hasFile('resume')) {

            $file = $request->file('resume');
            $extension = $file->getClientOriginalExtension();

            $folderPath = public_path('job_applications/resume_files/');

            if (!File::exists($folderPath)) {
                File::makeDirectory($folderPath, 0777, true);
            }

            // Unique filename
            $resumeFile = $applicant_id . '.' . $extension;

            $file->move($folderPath, $resumeFile);
            $filePath = $folderPath . $resumeFile;
            $resumeText = $this->extractResumeText($filePath);
            
          
            if (file_exists($filePath)) {
                $drive_data = $this->UploadFileInDrive($resumeFile);
            }
        }
        // for only in drive
        // if ($request->hasFile('resume')) {

        //     $file = $request->file('resume');

        //     $extension = $file->getClientOriginalExtension();
        //     $resumeFileName = $applicant_id . '_' . time() . '.' . $extension;

        //     // Extract text directly from temp file
        //     $resumeText = $this->extractResumeText($file->getRealPath());

        //     // Upload with custom filename
        //     $driveData = $this->uploadFileInDrive($file, $resumeFileName);
        // }
        // return $drive_data;

        // ✅ Save Applicant
        $applicant=ApplicantModel::create([
            'applicant_id'      => $applicant_id,
            'candidate_id'      => $candidate_id,
            'applicant_name'    => $fullName,
            'job_request_id'       => $job_request_id,
            'job_role_id'       => $job_role_id,
            'mobile'            => $mobile_no,
            'email'             => $email_id,
            'attachment'        => $resumeFile,
            'ipaddress'         => $ipAddress ?? null,
            'resume_text'       => $resumeText,
            'gender'            => $gender,
            'marital_status_id' => $marital_status,
            'qualification_id'  => $qualification,
            'major'             => $major,
            'experience_id'     => $exper_type,
            'experience_count'  => $exper_count,
            'source_id'         => $source,
            'description'       => $description,
            'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
        ]);

        if($applicant){
            $qualificationName = "Not provided"; 
            $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

            $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
                ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
                ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$job_request_id)->first();

             $promptTemplate = "
                You are an AI HR screening assistant.
                Your task is to evaluate how well a candidate matches a job requirement.
                The resume content is PRIMARY source of truth.
                Form input data is SECONDARY.

                Return ONLY valid JSON as below:

                {
                \"match_status\": 0, 
                \"match_score\": 0, 
                \"matched_skills\": [], 
                \"missing_skills\": [], 
                \"experience_analysis\": \"short sentence\", 
                \"education_analysis\": \"short sentence\", 
                \"overall_summary\": \"1-2 sentence professional HR summary\"
                }

                STRICT RULES:
                - Resume text has higher priority than form data.
                - If resume is empty or unreadable, base decision on form data.
                - Do NOT overrate candidates.
                - No markdown or extra text.
                - Output must be valid parsable JSON.

                JOB DETAILS:
                Role: {{JOB_ROLE_NAME}}
                Description: {{JOB_DESCRIPTION}}
                Required Experience: {{REQUIRED_EXPERIENCE}}
                Required Skills: {{REQUIRED_SKILLS}}

                CANDIDATE DATA:
                Name: {{FULL_NAME}}
                Qualification: {{QUALIFICATION}}
                Major: {{MAJOR}}
                Experience Type: {{EXPERIENCE_TYPE}}
                Experience Count: {{EXPERIENCE_COUNT}}
                Resume Content: {{RESUME_TEXT}}
                ";

                    $prompt = str_replace(
                        [
                            '{{JOB_ROLE_NAME}}',
                            '{{JOB_DESCRIPTION}}',
                            '{{REQUIRED_EXPERIENCE}}',
                            '{{REQUIRED_SKILLS}}',
                            '{{FULL_NAME}}',
                            '{{QUALIFICATION}}',
                            '{{MAJOR}}',
                            '{{EXPERIENCE_TYPE}}',
                            '{{EXPERIENCE_COUNT}}',
                            '{{RESUME_TEXT}}',
                        ],
                        [
                            $jobRequest->job_role_name,
                            $jobRequest->job_description,
                            $jobRequest->experience,
                            $jobRequest->required_skills,
                            $applicant->applicant_name,
                            $qualificationName,
                            $applicant->major,
                            $experTypeText,
                            $applicant->experience_count,
                            $applicant->resume_text ?? 'Resume not available',
                        ],
                        $promptTemplate
                    );

            $aiData = $this->getAIFromHuggingFace($prompt);
            if (empty($aiData)) {
                $aiData = $this->getAiFromOpenRouter($prompt);
            }
            if($aiData){
                ApplicantModel::where('sno', $applicant->sno)->update([
                    'match_status' => $aiData['match_status'] ?? 0,
                    'match_score'  => $aiData['match_score'] ?? 0,
                    'ai_response'  => $aiData ?? null,
                    'ai_summary'   => $aiData['overall_summary'] ?? null,
                ]);
            }
           
            
            
        }

        
        // ✅ Redirect URL
        $thankScreenUrl = url('/application_submitted/' . base64_encode($job_request_id));

        return response()->json([
            'status'         => 200,
            'message'        => 'Job application submitted successfully!',
            'redirect'       => $thankScreenUrl,
            'application_id' => base64_encode($applicant->sno),
        ]);
    }

  public function applicationSubmitted($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
    //  $decodeId = $id;
      $applicant = ApplicantModel::orderBy('sno', 'desc')->where('sno', $decodeId)->first();
    //   return $applicant;
      $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$applicant->job_request_id)->first();
     

    return view('content.hr_management.hr_recruiter.job_application.form_submit_thanku',compact('jobRequest','applicant'));
  }

  public function generateQrJob($id, Request $request)
  {
      // Encode sno in base64 (shorter than Crypt)
      $encodedId = base64_encode($id);
      $encodedcode = base64_encode('EGCJOBQR'.$id);
  
      
      $qrContent = url("/apply_job/{$encodedId}?qr={$encodedcode}");
      // 'https://erp.elysium.community/job_application_qr';
  
      // Generate QR as base64 image
      $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=300x300";
      $qrImageData = @file_get_contents($qrServerUrl);
      $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
      // Save scan details
      
  
      return response()->json([
          'status'    => $qrBase64 ? 200 : 500,
          'qr_base64' => $qrBase64,
          'link'      => $qrContent,
      ]);
  }
    
  private function saveScanDetails($job_request_id,Request $request)
  {
      // Get the user's IP address
      $ipAddress = $request->ip();
  
      // Get latitude and longitude if provided by frontend (JavaScript geolocation)
      $latitude = $request->input('latitude', null);
      $longitude = $request->input('longitude', null);
  
      // Get area from IP address (you can use any IP geolocation API)
      // $area = $this->getAreaByIp($ipAddress);
      $area="";
      // Get device information (User-Agent string)
      $deviceInfo = $request->header('User-Agent');
      $isMobile = preg_match('/Mobile|Android|iP(hone|od|ad)|IEMobile|BlackBerry|Opera Mini/i', $deviceInfo);
              
      $deviceType = $isMobile ? 'Mobile' : 'Desktop';
  
      // Insert the scan data into the database
      JobQRScannerModel::create([
          'job_request_id'      => $job_request_id,
          'ipaddress' => $ipAddress,
          'latitude'   => $latitude,
          'longitude'  => $longitude,
          'area'       => $area,
          'device'=> $deviceType,
      ]);
  }

  
    public function startInterview($encodedId)
  {

        $decoded = base64_decode($encodedId, true);
       
        if (!$decoded) {
            abort(404, 'Interview Not Found');
        }
        // return $decoded;
        $exp = explode('~', $decoded);
        if (count($exp) !== 3 || empty(trim($exp[0])) || empty(trim($exp[1]))) {
            abort(404, 'Interview Not Found');
        }

      $job_request_id  = trim($exp[0]);
      $scheduleId = trim($exp[1]);
      $category_id = trim($exp[2]);

      $schedule = InterviewScheduleModel::where('egc_interview_schedule.sno', $scheduleId)
          ->select('egc_interview_schedule.share_code',
                   'egc_interview_schedule.sno as schedule_id',
                   'egc_job_request.*',
                   'egc_interview_schedule_stage.sno as schedule_stage_id',
                   'egc_interview_schedule_stage.duration_value',
                   'egc_interview_schedule_stage.duration_unit',
                   'egc_interview_schedule_stage.status as stage_status',
                   'egc_interview_category.interview_category_name',
                   'egc_interview_mode.interview_mode_name',
                   'egc_job_role.job_position_name as job_role_name',
                   'egc_entity.entity_name',
                    'egc_entity.entity_short_name',
                    'egc_entity.entity_base_color',
                    'egc_entity.entity_logo',
                    'egc_entity.company_id',
          )
          ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
          ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
          ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
          ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
          ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
          ->join('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
          ->where('egc_interview_schedule.status', 0)
          ->where('egc_job_request.status', '!=',2)
          ->where('egc_interview_schedule_stage.sno',$category_id)
          ->first();
       
          if(!$schedule){
            abort(404);
          }
          session([
            'interview_schedule_id' => $schedule->schedule_id ?? 0,
            'interview_schedule_stage_id' => $schedule->schedule_stage_id ?? 0,
          ]);
    
      return view('content.hr_management.hr_recruiter.job_application.interview_login', compact('encodedId','scheduleId','schedule'));
  }


  public function sendOtp(Request $request)
  {
      $request->validate([
          'mobile'    => 'required|regex:/^[6-9]\d{9}$/',
        //   'email'     => 'required|email'
      ]);

      DB::beginTransaction();
      
      // try {
          // create or get candidate
          $candidate = InterviewCandidateModel::where('mobile',$request->mobile)->first();

         
            
        //   $candidate = InterviewCandidateModel::firstOrCreate(
        //       ['mobile' => $request->mobile],
        //       [
        //           'full_name' => $request->full_name,
        //           'email'     => $request->email,
        //           'status'    => 0
        //       ]
        //   );
        if(!$candidate){
            return response()->json([
                  'message' => 'The mobile number is not registered'
              ], 400);
        }

        $Applicant = ApplicantModel::where('candidate_id',$candidate->sno)->where('job_request_id',$request->job_request_id)->first();

        if (!$Applicant) {
            return response()->json([
                'message' => 'This mobile number is not registered For this job.'
            ], 400);
        }

          // email mismatch safety
        //   if ($Applicant->email !== $request->email) { 
        //       return response()->json([
        //           'message' => 'Email does not match registered mobile number You are not eligible for this job request.'
        //       ], 400);
        //   }

          // invalidate old OTPs
          InterviewOtpModel::where('applicant_id', $Applicant->sno)
              ->update(['is_used' => 1]);

          $otp = rand(100000, 999999);
          

          InterviewOtpModel::create([
              'applicant_id' => $Applicant->sno,
              'interview_schedule_id' => $request->interview_schedule_id,
              'job_request_id' => $request->job_request_id,
              'otp'          => $otp,
              'expires_at'   => now()->addHours(24),
              'is_used'      => 0
          ]);

          // SMS / Email integration
          // sendSms($candidate->mobile, $otp);

              if ($Applicant->email) {
                $emailTemplate_id =2; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;

                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }
        
                $dynamicSubject = str_replace('#otp', $otp ?? '000000', $emailTemplate->email_name);
        
                $content = str_replace('#employee_name', $Applicant->applicant_name ?? 'Candidate', $content);
                $content = str_replace('#otp', $otp ?? '000000', $content);
                $content = str_replace('#hr_contact',  $cre_mobile ?? '8220011465', $content);
                $content = str_replace('#hr_email',  $cre_mobile ?? 'email_id', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $branchNo,
                      'branchemail' => $branchemail, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $branchData->cre_mobile ?? '8220011465',
                  ];
        
                $to_address = $Applicant->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups ';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));
              }

          DB::commit();

          return response()->json([
              'status' => true,
              'message' => 'OTP sent successfully'
          ]);
  }

public function verifyOtp(Request $request)
{
    $request->validate([
        'mobile' => 'required',
        'otp'    => 'required',
        'schedule_stage_id' => 'required|integer'
    ]);

    
    $candidate = InterviewCandidateModel::where('mobile',$request->mobile)->first();

    if (!$candidate) {
        return response()->json(['message' => 'Candidate not found'], 400);
    }

    $Applicant = ApplicantModel::where('candidate_id',$candidate->sno)->where('job_request_id',$request->job_request_id)->first();

     if (!$Applicant) {
        return response()->json(['message' => 'You are not eligible for this job request.'], 400);
    }

    $otpRow = InterviewOtpModel::where('applicant_id', $Applicant->sno)
        ->where('otp', $request->otp)
        ->where('is_used', 0)
        ->where('expires_at', '>', now())
        ->first();

    if (!$otpRow) {
        return response()->json(['message' => 'Invalid or expired OTP'], 400);
    }

        $interviewStage = InterviewScheduleStageModel::where('sno', $request->schedule_stage_id)
            ->whereJsonContains('shortlist_applicant_ids', (string)$Applicant->sno)
            ->first();
        //  return response()->json(['data' => $interviewStage], 400);
         $encrypt_applicant_id = base64_encode($Applicant->sno);
        $otpRow->update(['is_used' => 1]);
        if (!$interviewStage) {
            return response()->json([
                'status' => true,
                'message' => 'You are not eligible for this job request.',
                'redirect' => url('/interview_not_eligible/' . $encrypt_applicant_id),
            ]);
        }

        

        $session = InterviewSessionModel::updateOrCreate(
            [
                'interview_schedule_id' => session('interview_schedule_id'),
                'interview_schedule_stage_id' => session('interview_schedule_stage_id'),
                'applicant_id' => $Applicant->sno,
            ],
            [
                'session_token' => \Str::uuid(),
                'status' => 1,
            ]
        );

        if ($session->wasRecentlyCreated) {
            $session->started_at = now();
            $session->save();
        }

    return response()->json([
        'status' => true,
        'redirect' => url('/interview/' . $session->session_token)
    ]);
}

public function runInterview($token)
{
    //  return $token;
    $session = InterviewSessionModel::where('egc_interview_session.session_token', $token)
        ->join('egc_interview_schedule', 'egc_interview_schedule.sno', 'egc_interview_session.interview_schedule_id')
        ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.sno', 'egc_interview_session.interview_schedule_stage_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
        ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
        ->select( 
                'egc_interview_schedule_stage.*',
                'egc_interview_category.interview_category_name',
                'egc_interview_mode.interview_mode_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_interview_session.session_token',
                'egc_interview_session.status as session_status',
        ) 
        // ->where('egc_interview_session.status', 1)
        ->first();
        if(!$session){
            abort(404,'Intreview Not Found');
        }
        // return $session;
          session([
            'session_token' => $token ?? 0,
          ]);
      if($session->session_status == 2){
         abort(404,'You Already Completed');
      }
    return view('content.hr_management.hr_recruiter.job_application.interview_page', compact('session'));
}

public function fetchNextQuestion(Request $request)
{
    $session = InterviewSessionModel::where('egc_interview_session.session_token', $request->session_token)
        ->select('egc_interview_session.*','egc_interview_schedule_stage.interview_category_id')
        ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.sno', 'egc_interview_session.interview_schedule_stage_id')
        ->join('egc_interview_schedule', 'egc_interview_schedule.sno', 'egc_interview_session.interview_schedule_id')
        ->join('egc_interview_category', 'egc_interview_category.sno', 'egc_interview_schedule_stage.interview_category_id')
        ->where('egc_interview_session.status', 1)
        ->first();

    // total questions for progress bar
    $totalQuestions = InterviewScheduleQuestionModel::where(
        'interview_schedule_stage_id',
        $session->interview_schedule_stage_id
    )->where('status', 0)->count();

    $nextQuestion = InterviewScheduleQuestionModel::query()
        ->join('egc_interview_question as q', 'q.sno', '=', 'egc_interview_schedule_questions.interview_question_id')
        ->leftJoin('egc_interview_answers as a', function ($join) use ($session) {
            $join->on('a.interview_question_id', '=', 'egc_interview_schedule_questions.interview_question_id')
                 ->where('a.interview_session_id', '=', $session->sno);
        })
        ->where('egc_interview_schedule_questions.interview_schedule_stage_id', $session->interview_schedule_stage_id)
        ->whereNull('a.sno') // unanswered only
        ->where('egc_interview_schedule_questions.status', 0)
        ->orderBy('egc_interview_schedule_questions.sno')
        ->select([
            'q.sno as question_id',
            'q.field_name',
            'q.field_value',
            'egc_interview_schedule_questions.thinking_time',
            'egc_interview_schedule_questions.allowed_time',
            'egc_interview_schedule_questions.retakes',
        ])
        ->first();
          // $session = $this->getValidSession($request->session_token);
  // return $$nextQuestion;
    if (!$nextQuestion) {
        $session->update([
            'status' => 2, // completed
            'completed_at' => now()
        ]);

        $already = DB::table('egc_applicant_feedback_answer')
            ->where('applicant_id', $session->applicant_id)
            ->where('interview_schedule_stage_id', $session->interview_schedule_stage_id)
            ->exists();
        $questionExist = FeedbackQuestionModel::where('egc_feedback_question.status', 0)
            ->where('egc_feedback_question.interview_category_id', $session->interview_category_id)
            ->where('egc_feedback_question.feedback_section_id', 1)
            ->exists();
        if($already){
            $url=url('/interview/thank-you/'.$session->session_token);
        }elseif($questionExist){
            $url=url('/interview_feedback/'.$session->session_token);
        }else{
             $url=url('/interview/thank-you/'.$session->session_token);
        }
       

        return response()->json([
            'completed' => true,
            'redirect' => $url,
        ]);
    }


    // answered count for progress
    $answered = InterviewAnswerModel::where('interview_session_id', $session->sno)->count();

    return response()->json([
        'completed' => false,
        'question' => $nextQuestion,
        'progress' => [
            'current' => $answered + 1,
            'total'   => $totalQuestions
        ]
    ]);
}

public function logTabSwitch(Request $request)
{
  $session = $this->getValidSession($request->session_token);

    InterviewSessionModel::where('session_token', $request->session_token)
        ->increment('tab_switch_count');
}


public function saveAnswer(Request $request)
{
    $request->validate([
        'session_token' => 'required',
        'question_id'   => 'required|integer',
        // 'answer_type'   => 'required|in:text,audio,video',
        'answer_file' => 'nullable|max:51200'
    ]);

    // $session = InterviewSessionModel::where('session_token', $request->session_token)
    //     ->where('status', 1)
    //     ->firstOrFail();
    $session = $this->getValidSession($request->session_token);

    $filePath = null;

    if ($request->hasFile('answer_file')) {

        $file = $request->file('answer_file');

        // 1️⃣ Detect MIME TYPE (CRITICAL)
        $mime = $file->getMimeType();

        // 2️⃣ Map MIME → EXTENSION (DO NOT SKIP)
        $extensionMap = [
            'video/webm'  => 'webm',
            'video/mp4'   => 'mp4',
            'audio/webm'  => 'webm',
            'audio/wav'   => 'wav',
            'audio/mpeg'  => 'mp3',
        ];

        if (!isset($extensionMap[$mime])) {
            return response()->json([
                'message' => 'Unsupported media format: ' . $mime
            ], 422);
        }

        $extension = $extensionMap[$mime];

        // 3️⃣ Choose folder
        $folder = str_starts_with($mime, 'video')
            ? 'interview_file/video'
            : 'interview_file/audio';

        // 4️⃣ Ensure directory exists
        $destinationPath = public_path($folder);
        if (!is_dir($destinationPath)) {
            mkdir($destinationPath, 0775, true);
        }

        // 5️⃣ Generate SAFE filename (NO trailing dot)
        $filename = uniqid('ans_') . '.' . $extension;

        // 6️⃣ MOVE FILE (WINDOWS SAFE)
        $file->move($destinationPath, $filename);

        // 7️⃣ Save relative path
        $filePath = $folder . '/' . $filename;
    }

      $allowedRetakes = InterviewScheduleQuestionModel::where(
          'interview_question_id',
          $request->question_id
      )->value('retakes');

      $attempts = InterviewAnswerModel::where([
          'interview_session_id' => $session->sno,
          'interview_question_id' => $request->question_id
      ])->count();

      // if ($attempts >= $allowedRetakes + 1) {
      //     return response()->json([
      //         'message' => 'Retake limit exceeded'
      //     ], 403);
      // }
    $answer_type=$request->answer_type =='assesment' ? 'text': $request->answer_type;
    InterviewAnswerModel::create([
        'interview_session_id'       => $session->sno,
        'interview_schedule_stage_id'=> $session->interview_schedule_stage_id,
        'interview_question_id'      => $request->question_id,
        'answer_type'                => $answer_type,
        'answer_text'                => $request->answer_text,
        'answer_file'                => $filePath,
        'time_taken'                 => $request->time_taken ?? 0,
        'retake_count' => $request->retake_count ?? 0,
        'status'                     => 1,
        'created_at'                 => now(),
        'created_by'                 => $session->applicant_id
    ]);

    return response()->json(['status' => true]);
}

// public function saveAnswer(Request $request)
// {
//     $request->validate([
//         'session_token' => 'required',
//         'question_id'   => 'required|integer',
//         'answer_type'   => 'required',
//         'answer_text'   => 'nullable|string',
//         'answer_file'   => 'nullable|file|max:51200|mimetypes:video/mp4,video/webm,audio/webm,audio/wav,audio/mpeg',
//         'time_taken'    => 'nullable|integer',
//         'retake_count'  => 'nullable|integer'
//     ]);

//     /** ✅ Validate session */
//     $session = $this->getValidSession($request->session_token);

//     $filePath = null;

//     if ($request->hasFile('answer_file')) {

//         $file = $request->file('answer_file');
//         $mime = $file->getMimeType();

//         /** ✅ MIME → extension */
//         $extensionMap = [
//             'video/webm'  => 'webm',
//             'video/mp4'   => 'mp4',
//             'audio/webm'  => 'webm',
//             'audio/wav'   => 'wav',
//             'audio/mpeg'  => 'mp3',
//         ];

//         if (!isset($extensionMap[$mime])) {
//             return response()->json([
//                 'message' => 'Unsupported media format: ' . $mime
//             ], 422);
//         }

//         /** ✅ Folder decision */
//         $folder = str_starts_with($mime, 'video') ? 'video' : 'audio';

//         /** ✅ Safe filename */
//         $filename = uniqid('ans_', true) . '.' . $extensionMap[$mime];

//         /** ✅ Store using Laravel Storage */
//         $filePath = $file->storeAs(
//             $folder,
//             $filename,
//             'interview'
//         );
//     }

//     /** ✅ Retake logic */
//     $allowedRetakes = InterviewScheduleQuestionModel::where(
//         'interview_question_id',
//         $request->question_id
//     )->value('retakes') ?? 0;

//     $attempts = InterviewAnswerModel::where([
//         'interview_session_id'  => $session->sno,
//         'interview_question_id' => $request->question_id
//     ])->count();

//     /*
//     if ($attempts > $allowedRetakes) {
//         return response()->json([
//             'message' => 'Retake limit exceeded'
//         ], 403);
//     }
//     */

//     /** ✅ Normalize answer type */
//     $answerType = $request->answer_type === 'assesment'
//         ? 'text'
//         : $request->answer_type;

//     /** ✅ Save answer */
//     InterviewAnswerModel::create([
//         'interview_session_id'        => $session->sno,
//         'interview_schedule_stage_id' => $session->interview_schedule_stage_id,
//         'interview_question_id'       => $request->question_id,
//         'answer_type'                 => $answerType,
//         'answer_text'                 => $request->answer_text,
//         'answer_file'                 => $filePath, // ex: video/ans_xxx.webm
//         'time_taken'                  => $request->time_taken ?? 0,
//         'retake_count'                => $request->retake_count ?? 0,
//         'status'                      => 1,
//         'created_at'                  => now(),
//         'created_by'                  => $session->applicant_id
//     ]);

//     return response()->json([
//         'status' => true,
//         'message' => 'Answer saved successfully'
//     ]);
// }


public function checkResume(Request $request)
{
    $session = InterviewSessionModel::where('session_token', $request->session_token)
        ->where('status', 1)
        ->first();
  
    if (!$session) {
        return response()->json([
            'resume' => false
        ]);
    }

    // check unanswered questions
    $pending = InterviewScheduleQuestionModel::where(
        'interview_schedule_stage_id',
        $session->interview_schedule_stage_id
    )
    ->where('status', 1)
    ->whereNotIn('interview_question_id', function ($q) use ($session) {
        $q->select('interview_question_id')
          ->from('egc_interview_answers')
          ->where('interview_session_id', $session->sno);
    })
    ->exists();

    return response()->json([
        'resume' => $pending,
        'last_seen' => $session->updated_at
    ]);
}

private function extractResumeText(string $filePath): string
{
    $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    $text = '';

    try {

        /* ===== PDF ===== */
        if ($extension === 'pdf') {
            $parser = new PdfParser();
            $pdf = $parser->parseFile($filePath);
            $text = $pdf->getText();
        }

        /* ===== DOC / DOCX ===== */
        if (in_array($extension, ['doc', 'docx'])) {

            $phpWord = IOFactory::load($filePath);

            foreach ($phpWord->getSections() as $section) {
                foreach ($section->getElements() as $element) {

                    if (method_exists($element, 'getText')) {
                        $text .= $element->getText() . ' ';
                    }

                    if (method_exists($element, 'getElements')) {
                        foreach ($element->getElements() as $child) {
                            if (method_exists($child, 'getText')) {
                                $text .= $child->getText() . ' ';
                            }
                        }
                    }
                }
            }
        }

    } catch (\Exception $e) {
        \Log::error('Resume extraction failed: ' . $e->getMessage());
    }

    // Cleanup text
    return trim(preg_replace('/\s+/', ' ', $text));
}

public function getAiResponse($prompt){

}

    private function getAiFromOpenRouter($prompt)
    {
        $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 
        $primaryApiKey = '-'; 
        $maxTokens = 1000;
        $aiTimeout = 60; 

        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:free", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
      
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);
        }
        
        // return $response;
        // Parse Response
       if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            return $this->safeJsonDecode($content);
        }

       return $this->defaultAiData();
    }
    private function getAIFromHuggingFace($prompt)
    {
        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions'; 
        $primaryApiKey = '-'; 
        $maxTokens = 1000;
        $aiTimeout = 60; 
        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:nebius", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
        
        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:featherless-ai",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);

            if($response->failed()){
              $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                  'Authorization' => "Bearer $primaryApiKey",
                  'Content-Type' => 'application/json',
                  "X-Title" => "JobApplicationAnalyses",
              ])->post($primaryApiUrl, [
                  'model' => "deepseek-ai/DeepSeek-R1:novita",
                  'messages' => [['role' => 'user', 'content' => $prompt]],
                  'max_tokens' => $maxTokens, 
              ]);
            }

        }
        // return $response ;
        if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            
            return $this->safeJsonDecode($content);
        }else{
            return $this->getAiFromOpenRouter($prompt);
        }


        // return $this->defaultAiData();
    }


    private function safeJsonDecode($content)
    {
        $content = trim($content);

        // Extract JSON using regex
        if (preg_match('/\{.*\}/s', $content, $matches)) {
            $json = json_decode($matches[0], true);
            if (is_array($json)) {
                return $json;
            }
        }

        // Fallback
        return $this->defaultAiData();
    }

    private function defaultAiData()
    {
        return [
            'match_status' => 0,
            'match_score' => 0,
            'matched_skills' => [],
            'missing_skills' => [],
            'experience_analysis' => 'Could not evaluate',
            'education_analysis' => 'Could not evaluate',
            'overall_summary' => 'Could not evaluate',
        ];
    }


    // List files from Google Drive
    public function listFiles()
    {
        $files = $this->googleDriveService->listFiles();
        return view('files', compact('files'));
    }

     public function getAuthUrl()
    {
        // return 'fdggdf';
        $client = new \Google\Client();

        $client->setClientId(env('GOOGLE_CLIENT_ID'));
        $client->setClientSecret(env('GOOGLE_CLIENT_SECRET'));
        $client->setRedirectUri(env('GOOGLE_REDIRECT_URI'));
        $client->setScopes(['https://www.googleapis.com/auth/drive']);
        $client->setAccessType('offline'); // Required for refresh token
        $client->setPrompt('consent');     // Required to get refresh token every time
        
        // Don't set any access token here—just generate the URL
        $authUrl = $client->createAuthUrl();

        return response()->json([
            'auth_url' => $authUrl
        ]);
    }

    public function getRefreshToken(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        $code = $request->input('code');

        $client = new Client();
        $client->setClientId(env('GOOGLE_CLIENT_ID'));
        $client->setClientSecret(env('GOOGLE_CLIENT_SECRET'));
        $client->setRedirectUri(env('GOOGLE_REDIRECT_URI'));

        $token = $client->fetchAccessTokenWithAuthCode($code);

        if (isset($token['error'])) {
            return response()->json([
                'error' => $token['error_description'] ?? $token['error']
            ], 400);
        }

        $refreshToken = $token['refresh_token'] ?? null;

        if (!$refreshToken) {
            return response()->json([
                'error' => 'Refresh token not returned. Make sure you set prompt=consent and this account hasn’t authorized the app before.'
            ], 400);
        }

        // Return refresh token in JSON (copy to your .env)
        return response()->json([
            'refresh_token' => $refreshToken,
            'access_token' => $token['access_token'] // optional
        ]);
    }

    public function handleCallback(Request $request)
    {
        $code = $request->get('code');

        if (!$code) {
            return response()->json(['error' => 'Authorization code not found'], 400);
        }

        $client = new Client();
        $client->setClientId(env('GOOGLE_CLIENT_ID'));
        $client->setClientSecret(env('GOOGLE_CLIENT_SECRET'));
        $client->setRedirectUri(env('GOOGLE_REDIRECT_URI')); // must match route URL

        $token = $client->fetchAccessTokenWithAuthCode($code);

        if (isset($token['error'])) {
            return response()->json([
                'error' => $token['error_description'] ?? $token['error']
            ], 400);
        }

        $refreshToken = $token['refresh_token'] ?? null;

        if (!$refreshToken) {
            return response()->json([
                'error' => 'Refresh token not returned. Make sure you set prompt=consent and that this account has not authorized the app before.'
            ], 400);
        }

        // Optionally: store the refresh token in your database or .env manually
        return response()->json([
            'refresh_token' => $refreshToken,
            'access_token' => $token['access_token'] // optional
        ]);
    }

     public function createDriveFolder(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'parent_id' => 'nullable|string' // optional parent folder
        ]);

        try {
            $folder = $this->googleDriveService->createFolder(
                $request->name,
                $request->parent_id ?? null
            );
                            
            return response()->json([
                'success' => true,
                'folder_id' => $folder->id,
                'folder_name' => $folder->name,
            ]);

        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create folder: ' . $e->getMessage()
            ], 500);
        }
    }

    public function makeFolderPublic(Request $request)
    {
        $request->validate([
            'folder_id' => 'required|string'
        ]);

        try {
            $this->googleDriveService->ensurePublicViewerAccess(
                $request->folder_id
            );

            return response()->json([
                'success' => true,
                'folder_id' => $request->folder_id,
                'folder_url' => "https://drive.google.com/drive/folders/{$request->folder_id}",
                'public' => true
            ]);

        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function makeFolderRestricted(Request $request)
    {
        $request->validate([
            'folder_id' => 'required|string'
        ]);

        try {
            $this->googleDriveService->ensureRestrictedAccess(
                $request->folder_id
            );

            return response()->json([
                'success' => true,
                'folder_id' => $request->folder_id,
                'folder_url' => "https://drive.google.com/drive/folders/{$request->folder_id}",
                'public' => false
            ]);

        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function UploadRecruiterResume(Request $request)
    {
        $page = $request->input('page', 1);        // Default page = 1
        $perPage = $request->input('limit', 20);   // Default 20 rows per page

        $other_db = DB::connection('mysql_secondary');

        // Paginate manually
        $applicants = $other_db
            ->table('applicant')
            ->where('egc_file_updated',0)
            ->where('status','!=',2)
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get();
           return $applicants;
            $uploadedFiles = [];
            $errors = [];

        foreach ($applicants as $applicant) {

            $applicant_sno = $applicant->sno  ?? null;
            if (!$applicant_sno) continue;

            $applicant_id = $applicant->applicant_id ?? null;
            if (!$applicant_id) continue;

            $applicant_name = $applicant->applicant_name ?? null;
            if (!$applicant_name) continue;

            $mobile = $applicant->mobile ?? null;
            if (!$mobile) continue;

            $job_role_ids = [];

            if (!empty($applicant->job_role_id) && $applicant->job_role_id !== 'null') {
                $decoded = json_decode($applicant->job_role_id, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $job_role_ids = $decoded;
                }
            }

            
            
            // $job_role_ids = $applicant->job_role_id ? json_decode($applicant->job_role_id) : [];
            $alter_mobile = $applicant->alter_mobile ?? NULL;
            $email = $applicant->email ?? NULL;
            $gender = $applicant->gender == 'M' ? '1' : ($applicant->gender == 'F' ? '2' : '3');
            $qualification_id = $applicant->qualification_id ?? 0;
            $major = $applicant->major ?? NULL;
            $experience_id = $applicant->experience_id ?? NULL;
            $source_id = $applicant->source_id ?? 0;
            $attachment = $applicant->attachment ?? NULL;
            $interview_date = $applicant->interview_date ?? NULL;
            $marital_status_id = $applicant->marital_status_id ?? NULL;
            $applicant_status = $applicant->applicant_status ?? NULL;
                
            // Fetch related data
            $source_name = $other_db->table('source')->where('sno', $source_id)->value('source_name');
            $qualification_name = $other_db->table('qualification')->where('sno', $qualification_id)->value('qualification_name');
            $major_name = $other_db->table('major')->where('sno', $major)->value('major_name');
            $experience_name = $other_db->table('experience')->where('sno', $experience_id)->value('experience_name');
            $applicant_status_name = $other_db->table('applicant_status')->where('sno', $applicant_status)->value('applicant_status_name');
            $job_role_names = $other_db->table('jobrole')->whereIn('sno', $job_role_ids)->pluck('jobrole_name');
          
            $old_data = [
                'source_id' => $source_id,
                'source_name' => $source_name,
                'qualification_id' => $qualification_id,
                'qualification_name' => $qualification_name,
                'major' => $major,
                'major_name' => $major_name,
                'experience_id' => $experience_id,
                'experience_name' => $experience_name,
                'applicant_status_id' => $applicant_status,
                'applicant_status_name' => $applicant_status_name,
                'job_role_names' => $job_role_names,
            ];

            
            $candidate = InterviewCandidateModel::where('mobile', $mobile)->first();

            $applicantSave = ApplicantModel::where('recruitment_id', $applicant_sno)
                ->where('status', '!=', 2)
                ->first();

            if(!$applicantSave){

                if (!$candidate) {
                    $candidate = InterviewCandidateModel::create([
                        'full_name' => $applicant_name,
                        'mobile'    => $mobile,
                        'email'     => $email,
                    ]);
                }
            
                $applicantSave = ApplicantModel::create([
                    'applicant_id' => $applicant_id,
                    'recruitment_id' => $applicant_sno,
                    'candidate_id' => $candidate->sno,
                    'applicant_name' => $applicant_name,
                    'job_request_id' => 0,
                    'job_role_id' => json_encode($job_role_ids),
                    'mobile' => $mobile,
                    'email' => $email,
                    'attachment' => $attachment,
                    'gender' => $gender,
                    'applicant_status' => $applicant_status,
                    'marital_status_id' => $marital_status_id,
                    'experience_id' => $experience_id == 1 ? '1' : '2',
                    'old_data' => json_encode($old_data),
                    'created_at' => $applicant->created_on,
                ]);
                if($applicantSave){
                    $other_db->table('applicant')
                        ->where('sno', $applicant_sno)
                        ->update(['egc_data_updated' => 1]);
                }
            }

            if (!$applicant->attachment) {
                continue; // skip if attachment is null
            }

            if ($applicantSave->recruitment_file == 1) {
                continue;
            }

            $filename = basename($applicant->attachment);

            // $fileUrl = 'https://recruit.elysium.community/egc/assets/image/Applicant_attach/' . $filename;
            $fileUrl = 'http://192.168.3.94:8080/egc/assets/image/Applicant_attach/' . $filename;
            $candidate_drive = [];
            
            try {
                
                $response = Http::timeout(30)->retry(3, 2000)->get($fileUrl);
                if (!$response->ok()) {
                    $errors[] = [
                        'attachment' => $applicant->attachment,
                        'error' => 'File not accessible at URL'
                    ];
                    continue;
                }

                $tempPath = sys_get_temp_dir() . '/' . $applicant->attachment;
                // $extension = pathinfo($applicant->attachment, PATHINFO_EXTENSION);
                // $tempPath = sys_get_temp_dir() . '/' . uniqid('resume_', true) . '.' . $extension;
                file_put_contents($tempPath, $response->body());

                $uploadedFile = new UploadedFile(
                    $tempPath,
                    $applicant->attachment,
                    mime_content_type($tempPath),
                    null,
                    true
                );

                $driveFile = $this->googleDriveService->upload(
                    $uploadedFile,
                    '1CR_w0qRfAZ1P4dnFPDiSJRXyqzYzNKLP'
                    // env('GOOGLE_DRIVE_FOLDER_ID')
                );

                if ($driveFile && $driveFile->id) {
                    $candidate_drive = [
                        'file_name' => $driveFile->name,
                        'file_id' => $driveFile->id,
                        'webViewLink' => $driveFile->webViewLink ?? null
                    ];

                    $uploadedFiles[] = $candidate_drive;

                    // Update local applicant only if candidate_drive exists
                    $applicantSave->drive_data = json_encode($candidate_drive);
                    $applicantSave->recruitment_file = 1;
                    $applicantSave->save();

                    // Update applicant in other DB
                    $other_db->table('applicant')
                        ->where('sno', $applicant_sno)
                        ->update(['egc_file_updated' => 1]);
                }

                @unlink($tempPath);

                

            } catch (\Exception $e) {
                $errors[] = [
                    'attachment' => $applicant->attachment,
                    'error' => $e->getMessage()
                ];
            }

        }

        return response()->json([
            'page' => $page,
            'per_page' => $perPage,
            'success_count' => count($uploadedFiles),
            'failed_count' => count($errors),
            'uploaded_files' => $uploadedFiles,
            'errors' => $errors
        ]);
    }


    private function UploadFileInDrive($attachment)
{
    $uploadedFiles = [];
    $errors = [];

    if (!$attachment) {
        return ['error' => 'No attachment provided'];
    }

    $filePath = public_path('job_applications/resume_files/' . $attachment);

    // Check if the file exists on the server
    if (!file_exists($filePath)) {
        $errors[] = [
            'attachment' => $attachment,
            'error' => 'File not found on server'
        ];
        return ['errors' => $errors];  // Return errors in case file is not found
    }

    try {
        $uploadedFile = new UploadedFile(
            $filePath,
            $attachment,
            mime_content_type($filePath),
            null,
            true
        );

        // Upload the file to Google Drive
        $driveFile = $this->googleDriveService->upload(
            $uploadedFile,
            env('GOOGLE_DRIVE_FOLDER_ID') // Folder ID is taken from .env
        );

        // Check if the file was uploaded successfully
        if ($driveFile) {
            $uploadedFiles = [
                'file_name' => $driveFile->name,
                'file_id' => $driveFile->id,
                'webViewLink' => $driveFile->webViewLink ?? null
            ];
        } else {
            $errors[] = ['error' => 'Google Drive upload failed'];
        }
    } catch (\Exception $e) {
        // Catch any exception during the upload process
        $errors[] = ['error' => 'Error uploading file to Google Drive: ' . $e->getMessage()];
    }

    // If there are errors, return them; otherwise, return the uploaded file details
    if (!empty($errors)) {
        return ['errors' => $errors];
    }

    return $uploadedFiles;
}

    // for direct upload in drive
    // private function uploadFileInDrive(UploadedFile $file, string $customName)
    // {
    //     try {
    //         // Create a new UploadedFile instance with custom filename
    //         $renamedFile = new UploadedFile(
    //             $file->getRealPath(),   // temp path
    //             $customName,            // custom filename
    //             $file->getMimeType(),
    //             null,
    //             true                    // mark as test (skip file upload checks)
    //         );

    //         $driveFile = $this->googleDriveService->upload(
    //             $renamedFile,
    //             env('GOOGLE_DRIVE_FOLDER_ID')
    //         );

    //         if (!$driveFile) {
    //             return ['error' => 'Google Drive upload failed'];
    //         }

    //         return [
    //             'file_name'   => $driveFile->name,
    //             'file_id'     => $driveFile->id,
    //             'webViewLink' => $driveFile->webViewLink ?? null,
    //         ];

    //     } catch (\Exception $e) {
    //         return [
    //             'error' => 'Error uploading file to Google Drive',
    //             'message' => $e->getMessage()
    //         ];
    //     }
    // }

    public function showNotEligible($encryptedApplicantId)
    {
        // Decode or get the job role dynamically
        $applicantId = base64_decode($encryptedApplicantId);
        $Applicant = ApplicantModel::where('egc_applicant.sno',$applicantId)
         ->select('egc_applicant.*','egc_job_role.job_position_name as job_role_name')
         ->join('egc_job_role', 'egc_applicant.job_role_id', 'egc_job_role.sno')
         ->first();

        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        $jobRoleName = $Applicant?->job_role_name ?? 'Selected Job';
        $applicant_name = $Applicant?->applicant_name ??'Candidate';

        $hr_mobile = $general_setting?->hr_head_no ?? '9879987897';
        $hr_email = $general_setting?->hr_head_mail_id ??'hrelysiumgroups@gmail.com';

        return view('content.hr_management.hr_recruiter.job_application.interview_not_eligible', [
            'job_role_name' => $jobRoleName,
            'applicant_name' => $applicant_name,
            'Applicant' => $Applicant,
            'hr_mobile' => $hr_mobile,
            'hr_email' => $hr_email,
        ]);
    }
    
    public function interviewFeedback($id,Request $request)
    {
        $applicant=InterviewSessionModel::where('egc_interview_session.session_token', $id)
        ->select(
            'egc_applicant.*',
            'egc_interview_schedule_stage.interview_category_id',
            'egc_interview_session.interview_schedule_stage_id',
            'egc_interview_session.interview_schedule_id',
            'egc_interview_category.interview_category_name',
        )
         ->join('egc_applicant', 'egc_applicant.sno', 'egc_interview_session.applicant_id')
         ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.sno', 'egc_interview_session.interview_schedule_stage_id')
         ->join('egc_interview_schedule', 'egc_interview_schedule.sno', 'egc_interview_session.interview_schedule_id')
         ->join('egc_interview_category', 'egc_interview_category.sno', 'egc_interview_schedule_stage.interview_category_id')
          ->first();
        $existing = DB::table('egc_applicant_feedback_answer')
            ->where('applicant_id', $applicant->sno)
            ->where('interview_schedule_stage_id', $applicant->interview_schedule_stage_id)
            ->latest()
            ->first();
        $feedback_submitted = !empty($existing);

        $languages = FeedbackQuestionModel::where('egc_feedback_question.status', 0)
        ->join('egc_languages', 'egc_languages.sno', '=', 'egc_feedback_question.language_id')
        ->select('egc_languages.sno as language_id', 'egc_languages.name', 'egc_languages.native_name')
        ->distinct()
        ->get();
        
        $helper = new \App\Helpers\Helpers();
        $encrypted_schedule_stage_id = $helper->encrypt_decrypt($applicant->interview_schedule_stage_id, 'decrypt');

        
        $schedule_stage_id  = $encrypted_schedule_stage_id;
        return view('content.hr_management.hr_recruiter.job_application.feedback_form',[
            "applicant"=>$applicant,
            "feedback_submitted"=>$feedback_submitted,
            "languages"=>$languages,
            "schedule_stage_id"=>$schedule_stage_id,
        ]);
    }
    public function ThankYouInterview($id,Request $request)
    {

        $applicant=InterviewSessionModel::where('egc_interview_session.session_token', $id)
        ->select(
            'egc_applicant.*',
            'egc_interview_schedule_stage.interview_category_id',
            'egc_interview_session.interview_schedule_stage_id',
            'egc_interview_session.interview_schedule_id',
            'egc_interview_category.interview_category_name',
        )
         ->join('egc_applicant', 'egc_applicant.sno', 'egc_interview_session.applicant_id')
         ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.sno', 'egc_interview_session.interview_schedule_stage_id')
         ->join('egc_interview_schedule', 'egc_interview_schedule.sno', 'egc_interview_session.interview_schedule_id')
         ->join('egc_interview_category', 'egc_interview_category.sno', 'egc_interview_schedule_stage.interview_category_id')
          ->first();

        return view('content.hr_management.hr_recruiter.job_application.interview_thank_you',[
            'applicant'=>$applicant
        ]);
    }

     public function FeedbackListByCategory(Request $request, $id)
    {
        $applicant_id = $request->input('applicant_id');
        $category_id   = $request->input('category_id');
        $section_id = 1;
        // return $category_id ;
        // Base query
        $leadquestion = FeedbackQuestionModel::select(
        'egc_feedback_question.sno as sno',
        'egc_feedback_question.question_name as category_question_name',
        'egc_feedback_question.question_option as category_question_option',
        'egc_feedback_question.question_type as category_question_type',
        'egc_feedback_question.language_id',
        'egc_feedback_question.feedback_section_id as section_id',
        'egc_feedback_section.sno as section_sno',
        'egc_feedback_section.section_name'
        )
        ->join('egc_feedback_section', 'egc_feedback_section.sno', '=', 'egc_feedback_question.feedback_section_id')
        ->where('egc_feedback_question.status', 0)
        ->where('egc_feedback_question.language_id', $id)
        ->where('egc_feedback_question.feedback_section_id', $section_id)
        ->where('egc_feedback_question.interview_category_id', $category_id)
        // ->orderBy('egc_feedback_question.feedback_section_id')
        ->orderBy('egc_feedback_question.sno')
        ->get();

        return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $leadquestion
        ], 200);
    }

    public function SubmitApplicantFeedback(Request $request, $id)
    {

        // return $request;
        try {
            $applicant_id = $id;
            $interview_category_id =$request->interview_category_id;
            $interview_schedule_stage_id =$request->interview_stage_id;
            $interview_schedule_id =$request->interview_schedule_id;
            // Get the Applicant
            $customer = ApplicantModel::where('sno', $applicant_id)->first();

            if (!$customer) {
                return response()->json([
                'status'  => 404,
                'message' => 'Candidate not found'
                ], 404);
            }

            // ---------------- CHECK ALREADY SUBMITTED ----------------
            $already = DB::table('egc_applicant_feedback_answer')
                ->where('applicant_id', $applicant_id)
                ->where('interview_schedule_stage_id', $interview_schedule_stage_id)
                ->exists();

            if ($already) {
                return response()->json([
                'status'  => 409,
                'message' => 'Feedback already submitted.'
                ], 409);
            }

            // Get all answers from request
            $answers = $request->input('answers', []);

            if (empty($answers)) {
                return response()->json([
                'status'  => 400,
                'message' => 'No answers provided.'
                ], 400);
            }

            // Prepare feedback array
            $feedback = [];

            foreach ($answers as $index => $answer) {
                if (!isset($answer['question_id']) || !isset($answer['score'])) {
                continue; // Skip invalid entries
                }

                $feedback[] = [
                'question_id' => $answer['question_id'],
                'answer_value' => $answer['score'],
                'answer_score' => is_numeric($answer['score']) ? (int) $answer['score'] : ($answer['score'] === 'yes' ? 1 : 0)
                ];
            }

            // ---- FORMAT COMPLETE JSON STRUCTURE ----
            $saveJson = [
                "applicant" => [
                "id"   => $applicant_id,
                "name" => $customer->applicant_name
                ],
                "submitted_at" => now()->toISOString(),
                "answers" => $feedback
            ];

            // ---------------- INSERT JSON ----------------
            DB::table('egc_applicant_feedback_answer')->insert([
                'applicant_id'    => $applicant_id,
                'interview_schedule_id'     => $interview_schedule_id,
                'interview_schedule_stage_id'      => $interview_schedule_stage_id,
                'language_id'      => $request->language_id,
                'feedback_json' => json_encode($saveJson, JSON_PRETTY_PRINT),
                'status' => 1,
                'created_at'    => now(),
                'updated_at'    => now(),
            ]);

            return response()->json([
                'status'  => 200,
                'message' => 'Thank you! Your feedback was submitted successfully.'
            ], 200);
        } catch (\Exception $e) {
        \Log::error('Feedback submission error: ' . $e->getMessage());

        return response()->json([
            'status'  => 500,
            'message' => 'An error occurred while submitting feedback. Please try again.'
        ], 500);
        }
    }

    public function ZoomMeetingCreate(Request $request){
        return "working";
    }

     public function generateAiQuestion(Request $request)
{
    $jobRoleId  = $request->job_role_id;
    $categoryId = $request->interview_category_id;
    $LIMIT = 5;

    $role = JobRoleModel::where('sno', $jobRoleId)->first();
    if (!$role) {
        return response()->json(['status' => false, 'questions' => []]);
    }

    $category = InteviewCategoryModel::where('sno', $categoryId)->first();
    $categoryName = $category?->interview_category_name ?? 'General';

    // Existing DB questions first
    $existingQuestions = InterviewQuestionModel::where([
            'job_role_id' => $jobRoleId,
            'interview_category_id' => $categoryId
        ])
        ->orderBy('sno')
        ->limit($LIMIT)
        ->pluck('field_name')
        ->toArray();

    $remaining = $LIMIT - count($existingQuestions);
    $aiQuestions = [];

    if ($remaining > 0) {
        $prompt = "<<<PROMPT
You are an expert HR interviewer.

Generate exactly {$remaining} interview questions.

Job Role: {$role->job_position_name}
Interview Category: {$categoryName}

Rules:
- Each question must be on a NEW LINE
- Questions only
- No numbering
- No explanations
PROMPT";

        $aiRaw = $this->getAIFromHuggingFaceQuestion($prompt);
        // return $aiRaw;
        $aiQuestions = $this->normalizeAIQuestions($aiRaw);

        // Remove duplicates vs DB
        $aiQuestions = array_values(array_diff($aiQuestions, $existingQuestions));
    }

    $finalQuestions = array_slice(
        array_merge($existingQuestions, $aiQuestions),
        0,
        $LIMIT
    );

    return response()->json([
        'status' => true,
        'questions' => collect($finalQuestions)->map(fn ($q) => [
            'question' => $q
        ])
    ]);
}


  private function normalizeAIQuestions($aiData): array
{
    if (!$aiData || !is_string($aiData)) {
        return [];
    }

    // Normalize bullets, dashes, numbering
    $text = str_replace(
        ["•", "–", "—", "\t"],
        "\n",
        $aiData
    );

    $lines = preg_split("/\r\n|\n|\r/", $text);

    return collect($lines)
        ->map(fn ($q) => trim($q))
        ->map(fn ($q) => preg_replace('/^[0-9]+[\.\)]\s*/', '', $q)) // remove numbering
        ->filter(fn ($q) => strlen($q) >= 12) // realistic question length
        ->unique()
        ->values()
        ->toArray();
}

     private function getAIFromHuggingFaceQuestion(string $prompt): string
{
    $apiUrl   = 'https://router.huggingface.co/v1/chat/completions';
    $apiKey   = '-'; 
    $timeout  = 60;
    $maxTokens = 800;

    // ✅ Ordered fallback models (best → cheapest)
    $models = [
        'google/gemma-3-27b-it:nebius',
        'google/gemma-3-12b-it:featherless-ai',
        'deepseek-ai/DeepSeek-R1:novita',
    ];

    foreach ($models as $model) {
        try {
            $response = Http::timeout($timeout)
                ->withHeaders([
                    'Authorization' => "Bearer {$apiKey}",
                    'Content-Type'  => 'application/json',
                    'X-Title'       => 'JobApplicationAnalyses',
                ])
                ->post($apiUrl, [
                    'model' => $model,
                    'messages' => [
                        [
                            'role' => 'user',
                            'content' => $prompt
                        ]
                    ],
                    'max_tokens' => $maxTokens,
                    'temperature' => 0.7, // ✅ stable output
                ]);

            if ($response->successful()) {
                return $response->json('choices.0.message.content', '');
            }

        } catch (\Throwable $e) {
            // ✅ Log but continue fallback
            \Log::warning('AI model failed', [
                'model' => $model,
                'error' => $e->getMessage(),
            ]);
             return $e;
        }
    }

    return "";
    
}

}