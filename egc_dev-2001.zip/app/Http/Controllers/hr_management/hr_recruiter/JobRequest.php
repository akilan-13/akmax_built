<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;

class JobRequest extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
      ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->select('egc_job_request.*','egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_company.company_base_color',);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%");
          });
      }

        if ($job_role_fill) {
          $jobRequest->where('egc_job_request.job_role_name', $job_role_fill);
        }
        if ($closing_date_filt) {
          $jobRequest->where('egc_job_request.closing_date', $closing_date_filt);
        }
        if ($exp_type_filt) {
          $jobRequest->whereJsonContains('egc_job_request.exp_type_ids', $exp_type_filt);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('egc_job_request.created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('egc_job_request.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('egc_job_request.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('egc_job_request.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('egc_job_request.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('egc_job_request.created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
            $applicants_count = ApplicantModel::where('job_request_id', $item->sno)
                    ->where('status', '!=', 2)
                    ->count();

            $interview_stage_count = 0;
            
            $interview_schedule = InterviewScheduleModel::where('job_request_id', $item->sno)
                ->where('status', '!=', 2)
                ->first();

            if ($interview_schedule) {
                $interview_stage_count = InterviewScheduleStageModel::where(
                        'interview_schedule_id',
                        $interview_schedule->sno
                    )
                    ->where('status', '!=', 2)
                    ->count();
            }
            
            // return $interview_schedule;
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'job_role_name' => $item->job_role_name ?? '-',
                  'min_salary' => $item->min_salary,
                  'max_salary' => $item->max_salary,
                  'vacancy_count' => $item->vacancy_count,
                  'experience' => $item->experience,
                  'experience' => $item->experience,
                  'closing_date' => $item->closing_date,
                  'last_apply_date' => $item->last_apply_date,
                  'company_base_color' => $item->company_base_color,
                  'company_name' => $item->company_name,
                  'entity_name' => $item->entity_name,
                  'skill_required' => $item->skill_required,
                  'applicants_count' => $applicants_count,
                  'exp_type_ids' => $item->exp_type_ids,
                  'data' => $item,
                  'interview_schedule_status' => $interview_stage_count > 0 ? 1 : 0,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.hr_management.hr_recruiter.job_request.job_request', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'source_list' => $source_list,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        $interviewCategoryType = DB::table('egc_interview_category')->where('status', '!=', 2)->get();
        $interviewModeList = DB::table('egc_interview_mode')->where('status', '!=', 2)->get();

        $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
        ->select('egc_job_request.*','egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_job_role.job_position_name as job_role_name',
        'egc_company.company_name',
        'egc_entity.entity_base_color',
        'egc_company.company_base_color',)->where('egc_job_request.sno', $decodeId)->first();

        
            $schedule = InterviewScheduleModel::updateOrCreate(
            [
                'job_request_id' => $jobRequest->sno,
                'entity_id' => $jobRequest->entity_id,  
            ],
            [
                'status'      => 0,
                'created_at'  => now(),
                'created_by'  => $userId ?? 0
            ]
        );
        $lastStageId = InterviewScheduleStageModel::max('sno');
        $nextStageId = $lastStageId ? $lastStageId + 1 : 1;

        $idMerge = $decodeId . '~' . $schedule->sno . '~' . $nextStageId;
        $shareCode = base64_encode($idMerge);
        
        $url=url('/interview_login/'.$shareCode);

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          'interviewCategoryType' => $interviewCategoryType,
          'interviewModeList' => $interviewModeList,
          'jobRequest' => $jobRequest,
          'encoded' => $id,
          'url' => $url,
          'scheduleId' => $schedule->sno ,
          
      ]);
  }


 public function createInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id;
    $request->validate([
        'job_request_id' => 'required|integer',
        'entity_id'   => 'required|integer',
        'interview_stages' => 'required|array|min:1'
    ]);
    // return $request;
    DB::beginTransaction();

    try {
         $schedule = InterviewScheduleModel::updateOrCreate(
            [
            'job_request_id' => $request->job_request_id,
            'entity_id' => is_array($request->entity_id)
                          ? ($request->entity_id[0] ?? null)
                          : $request->entity_id,
            ],
            [
            
            'status'      => 0,
            'created_at'  => now(),
            'created_by'  => $userId ?? 0
        ]);
        $firstStageShareCode = null;
       
        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id'  => $stage['interview_category_id'],
                'stage_order'            => $order + 1,
                'duration_value'         => $stage['config']['duration_value'],
                'interview_date' => date('Y-m-d', strtotime($stage['config']['interview_date'])),
                'interview_time' => date('H:i:s', strtotime($stage['config']['interview_time'])),
                'duration_unit'          => $stage['config']['duration_unit'],
                'mode'                   => $stage['config']['mode'],
                'call_confirmation'      => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'       => $stage['config']['immediate_notify'] ?? 0,
                'status'                 => 0,
                'created_at'             => now(),
                'created_by'             => $userId ?? 0
            ]);

             $idMerge   = $request->job_request_id . '~' . $schedule->sno . '~' . $stageModel->sno;
            $shareCode = base64_encode($idMerge);
             $shareUrl=url('/interview_login/'.$shareCode);
            $stageModel->update([
                'shareLink' => $shareUrl
            ]);

             if ($order === 0) {
                $firstStageShareCode = $shareCode;
            }
            
            foreach ($stage['questions'] as $question) {
                $questionData=InterviewQuestionModel::where('sno',$question['question_id'])->first();
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $question['question_id'], // ✅ FIX
                    'thinking_time'               => $questionData->thinking_time ?? '30 Seconds',
                    'allowed_time'                => $$questionData->allowed_time ?? '1 Minutes',
                    'retakes'                     => $$questionData->retakes ?? 3,
                    'status'                      => 0,
                    'created_at'                  => now(),
                    'created_by'                  => $userId ?? 0
                ]);
            }
        }

        

         $schedule->update([
            'share_code' => $firstStageShareCode,
            'updated_by' => $userId ?? 0,
            'updated_at' => now()
        ]);

        DB::commit();

        return response()->json([
            'status'     => true,
            'share_code' => $firstStageShareCode
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to create interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function editInterviewSchedule($encoded)
  {
      [$scheduleSno] = explode('|', base64_decode($encoded));

      $schedule = InterviewScheduleModel::where('sno', $scheduleSno)
          ->where('status', 0)
          ->first();

      $stages = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
          ->where('status', 0)
          ->orderBy('stage_order')
          ->get();
      
          $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->select('egc_job_request.*','egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_job_role.job_position_name as job_role_name',
            'egc_company.company_name',
            'egc_entity.entity_base_color',
            'egc_company.company_base_color',)->where('egc_job_request.sno', $schedule->job_request_id)->first();

      $questions = InterviewScheduleQuestionModel::whereIn(
          'interview_schedule_stage_id',
          $stages->pluck('sno')
      )->where('status', 0)->get();

        $shareCode =$schedule->share_code  ?? base64_encode($schedule->sno . '|' . time());

        $url=url('/interview_login/'.$shareCode);
        $interviewCategoryType = DB::table('egc_interview_category')->where('status', '!=', 2)->get();
        $interviewModeList = DB::table('egc_interview_mode')->where('status', '!=', 2)->get();


      return view('content.hr_management.hr_recruiter.job_request.interview_schedule_edit', [
          'schedule' => $schedule,
          'jobRequest' => $jobRequest,
          'interviewCategoryType' => $interviewCategoryType,
          'interviewModeList' => $interviewModeList,
          'stages'   => $stages,
          'url'   => $url,
          'questions'=> $questions,
          'encoded'  => $encoded
      ]);
  }


  public function updateInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id ?? 0;

    $request->validate([
        'schedule_id'    => 'required|integer',
        'job_request_id'     => 'required|integer',
        'entity_id'       => 'required|integer',
        'interview_stages'=> 'required|array|min:1'
    ]);

    DB::beginTransaction();

    try {
        $schedule = InterviewScheduleModel::where('sno', $request->schedule_id)
            ->where('status', 0)
            ->firstOrFail();

        // 🔹 Update main schedule
        $schedule->update([
            'job_request_id' => $request->job_request_id,
            'entity_id'   => $request->entity_id,
            'updated_at'  => now(),
            'updated_by'  => $userId
        ]);

        // 🔥 DELETE OLD DATA (SAFE)
        $oldStageIds = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
            ->pluck('sno');

        InterviewScheduleQuestionModel::whereIn(
            'interview_schedule_stage_id',
            $oldStageIds
        )->update(['status' => 2 ]);

        InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)->update(['status' => 2 ]);

        // 🔁 REINSERT UPDATED DATA
        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id' => $stage['interview_category_id'],
                'stage_order'           => $order + 1,
                'duration_value'        => $stage['config']['duration_value'],
                'duration_unit'         => $stage['config']['duration_unit'],
                'mode'                  => $stage['config']['mode'],
                'call_confirmation'     => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'      => $stage['config']['immediate_notify'] ?? 0,
                'status'                => 0,
                'created_at'            => now(),
                'created_by'            => $userId
            ]);

            foreach ($stage['questions'] as $qid) {
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $qid,
                    'status'                      => 0,
                    'created_at'                  => now(),
                    'created_by'                  => $userId
                ]);
            }
        }

        DB::commit();

        return response()->json([
            'status'  => true,
            'message' => 'Interview schedule updated successfully'
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to update interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function Status($id, Request $request)
  {
    $last_apply_date = $request->input('last_apply_date');
    $last_apply_date = $last_apply_date ? date('Y-m-d', strtotime($last_apply_date)) : null;
    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->last_apply_date = $last_apply_date;
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }

  public function interviewQuestionsByRole(Request $request)
  {
      $job_role_id = $request->input('job_role_id');
      $interview_category_id = $request->input('interview_category_id');

      $questions = DB::table('egc_interview_question')
          ->where('job_role_id', $job_role_id)
          ->where('interview_category_id', $interview_category_id)
          ->where('status', 0)
          ->get();

      return response()->json([
          'status' => 200,
          'message' => null,
          'error_msg' => null,
          'data' => $questions
      ], 200);
  }

  public function ApplyCandidateListByJob(Request $request){

    $job_request_id = $request->input('request_id');
    $decodeId = base64_decode($job_request_id);

    $applicants = ApplicantModel::where('job_request_id', $decodeId)
                    ->where('status', '!=', 2)
                    ->get();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Fetched!',
      'error_msg' => null,
      'data'      => $applicants,
    ], 200);
  }


   public function UpdateShortlistCandidate(Request $request)
    {
        $shortlistData = $request->input('shortlist_data');
        $job_request_id = $request->input('job_request_id');
        // return $shortlistData;
         $shortlist_students = [];
        foreach ($shortlistData as $data) {
            // Update attendance_check for each student based on sno
            $student = ApplicantModel::where('sno', $data['sno'])->first();
            if ($data['shortListStatus'] == 1) {
                $shortlist_students[] = $data['sno'];
                $student->applicant_status = 3;
            } else {
                $student->applicant_status = 3;
            }

            $student->shortlist_check = $data['shortListStatus'];
            $student->save();
        }
        // return $job_request_id;
        if($job_request_id){
             $upd_eventModel =  JobRequestModel::where('sno', $job_request_id)->first();
              $upd_eventModel->status  =  4;
              $upd_eventModel->Update();

            $interview_schedule = InterviewScheduleModel::where('status', '!=', 2)
            ->where('job_request_id', $job_request_id)
            ->first();

            if ($interview_schedule) {

                $interview_stage = InterviewScheduleStageModel::where('status', '!=', 2)
                    ->where('interview_schedule_id', $interview_schedule->sno)
                    ->where('stage_order', 1)
                    ->first();

                if ($interview_stage) {
                    $interview_stage->shortlist_applicant_ids = !empty($shortlist_students)
                        ? json_encode($shortlist_students)
                        : null;

                    $interview_stage->save();
                }
            }
        }
    
         return response([
            'success'    => true,
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            ], 200);
    }


      public function Scanner_view(Request $request)
    {
            $search_fill = $request->search_fill ?? '';
            $user_id     = $request->user()->user_id;
            $branch_id   = $request->user()->branch_id;
            $role_id   = $request->user()->role_id;
            $sno = $request->sno ?? '';
            $List_table = JobQRScannerModel::where('egc_job_qr_scanner.job_request_id',$sno)->select('egc_job_qr_scanner.*','egc_applicant.applicant_name')
            ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                     ->where('egc_applicant.job_request_id', '=', $sno); // subquery-like condition
                            })
                    ->orderBy('egc_job_qr_scanner.sno','desc')->get();
        // return $ListTable;
        return view('content.hr_management.hr_recruiter.job_request.qr_scannerTable', compact('List_table'));
    }
   
    public function MultiMap(Request $request){
        $sno = $request->sno ?? '';
        $locations = JobQRScannerModel::where('egc_job_qr_scanner.job_request_id', $sno)
                         ->leftJoin('egc_applicant', function($join) use ($sno) {
                                $join->on('egc_applicant.ipaddress', '=', 'egc_job_qr_scanner.ipaddress')
                                     ->where('egc_applicant.job_request_id', '=', $sno); // subquery-like condition
                            })
                        ->where('egc_job_qr_scanner.latitude','!=',NULL)
                        ->where('egc_job_qr_scanner.longitude','!=',NULL)
                        ->select('egc_job_qr_scanner.latitude', 'egc_job_qr_scanner.longitude', 'egc_job_qr_scanner.ipaddress as name','egc_applicant.applicant_name') // adjust columns
                        ->get();
        return response()->json($locations);
    }



    public function NotAppliedListByJob(Request $request)
    {
        $job_request_id = $request->input('request_id');

        $applicants = InterviewCandidateModel::from('egc_interview_candidate as ic')
            ->leftJoin('egc_applicant as ea', 'ea.candidate_id', '=', 'ic.sno')

            ->where('ic.status', '!=', 2)

            // Exclude candidates already applied to this job
            ->whereNotExists(function ($query) use ($job_request_id) {
                $query->select(DB::raw(1))
                    ->from('egc_applicant as ea2')
                    ->whereColumn('ea2.candidate_id', 'ic.sno')
                    ->where('ea2.job_request_id', $job_request_id);
            })

            // Latest applicant per candidate
            ->whereIn('ea.sno', function ($query) {
                $query->select(DB::raw('MAX(sno)'))
                    ->from('egc_applicant')
                    ->groupBy('candidate_id');
            })

            ->select([
                'ic.sno as candidate_id',
                'ea.sno as applicant_id',
                'ea.applicant_name',
                'ea.recruitment_id',
                'ea.job_request_id',
                'ea.job_role_id',
                'ea.mobile',
                'ea.email',
                'ea.gender',
                'ea.marital_status_id',
                'ea.qualification_id',
                'ea.major',
                'ea.experience_id',
                'ea.experience_count',
                'ea.source_id',
                'ea.marital_status_id',
                'ea.drive_data',
                'ea.old_data',
            ])

            ->orderBy('ea.applicant_name','asc')
            ->get();

        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Fetched!',
            'error_msg' => null,
            'data'      => $applicants,
        ]);
    }


    public function majorListByQualification(Request $request)
    {
        $qualification_id = $request->qualification_id;
        $majorList = MajorModel::where('status', 0)->where('qualification_id', $qualification_id)->orderBy('major_name', 'asc')->get();

        return response([
        'status' => 200,
        'message' => null,
        'error_msg' => null,
        'data' => $majorList
        ], 200);
    }
     public function AddJobCandidate(Request $request)
    {
       
       $request->validate([
            'candidate_name' => 'required',
            'candidate_mobile' => 'required',
            'candidate_email' => 'required',
            'candidate_gender'   => 'required|integer',
            'candidate_marital_status' => 'nullable|max:51200'
        ]);
        DB::beginTransaction();

        
        try {
            $resumeFile = null;
            $resumeUrl = null;
            $fullName        = $request->candidate_name;
            $mobile_no       = $request->candidate_mobile;
            $email_id        = $request->candidate_email;
            $gender          = $request->candidate_gender;
            $job_request_id  = $request->apply_job_request_id;
            $apply_applicant_id  = $request->apply_applicant_id;
            $jobRequestdata =  JobRequestModel::where('sno', $job_request_id)->first();

            $candidateData =  ApplicantModel::where('sno', $apply_applicant_id)->first();
            $job_role_id     = $jobRequestdata->job_role_id;
            $marital_status  = $request->candidate_marital_status;
            $qualification   = $request->candidate_qualification;
            $major           = $request->candidate_major;
            $OtherQualification           = $request->candidate_other_qualify;
            $exper_type      = $request->candidate_exper_type;
            $exper_count     = $request->candidate_exper_count ?? 0;
            $resume_check     = $request->resume_check ?? 0;
            $source          = $request->source_name;
            $ipAddress = $request->ip();
            $resumeText = null;
            $userId = auth()->user()->user_id;
            $drive_data=[];

            if($candidateData){
                $candidate_id = $candidateData->candidate_id;
                $candidate = InterviewCandidateModel::where('sno', $candidate_id)->first();
                $candidate->full_name =$fullName;
                // $candidate->mobile =$mobile_no;
                // $candidate->email =$email_id;
                $candidate->update();
            }else{
                $candidate = InterviewCandidateModel::create([
                    'full_name' => $fullName,
                    'mobile'    => $mobile_no,
                    'email'     => $email_id,
                ]);

                $candidate_id = $candidate->sno;
            }
            // return $candidate;
            $lastApplicant = ApplicantModel::orderBy('sno', 'desc')->first();
            $year = date('y');

            if (!$lastApplicant) {
                $applicant_id = "EGCJA-0001-{$year}";
            } else {
                preg_match('/EGCJA-(\d+)/', $lastApplicant->applicant_id, $matches);
                $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
                $applicant_id = 'EGCJA-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $year;
            }

            

            if($resume_check == 0){
                if ($request->hasFile('upload_resume')) {
                    $file = $request->file('upload_resume');
                    $extension = $file->getClientOriginalExtension();

                    $folderPath = public_path('job_applications/resume_files/');

                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true);
                    }

                    // Unique filename
                    $resumeFile = $applicant_id . '.' . $extension;

                    $file->move($folderPath, $resumeFile);
                    $filePath = $folderPath . $resumeFile;
                    $resumeText = $this->extractResumeText($filePath);
                    
                
                    if (file_exists($filePath)) {
                        $drive_data = $this->UploadFileInDrive($resumeFile);
                    }
                }
            }else{
                $drive_old =$candidateData->drive_data;
                $drive_data=$drive_old ? json_decode($drive_old):null;
                $attachment_link=$drive_data ?$drive_data->webViewLink : null;
                if($candidateData->resumeText){
                    $resumeText =$candidateData->resumeText;
                }else{
                    if ($drive_data && isset($drive_data->file_id)) {
                        // $resumeText = $this->extractResumeTextFromDrive($drive_data->file_id);
                        $resumeText = $this->extractResumeTextFromDrive($drive_data->file_id);
                    } else if ($candidateData->attachment) {
                        $resumeText = $this->extractResumeText(public_path('job_applications/resume_files/' . $candidateData->attachment));
                    }
                }
                
                
                $resumeFile=$candidateData->attachment;
                // $resumeText = $this->extractResumeText($attachment_link);
                
            }
               

               function cleanUtf8($value)
                {
                    if (is_array($value)) {
                        return array_map('cleanUtf8', $value);
                    }

                    if (is_string($value)) {
                        return mb_convert_encoding($value, 'UTF-8', 'UTF-8');
                    }

                    return $value;
                }
                $resumeText  = cleanUtf8($resumeText);
               
              $applicant=ApplicantModel::create([
                'applicant_id'      => $applicant_id,
                'candidate_id'      => $candidate_id,
                'applicant_name'    => $fullName,
                'job_request_id'       => $job_request_id,
                'job_role_id'       => $job_role_id,
                'mobile'            => $mobile_no,
                'email'             => $email_id,
                'attachment'        => $resumeFile,
                'ipaddress'         => $ipAddress ?? null,
                'resume_text'       => $resumeText ?? NULL,
                'gender'            => $gender,
                'marital_status_id' => $marital_status,
                'qualification_id'  => $qualification,
                'major'             => $major,
                'other_qualification' => $OtherQualification ?? NULL,
                'experience_id'     => $exper_type,
                'experience_count'  => $exper_count,
                'source_id'         => $source,
                'drive_data'        => $drive_data ? json_encode($drive_data) : NULL,
                'created_by'       => $userId,
                'updated_by'       => $userId,
            ]);
            
             if($applicant){
                $qualificationName = "Not provided"; 
                $experTypeText = $exper_type == 1 ? "Fresher" : "Experience"; 

                $jobRequest = JobRequestModel::select('egc_job_request.*', 'egc_job_role.job_position_name as job_role_name')
                    ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
                    ->where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$job_request_id)->first();

                    $promptTemplate = "
                You are an AI HR screening assistant.
                Your task is to evaluate how well a candidate matches a job requirement.
                The resume content is PRIMARY source of truth.
                Form input data is SECONDARY.

                Return ONLY valid JSON as below:

                {
                \"match_status\": 0, 
                \"match_score\": 0, 
                \"matched_skills\": [], 
                \"missing_skills\": [], 
                \"experience_analysis\": \"short sentence\", 
                \"education_analysis\": \"short sentence\", 
                \"overall_summary\": \"1-2 sentence professional HR summary\"
                }

                STRICT RULES:
                - Resume text has higher priority than form data.
                - If resume is empty or unreadable, base decision on form data.
                - Do NOT overrate candidates.
                - No markdown or extra text.
                - Output must be valid parsable JSON.

                JOB DETAILS:
                Role: {{JOB_ROLE_NAME}}
                Description: {{JOB_DESCRIPTION}}
                Required Experience: {{REQUIRED_EXPERIENCE}}
                Required Skills: {{REQUIRED_SKILLS}}

                CANDIDATE DATA:
                Name: {{FULL_NAME}}
                Qualification: {{QUALIFICATION}}
                Major: {{MAJOR}}
                Experience Type: {{EXPERIENCE_TYPE}}
                Experience Count: {{EXPERIENCE_COUNT}}
                Resume Content: {{RESUME_TEXT}}
                ";

                    $prompt = str_replace(
                        [
                            '{{JOB_ROLE_NAME}}',
                            '{{JOB_DESCRIPTION}}',
                            '{{REQUIRED_EXPERIENCE}}',
                            '{{REQUIRED_SKILLS}}',
                            '{{FULL_NAME}}',
                            '{{QUALIFICATION}}',
                            '{{MAJOR}}',
                            '{{EXPERIENCE_TYPE}}',
                            '{{EXPERIENCE_COUNT}}',
                            '{{RESUME_TEXT}}',
                        ],
                        [
                            $jobRequest->job_role_name,
                            $jobRequest->job_description,
                            $jobRequest->experience,
                            $jobRequest->required_skills,
                            $applicant->applicant_name,
                            $qualificationName,
                            $applicant->major,
                            $experTypeText,
                            $applicant->experience_count,
                            $applicant->resume_text ?? 'Resume not available',
                        ],
                        $promptTemplate
                    );

                $aiData = $this->getAIFromHuggingFace($prompt);
                if (empty($aiData)) {
                    $aiData = $this->getAiFromOpenRouter($prompt);
                }
                if($aiData){
                    ApplicantModel::where('sno', $applicant->sno)->update([
                        'match_status' => $aiData['match_status'] ?? 0,
                        'match_score'  => $aiData['match_score'] ?? 0,
                        'ai_response'  => $aiData ?? null,
                        'ai_summary'   => $aiData['overall_summary'] ?? null,
                    ]);
                }
             }
            
            // return response()->json([
            //         'status'         => 401,
            //         'message'        => 'Job application submitted successfully!',
            //         'data' => $resumeText,
            //     ]);
            $payload = [
                'applicant_id'=>$applicant->sno,
                'stage'=>'Applied',
                'job_request_id'=>$applicant->job_request_id,
                'interview_stage_id'=> 0,
                'interview_session_id'=> 0,
                'staff_id'=> 0,
                'created_by'=>$userId,
                'updated_by'=>$userId,
                
            ];
            $saveLog = $this->applicantLogCreate($payload);
            DB::commit();
            return response()->json([
                'status'         => 200,
                'message'        => 'candidate Add successfully!',
            ]);
        }catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'status'  => false,
                'message' => 'Failed to Add Candidate',
                'error'   => $e->getMessage()
            ], 500);
        }
        
        return response()->json([
            'status'         => 200,
            'message'        => 'Job application submitted successfully!',
            'application_id' => base64_encode($applicant->sno),
        ]);
    }


    private function extractResumeText(string $filePath): string
    {
       
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        $text = '';
        // return $extension;
        try {

            /* ===== PDF ===== */
            if ($extension === 'pdf') {
                // return $extension;
                $parser = new PdfParser();
                $pdf = $parser->parseFile($filePath);
                //  return $pdf->getText();
                $text = $pdf->getText();
            }

            /* ===== DOC / DOCX ===== */
            if (in_array($extension, ['doc', 'docx'])) {

                $phpWord = IOFactory::load($filePath);

                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {

                        if (method_exists($element, 'getText')) {
                            $text .= $element->getText() . ' ';
                        }

                        if (method_exists($element, 'getElements')) {
                            foreach ($element->getElements() as $child) {
                                if (method_exists($child, 'getText')) {
                                    $text .= $child->getText() . ' ';
                                }
                            }
                        }
                    }
                }
            }

        } catch (\Exception $e) {
            \Log::error('Resume extraction failed: ' . $e->getMessage());
        }

        // Cleanup text
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    public function extractResumeTextFromDrive(string $fileId): string
    {
        
        try {
            $filePath = $this->googleDriveService->downloadFile($fileId);

            $mime = mime_content_type($filePath);

            $extension = match ($mime) {
                'application/pdf' => 'pdf',
                'application/msword' => 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
                default => throw new Exception("Unsupported MIME type: {$mime}")
            };

            $finalPath = $filePath . '.' . $extension;
            rename($filePath, $finalPath);

            $text = $this->extractResumeText($finalPath);

            unlink($finalPath);

            return $text;

        } catch (Exception $e) {
            Log::error('Resume extraction failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            return '';
        }
    }

    private function getAiFromOpenRouter($prompt)
    {
        $primaryApiUrl = 'https://openrouter.ai/api/v1/chat/completions'; 
        $primaryApiKey = '-'; 
        $maxTokens = 1000;
        $aiTimeout = 60; 

        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:free", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
      
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:free",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);
        }
        
        // return $response;
        // Parse Response
       if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            return $this->safeJsonDecode($content);
        }

       return $this->defaultAiData();
    }
    private function getAIFromHuggingFace($prompt)
    {
        $primaryApiUrl = 'https://router.huggingface.co/v1/chat/completions'; 
        $primaryApiKey = ''; 
        $maxTokens = 1000;
        $aiTimeout = 60; 
        // Primary API Request (Gemma 3)
        $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
            'Authorization' => "Bearer $primaryApiKey",
            'Content-Type' => 'application/json',
            "X-Title" => "JobApplicationAnalyses",
        ])->post($primaryApiUrl, [
            // Using a potentially free model on OpenRouter
            'model' => "google/gemma-3-27b-it:nebius", 
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'max_tokens' => $maxTokens, 
        ]);
        
        // Check if primary API failed
        if ($response->failed()) {
            // Use fallback API (Gemma 3 smaller version)
            $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                'Authorization' => "Bearer $primaryApiKey",
                'Content-Type' => 'application/json',
                "X-Title" => "JobApplicationAnalyses",
            ])->post($primaryApiUrl, [
                'model' => "google/gemma-3-12b-it:featherless-ai",
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'max_tokens' => $maxTokens, 
            ]);

            if($response->failed()){
              $response = Http::timeout($aiTimeout)->withHeaders([ // <-- ADDED TIMEOUT
                  'Authorization' => "Bearer $primaryApiKey",
                  'Content-Type' => 'application/json',
                  "X-Title" => "JobApplicationAnalyses",
              ])->post($primaryApiUrl, [
                  'model' => "deepseek-ai/DeepSeek-R1:novita",
                  'messages' => [['role' => 'user', 'content' => $prompt]],
                  'max_tokens' => $maxTokens, 
              ]);
            }

        }
        // return $response ;
        if ($response->successful()) {
            $content = $response->json()['choices'][0]['message']['content'] ?? '';
            
            return $this->safeJsonDecode($content);
        }else{
            return $this->getAiFromOpenRouter($prompt);
        }


        // return $this->defaultAiData();
    }

    private function safeJsonDecode($content)
    {
        $content = trim($content);

        // Extract JSON using regex
        if (preg_match('/\{.*\}/s', $content, $matches)) {
            $json = json_decode($matches[0], true);
            if (is_array($json)) {
                return $json;
            }
        }

        // Fallback
        return $this->defaultAiData();
    }

    private function defaultAiData()
    {
        return [
            'match_status' => 0,
            'match_score' => 0,
            'matched_skills' => [],
            'missing_skills' => [],
            'experience_analysis' => 'Could not evaluate',
            'education_analysis' => 'Could not evaluate',
            'overall_summary' => 'Could not evaluate',
        ];
    }


     private function UploadFileInDrive($attachment)
    {
        $uploadedFiles = [];
        $errors = [];

        if (!$attachment) {
            return ['error' => 'No attachment provided'];
        }

        $filePath = public_path('job_applications/resume_files/' . $attachment);

        // Check if the file exists on the server
        if (!file_exists($filePath)) {
            $errors[] = [
                'attachment' => $attachment,
                'error' => 'File not found on server'
            ];
            return ['errors' => $errors];  // Return errors in case file is not found
        }

        try {
            $uploadedFile = new UploadedFile(
                $filePath,
                $attachment,
                mime_content_type($filePath),
                null,
                true
            );

            // Upload the file to Google Drive
            $driveFile = $this->googleDriveService->upload(
                $uploadedFile,
                env('GOOGLE_DRIVE_FOLDER_ID') // Folder ID is taken from .env
            );

            // Check if the file was uploaded successfully
            if ($driveFile) {
                $uploadedFiles = [
                    'file_name' => $driveFile->name,
                    'file_id' => $driveFile->id,
                    'webViewLink' => $driveFile->webViewLink ?? null
                ];
            } else {
                $errors[] = ['error' => 'Google Drive upload failed'];
            }
        } catch (\Exception $e) {
            // Catch any exception during the upload process
            $errors[] = ['error' => 'Error uploading file to Google Drive: ' . $e->getMessage()];
        }

        // If there are errors, return them; otherwise, return the uploaded file details
        if (!empty($errors)) {
            return ['errors' => $errors];
        }

        return $uploadedFiles;
    }

    public function preview(Request $request, string $fileId)
    {
        return $this->googleDriveService->streamFile($fileId);
    }

    // public function getInterviewScheduleByJobId(Request $request)
    // {
    //     $request->validate([
    //         'job_request_id' => 'required|integer'
    //     ]);

    //     $schedule = InterviewScheduleModel::where('egc_interview_schedule.job_request_id', $request->job_request_id)
    //         ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
    //          ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
    //         ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
    //         ->select(
    //             'egc_interview_schedule.*',
    //             'egc_job_role.job_position_name as job_role_name',
    //             'egc_entity.entity_name',
    //             'egc_entity.entity_short_name',
    //             'egc_entity.entity_base_color',
    //             'egc_entity.entity_logo',
    //             'egc_entity.company_id',
    //         )
    //         ->first();

    //     $stages=InterviewScheduleStageModel::where('egc_interview_schedule_stage.interview_schedule_id',$schedule->sno)
    //             ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
    //             ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
    //             ->select(
    //                 'egc_interview_schedule_stage.*',
    //                 'egc_interview_category.interview_category_name',
    //                 'egc_interview_mode.interview_mode_name',
    //             )
    //             ->get();
    //     foreach($stages as $stg){
    //         $question =InterviewScheduleQuestionModel::where('egc_interview_schedule_questions.interview_schedule_stage_id',$stg->sno)
    //                     ->join('egc_interview_question','egc_interview_question.sno','=','egc_interview_schedule_questions.interview_question_id')
    //                     ->select(
    //                         'egc_interview_schedule_questions.*',
    //                         'egc_interview_question.field_name as question',
    //                         'egc_interview_question.field_option as question_options',
    //                         'egc_interview_question.field_value as question_type',
    //                         )
    //                         ->get();
    //         $stg->questions=$question;
    //     }

    //     $schedule->stages=$stages;
    //     if (!$schedule) {
    //         return response()->json([
    //             'status' => 404,
    //             'message' => 'Schedule not found'
    //         ]);
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'data' => $schedule
    //     ]);
    // }

    public function getInterviewScheduleByJobId(Request $request)
    {
        $validated = $request->validate([
            'job_request_id' => 'required|integer'
        ]);

        $schedule = InterviewScheduleModel::query()
            ->where('egc_interview_schedule.job_request_id', $validated['job_request_id'])
            ->join('egc_job_request', 'egc_job_request.sno', '=', 'egc_interview_schedule.job_request_id')
            ->join('egc_job_role', 'egc_job_request.job_role_id', '=', 'egc_job_role.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', '=', 'egc_entity.sno')
            ->select([
                'egc_interview_schedule.*',
                'egc_job_role.job_position_name as job_role_name',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_entity.entity_base_color',
                'egc_entity.entity_logo',
                'egc_entity.company_id',
            ])
            ->first();

        if (!$schedule) {
            return response()->json([
                'status' => 404,
                'message' => 'Interview schedule not found'
            ], 404);
        }

        /** ---------------- STAGES ---------------- */
        $stages = InterviewScheduleStageModel::query()
            ->where('egc_interview_schedule_stage.interview_schedule_id', $schedule->sno)
            ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', '=', 'egc_interview_category.sno')
            ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', '=', 'egc_interview_mode.sno')
            ->select([
                'egc_interview_schedule_stage.*',
                'egc_interview_category.interview_category_name',
                'egc_interview_mode.interview_mode_name',
            ])
            ->get();

        /** ---------------- QUESTIONS (Single Query) ---------------- */
        $questions = InterviewScheduleQuestionModel::query()
            ->join(
                'egc_interview_question',
                'egc_interview_question.sno',
                '=',
                'egc_interview_schedule_questions.interview_question_id'
            )
            ->select([
                'egc_interview_schedule_questions.interview_schedule_stage_id',
                'egc_interview_schedule_questions.thinking_time',
                'egc_interview_schedule_questions.allowed_time',
                'egc_interview_schedule_questions.retakes',
                'egc_interview_question.field_name as question',
                'egc_interview_question.field_option as question_options',
                'egc_interview_question.field_value as question_type',
            ])
            ->get()
            ->groupBy('interview_schedule_stage_id');

        /** ---------------- MAP QUESTIONS TO STAGES ---------------- */
        $stages->transform(function ($stage) use ($questions) {
            $stage->questions = $questions[$stage->sno] ?? [];
            return $stage;
        });

        $schedule->stages = $stages;

        return response()->json([
            'status' => 200,
            'data' => $schedule
        ]);
    }

    private function applicantLogCreate($payload){

            $applicant=ApplicantLogModel::create([
                'applicant_id'      => $payload['applicant_id'],
                'stage'      => $payload['stage'],
                'job_request_id'    => $payload['job_request_id'],
                'interview_stage_id'       => $payload['interview_stage_id'],
                'interview_session_id'       => $payload['interview_session_id'],
                'staff_id'            => $payload['staff_id'],
                'updated_by'             => $payload['updated_by'],
                'created_by'        => $payload['created_by'],
            ]);
    }

}
