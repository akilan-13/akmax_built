<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ApplicantStatusModel;
use Illuminate\Support\Facades\Validator;

class ApplicantStatus extends Controller
{
  
  public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = ApplicantStatusModel::where('egc_applicant_status.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_applicant_status.*');
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_applicant_status.applicant_status_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_applicant_status.applicant_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_applicant_status.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'applicant_status_name' => $item->applicant_status_name,
                    'status_color' => $item->status_color,
                    'applicant_desc' => $item->applicant_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.recruitment.applicant_status.applicant_status_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }

 

  public function List(Request $request)
  {
    
    $Department = ApplicantStatusModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function Status($id, Request $request)
  {

    $staff =  ApplicantStatusModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Applicant Status Updated Successfully!',
        'error_msg' => 'Could not, update  Applicant Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Applicant Status!',
        'error_msg' => 'Could not, update  Applicant Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_ApplicantStatusModel = ApplicantStatusModel::where('sno', $id)->first();
    $upd_ApplicantStatusModel->status = 2;
    $upd_ApplicantStatusModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'applicant_status_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $applicant_status_name = $request->applicant_status_name;
      $status_color = $request->status_color;
      $applicant_desc = $request->applicant_desc;
      $user_id = $request->user()->user_id;
      $chk = ApplicantStatusModel::where('applicant_status_name', $applicant_status_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Aplpicant Status Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = ApplicantStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

       
        $add_department = new ApplicantStatusModel();
        $add_department->applicant_status_name = $applicant_status_name;
        $add_department->status_color = $status_color;
        $add_department->applicant_desc = $applicant_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Applicant Status added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Applicant Status!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = ApplicantStatusModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Applicant Status not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Applicant Status fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'applicant_status_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $applicant_status_name = $request->applicant_status_name;
      $status_color = $request->status_color;
      $applicant_desc = $request->applicant_desc;
      $user_id = $request->user()->user_id;
      $chk = ApplicantStatusModel::where('applicant_status_name', $applicant_status_name)->where('sno', '!=', $sno)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Applicant Status Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = ApplicantStatusModel::where('sno', $sno)->first();
        $up_department->applicant_status_name = $applicant_status_name;
        $up_department->status_color = $status_color;
        $up_department->applicant_desc = $applicant_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Applicant Status updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Applicant Status!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

}
