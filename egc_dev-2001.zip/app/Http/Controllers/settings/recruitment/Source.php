<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SourceModel;
use Illuminate\Support\Facades\Validator;

class Source extends Controller
{
    

     public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = SourceModel::where('egc_source.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_source.*');
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_source.source_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_source.source_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_source.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'source_name' => $item->source_name,
                    'source_desc' => $item->source_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.recruitment.source.source_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }

 

  public function List(Request $request)
  {
    
    $Department = SourceModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function Status($id, Request $request)
  {

    $staff =  SourceModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Source Updated Successfully!',
        'error_msg' => 'Could not, update Source!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Source!',
        'error_msg' => 'Could not, update Source!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_SourceModel = SourceModel::where('sno', $id)->first();
    $upd_SourceModel->status = 2;
    $upd_SourceModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'source_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $source_name = $request->source_name;
      $source_desc = $request->source_desc;
      $user_id = $request->user()->user_id;
      $chk = SourceModel::where('source_name', $source_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Aplpicant Status Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = SourceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

       
        $add_department = new SourceModel();
        $add_department->source_name = $source_name;
        $add_department->source_desc = $source_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Source added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Source!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = SourceModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Source not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Source fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'source_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $source_name = $request->source_name;
      $source_desc = $request->source_desc;
      $user_id = $request->user()->user_id;
      $chk = SourceModel::where('source_name', $source_name)->where('sno', '!=', $sno)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Source Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = SourceModel::where('sno', $sno)->first();
        $up_department->source_name = $source_name;
        $up_department->source_desc = $source_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Source updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Source!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

}
