<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\QualificationLevelModel;
use Illuminate\Support\Facades\Validator;

class QualificationLevel extends Controller
{
    

     public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = QualificationLevelModel::where('egc_qualification_level.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_qualification_level.*');
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_qualification_level.qualification_level_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_qualification_level.description', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_qualification_level.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'qualification_level_name' => $item->qualification_level_name,
                    'description' => $item->description,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
 
    return view('content.settings.recruitment.qualification_level.qualification_level_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
    ]);
  }

 

  public function List(Request $request)
  {
    
    $Department = QualificationLevelModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function Status($id, Request $request)
  {

    $staff =  QualificationLevelModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Qualification Updated Successfully!',
        'error_msg' => 'Could not, update Qualification!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Qualification!',
        'error_msg' => 'Could not, update Qualification!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_QualificationLevelModel = QualificationLevelModel::where('sno', $id)->first();
    $upd_QualificationLevelModel->status = 2;
    $upd_QualificationLevelModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'qualification_level_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $qualification_level_name = $request->qualification_level_name;
      $description = $request->description;
      $user_id = $request->user()->user_id;
      $chk = QualificationLevelModel::where('qualification_level_name', $qualification_level_name)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Aplpicant Status Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = QualificationLevelModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

       
        $add_department = new QualificationLevelModel();
        $add_department->qualification_level_name = $qualification_level_name;
        $add_department->description = $description;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Qualification added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Qualification!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = QualificationLevelModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Qualification not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Qualification fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'qualification_level_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $qualification_level_name = $request->qualification_level_name;
      $description = $request->description;
      $user_id = $request->user()->user_id;
      $chk = QualificationLevelModel::where('qualification_level_name', $qualification_level_name)->where('sno', '!=', $sno)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Qualification Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = QualificationLevelModel::where('sno', $sno)->first();
        $up_department->qualification_level_name = $qualification_level_name;
        $up_department->description = $description;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Qualification updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Qualification!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

}
