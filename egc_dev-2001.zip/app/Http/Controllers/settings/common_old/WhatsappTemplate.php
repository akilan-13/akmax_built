<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use App\Models\WhatsappTemplateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class WhatsappTemplate extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        return view('content.settings.common.whatsapp_template.whatsapp_template_list');
    }




    public function list()
    {
        $whatsappTemplate = WhatsappTemplateModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $whatsappTemplate,
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'whatsapp_title_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $whatsapp_title_name = $request->whatsapp_title_name;
            $start_date = date('Y-m-d', strtotime($request->start_date));
            $end_date = date('Y-m-d', strtotime($request->end_date));
            $waba_template_id = $request->waba_template_id;
            $user_id = $request->user()->user_id;
            $chk = WhatsappTemplateModel::where('whatsapp_title_name', ucwords($whatsapp_title_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Email is exist!',
                ]);
                return redirect('settings/common/whatsapp_template');
            } else {
                $category_check = WhatsappTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $whatsapp_template_id = 'WA-0001/' . $year;
                } else {

                    $data = $category_check->whatsapp_template_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('WA-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $whatsapp_template_id = $request . '/' . $year;
                }

                $add_wTemplate = new WhatsappTemplateModel();
                $add_wTemplate->whatsapp_template_id = $whatsapp_template_id;
                $add_wTemplate->whatsapp_title_name = Ucfirst($whatsapp_title_name);
                $add_wTemplate->start_date = $start_date;
                $add_wTemplate->end_date = $end_date;
                $add_wTemplate->waba_template_id = $waba_template_id;
                $add_wTemplate->branch_id = self::$branch_id;
                $add_wTemplate->created_by = $user_id;
                $add_wTemplate->updated_by = $user_id;

                $add_wTemplate->save();

                if ($add_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Template added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Whatsapp Template!',
                    ]);
                }
            }
            return redirect('settings/common/whatsapp_template');
        }
    }

    public function Update(Request $request)
    {

        // return $request;

        $validator = Validator::make($request->all(), [
            'whatsapp_title_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $whatsapp_title_name = $request->whatsapp_title_name;
            $start_date = date('Y-m-d', strtotime($request->start_date));
            $end_date = date('Y-m-d', strtotime($request->end_date));
            $waba_template_id = $request->waba_template_id;
            $edit_id = $request->edit_id;

            $upd_wTemplate = WhatsappTemplateModel::where('sno', $edit_id)->first();

            $chk = WhatsappTemplateModel::where('whatsapp_title_name', ucwords($whatsapp_title_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already whatsapp Template is exist!',
                ]);
                return redirect()->back();
            } else {

                $upd_wTemplate->whatsapp_title_name = Ucfirst($whatsapp_title_name);
                $upd_wTemplate->start_date = $start_date;
                $upd_wTemplate->end_date = $end_date;
                $upd_wTemplate->waba_template_id = $waba_template_id;
                $upd_wTemplate->update();

                if ($upd_wTemplate) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Whatsapp Template Update Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the Whatsapp Template!',
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_wTemplate = WhatsappTemplateModel::where('sno', $id)->first();
        $upd_wTemplate->status = 2;
        $upd_wTemplate->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_wTemplate = WhatsappTemplateModel::where('sno', $id)->first();
        $upd_wTemplate->status = $request->input('status', 0);
        $upd_wTemplate->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
 public function handleWebhook(Request $request)
{
    // Handle verification (GET request)
    if ($request->isMethod('get')) {
        if (
            $request->query('hub_mode') === 'subscribe' &&
            $request->query('hub_verify_token') === '2026d0dfea8175ec07b42b2245da10f7'
        ) {
            // Send challenge back as plain text, not as a JSON response
            return response($request->query('hub_challenge'), 200)->header('Content-Type', 'text/plain');
        }
        return response()->json(['error' => 'Invalid token'], 403);
    }

    // Handle incoming message (POST request)
    return response()->json(['success' => true]);
}


}
