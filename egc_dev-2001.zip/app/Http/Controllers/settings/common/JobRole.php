<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;


class JobRole extends Controller
{
  public function index()
{
    return view('content.settings.common.jobrole.jobrole');
}


}
