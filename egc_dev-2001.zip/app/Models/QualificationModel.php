<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QualificationModel extends Model {
    use HasFactory;
    public $table      = 'egc_education';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'qualification_level_id',
        'education',
        'education_desc',
        'created_by',
        'created_at',
        'status',
    ];
}