<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SkillTagModel extends Model
{
    use HasFactory;
    public $table      = "egc_skill_tag";
    public $primaryKey = 'sno';


    protected $fillable = [
        'skill_tag_name',
        'skill_tag_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}