<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FinancialYearModel extends Model
{
    use HasFactory;
    public $table      = 'egc_financial_year';
    public $primaryKey = 'sno';

    protected $fillable = [
        'financial_year_id	',
        'branch_id',
        'financial_year_name',
        'financial_month',
        'financial_year_desc',
        'created_by',
        'created_at',
        'status',
    ];
}