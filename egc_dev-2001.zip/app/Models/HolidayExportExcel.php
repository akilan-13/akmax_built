<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;

class HolidayExportExcel implements  WithHeadings
{
     protected $companies = [];

    public function __construct()
    {
        $this->companies = DB::table('egc_company')
            ->where('status', 0)
            ->pluck('company_name', 'sno')
            ->toArray();
    }

    public function headings(): array
    {
        return [
            'Holiday From Date (YYYY-MM-DD)',
            'Holiday To Date (YYYY-MM-DD)',
            'Holiday Reason',
            'Company',
        ];
    }

    public function array(): array
    {
        // Empty rows for entry
        return array_fill(0, 100, ['', '', '', '']);
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();

                /**
                 * Prepare dropdown list
                 */
                $dropdownValues = [
                    'All|all',
                    'Elysium Groups|0'
                ];

                foreach ($this->companies as $sno => $name) {
                    $dropdownValues[] = "{$name}|{$sno}";
                }

                $dropdownList = implode(',', $dropdownValues);

                /**
                 * Apply dropdown to column D (Company)
                 */
                for ($row = 2; $row <= 101; $row++) {
                    $validation = $sheet->getCell("D{$row}")->getDataValidation();
                    $validation->setType(DataValidation::TYPE_LIST);
                    $validation->setAllowBlank(false);
                    $validation->setShowDropDown(true);
                    $validation->setFormula1('"' . $dropdownList . '"');
                }

                /**
                 * Column widths
                 */
                $sheet->getColumnDimension('A')->setWidth(25);
                $sheet->getColumnDimension('B')->setWidth(25);
                $sheet->getColumnDimension('C')->setWidth(30);
                $sheet->getColumnDimension('D')->setWidth(40);
            }
        ];
    }
}