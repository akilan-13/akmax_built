<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeedbackAnswerModel extends Model
{
    use HasFactory;
    public $table      = "egc_applicant_feedback_answer";
    public $primaryKey = 'sno';


    protected $fillable = [
        'applicant_id',
        'interview_schedule_id',
        'interview_schedule_stage_id',
        'language_id',
        'feedback_json',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];

}