<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicantLogModel extends Model
{
    use HasFactory;

    protected $table = 'egc_applicant_logs';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'applicant_id',
        'stage',
        'job_request_id',
        'interview_stage_id',
        'interview_session_id',
        'staff_id',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at'
    ];

}
