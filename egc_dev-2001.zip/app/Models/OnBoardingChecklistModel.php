<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OnBoardingChecklistModel extends Model
{
    use HasFactory;
    public $table      = "egc_onboard_checklist";
    public $primaryKey = 'sno';


    protected $fillable = [
        'onboard_checklist',
        'company_type',
        'orientation_staging_id',
        'company_id',
        'entity_id',
        'department_id',
        'division_id',
        'job_role_id',
        'metrics_check',
        'metrics_ids',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}