<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewCandidateModel extends Model
{
  use HasFactory;
   protected $table = 'egc_interview_candidate';
    protected $primaryKey = 'sno';
    // public $timestamps = false;

    protected $fillable = [
      'full_name','email', 'mobile', 'status','created_at','updated_at'
    ];
}