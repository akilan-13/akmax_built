<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobRequestLogModel extends Model
{
  use HasFactory;
  protected $table = 'egc_job_log_timeline';
    protected $primaryKey = 'sno';
    public $timestamps = true;

    protected $fillable = [
        'job_request_id',
        'applicant_id',
        'schedule_id',
        'interview_stage_id',
        'event_type',
        'event_time',
        'meta',
        'status',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by'
    ];
}