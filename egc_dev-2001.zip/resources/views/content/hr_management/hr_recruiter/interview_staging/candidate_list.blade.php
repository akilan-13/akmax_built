<style>
.candidate-container {
    display: flex;
    align-items: start;
    border-radius: 6px;
    border-style: none;
    position: relative;
    margin-left: 0px;
    box-shadow: rgba(47, 43, 61, 0.16) 0px 4px 11px 0px;
}

.candidate-list {
    background-color: rgb(255, 255, 255);
    color: rgba(47, 43, 61, 0.78);
    box-shadow: rgba(47, 43, 61, 0.1) 0px 4px 18px 0px;
    background-image: none;
    margin-right: 20px;
    transition: box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
    border-radius: 6px;
}

.candidate-content {
    width: 0px;
    flex-grow: 1;
}

</style>
<div class="card p-4">
    <div class="candidate-container">
        <div class="candidate-list h-350px">
            <div id="notCandidateList" class=" py-2 px-4 border border-bottom">
                <input type="text" id="candidateSearch" class="form-control mb-2" placeholder="Search Candidate">
                <div id="candidateList"
                    style="max-height:450px; overflow-y:auto;"
                    class="list-group">
                </div>
            </div>
        </div>
        <div class="candidate-content">
            
        </div>
    </div>
</div>
@if(count($candidates))
<table class="table table-row-dashed table-striped table-hover mb-0 bg-white">
    <thead >
        <tr class="fw-bold fs-6 gs-0 bg-primary">
            <th>Name</th>
            <th>mobile / Email</th>
            <th>Status</th>
            <th>Applied On</th>
        </tr>
    </thead>
    <tbody>
        @foreach($candidates as $c)

        @php 
            $statuBadge='';
            $statuClass='';
            if($c->hiring_status ==1){
                $statuBadge='Selected';
                $statuClass='bg-label-success';
            }
            elseif ($c->applicant_status == 1) {
                $statuBadge='New Applicant';
                $statuClass='bg-label-warning';
            }elseif($c->applicant_status == 3){
                if($c->shortlist_check == 1){
                    $statuBadge='Shortlisted';
                    $statuClass='bg-label-info';
                }else{
                    $statuBadge='Not Eligible';
                    $statuClass='bg-label-danger';
                }
            }else{
                $statuBadge='New Applicant';
                $statuClass='bg-label-warning';
            }
        @endphp
        <tr>
            <td>{{ $c->applicant_name }}</td>
            <td>
                <div>{{ $c->mobile}}</div>
                <div>{{ $c->email }}</div>
            </td>
            <td>
              <span class="badge rounded {{$statuClass}} text-black fw-semibold fs-7">{{ $statuBadge }}</span> 
            </td>
            <td>{{ date('d M Y', strtotime($c->created_at)) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="text-center text-muted py-4">
    No candidates found
</div>
@endif
