
<style>
 /* WRAPPER */
.timeline {
    position: relative;
}

/* ITEM */
.timeline-item {
    position: relative;
    padding: 8px 0;
}

/* CONNECTOR LINE (ONLY BETWEEN DOTS) */
.timeline-item::before {
    content: '';
    position: absolute;
    left: 32px;               /* CENTER AXIS */
    top: 0;
    bottom: 0;
    width: 2px;
     background: #9ca3af;
}

/* REMOVE LINE ABOVE FIRST */
.timeline-item:first-child::before {
    top: 50%;
}

/* REMOVE LINE BELOW LAST */
.timeline-item:last-child::before {
    bottom: 50%;
}

/* DOT — PERFECT CENTER */
.timeline-dot {
    position: absolute;
    left: 26px;               /* 32 - (12/2) */
    top: 50%;
    transform: translateY(-50%);
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #9ca3af;
    z-index: 2;
}

/* CONTENT */
.timeline-content {
    margin-left: 20px;
}

/* COMPLETED */
.timeline-item.completed::before {
    background: #22c55e;
}

.timeline-item.completed .timeline-dot {
    background: #22c55e;
}


</style>
<div class="accordion" id="applicantResultAccordion">

@forelse($candidates as $candidate)

@php
    $uid = 'cand_'.$candidate->sno;

@endphp
@php
$totalTime = collect($candidate->questions ?? [])
                ->whereIn('status', ['completed','retake'])
                ->sum('time_taken');

$totalRetakes = collect($candidate->questions ?? [])
                ->sum('retake_count');

$answeredCount = collect($candidate->questions ?? [])
                ->where('status','!=','not_answered')
                ->count();
@endphp

<div class="accordion-item border-0 mb-4 rounded-4 shadow-sm overflow-hidden">

    {{-- HEADER --}}
    <h2 class="accordion-header" id="heading-{{ $uid }}">
        <button class="accordion-button collapsed px-4 py-3 bg-white"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse-{{ $uid }}"
                aria-expanded="false">

            <div class="d-flex align-items-center w-100 gap-3">

                {{-- Avatar --}}
                <div class="rounded-circle bg-primary text-white fw-bold d-flex align-items-center justify-content-center"
                     style="width:44px;height:44px;">
                    {{ strtoupper(substr($candidate->applicant_name,0,1)) }}
                </div>

                {{-- Info --}}
                <div class="flex-grow-1">
                    <div class="fw-semibold">{{ $candidate->applicant_name }}</div>
                    <small class="text-muted">
                        {{ $candidate->email }} • {{ $candidate->mobile }}
                    </small>
                </div>

                {{-- Stats --}}
                <div class="text-end d-none d-md-block">
                    <span class="badge bg-label-primary me-1">
                        {{ $answeredCount }} / {{ count($candidate->questions ?? []) }} Answered
                    </span>
                    <span class="badge bg-label-warning me-1">
                        {{ $totalRetakes }} Retakes
                    </span>
                    <span class="badge bg-label-success me-1">
                        {{ gmdate('i:s', $totalTime) }} Time
                    </span>
                    <span class="me-1">
                        @if($candidate->is_selected == 1)
                        <span class="badge bg-label-info me-1">
                            Selected
                        </span>
                        @endif
                    </span>
                </div>
                
            </div>
        </button>
        
    </h2>

    {{-- BODY --}}
    <div id="collapse-{{ $uid }}"
         class="accordion-collapse collapse"
         data-bs-parent="#applicantResultAccordion">

        <div class="accordion-body bg-light">

            @if(!empty($candidate->questions))

            <div class="timeline {{ $answeredCount === count($candidate->questions ?? []) ? 'completed' : '' }}">

                @foreach($candidate->questions as $index => $q)
                    <div class="timeline-item {{ $q->status === 'completed' ? 'completed' : 'not_answered' }}">
                        {{-- DOT --}}
                        <div class="timeline-dot"></div>

                        {{-- CONTENT --}}
                        <div class="timeline-content bg-white rounded-4 shadow-sm p-4">

                            <div class="d-flex justify-content-between mb-2">
                                <div>
                                    <span class="badge bg-secondary me-2">Q{{ $index+1 }}</span>
                                    <strong>{{ $q->question_text }}</strong>
                                </div>

                                @if($q->created_at)
                                    <small class="text-muted">
                                        {{ \Carbon\Carbon::parse($q->created_at)->format('d M Y, h:i A') }}
                                    </small>
                                @endif
                            </div>

                            @if($q->status === 'not_answered')
                                <div class="text-muted px-2 mb-0">
                                    Candidate did not submit an answer
                                </div>
                            @else

                                {{-- ANSWER TYPE --}}
                                <div class="mb-2 text-muted small">
                                    @if($q->answer_type === 'text')
                                        <i class="mdi mdi-text-long me-1"></i> Text Answer
                                    @elseif($q->answer_type === 'audio')
                                        <i class="mdi mdi-microphone me-1"></i> Audio Answer
                                    @elseif($q->answer_type === 'video')
                                        <i class="mdi mdi-video me-1"></i> Video Answer
                                    @endif
                                </div>

                                {{-- ANSWER --}}
                                <div class="mt-3">
                                    @if($q->answer_type === 'text')
                                        <div class="border rounded-3 p-3 bg-light">
                                            {{ $q->answer_text }}
                                        </div>
                                    @endif

                                    <!-- @if($q->answer_type === 'audio')
                                        <audio controls class="w-100">
                                            <source src="{{ asset($q->answer_file) }}">
                                        </audio>
                                    @endif

                                    @if($q->answer_type === 'video')
                                        <video controls class="w-100 rounded-3" style="max-height:260px">
                                            <source src="{{ asset($q->answer_file) }}">
                                        </video>
                                    @endif -->

                                    @if($q->answer_type === 'audio')
                                        <audio controls class="w-100">
                                            <source src="{{ route('interview.media', $q->id) }}">
                                        </audio>
                                    @endif

                                    @if($q->answer_type === 'video')
                                        <video controls class="w-100 rounded-3" style="max-height:260px">
                                            <source src="{{ route('interview.media', $q->id) }}">
                                        </video>
                                    @endif
                                </div>

                                {{-- META --}}
                                <div class="d-flex justify-content-between mt-3 text-muted small">
                                    <span><span class="mdi mdi-timer-outline"></span> {{ gmdate('i:s', $q->time_taken) }} spent</span>
                                    <span><span class="mdi mdi-refresh text-info"></span> {{ $q->retake_count ?? 0 }} retakes</span>
                                </div>

                            @endif

                        </div>
                    </div>
                @endforeach
                
            </div>
                @if($candidate->is_selected == 1)
                <div class="d-flex justify-content-end align-items-center gap-2">
                    <span class="badge bg-label-success me-1 "><span class="mdi mdi-check-circle-outline"></span> Selected</span>
                </div>
                @elseif($candidate->is_rejected == 1)
                <div class="d-flex justify-content-end align-items-center gap-2">
                    <span class="badge bg-label-danger me-1"><span class="mdi mdi-close-circle-outline"></span> Rejected</span>
                </div>
                @else
                    @if($candidate->is_last_stage)
                        @if(!$candidate->is_completed)
                        <div class="d-flex justify-content-end align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-danger " disabled>
                                Reject
                            </button>
                            <button type="button" class="btn btn-sm btn-success" disabled>
                                Hire
                            </button>
                        </div>
                        
                        @else
                        <div class="d-flex justify-content-end align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-danger" onclick="openRejectModal({{ $candidate->sno }},'{{ $candidate->applicant_name }}','{{ $candidate->email }}','{{ $stage->interview_category_name ?? '' }}')">
                                Reject
                            </button>
                            <button type="button" class="btn btn-sm btn-success" onclick="openHireModal({{ $candidate->sno }},'{{ $candidate->applicant_name }}','{{ $candidate->email }}','{{ $stage->interview_category_name ?? '' }}')">
                                Hire
                            </button>
                        </div>
                        @endif
                    @else
                        @if(!$candidate->is_completed)
                        <div class="d-flex justify-content-end align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-danger" disabled>
                                Reject
                            </button>
                            <button type="button" class="btn btn-sm btn-success" disabled>
                                Next Round Eligible
                            </button>
                        </div>
                        @else
                        <div class="d-flex justify-content-end align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-danger" onclick="openRejectModal({{ $candidate->sno }},'{{ $candidate->applicant_name }}','{{ $candidate->email }}','{{ $stage->interview_category_name ?? '' }}')">
                                Reject
                            </button>
                            <button type="button" class="btn btn-sm btn-success" onclick="openShortlistModal({{ $candidate->sno }},'{{ $candidate->applicant_name }}','{{ $candidate->email }}','{{ $stage->interview_category_name ?? '' }}')">
                                Next Round Eligible
                            </button>
                        </div>
                        @endif
                    @endif
                @endif
            @else
                <div class="text-center text-muted py-5">
                    No interview answers available
                </div>
            @endif

        </div>
    </div>
</div>

@empty
<div class="text-center text-muted py-5">
    No applicants found
</div>
@endforelse

</div>
