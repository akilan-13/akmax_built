@extends('layouts/blankLayout')

@section('title', 'Feedback Form')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('content')

<style>
    @page {
        size: A4;
        margin: 0;
    }

    .print-container {
        box-sizing: border-box;
        width: 100%;
    }

    .header_content {
        display:flex;
        flex-direction: column;
        align-items:start;
        justify-content:center;
        gap:1px;
    }

    .header_wrapper {
        display:flex;
        align-items:center;
        justify-content:start;
        gap:15px;
    }

    .header {
        display: flex;
        align-items:start;
        justify-content:start;
        flex-direction: column;
        /* gap:5px; */
    }

    .contact {
        display: flex;
        align-items: end;
        justify-content: start;
        flex-direction: column; 
    }

    @media print {

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            page-break-before: auto;
            /* padding-top: 220px; */
            /* counter-reset: page; */
        }

        .print-container::before {
            content: "";
            display: block;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        .page-break {
            page-break-before: auto !important;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            /* overflow-x: visible !important; */
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            page-break-inside: always !important;
            /* break-inside: avoid !important; */
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }
    
    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }

        .header_content {
            display:flex;
            flex-direction: column;
            align-items:center;
            justify-content:center;
            gap:1px;
        }

        .header_wrapper {
            display:flex;
            flex-direction: column;
            align-items:center;
            justify-content:center;
            gap:3px;
        }

        .header {
            display: flex;
            align-items:center;
            justify-content:start;
            flex-direction: column;
            gap:5px;
        }

        .contact {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 2px;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }

        .header_content {
            display:flex;
            flex-direction: column;
            align-items:start;
            justify-content:center;
            gap:1px;
        }

        .header_wrapper {
            display:flex;
            align-items:start;
            justify-content:start;
            gap:15px;
        }

        .header {
            display: flex;
            align-items:start;
            justify-content:start;
            flex-direction: column;
            /* gap:5px; */
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
    .star-rating {
        display: flex;
        flex-direction: row-reverse;
        justify-content: start;
        align-items: center;
        gap: 10px;
    }

    .star-rating input {
        display: none;
    }

    .star-rating label {
        cursor: pointer;
        color: #d1d5db; /* default grey */
        transition: color 0.2s ease, transform 0.2s ease;
    }

    .star-rating label:hover {
        transform: scale(1.1);
    }

    /* Hover & selected fill */
    .star-rating label:hover,
    .star-rating label:hover ~ label,
    .star-rating input:checked ~ label {
        color: #fdd10dff; /* primary */
    }


    .emoji-container {
        display: flex;
        /* grid-template-columns: repeat(5, 1fr); */
        gap: 16px;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
    }

    .emoji-box {
        background: #fff;
        border: 1.5px solid #e2e5ea;
        border-radius: 12px;
        padding: 18px 10px;
        text-align: center;
        cursor: pointer;
        transition: all 0.25s ease;
        width: 100px;
        height: auto;
    }

    .emoji-box img {
        width: 42px;
        height: 42px;
        padding: 8px;
        border-radius: 50%;
        background: #f8f9fa;
        box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        transition: all 0.25s ease;
    }

    .emoji-label {
        margin-top: 8px;
        font-size: 13px;
        font-weight: 500;
        color: #555;
    }

    /* Hover */
    .emoji-box:hover {
        border-color: #AB2B22;
        background: #ffe0dd93;
    }

    .emoji-box:hover .emoji-icon{
        color: #AB2B22;
    }

    /* Selected */
    .emoji-box.selected {
        border-color: #AB2B22;
        background: #ffe0dd93;
    }

    .emoji-box.selected .emoji-label {
        color: #AB2B22;
        font-weight: 600;
    }

    .emoji-box.selected .emoji-icon {
        color: #AB2B22;
    }

    @keyframes blink {
        0%, 50%, 100% { opacity: 1; }
        25%, 75% { opacity: 0; }
    }

    .blink {
        animation: blink 1s infinite;
    }
</style>
<center>
    <div style="margin:bottom:20px;" class="w-lg-45 w-md-100 w-sm-100 print-container">
        <div style="background-image: url('{{ asset('assets/egc_images/feedback_bg.png') }}');transform: scaleX(1); background-size: cover;background-repeat: no-repeat; background-position: center; padding: 20px; border-radius: 8px; margin-bottom: 10px; box-shadow: 0 3px 3px rgb(177,177,177,0.8); border: 1px solid #e9ecef;">
            <div class="header_wrapper">
                <img src="{{ asset('assets/common/logo_small.png') }}" width="80" alt="EGC Logo">
                <div class="header">
                    <label style="font-size: 16px; font-weight: 500; color: #000000;">
                        Content Writer - Feedback Form
                    </label>
                    <label style="font-size: 20px; font-weight: 500; color: #000000;">
                        Preliminary Interview Feedback
                    </label>
                    <medium style="font-size: 14px; color: #666; margin-top: 8px; display: block;">
                        Help us improve by sharing your experience from the interview process.
                    </medium>
                </div>
            </div>
        </div>
        <div style="padding: 5px 20px;background-color: #fff; border-radius: 10px;box-shadow: 0 3px 3px rgb(177,177,177, 0.8);margin-bottom: 20px;">
            <div style="padding: 10px 20px;">
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>How would you rate your overall experience with this journey?</span>
                    </label>
                    <div class="emoji-container">
                        <div class="emoji-box" data-value="1">
                             <i class="mdi mdi-emoticon-cry emoji-icon fs-1"></i>
                            <div class="emoji-label">Very Poor</div>
                        </div>

                        <div class="emoji-box" data-value="2">
                            <i class="mdi mdi-emoticon-sad emoji-icon fs-1"></i>
                            <div class="emoji-label">Poor</div>
                        </div>

                        <div class="emoji-box" data-value="3">
                            <i class="mdi mdi-emoticon-neutral emoji-icon fs-1"></i>
                            <div class="emoji-label">Neutral</div>
                        </div>

                        <div class="emoji-box" data-value="4">
                             <i class="mdi mdi-emoticon-happy emoji-icon fs-1"></i>
                            <div class="emoji-label">Good</div>
                        </div>

                        <div class="emoji-box" data-value="5">
                             <i class="mdi mdi-emoticon-excited emoji-icon fs-1"></i>
                            <div class="emoji-label">Excellent</div>
                        </div>
                    </div>
                </div>
                <div class="w-full border my-2"></div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>How easy was it to coordinate the interview schedule?</span>
                    </label>
                    <div class="star-rating">
                        <input type="checkbox" name="q1_rating" id="q1_1" value="1">
                        <label for="q1_1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q1_rating" id="q1_2" value="2">
                        <label for="q1_2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q1_rating" id="q1_3" value="3">
                        <label for="q1_3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q1_rating" id="q1_4" value="4">
                        <label for="q1_4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q1_rating" id="q1_5" value="5">
                        <label for="q1_5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                    </div>
                </div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>Was the interview schedule communicated clearly in advance?</span>
                    </label>
                    <div class="star-rating">
                        <input type="checkbox" name="q2_rating" id="q2_1" value="1">
                        <label for="q2_1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q2_rating" id="q2_2" value="2">
                        <label for="q2_2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q2_rating" id="q2_3" value="3">
                        <label for="q2_3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q2_rating" id="q2_4" value="4">
                        <label for="q2_4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q2_rating" id="q2_5" value="5">
                        <label for="q2_5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                    </div>
                </div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>Did you feel comfortable asking questions during the interview?</span>
                    </label>
                    <div class="star-rating">
                        <input type="checkbox" name="q3_rating" id="q3_1" value="1">
                        <label for="q3_1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q3_rating" id="q3_2" value="2">
                        <label for="q3_2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q3_rating" id="q3_3" value="3">
                        <label for="q3_3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q3_rating" id="q3_4" value="4">
                        <label for="q3_4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q3_rating" id="q3_5" value="5">
                        <label for="q3_5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                    </div>
                </div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>Were the job role and responsibilities explained clearly?</span>
                    </label>
                    <div class="star-rating">
                        <input type="checkbox" name="q4_rating" id="q4_1" value="1">
                        <label for="q4_1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q4_rating" id="q4_2" value="2">
                        <label for="q4_2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q4_rating" id="q4_3" value="3">
                        <label for="q4_3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q4_rating" id="q4_4" value="4">
                        <label for="q4_4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q4_rating" id="q4_5" value="5">
                        <label for="q4_5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                    </div>
                </div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;margin-bottom: 5px;">
                        <span>Did the interview focus on understanding your basic skills and background?</span>
                    </label>
                    <div class="star-rating">
                        <input type="checkbox" name="q5_rating" id="q5_1" value="1">
                        <label for="q5_1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q5_rating" id="q5_2" value="2">
                        <label for="q5_2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q5_rating" id="q5_3" value="3">
                        <label for="q5_3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q5_rating" id="q5_4" value="4">
                        <label for="q5_4">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                        <input type="checkbox" name="q5_rating" id="q5_5" value="5">
                        <label for="q5_5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="currentColor" stroke="currentColor" stroke-width="1.5" d="M9.153 5.408C10.42 3.136 11.053 2 12 2s1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182s.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506s-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452s-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882S3.58 8.328 6.04 7.772l.636-.144c.699-.158 1.048-.237 1.329-.45s.46-.536.82-1.182z"/>
                            </svg>
                        </label>
                    </div>
                </div>
                <div style="text-align:left;margin-bottom:10px;margin-top:20px;">
                    <label style="font-weight: semibold;font-size:16px;color; #000000;">
                        <span>Do you have any suggestions to help us improve further?</span>
                    </label>
                    <div style="display:block;margin-top:4px;">
                        <textarea class="form-control" rows="2" placeholder="Enter suggestions"></textarea>
                    </div>
                </div>
            </div>
            <div style="display: flex;align-items:center;justify-content:center;padding-bottom:50px;margin-top:5px;">
                <a href="{{url('/hr_recruitment/interview_staging')}}" class="btn btn-lg btn-primary waves-effect waves-light fw-semibold fs-4" style="width: 300px;" id="agr_butt">
                    Send Feedback
                </a>
            </div>
        </div>
    </div>
</center>

<script>
    document.querySelectorAll('.emoji-box').forEach(box => {
        box.addEventListener('click', () => {
            document.querySelectorAll('.emoji-box').forEach(b => b.classList.remove('selected'));
            box.classList.add('selected');
        });
    });
</script>

@endsection