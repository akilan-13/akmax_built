@extends('layouts/layoutMaster')

@section('title', 'Interview Staging')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
    .emoji-box {
        background: #fff;
        border: 1.5px solid #e2e5ea;
        border-radius: 12px;
        padding: 18px 10px;
        text-align: center;
        cursor: pointer;
        transition: all 0.25s ease;
        width: 130px;
        height: 150px;
    }

    .interview-card {
    border-radius: 14px;
}

.stat-box {
    cursor: pointer;
    min-width: 130px;
}

.stat-card {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    transition: all .25s ease;
    border: 1px solid transparent;
}

.stat-box:hover .stat-card {
    background: #fff;
    border-color: #dee2e6;
    transform: translateY(-2px);
}

.stat-box.active .stat-card {
    background: #ab2b22;
    color: #fff;
}

.stat-count {
    font-size: 22px;
    font-weight: 700;
}

.stat-label {
    font-size: 13px;
    font-weight: 500;
    opacity: .85;
}


.skeleton {
    background: linear-gradient(
        90deg,
        #f1f1f1 25%,
        #e6e6e6 37%,
        #f1f1f1 63%
    );
    background-size: 400% 100%;
    animation: skeleton-loading 1.4s ease infinite;
}

@keyframes skeleton-loading {
    0% { background-position: 100% 50%; }
    100% { background-position: 0 50%; }
}

.skeleton-row {
    height: 42px;
    border-radius: 6px;
    margin-bottom: 10px;
}


</style>

<!-- Lead List Table -->
<div class="card card-action mb-3">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Interview Staging</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Recruitment
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="card p-4" style="box-shadow: none;">

@if(isset($jobRequest) && count($jobRequest))
<div class="accordion" id="jobRequestAccordion">

@foreach($jobRequest as $request)

<div class="accordion-item border-0 mb-3 interview-card">

    {{-- HEADER --}}
    <h2 class="accordion-header" id="heading-{{ $request->sno }}">
        <button class="accordion-button collapsed bg-white px-4 py-3"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse-{{ $request->sno }}"
                aria-expanded="false">

            <div class="d-flex w-100 justify-content-between align-items-center">
                <div>
                    <h6 class="mb-0 fw-bold">{{ $request->job_role_name }}</h6>
                    <small class="text-muted">{{ $request->company_name }}</small>
                </div>

                <span class="badge rounded-pill px-3 py-2"
                      style="background: {{ $request->entity_base_color ?? '#6c757d' }}">
                    {{ $request->entity_name }}
                </span>
            </div>
        </button>
    </h2>

    {{-- BODY --}}
    <div id="collapse-{{ $request->sno }}"
         class="accordion-collapse collapse"
         data-bs-parent="#jobRequestAccordion">

        <div class="accordion-body bg-light">

            {{-- STAT CARDS --}}
            <div class="row g-3 interview-stats mb-3">

                <div class="col stat-box active"
                     data-type="candidates"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{ $request->candidate_count }}</div>
                        <div class="stat-label">Candidates</div>
                    </div>
                </div>

                <!-- <div class="col stat-box"
                     data-type="shortlisted"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{ $request->shortlist_count }}</div>
                        <div class="stat-label">Shortlisted</div>
                    </div>
                </div> -->

                @foreach($request->interviewStageList as $stage)
                    @php
                        $ids = $stage->shortlist_applicant_ids
                            ? json_decode($stage->shortlist_applicant_ids)
                            : [];
                    @endphp
                    <div class="col stat-box"
                         data-type="stage"
                         data-stage="{{ $stage->sno }}"
                         data-job="{{ $request->sno }}">
                        <div class="stat-card">
                            <div class="stat-count">{{ count($ids) }}</div>
                            <div class="stat-label">
                                {{ $stage->interview_category_name }}
                            </div>
                        </div>
                    </div>
                @endforeach

                <div class="col stat-box"
                     data-type="hired"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{$request->hired_count}}</div>
                        <div class="stat-label">Hired</div>
                    </div>
                </div>

            </div>

            {{-- AJAX PANEL --}}
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div id="candidate-panel-{{ $request->sno }}">
                        <div class="text-center text-muted py-4">
                            Expand to load candidates
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
@endforeach

</div>
@else
<div class="text-center text-muted">No Request Found</div>
@endif

</div>


<div class="modal fade" id="hireModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title text-success fw-semibold">
          Confirm Hiring
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="hire-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="hire-email"></span></p>
          <p class="mb-0"><strong>Final Stage:</strong> <span id="hire-stage"></span></p>
        </div>

        <div class="alert alert-danger small">
          Hiring is <strong>final</strong>. This action cannot be reverted.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="hire-agree"
                 onchange="document.getElementById('hire-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I confirm that this candidate is approved for hiring
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-success" id="hire-confirm" disabled>
          Hire Candidate
        </button>
      </div>

    </div>
  </div>
</div>


<div class="modal fade" id="shortlistModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title fw-semibold">
          Shortlist Candidate
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="sl-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="sl-email"></span></p>
          <p class="mb-0"><strong>Current Stage:</strong> <span id="sl-stage"></span></p>
        </div>

        <div class="alert alert-warning small">
          This applicant will move to the <strong>next interview stage</strong>.
          Please ensure the evaluation is complete.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="sl-agree"
                 onchange="document.getElementById('sl-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I have reviewed the interview results and confirm shortlisting
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" id="sl-confirm" disabled>
          Shortlist Candidate
        </button>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="RejectModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title fw-semibold">
          Reject Candidate
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="rjct-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="rjct-email"></span></p>
          <p class="mb-0"><strong>Current Stage:</strong> <span id="rjct-stage"></span></p>
        </div>
        <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Reason<span class="text-danger">*</span></label>
            <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleAddSpam(this.value)">
                <option value="">Select Reason</option>
                @if (isset($reasonList) && count($reasonList) > 0)
                @foreach ($reasonList as $reason_spam)
                <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                    {{ $reason_spam->reason_name }}
                </option>
                @endforeach
                @endif
                <option value="1">Others</option>
            </select>
            <div class="text-danger" id="reason_select_err"></div>
        </div>
        <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
            <div class="text-danger" id="reason_text_err"></div>
        </div>
        <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
            <div class="text-danger" id="spam_comments_err"></div>
        </div>
        <div class="alert alert-warning small">
          This applicant will move to the <strong>next interview stage</strong>.
          Please ensure the evaluation is complete.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="rjct-agree"
                 onchange="document.getElementById('rjct-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I have reviewed the interview results and confirm Rejecting
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" id="rjct-confirm" disabled>
          Reject Candidate
        </button>
      </div>

    </div>
  </div>
</div>

<script>
    let fetchControllers = {};  
    let responseCache   = {}; 

    function skeletonTable() {
        let rows = '';
        for (let i = 0; i < 6; i++) {
            rows += `<div class="skeleton-row skeleton"></div>`;
        }

        return `
            <div class="p-4">
                ${rows}
            </div>
        `;
    }

</script>

<script>
$(document).ready(function () {

    /* Load candidates ONLY when accordion opens */
    $('.accordion-collapse').on('shown.bs.collapse', function () {

        let jobId = $(this).attr('id').replace('collapse-', '');
        let card  = $(this).closest('.accordion-item');

        let defaultBox = card.find('.stat-box[data-type="candidates"]');

        if (!defaultBox.data('loaded')) {
            defaultBox.data('loaded', true);
            loadCandidates(jobId, 'candidates');
        }
    });

    /* Stat box click */
    $(document).on('click', '.stat-box', function () {

        let card = $(this).closest('.accordion-item');
        card.find('.stat-box').removeClass('active');
        $(this).addClass('active');

        let jobId = $(this).data('job');
        let type  = $(this).data('type');
        let stage = $(this).data('stage') ?? '';

        loadCandidates(jobId, type, stage);
        clearJobCache(jobId)
    });

});

$('.stat-box').css('pointer-events', 'none');
setTimeout(() => {
    $('.stat-box').css('pointer-events', 'auto');
}, 300);
</script>
<script>
function loadCandidates(jobId, type, stage = '') {

    const panel   = document.getElementById('candidate-panel-' + jobId);
    const cacheKey = `${jobId}_${type}_${stage}`;

    /* ===============================
       CACHE HIT
    =============================== */
    if (responseCache[cacheKey]) {
        panel.innerHTML = responseCache[cacheKey];
        return;
    }

    /* ===============================
       ABORT PREVIOUS REQUEST (PER JOB)
    =============================== */
    if (fetchControllers[jobId]) {
        fetchControllers[jobId].abort();
    }

    fetchControllers[jobId] = new AbortController();

    /* ===============================
       SKELETON LOADER
    =============================== */
    panel.innerHTML = skeletonTable();

    /* ===============================
       FETCH
    =============================== */
    const params = new URLSearchParams({
        job_request_id: jobId,
        filter_type: type,
        stage_id: stage
    });

    fetch(`{{ route('monitoring_candidate_list') }}?${params}`, {
        signal: fetchControllers[jobId].signal
    })
    .then(res => res.text())
    .then(html => {

        // cache response
        responseCache[cacheKey] = html;

        panel.innerHTML = html;
    })
    .catch(err => {
        if (err.name !== 'AbortError') {
            panel.innerHTML = `
                <div class="text-danger text-center py-4">
                    Failed to load data
                </div>
            `;
        }
    })
    .finally(() => {
        delete fetchControllers[jobId];
    });
}

function clearJobCache(jobId) {
    Object.keys(responseCache).forEach(key => {
        if (key.startsWith(jobId + '_')) {
            delete responseCache[key];
        }
    });
}
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {

    let selectedApplicant = null;

    /* ===============================
       OPEN MODALS (GLOBAL)
    =============================== */
    window.openShortlistModal = function (id, name, email, stageName = '') {
        selectedApplicant = id;

        document.getElementById('sl-name').innerText  = name;
        document.getElementById('sl-email').innerText = email;
        document.getElementById('sl-stage').innerText = stageName;

        resetShortlistModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('shortlistModal')
        ).show();
    };

    window.openRejectModal = function (id, name, email, stageName = '') {
        selectedApplicant = id;

        document.getElementById('rjct-name').innerText  = name;
        document.getElementById('rjct-email').innerText = email;
        document.getElementById('rjct-stage').innerText = stageName;

        resetRejectModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('RejectModal')
        ).show();
    };

    window.openHireModal = function (id, name, email, stageName = '') {
        selectedApplicant = id;

        document.getElementById('hire-name').innerText  = name;
        document.getElementById('hire-email').innerText = email;
        document.getElementById('hire-stage').innerText = stageName;

        resetHireModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('hireModal')
        ).show();
    };

    /* ===============================
       RESET MODALS
    =============================== */
    function resetShortlistModal() {
        const agree = document.getElementById('sl-agree');
        const btn   = document.getElementById('sl-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }
    function resetRejectModal() {
        const agree = document.getElementById('rjct-agree');
        const btn   = document.getElementById('rjct-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }

    function resetHireModal() {
        const agree = document.getElementById('hire-agree');
        const btn   = document.getElementById('hire-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }

    /* ===============================
       CHECKBOX ENABLE/DISABLE
    =============================== */
    document.getElementById('sl-agree').addEventListener('change', function () {
        document.getElementById('sl-confirm').disabled = !this.checked;
    });
    document.getElementById('rjct-agree').addEventListener('change', function () {
        document.getElementById('rjct-confirm').disabled = !this.checked;
    });

    document.getElementById('hire-agree').addEventListener('change', function () {
        document.getElementById('hire-confirm').disabled = !this.checked;
    });

    /* ===============================
       SUBMIT SHORTLIST
    =============================== */
    document.getElementById('sl-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Processing...';

        fetch("{{ route('hr.shortlist.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload();
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Shortlist Candidate';
            alert('Something went wrong. Please try again.');
        });
    });

     /* ===============================
       SUBMIT Reject
    =============================== */
    document.getElementById('rjct-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Processing...';

        var reject_reason = $('#reject_reason').val().trim();
        var other_reason = $('#other_reason').val().trim();

        fetch("{{ route('hr.reject.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant,
                reject_reason: reject_reason,
                other_reason: other_reason,
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload();
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Reject Candidate';
            alert('Something went wrong. Please try again.');
        });
    });

    /* ===============================
       SUBMIT HIRE
    =============================== */
    document.getElementById('hire-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Hiring...';

        fetch("{{ route('hr.hire.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload()
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Hire Candidate';
            alert('Something went wrong. Please try again.');
        });
    });

});
</script>
<script>
    function toggleAddSpam(value) {
          var ReasonDiv = document.getElementById('reason_div');
          var ReasonText = document.getElementById('reason_text');
          var CommentsDiv = document.getElementById('comments_div');
          var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
          var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;
    
          if (value == '1') {
              ReasonDiv.style.display = 'block';
              ReasonText.setAttribute('required', 'required');
          } else {
              ReasonDiv.style.display = 'none';
              ReasonText.removeAttribute('required');
          }
    
          if (commentsCheck == '1') {
              CommentsDiv.style.display = 'block';
          } else {
              CommentsDiv.style.display = 'none';
          }
      }
</script>
<!-- ALTER TABLE `egc_interview_schedule` ADD `hired_applicant_ids` TEXT NULL AFTER `status`;
ALTER TABLE `egc_applicant` ADD `hiring_status` INT(11) NULL DEFAULT '0' AFTER `shortlist_check`;
ALTER TABLE `egc_applicant` ADD `hiring_details` TEXT NULL AFTER `hiring_status`; -->

@endsection
