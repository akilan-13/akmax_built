<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrientationStagingModel extends Model
{
    use HasFactory;
    public $table      = "egc_orientation_staging";
    public $primaryKey = 'sno';


    protected $fillable = [
        'orientation_staging_name',
        'schedule_duration',
        'duration_type',
        'score_check',
        'evaluation_check',
        'emoji',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}