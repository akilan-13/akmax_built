<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InteviewModeModel extends Model {
    use HasFactory;
    public $table      = 'egc_interview_mode';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'interview_mode_name',
        'mode_icon',
        'interview_mode_desc',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}