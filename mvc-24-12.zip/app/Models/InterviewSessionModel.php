<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewSessionModel extends Model
{
  use HasFactory;
  protected $table = 'egc_interview_session';
    protected $primaryKey = 'sno';
    public $timestamps = true;

    protected $fillable = [
        'interview_schedule_id',
        'interview_schedule_stage_id',
        'tab_switch_count',
        'candidate_id',
        'session_token',
        'started_at',
        'completed_at',
        'current_stage_order',
        'status',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by'
    ];
}