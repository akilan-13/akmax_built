<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InteviewCategoryModel extends Model {
    use HasFactory;
    public $table      = 'egc_interview_category';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'interview_category_name',
        'category_icon',
        'interview_category_desc',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}