<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffTimestampModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_timestamp';
    protected $primaryKey = 'sno';
    public $timestamps = true;

    protected $fillable = [
        'time_sheet_date', 'staff_timestamp_reports','created_by', 'updated_by',
    ];

}