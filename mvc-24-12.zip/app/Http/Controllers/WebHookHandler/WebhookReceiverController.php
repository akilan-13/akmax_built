<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\SpecialRequirementModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Events\JobRequestEvent;

class WebhookReceiverController extends Controller
{

   
 // UserRole Webhook Start
    public function AddJobRequestHook(Request $request)
    {
            // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                // Retrieve the payload and decode it
            $payload = $request->all();
                    // Check if the payload contains a JSON-encoded string (as your logs suggest)
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }

            // Log the decoded payload
            \Log::info('Decoded Payload:', $payload);

            // Validate payload
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
        
        $category_check = JobRequestModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        $branchData = DB::table('egc_branch')->where('entity_id',$payload['entity_id'])->where('erp_branch_id', $payload['branch_id'])->first();

        $branch_id =$branchData ? $branchData->sno :0;
        $helper = new \App\Helpers\Helpers();

        $job_role_id = $helper->get_sno_by_erpId($payload['job_role_id'], 'egc_job_role', 'erp_job_role_id',$payload['entity_id']);
        $erp_special_requirements = json_decode($payload['special_requirements'] ?? '[]', true);
        $special_requirements_ids = [];
        $special_requirements_ids = $helper->getSnosByArrayOfErpIds($erp_special_requirements, 'egc_special_requirements', 'erp_requirement_id',$payload['entity_id']);
        $special_requirements_ids=$special_requirements_ids ? json_encode($special_requirements_ids) : null;
        $department = JobRequestModel::updateOrCreate(
            [
                'erp_job_request_id' => $uuid,
                'company_id'    => $payload['company_id'],
                'entity_id'    => $payload['entity_id'],

            ],  // ✅ match by UUID, not ERP id
            [
                'job_request_id'    => $payload['job_request_id'],
                'company_type'    => 2,
                'branch_id'        => $branch_id,
                'job_role_id'        => $job_role_id,
                'special_requirements'        => $special_requirements_ids,
                'erp_job_role_id'        => $payload['job_role_id'],
                'erp_special_requirements'        => $payload['special_requirements'],
                'job_role_name'        => null,
                'min_salary'  => $payload['min_salary'],
                'max_salary'  => $payload['max_salary'],
                'vacancy_count'  => $payload['vacancy_count'],
                'exp_type_ids'  => $payload['exp_type_ids'],
                'experience'  => $payload['experience'],
                'closing_date'  => $payload['closing_date'],
                'skill_required'  => $payload['skill_required'],
                'job_description'  => $payload['job_description'],
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        broadcast(new JobRequestEvent($department));

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

    public function UpdateJobRequestHook(Request $request)
    {
            // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                // Retrieve the payload and decode it
            $payload = $request->all();
                    // Check if the payload contains a JSON-encoded string (as your logs suggest)
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }

            // Log the decoded payload
            \Log::info('Decoded Payload:', $payload);

            // Validate payload
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }

            $updateJobRequest = JobRequestModel::where('erp_job_request_id',$uuid)
                            ->where('company_id',$payload['company_id'])
                            ->where('entity_id',$payload['entity_id'])
                            ->first();

                if($updateJobRequest){
                    $updateJobRequest->status=$payload['status'];
                    $updateJobRequest->update();
                }
            
             broadcast(new JobRequestEvent($updateJobRequest));
        return response()->json([
            'ok'  => true,
            'sno' => $updateJobRequest->sno, // auto-increment from your DB
        ], 200);
    }

    
    
    // Job Position Webhook End


    public function AddSpecialRequirementHook(Request $request)
    {
            // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                // Retrieve the payload and decode it
            $payload = $request->all();
                    // Check if the payload contains a JSON-encoded string (as your logs suggest)
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }

            // Log the decoded payload
            \Log::info('Decoded Payload:', $payload);

            // Validate payload
            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }

        $category_check = SpecialRequirementModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();



        $department = SpecialRequirementModel::updateOrCreate(
            [
                'erp_requirement_id' => $uuid,
                'company_id'    => $payload['company_id'],
                'entity_id'    => $payload['entity_id'],

            ],  // ✅ match by UUID, not ERP id
            [
                'company_type'    => 2,
                'requirement_name'        => $payload['requirement_name'],
                'requirement_desc'  => $payload['requirement_desc'],
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }


   


}
