<?php

namespace App\Http\Controllers\settings\business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use App\Models\CompanyModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\ManageEntityModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class BusinessDepartment extends Controller
{

  // management Department
  public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = DepartmentModel::where('egc_department.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_department.*','egc_entity.entity_name','egc_company.company_name','egc_entity.entity_short_name', 'egc_company.company_base_color')
      ->join('egc_company', 'egc_department.company_id', 'egc_company.sno')
      ->join('egc_entity', 'egc_department.entity_id', 'egc_entity.sno')
      ->where('egc_department.company_type',2);
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_desc', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_department.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'department_name' => $item->department_name,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'entity_short_name' => $item->entity_short_name,
                    'company_base_color' => $item->company_base_color,
                    'department_desc' => $item->department_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
    $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.settings.business.department.department_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
      'company_list' => $company_list
    ]);
  }



  public function List(Request $request)
  {
    
    $entity_id=$request->entity_id;
    $Department = DepartmentModel::where('status', 0)->where('entity_id',$entity_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function BranchDepartList(Request $request)
  {

    $branch_id = $request->branch_id;
    // ->where('branch_id', $branch_id)
    $Department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $staff =  DepartmentModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Department Status Updated Successfully!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'department_name' => 'required_if:erp_department_name,new_department'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $company_id = $request->company_id;
      $entity_id = $request->entity_id;

      // If user selected "other", take manual input
      if ($request->erp_department_name == 'new_department') {
          $department_name = $request->department_name;
          $erp_department_id = $request->erp_department_id;
      }
      else {
          $department_name = $request->department_name_hidden;
          $erp_department_id = $request->erp_department_name; // sno from ERP
      }

 
      
      $department_desc = $request->department_desc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', $department_name)->where('company_type', 2)->where('entity_id', $entity_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = DepartmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $department_id = 'DP-0001/' . $year;
        } else {

          $data = $category_check->department_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $requestID = sprintf('DP-%04d', $next_number);

          $year = substr(date('y'), -2);
          $department_id = $requestID . '/' . $year;
        }

        $add_department = new DepartmentModel();
        $add_department->department_id = $department_id;
        $add_department->company_type = 2;
        $add_department->company_id = $company_id;
        $add_department->entity_id = $entity_id;
        $add_department->erp_department_id = $erp_department_id;
        $add_department->department_name = $department_name;
        $add_department->department_desc = $department_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          if($request->erp_department_name == 'new_department'){
              $this->dispatchWebhooks($add_department, $user_id,'Department_Hook');
          }else{
            $this->dispatchWebhooks($add_department, $user_id,'Update_Department_uuid');
          }
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'department added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = DepartmentModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Department not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Department fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'department_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $department_name = $request->department_name;
      $department_desc = $request->department_desc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', $department_name)->where('company_type', 2)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = DepartmentModel::where('sno', $sno)->first();
        $up_department->department_name = $department_name;
        $up_department->department_desc = $department_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Department updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  // Old Department Data Add
   public function businessDepartmentAdd(Request $request)
  {
      // 🧩 Step 1: Validate input
      $validator = Validator::make($request->all(), [
          'company_id' => 'required|integer',
          'entity_id'  => 'required|integer'
      ]);

      if ($validator->fails()) {
          return response()->json([
              'status'    => 401,
              'message'   => 'Incorrect format input fields',
              'error_msg' => $validator->messages()->get('*'),
              'data'      => null,
          ], 200);
      }

      $company_id = $request->company_id;
      $entity_id  = $request->entity_id;

      // 🧩 Step 2: Get entity base URL
      $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

      if (!$entity_url) {
          return response()->json([
              'status'  => 404,
              'message' => 'Entity URL not found for the given entity ID.',
          ], 200);
      }

      // 🧩 Step 3: Call external API using Http facade
      $verify_key = 'egcsecret2030datagetapierp';
      $api_url = rtrim($entity_url, '/') . '/api/department_data_get';

      try {
          $response = Http::get($api_url, ['auth_key' => $verify_key]);

          if (!$response->successful()) {
              return response()->json([
                  'status'  => 500,
                  'message' => 'Failed to fetch Department from entity API.',
                  'error'   => $response->body(),
              ], 200);
          }

          $DepartmentData = $response->json()['data'] ?? [];

          if (empty($DepartmentData)) {
              return response()->json([
                  'status'  => 404,
                  'message' => 'No user roles found in API response.',
              ], 200);
          }

          // 🧩 Step 4: Loop and insert roles
          foreach ($DepartmentData as $Department) {
              $department_name = ucfirst($Department['department_name'] ?? null);
              if (!$department_name) continue;

              $company_type = 2;
              $erp_department_id = $Department['sno'] ?? 0;
              $user_id = $request->user()->user_id ?? null;

              // 🔍 Check if role already exists
              $chk = DepartmentModel::where('department_name', $department_name)
                  ->where('entity_id', $entity_id)
                  ->where('status', '!=', 2)
                  ->first();

              if ($chk) continue; // skip duplicates

              // 🧩 Step 5: Generate next role_id
              $last = DepartmentModel::where('status', '!=', 2)
                  ->orderBy('sno', 'desc')
                  ->first();

                  if (!$last) {

                    $year = substr(date('y'), -2);
                    $department_id = 'DP-0001/' . $year;
                  } else {

                    $data = $last->department_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $requestID = sprintf('DP-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $department_id = $requestID . '/' . $year;
                  }

              

              // 🧩 Step 6: Save to DB
              $add_department = new DepartmentModel();
              $add_department->department_id          = $department_id;
              $add_department->company_type     = $company_type;
              $add_department->company_id       = $company_id;
              $add_department->entity_id        = $entity_id;
              $add_department->erp_department_id      = $erp_department_id;
              $add_department->department_name        = $department_name;
              $add_department->created_by       = 1;
              $add_department->updated_by       = 1;
              $add_department->save();

              $this->dispatchWebhooks($add_department, $user_id=1,'Update_Department_uuid');
          }

          return response()->json([
              'status'  => 200,
              'message' => 'Business Department imported successfully.',
          ]);

      } catch (\Throwable $e) {
          // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
          return response()->json([
              'status'  => 500,
              'message' => 'Something went wrong while fetching Department.',
              'error'   => $e->getMessage(),
          ], 200);
      }
  }

  protected function dispatchWebhooks(DepartmentModel $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast->entity_id)->first();
          if($webhook){
              $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => get_class($broadcast),
                'dispatchable_id' => $broadcast->sno,
                'message_uuid' => $broadcast->sno,
                'payload' => $broadcast->toArray(),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // broadcast creation once
            broadcast(new WebhookDispatchedEvent($dispatch));
           
            // enqueue the job
            try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                if (!$result['success']) {
                    // If fails, dispatch to queue
                    SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
            
          }
          
  }
    public function AddOldData(Request $request)
    {

      // return $request;
      // Validate incoming request
      $helper = new \App\Helpers\Helpers();
      $validator = Validator::make($request->all(), [
        'staff_company_name' => 'required',
        'staff_entity_name' => 'required',
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id ?? 1;
      
      $company_type=2;
      $company_id=$request->staff_company_name;
      $entity_id=$request->staff_entity_name;

      $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

        if (!$entity_url) {
            return response()->json([
                'status'  => 404,
                'message' => 'Entity URL not found for the given entity ID.',
            ], 200);
        }

        // 🧩 Step 3: Call external API using Http facade
        $verify_key = 'egcsecret2030datagetapierp';
        $api_url = rtrim($entity_url, '/') . '/api/department_data_get';

        try {
            $response = Http::get($api_url, ['auth_key' => $verify_key]);

            if (!$response->successful()) {
                return response()->json([
                    'status'  => 500,
                    'message' => 'Failed to fetch Data from entity API.',
                    'error'   => $response->body(),
                ], 200);
            }

            $ErpData = $response->json()['data'] ?? [];
            $filteredErpData = array_filter($ErpData, function($staff) {
                return $staff['external_uuid'] == null;
            });
            $filteredErpData = array_values($filteredErpData);

            // return $filteredErpData;


            if (empty($ErpData)) {
                return response()->json([
                    'status'  => 404,
                    'message' => 'No user roles found in API response.',
                ], 200);
            }

            // 🧩 Step 4: Loop and insert roles
            foreach ($ErpData as $staff) {

                $department_name = $staff['department_name'] ?? null;
                if (!$department_name) continue;

                $erp_department_id = $staff['sno'] ?? null;
                if (!$erp_department_id) continue;

                $company_type = 2;

                // 🔍 Check if role already exists
                $chk = DepartmentModel::where('erp_department_id', $erp_department_id)
                    ->where('entity_id',$entity_id)
                    ->where('status', '!=', 2)
                    ->first();

                if ($chk){
                    $chk->department_name=$department_name;
                    $chk->update();
                    $this->dispatchWebhooks($chk, $user_id=1,'Update_Department_uuid');
                    continue; 
                }else{
                  $department_desc = $staff['department_desc'];
                  $user_id = $request->user()->user_id;
                
                  $last = DepartmentModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();

                    if (!$last) {

                      $year = substr(date('y'), -2);
                      $department_id = 'DP-0001/' . $year;
                    } else {

                      $data = $last->department_id;
                      $slice = explode('/', $data);
                      $result = preg_replace('/[^0-9]/', '', $slice[0]);

                      $next_number = (int) $result + 1;
                      $requestID = sprintf('DP-%04d', $next_number);

                      $year = substr(date('y'), -2);
                      $department_id = $requestID . '/' . $year;
                    }

                    $add_department = new DepartmentModel();
                    $add_department->department_id = $department_id;
                    $add_department->company_type = 2;
                    $add_department->company_id = $company_id;
                    $add_department->entity_id = $entity_id;
                    $add_department->erp_department_id = $erp_department_id;
                    $add_department->department_name = $department_name;
                    $add_department->department_desc = $department_desc;
                    $add_department->created_by = $user_id;
                    $add_department->updated_by = $user_id;

                    $add_department->save();

                  

                    if ($add_department) {
                      $this->dispatchWebhooks($add_department, $user_id=1,'Update_Department_uuid');
                    }
                }
            }

            return response()->json([
                'status'  => 200,
                'message' => 'Business Department imported successfully.',
            ]);

        } catch (\Throwable $e) {
            // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
            return response()->json([
                'status'  => 500,
                'message' => 'Something went wrong while fetching Department.',
                'error'   => $e->getMessage(),
            ], 200);
        }
    }

    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }

     
  
}