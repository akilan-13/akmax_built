<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageCandidate extends Controller
{
  public function index()
  {
    return view('content.hr_management.hr_recruiter.manage_candidate.candidate_list');
  }

}
