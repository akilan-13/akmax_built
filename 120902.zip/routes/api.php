<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VideoSubmissionController;
use App\Http\Controllers\control_panel\user_management\UserRole;
use App\Http\Controllers\settings\business\BusinessDepartment;
use App\Http\Controllers\WebHookHandler\WebhookReceiverController;
use App\Http\Controllers\hr_management\hr_recruiter\JobController;
use App\Http\Controllers\EmployeeApp\EmployeeAppController;
use App\Http\Controllers\hr_management\hr_enroll\ManageAttendance;
use App\Http\Controllers\hr_management\hr_recruiter\BulkApplicantAIController;
use App\Http\Controllers\Api\SecurityApiController;
use App\Http\Controllers\hr_management\hr_recruiter\CarrerFormController;
use App\Http\Controllers\EmployeeApp\CallerPilot;

use App\Http\Controllers\TableManagerController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('/upload-video', [VideoSubmissionController::class, 'upload']);

Route::post('/add_business_userrole', [UserRole::class, 'businessAdd']);
Route::post('/add_business_old_department', [BusinessDepartment::class, 'businessDepartmentAdd']);
Route::post('/webhooks/add_job_request', [WebhookReceiverController::class, 'AddJobRequestHook']);
Route::post('/webhooks/update_job_request', [WebhookReceiverController::class, 'UpdateJobRequestHook']);
Route::post('/webhooks/add_special_requirement', [WebhookReceiverController::class, 'AddSpecialRequirementHook']);

Route::get('google/auth-url', [JobController::class, 'getAuthUrl']);
Route::post('google/token', [JobController::class, 'getRefreshToken']);
Route::get('/google/callback', [JobController::class, 'handleCallback']);
Route::post('/google/create-folder', [JobController::class, 'createDriveFolder']);
Route::match(['get','post'],'/google/upload_recruit_resume', [JobController::class, 'UploadRecruiterResume']);
Route::post('/google/folder/public-viewer', [JobController::class, 'makeFolderPublic']);



// Mobile App
Route::post('/employee_login', [EmployeeAppController::class, 'EmployeeLogin']);
Route::post('/verify_otp_staff', [EmployeeAppController::class, 'verifyOtp']);
// Route::post('/staff_tokken_verify', [EmployeeAppController::class, 'verifyOtp']);
  Route::middleware(['auth.jwt'])->group(function () {

        Route::get('/get_staff_data', [EmployeeAppController::class, 'getStaffData']);
        Route::get('/get_staff_today_check_in', [EmployeeAppController::class, 'getTodayCheckIN']);
        Route::get('/get_staff_face_id', [EmployeeAppController::class, 'getStaffFaceId']);
        Route::post('/verify_checkin_location', [EmployeeAppController::class, 'verifyCheckinLocation']);
        Route::post('/confirm_checkin', [EmployeeAppController::class, 'confirmCheckin']);
        Route::post('/get_unread_notification_count', [EmployeeAppController::class, 'GetUnreadNotificationCount']);

        Route::get('/get_month_staff_attendance_count', [EmployeeAppController::class, 'getAttendanceCount']);
         Route::get('/get_year_holiday_list', [EmployeeAppController::class, 'getYearHolidayList']);
         Route::get('/get_month_leave_perm_request', [EmployeeAppController::class, 'getLeavePermRequest']);
         Route::get('/get_month_staff_attendance_list', [EmployeeAppController::class, 'getAttendanceList']);
         Route::get('/get_leave_permission_details', [EmployeeAppController::class, 'GetLeavePermissionDetails']);
         Route::get('/get_staff_dashboard_points', [EmployeeAppController::class, 'getDashboardPoint']);
        Route::get('/get_staff_dashboard_overview', [EmployeeAppController::class, 'getDashboardOverview']);
          Route::get('/get_staff_payslip_list', [EmployeeAppController::class, 'getStaffPayslipList']);
              Route::get('/get_staff_payslip_detail_by_id', [EmployeeAppController::class, 'getStaffPayslipDetailById']);
        Route::get('/get_hr_support_category_list', [EmployeeAppController::class, 'getHrSupportCategoryList']);
        Route::get('/get_hr_department_ticket_list', [EmployeeAppController::class, 'getHrDepartmentTicketList']);
        Route::get('/get_training_list', [EmployeeAppController::class, 'trainingList']);
        Route::get('/get_ticket_details_by_id', [EmployeeAppController::class, 'getTicketDetailsById']);

        Route::get('/staff_notification_list', [EmployeeAppController::class, 'NotificationList']);
        Route::post('/staff_clear_all', [EmployeeAppController::class, 'ClearAllNotifications']);
        Route::post('/staff_clear_notification/{id}', [EmployeeAppController::class, 'ClearSingleNotification']);
        Route::post('/staff_mark_read_all', [EmployeeAppController::class, 'MarkasReadAllNotifications']);
        Route::post('/staff_read_notification/{id}', [EmployeeAppController::class, 'ReadSingleNotification']);
        Route::post('/confirm_checkout', [EmployeeAppController::class, 'confirmCheckOut']);
         Route::post('/add_leave_permission_request', [EmployeeAppController::class, 'AddLeavePermissionRequest']);
         Route::post('/add_hr_support_ticket', [EmployeeAppController::class, 'addHrSupportTicket']);
         Route::post('/update_staff_face_id', [EmployeeAppController::class, 'UpdateFaceId']);
         Route::post('/close_support_ticket', [EmployeeAppController::class, 'closeSupportTicket']);

  });
    Route::get('/daily_staff_checkin_qr', [ManageAttendance::class, 'DailyAttendanceCheckQr']);
    Route::get('/get_leave_reason_list', [EmployeeAppController::class, 'LeaveAndPermissionReasonList']);


    Route::post('/ai/bulk-role-matching',[BulkApplicantAIController::class, 'bulkRoleMatching']);


// athenticator QR 
Route::post('/security/authenticator_login', [SecurityApiController::class, 'EmployeeLogin']);
Route::post('/security/verify_otp', [SecurityApiController::class, 'verifyOtp']);

 Route::middleware(['auth.jwtsecurity'])->prefix('security')->name('security.')->group(function () {
    // Register Device
    Route::post('/device/register',[SecurityApiController::class, 'registerDevice']);
    /* Scan QR */
    Route::post('/scan',[SecurityApiController::class, 'scan'])->name('scan');
    /* Approve Request */
    Route::post('/approve', [SecurityApiController::class, 'approve'] )->name('approve');
    /*Verify PIN in ERP  */
    Route::post('/verify-pin', [SecurityApiController::class, 'verifyPin'] )->name('verify-pin');
    /* Session Status ERP */
    Route::get('/status',[SecurityApiController::class, 'status'])->name('status');
    /* Close Session ERP / APK */
    Route::post('/close', [SecurityApiController::class, 'close'])->name('close');
    Route::get('/get_staff_profile', [SecurityApiController::class, 'getStaffData']);
});


// recruiter 
Route::post('/save_job_application', [CarrerFormController::class, 'submitJobApplication'])->name('save_job_application');
Route::get('/source_list', [CarrerFormController::class, 'SourceList'])->name('source_list');
Route::get('/major_list', [CarrerFormController::class, 'MajorList'])->name('major_list');
Route::get('/job_form_questions', [CarrerFormController::class, 'JobFormQuestions'])->name('job_form_questions');


// caller Pilot App 
Route::prefix('sales_app')->group(function () {
    Route::post('/staff_login', [CallerPilot::class, 'StaffLogin']);
    Route::post('/verify_otp_staff', [CallerPilot::class, 'verifyOtp']);

    Route::middleware(['cugauth.jwt'])->group(function () {
        Route::get('/staff_details', [CallerPilot::class, 'staffDetails']);
        Route::get('/lead_list', [CallerPilot::class, 'LeadList']);
        Route::get('/lead_detail_by_id', [CallerPilot::class, 'LeadDetail']);
        Route::get('/lead_source_list', [CallerPilot::class, 'leadSourceList']);
        Route::get('/product_list', [CallerPilot::class, 'productList']);
        Route::get('/followup_list', [CallerPilot::class, 'FollowupList']);
        Route::post('/followup_add', [CallerPilot::class, 'FollowupAdd']);
        Route::post('/followup_detail', [CallerPilot::class, 'FollowupDetail']);
        Route::post('/followup_reschedule', [CallerPilot::class, 'FollowupReschedule']);
        Route::post('/followup_close', [CallerPilot::class, 'FollowupClose']);
        Route::get('/team_call_list', [CallerPilot::class, 'TeamCallList']);
        Route::get('/team_call_by_staff_id', [CallerPilot::class, 'TeamCallByStaffId']);
        Route::get('/lead_dashboard_card', [CallerPilot::class, 'LeadDashboardCard']);
        Route::get('/followup_dashboard', [CallerPilot::class, 'FollowupDashboard']);
        Route::get('/team_call_dashboard', [CallerPilot::class, 'TeamCallDashboard']);
        Route::get('/call_dashboard', [CallerPilot::class, 'CallDashboard']);
        Route::get('/followup_reason_list', [CallerPilot::class, 'followupReasonList']);
        Route::post('/call_tracker_log_save', [CallerPilot::class, 'CallTrackerLogSave']);
        Route::get('/staff_call_log_list', [CallerPilot::class, 'StaffCallLogList']);
        Route::post('/contact_call_history_by_phone', [CallerPilot::class, 'ContactCallHistoryByPhone']);
        Route::post('/contact_detail_by_phone', [CallerPilot::class, 'ContactDetailByPhone']);
        Route::get('/role_check_by_user', [CallerPilot::class, 'roleCheckByUserId']);
        Route::post('/cug_staff_last_login', [CallerPilot::class, 'cugStaffLastLogin']);
        Route::post('/update_online_status', [CallerPilot::class, 'updateOnlineStatus']);
        Route::post('/application_alive', [CallerPilot::class, 'applicationAlive']);
        Route::get('/this_week_call_bar_chart_count', [CallerPilot::class, 'thisWeekCallBarChartCount']);
        Route::post('/update_app_version', [CallerPilot::class, 'updateAppVersion']);
        Route::get('/staff_notification_list', [CallerPilot::class, 'NotificationList']);
      });

});