<?php

namespace App\Imports;

use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

class TargetSheetImport implements ToCollection
{

    private $entityId;
    private $year;

    public function __construct($entityId, $year)
    {
        $this->entityId = $entityId;
        $this->year = $year;
    }


    public function collection(Collection $rows)
    {
        DB::beginTransaction();

        try {

            $weekSettings = DB::table('egc_target_week_settings')
                ->where('status', 0)
                ->orderBy('week_no')
                ->get();

            if ($weekSettings->isEmpty()) {
                throw new \Exception('Week settings not configured');
            }


            $yearCache = [];
            $quarterCache = [];
            $monthCache = [];

            $affectedYearIds = [];
            $affectedQuarterIds = [];
            $affectedMonthIds = [];

            $rows = $rows->skip(1);
            $year = $this->year;
            \Log::info('Sheet Entity ID: ' . $this->entityId);
            \Log::info('Sheet year: ' . $this->year);


            foreach ($rows as $row) {



                $row = $row->toArray();
                \Log::info('RAW ROW:', $row);

                $row = array_map(fn($v) => is_string($v) ? trim($v) : $v, $row);

                if (collect($row)->filter()->isEmpty()) continue;

                // ===== ENTITY =====
                $entityId = $this->entityId;

                // ===== YEAR =====
                $year = $this->year;

                if ($year < 2000 || $year > 2100) continue;


                // ===== QUARTER (carry forward) =====
                static $currentQuarter = null;

                if (!empty($row[0])) {
                    preg_match('/[1-4]/', $row[0], $matches);
                    $currentQuarter = isset($matches[0]) ? 'Q' . $matches[0] : null;
                }

                $quarter = $currentQuarter;

                if (!$quarter) continue;


                // ===== DATE → MONTH =====
                $dateRaw = $row[1];

                if (!is_numeric($dateRaw)) continue;

                try {
                    $date = Carbon::instance(
                        ExcelDate::excelToDateTimeObject($dateRaw)
                    );
                } catch (\Exception $e) {
                    continue;
                }

                $monthNumber = $date->month;


                // ===== VALUES =====
                $target = floatval($row[2] ?? 0);
                $pre    = floatval($row[3] ?? 0);
                $post   = floatval($row[4] ?? 0);

                // ================= FINANCIAL YEAR =================
                $actualYear = in_array($monthNumber, [1, 2, 3]) ? $year + 1 : $year;

                // ===== YEAR =====
                $yearKey = $entityId . '_' . $year;

                \Log::info('FINAL DATA', [
                    'entity' => $entityId,
                    'year' => $year,
                    'quarter' => $quarter,
                    'month' => $monthNumber,
                    'target' => $target
                ]);
                // \Log::info('RAW ROW:', $row);


                if (!isset($yearCache[$yearKey])) {
                    $yearCache[$yearKey] = YearlyTargetModel::updateOrCreate(
                        [
                            'entity_id' => $entityId,
                            'branch_id' => $entityId,
                            'year' => $year
                        ],
                        [
                            'updated_at' => now() // optional
                        ]
                    );
                }

                $yearly = $yearCache[$yearKey];
                $affectedYearIds[$yearly->id] = $yearly->id;

                // ===== QUARTER =====
                $quarterKey = $yearly->id . '_' . $quarter;
                $quarterNumber = (int) str_replace('Q', '', $quarter);

                if (!isset($quarterCache[$quarterKey])) {
                    $quarterCache[$quarterKey] = QuarterTargetModel::firstOrCreate([
                        'yearly_id' => $yearly->id,
                        'quarter' => $quarter,
                        'financial_year_id' => $quarterNumber,
                        'financial_year' => $actualYear
                    ]);
                }

                $qModel = $quarterCache[$quarterKey];
                $affectedQuarterIds[$qModel->id] = $qModel->id;

                // ===== MONTH =====
                $monthKey = $qModel->id . '_' . $monthNumber;

                if (!isset($monthCache[$monthKey])) {
                    $monthCache[$monthKey] = MonthTargetModel::firstOrCreate([
                        'quarter_id' => $qModel->id,
                        'month' => $monthNumber
                    ]);
                }

                $mModel = $monthCache[$monthKey];
                $affectedMonthIds[$mModel->id] = $mModel->id;

                $remainingPre = $pre;
                $remainingPost = $post;



                foreach ($weekSettings as $setting) {

                    $percentage = (float) $setting->percentage;

                    /*
                    |--------------------------------------------------------------------------
                    | TARGET CALCULATION
                    |--------------------------------------------------------------------------
                    */

                    $weekTarget =
                        ($target * $percentage) / 100;

                    /*
                    |--------------------------------------------------------------------------
                    | PRE SALE
                    |--------------------------------------------------------------------------
                    */

                    $weekPre = round(
                        ($pre * $percentage) / 100
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | POST SALE
                    |--------------------------------------------------------------------------
                    */

                    $weekPost = round(
                        ($post * $percentage) / 100
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | LAST WEEK BALANCE FIX
                    |--------------------------------------------------------------------------
                    */

                    if ($setting->week_no == 4) {

                        $weekPre = $remainingPre;
                        $weekPost = $remainingPost;
                    }

                    $remainingPre -= $weekPre;
                    $remainingPost -= $weekPost;

                    /*
                    |--------------------------------------------------------------------------
                    | WEEK DATES
                    |--------------------------------------------------------------------------
                    */

                    [$startDate, $endDate] =
                        $this->getWeekDatesFromSetting(
                            $monthNumber,
                            $actualYear,
                            $setting
                        );

                    /*
                    |--------------------------------------------------------------------------
                    | SAVE
                    |--------------------------------------------------------------------------
                    */

                    WeekTargetModel::updateOrCreate(
                        [
                            'month_id' => $mModel->id,
                            'week' => $setting->week_no
                        ],
                        [
                            'percentage' => $percentage,
                            'target_amount' => $weekTarget,
                            'pre_sale' => $weekPre,
                            'post_sale' => $weekPost,
                            'week_start_date' => $startDate,
                            'week_end_date' => $endDate
                        ]
                    );
                }
            }

            // ================= TOTAL UPDATE =================
            $this->updateTotalsOptimized(
                array_values($affectedMonthIds),
                array_values($affectedQuarterIds),
                array_values($affectedYearIds)
            );

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    // ✅ WEEK DATE LOGIC
    private function getWeekDates($monthNumber, $year, $week)
    {
        $startDay = match ($week) {
            1 => 1,
            2 => 8,
            3 => 15,
            4 => 22,
            default => 1
        };

        $endDay = match ($week) {
            1 => 7,
            2 => 14,
            3 => 21,
            4 => Carbon::create($year, $monthNumber)->endOfMonth()->day,
            default => 7
        };

        $start = Carbon::create($year, $monthNumber, $startDay)->toDateString();
        $end   = Carbon::create($year, $monthNumber, $endDay)->toDateString();

        return [$start, $end];
    }

    private function getWeekDatesFromSetting(
        $monthNumber,
        $year,
        $setting
    ) {

        $startDay = (int) $setting->start_day;

        /*
    |--------------------------------------------------------------------------
    | END DAY
    |--------------------------------------------------------------------------
    */

        if ($setting->end_day === 'END') {

            $endDay = Carbon::create(
                $year,
                $monthNumber
            )->endOfMonth()->day;
        } else {

            $endDay = (int) $setting->end_day;
        }

        /*
    |--------------------------------------------------------------------------
    | DATE BUILD
    |--------------------------------------------------------------------------
    */

        $startDate = Carbon::create(
            $year,
            $monthNumber,
            $startDay
        )->toDateString();

        $endDate = Carbon::create(
            $year,
            $monthNumber,
            $endDay
        )->toDateString();

        return [$startDate, $endDate];
    }

    private function updateTotalsOptimized($monthIds, $quarterIds, $yearIds)
    {
        //  MONTH TOTALS (single query)
        $monthTotals = WeekTargetModel::whereIn('month_id', $monthIds)
            ->groupBy('month_id')
            ->selectRaw('month_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($monthTotals as $m) {
            MonthTargetModel::where('id', $m->month_id)->update([
                'target_amount' => $m->t ?? 0,
                'pre_sale' => $m->pre ?? 0,
                'post_sale' => $m->post ?? 0,
            ]);
        }

        //  QUARTER TOTALS
        $quarterTotals = MonthTargetModel::whereIn('quarter_id', $quarterIds)
            ->groupBy('quarter_id')
            ->selectRaw('quarter_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($quarterTotals as $q) {
            QuarterTargetModel::where('id', $q->quarter_id)->update([
                'target_amount' => $q->t ?? 0,
                'pre_sale' => $q->pre ?? 0,
                'post_sale' => $q->post ?? 0,
            ]);
        }

        //  YEAR TOTALS
        $yearTotals = QuarterTargetModel::whereIn('yearly_id', $yearIds)
            ->groupBy('yearly_id')
            ->selectRaw('yearly_id, SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
            ->get();

        foreach ($yearTotals as $y) {
            YearlyTargetModel::where('id', $y->yearly_id)->update([
                'total_target' => $y->t ?? 0,
                'total_pre_sale' => $y->pre ?? 0,
                'total_post_sale' => $y->post ?? 0,
            ]);
        }
    }

    // ✅ TOTAL CALCULATION
    private function updateTotals()
    {
        // MONTH TOTAL
        MonthTargetModel::all()->each(function ($month) {

            $totals = WeekTargetModel::where('month_id', $month->id)
                ->selectRaw('SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
                ->first();

            $month->update([
                'target_amount' => $totals->t ?? 0,
                'pre_sale' => $totals->pre ?? 0,
                'post_sale' => $totals->post ?? 0,
            ]);
        });

        // QUARTER TOTAL
        QuarterTargetModel::all()->each(function ($q) {

            $totals = MonthTargetModel::where('quarter_id', $q->id)
                ->selectRaw('SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
                ->first();

            $q->update([
                'target_amount' => $totals->t ?? 0,
                'pre_sale' => $totals->pre ?? 0,
                'post_sale' => $totals->post ?? 0,
            ]);
        });

        // YEAR TOTAL
        YearlyTargetModel::all()->each(function ($y) {

            $totals = QuarterTargetModel::where('yearly_id', $y->id)
                ->selectRaw('SUM(target_amount) as t, SUM(pre_sale) as pre, SUM(post_sale) as post')
                ->first();

            $y->update([
                'total_target' => $totals->t ?? 0,
                'total_pre_sale' => $totals->pre ?? 0,
                'total_post_sale' => $totals->post ?? 0,
            ]);
        });
    }
}
