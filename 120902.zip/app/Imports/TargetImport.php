<?php
namespace App\Imports;

use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\WeekTargetModel;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class TargetImport implements WithMultipleSheets
{

 public function sheets(): array
    {
        return [
            0 => new TargetSheetImport(),
            1 => new TargetSheetImport(),
            2 => new TargetSheetImport(),
            3 => new TargetSheetImport(),
            //  DO NOT include last sheet (summary)
        ];
    }
    // public function collection(Collection $rows)
    // {
    //     $headerSkipped = false;

    //     foreach ($rows as $row) {

    //         if (!$headerSkipped) {
    //             $headerSkipped = true;
    //             continue;
    //         }

    //         $entityId = $row[0];
    //         $year = $row[1];
    //         $quarter = $row[2];
    //         $month = $row[3];
    //         $week = $row[4];
    //         $percentage = $row[5];
    //         $target = $row[6];
    //         $pre = $row[7];
    //         $post = $row[8];

    //         // YEARLY
    //         $yearly = YearlyTargetModel::updateOrCreate(
    //             ['entity_id' => $entityId, 'year' => $year],
    //             []
    //         );

    //         // QUARTER
    //         $quarterData = QuarterTargetModel::updateOrCreate(
    //             ['yearly_id' => $yearly->id, 'quarter' => $quarter],
    //             []
    //         );

    //         // WEEK
    //         WeekTargetModel::updateOrCreate(
    //             [
    //                 'quarter_id' => $quarterData->id,
    //                 'month' => $month,
    //                 'week' => $week
    //             ],
    //             [
    //                 'percentage' => $percentage,
    //                 'target_amount' => $target,
    //                 'pre_sale' => $pre,
    //                 'post_sale' => $post
    //             ]
    //         );
    //     }
    // }
}