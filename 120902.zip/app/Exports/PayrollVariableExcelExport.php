<?php

namespace App\Exports;

use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;

use Maatwebsite\Excel\Events\AfterSheet;

class PayrollVariableExcelExport implements
    FromArray,
    WithTitle,
    WithStyles,
    WithEvents,
    WithColumnFormatting,
    WithCustomStartCell
{

    protected $payroll;

    public function __construct($payroll)
    {
        $this->payroll = $payroll;
    }

    public function title(): string
    {
        return 'Variable Report';
    }

    public function startCell(): string
    {
        return 'A3';
    }

    public function array(): array
    {
        $rows = [];

        /*
        |--------------------------------------------------------------------------
        | Header
        |--------------------------------------------------------------------------
        */

        $rows[] = [
            'S.No',
            'Staff Name',
            'Staff ID',
            'Salary Company',
            'Entity',
            'Salary Date',
            'Variable Amount'
        ];

        /*
        |--------------------------------------------------------------------------
        | Employee Rows
        |--------------------------------------------------------------------------
        */

        foreach ($this->payroll['rows'] as $index => $row) {

            $salaryDate = '';

            if (!empty($row['staff_salary_date'])) {
                $salaryDate = date('d-M-Y', strtotime($row['staff_salary_date']));
            }

            $rows[] = [
                $index + 1,
                $row['staff_name'] ?? '',
                $row['staff_id'] ?? '',
                $row['salary_company_name'] ?? '',
                $row['entity_name'] ?? '',
                $salaryDate,
                $row['variable'] ?? 0

            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Dynamic Total Row (Excel Filter Supported)
        |--------------------------------------------------------------------------
        */

        $firstDataRow = 4;
        $lastDataRow  = count($this->payroll['rows']) + 3;

        $rows[] = [
            '',
            'TOTAL',
            '',
            '',
            '',
            '',
            "=SUBTOTAL(9,G{$firstDataRow}:G{$lastDataRow})"

        ];

        return $rows;
    }
        /*
    |--------------------------------------------------------------------------
    | Styles
    |--------------------------------------------------------------------------
    */

    public function styles(Worksheet $sheet)
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | Report Title
            |--------------------------------------------------------------------------
            */

            1 => [

                'font' => [
                    'bold' => true,
                    'size' => 18,
                    'color' => [
                        'rgb' => 'FFFFFF'
                    ]
                ],

                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical'   => Alignment::VERTICAL_CENTER,
                ],

                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'rgb' => '1F4E78'
                    ]
                ]

            ],

            /*
            |--------------------------------------------------------------------------
            | Table Header
            |--------------------------------------------------------------------------
            */

            3 => [

                'font' => [
                    'bold' => true,
                    'color' => [
                        'rgb' => 'FFFFFF'
                    ]
                ],

                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'rgb' => '305496'
                    ]
                ],

                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical'   => Alignment::VERTICAL_CENTER,
                    'wrapText'   => true
                ]

            ]

        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Events
    |--------------------------------------------------------------------------
    */

    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function (AfterSheet $event) {

                $sheet = $event->sheet->getDelegate();

                $firstDataRow = 4;
                $lastDataRow  = count($this->payroll['rows']) + 3;
                $totalRow     = $lastDataRow + 1;

                /*
                |--------------------------------------------------------------------------
                | Report Title
                |--------------------------------------------------------------------------
                */

                $sheet->mergeCells('A1:G1');

                $sheet->setCellValue(
                    'A1',
                    'PAYROLL VARIABLE REPORT - ' . strtoupper($this->payroll['month'])
                );

                $sheet->getRowDimension(1)->setRowHeight(30);

                /*
                |--------------------------------------------------------------------------
                | Header Height
                |--------------------------------------------------------------------------
                */

                $sheet->getRowDimension(3)->setRowHeight(24);

                /*
                |--------------------------------------------------------------------------
                | Employee Row Height
                |--------------------------------------------------------------------------
                */

                for ($i = $firstDataRow; $i <= $lastDataRow; $i++) {
                    $sheet->getRowDimension($i)->setRowHeight(24);
                }

                /*
                |--------------------------------------------------------------------------
                | Wrap Long Text
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("B{$firstDataRow}:F{$lastDataRow}")
                    ->getAlignment()
                    ->setWrapText(true);

                /*
                |--------------------------------------------------------------------------
                | Vertical Alignment
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("A3:G{$totalRow}")
                    ->getAlignment()
                    ->setVertical(Alignment::VERTICAL_CENTER);

                /*
                |--------------------------------------------------------------------------
                | Center Alignment
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("A3:A{$totalRow}")
                    ->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_CENTER);

                /*
                |--------------------------------------------------------------------------
                | Right Align Amount
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("G{$firstDataRow}:G{$totalRow}")
                    ->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_RIGHT);

                /*
                |--------------------------------------------------------------------------
                | Freeze Header
                |--------------------------------------------------------------------------
                */

                $sheet->freezePane('A4');

                /*
                |--------------------------------------------------------------------------
                | Auto Filter
                |--------------------------------------------------------------------------
                */

                $sheet->setAutoFilter("A3:G{$lastDataRow}");
                                /*
                |--------------------------------------------------------------------------
                | Borders
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("A3:G{$totalRow}")
                    ->getBorders()
                    ->getAllBorders()
                    ->setBorderStyle(Border::BORDER_THIN);

                /*
                |--------------------------------------------------------------------------
                | Total Row Style
                |--------------------------------------------------------------------------
                */

                $sheet->getStyle("A{$totalRow}:G{$totalRow}")
                    ->applyFromArray([

                        'font' => [
                            'bold' => true,
                            'color' => [
                                'rgb' => '000000'
                            ]
                        ],

                        'fill' => [
                            'fillType' => Fill::FILL_SOLID,
                            'startColor' => [
                                'rgb' => 'FFF2CC'
                            ]
                        ]

                    ]);

                /*
                |--------------------------------------------------------------------------
                | Column Widths
                |--------------------------------------------------------------------------
                */

                $sheet->getColumnDimension('A')->setWidth(8);
                $sheet->getColumnDimension('B')->setWidth(30);
                $sheet->getColumnDimension('C')->setWidth(18);
                $sheet->getColumnDimension('D')->setWidth(32);
                $sheet->getColumnDimension('E')->setWidth(22);
                $sheet->getColumnDimension('F')->setWidth(18);
                $sheet->getColumnDimension('G')->setWidth(18);

                /*
                |--------------------------------------------------------------------------
                | Page Setup
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);

                $sheet->getPageSetup()
                    ->setPaperSize(PageSetup::PAPERSIZE_A4);

                $sheet->getPageSetup()
                    ->setFitToWidth(1);

                $sheet->getPageSetup()
                    ->setFitToHeight(0);

                /*
                |--------------------------------------------------------------------------
                | Margins
                |--------------------------------------------------------------------------
                */

                $sheet->getPageMargins()->setTop(0.30);
                $sheet->getPageMargins()->setBottom(0.30);
                $sheet->getPageMargins()->setLeft(0.25);
                $sheet->getPageMargins()->setRight(0.25);

                /*
                |--------------------------------------------------------------------------
                | Repeat Header While Printing
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setRowsToRepeatAtTopByStartAndEnd(3, 3);

                /*
                |--------------------------------------------------------------------------
                | Print Area
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setPrintArea("A1:G{$totalRow}");

            }

        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Number Formats
    |--------------------------------------------------------------------------
    */

    public function columnFormats(): array
    {
        return [

            'G' => '#,##0.00',

        ];
    }

}