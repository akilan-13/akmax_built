<?php

namespace App\Exports;

use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;

use Maatwebsite\Excel\Events\AfterSheet;

class PayrollExport implements
    FromArray,
    WithTitle,
    WithStyles,
    WithEvents,
    WithColumnFormatting,
    WithCustomStartCell
{

    protected $payroll;

    public function __construct($payroll)
    {
        $this->payroll = $payroll;
    }

    public function title(): string
    {
        return 'Payroll Report';
    }

    public function startCell(): string
    {
        return 'A3';
    }

    public function array(): array
    {
        $rows = [];

        /*
        |--------------------------------------------------------------------------
        | Table Header
        |--------------------------------------------------------------------------
        */

        $rows[] = [
            'S.No',
            'Staff Name',
            'Staff ID',
            'Salary Company',
            'Entity',
            'Salary Type',
            'Gross',
            'On Duty',
            'Incentive',
            'Variable',
            'LOP Days',
            'LOP',
            'PF',
            'ESI',
            'PT',
            'TDS',
            'Deductions',
            'Net Salary'
        ];

        /*
        |--------------------------------------------------------------------------
        | Totals
        |--------------------------------------------------------------------------
        */
        $totalGross      = 0;
        $totalOnDuty     = 0;
        $totalIncentive  = 0;
        $totalVariable   = 0;
        $totalLopDays    = 0;
        $totalLop        = 0;
        $totalPF         = 0;
        $totalESI        = 0;
        $totalPT         = 0;
        $totalTDS        = 0;
        $totalDeduction  = 0;
        $totalNetSalary  = 0;
        /*
        |--------------------------------------------------------------------------
        | Employee Rows
        |--------------------------------------------------------------------------
        */
        foreach ($this->payroll['rows'] as $index => $row) {
            $rows[] = [
                $index + 1,
                $row['staff_name'],
                $row['staff_id'],
                $row['salary_company_name'],
                $row['entity_name'],
                $row['salary_type'] == 1 ? 'Cash' : 'Bank',
                $row['gross_salary'] ?? 0,
                $row['onduty'] ?? 0,
                $row['incentive'] ?? 0,
                $row['variable'] ?? 0,
                $row['lop_days'] ?? 0,
                $row['lopAmount'] ?? 0,
                $row['pf'] ?? 0,
                $row['esi'] ?? 0,
                $row['pt'] ?? 0,
                $row['tax'] ?? 0,
                $row['deductions'] ?? 0,
                $row['amount']?? 0
            ];

            $totalGross += $row['gross_salary'];
            $totalOnDuty += $row['onduty'];
            $totalIncentive += $row['incentive'];
            $totalVariable += $row['variable'];
            $totalLopDays += $row['lop_days'];
            $totalLop += $row['lopAmount'];
            $totalPF += $row['pf'];
            $totalESI += $row['esi'];
            $totalPT += $row['pt'];
            $totalTDS += $row['tax'];
            $totalDeduction += $row['deductions'];
            $totalNetSalary += $row['amount'];
        }
        /*
        |--------------------------------------------------------------------------
        | Grand Total Row
        |--------------------------------------------------------------------------
        */
        $firstDataRow = 4;
        $lastDataRow  = count($this->payroll['rows']) + 3;
        $totalRow     = $lastDataRow + 1;

        $rows[] = [
            '',
            'TOTAL',
            '',
            '',
            '',
            '',
            "=SUBTOTAL(9,G{$firstDataRow}:G{$lastDataRow})",
            "=SUBTOTAL(9,H{$firstDataRow}:H{$lastDataRow})",
            "=SUBTOTAL(9,I{$firstDataRow}:I{$lastDataRow})",
            "=SUBTOTAL(9,J{$firstDataRow}:J{$lastDataRow})",
            "=SUBTOTAL(9,K{$firstDataRow}:K{$lastDataRow})",
            "=SUBTOTAL(9,L{$firstDataRow}:L{$lastDataRow})",
            "=SUBTOTAL(9,M{$firstDataRow}:M{$lastDataRow})",
            "=SUBTOTAL(9,N{$firstDataRow}:N{$lastDataRow})",
            "=SUBTOTAL(9,O{$firstDataRow}:O{$lastDataRow})",
            "=SUBTOTAL(9,P{$firstDataRow}:P{$lastDataRow})",
            "=SUBTOTAL(9,Q{$firstDataRow}:Q{$lastDataRow})",
            "=SUBTOTAL(9,R{$firstDataRow}:R{$lastDataRow})",
        ];

        return $rows;
    }

    /*
    |--------------------------------------------------------------------------
    | Styles
    |--------------------------------------------------------------------------
    */

    public function styles(Worksheet $sheet)
    {
        return [
            /*
            |--------------------------------------------------------------------------
            | Payroll Title
            |--------------------------------------------------------------------------
            */
            1 => [
                'font' => [
                    'bold' => true,
                    'size' => 18,
                    'color' => [
                        'rgb' => 'FFFFFF'
                    ]
                ],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical'   => Alignment::VERTICAL_CENTER
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'rgb' => '1F4E78'
                    ]
                ]
            ],
            /*
            |--------------------------------------------------------------------------
            | Table Header
            |--------------------------------------------------------------------------
            */
            3 => [
                'font' => [
                    'bold' => true,
                    'color' => [
                        'rgb' => 'FFFFFF'
                    ]
                ],

                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'rgb' => '305496'
                    ]
                ],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical'   => Alignment::VERTICAL_CENTER,
                    'wrapText'   => true
                ]
            ]
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Events
    |--------------------------------------------------------------------------
    */

    public function registerEvents(): array
    {
        return [

            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $lastRow = count($this->payroll['rows']) + 4;
                $firstDataRow = 4;
                $lastDataRow  = count($this->payroll['rows']) + 3;
                $totalRow     = $lastDataRow + 1;
                /*
                |--------------------------------------------------------------------------
                | Title
                |--------------------------------------------------------------------------
                */
                $sheet->mergeCells('A1:R1');
                $sheet->setCellValue(
                    'A1',
                    'PAYROLL REPORT - '.strtoupper($this->payroll['month'])
                );
                $sheet->getRowDimension(1)->setRowHeight(30);
                /*
                |--------------------------------------------------------------------------
                | Header Row Height
                |--------------------------------------------------------------------------
                */
                $sheet->getRowDimension(3)->setRowHeight(24);
                /*
                |--------------------------------------------------------------------------
                | Employee Rows
                |--------------------------------------------------------------------------
                */
                for($i=4;$i<=$lastDataRow;$i++){
                    $sheet->getRowDimension($i)->setRowHeight(48);
                }
                /*
                |--------------------------------------------------------------------------
                | Staff Column
                |--------------------------------------------------------------------------
                */
                $sheet->getStyle("B4:F".$lastDataRow)
                    ->getAlignment()
                    ->setWrapText(true);
                $sheet->getStyle("B4:F".$lastDataRow)
                    ->getAlignment()
                    ->setVertical(Alignment::VERTICAL_TOP);
                /*
                |--------------------------------------------------------------------------
                | Center Alignment
                |--------------------------------------------------------------------------
                */
                $sheet->getStyle("A3:R".$totalRow)
                    ->getAlignment()
                    ->setVertical(Alignment::VERTICAL_CENTER);

                $sheet->getStyle("A3:A".$lastDataRow)
                    ->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_CENTER);
                /*
                |--------------------------------------------------------------------------
                | Right Align Numbers
                |--------------------------------------------------------------------------
                */
                $sheet->getStyle("G4:R".$lastDataRow)
                    ->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_RIGHT);
                $sheet->getStyle("G{$totalRow}:R{$totalRow}")
                    ->getAlignment()
                    ->setHorizontal(Alignment::HORIZONTAL_RIGHT);
                /*
                |--------------------------------------------------------------------------
                | Freeze Header
                |--------------------------------------------------------------------------
                */
                $sheet->freezePane('A4');
                /*
                |--------------------------------------------------------------------------
                | Auto Filter
                |--------------------------------------------------------------------------
                */
                $sheet->setAutoFilter("A3:R{$lastDataRow}");
                /*
                |--------------------------------------------------------------------------
                | Borders
                |--------------------------------------------------------------------------
                */
                $sheet->getStyle("A3:R".$totalRow)
                        ->getBorders()
                        ->getAllBorders()
                        ->setBorderStyle(Border::BORDER_THIN);

               
                /*
                |--------------------------------------------------------------------------
                | Total Row
                |--------------------------------------------------------------------------
                */
                $sheet->getStyle("A{$totalRow}:R{$totalRow}")
                    ->applyFromArray([
                        'font'=>[
                            'bold'=>true,
                            'color'=>[
                                'rgb'=>'000000'
                            ]
                        ],
                        'fill'=>[
                            'fillType'=>Fill::FILL_SOLID,
                            'startColor'=>[
                                'rgb'=>'FFF2CC'
                            ]
                        ]
                    ]);
                                /*
                |--------------------------------------------------------------------------
                | Column Widths
                |--------------------------------------------------------------------------
                */

                $sheet->getColumnDimension('A')->setWidth(8);    // S.No
                $sheet->getColumnDimension('B')->setWidth(28);   // Staff Name
                $sheet->getColumnDimension('C')->setWidth(18);   // Staff ID
                $sheet->getColumnDimension('D')->setWidth(28);   // Salary Company
                $sheet->getColumnDimension('E')->setWidth(22);   // Entity
                $sheet->getColumnDimension('F')->setWidth(14);   // Salary Type

                foreach(range('G','R') as $column){
                    $sheet->getColumnDimension($column)->setWidth(15);
                }

                /*
                |--------------------------------------------------------------------------
                | Page Setup
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);

                $sheet->getPageSetup()
                    ->setPaperSize(PageSetup::PAPERSIZE_A4);

                $sheet->getPageSetup()
                    ->setFitToWidth(1);

                $sheet->getPageSetup()
                    ->setFitToHeight(0);

                /*
                |--------------------------------------------------------------------------
                | Print Margins
                |--------------------------------------------------------------------------
                */

                $sheet->getPageMargins()->setTop(0.30);
                $sheet->getPageMargins()->setBottom(0.30);
                $sheet->getPageMargins()->setLeft(0.25);
                $sheet->getPageMargins()->setRight(0.25);

                /*
                |--------------------------------------------------------------------------
                | Repeat Header On Every Page
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setRowsToRepeatAtTopByStartAndEnd(3, 3);

                /*
                |--------------------------------------------------------------------------
                | Print Area
                |--------------------------------------------------------------------------
                */

                $sheet->getPageSetup()
                    ->setPrintArea("A1:R{$totalRow}");

            }

        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Number Formats
    |--------------------------------------------------------------------------
    */

    public function columnFormats(): array
    {
        return [
            'G' => '#,##0.00',
            'H' => '#,##0.00',
            'I' => '#,##0.00',
            'J' => '#,##0.00',
            'K' => '0.00',
            'L' => '#,##0.00',
            'M' => '#,##0.00',
            'N' => '#,##0.00',
            'O' => '#,##0.00',
            'P' => '#,##0.00',
            'Q' => '#,##0.00',
            'R' => '#,##0.00',
        ];
    }

}