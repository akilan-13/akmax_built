<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;

use Maatwebsite\Excel\Events\AfterSheet;

use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Worksheet\PageMargins;

class PayrollBankExcelExport implements
    FromArray,
    WithEvents,
    WithStyles,
    ShouldAutoSize,
    WithCustomStartCell
{
    /**
     * Payroll Data
     *
     * @var array
     */
    protected $payroll;

    /**
     * Constructor
     */
    public function __construct(array $payroll)
    {
        $this->payroll = $payroll;
    }

    /**
     * Table starts from Row 22
     */
    public function startCell(): string
    {
        return 'A24';
    }

    /**
     * Employee Table
     */
    public function array(): array
    {
        $rows = [];

        $sl = 1;

        foreach ($this->payroll['rows'] as $row) {

            $rows[] = [

                $sl++,

                $row['staff_name'],

                $row['account_no'],

                (float)$row['amount']

            ];
        }

        // Total Row

        $rows[] = [

            '',

            'TOTAL',

            '',

            (float)$this->payroll['grand_total']

        ];

        return $rows;
    }

    /**
     * Default Sheet Style
     */
    public function styles(Worksheet $sheet)
    {
        return [

            1 => [

                'font' => [

                    'name' => 'Calibri',

                    'size' => 11

                ]

            ]

        ];
    }

    /**
     * Sheet Events
     */
    public function registerEvents(): array
    {
        return [
                AfterSheet::class => function (AfterSheet $event) {

                    $sheet = $event->sheet->getDelegate();

                    /*
                    |--------------------------------------------------------------------------
                    | Page Setup
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getPageSetup()
                        ->setOrientation(PageSetup::ORIENTATION_PORTRAIT);

                    $sheet->getPageSetup()
                        ->setPaperSize(PageSetup::PAPERSIZE_A4);

                    $sheet->getPageMargins()->setTop(0.35);
                    $sheet->getPageMargins()->setBottom(0.35);
                    $sheet->getPageMargins()->setLeft(0.30);
                    $sheet->getPageMargins()->setRight(0.30);

                    /*
                    |--------------------------------------------------------------------------
                    | Column Width
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getColumnDimension('A')->setWidth(8);
                    $sheet->getColumnDimension('B')->setWidth(36);
                    $sheet->getColumnDimension('C')->setWidth(24);
                    $sheet->getColumnDimension('D')->setWidth(18);

                    /*
                    |--------------------------------------------------------------------------
                    | Company Logo
                    |--------------------------------------------------------------------------
                    */

                    if (
                        !empty($this->payroll['company_logo']) &&
                        file_exists($this->payroll['company_logo'])
                    ) {

                        $drawing = new Drawing();

                        $drawing->setName('Company Logo');
                        $drawing->setDescription('Company Logo');
                        $drawing->setPath($this->payroll['company_logo']);
                        $drawing->setCoordinates('A1');
                        $drawing->setHeight(70);
                        $drawing->setWorksheet($sheet);
                    }

                    $sheet->getRowDimension(1)->setRowHeight(60);

                    /*
                    |--------------------------------------------------------------------------
                    | Date
                    |--------------------------------------------------------------------------
                    */

                    $sheet->mergeCells('C4:D4');

                    $sheet->setCellValue(
                        'C4',
                        'Date : '.$this->payroll['format_salary_date']
                    );

                    $sheet->getStyle('C4')->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_RIGHT);

                    /*
                    |--------------------------------------------------------------------------
                    | Address
                    |--------------------------------------------------------------------------
                    */

                    $sheet->setCellValue('A6','To');

                    $sheet->getStyle('A6')->getFont()->setBold(true);

                    $sheet->setCellValue('A7','The Manager');

                    $sheet->setCellValue(
                        'A8',
                        $this->payroll['bank_name']
                    );

                    $sheet->setCellValue(
                        'A9',
                        $this->payroll['bank_branch']
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Current Account
                    |--------------------------------------------------------------------------
                    */

                    $sheet->mergeCells('A11:D11');

                    $sheet->setCellValue(

                        'A11',

                        'Reg : Our Current Account No : '.$this->payroll['current_account']

                    );

                    $sheet->getStyle('A11')
                        ->getFont()
                        ->setBold(true);

                    /*
                    |--------------------------------------------------------------------------
                    | Dear Sir
                    |--------------------------------------------------------------------------
                    */

                    $sheet->setCellValue(
                        'A13',
                        'Dear Sir,'
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Letter
                    |--------------------------------------------------------------------------
                    */

                    $richText = new RichText();

                        // Normal text
                        $richText->createText(
                            '    Please find here with enclosed yourselves cheque for an amount of '
                        );

                        // Bold "Rs. xxx"
                        $bold = $richText->createTextRun(
                            'Rs. '.number_format($this->payroll['grand_total'], 2)
                        );
                        $bold->getFont()->setBold(true);

                        // Normal
                        $richText->createText(' (Rupees ');

                        // Bold amount in words
                        $bold = $richText->createTextRun(
                            $this->payroll['amount_words']
                        );
                        $bold->getFont()->setBold(true);

                        // Normal
                        $richText->createText(' ) vide cheque ');

                        // Bold cheque number
                        $bold = $richText->createTextRun(
                            $this->payroll['cheque_no']
                        );
                        $bold->getFont()->setBold(true);

                        // Normal
                        $richText->createText('. ');

                        // Bold salary date
                        $bold = $richText->createTextRun(
                            $this->payroll['default_salary_date']
                        );
                        $bold->getFont()->setBold(true);

                        // Remaining text
                        $richText->createText(
                            ' for our staff salary transfers purpose. Please arrange to credit in the respective account with you as detailed below towards staff salary'
                        );

                        $sheet->mergeCells('A15:D20');

                        $sheet->setCellValue('A15', $richText);

                        $sheet->getStyle('A15')->applyFromArray([
                            'alignment' => [
                                'wrapText'   => true,
                                'horizontal' => Alignment::HORIZONTAL_JUSTIFY,
                                'vertical'   => Alignment::VERTICAL_TOP,
                            ],
                        ]);

                    /*
                    |--------------------------------------------------------------------------
                    | Row Heights
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getRowDimension(15)->setRowHeight(-1);
                    $sheet->getRowDimension(16)->setRowHeight(-1);
                    $sheet->getRowDimension(17)->setRowHeight(-1);
                    $sheet->getRowDimension(18)->setRowHeight(-1);

                    /*
                    |--------------------------------------------------------------------------
                    | Table Header starts at Row 21
                    |--------------------------------------------------------------------------
                    */

                    $sheet->fromArray(

                        [[

                            'Sl',
                            'Employee Name',
                            'Account Number',
                            'Amount'

                        ]],

                        null,

                        'A23'

                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Table Header Style
                    |--------------------------------------------------------------------------
                    */

                    $companyColor = strtoupper(
                        ltrim(
                            $this->payroll['company_base_color'] ?? '#AB2B22',
                            '#'
                        )
                    );

                    $sheet->getStyle('A23:D23')->applyFromArray([

                        'font' => [

                            'bold'  => true,
                            'color' => [
                                'rgb' => 'FFFFFF'
                            ],
                            'size' => 11

                        ],

                        'fill' => [

                            'fillType' => Fill::FILL_SOLID,

                            'startColor' => [

                                'rgb' => $companyColor

                            ]

                        ],

                        'alignment' => [

                            'horizontal' => Alignment::HORIZONTAL_CENTER,

                            'vertical' => Alignment::VERTICAL_CENTER

                        ],

                        'borders' => [

                            'allBorders' => [

                                'borderStyle' => Border::BORDER_THIN,

                                'color' => [
                                    'rgb' => '000000'
                                ]

                            ]

                        ]

                    ]);

                    $sheet->getRowDimension(23)->setRowHeight(24);

                    /*
                    |--------------------------------------------------------------------------
                    | Employee Rows
                    |--------------------------------------------------------------------------
                    */

                    $highestRow = $sheet->getHighestRow();

                    /*
                    |--------------------------------------------------------------------------
                    | Borders
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getStyle("A24:D{$highestRow}")
                        ->applyFromArray([

                            'borders' => [

                                'allBorders' => [

                                    'borderStyle' => Border::BORDER_THIN,

                                    'color' => [
                                        'rgb' => '000000'
                                    ]

                                ]

                            ]

                        ]);

                    /*
                    |--------------------------------------------------------------------------
                    | Alignment
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getStyle("A24:A{$highestRow}")
                        ->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_CENTER);

                    $sheet->getStyle("A24:A{$highestRow}")
                        ->getAlignment()
                        ->setVertical(Alignment::VERTICAL_CENTER);

                    $sheet->getStyle("C24:C{$highestRow}")
                        ->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_LEFT);

                    $sheet->getStyle("D24:D{$highestRow}")
                        ->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_RIGHT);

                    $sheet->getStyle("D24:D{$highestRow}")
                        ->getNumberFormat()
                        ->setFormatCode('#,##0.00');

                    /*
                    |--------------------------------------------------------------------------
                    | Font
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getStyle("A24:D{$highestRow}")
                        ->getFont()
                        ->setSize(10);

                    /*
                    |--------------------------------------------------------------------------
                    | Row Height
                    |--------------------------------------------------------------------------
                    */

                    for ($row = 24; $row <= $highestRow; $row++) {

                        $sheet->getRowDimension($row)
                        ->setRowHeight(-1);

                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Total Row
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getStyle("A{$highestRow}:D{$highestRow}")
                        ->applyFromArray([

                            'font' => [

                                'bold' => true

                            ],

                            'alignment' => [

                                'horizontal' => Alignment::HORIZONTAL_CENTER,

                                'vertical' => Alignment::VERTICAL_CENTER

                            ],

                            'borders' => [

                                'allBorders' => [

                                    'borderStyle' => Border::BORDER_THIN,

                                    'color' => [
                                        'rgb' => '000000'
                                    ]

                                ]

                            ]

                        ]);

                    $sheet->getStyle("D{$highestRow}")
                        ->getAlignment()
                        ->setHorizontal(Alignment::HORIZONTAL_RIGHT);

                    $sheet->getStyle("D{$highestRow}")
                        ->getNumberFormat()
                        ->setFormatCode('#,##0.00');


                    /*
                    |--------------------------------------------------------------------------
                    | Signature
                    |--------------------------------------------------------------------------
                    */

                    $signatureRow = $highestRow + 4;

                    // Company Name

                    $sheet->mergeCells("A{$signatureRow}:D{$signatureRow}");

                    $sheet->setCellValue(
                        "A{$signatureRow}",
                        "For ".$this->payroll['company_name'].","
                    );

                    $sheet->getStyle("A{$signatureRow}")->applyFromArray([

                        'font' => [
                            'size' => 11
                        ],

                        'alignment' => [

                            'horizontal' => Alignment::HORIZONTAL_LEFT,

                            'vertical'   => Alignment::VERTICAL_CENTER

                        ]

                    ]);

                    // Space for Signature

                    $signatureRow += 3;

                    // Managing Director

                    $sheet->mergeCells("A{$signatureRow}:D{$signatureRow}");

                    $sheet->setCellValue(
                        "A{$signatureRow}",
                        "Managing Director"
                    );

                    $sheet->getStyle("A{$signatureRow}")->applyFromArray([

                        'font' => [

                            'bold' => true,

                            'size' => 11

                        ],

                        'alignment' => [

                            'horizontal' => Alignment::HORIZONTAL_LEFT,

                            'vertical' => Alignment::VERTICAL_CENTER

                        ]

                    ]);

                    /*
                    |--------------------------------------------------------------------------
                    | Print Area
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getPageSetup()->setPrintArea(
                        "A1:D{$signatureRow}"
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Fit To One Page Wide
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getPageSetup()->setFitToWidth(1);

                    $sheet->getPageSetup()->setFitToHeight(0);

                    /*
                    |--------------------------------------------------------------------------
                    | Center Horizontally
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getPageSetup()->setHorizontalCentered(false);

                    $sheet->getPageSetup()->setVerticalCentered(false);

                    /*
                    |--------------------------------------------------------------------------
                    | Repeat Table Header
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(23, 23);

                    /*
                    |--------------------------------------------------------------------------
                    | Header/Footer
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getHeaderFooter()->setOddFooter(
                        '&L'.$this->payroll['company_name'].
                        '&RPage &P of &N'
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Sheet View
                    |--------------------------------------------------------------------------
                    */

                    $sheet->setShowGridLines(false);

                    /*
                    |--------------------------------------------------------------------------
                    | Vertical Alignment
                    |--------------------------------------------------------------------------
                    */

                    $sheet->getStyle("A1:D{$signatureRow}")
                        ->getAlignment()
                        ->setVertical(Alignment::VERTICAL_CENTER);

                    /*
                    |--------------------------------------------------------------------------
                    | Document Ready
                    |--------------------------------------------------------------------------
                    */
                }
        ];
    }

    
}
