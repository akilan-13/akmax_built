<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class PayrollExport implements FromCollection, WithHeadings
{
    protected $month;
    protected $year;

    public function __construct($month, $year)
    {
        $this->month = $month;
        $this->year  = $year;
    }

    public function collection()
    {
        return DB::table('egc_payroll_entries_new as e')
            ->join('egc_payroll_runs_new as r','r.sno','=','e.payroll_run_sno')
            ->join('egc_staff as s','s.sno','=','e.staff_id')
            ->where('r.payroll_month',$this->month)
            ->where('r.payroll_year',$this->year)
            ->select(
                's.staff_name',
                'e.basic_salary',
                'e.total_earnings',
                'e.total_deductions',
                'e.net_salary',
                'e.lop_days'
            )
            ->get();
    }

    public function headings(): array
    {
        return [
            'Employee Name',
            'Basic Salary',
            'Total Earnings',
            'Total Deductions',
            'Net Salary',
            'LOP Days'
        ];
    }
}