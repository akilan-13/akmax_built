<?php

namespace App\Services;

use Carbon\Carbon;
use App\Models\StaffModel;
use App\Models\StaffAdvanceModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdvanceService
{
    public function list(Request $request)
    {

        $year = $request->year ?? now()->year;

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';


        $latestAdvance = DB::table('egc_staff_advance_amount_log as sal')
                        ->select(
                            'sal.staff_id',
                            'sal.month',
                            'sal.year',
                            'sal.total_amount'
                        )
                        ->join(DB::raw("
                            (
                                SELECT
                                    staff_id,
                                    MAX(year * 100 + month) AS max_period
                                FROM egc_staff_advance_amount_log
                                WHERE status = 0
                                GROUP BY staff_id
                            ) latest
                        "), function ($join) {
                            $join->on('latest.staff_id', '=', 'sal.staff_id')
                                ->whereRaw('(sal.year * 100 + sal.month) = latest.max_period');
                        });

        $query = StaffModel::query()
                ->select(
                    'egc_staff.*',
                    'egc_department.department_name',
                    'egc_division.division_name',
                    'egc_job_role.job_position_name',
                    'egc_company.company_name',
                    'egc_company.company_base_color',
                    'egc_entity.entity_name',
                    'adv.month as advance_month',
                    'adv.year as advance_year',
                    'adv.total_amount as advance_amount'
                )
                ->joinSub($latestAdvance, 'adv', function ($join) {
                    $join->on('adv.staff_id', '=', 'egc_staff.sno');
                })
                ->leftJoin('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
                ->leftJoin('egc_division', 'egc_division.sno', '=', 'egc_staff.division_id')
                ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.job_role_id')
                ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_staff.company_id')
                ->leftJoin('egc_entity', 'egc_entity.sno', '=', 'egc_staff.entity_id')
                ->where('egc_staff.status', '!=', 2);

            if($request->filled('search_filter')){
                $search=$request->search_filter;
                $query->where(function($q) use($search){
                    $q->where('egc_staff.staff_name','like',"%{$search}%")
                    ->orWhere('egc_staff.staff_id','like',"%{$search}%")
                    ->orWhere('egc_staff.mobile_no','like',"%{$search}%");
                });
            }
            if($request->company_fill){
                $query->where('egc_staff.company_id',$request->company_fill);
            }

            if($request->entity_fill){
                $query->where('egc_staff.entity_id',$request->entity_fill);
            }

            if($request->department_fill){
                $query->where('egc_staff.department_id',$request->department_fill);
            }
            if($request->division_fill){
                $query->where('egc_staff.division_id',$request->division_fill);
            }

            if($request->job_role_fill){
                $query->where('egc_staff.job_role_id',$request->job_role_fill);
            }

            $dashboardQuery = clone $query;
            $dashboardStaffIds = $dashboardQuery->pluck('egc_staff.sno');
            $totalStaff = $dashboardStaffIds->count();

           $thisYearAdvance = StaffAdvanceModel::where('status', 0)
                ->where('year', now()->year)
                ->whereIn('staff_id', $dashboardStaffIds)
                ->count();

          $thisMonthAdvance = StaffAdvanceModel::where('status', 0)
            ->where('year', now()->year)
            ->where('month', now()->month)
            ->whereIn('staff_id', $dashboardStaffIds)
            ->count();

            $staffs=$query
                ->orderBy('egc_staff.date_of_joining','asc')
                ->paginate($perpage);

            $staffIds=$staffs->pluck('sno');

           $histories = StaffAdvanceModel::where('status', 0)
            ->whereIn('staff_id', $staffIds)
            ->orderBy('year')
            ->orderBy('month')
            ->get()
            ->groupBy('staff_id');
            $headers = [];

            $advanceRange = StaffAdvanceModel::where('status', 0)
                ->whereIn('staff_id', $staffIds)
                ->selectRaw('MIN(year * 100 + month) as min_period')
                ->selectRaw('MAX(year * 100 + month) as max_period')
                ->first();

            $headers = [];

            if ($advanceRange && $advanceRange->min_period) {

                $startYear = floor($advanceRange->min_period / 100);
                $startMonth = $advanceRange->min_period % 100;

                $endYear = floor($advanceRange->max_period / 100);
                $endMonth = $advanceRange->max_period % 100;

                $startHeader = Carbon::create($startYear, $startMonth, 1)->startOfMonth();
                $endHeader = Carbon::create($endYear, $endMonth, 1)->startOfMonth();

                while ($startHeader->lte($endHeader)) {

                    $headers[] = [
                        'key'   => $startHeader->format('Y-m'),
                        'label' => $startHeader->format('M-y'),
                        'year'  => $startHeader->year,
                        'month' => $startHeader->month,
                    ];

                    $startHeader->addMonth();
                }
            }
            // $endHeader = now()->startOfMonth();
            $temp = $startHeader->copy();

            while ($temp <= $endHeader) {
                $headers[] = [
                    'key' => $temp->format('Y-m'),
                    'label' => $temp->format('M-y'),
                    'year' => $temp->year,
                    'month' => $temp->month
                ];
                $temp->addMonth();
            }

            $staffs->getCollection()->transform(function ($staff) use ($histories, $headers) {

                $joiningDate = Carbon::parse($staff->date_of_joining)->startOfMonth();
                $exitDate = null;

                switch ((int)$staff->status) {
                    case 4: // Notice
                        if (!empty($staff->notice_end_date)) {
                            $exitDate = Carbon::parse($staff->notice_end_date)->startOfMonth();
                        }
                    break;
                    case 5: // Relieved
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 6: // Abscond
                         if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 7: // Terminated
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }

                    break;
                }
                $advanceHistory = $histories[$staff->sno] ?? collect();
                $timeline = [];
                $totalAdvance = 0;

                foreach ($headers as $header) {
                    $current = Carbon::create( $header['year'],$header['month'],1);

                    if ($exitDate && $current->gt($exitDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'exited',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    if ($current->lt($joiningDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'before_join',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    

                    $record = $advanceHistory->first(function ($item) use ($header) {
                        return $item->year == $header['year']
                            && $item->month == $header['month'];
                    });

                    $status = "normal";

                    if ($current->equalTo($joiningDate)) {
                        $status = "joining";
                    }

                    if ($record) {
                        $status = "advance";
                        $totalAdvance += $record->total_amount;
                    }

                    if (
                        $current->year == now()->year &&
                        $current->month == now()->month
                    ) {
                        $status = $record ? "current-advance" : "current";
                    }

                    $timeline[] = [
                        'month' => $header['label'],
                        'amount' => $record ? $record->total_amount : null,
                        'status' => $status,
                        'remarks' => $record->remarks ?? '',
                        'year' => $header['year'],
                        'month_no' => $header['month']
                    ];
                }

                $totalAdvanceCount = $advanceHistory->count();

                $helper = new \App\Helpers\Helpers();
                $general_setting=$helper->general_setting_data();

                if ($staff->company_type == 1) {
                    $staff->company_name = $general_setting->title;
                    $staff->company_base_color = '#ab2b22';
                    $staff->company_logo = $general_setting->logo;
                }

                $staff->total_advance = $totalAdvanceCount;
                $staff->current_salary = $totalAdvance;
                $staff->timeline = $timeline;
                return $staff;
            });

        return [
            'status' => 200,
            'dashboard'=>[
                'total_staff' => $totalStaff,
                'this_month' => $thisMonthAdvance,
                'this_year' => $thisYearAdvance,

            ],

            'headers' => $headers,
            'current_page' => $staffs->currentPage(),
            'last_page' => $staffs->lastPage(),
            'total' => $staffs->total(),
            'data' => $staffs->values()
        ];

    }
    public function details($staffId)
    {
        $staff = StaffModel::query()
            ->leftJoin('egc_department','egc_department.sno','=','egc_staff.department_id')
            ->leftJoin('egc_division','egc_division.sno','=','egc_staff.division_id')
            ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_staff.job_role_id')
            ->select(
                'egc_staff.*',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name'
            )
            ->findOrFail($staffId);

        $history = StaffAdvanceModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                ->orderBy('effective_from')
                ->get();

        $historyWithoutJoining = StaffAdvanceModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                 ->whereNot('appraisal_type',0)
                ->orderBy('effective_from')
                ->get();
        $lastData =StaffAdvanceModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->where('appraisal_type',0)
                    ->orderBy('effective_from','asc')
                    ->first();

            $lastDataHisrtry =StaffAdvanceModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->orderBy('effective_from','asc')
                    ->first();

        $joiningSalary = $lastData ? $lastData->gross_salary : ($lastDataHisrtry ? $lastDataHisrtry->gross_salary : $staff->basic_salary);

        $currentSalary = $staff->basic_salary ??( $history->count()
            ? $history->last()->gross_salary
            : $joiningSalary);

        $totalIncrement = $currentSalary - $joiningSalary;

        $experience = Carbon::parse($staff->date_of_joining)
            ->diff(now());

        $summary = [
            'joining_salary'   => $joiningSalary,
            'current_salary'   => $currentSalary,
            'highest_salary'   => max($history->pluck('gross_salary')->push($joiningSalary)->toArray()),
            'total_increment'  => $totalIncrement,
            'total_appraisals' => $historyWithoutJoining->count(),
            'salary_growth'    => $joiningSalary > 0
                ? round(($totalIncrement / $joiningSalary) * 100, 1)
                : 0,
            'experience'       => $experience->y . 'Y ' . $experience->m . 'M'
        ];

        $increments = [];

        $highestIncrement = 0;

        $lastSalary = $joiningSalary;

        foreach($history as $row){

            $inc = $row->gross_salary - $lastSalary;

            $increments[] = $inc;

            if($inc > $highestIncrement){
                $highestIncrement = $inc;
            }
            $lastSalary = $row->gross_salary;
        }

        $averageIncrement = count($increments)
            ? round(array_sum($increments)/count($increments),2)
            : 0;

        $summary['highest_increment'] = $highestIncrement;

        $summary['average_increment'] = $averageIncrement;

        return [
            'status'=>200,
            'staff'=>$staff,
            'history'=>$history,
            'summary' => $summary
        ];

    }
}