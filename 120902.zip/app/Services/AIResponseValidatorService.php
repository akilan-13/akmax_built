<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class AIResponseValidatorService
{

    /**
     * Validate Single Role Matching
     */
    public function validateRoleMatching(array $response): array
    {

        if (!isset($response['matches'])) {

            return [
                'status'=>false,
                'message'=>'matches key missing.'
            ];

        }


        if (!is_array($response['matches'])) {

            return [
                'status'=>false,
                'message'=>'matches should be array.'
            ];

        }


        $validRoleIds = $this->getRoleIds();


        $matches=[];


        foreach($response['matches'] as $match){


            if(
                !isset($match['role_id']) ||
                !isset($match['confidence'])
            ){
                continue;
            }



            $roleId=(int)$match['role_id'];


            $confidence=(float)$match['confidence'];



            /*
            |--------------------------------------------------
            | Check Role Exists
            |--------------------------------------------------
            */

            if(!in_array($roleId,$validRoleIds)){

                continue;

            }



            /*
            |--------------------------------------------------
            | Confidence Range
            |--------------------------------------------------
            */

            $confidence=max(
                0,
                min(
                    100,
                    $confidence
                )
            );



            $matches[]=[

                'role_id'=>$roleId,

                'confidence'=>round(
                    $confidence,
                    2
                ),

                'reason'=>$match['reason'] ?? null

            ];

        }



        if(empty($matches)){


            return [

                'status'=>false,

                'message'=>'No valid roles returned.'

            ];

        }



        /*
        |--------------------------------------------------
        | Highest Confidence First
        |--------------------------------------------------
        */

        usort(
            $matches,
            function($a,$b){

                return $b['confidence']
                    <=>
                    $a['confidence'];

            }
        );



        return [

            'status'=>true,

            'matches'=>array_slice(
                $matches,
                0,
                3
            )

        ];

    }





    /**
     * Validate Batch ATS Response
     */
    public function validateBatchRoleMatching(
        array $response
    ): array
    {


        if(!isset($response['results'])){


            return [

                'status'=>false,

                'message'=>'results key missing.'

            ];

        }



        if(!is_array($response['results'])){


            return [

                'status'=>false,

                'message'=>'results should be array.'

            ];

        }



        $validated=[];



        foreach($response['results'] as $item){



            if(
                empty($item['applicant_id'])
            ){

                continue;

            }



            /*
            |--------------------------------------------------
            | Validate Matches
            |--------------------------------------------------
            */

            $matches=$this->validateRoleMatching([

                'matches'=>$item['matches'] ?? []

            ]);



            /*
            |--------------------------------------------------
            | Keep Applicant Even If AI Failed
            |--------------------------------------------------
            */

            if(!$matches['status']){


                $validated[]=[

                    'applicant_id'=>$item['applicant_id'],

                    'matches'=>[],

                    'ai_response'=>$this->validateAIResponse(
                        $item['ai_response'] ?? []
                    )

                ];


                continue;

            }



            $validated[]=[


                'applicant_id'=>$item['applicant_id'],


                'matches'=>$matches['matches'],


                'ai_response'=>$this->validateAIResponse(

                    $item['ai_response'] ?? []

                )


            ];

        }



        return [

            'status'=>true,

            'results'=>$validated

        ];

    }





    /**
     * Validate ATS AI Response
     */
    private function validateAIResponse(
        array $ai
    ): array {


        return [


            "overall_match_score"=>
                $this->score(
                    $ai['overall_match_score'] ?? 0
                ),


            "ats_keyword_match_score"=>
                $this->score(
                    $ai['ats_keyword_match_score'] ?? 0
                ),


            "skills_alignment_score"=>
                $this->score(
                    $ai['skills_alignment_score'] ?? 0
                ),


            "experience_relevance_score"=>
                $this->score(
                    $ai['experience_relevance_score'] ?? 0
                ),


            "impact_metrics_score"=>
                $this->score(
                    $ai['impact_metrics_score'] ?? 0
                ),


            "role_responsibility_match_score"=>
                $this->score(
                    $ai['role_responsibility_match_score'] ?? 0
                ),



            "missing_keywords"=>
                $this->arrayValue(
                    $ai['missing_keywords'] ?? []
                ),



            "strengths"=>
                $this->arrayValue(
                    $ai['strengths'] ?? []
                ),



            "weaknesses"=>
                $this->arrayValue(
                    $ai['weaknesses'] ?? []
                ),



            "resume_improvements"=>
                $this->arrayValue(
                    $ai['resume_improvements'] ?? []
                ),



            "rewritten_bullets"=>
                $this->arrayValue(
                    $ai['rewritten_bullets'] ?? []
                ),



            "optimized_summary"=>
                $ai['optimized_summary'] ?? ''

        ];

    }





    /**
     * Score Validation
     */
    private function score($value): int
    {

        return max(
            0,
            min(
                100,
                (int)$value
            )
        );

    }





    private function arrayValue($value): array
    {

        return is_array($value)
            ? $value
            : [];

    }





    /**
     * Active Role IDs
     */
    private function getRoleIds(): array
    {

        return Cache::rememberForever(

            'hf_role_ids',

            function(){

                return DB::table(
                    'egc_recruitment_roles'
                )
                ->where('status',0)
                ->pluck('sno')
                ->toArray();

            }

        );

    }




    /**
     * Clear Cache
     */
    public function clearCache()
    {

        Cache::forget(
            'hf_role_ids'
        );

    }


}