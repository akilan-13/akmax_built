<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class ApplicantBatchService
{
    protected ResumeParserService $resumeParser;

    protected PromptBuilderService $promptBuilder;

    protected HuggingFaceClientService $huggingFace;

    protected AIResponseValidatorService $validator;

    protected ApplicantUpdaterService $updater;


    public function __construct(
        ResumeParserService $resumeParser,
        PromptBuilderService $promptBuilder,
        HuggingFaceClientService $huggingFace,
        AIResponseValidatorService $validator,
        ApplicantUpdaterService $updater
    ) {

        $this->resumeParser = $resumeParser;

        $this->promptBuilder = $promptBuilder;

        $this->huggingFace = $huggingFace;

        $this->validator = $validator;

        $this->updater = $updater;
    }


    /**
     * =========================================================
     * PROCESS APPLICANT BATCH
     * =========================================================
     *
     * Cursor based processing.
     *
     * $lastSno means:
     *
     * "Give me applicants where sno > lastSno"
     *
     * This is safer than offset pagination for large
     * production backfills.
     */
    public function process(
        int $batchSize = 5,
        int $limit = 5,
        int $lastSno = 0,
        bool $forceReprocess = false
    ): array {

        /*
        |--------------------------------------------------------------------------
        | Safety limits
        |--------------------------------------------------------------------------
        */

        $batchSize = max(
            1,
            min(
                10,
                $batchSize
            )
        );

        $limit = max(
            1,
            min(
                500,
                $limit
            )
        );


        /*
        |--------------------------------------------------------------------------
        | Never process more than the requested limit.
        |--------------------------------------------------------------------------
        */

        $take = min(
            $batchSize,
            $limit
        );


        /*
        |--------------------------------------------------------------------------
        | Load active company roles.
        |--------------------------------------------------------------------------
        */

        $roles = $this->getActiveRoles();


        if (empty($roles)) {

            return [

                'status' => false,

                'message' =>
                    'No active recruitment roles are available.',

                'processed' => 0,

                'matched' => 0,

                'unmatched' => 0,

                'failed' => 0,

                'last_sno' => $lastSno,

                'has_more' => false

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Get next applicant cursor.
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        |
        | We do not use offset().
        |
        | Applicants are always ordered by sno.
        |
        */

        $query = ApplicantModel::query()
            ->where(
                'sno',
                '>',
                $lastSno
            )
            ->orderBy(
                'sno',
                'asc'
            );


        /*
        |--------------------------------------------------------------------------
        | Normal mode:
        |
        | Process applicants that have not yet received an AI response.
        |
        | This means:
        |
        | ai_response IS NULL
        |
        | "[]" in job_role_id is considered a valid processed result.
        |
        */

        if (!$forceReprocess) {

            $query->whereNull(
                'ai_response'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Select only fields required for processing.
        |--------------------------------------------------------------------------
        */

        $applicants = $query
            ->limit($take)
            ->get();


        /*
        |--------------------------------------------------------------------------
        | No applicants remaining.
        |--------------------------------------------------------------------------
        */

        if ($applicants->isEmpty()) {

            return [

                'status' => true,

                'message' =>
                    'No more applicants require processing.',

                'processed' => 0,

                'matched' => 0,

                'unmatched' => 0,

                'failed' => 0,

                'last_sno' => $lastSno,

                'has_more' => false

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Prepare resumes.
        |--------------------------------------------------------------------------
        */

        $applicantPayload = [];

        $applicantMap = [];


        foreach ($applicants as $applicant) {

            $resume = '';

            try {

                $resume =
                    $this->resumeParser
                        ->getResumeText(
                            $applicant
                        );

            } catch (Throwable $e) {

                Log::error(
                    'Resume extraction failed during bulk AI processing',
                    [
                        'applicant_id' =>
                            $applicant->sno,

                        'error' =>
                            $e->getMessage()
                    ]
                );
            }


            $resume = trim(
                $resume
            );


            /*
            |--------------------------------------------------------------------------
            | Keep applicant indexed by ID.
            |--------------------------------------------------------------------------
            */

            $applicantMap[
                (string) $applicant->sno
            ] = $applicant;


            /*
            |--------------------------------------------------------------------------
            | Send resume to AI.
            |--------------------------------------------------------------------------
            |
            | Keep the prompt size controlled.
            |
            */

            $applicantPayload[] = [

                'sno' =>
                    (string) $applicant->sno,

                'resume' =>
                    $this->prepareResume(
                        $resume
                    )

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Build enterprise ATS prompt.
        |--------------------------------------------------------------------------
        */

        $prompt =
            $this->promptBuilder
                ->batchRoleMatching(
                    $applicantPayload,
                    $roles
                );


        /*
        |--------------------------------------------------------------------------
        | Call Hugging Face / Llama.
        |--------------------------------------------------------------------------
        */

        $aiResponse =
            $this->huggingFace
                ->askJson(
                    $prompt
                );


        /*
        |--------------------------------------------------------------------------
        | AI request failed.
        |--------------------------------------------------------------------------
        |
        | IMPORTANT:
        |
        | Do not write fake role matches.
        |
        | Do not overwrite existing records.
        |
        */

        if (
            !$aiResponse['status']
        ) {

            Log::error(
                'Bulk AI request failed',
                [
                    'last_sno' =>
                        $lastSno,

                    'applicant_ids' =>
                        $applicants
                            ->pluck('sno')
                            ->values()
                            ->toArray(),

                    'error' =>
                        $aiResponse['message']
                            ?? 'Unknown AI error'
                ]
            );


            /*
            |--------------------------------------------------------------------------
            | Move cursor forward.
            |--------------------------------------------------------------------------
            |
            | We report these as failed.
            |
            | The frontend can stop/retry.
            |
            */

            $newLastSno =
                (int) $applicants
                    ->last()
                    ->sno;


            return [

                'status' => false,

                'message' =>
                    'AI request failed. No applicant records were overwritten.',

                'processed' => 0,

                'matched' => 0,

                'unmatched' => 0,

                'failed' =>
                    $applicants->count(),

                'last_sno' =>
                    $newLastSno,

                /*
                 * Do not automatically continue after
                 * an entire AI request failed.
                 */
                'has_more' => true

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Validate complete AI response.
        |--------------------------------------------------------------------------
        */

        $validated =
            $this->validator
                ->validateBatchRoleMatching(
                    $aiResponse['data']
                );


        if (
            !$validated['status']
        ) {

            Log::error(
                'Bulk AI response validation failed',
                [
                    'last_sno' =>
                        $lastSno,

                    'error' =>
                        $validated['message']
                            ?? 'Invalid AI response'
                ]
            );


            return [

                'status' => false,

                'message' =>
                    'AI returned an invalid recruitment response.',

                'processed' => 0,

                'matched' => 0,

                'unmatched' => 0,

                'failed' =>
                    $applicants->count(),

                'last_sno' =>
                    $lastSno,

                'has_more' => true

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Index AI results by applicant_id.
        |--------------------------------------------------------------------------
        */

        $resultsByApplicant = [];


        foreach (
            $validated['results']
            as $result
        ) {

            $applicantId =
                (string) (
                    $result['applicant_id']
                    ?? ''
                );


            if (
                $applicantId === ''
            ) {
                continue;
            }


            $resultsByApplicant[
                $applicantId
            ] = $result;
        }


        /*
        |--------------------------------------------------------------------------
        | Counters.
        |--------------------------------------------------------------------------
        */

        $processed = 0;

        $matched = 0;

        $unmatched = 0;

        $failed = 0;


        /*
        |--------------------------------------------------------------------------
        | Save each applicant independently.
        |--------------------------------------------------------------------------
        */

        foreach (
            $applicants as $applicant
        ) {

            $applicantId =
                (string) $applicant->sno;


            /*
            |--------------------------------------------------------------------------
            | AI must return every applicant.
            |--------------------------------------------------------------------------
            */

            if (
                !isset(
                    $resultsByApplicant[
                        $applicantId
                    ]
                )
            ) {

                $failed++;

                Log::error(
                    'AI omitted applicant from batch response',
                    [
                        'applicant_id' =>
                            $applicantId
                    ]
                );

                continue;
            }


            $result =
                $resultsByApplicant[
                    $applicantId
                ];


            /*
            |--------------------------------------------------------------------------
            | Validate role IDs one more time at persistence layer.
            |--------------------------------------------------------------------------
            |
            | Defense in depth.
            |
            */

            $safeMatches =
                $this->sanitizeMatches(
                    $result['matches']
                        ?? [],
                    $roles
                );


            /*
            |--------------------------------------------------------------------------
            | Validate AI analysis.
            |--------------------------------------------------------------------------
            */

            $safeAiResponse =
                $this->sanitizeAiResponse(
                    $result['ai_response']
                        ?? []
                );


            /*
            |--------------------------------------------------------------------------
            | Final structure stored in applicant.ai_response.
            |--------------------------------------------------------------------------
            */

            $finalAiData = [

                'matches' =>
                    $safeMatches,

                'ai_response' =>
                    $safeAiResponse

            ];


            /*
            |--------------------------------------------------------------------------
            | Save applicant.
            |--------------------------------------------------------------------------
            */

            try {

                $saveResult =
                    $this->updater
                        ->saveRoleMatching(
                            $applicant,
                            $finalAiData
                        );


                if (
                    !$saveResult['status']
                ) {

                    $failed++;

                    continue;
                }


                $processed++;


                if (
                    empty(
                        $safeMatches
                    )
                ) {

                    $unmatched++;

                } else {

                    $matched++;
                }


            } catch (Throwable $e) {

                $failed++;


                Log::error(
                    'Applicant AI result save failed',
                    [
                        'applicant_id' =>
                            $applicantId,

                        'error' =>
                            $e->getMessage()
                    ]
                );
            }
        }


        /*
        |--------------------------------------------------------------------------
        | New cursor.
        |--------------------------------------------------------------------------
        */

        $newLastSno =
            (int) $applicants
                ->last()
                ->sno;


        /*
        |--------------------------------------------------------------------------
        | Determine whether applicants remain.
        |--------------------------------------------------------------------------
        */

        $hasMore =
            $this->hasMoreApplicants(
                $newLastSno,
                $forceReprocess
            );


        return [

            'status' => true,

            'message' =>
                'AI applicant batch processed successfully.',

            'processed' =>
                $processed,

            'matched' =>
                $matched,

            'unmatched' =>
                $unmatched,

            'failed' =>
                $failed,

            'last_sno' =>
                $newLastSno,

            'has_more' =>
                $hasMore

        ];
    }


    /**
     * =========================================================
     * ACTIVE COMPANY ROLES
     * =========================================================
     *
     * No hard-coded role names.
     *
     * Every currently active role in:
     *
     * egc_recruitment_roles
     *
     * becomes available to the AI.
     */
    protected function getActiveRoles(): array
    {

        return DB::table(
            'egc_recruitment_roles'
        )
        ->where(
            'status',
            0
        )
        ->select('egc_recruitment_roles.sno','egc_recruitment_roles.jobrole_name as role_name')
        ->orderBy(
            'sno',
            'asc'
        )
        ->get()
        ->map(
            function ($role) {

                return $role->toArray();

            }
        )
        ->values()
        ->toArray();
    }


    /**
     * =========================================================
     * PREPARE RESUME
     * =========================================================
     */

    protected function prepareResume(
        string $resume
    ): string {

        if (
            $resume === ''
        ) {

            return '[NO RESUME TEXT AVAILABLE]';
        }


        /*
        |--------------------------------------------------------------------------
        | Normalize whitespace.
        |--------------------------------------------------------------------------
        */

        $resume =
            preg_replace(
                '/\s+/u',
                ' ',
                $resume
            );


        $resume =
            trim(
                $resume
            );


        /*
        |--------------------------------------------------------------------------
        | Protect AI context window.
        |--------------------------------------------------------------------------
        |
        | 5000 characters per applicant is intentionally
        | conservative for batch processing.
        |
        */

        return mb_substr(
            $resume,
            0,
            5000
        );
    }


    /**
     * =========================================================
     * SANITIZE ROLE MATCHES
     * =========================================================
     *
     * Second validation layer before DB persistence.
     */

    protected function sanitizeMatches(
        array $matches,
        array $roles
    ): array {

        $validRoleIds = collect(
            $roles
        )
        ->pluck('sno')
        ->map(
            fn ($id) => (int) $id
        )
        ->values()
        ->toArray();


        $safe = [];


        foreach (
            $matches
            as $match
        ) {

            if (
                !is_array($match)
            ) {
                continue;
            }


            if (
                !isset(
                    $match['role_id']
                )
            ) {
                continue;
            }


            $roleId =
                (int) $match['role_id'];


            /*
            |--------------------------------------------------------------------------
            | Never allow AI-created role IDs.
            |--------------------------------------------------------------------------
            */

            if (
                !in_array(
                    $roleId,
                    $validRoleIds,
                    true
                )
            ) {

                continue;
            }


            $confidence =
                isset(
                    $match['confidence']
                )
                    ? (float)
                        $match['confidence']
                    : 0;


            $confidence =
                max(
                    0,
                    min(
                        100,
                        $confidence
                    )
                );


            $reason =
                trim(
                    (string) (
                        $match['reason']
                        ?? ''
                    )
                );


            if (
                $reason === ''
            ) {

                $reason =
                    'Role match identified from resume evidence.';
            }


            $safe[] = [

                'role_id' =>
                    $roleId,

                'confidence' =>
                    round(
                        $confidence,
                        2
                    ),

                'reason' =>
                    mb_substr(
                        $reason,
                        0,
                        1000
                    )

            ];
        }


        /*
        |--------------------------------------------------------------------------
        | Remove duplicate roles.
        |--------------------------------------------------------------------------
        */

        $safe =
            collect(
                $safe
            )
            ->unique(
                'role_id'
            )
            ->sortByDesc(
                'confidence'
            )
            ->values()
            ->toArray();


        /*
        |--------------------------------------------------------------------------
        | IMPORTANT:
        |
        | We do NOT limit to 3.
        |
        | Multiple genuine company roles are allowed.
        |
        */

        return $safe;
    }


    /**
     * =========================================================
     * SANITIZE ATS RESPONSE
     * =========================================================
     */

    protected function sanitizeAiResponse(
        array $ai
    ): array {

        return [

            'overall_match_score' =>
                $this->score(
                    $ai[
                        'overall_match_score'
                    ] ?? 0
                ),

            'ats_keyword_match_score' =>
                $this->score(
                    $ai[
                        'ats_keyword_match_score'
                    ] ?? 0
                ),

            'skills_alignment_score' =>
                $this->score(
                    $ai[
                        'skills_alignment_score'
                    ] ?? 0
                ),

            'experience_relevance_score' =>
                $this->score(
                    $ai[
                        'experience_relevance_score'
                    ] ?? 0
                ),

            'impact_metrics_score' =>
                $this->score(
                    $ai[
                        'impact_metrics_score'
                    ] ?? 0
                ),

            'role_responsibility_match_score' =>
                $this->score(
                    $ai[
                        'role_responsibility_match_score'
                    ] ?? 0
                ),

            'missing_keywords' =>
                $this->arrayValue(
                    $ai[
                        'missing_keywords'
                    ] ?? []
                ),

            'strengths' =>
                $this->arrayValue(
                    $ai[
                        'strengths'
                    ] ?? []
                ),

            'weaknesses' =>
                $this->arrayValue(
                    $ai[
                        'weaknesses'
                    ] ?? []
                ),

            'resume_improvements' =>
                $this->arrayValue(
                    $ai[
                        'resume_improvements'
                    ] ?? []
                ),

            'rewritten_bullets' =>
                $this->arrayValue(
                    $ai[
                        'rewritten_bullets'
                    ] ?? []
                ),

            'optimized_summary' =>
                mb_substr(
                    trim(
                        (string) (
                            $ai[
                                'optimized_summary'
                            ] ?? ''
                        )
                    ),
                    0,
                    5000
                )

        ];
    }


    /**
     * =========================================================
     * SCORE
     * =========================================================
     */

    protected function score(
        mixed $value
    ): int {

        return max(
            0,
            min(
                100,
                (int) $value
            )
        );
    }


    /**
     * =========================================================
     * ARRAY VALUE
     * =========================================================
     */

    protected function arrayValue(
        mixed $value
    ): array {

        if (
            !is_array($value)
        ) {

            return [];
        }


        /*
        |--------------------------------------------------------------------------
        | Remove empty values.
        |--------------------------------------------------------------------------
        */

        return collect(
            $value
        )
        ->map(
            function ($item) {

                if (
                    is_array($item)
                ) {

                    return $item;
                }

                return trim(
                    (string) $item
                );
            }
        )
        ->filter(
            function ($item) {

                if (
                    is_array($item)
                ) {

                    return !empty(
                        $item
                    );
                }

                return $item !== '';
            }
        )
        ->values()
        ->toArray();
    }


    /**
     * =========================================================
     * CHECK REMAINING APPLICANTS
     * =========================================================
     */

    protected function hasMoreApplicants(
        int $lastSno,
        bool $forceReprocess
    ): bool {

        $query =
            ApplicantModel::query()
                ->where(
                    'sno',
                    '>',
                    $lastSno
                );


        if (
            !$forceReprocess
        ) {

            $query->whereNull(
                'ai_response'
            );
        }


        return $query->exists();
    }


    /**
     * =========================================================
     * BULK STATISTICS
     * =========================================================
     */

    public function statistics(): array
    {

        $pendingCount =
            ApplicantModel::query()
                ->whereNull(
                    'ai_response'
                )
                ->count();


        $activeRoleCount =
            DB::table(
                'egc_recruitment_roles'
            )
            ->where(
                'status',
                0
            )
            ->count();


        return [

            'pending_count' =>
                $pendingCount,

            'active_role_count' =>
                $activeRoleCount,

            'recommended_batch_size' =>
                5

        ];
    }
}