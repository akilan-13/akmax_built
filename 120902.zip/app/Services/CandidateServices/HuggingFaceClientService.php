<?php

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class HuggingFaceClientService
{
    /**
     * Default Model
     */
    // protected string $model = 'meta-llama/Llama-3.1-8B-Instruct:novita';
    protected string $model =
    'Qwen/Qwen3-30B-A3B-Instruct-2507';

    /**
     * Send Prompt
     */
    public function ask(
        string $prompt,
        string $model = null,
        int $temperature = 0,
        int $timeout = 120
    ): array {

        try {

            $apiKey = $this->getApiKey();

            if (!$apiKey) {

                return [
                    'status' => false,
                    'message' => 'HuggingFace API Key Missing'
                ];

            }

            $response = Http::timeout($timeout)

                ->retry(3,3000)

                ->withToken($apiKey)

                ->acceptJson()

                ->post(

                    'https://router.huggingface.co/v1/chat/completions',

                    [
                        'model'=>$model ?? $this->model,

                        'messages'=>[
                            [
                                'role'=>'system',
                                'content'=>'Return only valid JSON. No markdown. No explanation.'
                            ],
                            [
                                'role'=>'user',
                                'content'=>$prompt
                            ]
                        ],

                        'temperature'=>0,

                        'response_format'=>[
                            'type'=>'json_object'
                        ],

                        'stream'=>false
                    ]

                );

            if(!$response->successful()){

                Log::error(
                    'HF API ERROR',
                    [
                        'status'=>$response->status(),
                        'body'=>$response->body()
                    ]
                );

                return [

                    'status'=>false,

                    'message'=>$response->body()

                ];

            }

            $content = data_get(

                $response->json(),

                'choices.0.message.content'

            );

            return [

                'status'=>true,

                'content'=>$this->cleanJson($content)

            ];

        }

        catch(Exception $e){

            Log::error(

                'HF Exception',

                [

                    'message'=>$e->getMessage()

                ]

            );

            return [

                'status'=>false,

                'message'=>$e->getMessage()

            ];

        }

    }

    /**
     * JSON Response
     */
    public function askJson(
    string $prompt,
    string $model = null
): array
{

    $response = $this->ask(
        $prompt,
        $model
    );


    if(!$response['status']){

        return $response;

    }


    $cleanJson = $this->extractJson(
        $response['content']
    );


    $json = json_decode(
        $cleanJson,
        true
    );


    if(json_last_error()!=JSON_ERROR_NONE){


        Log::error(
            'AI JSON Decode Failed',
            [
                'error'=>json_last_error_msg(),
                'json'=>$cleanJson
            ]
        );


        return [

            'status'=>false,

            'message'=>'Invalid JSON returned by AI.',

            'raw'=>$response['content']

        ];

    }



    return [

        'status'=>true,

        'data'=>$json

    ];

}

    /**
     * Clean AI JSON
     */
   private function cleanJson($text): string
    {

        $text = trim($text);


        // remove markdown
        $text = preg_replace(
            '/```(?:json)?/i',
            '',
            $text
        );


        // remove common AI prefixes
        $patterns = [
            '/^Here is.*?:/is',
            '/^Output:/is',
            '/^JSON:/is'
        ];


        foreach($patterns as $pattern){

            $text = preg_replace(
                $pattern,
                '',
                $text
            );

        }


        return trim($text);
    }

private function extractJson(string $text): string
{
    $text = $this->cleanJson($text);

    $start = strpos($text, '{');

    if ($start === false) {
        return '';
    }


    $json = substr($text, $start);


    $brace = 0;
    $bracket = 0;

    $inString = false;
    $escape = false;


    for($i=0; $i < strlen($json); $i++)
    {

        $char = $json[$i];


        if($char === '"' && !$escape)
        {
            $inString = !$inString;
        }


        if($char === '\\' && !$escape)
        {
            $escape = true;
            continue;
        }


        $escape = false;


        if(!$inString)
        {

            if($char === '{')
            {
                $brace++;
            }

            elseif($char === '}')
            {
                $brace--;
            }


            elseif($char === '[')
            {
                $bracket++;
            }


            elseif($char === ']')
            {
                $bracket--;
            }


            if($brace === 0 && $bracket === 0)
            {
                return substr(
                    $json,
                    0,
                    $i+1
                );
            }

        }

    }


    return '';
}

    /**
     * API Key
     */
    private function getApiKey(): ?string
    {
        return Cache::rememberForever(

            'hf_api_key',

            function(){

                $api = DB::table(
                    'egc_api_integration'
                )

                ->where(
                    'api_key',
                    'egc_huggingface_api_1'
                )

                ->where(
                    'status',
                    0
                )

                ->latest('sno')

                ->first();

                if(!$api){

                    return null;

                }

                $fields = json_decode(
                    $api->api_fields,
                    true
                );

                foreach($fields as $field){

                    if($field['key']=='api_key'){

                        return trim(
                            $field['value']
                        );

                    }

                }

                return null;

            }

        );
    }

    /**
     * Clear API Cache
     */
    public function clearApiCache()
    {
        Cache::forget(
            'hf_api_key'
        );
    }

    /**
     * Change Default Model
     */
    public function setModel(
        string $model
    )
    {
        $this->model = $model;
    }

}