<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;

class ApplicantUpdaterService
{
    /**
     * Save AI Role Matching
     */
    // public function saveRoleMatching(
    //     ApplicantModel $applicant,
    //      array $aiData
    // ): array {

    //     DB::beginTransaction();

    //     try {

    //         $roleIds = collect($aiData['matches'])
    //                 ->pluck('role_id')
    //                 ->unique()
    //                 ->values()
    //                 ->toArray();

    //         // $confidence = collect($matches)
    //         //     ->max('confidence');

    //         $applicant->job_role_id = !empty($roleIds) ? 
    //                         json_encode($roleIds, JSON_UNESCAPED_UNICODE) : NULL;

    //         // $applicant->match_score = $confidence;

    //         $applicant->ai_response = json_encode(
    //              $aiData,
    //             JSON_UNESCAPED_UNICODE
    //         );

    //         $applicant->updated_at = now();

    //         $applicant->save();

    //         DB::commit();

    //         return [

    //             'status' => true,

    //             'message' => 'Updated successfully.',

    //             'job_role_ids' => $roleIds,

    //             // 'confidence' => $confidence

    //         ];

    //     } catch (Exception $e) {

    //         DB::rollBack();

    //         Log::error(
    //             'Applicant Update Failed',
    //             [
    //                 'applicant_id' => $applicant->sno,
    //                 'error' => $e->getMessage()
    //             ]
    //         );

    //         return [

    //             'status' => false,

    //             'message' => $e->getMessage()

    //         ];

    //     }

    // }

    /**
     * Clear AI Result
     */
    public function clearRoleMatching(
        ApplicantModel $applicant
    ): bool {

        return $applicant->update([

            'job_role_id' => null,

            'match_score' => null,

            'ai_response' => null

        ]);

    }

    /**
     * Update Resume Text
     */
    // public function updateResumeText(
    //     ApplicantModel $applicant,
    //     string $resume
    // ): bool {

    //     return $applicant->update([

    //         'resume_text' => $resume

    //     ]);

    // }

    public function updateResumeText(
        ApplicantModel $applicant,
        string $resume
    ): bool {


        // Remove invalid UTF8 characters
        $resume = mb_convert_encoding(
            $resume,
            'UTF-8',
            'UTF-8'
        );


        // Remove control characters from PDF
        $resume = preg_replace(
            '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',
            '',
            $resume
        );


        return $applicant->update([
            'resume_text'=>$resume
        ]);

    }

}