<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class ApplicantUpdaterService
{
    /**
     * Save AI Role Matching
     */
    public function saveRoleMatching(
        ApplicantModel $applicant,
        array $aiData
    ): array {

        DB::beginTransaction();

        try {

            $matches = collect(
                $aiData['matches'] ?? []
            )
                ->filter(function ($match) {

                    return isset(
                        $match['role_id']
                    );
                })
                ->unique('role_id')
                ->values();

            $roleIds = $matches
                ->pluck('role_id')
                ->map(fn ($id) => (int) $id)
                ->values()
                ->toArray();

            /*
             * Highest role confidence.
             */
            $matchScore = $matches
                ->max(function ($match) {

                    return (float) (
                        $match['confidence']
                        ?? 0
                    );
                });

            /*
             * IMPORTANT:
             *
             * [] means AI analysed successfully
             * but no suitable company role.
             */
            $applicant->job_role_id =
                json_encode(
                    $roleIds,
                    JSON_UNESCAPED_UNICODE
                );

            $applicant->match_score =
                !empty($roleIds)
                    ? round(
                        $matchScore,
                        2
                    )
                    : 0;

            $applicant->ai_response =
                json_encode(
                    $aiData,
                    JSON_UNESCAPED_UNICODE
                );

            $applicant->updated_at =
                now();

            $applicant->save();

            DB::commit();

            return [
                'status' => true,

                'message' =>
                    'AI role matching saved.',

                'job_role_ids' =>
                    $roleIds,

                'match_score' =>
                    !empty($roleIds)
                        ? round(
                            $matchScore,
                            2
                        )
                        : 0,
            ];

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error(
                'Applicant AI Update Failed',
                [
                    'applicant_sno' =>
                        $applicant->sno,

                    'error' =>
                        $e->getMessage(),

                    'file' =>
                        $e->getFile(),

                    'line' =>
                        $e->getLine(),
                ]
            );

            return [
                'status' => false,
                'message' =>
                    'Unable to save AI matching result.'
            ];
        }
    }

    /**
     * Clear AI result.
     */
    public function clearRoleMatching(
        ApplicantModel $applicant
    ): bool {

        return $applicant->update([
            'job_role_id' => null,
            'match_score' => null,
            'ai_response' => null,
            'ai_summary' => null,
        ]);
    }

    /**
     * Update resume text.
     */
    public function updateResumeText(
        ApplicantModel $applicant,
        string $resume
    ): bool {

        $resume = mb_convert_encoding(
            $resume,
            'UTF-8',
            'UTF-8'
        );

        $resume = preg_replace(
            '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',
            '',
            $resume
        );

        return $applicant->update([
            'resume_text' => $resume
        ]);
    }
}