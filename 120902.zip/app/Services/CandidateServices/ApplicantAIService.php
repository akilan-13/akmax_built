<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;

class ApplicantAIService
{

    public function getApplicant(int $id): array
    {

        $applicant = ApplicantModel::where('egc_applicant.status', '!=', 2)
            ->leftJoin('egc_job_request', 'egc_applicant.job_request_id', 'egc_job_request.sno')
            ->leftJoin('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_source', 'egc_applicant.source_id', 'egc_source.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->leftJoin('egc_major', 'egc_applicant.major', 'egc_major.sno')
            ->leftJoin('egc_job_fair', 'egc_applicant.job_fair_id', 'egc_job_fair.sno')
            ->leftJoin('egc_qualification_level', 'egc_applicant.qualification_id', 'egc_qualification_level.sno')
            ->distinct('egc_applicant.sno')
            ->select(
                'egc_applicant.*',
                'egc_job_request.status as job_request_status',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_company.company_name',
                'egc_major.major_name',
                'egc_qualification_level.qualification_level_name',
                'egc_job_fair.job_fair_name',
                'egc_source.source_name as applicant_source_name',
                'egc_company.company_base_color',
            )
            ->where('egc_applicant.sno',$id)
            ->first();

        if(!$applicant){
            return [
                'status'=>false,
                'message'=>'Applicant not found.'
            ];
        }

        return [

            'status'=>true,
            'data'=>[
                'candidate'=>$this->candidate($applicant),
                'ai'=>$this->ai($applicant),
                'resume'=>$this->resume($applicant)
            ]

        ];

    }

    /**
     * Candidate
     */
    private function candidate($applicant): array
    {
        return [
            'id'=>$applicant->sno,
            'name'=>$applicant->applicant_name,
            'email'=>$applicant->email,
            'mobile'=>$applicant->mobile,
            'experience'=>$applicant->experience_count,
            'qualification'=>$applicant->qualification_level_name ? $applicant->qualification_level_name  : ($applicant->qualification_id == 'Others' ? $applicant->other_qualification : '') ,
            'major_name'=>$applicant->major_name ? $applicant->major_name  : ($applicant->major_name == 'Others' ? $applicant->other_qualification : '') ,
            'current_company'=>$applicant->current_company,
            'current_designation'=>$applicant->job_role_name,
            'current_ctc'=>$applicant->current_ctc,
            'expected_ctc'=>$applicant->expected_ctc,
            'notice_period'=>$applicant->notice_period,
            'location'=>$applicant->location,
            'resume'=>$applicant->attachment,
            'resume_text'=>$applicant->resume_text
        ];

    }

    /**
     * AI
     */
    private function ai($applicant): array
    {

        if(empty($applicant->ai_response)){

            return [];

        }

        return json_decode(
            $applicant->ai_response,
            true
        ) ?? [];

    }

    /**
     * Resume
     */
    private function resume($applicant): array
    {

        return [
            'text'=>$applicant->resume_text,
            'attachment'=>$applicant->attachment

        ];

    }

}