<?php

namespace App\Services;

use Carbon\Carbon;
use App\Models\StaffModel;
use App\Models\StaffSalaryAppraisalHistoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppraisalService
{
    public function list(Request $request)
    {

        $year = $request->year ?? now()->year;

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        $query = StaffModel::query()
            ->select(
                'egc_staff.*',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_entity.entity_name'
            )

            ->leftJoin('egc_department','egc_department.sno','=','egc_staff.department_id')
            ->leftJoin('egc_division','egc_division.sno','=','egc_staff.division_id')
            ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_staff.job_role_id')
            ->leftJoin('egc_company','egc_company.sno','=','egc_staff.company_id')
            ->leftJoin('egc_entity','egc_entity.sno','=','egc_staff.entity_id')
            ->where('egc_staff.status','!=',2);

            if($request->filled('search_filter')){
                $search=$request->search_filter;
                $query->where(function($q) use($search){
                    $q->where('egc_staff.staff_name','like',"%{$search}%")
                    ->orWhere('egc_staff.staff_id','like',"%{$search}%")
                    ->orWhere('egc_staff.mobile_no','like',"%{$search}%");
                });
            }
            if($request->company_fill){
                $query->where('egc_staff.company_id',$request->company_fill);
            }

            if($request->entity_fill){
                $query->where('egc_staff.entity_id',$request->entity_fill);
            }

            if($request->department_fill){
                $query->where('egc_staff.department_id',$request->department_fill);
            }
            if($request->division_fill){
                $query->where('egc_staff.division_id',$request->division_fill);
            }

            if($request->job_role_fill){
                $query->where('egc_staff.job_role_id',$request->job_role_fill);
            }

            $dashboardQuery = clone $query;
            $dashboardStaffIds = $dashboardQuery->pluck('egc_staff.sno');
            $totalStaff = $dashboardStaffIds->count();
            $totalSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
            ->sum('basic_salary');
            $highestSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->max('basic_salary');
                    $lowestSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->min('basic_salary');
            $averageSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->avg('basic_salary');
            $thisYearAppraisal = StaffSalaryAppraisalHistoryModel::active()
            // ->processed()
            ->where('status',0)
            ->whereNot('appraisal_type',0)
            ->whereYear('effective_from',now()->year)
            ->whereIn('employee_sno',$dashboardStaffIds)
            ->count();

            $thisMonthAppraisal = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereYear('effective_from',now()->year)
                ->whereMonth('effective_from',now()->month)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->count();

            $appraisedStaff = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->distinct('employee_sno')
                ->count('employee_sno');

            $appraisalTypes = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->selectRaw('appraisal_type,COUNT(*) total')
                ->groupBy('appraisal_type')
                ->pluck('total','appraisal_type');
            $avgIncrement = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->selectRaw('AVG(appraisal_value) avg_increment')
                ->value('avg_increment');

            $staffs=$query
                ->orderBy('egc_staff.date_of_joining','asc')
                ->paginate($perpage);

            $staffIds=$staffs->pluck('sno');

            $histories=StaffSalaryAppraisalHistoryModel::active()
                        // ->processed()
                        ->where('status',0)
                        ->whereIn('employee_sno',$staffIds)
                        ->orderBy('effective_from')
                        ->get()
                        ->groupBy('employee_sno');
            $headers = [];

            $firstJoining = StaffModel::where('status', '!=', 2)
                            ->whereIn('sno',$staffIds)
                            ->min('date_of_joining');
            $startHeader = Carbon::parse($firstJoining)->startOfMonth();
            $endHeader = now()->startOfMonth();
            $temp = $startHeader->copy();

            while ($temp <= $endHeader) {
                $headers[] = [
                    'key' => $temp->format('Y-m'),
                    'label' => $temp->format('M-y'),
                    'year' => $temp->year,
                    'month' => $temp->month
                ];
                $temp->addMonth();
            }

            $staffs->getCollection()->transform(function ($staff) use ($histories, $headers) {

                $joiningDate = Carbon::parse($staff->date_of_joining)->startOfMonth();
                $exitDate = null;

                switch ((int)$staff->status) {
                    case 4: // Notice
                        if (!empty($staff->notice_end_date)) {
                            $exitDate = Carbon::parse($staff->notice_end_date)->startOfMonth();
                        }
                    break;
                    case 5: // Relieved
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 6: // Abscond
                         if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 7: // Terminated
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }

                    break;
                }
                $salaryHistory = $histories[$staff->sno] ?? collect();
                $timeline = [];
                $latestSalary = $staff->basic_salary;

                foreach ($headers as $header) {
                    $current = Carbon::create( $header['year'],$header['month'],1);

                    if ($exitDate && $current->gt($exitDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'exited',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    if ($current->lt($joiningDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'before_join',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    

                    $record = $salaryHistory
                        ->filter(function ($item) use ($current) {
                            return Carbon::parse($item->effective_from)
                                ->startOfMonth()
                                ->lte($current);

                        })
                        ->last();

                    
                    if ($record) {
                        $latestSalaryPrevious = $record->gross_salary;
                        $latestSalary = $record->gross_salary;
                        $hikeValue =0 ;

                        if ($record->appraisal_unit == '%') {
                            $hikeValue =  ($record->appraisal_value / 100) * $latestSalaryPrevious ;
                        } else {
                            $hikeValue =  $record->appraisal_value ?? 0;
                        }

                        $latestSalary = $latestSalaryPrevious + round($hikeValue);

                    }

                    

                    $status = "normal";

                    if ($current->equalTo($joiningDate)) {
                        $status = "joining";
                    }

                    if ($record && Carbon::parse($record->effective_from)->format('Y-m') == $current->format('Y-m')) {

                        if($record->appraisal_type == 0){
                            $status = "joining";
                        }else{
                            $status = "appraisal";
                        } 
                    }

                    if ($current->isCurrentMonth()) {
                        $status = "current";
                    }

                    $timeline[] = [
                        'month' => $header['label'],
                        'salary' => $latestSalary,
                        'status' => $status,
                        'effective_from' => $record ? $record->effective_from->format('Y-m-d') : null,
                        'type' => $record? $record->appraisal_type_name : null
                    ];
                }

                 $total_appraisal_staff =StaffSalaryAppraisalHistoryModel::active()
                    ->where('status',0)
                    ->where('employee_sno',$staff->sno)
                    ->whereNot('appraisal_type',0)
                    ->orderBy('effective_from','asc')
                    ->count();

                $helper = new \App\Helpers\Helpers();
                $general_setting=$helper->general_setting_data();

                if ($staff->company_type == 1) {
                    $staff->company_name = $general_setting->title;
                    $staff->company_base_color = '#ab2b22';
                    $staff->company_logo = $general_setting->logo;
                }

                $staff->total_appraisal = $total_appraisal_staff;
                $staff->current_salary = $latestSalary;
                $staff->timeline = $timeline;
                return $staff;
            });

        return [
            'status' => 200,
            'dashboard'=>[

                'total_staff'=>$totalStaff,

                'appraised_staff'=>$appraisedStaff,

                'average_salary'=>round($averageSalary),

                'highest_salary'=>$highestSalary,

                'lowest_salary'=>$lowestSalary,

                'salary_cost'=>$totalSalary,

                'this_month'=>$thisMonthAppraisal,

                'this_year'=>$thisYearAppraisal,

                'avg_increment'=>round($avgIncrement,2),

                'types'=>[

                    'joining'=>$appraisalTypes[0] ?? 0,

                    'yearly'=>$appraisalTypes[1] ?? 0,

                    'special'=>$appraisalTypes[2] ?? 0,

                    'project'=>$appraisalTypes[3] ?? 0,

                    'warrior'=>$appraisalTypes[5] ?? 0

                ]

            ],

            'headers' => $headers,
            'current_page' => $staffs->currentPage(),
            'last_page' => $staffs->lastPage(),
            'total' => $staffs->total(),
            'data' => $staffs->values()
        ];

    }
    public function details($staffId)
    {
        $staff = StaffModel::query()
            ->leftJoin('egc_department','egc_department.sno','=','egc_staff.department_id')
            ->leftJoin('egc_division','egc_division.sno','=','egc_staff.division_id')
            ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_staff.job_role_id')
            ->select(
                'egc_staff.*',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name'
            )
            ->findOrFail($staffId);

        $history = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                ->orderBy('effective_from')
                ->get();

        $historyWithoutJoining = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                 ->whereNot('appraisal_type',0)
                ->orderBy('effective_from')
                ->get();
        $lastData =StaffSalaryAppraisalHistoryModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->where('appraisal_type',0)
                    ->orderBy('effective_from','asc')
                    ->first();

            $lastDataHisrtry =StaffSalaryAppraisalHistoryModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->orderBy('effective_from','asc')
                    ->first();

        $joiningSalary = $lastData ? $lastData->gross_salary : ($lastDataHisrtry ? $lastDataHisrtry->gross_salary : $staff->basic_salary);

        $currentSalary = $staff->basic_salary ??( $history->count()
            ? $history->last()->gross_salary
            : $joiningSalary);

        $totalIncrement = $currentSalary - $joiningSalary;

        $experience = Carbon::parse($staff->date_of_joining)
            ->diff(now());

        $summary = [
            'joining_salary'   => $joiningSalary,
            'current_salary'   => $currentSalary,
            'highest_salary'   => max($history->pluck('gross_salary')->push($joiningSalary)->toArray()),
            'total_increment'  => $totalIncrement,
            'total_appraisals' => $historyWithoutJoining->count(),
            'salary_growth'    => $joiningSalary > 0
                ? round(($totalIncrement / $joiningSalary) * 100, 1)
                : 0,
            'experience'       => $experience->y . 'Y ' . $experience->m . 'M'
        ];

        $increments = [];

        $highestIncrement = 0;

        $lastSalary = $joiningSalary;

        foreach($history as $row){

            $inc = $row->gross_salary - $lastSalary;

            $increments[] = $inc;

            if($inc > $highestIncrement){
                $highestIncrement = $inc;
            }
            $lastSalary = $row->gross_salary;
        }

        $averageIncrement = count($increments)
            ? round(array_sum($increments)/count($increments),2)
            : 0;

        $summary['highest_increment'] = $highestIncrement;

        $summary['average_increment'] = $averageIncrement;

        return [
            'status'=>200,
            'staff'=>$staff,
            'history'=>$history,
            'summary' => $summary
        ];

    }
}