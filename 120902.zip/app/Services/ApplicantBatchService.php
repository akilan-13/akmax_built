<?php

namespace App\Services;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;

class ApplicantBatchService
{
    protected ResumeParserService $resumeParser;
    protected PromptBuilderService $promptBuilder;
    protected HuggingFaceClientService $hfClient;
    protected AIResponseValidatorService $validator;
    protected ApplicantUpdaterService $updater;
    protected RoleCandidateService $candidateService;

    public function __construct(
        ResumeParserService $resumeParser,
        PromptBuilderService $promptBuilder,
        HuggingFaceClientService $hfClient,
        AIResponseValidatorService $validator,
        ApplicantUpdaterService $updater,
        RoleCandidateService $candidateService
    ) {
        $this->resumeParser = $resumeParser;
        $this->promptBuilder = $promptBuilder;
        $this->hfClient = $hfClient;
        $this->validator = $validator;
        $this->updater = $updater;
        $this->candidateService = $candidateService;
    }

    /**
     * Main Batch Process
     */
    public function process(
        int $batchSize = 20,
        int $limit = 100
        
    ): array {

        $processed = 0;
        $success = 0;
        $failed = 0;

        while (true) {

            /* Get Next Batch */

            $applicants = $this->getApplicants( $batchSize, $limit - $processed );

            if ($applicants->isEmpty()) {
                break;
            }

            /* Prepare Resume Data */
            $preparedApplicants = $this->prepareApplicants( $applicants );
            if (count($preparedApplicants) == 0) {
                break;
            }

            /* AI Matching  */
            $result = $this->matchApplicants($preparedApplicants );

            Log::error(
                    'result response of matchApplicants',
                    [
                        'message' => $result
                    ]
                );

            /* Save */

            if ($result['status']) {
                $save = $this->saveResults(
                    $preparedApplicants,
                    $result['results']
                );

                $success += $save['success'];
                $failed += $save['failed'];

            } else {

                $failed += count($preparedApplicants);

                Log::error(
                    'Batch AI Failed',
                    [
                        'message' => $result['message']
                    ]
                );

            }

            $processed += count($preparedApplicants);

            if ($processed >= $limit) {
                break;
            }

        }

        return [

            'status' => true,

            'processed' => $processed,

            'success' => $success,

            'failed' => $failed,

            'remaining' => $this->remainingApplicants()

        ];

    }


    /* Get Next Applicants */

    private function getApplicants(
        int $batchSize,
        int $remaining
    ) {

        $take = min(
            $batchSize,
            $remaining
        );

        return ApplicantModel::query()

            ->where(function ($q) {

                $q->whereNull('job_role_id')
                    ->orWhere('job_role_id', '');

            })

            ->where('status', '!=', 2)

            ->orderByDesc('sno')

            ->limit($take)

            ->get();

    }

        /**
     * Remaining Applicants
     */
    private function remainingApplicants(): int
    {

        return ApplicantModel::query()

            ->where(function ($q) {

                $q->whereNull('job_role_id')
                    ->orWhere('job_role_id', '');

            })

            ->count();

    }

    /**
     * Prepare Applicants
     */
    private function prepareApplicants($applicants): array
    {
        $prepared = [];

        foreach ($applicants as $applicant) {

            try {

                $resume = trim($applicant->resume_text ?? '');

                /*
                |---------------------------------------------------------
                | Resume Parsing
                |---------------------------------------------------------
                */

                if (empty($resume)) {

                   $resume = $this->resumeParser
                        ->getResumeText($applicant);


                    if(!empty($resume)){


                        $resume = mb_convert_encoding(
                            $resume,
                            'UTF-8',
                            'UTF-8'
                        );


                        $this->updater
                            ->updateResumeText(
                                $applicant,
                                $resume
                            );

                    }

                }

                if (empty($resume)) {

                    Log::warning(
                        'Resume not found.',
                        [
                            'applicant_id'=>$applicant->sno
                        ]
                    );

                    continue;

                }

                /*
                |---------------------------------------------------------
                | Reduce Prompt Size
                |---------------------------------------------------------
                */

                $resume = mb_substr(
                    strip_tags($resume),
                    0,
                    config(
                        'ai.max_resume_length',
                        3000
                    )
                );

                $prepared[] = [

                    'applicant'=>$applicant,
                    'sno'=>$applicant->sno,
                    'applicant_id'=>$applicant->sno,
                    'resume'=>$resume

                ];

            }

            catch(\Throwable $e){

                Log::error(

                    'Resume Prepare Error',

                    [

                        'applicant'=>$applicant->sno,

                        'error'=>$e->getMessage()

                    ]

                );

            }

        }

        return $prepared;
    }

    /**
     * Match Applicants
     */
    private function matchApplicants(
        array $preparedApplicants
    ): array
    {

        /* Roles */

        $roles = DB::table('egc_recruitment_roles')
            ->where('status',0)
            ->orderBy('sno')
            ->get(['sno','jobrole_name'])
            ->map(function($role){
                return [
                    'role_id'=>$role->sno,
                    'role_name'=>$role->jobrole_name
                ];
            })
            ->values()
            ->toArray();

        /*Prompt */
        $prompt = $this->promptBuilder->batchRoleMatching( $preparedApplicants, $roles );
        /* AI */

        $response = $this->hfClient->askJson($prompt);
        if(!$response['status']){
            return $response;
        }

        /* Validate */

        return $this->validator->validateBatchRoleMatching( $response['data'] );

    }

    /**
     * Save Results
     */
    private function saveResults(
        array $preparedApplicants,
        array $results
    ): array
    {

        $success = 0;
        $failed = 0;

        /*
        |---------------------------------------------------------
        | Applicant Map
        |---------------------------------------------------------
        */

        $map = [];

        foreach($preparedApplicants as $row){
            $map[$row['sno']] = $row['applicant'];

        }

        foreach($results as $result){
            try{
                if(
                    !isset(
                        $map[
                            $result['applicant_id']
                        ]
                    )
                ){

                    $failed++;
                    continue;

                }

                $save = $this->updater
                    ->saveRoleMatching(
                        $map[$result['applicant_id']],
                        $result
                    );

                if(
                    $save['status']
                ){

                    $success++;

                }else{

                    $failed++;

                }

            }

            catch(\Throwable $e){

                $failed++;

                Log::error(

                    'Save Result Error',

                    [

                        'applicant'=>$result['sno'] ?? null,

                        'message'=>$e->getMessage()

                    ]

                );

            }

        }

        return [

            'success'=>$success,

            'failed'=>$failed

        ];

    }

 
}