<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

class AuthJwtMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $bearerToken = $request->bearerToken();

        if (!$bearerToken) {
            return response()->json(['status' => 401, 'message' => 'Token missing']);
        }

        $hashedToken = hash('sha256', $bearerToken);

        $token = PersonalAccessToken::where('token', $hashedToken)
            ->where('expires_at', '>', now())
            ->first();

        if (!$token) {
            return response()->json(['status' => 401, 'message' => 'Token invalid or expired']);
        }

        $request->setUserResolver(function () use ($token) {
            return $token->tokenable; // Set authenticated user
        });

        return $next($request);
    }
}