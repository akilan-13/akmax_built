<?php

namespace App\Http\Controllers\business_strategy;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\StaffModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Cache;


class StaffTenX extends Controller
{

    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search = $request->search_filter ?? '';
        $company_fill  = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        $month_filter_mode = $request->input('month_filter_mode', 'all');
        $single_month = $request->input('single_month', '');
        $custom_months = $request->input('custom_months', []);
        if (!is_array($custom_months)) {
            $custom_months = [];
        }
        $dashboard_filter = $request->input('dashboard_filter', '');

        $allowedMonthFormats = [];
        foreach ($custom_months as $month) {
            try {
                $parsed = Carbon::createFromFormat('Y-m', $month);
                if ($parsed && $parsed->format('Y-m') === $month) {
                    $allowedMonthFormats[] = $month;
                }
            } catch (\Throwable $e) {
              
            }
        }

        $custom_months = array_values(array_unique($allowedMonthFormats));
        $singleMonthCarbon = null;

        if ($single_month !== '') {
            try {
                $singleMonthCarbon = Carbon::createFromFormat('Y-m', $single_month);
                if ($singleMonthCarbon->format('Y-m') !== $single_month) {
                    $singleMonthCarbon = null;
                }
            } catch (\Throwable $e) {
                $singleMonthCarbon = null;
            }
        }
       
         $staffs = StaffModel::query()
        ->join('egc_staff_tenx_log as tenx', 'tenx.staff_id', '=', 'egc_staff.sno')
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('tenx.status', 0)
        ->where('egc_staff.status', 0)
        ->when($search, function ($q) use ($search) {
            $q->where(function ($sub) use ($search) {
                $sub->where('egc_staff.staff_name', 'like', "%{$search}%")
                    ->orWhere('egc_staff.staff_id', 'like', "%{$search}%");
            });
        })
        ->select(
            'egc_staff.sno',
            'egc_staff.staff_name',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.staff_id',
            'egc_staff.role_id',
            'egc_staff.staff_image',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
             'egc_entity.entity_name',
             'egc_entity.entity_base_color',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_company.company_logo',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
            DB::raw('MAX(tenx.updated_at) as last_updated'),
            DB::raw('COUNT(*) as total_tenx_months')
        )

        ->groupBy(
            'egc_staff.sno',
            'egc_staff.staff_name',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.staff_id',
            'egc_staff.role_id',
            'egc_staff.staff_image',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_entity.entity_name',
            'egc_entity.entity_base_color',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_company.company_logo',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name',
        );

            if ($company_fill != '') {
                if ($company_fill == 'egc') {
                    $staffs->where('egc_staff.company_type', 1);
                } else {
                    $staffs->where('egc_staff.company_id', 'LIKE', $company_fill);
                }
            }

            if ($entity_fill) {
                $staffs->where('egc_staff.entity_id', $entity_fill);
            }


            if ($department_fill) {
                $staffs->where('egc_staff.department_id', $department_fill);
            }

            if ($division_fill) {
                $staffs->where('egc_staff.division_id', $division_fill);
            }

            if ($job_role_fill) {
                $staffs->where('egc_staff.job_role_id', $job_role_fill);
            }

            if ($month_filter_mode === 'single' && $singleMonthCarbon) {

                $staffs->where('tenx.year', $singleMonthCarbon->year)
                    ->where('tenx.month', $singleMonthCarbon->month);

            } elseif ($month_filter_mode === 'custom' && !empty($custom_months)) {

                $staffs->where(function ($query) use ($custom_months) {

                    foreach ($custom_months as $index => $monthValue) {

                        [$year, $month] = explode('-', $monthValue);

                        if ($index === 0) {
                            $query->where(function ($sub) use ($year, $month) {
                                $sub->where('tenx.year', (int) $year)
                                    ->where('tenx.month', (int) $month);
                            });
                        } else {
                            $query->orWhere(function ($sub) use ($year, $month) {
                                $sub->where('tenx.year', (int) $year)
                                    ->where('tenx.month', (int) $month);
                            });
                        }
                    }

                });
            }

            $dashboardBaseStaffQuery = clone $staffs;

            $dashboardStaffIds = $dashboardBaseStaffQuery
                ->pluck('egc_staff.sno')
                ->unique()
                ->values();

            $now = now();
            $thisMonthKey = $now->format('Y-m');
            $lastMonthDate = $now->copy()->subMonth();
            $lastMonthKey = $lastMonthDate->format('Y-m');

            $thisMonthYear  = (int) $now->year;
            $thisMonth      = (int) $now->month;

            $lastMonthYear  = (int) $lastMonthDate->year;
            $lastMonth      = (int) $lastMonthDate->month;

            $dashboardLogs = DB::table('egc_staff_tenx_log')
                ->whereIn('staff_id', $dashboardStaffIds)
                ->where('tenx_achieved', 1)
                ->where('status', 0)
                ->orderBy('year')
                ->orderBy('month')
                ->get()
                ->groupBy('staff_id');

            $thisMonth10x = 0;
            $lastMonth10x = 0;
            $thisMonthWarrior = 0;
            $lastMonthWarrior = 0;

            foreach ($dashboardLogs as $staffId => $logs) {

                $achievedMonths = [];
                foreach ($logs as $log) {
                    $key = sprintf('%04d-%02d', $log->year, $log->month );
                    $achievedMonths[$key] = true;
                }

                if (isset($achievedMonths[$thisMonthKey])) {
                    $thisMonth10x++;
                }

                if (isset($achievedMonths[$lastMonthKey])) {
                    $lastMonth10x++;
                }

                $runningStreak = 0;
                $previousValue = null;

                foreach ($logs as $log) {

                    $currentValue =  ((int) $log->year * 12) + (int) $log->month;

                    if ( $previousValue !== null && ($currentValue - $previousValue) === 1 ) {
                        $runningStreak++;
                    } else {
                        $runningStreak = 1;
                    }

                    if ($log->year == $thisMonthYear &&  $log->month == $thisMonth &&  $runningStreak === 4 ) {
                        $thisMonthWarrior++;
                    }

                    if (
                        $log->year == $lastMonthYear &&
                        $log->month == $lastMonth &&
                        $runningStreak === 4
                    ) {
                        $lastMonthWarrior++;
                    }

                    $previousValue = $currentValue;
                }
            }

            if ($dashboard_filter === 'this_month_10x') {

                $staffs->where('tenx.year', $thisMonthYear)
                    ->where('tenx.month', $thisMonth);


            } elseif ($dashboard_filter === 'last_month_10x') {

                $staffs->where('tenx.year', $lastMonthYear)
                    ->where('tenx.month', $lastMonth);


            } elseif ($dashboard_filter === 'this_month_warrior') {

                /*
                |--------------------------------------------------------------------------
                | Get staff IDs who achieved Warrior this month
                |--------------------------------------------------------------------------
                */

                $warriorStaffIds = [];

                foreach ($dashboardLogs as $staffId => $logs) {

                    $runningStreak = 0;
                    $previousValue = null;

                    foreach ($logs as $log) {

                        $currentValue =
                            ((int) $log->year * 12) +
                            (int) $log->month;

                        if (
                            $previousValue !== null &&
                            ($currentValue - $previousValue) === 1
                        ) {
                            $runningStreak++;
                        } else {
                            $runningStreak = 1;
                        }

                        if (
                            $log->year == $thisMonthYear &&
                            $log->month == $thisMonth &&
                            $runningStreak === 4
                        ) {
                            $warriorStaffIds[] = $staffId;
                        }

                        $previousValue = $currentValue;
                    }
                }

                $staffs->whereIn(
                    'egc_staff.sno',
                    array_unique($warriorStaffIds)
                );


            } elseif ($dashboard_filter === 'last_month_warrior') {



                $warriorStaffIds = [];

                foreach ($dashboardLogs as $staffId => $logs) {

                    $runningStreak = 0;
                    $previousValue = null;

                    foreach ($logs as $log) {

                        $currentValue =
                            ((int) $log->year * 12) +
                            (int) $log->month;

                        if (
                            $previousValue !== null &&
                            ($currentValue - $previousValue) === 1
                        ) {
                            $runningStreak++;
                        } else {
                            $runningStreak = 1;
                        }

                        if (
                            $log->year == $lastMonthYear &&
                            $log->month == $lastMonth &&
                            $runningStreak === 4
                        ) {
                            $warriorStaffIds[] = $staffId;
                        }

                        $previousValue = $currentValue;
                    }
                }

                $staffs->whereIn(
                    'egc_staff.sno',
                    array_unique($warriorStaffIds)
                );
            }


        $staffs =$staffs->orderByDesc('last_updated')
        ->paginate($perpage);

        if ($request->ajax()) {

            $staffIds = $staffs->pluck('sno');
            $allLogs = DB::table('egc_staff_tenx_log')
                ->whereIn('staff_id', $staffIds)
                ->where('tenx_achieved', 1)
                ->where('status', 0)
                ->orderBy('year')
                ->orderBy('month')
                ->get()
                ->groupBy('staff_id');

            $now = now();
            $currentMonthKey = $now->format('Y-m');
            $currentYear = (int)$now->year;
            $currentMonth = (int)$now->month;

            $response = $staffs->getCollection()->map(function ($staff) use (
                $allLogs,
                $currentYear,
                $currentMonth,
                $currentMonthKey
            ) {

                $logs = $allLogs[$staff->sno] ?? collect();

                $timeline = [];

                $achievedMonths = [];
                $achievedLookup = [];

                $maxStreak = 0;
                $runningStreak = 0;
                $previousValue = null;

                $firstLog = null;
                $lastLog = null;

                /*
                |--------------------------------------------------------------------------
                | Single Loop
                |--------------------------------------------------------------------------
                */

                foreach ($logs as $log) {

                    if (!$firstLog) {
                        $firstLog = $log;
                    }

                    $lastLog = $log;

                    $monthKey = sprintf('%04d-%02d', $log->year, $log->month);

                    $achievedMonths[$monthKey] = true;
                    $achievedLookup[$monthKey] = true;

                    $currentValue = ($log->year * 12) + $log->month;

                    if ($previousValue !== null && ($currentValue - $previousValue) === 1) {
                        $runningStreak++;
                    } else {
                        $runningStreak = 1;
                    }

                    if ($runningStreak > $maxStreak) {
                        $maxStreak = $runningStreak;
                    }

                    $previousValue = $currentValue;
                }

                /*
                |--------------------------------------------------------------------------
                | Timeline
                |--------------------------------------------------------------------------
                */

                if ($firstLog) {

                    $year = (int)$firstLog->year;
                    $month = (int)$firstLog->month;

                    $runningStreak = 0;
                    $previousValue = null;

                    while (
                        ($year < $currentYear) ||
                        ($year == $currentYear && $month <= $currentMonth)
                    ) {

                        $key = sprintf('%04d-%02d', $year, $month);

                        $achieved = isset($achievedMonths[$key]);

                        $warrior = false;
                        $elite = false;
                        $legend = false;

                        if ($achieved) {

                            $currentValue = ($year * 12) + $month;

                            if ($previousValue !== null && ($currentValue - $previousValue) === 1) {
                                $runningStreak++;
                            } else {
                                $runningStreak = 1;
                            }

                            if ($runningStreak === 4) {
                                $warrior = true;
                            } elseif ($runningStreak === 8) {
                                $elite = true;
                            } elseif ($runningStreak === 12) {
                                $legend = true;
                            }

                            $previousValue = $currentValue;

                        } else {

                            $runningStreak = 0;
                            $previousValue = null;
                        }

                        $timeline[] = [

                            'month' => date('M', mktime(0, 0, 0, $month, 1)),
                            'month_no' => $month,
                            'year' => $year,

                            'achieved' => $achieved,
                            'current' => ($key === $currentMonthKey),
                            'future' => false,

                            'warrior_month' => $warrior,
                            'elite_month' => $elite,
                            'legend_month' => $legend,
                        ];

                        $month++;

                        if ($month > 12) {
                            $month = 1;
                            $year++;
                        }
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | Current Streak
                |--------------------------------------------------------------------------
                */

                $currentStreak = 0;

                $year = $currentYear;
                $month = $currentMonth - 1;

                if ($month == 0) {
                    $month = 12;
                    $year--;
                }

                while (true) {

                    $key = sprintf('%04d-%02d', $year, $month);

                    if (!isset($achievedLookup[$key])) {
                        break;
                    }

                    $currentStreak++;

                    $month--;

                    if ($month == 0) {
                        $month = 12;
                        $year--;
                    }
                }

                if ($currentStreak >= 12) {
                    $title = 'Legend Warrior';
                } elseif ($currentStreak >= 8) {
                    $title = 'Elite Warrior';
                } elseif ($currentStreak >= 4) {
                    $title = '10X Warrior';
                } else {
                    $title = 'Rising Star';
                }

                return [

                    'sno' => $staff->sno,
                    'staff_name' => $staff->staff_name,
                    'gender' => $staff->gender,
                    'company_name' => $staff->company_name,
                    'entity_name' => $staff->entity_name,
                    'company_base_color' => $staff->company_base_color,
                    'entity_base_color' => $staff->entity_base_color,
                    'department_name' => $staff->department_name,
                    'job_role_name' => $staff->job_role_name,
                    'nick_name' => $staff->nick_name,
                    'staff_code' => $staff->staff_id,
                    'staff_image' => $staff->profile_image_url,
                    'total_tenx_months' => $staff->total_tenx_months,
                    'max_streak' => $maxStreak,
                    'warrior_title' => $title,
                    'warrior_status' => $currentStreak >= 4,
                    'last_updated' => $staff->last_updated,
                    'timeline' => $timeline,
                    'current_streak' => $currentStreak,
                    'last_achievement' => $lastLog
                        ? date('M-Y', strtotime($lastLog->year . '-' . $lastLog->month . '-01'))
                        : null,
                    'first_achievement' => $firstLog
                        ? date('M-Y', strtotime($firstLog->year . '-' . $firstLog->month . '-01'))
                        : null,
                ];
            });

            

            return response()->json([
                'data' => $response,
                'current_page' => $staffs->currentPage(),
                'last_page' => $staffs->lastPage(),
                'total' => $staffs->total(),
                'dashboard' => [
                    'this_month_10x'     => $thisMonth10x,
                    'last_month_10x'     => $lastMonth10x,
                    'this_month_warrior' => $thisMonthWarrior,
                    'last_month_warrior' => $lastMonthWarrior,
                ],

                'active_dashboard_filter' => $dashboard_filter,
            ]);
        }
        $entity_list = ManageEntityModel::where('status', 0)->get();
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        return view( 'content.hr_management.hr_sib.manage_tenx.tenx_list',[
            'perpage' =>$perpage ,
            'entity_list' => $entity_list,
            'company_list' => $company_list,
        ]);
    }

    public function staffListByDepartment(Request $request)
    {
        $staffs = StaffModel::join('egc_job_role','egc_staff.job_role_id','=','egc_job_role.sno')
            ->where('egc_staff.department_id',$request->department_id)
            ->where('egc_staff.status',0)
            ->orderBy('egc_staff.staff_name')
            ->select(
                'egc_staff.sno',
                'egc_staff.staff_name',
                'egc_job_role.job_position_name'
            )
            ->get();

        return response()->json([
            'status' => 200,
            'data' => $staffs
        ]);
    }

    public function staffTenxProfile(Request $request)
    {
        $staff = StaffModel::query()
            ->leftJoin('egc_company','egc_staff.company_id','=','egc_company.sno')
            ->leftJoin('egc_entity','egc_staff.entity_id','=','egc_entity.sno')
            ->leftJoin('egc_branch','egc_staff.branch_id','=','egc_branch.sno')
            ->leftJoin('egc_job_role','egc_staff.job_role_id','=','egc_job_role.sno')
            ->where('egc_staff.sno',$request->staff_id)
            ->select(
                'egc_staff.*',
                'egc_company.company_name',
                'egc_entity.entity_name',
                'egc_entity.entity_base_color',
                'egc_branch.branch_name',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->first();

        if (!$staff) {
            return response()->json([
                'status'=>404
            ]);
        }

        $lastTenx = DB::table('egc_staff_tenx_log')
            ->where('staff_id',$staff->sno)
            ->where('tenx_achieved',1)
            ->where('status', 0)
            ->latest('updated_at')
            ->first();

        return response()->json([
            'status'=>200,
            'staff'=>[
                'sno'=>$staff->sno,
                'staff_name'=>$staff->staff_name,
                'nick_name'=>$staff->nick_name,
                'staff_code'=>$staff->staff_id,
                'date_of_joining'=>date('d-M-Y',strtotime($staff->date_of_joining)),
                'profile_image'=>$staff->profile_image_url,
                'company_name'=>$staff->company_name,
                'entity_name'=>$staff->entity_name,
                'entity_base_color'=>$staff->entity_base_color,
                'branch_name'=>$staff->branch_name,
                'job_role_name'=>$staff->job_role_name,
                'last_tenx'=>$lastTenx
                    ? date('M-Y',strtotime(
                        $lastTenx->year.'-'.$lastTenx->month.'-01'
                    ))
                    : 'No Achievement'
            ]
        ]);
    }


    public function updateTenxLog(Request $request)
    {
        $request->validate([
            'staff_id'   => 'required',
            'month_year' => 'required',
            'amount'     => 'required|numeric|min:1',
            'remarks'    => 'nullable'
        ]);

        DB::beginTransaction();
         $user_id = $request->user()->user_id ;

        try {

            [$monthName, $year] = explode('-', $request->month_year);

            $month =Carbon::parse(
                '01-'.$monthName.'-'.$year
            )->month;

            $staff =DB::table('egc_staff')->where('sno',$request->staff_id)->first();

            DB::table('egc_staff_tenx_log')
                ->updateOrInsert(

                    [
                        'staff_id' => $request->staff_id,
                        'month'    => $month,
                        'year'     => $year,
                        'status'     => 0,
                    ],

                    [
                        'entity_id'   => $staff->entity_id ?? 0,
                        'job_role_id'   => $staff->job_role_id ?? 0,
                        'role_id'      => $staff->role_id ?? NULL,
                        'tenx_achieved' => 1,
                        'total_amount'        => $request->amount,
                        'remarks'       => $request->remarks,
                        'status'        => 0,
                        'updated_at'    => now(),
                        'updated_by'    => $user_id,
                        'created_at'    => now(),
                        'created_by'    => $user_id,
                    ]
                );

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => '10X Award updated successfully'
            ]);

        } catch (\Exception $e) {

            DB::rollBack();

            return response()->json([
                'status' => 500,
                'message' => 'Unable to update 10X Award',
                'error' => config('app.debug')
                    ? $e->getMessage()
                    : null
            ], 500);
        }
    }

}
