<?php

namespace App\Http\Controllers\control_panel\communication_tool;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel;
use App\Models\ManageEntityModel;
use App\Models\BroadcastThemeModel;
use Illuminate\Support\Facades\Validator;
use App\Models\BranchModel;
use App\Models\UserRolePermissionModel;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\DB;
use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\CompanyModel;
use App\Jobs\SendWebhookJob;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class NewsBroadcast extends Controller
{
  protected static $branch_id = 1;

   public function index(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    date_default_timezone_set('Asia/Kolkata');
    // Now, run your query to check the current time in the set timezone
   $now = Carbon::now()->format('Y-m-d H:i:s');
    

    $country = NewsBroadcastModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $country->where(function ($subquery) use ($search_filter) {
            $subquery->where('template_name', 'LIKE', "%{$search_filter}%");
        });
    }
           $country = $country->select('*', \DB::raw('
            CASE
                WHEN start_date <= "' . $now . '" AND end_date >= "' . $now . '" THEN 1
                WHEN start_date > "' . $now . '" THEN 2
                ELSE 3
            END AS phase_order
        '))
        ->orderByRaw('phase_order ASC') // Order by phase_order first
        ->orderBy('start_date', 'asc')
    ->paginate($perpage);



    $helper = new \App\Helpers\Helpers();
    // If AJAX request → return JSON only
    if ($request->ajax()) {
        $data = $country->map(function ($item) use ($helper) {
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'branch_ids' => json_decode($item->branch_id,true),
                'role_ids' => json_decode($item->role_ids,true),
                'template_name' => $item->template_name,
                'broadcast_message' => $item->broadcast_message,
                'start_date' => \Carbon\Carbon::parse($item->start_date)->format('d-M-Y h:i A'),
                'end_date' => \Carbon\Carbon::parse($item->end_date)->format('d-M-Y h:i A'),
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $country->currentPage(),
            'last_page' => $country->lastPage(),
            'total' => $country->total(),
        ]);
    }
    $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.control_panel.communication_tool.news_broadcast.news_broadcast_list', [
        'country' => $country,
        'perpage' => $perpage,
        'company_list' => $company_list,
        'search_filter' => $search_filter
    ]);
}

  public function List()
  {
      $city = NewsBroadcastModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    
    public function List_for_edit()
  {
    $sms_template = NewsBroadcastModel::orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  
 public function Add(Request $request)
  {
      
      $branch_list = BranchModel::where('status', 0)->get();
      $entity_list = ManageEntityModel::where('status', 0)->get();
      $theme_list = BroadcastThemeModel::where('status', 0)->get();

        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            // ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();

        $default_theme = BroadcastThemeModel::where('status',0)->first();
        $theme_id =$default_theme ? $default_theme->sno : 0 ;
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.control_panel.communication_tool.news_broadcast.add_news_broadcast',[
        'branch_list'=>$branch_list,
        'roleList'=>$roleList,
        'company_list'=>$company_list,
        'theme_list'=>$theme_list,
        'theme_id'=>$theme_id,
        'entity_list'=>$entity_list,
        ]);
  }
  
      public function Edit($id, Request $request)
{
    $branch_list = BranchModel::where('status', 0)->get();
    $theme_list  = BroadcastThemeModel::where('status', 0)->get();

    $helper = new \App\Helpers\Helpers();

    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

    $roleList = UserRoleModel::where('status', 0)
        ->whereIn('sno', $userRolePermissions)
        ->get();

    $editData = NewsBroadcastModel::where('status', '!=', 2)
        ->where('sno', $decryptedValue)
        ->first();

    if (!$editData) {
        return redirect()->back()->with('error', 'Broadcast not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | Decode saved hierarchy safely
    |--------------------------------------------------------------------------
    */

    $company_ids = json_decode($editData->company_ids ?? '[]', true);
    $entity_ids  = json_decode($editData->entity_ids ?? '[]', true);

    /*
    | New records use branch_ids.
    | Old records may have branch_id.
    */
    $branch_ids = json_decode(
        $editData->branch_ids ?? $editData->branch_id ?? '[]',
        true
    );

    $role_ids = json_decode($editData->role_ids ?? '[]', true);

    /*
    |--------------------------------------------------------------------------
    | Always make them arrays
    |--------------------------------------------------------------------------
    */

    $company_ids = is_array($company_ids) ? $company_ids : [];
    $entity_ids  = is_array($entity_ids) ? $entity_ids : [];
    $branch_ids  = is_array($branch_ids) ? $branch_ids : [];
    $role_ids    = is_array($role_ids) ? $role_ids : [];

    /*
    |--------------------------------------------------------------------------
    | Convert IDs to string
    | Add page uses string values from Select2
    |--------------------------------------------------------------------------
    */

    $company_ids = array_map('strval', $company_ids);
    $entity_ids  = array_map('strval', $entity_ids);
    $branch_ids  = array_map('strval', $branch_ids);
    $role_ids    = array_map('strval', $role_ids);

    /*
    |--------------------------------------------------------------------------
    | Company 0 = Elysium Groups / Global
    |
    | Make sure edit page has the same hierarchy as Add page
    |--------------------------------------------------------------------------
    */

    if (
        count($company_ids) === 1 &&
        $company_ids[0] === '0'
    ) {
        $entity_ids = ['0'];
        $branch_ids = ['0'];
    }

    /*
    |--------------------------------------------------------------------------
    | Assign arrays back to editData
    |--------------------------------------------------------------------------
    */

    $editData->company_ids = $company_ids;
    $editData->entity_ids  = $entity_ids;

    // Keep branch_id also for old Blade compatibility
    $editData->branch_ids = $branch_ids;
    $editData->branch_id  = $branch_ids;

    $editData->role_ids = $role_ids;

    /*
    |--------------------------------------------------------------------------
    | Information
    |--------------------------------------------------------------------------
    */

    $information = json_decode($editData->information ?? '[]', true);

    $editData->information = is_array($information)
        ? $information
        : [];

    $editData->firstData = $editData->information[0] ?? [
        'date'    => '',
        'prefix'  => '',
        'heading' => '',
        'url'     => '#',
    ];

    /*
    |--------------------------------------------------------------------------
    | Theme
    |--------------------------------------------------------------------------
    */

    $default_theme = BroadcastThemeModel::where('status', 0)->first();

    $theme_id = $default_theme
        ? $default_theme->sno
        : 0;

    /*
    |--------------------------------------------------------------------------
    | Company list
    |--------------------------------------------------------------------------
    */

    $company_list = CompanyModel::where('status', 0)
        ->orderBy('sno', 'ASC')
        ->get();

    return view(
        'content.control_panel.communication_tool.news_broadcast.edit_news_broadcast',
        [
            'branch_list'  => $branch_list,
            'roleList'     => $roleList,
            'company_list' => $company_list,
            'theme_list'   => $theme_list,
            'editData'     => $editData,
            'theme_id'     => $theme_id,
        ]
    );
}
  
   public function saveTemplate(Request $request)
{

    $helper = new \App\Helpers\Helpers();
    $company_ids = $request->company_ids;
    $entity_ids  = $request->entity_ids;
    $branch_ids  = $request->branch_ids;
    $role_ids    = $request->role_ids;
    $user_id = $request->user()->user_id ?? 1;

    $uuid = (string) \Illuminate\Support\Str::uuid();

    if ($company_ids === "all") {
        $company_ids = DB::table("egc_company")
            ->where("status", 0)
            ->pluck("sno")
            ->toArray();

        $company_ids[] = 0;
        $company_ids = array_map('strval', $company_ids);
    }

    if ($entity_ids === "all") {
        $entityQuery = DB::table("egc_entity")
            ->where("status", 0);

        if (!empty($company_ids)) {
            $entityQuery->whereIn("company_id", $company_ids);
        }

        $entity_ids = $entityQuery->pluck("sno")->toArray();
        $entity_ids = array_map('strval', $entity_ids);
    }

    if ($branch_ids === "all") {
        $branchQuery = DB::table("egc_branch")
            ->where("status", 0);

        if (!empty($entity_ids)) {
            $branchQuery->whereIn("entity_id", $entity_ids);
        }

        $branch_ids = $branchQuery->pluck("sno")->toArray();
        $branch_ids = array_map('strval', $branch_ids);
    }

    if ($role_ids === "all") {
        $roleQuery = DB::table("egc_user_role")
            ->where("status", 0);

        $roleQuery->where(function ($q) use ($entity_ids, $company_ids) {

            if (!empty($entity_ids)) {
                $q->whereIn("entity_id", $entity_ids);
            }

            if (in_array(0, $company_ids)) {
                $q->orWhere("company_id", 0);
            }
        });

        $role_ids = $roleQuery->pluck("sno")->toArray();
        $role_ids = array_map('strval', $role_ids);
    }


    // IMPORTANT:
    // When company_ids is [0], entity_ids and branch_ids should also be [0]
    if (
        is_array($company_ids) &&
        count($company_ids) === 1 &&
        (string) $company_ids[0] === '0'
    ) {
        $entity_ids = ['0'];
        $branch_ids = ['0'];
    }


    // Prevent null values
    $entity_ids = is_array($entity_ids) ? $entity_ids : [];
    $branch_ids = is_array($branch_ids) ? $branch_ids : [];
    $role_ids   = is_array($role_ids) ? $role_ids : [];
    // return response()->json([
    //   "status" => "failed",
    //   "data" => $role_ids,
    //   ]);


    
    $themeData = DB::table('egc_broadcast_theme')
        ->where('egc_broadcast_theme.status', 0)
        ->where('egc_broadcast_theme.sno',$request->theme_id)
        ->first();
        
       
    $theme = $themeData ? json_decode($themeData->theme_style, true) : null;

    if ($theme) {
        $theme['position'] = 'sticky';
    }
    

  
       
   $broadcast=NewsBroadcastModel::create([
        "uuid"          => $uuid,
        "company_ids"    => json_encode($company_ids),
        "entity_ids"    => json_encode($entity_ids),
        "branch_ids"    => json_encode($branch_ids),
        "role_ids"     => json_encode($role_ids),
        "start_date"   => date('Y-m-d H:i:s', strtotime($request->start_date)),
        "end_date"     => date('Y-m-d H:i:s', strtotime($request->end_date)),
        "information"  => $request->information, // already json
        "theme_id"     => $request->theme_id,
        "broadcast_message"     => $request->broadcast_message,
        "theme_style"  => json_encode($theme), // Save the updated theme here
        "created_by"   => $user_id,
        "template_name"=> $request->template_name,
        "updated_by"   => $user_id,
    ]);
        if ($broadcast) {

            $entity_ids = json_decode($broadcast->entity_ids, true) ?: [];
            $branch_ids = json_decode($broadcast->branch_ids, true) ?: [];
            $role_ids   = json_decode($broadcast->role_ids, true) ?: [];

            foreach ($entity_ids as $entity) {

                if ($entity != 0) {

                    // Existing production logic remains unchanged

                    $enity_branch_ids = DB::table("egc_branch")
                        ->where("status", 0)
                        ->where("entity_id", $entity)
                        ->whereIn("sno", $branch_ids)
                        ->pluck("sno")
                        ->toArray();

                    $erp_branch_ids = DB::table("egc_branch")
                        ->where("status", 0)
                        ->where("entity_id", $entity)
                        ->whereIn("sno", $enity_branch_ids)
                        ->pluck("erp_branch_id")
                        ->toArray();

                    $enity_role_ids = DB::table("egc_user_role")
                        ->where("status", 0)
                        ->where("entity_id", $entity)
                        ->whereIn("sno", $role_ids)
                        ->pluck("sno")
                        ->toArray();

                    $erp_role_ids = DB::table("egc_user_role")
                        ->where("status", 0)
                        ->where("entity_id", $entity)
                        ->whereIn("sno", $enity_role_ids)
                        ->pluck("erp_role_id")
                        ->toArray();

                    $erp_role_ids = array_map('strval', $erp_role_ids);
                    $erp_branch_ids = array_map('strval', $erp_branch_ids);

                    $payload = [
                        'sno' => $broadcast->sno,
                        'entity_id' => $entity,
                        'branch_id' => json_encode($erp_branch_ids),
                        'role_ids' => json_encode($erp_role_ids),
                        'start_date' => $broadcast->start_date,
                        'end_date' => $broadcast->end_date,
                        'information' => $broadcast->information,
                        'theme_id' => $broadcast->theme_id,
                        'broadcast_message' => $broadcast->broadcast_message,
                        'theme_style' => $broadcast->theme_style,
                        'template_name' => $broadcast->template_name,
                        'created_by' => 1,
                        'updated_by' => 1,
                    ];

                    $this->dispatchWebhooks($payload, 1);
                }
            }
        }
      
      
      // $this->dispatchWebhooks($broadcast, $user_id);

    return response()->json(["status" => "success"]);
}

  public function Update(Request $request)
    {
        $broadcast_id = $request->broadcast_id;
        $user_id = $request->user()->user_id ?? 1;

        /*
        |--------------------------------------------------------------------------
        | Company IDs
        |--------------------------------------------------------------------------
        */
        $company_ids = $request->company_ids;

        if ($company_ids === "all") {

            $company_ids = DB::table("egc_company")
                ->where("status", 0)
                ->pluck("sno")
                ->toArray();

            $company_ids[] = 0;

            $company_ids = array_map('strval', $company_ids);
        } else {
            $company_ids = is_array($company_ids)
                ? array_map('strval', $company_ids)
                : [];
        }


        /*
        |--------------------------------------------------------------------------
        | Entity IDs
        |--------------------------------------------------------------------------
        */
        $entity_ids = $request->entity_ids;

        // Special production/global company case
        if (
            count($company_ids) === 1 &&
            (string) $company_ids[0] === '0'
        ) {
            $entity_ids = ['0'];
        }

        elseif ($entity_ids === "all") {

            $entityQuery = DB::table("egc_entity")
                ->where("status", 0);

            if (!empty($company_ids)) {
                $entityQuery->whereIn("company_id", $company_ids);
            }

            $entity_ids = $entityQuery
                ->pluck("sno")
                ->toArray();

            $entity_ids = array_map('strval', $entity_ids);
        }

        else {
            $entity_ids = is_array($entity_ids)
                ? array_map('strval', $entity_ids)
                : [];
        }


        /*
        |--------------------------------------------------------------------------
        | Branch IDs
        |--------------------------------------------------------------------------
        */
        $branch_ids = $request->branch_id;

        // Special production/global company case
        if (
            count($company_ids) === 1 &&
            (string) $company_ids[0] === '0'
        ) {
            $branch_ids = ['0'];
        }

        elseif ($branch_ids === "all") {

            $branchQuery = DB::table("egc_branch")
                ->where("status", 0);

            if (!empty($entity_ids)) {
                $branchQuery->whereIn("entity_id", $entity_ids);
            }

            $branch_ids = $branchQuery
                ->pluck("sno")
                ->toArray();

            $branch_ids = array_map('strval', $branch_ids);
        }

        else {
            $branch_ids = is_array($branch_ids)
                ? array_map('strval', $branch_ids)
                : [];
        }


        /*
        |--------------------------------------------------------------------------
        | Role IDs
        |--------------------------------------------------------------------------
        */
        $role_ids = $request->role_ids;

        if ($role_ids === "all") {

            $roleQuery = DB::table("egc_user_role")
                ->where("status", 0);

            $roleQuery->where(function ($q) use ($entity_ids, $company_ids) {

                if (!empty($entity_ids)) {
                    $q->whereIn("entity_id", $entity_ids);
                }

                if (in_array(0, $company_ids)) {
                    $q->orWhere("company_id", 0);
                }
            });

            $role_ids = $roleQuery
                ->pluck("sno")
                ->toArray();

            $role_ids = array_map('strval', $role_ids);
        }

        else {
            $role_ids = is_array($role_ids)
                ? array_map('strval', $role_ids)
                : [];
        }


        /*
        |--------------------------------------------------------------------------
        | Theme
        |--------------------------------------------------------------------------
        */
        $themeData = DB::table('egc_broadcast_theme')
            ->where('egc_broadcast_theme.status', 0)
            ->where('egc_broadcast_theme.sno', $request->theme_id)
            ->first();

        $theme = $themeData
            ? json_decode($themeData->theme_style, true)
            : null;

        if ($theme) {
            $theme['position'] = 'sticky';
        }


        /*
        |--------------------------------------------------------------------------
        | Update Broadcast
        |--------------------------------------------------------------------------
        */
        $UpdateBroadcast = NewsBroadcastModel::where(
            'sno',
            $broadcast_id
        )->first();

        if (!$UpdateBroadcast) {
            return response()->json([
                "status" => "failed"
            ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Save
        |--------------------------------------------------------------------------
        */
        $UpdateBroadcast->company_ids = json_encode($company_ids);
        $UpdateBroadcast->entity_ids = json_encode($entity_ids);
        $UpdateBroadcast->branch_ids = json_encode($branch_ids);
        $UpdateBroadcast->role_ids = json_encode($role_ids);

        $UpdateBroadcast->start_date = date(
            'Y-m-d H:i:s',
            strtotime($request->start_date)
        );

        $UpdateBroadcast->end_date = date(
            'Y-m-d H:i:s',
            strtotime($request->end_date)
        );

        $UpdateBroadcast->information = $request->information;
        $UpdateBroadcast->theme_id = $request->theme_id;
        $UpdateBroadcast->broadcast_message = $request->broadcast_message;
        $UpdateBroadcast->theme_style = json_encode($theme);
        $UpdateBroadcast->template_name = $request->template_name;
        $UpdateBroadcast->updated_by = $user_id;

        $UpdateBroadcast->update();


        /*
        |--------------------------------------------------------------------------
        | Success
        |--------------------------------------------------------------------------
        */
        return response()->json([
            "status" => "success"
        ]);
    }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  
  public function checkDates(Request $request) {
      
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('egc_news_broadcast')
        ->where('status', '!=',2)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}

public function checkDatesEdit(Request $request) {
      
      $broadcast_id=$request->broadcast_id;
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('egc_news_broadcast')
        ->where('status', '!=',2)
        ->where('sno', '!=',$broadcast_id)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}
  public function broadcastThemeById(Request $request) {
      
    $theme_id=$request->theme_id;

    $theme = DB::table('egc_broadcast_theme')
        ->where('egc_broadcast_theme.status','!=',2)
        ->where('egc_broadcast_theme.sno',$theme_id)
        ->first();

    if ($theme) {
        return response()->json([
            'status' => '200',
            'data' => json_decode($theme->theme_style)
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}


public function newsBroadcastById(Request $request) {
      
    $template_id=$request->theme_id;

    $theme = DB::table('egc_news_broadcast')
        ->where('egc_news_broadcast.status', '!=',2)
        ->where('egc_news_broadcast.sno',$template_id)
        ->first();
        $data = json_decode($theme->theme_style, true); // decode as array
        $data['position'] = 'fixed'; 
    if ($theme) {
        return response()->json([
            'status' => '200',
            'allData' => $theme,
            'data' => $data,
            'content' => json_decode($theme->information),
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}

   public function role_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('role_ids')
      ->first();

    $roleIds = json_decode($data->role_ids, true);
    $roles = [];
    foreach ($roleIds as $roleId) {
      $role = UserRoleModel::where('status', 0)->where('sno', $roleId)->first(); 
      $roles[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['roles' => $roles]
    ], 200);
  }


  public function Update_role(Request $request)
  {
    // return $request;
    $request->validate([
      'edit_role_sno' => 'required|integer',
      'Add_role_table' => 'required|array',
    ]);

   $user_id = $request->user()->user_id ?? 1;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_role_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Training document not found.',
      ], 404);
    }

    $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
    $roleIds = is_array($roleIds) ? $roleIds : [];

    $newRoles = [];
    foreach ($request->Add_role_table as $roles) {
      if (is_array($roles)) {
        $newRoles = array_merge($newRoles, $roles);
      } else {
        $newRoles[] = $roles;
      }
    }

    $mergedRoles = array_unique(array_merge($roleIds, $newRoles));
    
    if($broadcast){
        $broadcast->role_ids=json_encode(array_values($mergedRoles));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $roles = UserRoleModel::where('status', 0)
      ->whereIn('sno', $mergedRoles)
      ->get()
      ->keyBy('sno');

    $rolesData = [];
    foreach ($mergedRoles as $roleId) {
      $role = $roles->get($roleId);
      $rolesData[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Roles updated successfully!',
      'roles'   => $rolesData,
    ]);
  }
  
  
  public function removeRole(Request $request)
  {
      $request->validate([
          'sno' => 'required|integer',
          'role_id' => 'required'
      ]);
    $user_id = $request->user()->user_id ?? 1;
      $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
  
      if(!$broadcast){
          return response()->json(['success' => false, 'message' => 'Record not found']);
      }
  
      // Decode role_ids
      $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
  
      // Remove the role_id
      $roleIds = array_filter($roleIds, function($id) use ($request){
          return $id != $request->role_id;
      });
  
      if($broadcast){
          $broadcast->role_ids = json_encode(array_values($roleIds));
          $broadcast->updated_by=$user_id;
          $broadcast->update();
      }
    
  
      return response()->json(['success' => true]);
  }
    
  public function branch_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('branch_ids')
      ->first();

    $branchIds = json_decode($data->branch_ids, true);
    $branches = [];
    foreach ($branchIds as $branchId) {
      $branch = BranchModel::where('status', 0)->where('sno', $branchId)->first(); 
      $branches[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['branches' => $branches]
    ], 200);
  }
  
   public function branch_list(Request $request)
  {
     $user_id = $request->user()->user_id ?? 1;
     $entity_id = $request->user()->entity_id;
    $data = BranchModel::where('status', '!=', 2)
      ->where('entity_id', $entity_id)
      ->get();
      
    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' =>  $data
    ], 200);
  }


public function Update_branch(Request $request)
  {
   
    $request->validate([
      'edit_branch_sno' => 'required|integer',
      'Add_branch_table' => 'required|array',
    ]);

    $user_id = $request->user()->user_id ?? 1;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_branch_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Broadcast not found.',
      ], 404);
    }

    $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
    $branchIds = is_array($branchIds) ? $branchIds : [];

    $newBranches = [];
    foreach ($request->Add_branch_table as $branches) {
      if (is_array($branches)) {
        $newBranches = array_merge($newBranches, $branches);
      } else {
        $newBranches[] = $branches;
      }
    }

    $mergedBranches= array_unique(array_merge($branchIds, $newBranches));

    if($broadcast){
        $broadcast->branch_id=json_encode(array_values($mergedBranches));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $branches = BranchModel::where('status', 0)
      ->whereIn('sno', $mergedBranches)
      ->get()
      ->keyBy('sno');

    $branchesData = [];
    foreach ($mergedBranches as $branchId) {
      $branch = $branches->get($branchId);
      $branchesData[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Branch updated successfully!',
      'branches'   => $branchesData,
    ]);
  }
  
  
  public function removeBranch(Request $request)
  {
      $request->validate([
          'sno' => 'required|integer',
          'branch_id' => 'required'
      ]);
     $user_id = $request->user()->user_id ?? 1;
      $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
  
      if(!$broadcast){
          return response()->json(['success' => false, 'message' => 'Record not found']);
      }
  
      // Decode role_ids
      $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
  
      // Remove the role_id
      $branchIds = array_filter($branchIds, function($id) use ($request){
          return $id != $request->branch_id;
      });
  
      if($broadcast){
          $broadcast->branch_id = json_encode(array_values($branchIds));
          $broadcast->updated_by=$user_id;
          $broadcast->update();
      }
    
  
      return response()->json(['success' => true]);
  }

   protected function dispatchWebhooks($broadcast, $userId = 1)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module','Broadcast_Hook')->where('entity_id',$broadcast['entity_id'])->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\NewsBroadcastModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

          // broadcast creation once
          broadcast(new WebhookDispatchedEvent($dispatch));

          // enqueue the job
            try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                // if (!$result['success']) {
                //     // If fails, dispatch to queue
                //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                // }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
          
  }


  // public function BranchListMultiple(Request $request)
  // {
  //     $entity_ids = $request->entity_id;

  //     $branch = BranchModel::where('status',0)
  //                 ->whereIn('entity_id',$entity_ids)
  //                 ->get();

  //     return response()->json([
  //         'status'=>200,
  //         'data'=>$branch
  //     ]);
  // }

  // public function EntityListMultiple(Request $request)
  // {

  //     $company_ids = $request->company_id;

  //     $entity = ManageEntityModel::where('status',0)
  //                 ->whereIn('company_id',$company_ids)
  //                 ->get();

  //     return response()->json([
  //         'status'=>200,
  //         'data'=>$entity
  //     ]);

  // }

public function BranchListMultiple(Request $request)
{

    $entity_ids = $request->entity_id;

    $query = BranchModel::select(
                'egc_branch.sno',
                'egc_branch.branch_name',
                'egc_branch.entity_id',
                'egc_entity.entity_name'
            )
            ->leftJoin('egc_entity','egc_entity.sno','=','egc_branch.entity_id')
            ->where('egc_branch.status',0);
            if(!$request->all && $request->entity_id){
                $query->whereIn('egc_branch.entity_id',$request->entity_id);
            }
          $branch = $query->get();

    return response()->json([
        'status'=>200,
        'data'=>$branch
    ]);
}
  public function EntityListMultiple(Request $request)
{

    $company_ids = $request->company_id;

    $query  = ManageEntityModel::select(
                'egc_entity.sno',
                'egc_entity.entity_name',
                'egc_entity.company_id',
                'egc_company.company_name'
            )
            ->leftJoin('egc_company','egc_company.sno','=','egc_entity.company_id')
            ->where('egc_entity.status',0);
            if(!$request->all && $request->company_id){
                $query->whereIn('egc_entity.company_id',$request->company_id);
            }

           $entity = $query->get();

    return response()->json([
        'status'=>200,
        'data'=>$entity
    ]);

}

  // public function UserRoleListMultiple(Request $request)
  // {

  //     $entity_ids = $request->entity_id;

  //     $entity = UserRoleModel::where('status',0)
  //                 ->whereIn('entity_id',$entity_ids)
  //                 ->get();

  //     return response()->json([
  //         'status'=>200,
  //         'data'=>$entity
  //     ]);

  // }


public function UserRoleListMultiple(Request $request)
{

    $entity_ids  = $request->entity_id ?? [];
    $company_ids = $request->company_id ?? [];

    $query = UserRoleModel::select(
                'egc_user_role.sno',
                'egc_user_role.role_name',
                'egc_user_role.entity_id',
                'egc_user_role.company_id',
                'egc_company.company_name'
            )
            ->leftJoin('egc_company','egc_company.sno','=','egc_user_role.company_id')
            ->where('egc_user_role.status',0);

    if(!$request->all){

        $query->where(function($q) use ($entity_ids,$company_ids){

            if(!empty($entity_ids)){
                $q->whereIn('egc_user_role.entity_id',$entity_ids);
            }

            if(in_array(0,$company_ids)){
                $q->orWhere('egc_user_role.company_id',0);
            }

        });

    }

    $roles = $query->get();

    return response()->json([
        'status'=>200,
        'data'=>$roles
    ]);

}


 protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }


    public function currentBroadcast(Request $request)
    {
        $now = \Carbon\Carbon::now();

        $branch_id = $request->user()->branch_id ?? 1;
        $role_id   = $request->user()->role_id ?? 1;

        $helper = new \App\Helpers\Helpers();

        $settings = $helper->showTicker(
            $branch_id,
            $role_id
        );

        return response()->json([
            'status' => 200,

            // Server current time
            'server_time' => $now->format('Y-m-d H:i:s'),
            'server_time_12h' => $now->format('d-M-Y h:i:s A'),

            // Laravel application timezone
            'timezone' => config('app.timezone'),

            // Helpful debugging values
            'branch_id' => (string) $branch_id,
            'role_id' => (string) $role_id,

            // Broadcast status
            'active' => !empty($settings),

            'data' => $settings,

            // Broadcast timing if active
            'broadcast_start' => $settings['_broadcast']['start_date'] ?? null,
            'broadcast_end' => $settings['_broadcast']['end_date'] ?? null,
            'expires_in' => $settings['_broadcast']['expires_in'] ?? null,
        ]);
    }
}
