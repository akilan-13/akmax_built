<?php

namespace App\Http\Controllers\control_panel\entity_hub;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\CountryModel;
use App\Models\CompanyBankModel;
use App\Models\ManageEntityModel;
use App\Models\SocialMediaModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class ManageCompany extends Controller
{
 public function index(Request $request) 
{
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $Company = CompanyModel::where('egc_company.status', '!=', 2)
        ->select('egc_company.*', 'egc_company_type.company_type_name', 'egc_company_type.slug_name', 'egc_countries.name as country_name', 'egc_states.name as statename', 'egc_cities.name as citiesname')
        ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno')
        ->leftJoin('egc_countries', 'egc_company.company_country', 'egc_countries.id')
        ->leftJoin('egc_states', 'egc_company.company_state', 'egc_states.id')
        ->leftJoin('egc_cities', 'egc_company.company_city', 'egc_cities.id');

    if($search_filter != '') {
        $Company->where(function ($subquery) use ($search_filter) {
            $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_company.company_mail', 'LIKE', "%{$search_filter}%");
        });
    }

    $Company = $Company->orderBy('egc_company.sno', 'asc')->paginate($perpage);

    $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Company->map(function ($item) use ($helper) {
            $company_address = $item->company_door_no . ' ' . $item->company_area . ', ' . $item->citiesname . ', ' . $item->statename . ' - ' . $item->pincode;
             $entity_count = DB::table('egc_entity')->where('company_id',$item->sno)->where('status','!=',2)->count();
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'company_name' => $item->company_name,
                'entity_count' => $entity_count,
                'company_type_name' => $item->company_type_name,
                'slug_name' => $item->slug_name,
                'company_mail' => $item->company_mail,
                'company_logo' => $item->company_logo,
                'company_favicon' => $item->company_favicon,
                'company_base_color' => $item->company_base_color,
                'company_address' => $company_address,
                'company_website' => $item->company_website,
                'company_ct_person' => $item->company_ct_person,
                'company_ct_number' => $item->company_ct_number,
                'data' => $item,
                'company_encode' => base64_encode($item->sno),
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $Company->currentPage(),
            'last_page' => $Company->lastPage(),
            'total' => $Company->total(),
        ]);
    }

    $Company_type_list = CompanyTypeModel::where('status', 0)->orderBy('company_type_name', 'ASC')->get();
    $country_list = CountryModel::where('status', 0)->orderBy('name', 'ASC')->get();
    $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

    return view('content.control_panel.entity_hub.manage_company.company_list', [
        'Company' => $Company,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'Company_type_list' => $Company_type_list,
        'country_list' => $country_list,
        'social_media_list' => $social_media_list,
    ]);
}


  public function EntityListByCompany($id,Request $request)
  {
      $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        
      $Entity = ManageEntityModel::where('egc_entity.status', '!=', 2)
      ->select('egc_entity.*', 'egc_countries.name', 'egc_states.name as statename', 'egc_cities.name as citiesname', 'egc_company.company_name','egc_company.company_base_color','egc_company_type.company_type_name', 'egc_company_type.slug_name')
      ->leftJoin('egc_countries', 'egc_entity.entity_country', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_entity.entity_state', 'egc_states.id')
      ->leftJoin('egc_cities', 'egc_entity.entity_city', 'egc_cities.id')
      ->leftJoin('egc_company', 'egc_company.sno', 'egc_entity.company_id')
      ->where('egc_company.sno',$id)
      ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno');
    
      
        if($search_filter != '') {
            $Entity->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_ct_person', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_ct_number', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_mail', 'LIKE', "%{$search_filter}%");
            });
        }
        
    $Entity = $Entity->orderBy('egc_entity.sno', 'asc')->get();
     $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Entity->map(function ($item) use ($helper) {
            $company_address = $item->entity_door_no . ' ' . $item->entity_area . ', ' . $item->citiesname . ', ' . $item->statename . ' - ' . $item->entity_pincode;
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'company_name' => $item->company_name,
                'entity_name' => $item->entity_name,
                'entity_mail' => $item->entity_mail,
                'company_type_name' => $item->company_type_name,
                 'slug_name' => $item->slug_name,
                'company_mail' => $item->company_mail,
                'company_address' => $company_address,
                'entity_website' => $item->entity_website,
                'entity_ct_person' => $item->entity_ct_person,
                'entity_ct_number' => $item->entity_ct_number,
                'data' => $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
        ]);
    }

    $Company = CompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    
    return view('content.control_panel.entity_hub.manage_entity.entity_list',[
        'ListTable' => $Entity,
          'Company' => $Company,
          'social_media_list' => $social_media_list,
          'perpage' => $perpage,
            'search_filter' => $search_filter,
      ]);
  }


  public function List()
  {
    $company = CompanyModel::where('status', 0)->orderBy('sno', 'asc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $company
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $staff =  CompanyModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Company  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Company  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $exit_entity  = DB::table('egc_entity')->where('company_id', $id)->first();
    if($exit_entity){
        return response([
        'status'    => 302,
        'message'   => 'Deletion not allowed: This company is linked to one or more entities',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
    $upd_StaffModel = CompanyModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Company Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Company ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function View($id)
  {
    $data =  CompanyModel::where('egc_company.status', '!=', 2)
      ->select('egc_company.*', 'egc_company_type.company_type_name', 'egc_company_type.slug_name', 'egc_countries.name', 'egc_states.name as statename', 'egc_cities.name as citiesname')
      ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno')
      ->leftJoin('egc_countries', 'egc_company.company_country', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_company.company_state', 'egc_states.id')
      ->leftJoin('egc_cities', 'egc_company.company_city', 'egc_cities.id')
      ->orderBy('egc_company.sno', 'desc')->where('egc_company.sno', $id)->first();

      $bankList = CompanyBankModel::where('status',0)->where('company_id',$id)->orderBy('sno','desc')->get();
      $data->company_bank_list = $bankList ?? [];

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Company not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Company fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Add(Request $request)
  {
    // return $request;
      $chk = CompanyModel::where('company_name', $request->company_name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Company Name already Exists!'
        ]);
        return redirect()->back();
      }
    $category_check = CompanyModel::orderBy('sno', 'desc')->first();

    if (!$category_check) {

      $year = substr(date('y'), -2);
      $company_id = 'EGC-0002/' . $year;
    } else {

      $data = $category_check->company_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);

      $next_number = (int) $result + 1;
      $request_id = sprintf('EGC-%04d', $next_number);

      $year = substr(date('y'), -2);
      $company_id = $request_id . '/' . $year;
    }
    $user_id = $request->user()->user_id ?? 1;
    $socialMediaData = request()->input('social_media');
     $socialMediaData = array_filter($socialMediaData, function($value) {
        return !is_null($value) && $value !== '';
    });
    $company_short_name=$request->company_short_name;
    $company_logo = '';
     $request = request(); // Assuming the request object is available.

        if ($request->hasFile('fav_icon')) {
            // Define the directory and the base filename
            $company_logos_path = public_path('Company_logos');
            $base_name = 'company_';
            $extension = $request->file('fav_icon')->extension();
            
            // Ensure the directory exists, or create it
            if (!is_dir($company_logos_path)) {
                mkdir($company_logos_path, 0777, true);
            }
        
            // Start by checking for the first file (company_1.png, company_2.png, etc.)
            $i = 1;
            do {
                $company_logo_name = $base_name . $i . '.' . $extension;
                $file_path = $company_logos_path . DIRECTORY_SEPARATOR . $company_logo_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path)); // Check if the file already exists
        
            // Move the uploaded file to the available path
            $request->file('fav_icon')->move($company_logos_path, $company_logo_name);
            $company_logo = $company_logo_name; // Assign the filename to the company_logo variable
        }
        if ($request->hasFile('fav_icon_comp')) {
            // Define the directory and the base filename
            $company_favicon_path = public_path('Company_favicon');
            $base_name_favicon = 'company_';
            $extension_favicon = $request->file('fav_icon_comp')->extension();
            
            // Ensure the directory exists, or create it
            if (!is_dir($company_favicon_path)) {
                mkdir($company_favicon_path, 0777, true);
            }
        
            // Start by checking for the first file (company_1.png, company_2.png, etc.)
            $i_favicon = 1;
            do {
                $company_favicon_name = $base_name_favicon . $i_favicon . '.' . $extension_favicon;
                $file_path_favicon = $company_favicon_path . DIRECTORY_SEPARATOR . $company_favicon_name;
                $i_favicon++; // Increment the number for the next iteration
            } while (file_exists($file_path_favicon)); // Check if the file already exists
        
            // Move the uploaded file to the available path
            $request->file('fav_icon_comp')->move($company_favicon_path, $company_favicon_name);
            $company_favicon = $company_favicon_name; // Assign the filename to the company_logo variable
        }

    $company_bank_name = $request->comapny_bank_name ?? [];
    $company_bank_branch = $request->comapny_bank_branch ?? [];
    $company_acc_holder = $request->comapny_acc_holder ?? [];
    $company_acc_no = $request->comapny_acc_no ??  [];
    $company_ifsc = $request->comapny_bank_ifsc ?? [];

    $Add = new CompanyModel();

     

    $Add->company_id = $company_id;
    $Add->company_name = $request->company_name;
    $Add->company_short_name = $company_short_name;
    $Add->company_base_color = $request->company_base_color;
    $Add->company_logo = $company_logo ?? NULL;
    $Add->company_favicon = $company_favicon ?? NULL;
    $Add->company_in_menu = $request->company_in_menu ? 1 : 0;
    $Add->company_type = $request->company_type;
    $Add->company_mail = $request->company_mail;
    $Add->social_media_details = json_encode($socialMediaData);
    $Add->company_website = $request->website_url;
    $Add->company_ct_person = $request->ct_person;
    $Add->company_ct_number = $request->ct_per_mobile_no;
    $Add->company_country = $request->country;
    $Add->company_state = $request->state;
    $Add->company_city = $request->city;
    $Add->company_area = $request->area_street;
    $Add->company_door_no = $request->door_flat_no;
    $Add->company_pincode = $request->pincode;
    $Add->company_gst = $request->gst_no;
    $Add->company_cin = $request->cin_no;
    $Add->company_pan = $request->pan_no;
    $Add->company_desc = $request->company_desc;
    // $Add->company_bank_name = $request->comapny_bank_name ? json_encode($request->comapny_bank_name) : NULL;
    // $Add->company_bank_branch = $request->comapny_bank_branch ? json_encode($request->comapny_bank_branch) : NULL;
    // $Add->company_acc_holder = $request->comapny_acc_holder ? json_encode($request->comapny_acc_holder) : NULL;
    // $Add->company_acc_no = $request->comapny_acc_no ? json_encode($request->comapny_acc_no) : NULL;
    // $Add->company_ifsc = $request->comapny_bank_ifsc ? json_encode($request->comapny_bank_ifsc) : NULL;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {

        foreach ($company_bank_name as $key => $bank) {
          CompanyBankModel::create([
            'company_id' => $Add->sno,
            'bank_name' => $bank,
            'bank_branch' => $company_bank_branch[$key],
            'account_holder' => $company_bank_branch[$key],
            'account_number' => $company_acc_holder[$key] ?? 0,
            'ifsc_code' => $company_ifsc[$key],
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Company added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Company!'
      ]);
    }

    return redirect()->back();

    // return $Add;
  }
  public function Update(Request $request)
  {

    $user_id = $request->user()->user_id ?? 1;
    $id = $request->edit_id;
    // return $request;
    
    $chk = CompanyModel::where('company_name', $request->company_name)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Company Name already Exists!'
        ]);
        return redirect()->back();
      }
       $company_short_name=$request->company_short_name;
          $socialMediaData = request()->input('social_media');
         $socialMediaData = array_filter($socialMediaData, function($value) {
            return !is_null($value) && $value !== '';
        });
    
       $company_logo = '';
      $request = request(); // Assuming the request object is available.

        if ($request->hasFile('logo')) {
            // Define the directory and the base filename
            $company_logos_path = public_path('Company_logos');
            $base_name = 'company_';
            $extension = $request->file('logo')->extension();
            
            // Ensure the directory exists, or create it
            if (!is_dir($company_logos_path)) {
                mkdir($company_logos_path, 0777, true);
            }
        
            // Start by checking for the first file (company_1.png, company_2.png, etc.)
            $i = 1;
            do {
                $company_logo_name = $base_name . $i . '.' . $extension;
                $file_path = $company_logos_path . DIRECTORY_SEPARATOR . $company_logo_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path)); // Check if the file already exists
        
            // Move the uploaded file to the available path
            $request->file('logo')->move($company_logos_path, $company_logo_name);
            $company_logo = $company_logo_name; // Assign the filename to the company_logo variable
        }else{
             $company_logo =$request->old_company_image;
        }

        if ($request->hasFile('upload_fav')) {
            // Define the directory and the base filename
            $company_favicon_path = public_path('Company_favicon');
            $base_name_favicon = 'company_';
            $extension_favicon = $request->file('upload_fav')->extension();
            
            // Ensure the directory exists, or create it
            if (!is_dir($company_favicon_path)) {
                mkdir($company_favicon_path, 0777, true);
            }
        
            // Start by checking for the first file (company_1.png, company_2.png, etc.)
            $i = 1;
            do {
                $company_favicon_name = $base_name_favicon . $i . '.' . $extension_favicon;
                $file_path_favicon = $company_favicon_path . DIRECTORY_SEPARATOR . $company_favicon_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path_favicon)); // Check if the file already exists
        
            // Move the uploaded file to the available path
            $request->file('upload_fav')->move($company_favicon_path, $company_favicon_name);
            $company_favicon = $company_favicon_name; // Assign the filename to the company_favicon variable
        }else{
             $company_favicon =$request->old_company_favicon;
        }
        
        
    $update = CompanyModel::where('sno', $id)->first();
    $update->company_name = $request->company_name;
    $update->company_short_name = $company_short_name;
    $update->company_logo = $company_logo ;
    $update->company_favicon = $company_favicon ?? NULL ;
    $update->company_type = $request->company_type;
    $update->company_mail = $request->company_mail;
    $update->company_in_menu = $request->company_in_menu ? 1 : 0;
    $update->company_base_color = $request->company_base_color;
     $update->social_media_details = json_encode($socialMediaData);
    $update->company_website = $request->website_url;
    $update->company_ct_person = $request->ct_person;
    $update->company_ct_number = $request->ct_per_mobile_no;
    $update->company_country = $request->country;
    $update->company_state = $request->state;
    $update->company_city = $request->city;
    $update->company_area = $request->area_street;
    $update->company_door_no = $request->door_flat_no;
    $update->company_pincode = $request->pincode;
    $update->company_gst = $request->gst_no;
    $update->company_cin = $request->cin_no;
    $update->company_pan = $request->pan_no;
    $update->company_desc = $request->company_desc;
    // $update->company_bank_name = $request->comapny_bank_name;
    // $update->company_bank_branch = $request->comapny_bank_branch;
    // $update->company_acc_holder = $request->comapny_acc_holder;
    // $update->company_acc_no = $request->comapny_acc_no;
    // $update->company_ifsc = $request->comapny_bank_ifsc;
    $update->created_by = $user_id;
    $update->updated_by = $user_id;

    $update->update();

    if ($update) {
      $bank_ids       = $request->bank_id ?? [];
        $bank_names     = $request->comapny_bank_name;
        $branches       = $request->comapny_bank_branch;
        $holders        = $request->comapny_acc_holder;
        $accounts       = $request->comapny_acc_no;
        $ifscs          = $request->comapny_bank_ifsc;

        $existingIds = CompanyBankModel::where('company_id', $id)
                        ->where('status', 0)
                        ->pluck('sno')
                        ->toArray();

        $submittedIds = array_filter($bank_ids); // remove empty
        // 🔴 SOFT DELETE (missing IDs)
        $deleteIds = array_diff($existingIds, $submittedIds);

        if (!empty($deleteIds)) {
            CompanyBankModel::whereIn('sno', $deleteIds)
                ->update([
                    'status' => 2,
                    'updated_by' => $user_id
                ]);
        }

        // 🟢 INSERT / UPDATE
        foreach ($bank_names as $key => $name) {

            if (!empty($bank_ids[$key])) {

                // UPDATE
                CompanyBankModel::where('sno', $bank_ids[$key])->update([
                    'bank_name'       => $name,
                    'bank_branch'     => $branches[$key],
                    'account_holder'  => $holders[$key],
                    'account_number'  => $accounts[$key],
                    'ifsc_code'       => $ifscs[$key],
                    'updated_by'      => $user_id
                ]);

            } else {

                // INSERT
                CompanyBankModel::create([
                    'company_id'      => $id,
                    'bank_name'       => $name,
                    'bank_branch'     => $branches[$key],
                    'account_holder'  => $holders[$key],
                    'account_number'  => $accounts[$key],
                    'ifsc_code'       => $ifscs[$key],
                    'created_by'      => $user_id,
                    'updated_by'      => $user_id,
                ]);
            }
        }
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Company Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Company!'
      ]);
    }

    return redirect()->back();

   
  }
  public function changeBranch(Request $request)
    {
        $validated = $request->validate([
          'branch_id' => 'required', // Validate that the branch exists
        ]);
        
        // Update the user's role_id in the users table
        $branch    =  BranchModel::where('sno', $validated['branch_id'])->first();
        $entity_id = $branch->entity_id ?? 1;
        // Update the user's branch_id in the users table
        $user =  User::where('user_id', $request->user()->user_id)->first();
        if ($user) {
          $user->branch_id = $validated['branch_id'];
          $user->entity_id = $entity_id;
          $user->save();
        }
    
        return response()->json(['success' => true]);
    }
   public function changeRole(Request $request)
    {
        $validated = $request->validate([
          'role_id' => 'required', // Validate that the branch exists
        ]);
    
        
         
        $user =  User::where('user_id', $request->user()->user_id)->where('role_id', $request->user()->role_id)->first();
        if ($user) {
          $user->role_id = $validated['role_id'];
         
          $user->save();
        }
    
        return response()->json(['success' => true]);
    }
    public function getUsersByRole(Request $request)
    {
        $request->validate([
            'role_id' => 'required|integer',
        ]);
        //   return $request->user()->branch_id;
    
        $users = User::where('egc_staff.role_id', $request->role_id)->where('users.branch_id', $request->user()->branch_id)
                ->join('egc_staff', 'users.user_id', '=', 'egc_staff.sno')
                ->where('egc_staff.status', 0) // Only active users
                ->get(['egc_staff.sno','egc_staff.staff_name']); // Fetch only required columns
    
        return response()->json(['users' => $users]);
    }
    public function changeUser(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,user_id', // Ensure user exists
        ]);
    
        $newUser = User::where('user_id', $request->user_id)->first();
    
        if (!$newUser) {
            return response()->json(['success' => false, 'message' => 'User not found.'], 404);
        }
    
        // Generate new token for the selected user
        $token = $newUser->createToken('SuperUserToken')->plainTextToken;
    
        // Store the token in session or database as per your requirement
        session(['super_user_token' => $token]); // For session-based auth
    
        // If storing in DB, update the super_user_token column
        $newUser->update(['super_user_token' => $token]);
    
        // Log in as the new user
        Auth::loginUsingId($newUser->id);
    
        return response()->json([
            'success' => true,
            'message' => 'User switched successfully.',
            'token' => $token
        ]);
    }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('egc_company')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }
}
