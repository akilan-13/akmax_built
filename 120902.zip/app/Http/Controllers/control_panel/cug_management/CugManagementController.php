<?php

namespace App\Http\Controllers\control_panel\cug_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use App\Models\StaffModel;

class CugManagementController extends Controller
{


    protected string $cugTable = 'egc_cug_numbers';
    protected string $cugAssignmentTable = 'egc_cug_assignments';
    protected string $cugCallLogTable = 'egc_call_tracker';

    public function index()
    {
        return view('content.control_panel.cug_management.index');
    }

    /* DATATABLE */
    // public function datatable( Request $request ): JsonResponse {
    //     try {

    //         $query = DB::table( $this->cugTable . ' as c');
    //         /* Staff assignment */
    //         $query->leftJoin( $this->cugAssignmentTable . ' as ca',
    //             function ($join) {
    //                 $join->on('ca.cug_id', '=', 'c.sno' );
    //                 $join->where( 'ca.is_current','=', 1 );
    //                 $join->where('ca.status', '=',0 );
    //             }
    //         );
    //         /*Staff*/
    //         $query->leftJoin('egc_staff as s','s.sno','=','ca.staff_id' );
    //         /*Company */
    //         $query->leftJoin('egc_company as company',
    //             function ($join) {
    //                 $join->on('company.sno','=','c.company_id');
    //                 $join->where('company.status', '=', 0 );
    //             }
    //         );
    //         /*Entity */
    //         $query->leftJoin('egc_entity as entity',
    //             function ($join) {
    //                 $join->on('entity.sno','=','c.entity_id');
    //                 $join->where('entity.status','=', 0 );
    //             }
    //         );

    //         /* Search */
    //         $search =
    //             trim((string) $request->input(
    //                     'search.value', $request->input('search', '' )
    //                 )
    //             );

    //         if ($search !== '') {
    //             $query->where(
    //                 function ($q) use ($search) {
    //                     $q->where( 'c.cug_number','like','%' . $search . '%' )
    //                     ->orWhere('c.cug_code', 'like','%' . $search . '%' )
    //                     ->orWhere('s.staff_name','like', '%' . $search . '%' )
    //                     ->orWhere('s.staff_id','like', '%' . $search . '%' )
    //                     ->orWhere( 'company.company_name','like','%' . $search . '%')
    //                     ->orWhere('entity.entity_name','like', '%' . $search . '%');
    //                 }
    //             );

    //         }

    //         /* Filters */
    //         if ($request->filled('company_id') ) {
    //             $query->where('c.company_id', $request->company_id );
    //         }

    //         if ($request->filled('entity_id')) {
    //             $query->where('c.entity_id', $request->entity_id);
    //         }
    //         if ($request->filled('branch_id')) {
    //             $query->where('c.branch_id', $request->branch_id);
    //         }
    //         if ($request->filled('status')) {
    //             $query->where('c.status', $request->status);
    //         }

    //         /* Total */
    //         $recordsTotal = DB::table( $this->cugTable )
    //             ->where( 'status', '!=',2)
    //             ->count();

    //         $recordsFiltered = (clone $query)->count('c.sno');

    //         /* Ordering */
    //         $allowedOrderColumns = [
    //             0 => 'c.sno',
    //             1 => 'c.cug_number',
    //             2 => 'company.company_name',
    //             3 => 'entity.entity_name',
    //             4 => 's.staff_name',
    //             5 => 'c.status',
    //             6 => 'c.created_at',
    //         ];


    //         $orderColumn = $request->input( 'order.0.column', 0);
    //         $orderDirection = strtolower($request->input('order.0.dir', 'desc' ) );

    //         if (!in_array( $orderDirection, ['asc','desc'], true ) ) {
    //             $orderDirection = 'desc';
    //         }

    //         $orderBy = $allowedOrderColumns[ $orderColumn ] ?? 'c.sno';

    //         $query->orderBy( $orderBy, $orderDirection );

    //         /*Pagination */

    //         $start =  max( 0, (int) $request->input( 'start', 0 ) );
    //         $length = (int) $request->input('length', 25 );

    //         if ($length < 1 ) {
    //             $length = 25;
    //         }

    //         if ($length > 100 ) {
    //             $length = 100;
    //         }

    //         /* Fetch */
    //         $rows = $query
    //                 ->select([
    //                     'c.sno',
    //                     'c.cug_number',
    //                     'c.cug_code',
    //                     'c.provider',
    //                     'c.company_id',
    //                     'c.entity_id',
    //                     'c.branch_id',
    //                     'c.status',
    //                     'c.remarks',
    //                     'c.created_at',
    //                     'c.updated_at',

    //                     'company.company_name',

    //                     'entity.entity_name',

    //                     's.sno as staff_sno',
    //                     's.staff_id',
    //                     's.staff_name',
    //                     's.department_id',
    //                     's.job_role_id',

    //                 ])
    //                 ->skip( $start)
    //                 ->take( $length)
    //                 ->get();

    //         /* Response */

    //         $data =
    //             $rows->map(
    //                 function ($row) {
    //                     return [
    //                         'id' => $row->sno,
    //                         'cug_number' => $row->cug_number,
    //                         'cug_code' => $row->cug_code,
    //                         'provider' => $row->provider,
    //                         'company_id' =>  $row->company_id,
    //                         'company_name' => $row->company_name,
    //                         'entity_id' => $row->entity_id,
    //                         'entity_name' => $row->entity_name,
    //                         'branch_id' => $row->branch_id,
    //                         'staff_id' =>  $row->staff_id,
    //                         'staff_name' => $row->staff_name,
    //                         'status' =>  $row->status,
    //                         'status_label' =>  $this->statusLabel($row->status ),
    //                         'remarks' => $row->remarks,
    //                         'created_at' => $row->created_at,
    //                         'updated_at' => $row->updated_at,
    //                     ];
    //                 }
    //             )
    //             ->values();


    //         return response()->json([
    //             'draw' => (int) $request->input( 'draw', 0 ),
    //             'recordsTotal' => $recordsTotal,
    //             'recordsFiltered' => $recordsFiltered,
    //             'data' =>  $data,
    //         ]);

    //     } catch (\Throwable $e) {

    //         // report($e);

    //         return response()->json([
    //             'success' =>  false,
    //             'message' => 'Unable to load CUG records.',
    //             'err' => $e->getMessage(),
    //             'data' => [],
    //         ], 500);

    //     }

    // }

    /* DATATABLE */
    public function datatable(Request $request): JsonResponse
    {
        try {

            /*
            |--------------------------------------------------------------------------
            | Current assignment sub-query
            |--------------------------------------------------------------------------
            |
            | A CUG can have many historical assignment rows, but the table must
            | display only the current active assignment.
            |
            */
            $currentAssignments = DB::table(
                $this->cugAssignmentTable . ' as ca'
            )
                ->select([
                    'ca.cug_id',
                    'ca.sno as assignment_id',
                    'ca.staff_id',
                    'ca.start_date as assignment_start_date',
                    'ca.end_date as assignment_end_date',
                    'ca.reason as assignment_reason',
                    'ca.remarks as assignment_remarks',
                ])
                ->where('ca.is_current', 1)
                ->where('ca.status', 0);


            /*
            |--------------------------------------------------------------------------
            | Call count sub-query
            |--------------------------------------------------------------------------
            |
            | Aggregate once instead of executing one query per DataTable row.
            |
            */
            $callCounts = DB::table(
                $this->cugCallLogTable
            )
                ->select([
                    'cug_id',
                ])
                ->selectRaw('COUNT(*) AS call_count')
                ->groupBy('cug_id');


            /*
            |--------------------------------------------------------------------------
            | Main query
            |--------------------------------------------------------------------------
            */
            $query = DB::table(
                $this->cugTable . ' as c'
            )

                ->leftJoinSub(
                    $currentAssignments,
                    'ca',
                    function ($join) {
                        $join->on(
                            'ca.cug_id',
                            '=',
                            'c.sno'
                        );
                    }
                )

                ->leftJoin(
                    'egc_staff as s',
                    's.sno',
                    '=',
                    'ca.staff_id'
                )

                ->leftJoin(
                    'egc_company as company',
                    function ($join) {
                        $join->on(
                            'company.sno',
                            '=',
                            'c.company_id'
                        );

                        $join->where(
                            'company.status',
                            '=',
                            0
                        );
                    }
                )

                ->leftJoin(
                    'egc_entity as entity',
                    function ($join) {
                        $join->on(
                            'entity.sno',
                            '=',
                            'c.entity_id'
                        );

                        $join->where(
                            'entity.status',
                            '=',
                            0
                        );
                    }
                )

                ->leftJoinSub(
                    $callCounts,
                    'calls',
                    function ($join) {
                        $join->on(
                            'calls.cug_id',
                            '=',
                            'c.sno'
                        );
                    }
                );


            /*
            |--------------------------------------------------------------------------
            | Never expose business-deleted / archived CUGs
            |--------------------------------------------------------------------------
            */
            $query->where(
                'c.status',
                '!=',
                2
            );


            /*
            |--------------------------------------------------------------------------
            | Global search
            |--------------------------------------------------------------------------
            */
            $search = trim(
                (string) $request->input(
                    'search.value',
                    $request->input(
                        'search',
                        ''
                    )
                )
            );

            if ($search !== '') {

                $query->where(function ($q) use ($search) {

                    $like = '%' . $search . '%';

                    $q->where(
                        'c.cug_number',
                        'like',
                        $like
                    )

                    ->orWhere(
                        'c.cug_code',
                        'like',
                        $like
                    )

                    ->orWhere(
                        'c.provider',
                        'like',
                        $like
                    )

                    ->orWhere(
                        's.staff_name',
                        'like',
                        $like
                    )

                    ->orWhere(
                        's.staff_id',
                        'like',
                        $like
                    )

                    ->orWhere(
                        'company.company_name',
                        'like',
                        $like
                    )

                    ->orWhere(
                        'entity.entity_name',
                        'like',
                        $like
                    );

                });
            }


            /*
            |--------------------------------------------------------------------------
            | Company
            |--------------------------------------------------------------------------
            */
            if ($request->filled('company_id')) {

                $query->where(
                    'c.company_id',
                    $request->input('company_id')
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Entity
            |--------------------------------------------------------------------------
            */
            if ($request->filled('entity_id')) {

                $query->where(
                    'c.entity_id',
                    $request->input('entity_id')
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Branch
            |--------------------------------------------------------------------------
            |
            | branch_id is already present on your CUG master table.
            |
            */
            if ($request->filled('branch_id')) {

                $query->where(
                    'c.branch_id',
                    $request->input('branch_id')
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Provider
            |--------------------------------------------------------------------------
            */
            if (
                $request->filled('provider') &&
                strtolower(
                    trim(
                        (string) $request->input('provider')
                    )
                ) !== 'all'
            ) {

                $provider = trim(
                    (string) $request->input('provider')
                );

                $query->where(
                    'c.provider',
                    $provider
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Staff
            |--------------------------------------------------------------------------
            */
            if ($request->filled('staff_id')) {

                $query->where(
                    'ca.staff_id',
                    $request->input('staff_id')
                );
            }


            /*
            |--------------------------------------------------------------------------
            | CUG status
            |--------------------------------------------------------------------------
            |
            | Supported visible master statuses:
            |   0 = Available
            |   1 = Assigned
            |   3 = Inactive
            |
            | Status 2 remains excluded as archived/deleted.
            |
            */
            if ($request->filled('status')) {

                $status = $request->input('status');

                /*
                * Do not allow arbitrary status values into the query.
                */
                if (
                    in_array(
                        (string) $status,
                        ['0', '1', '3'],
                        true
                    )
                ) {
                    $query->where(
                        'c.status',
                        (int) $status
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Assignment status
            |--------------------------------------------------------------------------
            |
            | Supported values:
            |
            |   assigned / Assigned / 1
            |   available / Available / 0
            |
            | "available" means the CUG does not currently have an active
            | assignment.
            |
            */
            if ($request->filled('assignment_status')) {

                $assignmentStatus = strtolower(
                    trim(
                        (string) $request->input(
                            'assignment_status'
                        )
                    )
                );

                if (
                    in_array(
                        $assignmentStatus,
                        [
                            'assigned',
                            '1',
                            'active',
                        ],
                        true
                    )
                ) {

                    $query->whereNotNull(
                        'ca.assignment_id'
                    );

                } elseif (
                    in_array(
                        $assignmentStatus,
                        [
                            'available',
                            '0',
                            'unassigned',
                        ],
                        true
                    )
                ) {

                    $query->whereNull(
                        'ca.assignment_id'
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | CUG number range
            |--------------------------------------------------------------------------
            |
            | Stored CUG numbers are strings, therefore use lexical comparison
            | by default. For purely numeric values this also works correctly
            | when the stored format is consistent.
            |
            */
            if ($request->filled('number_from')) {

                $numberFrom = trim(
                    (string) $request->input(
                        'number_from'
                    )
                );

                if ($numberFrom !== '') {

                    $query->where(
                        'c.cug_number',
                        '>=',
                        $numberFrom
                    );
                }
            }


            if ($request->filled('number_to')) {

                $numberTo = trim(
                    (string) $request->input(
                        'number_to'
                    )
                );

                if ($numberTo !== '') {

                    $query->where(
                        'c.cug_number',
                        '<=',
                        $numberTo
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Assignment date FROM
            |--------------------------------------------------------------------------
            */
            if ($request->filled('assigned_from')) {

                $assignedFrom = $request->input(
                    'assigned_from'
                );

                $query->whereDate(
                    'ca.assignment_start_date',
                    '>=',
                    $assignedFrom
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Assignment date TO
            |--------------------------------------------------------------------------
            */
            if ($request->filled('assigned_to')) {

                $assignedTo = $request->input(
                    'assigned_to'
                );

                $query->whereDate(
                    'ca.assignment_start_date',
                    '<=',
                    $assignedTo
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Total before filters
            |--------------------------------------------------------------------------
            */
            $recordsTotal = DB::table(
                $this->cugTable
            )
                ->where(
                    'status',
                    '!=',
                    2
                )
                ->count('sno');


            /*
            |--------------------------------------------------------------------------
            | Filtered total
            |--------------------------------------------------------------------------
            */
            $recordsFiltered = (clone $query)
                ->distinct()
                ->count('c.sno');


            /*
            |--------------------------------------------------------------------------
            | Ordering
            |--------------------------------------------------------------------------
            |
            | Frontend columns:
            |
            | 0 = checkbox
            | 1 = CUG number
            | 2 = provider
            | 3 = company
            | 4 = entity
            | 5 = staff
            | 6 = assignment
            | 7 = calls
            | 8 = status
            | 9 = actions
            |
            */
            $allowedOrderColumns = [

                0 => 'c.sno',

                1 => 'c.cug_number',

                2 => 'c.provider',

                3 => 'company.company_name',

                4 => 'entity.entity_name',

                5 => 's.staff_name',

                6 => 'ca.assignment_start_date',

                7 => 'calls.call_count',

                8 => 'c.status',

                9 => 'c.sno',

            ];


            $orderColumn = (int) $request->input(
                'order.0.column',
                1
            );

            $orderDirection = strtolower(
                (string) $request->input(
                    'order.0.dir',
                    'asc'
                )
            );


            if (
                !in_array(
                    $orderDirection,
                    [
                        'asc',
                        'desc',
                    ],
                    true
                )
            ) {
                $orderDirection = 'asc';
            }


            $orderBy =
                $allowedOrderColumns[
                    $orderColumn
                ]
                ?? 'c.sno';


            /*
            |--------------------------------------------------------------------------
            | Stable secondary ordering
            |--------------------------------------------------------------------------
            */
            $query->orderBy(
                $orderBy,
                $orderDirection
            );

            $query->orderBy(
                'c.sno',
                'desc'
            );


            /*
            |--------------------------------------------------------------------------
            | Pagination
            |--------------------------------------------------------------------------
            | Use explicit page/per_page pagination. This keeps the endpoint independent
            | from jQuery DataTables and matches the CUG management UI contract.
            */
            $page = max(1, (int) $request->input('page', 1));
            $perPage = (int) $request->input('per_page', 25);

            $allowedPerPage = [5, 10, 25, 100, 500];
            if (!in_array($perPage, $allowedPerPage, true)) {
                $perPage = 25;
            }

            $total = (int) $recordsFiltered;
            $lastPage = max(1, (int) ceil($total / $perPage));

            if ($page > $lastPage) {
                $page = $lastPage;
            }

            $offset = ($page - 1) * $perPage;

            /*
            |--------------------------------------------------------------------------
            | Fetch rows
            |--------------------------------------------------------------------------
            */
            $rows = $query
                ->select([
                    'c.sno',

                    'c.cug_number',
                    'c.cug_code',
                    'c.provider',

                    'c.company_id',
                    'c.entity_id',
                    'c.branch_id',

                    'c.status',
                    'c.remarks',

                    'c.created_at',
                    'c.updated_at',

                    DB::raw("CASE WHEN c.company_id = 0 THEN 'Elysium Groups' ELSE company.company_name END AS company_name"),

                    DB::raw("CASE WHEN c.entity_id = 0 THEN 'Not Applicable' ELSE entity.entity_name END AS entity_name"),

                    'ca.assignment_id',
                    'ca.staff_id',

                    'ca.assignment_start_date',
                    'ca.assignment_end_date',
                    'ca.assignment_reason',
                    'ca.assignment_remarks',

                    's.staff_id as staff_code',
                    's.staff_name',

                    's.department_id',
                    's.job_role_id',

                    DB::raw(
                        'COALESCE(calls.call_count, 0) AS call_count'
                    ),
                ])
                ->distinct()
                ->offset($offset)
                ->limit($perPage)
                ->get();


            /*
            |--------------------------------------------------------------------------
            | Transform
            |--------------------------------------------------------------------------
            */
            $data = $rows
                ->map(function ($row) {

                    $hasCurrentAssignment =
                        !empty(
                            $row->assignment_id
                        );


                    /*
                    | Assignment status for frontend.
                    */
                    $assignmentStatus =
                        $hasCurrentAssignment
                            ? 'assigned'
                            : 'available';


                    /*
                    | Assignment label.
                    */
                    $assignmentLabel =
                        $hasCurrentAssignment
                            ? 'Assigned'
                            : 'Available';


                    /*
                    | Current staff object.
                    */
                    $staff = null;

                    if ($hasCurrentAssignment) {

                         $staffData = StaffModel::where('sno', $row->staff_id)->first();

                        $staff = [
                            'sno' => $row->staff_id,
                            'id' => $row->staff_id,
                            'staff_id' => $row->staff_code,
                            'staff_code' => $row->staff_code,
                            'staff_name' => $row->staff_name,
                            'staff_image_url' => $staffData->profile_image_url ?? '',
                            'department_id' => $row->department_id,
                            'job_role_id' => $row->job_role_id,
                        ];
                    }


                    return [

                        /*
                        |--------------------------------------------------------------------------
                        | Identity
                        |--------------------------------------------------------------------------
                        */
                        'id' =>
                            $row->sno,

                        'sno' =>
                            $row->sno,


                        /*
                        |--------------------------------------------------------------------------
                        | CUG
                        |--------------------------------------------------------------------------
                        */
                        'cug_number' =>
                            $row->cug_number,

                        'cug_code' =>
                            $row->cug_code,

                        'provider' =>
                            $row->provider,


                        /*
                        |--------------------------------------------------------------------------
                        | Organisation
                        |--------------------------------------------------------------------------
                        */
                        'company_id' =>
                            $row->company_id,

                        'company_name' =>
                            $row->company_name,

                        'entity_id' =>
                            $row->entity_id,

                        'entity_name' =>
                            $row->entity_name,

                        'branch_id' =>
                            $row->branch_id,


                        /*
                        |--------------------------------------------------------------------------
                        | Staff
                        |--------------------------------------------------------------------------
                        */
                        'staff_id' =>
                            $row->staff_id,

                        'staff_code' =>
                            $row->staff_code,

                        'staff_name' =>
                            $row->staff_name,

                        'staff' =>
                            $staff,


                        /*
                        |--------------------------------------------------------------------------
                        | Assignment
                        |--------------------------------------------------------------------------
                        */
                        'assignment_id' =>
                            $row->assignment_id,

                        'assignment_status' =>
                            $assignmentStatus,

                        'assignment_status_label' =>
                            $assignmentLabel,

                        'assignment_start_date' =>
                            $row->assignment_start_date,

                        'assignment_end_date' =>
                            $row->assignment_end_date,

                        'assignment_date' =>
                            $row->assignment_start_date,

                        'assignment_reason' =>
                            $row->assignment_reason,

                        'assignment_remarks' =>
                            $row->assignment_remarks,


                        /*
                        |--------------------------------------------------------------------------
                        | Calls
                        |--------------------------------------------------------------------------
                        */
                        'call_count' =>
                            (int) $row->call_count,

                        'calls' =>
                            (int) $row->call_count,


                        /*
                        |--------------------------------------------------------------------------
                        | Master status
                        |--------------------------------------------------------------------------
                        */
                        'status' =>
                            (int) $row->status,

                        'status_label' =>
                            $this->statusLabel(
                                $row->status
                            ),


                        /*
                        |--------------------------------------------------------------------------
                        | Other
                        |--------------------------------------------------------------------------
                        */
                        'remarks' =>
                            $row->remarks,

                        'created_at' =>
                            $row->created_at,

                        'updated_at' =>
                            $row->updated_at,

                    ];
                })
                ->values();


            /*
            |--------------------------------------------------------------------------
            | Response
            |--------------------------------------------------------------------------
            */
            return response()->json([
                'success' => true,
                'data' => $data,
                'current_page' => $page,
                'last_page' => $lastPage,
                'total' => $total,
                'per_page' => $perPage,
                // Kept for backward compatibility with any old consumer.
                'recordsTotal' => $recordsTotal,
                'recordsFiltered' => $recordsFiltered,
            ]);

        } catch (\Throwable $e) {

            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load CUG records.',
                'data' => [],
                'current_page' => 1,
                'last_page' => 1,
                'total' => 0,
                'per_page' => 25,
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'err' => $e->getMessage(),
                'line' => $e->getLine(),
            ], 500);
        }
    }

    /* SHOW */
    public function show( int $id ): JsonResponse {
        try {

            $cug =
                DB::table(
                    $this->cugTable . ' as c'
                )

                ->leftJoin(
                    'egc_company as company',
                    'company.sno',
                    '=',
                    'c.company_id'
                )

                ->leftJoin(
                    'egc_entity as entity',
                    'entity.sno',
                    '=',
                    'c.entity_id'
                )

                ->where('c.sno', $id)
                ->where('c.status', '!=', 2)

                ->select([

                    'c.sno',
                    'c.cug_number',
                    'c.cug_code',
                    'c.provider',

                    'c.company_id',
                    'c.entity_id',
                    'c.branch_id',

                    'c.status',
                    'c.remarks',

                    'c.created_at',
                    'c.updated_at',

                    'company.company_name',
                    'entity.entity_name',

                ])

                ->first();


            if (!$cug) {

                return response()->json([

                    'success' =>
                        false,

                    'message' =>
                        'CUG number not found.',

                ], 404);

            }


            /*
            |--------------------------------------------------------------------------
            | Current Assignment
            |--------------------------------------------------------------------------
            */

            $assignment =
                DB::table(
                    $this->cugAssignmentTable . ' as ca'
                )

                ->leftJoin(
                    'egc_staff as s',
                    's.sno',
                    '=',
                    'ca.staff_id'
                )

                ->where(
                    'ca.cug_id',
                    $id
                )

                ->where(
                    'ca.is_current',
                    1
                )

                ->where(
                    'ca.status',
                    0
                )

                ->select([

                    'ca.sno as assignment_id',

                    'ca.staff_id',

                    'ca.start_date',

                    'ca.end_date',

                    'ca.reason',

                    'ca.remarks',

                    's.staff_id as staff_code',

                    's.staff_name',

                    's.department_id',

                    's.job_role_id',

                ])

                ->first();

            $callCount = DB::table(
                $this->cugCallLogTable
            )
            ->where(
                'cug_id',
                $id
            )
            ->count();


            return response()->json([

                'success' =>
                    true,

                'data' => [

                    'sno' =>
                        $cug->sno,

                    'id' =>
                        $cug->sno,

                    'cug_number' =>
                        $cug->cug_number,

                    'cug_code' =>
                        $cug->cug_code,

                    'provider' =>
                        $cug->provider,

                    'company_id' =>
                        $cug->company_id,

                    'company_name' =>
                        $cug->company_name,

                    'entity_id' =>
                        $cug->entity_id,

                    'entity_name' =>
                        $cug->entity_name,

                    'branch_id' =>
                        $cug->branch_id,

                    'status' =>
                        $cug->status,

                    'status_label' =>
                        $this->statusLabel(
                            $cug->status
                        ),

                    'remarks' =>
                        $cug->remarks,

                    'current_staff' =>
                        $assignment
                            ? [

                                'staff_id' =>
                                    $assignment->staff_id,

                                'staff_code' =>
                                    $assignment->staff_code,

                                'staff_name' =>
                                    $assignment->staff_name,

                                'department_id' =>
                                    $assignment->department_id,

                                'job_role_id' =>
                                    $assignment->job_role_id,

                                'start_date' =>
                                    $assignment->start_date,

                                'end_date' =>
                                    $assignment->end_date,

                            ]
                            : null,

                    'staff_id' =>
                        $assignment->staff_id
                            ?? null,

                    'staff_name' =>
                        $assignment->staff_name
                            ?? null,

                    'call_count' =>
                            $callCount,
                ],

            ]);

        } catch (
            \Throwable $e
        ) {

            report($e);

            return response()->json([

                'success' =>
                    false,

                'message' =>
                    'Unable to load CUG details.',

            ], 500);

        }

    }

    /* COMPANIES */
    public function companies(): JsonResponse
    {
        try {
            $rows = DB::table('egc_company')
                ->where('status', 0)
                ->select([
                    'sno as id',
                    'company_id',
                    'company_name',
                ])
                ->orderBy('company_name')
                ->get()
                ->map(function ($row) {
                    return [
                        'id' => (int) $row->id,
                        'company_id' => (int) $row->company_id,
                        'company_name' => $row->company_name,
                    ];
                })
                ->values();

            // Fixed ERP-level company. Entity and branch are intentionally 0.
            $rows->prepend([
                'id' => 0,
                'company_id' => 0,
                'company_name' => 'Elysium Groups',
            ]);

            return response()->json([
                'success' => true,
                'data' => $rows->values(),
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load companies.',
                'data' => [],
            ], 500);
        }
    }

    /* ENTITIES */
    public function entities(Request $request): JsonResponse {

        $request->validate([

            'company_id' =>
                [
                    'required',
                    'integer',
                ],

        ]);


        try {

            $rows =
                DB::table(
                    'egc_entity'
                )

                ->where(
                    'company_id',
                    $request->company_id
                )

                ->where(
                    'status',
                    0
                )

                ->select([
                    'sno as id',
                    'entity_id',
                    'entity_name',
                ])

                ->orderBy(
                    'entity_name'
                )

                ->get();


            return response()->json([

                'success' =>
                    true,

                'data' =>
                    $rows,

            ]);

        } catch (
            \Throwable $e
        ) {

            report($e);

            return response()->json([

                'success' =>
                    false,

                'message' =>
                    'Unable to load entities.',

                'data' =>
                    [],

            ], 500);

        }

    }

    /* BRANCHES */
    public function branches(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'entity_id' => ['nullable', 'integer', 'min:1'],
            'company_id' => ['nullable', 'integer', 'min:0'],
        ]);

        try {
            $entityId = array_key_exists('entity_id', $validated) && $validated['entity_id'] !== null
                ? (int) $validated['entity_id']
                : null;
            $companyId = array_key_exists('company_id', $validated)
                ? (int) $validated['company_id']
                : null;

            foreach (['egc_branch', 'egc_branches'] as $table) {
                if (!Schema::hasTable($table)) {
                    continue;
                }

                $columns = Schema::getColumnListing($table);

                $idColumn = collect(['sno', 'id', 'branch_id'])
                    ->first(fn ($column) => in_array($column, $columns, true));

                $nameColumn = collect(['branch_name', 'name'])
                    ->first(fn ($column) => in_array($column, $columns, true));

                if (!$idColumn || !$nameColumn) {
                    continue;
                }

                $query = DB::table($table);

                if (in_array('status', $columns, true)) {
                    $query->where('status', 0);
                }

                // Entity is required for normal companies, but Elysium Groups
                // (company_id=0) is intentionally branch-driven.
                if ($entityId !== null) {
                    if (in_array('entity_id', $columns, true)) {
                        $query->where('entity_id', $entityId);
                    } elseif (in_array('entity_sno', $columns, true)) {
                        $query->where('entity_sno', $entityId);
                    }
                }

                if ($companyId !== null) {
                    if (in_array('company_id', $columns, true)) {
                        $query->where('company_id', $companyId);
                    } elseif (in_array('company_sno', $columns, true)) {
                        $query->where('company_sno', $companyId);
                    }
                }

                return response()->json([
                    'success' => true,
                    'data' => $query
                        ->select([
                            DB::raw("{$idColumn} as id"),
                            DB::raw("{$nameColumn} as name"),
                        ])
                        ->orderBy($nameColumn)
                        ->get(),
                ]);
            }

            // Fallback: expose distinct branches currently used by active staff.
            $query = DB::table('egc_staff')
                ->where('status', 0)
                ->whereNotNull('branch_id');

            if ($entityId !== null) {
                $query->where('entity_id', $entityId);
            }

            if ($companyId !== null) {
                $query->where('company_id', $companyId);
            }

            $rows = $query
                ->select('branch_id')
                ->distinct()
                ->orderBy('branch_id')
                ->get()
                ->map(fn ($row) => [
                    'id' => (int) $row->branch_id,
                    'name' => 'Branch #' . $row->branch_id,
                ])
                ->values();

            return response()->json([
                'success' => true,
                'data' => $rows,
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load branches.',
                'data' => [],
            ], 500);
        }
    }

    protected function resolveStaffJobRoleTable(): ?array
    {
        foreach (['egc_job_role', 'egc_job_roles', 'egc_job_roles_master'] as $table) {
            if (!Schema::hasTable($table)) {
                continue;
            }

            $columns = Schema::getColumnListing($table);

            $idColumn = collect(['sno', 'id', 'job_role_id'])
                ->first(fn ($column) => in_array($column, $columns, true));

            $nameColumn = collect(['job_role_name', 'role_name', 'name'])
                ->first(fn ($column) => in_array($column, $columns, true));

            if ($idColumn && $nameColumn) {
                return [
                    'table' => $table,
                    'id' => $idColumn,
                    'name' => $nameColumn,
                ];
            }
        }

        return null;
    }

    /* STAFF SEARCH */
    public function staffSearch(Request $request): JsonResponse
    {
        $search = trim((string) $request->input('q', ''));
        $companyId = $request->input('company_id');
        $entityId = $request->input('entity_id');
        $branchId = $request->input('branch_id');
        $page = max(1, (int) $request->input('page', 1));
        $staffPerPage = 20;

        // Select2 opens with an empty search when minimumInputLength is 0.
        // Return the first page for that case; typed searches still require
        // at least two characters to avoid expensive broad LIKE queries.
        if ($search !== '' && mb_strlen($search) < 2) {
            return response()->json([
                'success' => true,
                'data' => [],
                'pagination' => ['more' => false],
            ]);
        }

        try {
            $query = DB::table('egc_staff as s')
                ->leftJoin('egc_company as company', 'company.sno', '=', 's.company_id')
                ->where('s.status', 0);

            if ($search !== '') {
                $query->where(function ($q) use ($search) {
                    $like = '%' . $search . '%';

                    $q->where('s.staff_name', 'like', $like)
                        ->orWhere('s.staff_id', 'like', $like)
                        ->orWhere('s.mobile_no', 'like', $like)
                        ->orWhere('s.email_id', 'like', $like);
                });
            }

            $roleTable = $this->resolveStaffJobRoleTable();

            if ($roleTable) {
                $query->leftJoin(
                    $roleTable['table'] . ' as jr',
                    'jr.' . $roleTable['id'],
                    '=',
                    's.job_role_id'
                );
            }

            // Staff is branch-driven whenever a branch is supplied.
            // For company_id=0, do not additionally constrain by company_id;
            // this is required for Elysium branch-scoped staff.
            if ($companyId !== null && $companyId !== '' && (int) $companyId !== 0) {
                $query->where('s.company_id', (int) $companyId);
            }

            if ($entityId !== null && $entityId !== '' && (int) $companyId !== 0) {
                $query->where('s.entity_id', (int) $entityId);
            }

            if ($branchId !== null && $branchId !== '') {
                $query->where('s.branch_id', (int) $branchId);
            }

            $selects = [
                's.sno',
                's.staff_id',
                's.staff_name',
                's.company_id',
                's.entity_id',
                's.branch_id',
                's.department_id',
                's.job_role_id',
                's.email_id',
                's.mobile_no',
                'company.company_name',
            ];

            if ($roleTable) {
                $selects[] = DB::raw(
                    'jr.' . $roleTable['name'] . ' as job_role_name'
                );
            } elseif (Schema::hasColumn('egc_staff', 'job_role_name')) {
                $selects[] = 's.job_role_name';
            } else {
                $selects[] = DB::raw('NULL as job_role_name');
            }

            $rows = $query
                ->select($selects)
                ->orderBy('s.staff_name')
                ->orderBy('s.sno')
                ->offset(($page - 1) * $staffPerPage)
                ->limit($staffPerPage + 1)
                ->get();

            $data = $rows->take($staffPerPage)->map(function ($staff) {
                return [
                    'id' => $staff->sno,
                    'sno' => $staff->sno,
                    'staff_id' => $staff->staff_id,
                    'staff_name' => $staff->staff_name,
                    'job_role_name' => $staff->job_role_name ?: 'Role not assigned',
                    'company_id' => $staff->company_id,
                    'company_name' => $staff->company_name,
                    'entity_id' => $staff->entity_id,
                    'branch_id' => $staff->branch_id,
                    'department_id' => $staff->department_id,
                    'job_role_id' => $staff->job_role_id,
                    'email_id' => $staff->email_id,
                    'mobile_no' => $staff->mobile_no,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $data,
                'pagination' => [
                    'more' => $rows->count() > $staffPerPage,
                ],
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to search staff.',
                'data' => [],
                'pagination' => ['more' => false],
            ], 500);
        }
    }

    /* ELYSIUM GROUP STAFF SEARCH */
    public function branchStaffSearch(Request $request): JsonResponse
    {
        // ERP-level Elysium staff are scoped to the fixed branch_id = 0.
        // Entity is not used and company_id is intentionally not used as a
        // staff filter for this endpoint.
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:100'],
            'page' => ['nullable', 'integer', 'min:1'],
            'branch_id' => ['nullable'],
        ]);

        $search = trim((string) ($validated['q'] ?? ''));
        $page = (int) ($validated['page'] ?? 1);
        $staffPerPage = 20;

        if ($search !== '' && mb_strlen($search) < 2) {
            return response()->json([
                'success' => true,
                'data' => [],
                'pagination' => ['more' => false],
            ]);
        }

        try {
           $branch_id= $request->branch_id;
           $company_id= $request->company_id;
            $query = DB::table('egc_staff as s')
                ->leftJoin('egc_company as company', 'company.sno', '=', 's.company_id')
                ->where('s.status', 0)
                ->where('s.branch_id', $branch_id);

            if ($search !== '') {
                $like = '%' . $search . '%';
                $query->where(function ($q) use ($like) {
                    $q->where('s.staff_name', 'like', $like)
                        ->orWhere('s.staff_id', 'like', $like)
                        ->orWhere('s.mobile_no', 'like', $like)
                        ->orWhere('s.email_id', 'like', $like);
                });
            }

            $roleTable = $this->resolveStaffJobRoleTable();

            if ($roleTable) {
                $query->leftJoin(
                    $roleTable['table'] . ' as jr',
                    'jr.' . $roleTable['id'],
                    '=',
                    's.job_role_id'
                );
            }

            $selects = [
                's.sno',
                's.staff_id',
                's.staff_name',
                's.company_id',
                's.entity_id',
                's.branch_id',
                's.department_id',
                's.job_role_id',
                's.email_id',
                's.mobile_no',
                'company.company_name',
            ];

            if ($roleTable) {
                $selects[] = DB::raw(
                    'jr.' . $roleTable['name'] . ' as job_role_name'
                );
            } elseif (Schema::hasColumn('egc_staff', 'job_role_name')) {
                $selects[] = 's.job_role_name';
            } else {
                $selects[] = DB::raw('NULL as job_role_name');
            }

            $rows = $query
                ->select($selects)
                ->orderBy('s.staff_name')
                ->orderBy('s.sno')
                ->get();

            $data = $rows->map(function ($staff) {
                return [
                    'id' => $staff->sno,
                    'sno' => $staff->sno,
                    'staff_id' => $staff->staff_id,
                    'staff_name' => $staff->staff_name,
                    'job_role_name' => $staff->job_role_name ?: 'Role not assigned',
                    'company_id' => $staff->company_id,
                    'company_name' => $staff->company_name,
                    'entity_id' => $staff->entity_id,
                    'branch_id' => $staff->branch_id,
                    'department_id' => $staff->department_id,
                    'job_role_id' => $staff->job_role_id,
                    'email_id' => $staff->email_id,
                    'mobile_no' => $staff->mobile_no,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $data,
                'pagination' => [
                    'more' => $rows->count() ,
                ],
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to search Elysium Group staff.',
                'data' => [],
                'pagination' => ['more' => false],
            ], 500);
        }
    }

    /* STAFF SHOW */
    public function staffShow(int $id): JsonResponse
    {
        try {
            $roleTable = $this->resolveStaffJobRoleTable();

            $query = DB::table('egc_staff as s')
                ->leftJoin('egc_company as company', 'company.sno', '=', 's.company_id')
                ->where('s.sno', $id);

            if ($roleTable) {
                $query->leftJoin(
                    $roleTable['table'] . ' as jr',
                    'jr.' . $roleTable['id'],
                    '=',
                    's.job_role_id'
                );
            }

            $selects = [
                's.sno',
                's.staff_id',
                's.staff_name',
                's.company_id',
                's.entity_id',
                's.branch_id',
                's.department_id',
                's.job_role_id',
                's.mobile_no',
                's.email_id',
                's.status',
                'company.company_name',
            ];

            if ($roleTable) {
                $selects[] = DB::raw(
                    'jr.' . $roleTable['name'] . ' as job_role_name'
                );
            } elseif (Schema::hasColumn('egc_staff', 'job_role_name')) {
                $selects[] = 's.job_role_name';
            } else {
                $selects[] = DB::raw('NULL as job_role_name');
            }

            $staff = $query->select($selects)->first();

            if (!$staff) {
                return response()->json([
                    'success' => false,
                    'message' => 'Staff not found.',
                ], 404);
            }

            $currentCug = DB::table($this->cugAssignmentTable . ' as ca')
                ->join($this->cugTable . ' as c', 'c.sno', '=', 'ca.cug_id')
                ->where('ca.staff_id', $staff->sno)
                ->where('ca.is_current', 1)
                ->where('ca.status', 0)
                ->where('c.status', '!=', 2)
                ->select([
                    'c.sno',
                    'c.cug_number',
                ])
                ->first();

            return response()->json([
                'success' => true,
                'data' => [
                    'id' => $staff->sno,
                    'sno' => $staff->sno,
                    'staff_id' => $staff->staff_id,
                    'staff_name' => $staff->staff_name,
                    'job_role_name' => $staff->job_role_name ?: 'Role not assigned',
                    'company_id' => $staff->company_id,
                    'company_name' => $staff->company_name,
                    'entity_id' => $staff->entity_id,
                    'branch_id' => $staff->branch_id,
                    'department_id' => $staff->department_id,
                    'job_role_id' => $staff->job_role_id,
                    'mobile_no' => $staff->mobile_no,
                    'email_id' => $staff->email_id,
                    'status' => $staff->status,
                    'existing_cug_id' => $currentCug->sno ?? null,
                    'existing_cug_number' => $currentCug->cug_number ?? null,
                ],
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load staff details.',
            ], 500);
        }
    }

    /* STATUS LABEL */
    protected function statusLabel($status): string {

        return match (
            (int) $status
        ) {

            0 =>
                'Available',

            1 =>
                'Assigned',

            2 =>
                'Reserved',

            3 =>
                'Inactive',

            default =>
                'Unknown',

        };

    }

    /* ASSIGN */
    public function assign(Request $request): JsonResponse
    {
        $request->merge([
            'assignment_date' => $request->input(
                'assignment_date',
                $request->input('assigned_date')
            ),
        ]);

        $v = $request->validate([
            'cug_id' => ['required', 'integer', 'min:1'],
            'staff_id' => ['required', 'integer', 'min:1'],
            'company_id' => ['required', 'integer', 'min:0'],
            'assignment_date' => ['required', 'date_format:Y-m-d', 'before_or_equal:today'],
            'assignment_type' => ['nullable', 'string', 'max:50'],
            'remarks' => ['nullable', 'string', 'max:500'],
        ]);

        try {
            $result = DB::transaction(function () use ($v,$request) {
                $companyId = $request->company_id;
                $isElysium = $companyId === 0;
                $entity_id = $isElysium  ? 0 : $request->entity_id;
                $branch_id = $isElysium  ? 0 : $request->branch_id;

                if ($isElysium && ((int) $branch_id !== 0 || (int) $branch_id !== 0)) {
                    throw new \RuntimeException( 'Elysium Groups uses Entity 0 and Branch 0.');
                }

                $cug = DB::table($this->cugTable)
                    ->where('sno', $v['cug_id'])
                    ->where('status', '!=', 2)
                    ->lockForUpdate()
                    ->first();

                if (!$cug) {
                    throw new \RuntimeException(
                        'CUG number not found or has been archived.'
                    );
                }

                if ((int) $cug->status !== 0) {
                    throw new \RuntimeException(
                        'This CUG number is not available for assignment.'
                    );
                }

                if (!$isElysium) {
                    $entityValid = DB::table('egc_entity')
                        ->where('sno', $entity_id)
                        ->where('company_id', $companyId)
                        ->where('status', 0)
                        ->exists();
                   
                    // if (!$entityValid) {
                    //     throw new \RuntimeException(
                    //         'The selected entity does not belong to the selected company.'
                    //     );
                    // }

                    $staffBranch = DB::table('egc_staff')
                        ->where('sno', $v['staff_id'])
                        ->value('branch_id');

                    if ((int) $staffBranch !== (int) $branch_id) {
                        throw new \RuntimeException(
                            'The selected staff member does not belong to the selected branch.'
                        );
                    }
                }

                $staff = DB::table('egc_staff')
                    ->where('sno', $v['staff_id'])
                    ->lockForUpdate()
                    ->first();

                if (!$staff) {
                    throw new \RuntimeException('Staff member not found.');
                }

                if ((int) $staff->status !== 0) {
                    throw new \RuntimeException(
                        'The selected staff member is not active.'
                    );
                }

                // return $staff;
                if ((int) $staff->company_id != $companyId) {
                    throw new \RuntimeException(
                        'The selected staff member does not belong to the selected company.'
                    );
                }

                if (!$isElysium) {
                    if ((int) $staff->entity_id !== (int) $entity_id ||
                        (int) $staff->branch_id !== (int) $branch_id) {
                        throw new \RuntimeException(
                            'The selected staff member does not belong to the selected company, entity and branch.'
                        );
                    }
                }

                $existing = DB::table($this->cugAssignmentTable)
                    ->where('staff_id', $staff->sno)
                    ->where('is_current', 1)
                    ->where('status', 0)
                    ->lockForUpdate()
                    ->first();

                // if ($existing) {
                //     throw new \RuntimeException(
                //         'This staff member already has an active CUG number.'
                //     );
                // }

                $assignmentId = DB::table($this->cugAssignmentTable)->insertGetId([
                    'cug_id' => $cug->sno,
                    'staff_id' => $staff->sno,
                    'start_date' => $v['assignment_date'],
                    'end_date' => null,
                    'reason' => $v['assignment_type'] ?? 'NEW',
                    'remarks' => $v['remarks'] ?? null,
                    'is_current' => 1,
                    'status' => 0,
                    'created_by' => auth()->id(),
                    'updated_by' => auth()->id(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                DB::table($this->cugTable)
                    ->where('sno', $cug->sno)
                    ->update([
                        'company_id' => $companyId,
                        'entity_id' => $isElysium ? 0 : (int) $entity_id,
                        'branch_id' => $isElysium ? 0 : (int) $branch_id,
                        'status' => 1,
                        'updated_by' => auth()->id(),
                        'updated_at' => now(),
                    ]);

                DB::table('egc_cug_history')->insert([
                    'cug_id' => $cug->sno,
                    'assignment_id' => $assignmentId,
                    'staff_id' => $staff->sno,
                    'action' => 'ASSIGN',
                    'old_status' => 0,
                    'new_status' => 1,
                    'old_staff_id' => null,
                    'new_staff_id' => $staff->sno,
                    'event_date' => now(),
                    'reason' => $v['assignment_type'] ?? 'NEW',
                    'remarks' => $v['remarks'] ?? null,
                    'created_by' => auth()->id(),
                    'created_at' => now(),
                ]);

                return [
                    'assignment_id' => $assignmentId,
                    'cug_id' => $cug->sno,
                    'staff_id' => $staff->sno,
                    'company_id' => $companyId,
                    'entity_id' => $isElysium ? 0 : (int) $entity_id,
                    'branch_id' => $isElysium ? 0 : (int) $branch_id,
                ];
            });

            return response()->json([
                'success' => true,
                'message' => 'CUG number assigned successfully.',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => $e instanceof \RuntimeException
                    ? $e->getMessage()
                    : 'Unable to assign CUG number.' .$e->getMessage(),
                    'line' => $e->getLine(),
            ], 422);
        }
    }

    /* CHANGE STAFF */
    public function changeStaff(Request $request): JsonResponse
    {
        $request->merge([
            'staff_id' => $request->input(
                'staff_id',
                $request->input('new_staff_id')
            ),
            'transfer_reason' => $request->input(
                'transfer_reason',
                $request->input('reason')
            ),
        ]);

        $v = $request->validate([
            'cug_id' => ['required', 'integer', 'min:1'],
            'staff_id' => ['required', 'integer', 'min:1'],
            'company_id' => ['required', 'integer', 'min:0'],
            'entity_id' => ['required', 'integer', 'min:0'],
            'branch_id' => ['required', 'integer', 'min:0'],
            'effective_date' => ['required', 'date_format:Y-m-d', 'before_or_equal:today'],
            'transfer_reason' => ['required', 'string', 'max:100'],
            'remarks' => ['required', 'string', 'max:500'],
        ]);

        try {
            $result = DB::transaction(function () use ($v) {
                $companyId = (int) $v['company_id'];
                $isElysium = $companyId === 0;

                if ($isElysium && ((int) $v['entity_id'] !== 0 || (int) $v['branch_id'] !== 0)) {
                    throw new \RuntimeException(
                        'Elysium Groups uses Entity 0 and Branch 0.'
                    );
                }

                $cug = DB::table($this->cugTable)
                    ->where('sno', $v['cug_id'])
                    ->where('status', '!=', 2)
                    ->lockForUpdate()
                    ->first();

                if (!$cug) {
                    throw new \RuntimeException(
                        'CUG number not found or has been archived.'
                    );
                }

                $current = DB::table($this->cugAssignmentTable)
                    ->where('cug_id', $cug->sno)
                    ->where('is_current', 1)
                    ->where('status', 0)
                    ->lockForUpdate()
                    ->first();

                if (!$current) {
                    throw new \RuntimeException(
                        'This CUG number has no active staff assignment.'
                    );
                }

                if ((int) $current->staff_id === (int) $v['staff_id']) {
                    throw new \RuntimeException(
                        'The replacement staff member is already the current owner of this CUG number.'
                    );
                }

                if (!$isElysium) {
                    $entityValid = DB::table('egc_entity')
                        ->where('sno', $v['entity_id'])
                        ->where('company_id', $companyId)
                        ->where('status', 0)
                        ->exists();

                    // if (!$entityValid) {
                    //     throw new \RuntimeException(
                    //         'The selected entity does not belong to the selected company.'
                    //     );
                    // }
                }

                $staff = DB::table('egc_staff')
                    ->where('sno', $v['staff_id'])
                    ->lockForUpdate()
                    ->first();

                if (!$staff) {
                    throw new \RuntimeException(
                        'Replacement staff member not found.'
                    );
                }

                if ((int) $staff->status !== 0) {
                    throw new \RuntimeException(
                        'The replacement staff member is not active.'
                    );
                }

                if ((int) $staff->company_id !== $companyId) {
                    throw new \RuntimeException(
                        'The replacement staff member does not belong to the selected company.'
                    );
                }

                if (!$isElysium &&
                    ((int) $staff->entity_id !== (int) $v['entity_id'] ||
                     (int) $staff->branch_id !== (int) $v['branch_id'])) {
                    throw new \RuntimeException(
                        'The replacement staff member does not belong to the selected company, entity and branch.'
                    );
                }

                $existing = DB::table($this->cugAssignmentTable)
                    ->where('staff_id', $staff->sno)
                    ->where('is_current', 1)
                    ->where('status', 0)
                    ->where('sno', '!=', $current->sno)
                    ->lockForUpdate()
                    ->first();

                // if ($existing) {
                //     throw new \RuntimeException(
                //         'The replacement staff member already has an active CUG number.'
                //     );
                // }

                DB::table($this->cugAssignmentTable)
                    ->where('sno', $current->sno)
                    ->update([
                        'end_date' => $v['effective_date'],
                        'is_current' => 0,
                        'status' => 1,
                        'updated_by' => auth()->id(),
                        'updated_at' => now(),
                    ]);

                $newId = DB::table($this->cugAssignmentTable)->insertGetId([
                    'cug_id' => $cug->sno,
                    'staff_id' => $staff->sno,
                    'start_date' => $v['effective_date'],
                    'end_date' => null,
                    'reason' => $v['transfer_reason'],
                    'remarks' => $v['remarks'],
                    'is_current' => 1,
                    'status' => 0,
                    'created_by' => auth()->id(),
                    'updated_by' => auth()->id(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                DB::table('egc_cug_history')->insert([
                    'cug_id' => $cug->sno,
                    'assignment_id' => $newId,
                    'staff_id' => $staff->sno,
                    'action' => 'CHANGE_STAFF',
                    'old_status' => 1,
                    'new_status' => 1,
                    'old_staff_id' => $current->staff_id,
                    'new_staff_id' => $staff->sno,
                    'event_date' => now(),
                    'reason' => $v['transfer_reason'],
                    'remarks' => $v['remarks'],
                    'created_by' => auth()->id(),
                    'created_at' => now(),
                ]);

                DB::table($this->cugTable)
                    ->where('sno', $cug->sno)
                    ->update([
                        'company_id' => $companyId,
                        'entity_id' => $isElysium ? 0 : (int) $v['entity_id'],
                        'branch_id' => $isElysium ? 0 : (int) $v['branch_id'],
                        'status' => 1,
                        'updated_by' => auth()->id(),
                        'updated_at' => now(),
                    ]);

                return [
                    'cug_id' => $cug->sno,
                    'old_staff_id' => $current->staff_id,
                    'new_staff_id' => $staff->sno,
                    'assignment_id' => $newId,
                ];
            });

            return response()->json([
                'success' => true,
                'message' => 'CUG staff changed successfully.',
                'data' => $result,
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => $e instanceof \RuntimeException
                    ? $e->getMessage()
                    : 'Unable to change CUG staff.',
            ], 422);
        }
    }

    /* RELEASE */
    public function release(Request $request,int $id): JsonResponse {
        try {
            DB::transaction(
                function () use (
                    $id
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | Lock CUG
                    |--------------------------------------------------------------------------
                    */

                    $cug = DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->lockForUpdate()
                    ->first();


                    if (!$cug) {

                        throw new \RuntimeException(
                            'CUG number not found.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Current assignment
                    |--------------------------------------------------------------------------
                    */

                    $assignment =
                        DB::table(
                            $this->cugAssignmentTable
                        )
                        ->where(
                            'cug_id',
                            $id
                        )
                        ->where(
                            'is_current',
                            1
                        )
                        ->where(
                            'status',
                            0
                        )
                        ->lockForUpdate()
                        ->first();


                    if (!$assignment) {

                        throw new \RuntimeException(
                            'This CUG number is not currently assigned.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Close assignment
                    |--------------------------------------------------------------------------
                    */

                    DB::table(
                        $this->cugAssignmentTable
                    )
                    ->where(
                        'sno',
                        $assignment->sno
                    )
                    ->update([

                        'end_date' =>
                            now()->toDateString(),

                        'is_current' =>
                            0,

                        'status' =>
                            1,

                        'updated_by' =>
                            auth()->id(),

                        'updated_at' =>
                            now(),

                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | CUG becomes available
                    |--------------------------------------------------------------------------
                    */

                    DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->update([

                        'status' =>
                            0,

                        'updated_by' =>
                            auth()->id(),

                        'updated_at' =>
                            now(),

                    ]);

                    DB::table('egc_cug_history')->insert(['cug_id'=>$id,'assignment_id'=>$assignment->sno,'staff_id'=>$assignment->staff_id,'action'=>'RELEASE','old_status'=>1,'new_status'=>0,'old_staff_id'=>$assignment->staff_id,'new_staff_id'=>null,'event_date'=>now(),'reason'=>null,'remarks'=>null,'created_by'=>auth()->id(),'created_at'=>now()]);

                }
            );


            return response()->json([

                'success' =>
                    true,

                'message' =>
                    'CUG number released successfully.',

            ]);


        } catch (
            \Throwable $e
        ) {

            report($e);

            return response()->json([

                'success' =>
                    false,

                'message' =>
                    $e instanceof \RuntimeException
                        ? $e->getMessage()
                        : 'Unable to release CUG number.',

            ], 422);

        }

    }

    /* DEACTIVATE */
    public function deactivate( Request $request,int $id ): JsonResponse {

        try {

            DB::transaction(
                function () use (
                    $id
                ) {

                    $cug = DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->lockForUpdate()
                    ->first();


                    if (!$cug) {

                        throw new \RuntimeException(
                            'CUG number not found.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Cannot deactivate assigned number
                    |--------------------------------------------------------------------------
                    */

                    $activeAssignment =
                        DB::table(
                            $this->cugAssignmentTable
                        )
                        ->where(
                            'cug_id',
                            $id
                        )
                        ->where(
                            'is_current',
                            1
                        )
                        ->where(
                            'status',
                            0
                        )
                        ->exists();


                    if (
                        $activeAssignment
                    ) {

                        throw new \RuntimeException(
                            'Release the current staff assignment before deactivating this CUG number.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Deactivate
                    |--------------------------------------------------------------------------
                    */

                    DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->update([

                        'status' =>
                            3,

                        'updated_by' =>
                            auth()->id(),

                        'updated_at' =>
                            now(),

                    ]);

                    DB::table('egc_cug_history')->insert(['cug_id'=>$id,'assignment_id'=>null,'staff_id'=>null,'action'=>'DEACTIVATE','old_status'=>(int)$cug->status,'new_status'=>3,'old_staff_id'=>null,'new_staff_id'=>null,'event_date'=>now(),'reason'=>null,'remarks'=>null,'created_by'=>auth()->id(),'created_at'=>now()]);

                }
            );


            return response()->json([

                'success' =>
                    true,

                'message' =>
                    'CUG number deactivated successfully.',

            ]);


        } catch (
            \Throwable $e
        ) {

            report($e);

            return response()->json([

                'success' =>
                    false,

                'message' =>
                    $e instanceof \RuntimeException
                        ? $e->getMessage()
                        : 'Unable to deactivate CUG number.',

            ], 422);

        }

    }

    /* DELETE */
    public function destroy( Request $request,int $id): JsonResponse {

        try {

            DB::transaction(
                function () use (
                    $id
                ) {

                    $cug = DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->lockForUpdate()
                    ->first();


                    if (!$cug) {

                        throw new \RuntimeException(
                            'CUG number not found.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Cannot delete active assignment
                    |--------------------------------------------------------------------------
                    */

                    $activeAssignment =
                        DB::table(
                            $this->cugAssignmentTable
                        )
                        ->where(
                            'cug_id',
                            $id
                        )
                        ->where(
                            'is_current',
                            1
                        )
                        ->where(
                            'status',
                            0
                        )
                        ->exists();


                    if (
                        $activeAssignment
                    ) {

                        throw new \RuntimeException(
                            'Release the current staff assignment before deleting this CUG number.'
                        );

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Business delete
                    |--------------------------------------------------------------------------
                    */

                    DB::table(
                        $this->cugTable
                    )
                    ->where(
                        'sno',
                        $id
                    )
                    ->update([

                        'status' =>
                            2,

                        'updated_by' =>
                            auth()->id(),

                        'updated_at' =>
                            now(),

                    ]);

                    DB::table('egc_cug_history')->insert(['cug_id'=>$id,'assignment_id'=>null,'staff_id'=>null,'action'=>'DELETE','old_status'=>(int)$cug->status,'new_status'=>2,'old_staff_id'=>null,'new_staff_id'=>null,'event_date'=>now(),'reason'=>null,'remarks'=>null,'created_by'=>auth()->id(),'created_at'=>now()]);

                }
            );


            return response()->json([

                'success' =>
                    true,

                'message' =>
                    'CUG number deleted successfully.',

            ]);


        } catch (
            \Throwable $e
        ) {

            report($e);

            return response()->json([

                'success' =>
                    false,

                'message' =>
                    $e instanceof \RuntimeException
                        ? $e->getMessage()
                        : 'Unable to delete CUG number.',

            ], 422);

        }

    }

    /* ASSIGNMENT HISTORY*/
    public function assignmentHistory(int $id): JsonResponse {

        try {

            /*
            |--------------------------------------------------------------------------
            | Verify CUG
            |--------------------------------------------------------------------------
            */

            $cugExists = DB::table(
                $this->cugTable
            )
            ->where(
                'sno',
                $id
            )
            ->exists();


            if (!$cugExists) {

                return response()->json([

                    'success' => false,

                    'message' => 'CUG number not found.',

                ], 404);

            }


            /*
            |--------------------------------------------------------------------------
            | Assignment history
            |--------------------------------------------------------------------------
            */

            $rows = DB::table(
                $this->cugAssignmentTable . ' as ca'
            )

            ->leftJoin(
                'egc_staff as s',
                's.sno',
                '=',
                'ca.staff_id'
            )

            ->where(
                'ca.cug_id',
                $id
            )

            ->select([

                'ca.sno',

                'ca.cug_id',

                'ca.staff_id',

                'ca.start_date',

                'ca.end_date',

                'ca.reason',

                'ca.remarks',

                'ca.is_current',

                'ca.status',

                'ca.created_by',

                'ca.created_at',

                'ca.updated_at',

                's.staff_id as staff_code',

                's.staff_name',

                's.department_id',

                's.job_role_id',

            ])

            ->orderByDesc(
                'ca.start_date'
            )

            ->orderByDesc(
                'ca.sno'
            )

            ->get();


            /*
            |--------------------------------------------------------------------------
            | Response transformation
            |--------------------------------------------------------------------------
            */

            $history = $rows->map(
                function ($row) {

                    return [

                        'id' =>
                            $row->sno,

                        'assignment_id' =>
                            $row->sno,

                        'cug_id' =>
                            $row->cug_id,

                        'staff_id' =>
                            $row->staff_id,

                        'staff_code' =>
                            $row->staff_code,

                        'staff_name' =>
                            $row->staff_name
                                ?? 'Unassigned',

                        'department_id' =>
                            $row->department_id,

                        'job_role_id' =>
                            $row->job_role_id,

                        'start_date' =>
                            $row->start_date,

                        'end_date' =>
                            $row->end_date,

                        'reason' =>
                            $row->reason,

                        'transfer_reason' =>
                            $row->reason,

                        'remarks' =>
                            $row->remarks,

                        'is_current' =>
                            (bool) $row->is_current,

                        'status' =>
                            $row->status,

                        'created_by' =>
                            $row->created_by,

                        'created_at' =>
                            $row->created_at,

                        'updated_at' =>
                            $row->updated_at,

                    ];

                }
            )->values();


            return response()->json([

                'success' => true,

                'data' => [

                    'assignments' =>
                        $history,

                    'history' =>
                        $history,

                    'total' =>
                        $history->count(),

                ],

            ]);


        } catch (\Throwable $e) {

            report($e);

            return response()->json([

                'success' => false,

                'message' =>
                    'Unable to load assignment history.',

            ], 500);

        }

    }

    /* CALL HISTORY */
    public function callHistory(Request $request, int $id): JsonResponse
    {
        $v=$request->validate(['page'=>['nullable','integer','min:1'],'per_page'=>['nullable','integer','min:1','max:100'],'from'=>['nullable','date_format:Y-m-d'],'to'=>['nullable','date_format:Y-m-d','after_or_equal:from']]);
        try {
            if(!DB::table($this->cugTable)->where('sno',$id)->exists()) return response()->json(['success'=>false,'message'=>'CUG number not found.'],404);
            $page=(int)($v['page']??1); $per=(int)($v['per_page']??25);
            $q=DB::table($this->cugCallLogTable.' as cl')
                ->leftJoin($this->cugAssignmentTable.' as ca','ca.sno','=','cl.cug_assignment_id')
                ->leftJoin('egc_staff as s',function($join){$join->on('s.sno','=',DB::raw('COALESCE(ca.staff_id, cl.branch_staff_id)'));})
                ->where('cl.cug_id',$id);
            if(!empty($v['from'])) $q->whereDate('cl.call_start_date','>=',$v['from']);
            if(!empty($v['to'])) $q->whereDate('cl.call_start_date','<=',$v['to']);
            $calls=$q->orderByDesc('cl.call_start_date')->orderByDesc('cl.call_start_time')->select([
                'cl.sno','cl.cug_id','cl.cug_assignment_id','cl.branch_staff_id','cl.customer_phone_no','cl.call_start_date','cl.call_start_time','cl.call_duration','cl.call_status','cl.created_at','s.staff_name','s.staff_id as staff_code'
            ])->paginate($per,['*'],'page',$page);
            $types=[0=>'OUTGOING',1=>'INCOMING',2=>'MISSED',3=>'REJECTED',4=>'OUTGOING'];
            $statuses=[0=>'ANSWERED',1=>'ANSWERED',2=>'MISSED',3=>'REJECTED',4=>'ANSWERED'];
            $records=collect($calls->items())->map(function($row) use($types,$statuses){
                $dt=$row->call_start_date.' '.$row->call_start_time; $type=$types[(int)$row->call_status]??'UNKNOWN';
                return ['id'=>$row->sno,'cug_id'=>$row->cug_id,'cug_assignment_id'=>$row->cug_assignment_id,'staff_id'=>$row->branch_staff_id,'staff_name'=>$row->staff_name??'—','staff_code'=>$row->staff_code??'—','call_datetime'=>$dt,'datetime'=>$dt,'call_type'=>$type,'type'=>$type,'caller_number'=>$row->customer_phone_no,'phone_number'=>$row->customer_phone_no,'duration'=>$row->call_duration,'status'=>$statuses[(int)$row->call_status]??'UNKNOWN','created_at'=>$row->created_at];
            })->values();
            return response()->json(['success'=>true,'data'=>['records'=>$records,'data'=>$records,'total'=>$calls->total(),'current_page'=>$calls->currentPage(),'last_page'=>$calls->lastPage(),'per_page'=>$calls->perPage(),'from'=>$calls->firstItem(),'to'=>$calls->lastItem()]]);
        } catch(\Throwable $e){ report($e); return response()->json(['success'=>false,'message'=>'Unable to load CUG call history.'],500); }
    }

    public function store(Request $request): JsonResponse
    {
        $v=$request->validate(['cug_number'=>['required','string','max:30'],'cug_code'=>['nullable','string','max:50'],'provider'=>['nullable','string','max:100'],'status'=>['nullable','integer','in:0'],'remarks'=>['nullable','string','max:500']]);
        $v['cug_number']=trim($v['cug_number']);
        try{ $id=DB::transaction(function() use($v){
            if(DB::table($this->cugTable)->where('cug_number',$v['cug_number'])->lockForUpdate()->exists()) throw new \RuntimeException('CUG number already exists.');
            $id=DB::table($this->cugTable)->insertGetId(['cug_number'=>$v['cug_number'],'cug_code'=>$v['cug_code']??null,'provider'=>$v['provider']??null,'company_id'=>null,'entity_id'=>null,'branch_id'=>null,'status'=>0,'remarks'=>$v['remarks']??null,'created_by'=>auth()->id(),'updated_by'=>auth()->id(),'created_at'=>now(),'updated_at'=>now()]);
            DB::table('egc_cug_history')->insert(['cug_id'=>$id,'assignment_id'=>null,'staff_id'=>null,'action'=>'CREATE','old_status'=>null,'new_status'=>0,'old_staff_id'=>null,'new_staff_id'=>null,'event_date'=>now(),'reason'=>null,'remarks'=>$v['remarks']??null,'created_by'=>auth()->id(),'created_at'=>now()]);
            return $id; });
            return response()->json(['success'=>true,'message'=>'CUG number created successfully.','data'=>['id'=>$id]]);
        }catch(\Throwable $e){report($e);return response()->json(['success'=>false,'message'=>$e instanceof \RuntimeException?$e->getMessage():'Unable to create CUG number.'],422);}
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $v=$request->validate(['cug_number'=>['required','string','max:30'],'cug_code'=>['nullable','string','max:50'],'provider'=>['nullable','string','max:100'],'status'=>['required','integer','in:0,1,3'],'remarks'=>['nullable','string','max:500']]);
        $v['cug_number']=trim($v['cug_number']);
        try{ DB::transaction(function() use($v,$id){
            $cug=DB::table($this->cugTable)->where('sno',$id)->lockForUpdate()->first(); if(!$cug || (int)$cug->status===2) throw new \RuntimeException('CUG number not found.');
            if(DB::table($this->cugTable)->where('cug_number',$v['cug_number'])->where('sno','!=',$id)->lockForUpdate()->exists()) throw new \RuntimeException('Another CUG record already uses this number.');
            $active=DB::table($this->cugAssignmentTable)->where('cug_id',$id)->where('is_current',1)->where('status',0)->exists();
            if($active && (int)$v['status']!==1) throw new \RuntimeException('An assigned CUG must remain in Assigned status until its staff assignment is released.');
            if(!$active && (int)$v['status']===1) throw new \RuntimeException('A CUG without an active staff assignment cannot be marked Assigned.');
            DB::table($this->cugTable)->where('sno',$id)->update(['cug_number'=>$v['cug_number'],'cug_code'=>$v['cug_code']??null,'provider'=>$v['provider']??null,'status'=>(int)$v['status'],'remarks'=>$v['remarks']??null,'updated_by'=>auth()->id(),'updated_at'=>now()]);
            if((string)$cug->cug_number!==$v['cug_number'] || (string)$cug->cug_code!==(string)($v['cug_code']??null) || (string)$cug->provider!==(string)($v['provider']??null) || (int)$cug->status!==(int)$v['status'] || (string)$cug->remarks!==(string)($v['remarks']??null)){
                DB::table('egc_cug_history')->insert(['cug_id'=>$id,'assignment_id'=>null,'staff_id'=>null,'action'=>'UPDATE','old_status'=>(int)$cug->status,'new_status'=>(int)$v['status'],'old_staff_id'=>null,'new_staff_id'=>null,'event_date'=>now(),'reason'=>null,'remarks'=>$v['remarks']??null,'created_by'=>auth()->id(),'created_at'=>now()]);
            }
        }); return response()->json(['success'=>true,'message'=>'CUG number updated successfully.']);
        }catch(\Throwable $e){report($e);return response()->json(['success'=>false,'message'=>$e instanceof \RuntimeException?$e->getMessage():'Unable to update CUG number.'],422);}
    }

    /* RECENT CUG ACTIVITY */
    public function recentActivity(Request $request): JsonResponse
    {
        try {
            $limit = min(
                max((int) $request->input('limit', 6), 1),
                20
            );

            $rows = DB::table('egc_cug_history as h')
                ->leftJoin($this->cugTable . ' as c', 'c.sno', '=', 'h.cug_id')
                ->leftJoin('egc_staff as s', 's.sno', '=', 'h.new_staff_id')
                ->leftJoin('egc_staff as old_s', 'old_s.sno', '=', 'h.old_staff_id')
                ->where('c.status', '!=', 2)
                ->select([
                    'h.sno',
                    'h.cug_id',
                    'h.action',
                    'h.reason',
                    'h.remarks',
                    'h.event_date',
                    'h.new_staff_id',
                    'h.old_staff_id',
                    'c.cug_number',
                    'c.provider',
                    's.staff_name as new_staff_name',
                    'old_s.staff_name as old_staff_name',
                ])
                ->orderByDesc('h.event_date')
                ->orderByDesc('h.sno')
                ->limit($limit)
                ->get()
                ->map(function ($row) {
                    return [
                        'id' => $row->sno,
                        'cug_id' => $row->cug_id,
                        'cug_number' => $row->cug_number,
                        'provider' => $row->provider,
                        'action' => $row->action,
                        'reason' => $row->reason,
                        'remarks' => $row->remarks,
                        'event_date' => $row->event_date,
                        'new_staff_name' => $row->new_staff_name,
                        'old_staff_name' => $row->old_staff_name,
                    ];
                })
                ->values();

            return response()->json([
                'success' => true,
                'data' => $rows,
            ]);
        } catch (\Throwable $e) {
            report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load recent CUG activity.',
                'data' => [],
            ], 500);
        }
    }

    public function dashboard(Request $request): JsonResponse
    {
        try {
            $base = DB::table($this->cugTable . ' as c')
                ->where('c.status', '!=', 2);

            if ($request->filled('search')) {
                $search = trim((string) $request->input('search'));

                $base->where(function ($q) use ($search) {
                    $q->where('c.cug_number', 'like', "%{$search}%")
                        ->orWhere('c.cug_code', 'like', "%{$search}%")
                        ->orWhere('c.provider', 'like', "%{$search}%");
                });
            }

            if ($request->filled('company_id')) {
                $base->where('c.company_id', $request->company_id);
            }

            if ($request->filled('entity_id')) {
                $base->where('c.entity_id', $request->entity_id);
            }

            if ($request->filled('branch_id')) {
                $base->where('c.branch_id', $request->branch_id);
            }

            if ($request->filled('status')) {
                $base->where('c.status', $request->status);
            }

            $total = (clone $base)->count('c.sno');

            $assigned = (clone $base)
                ->where('c.status', 1)
                ->count('c.sno');

            $available = (clone $base)
                ->where('c.status', 0)
                ->count('c.sno');

            $inactive = (clone $base)
                ->where('c.status', 3)
                ->count('c.sno');

            $utilization = $total > 0
                ? round(($assigned / $total) * 100, 2)
                : 0;

            $todayCalls = DB::table($this->cugCallLogTable)
                ->whereDate('call_start_date', now()->toDateString())
                ->count();

            $receivedCalls = DB::table($this->cugCallLogTable)
                ->whereDate('call_start_date', now()->toDateString())
                ->where('call_status', 1)
                ->count();

            $dialledCalls = DB::table($this->cugCallLogTable)
                ->whereDate('call_start_date', now()->toDateString())
                ->whereIn('call_status', [0,4])
                ->count();

            $missedCalls = DB::table($this->cugCallLogTable)
                ->whereDate('call_start_date', now()->toDateString())
                ->where('call_status', 2)
                ->count();

            return response()->json([
                'success' => true,

                'data' => [
                    'total_count' => $total,
                    'assigned_count' => $assigned,
                    'available_count' => $available,
                    'inactive_count' => $inactive,

                    'utilization' => $utilization,

                    'today_calls' => $todayCalls,
                    'received_calls' => $receivedCalls,
                    'dialled_calls' => $dialledCalls,
                    'missed_calls' => $missedCalls,

                    'pool' => [
                        'available' => $available,
                        'assigned' => $assigned,
                        'reserved' => 0,
                        'inactive' => $inactive,
                    ],
                ],
            ]);

        } catch (\Throwable $e) {

            // report($e);

            return response()->json([
                'success' => false,
                'message' => 'Unable to load CUG dashboard.',
                'err' => $e->getMessage(),
                'data' => [],
            ], 500);
        }
    }

}