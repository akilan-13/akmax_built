<?php

namespace App\Http\Controllers\settings\business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use App\Models\DivisionModel;
use App\Models\CompanyModel;
use App\Models\JobRoleModel;
use App\Models\ManageEntityModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class BusinessDivision extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      
    $Division = DivisionModel::where('egc_division.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_division.*','egc_department.department_name','egc_entity.entity_name','egc_company.company_name','egc_entity.entity_short_name', 'egc_company.company_base_color')
      ->join('egc_company', 'egc_division.company_id', 'egc_company.sno')
      ->join('egc_entity', 'egc_division.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_division.department_id', 'egc_department.sno');

      
       if ($search_filter != '') {
            $Division->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_desc', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%");
            });
        }

        $Division=$Division->orderBy('egc_division.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Division->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'division_name' => $item->division_name,
                    'department_name' => $item->department_name,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'entity_short_name' => $item->entity_short_name,
                    'company_base_color' => $item->company_base_color,
                    'department_id' => $item->department_id,
                    'division_desc' => $item->division_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Division->currentPage(),
                'last_page' => $Division->lastPage(),
                'total' => $Division->total(),
            ]);
        }
      $Department = DepartmentModel::where('egc_department.status',  0)->orderBy('sno', 'asc')
            ->where('egc_department.company_type',2)->get();

    // return $Department;
      $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.settings.business.division.division_list', [
      'ListTable' => $Division,
      'Department' => $Department,
      'perpage' => $perpage,
      'company_list' => $company_list,
      'search_filter' => $search_filter
    ]);
  }
  public function BuisenessIndex()
  {
    $Division = DivisionModel::where('egc_division.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_division.*', 'egc_entity.entity_name as entityname', 'egc_branch.branch_name', 'egc_branch.franchise_name', 'egc_branch.branch_type', 'egc_department.department_name as deptname')
      ->leftJoin('egc_entity', 'egc_division.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'egc_division.branch_id', 'egc_branch.sno')
      ->leftJoin('egc_department', 'egc_division.department_id', 'egc_department.sno')
      ->orderBy('egc_division.sno', 'desc')->get();
    // return $Department;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.management.division.division_list', [
      'ListTable' => $Division,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function Status($id, Request $request)
  {

    $staff =  DivisionModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DivisionModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function DepartDivisionList(Request $request)
  {

    $department_id = $request->department_id;
    $Department = DivisionModel::where('status', '!=', 2)->where('department_id', $department_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function JobPostionList(Request $request)
  {
    
    $division_id = $request->division_id;

    $startTime = microtime(true);
    $job_position = JobRoleModel::where('division_id', $division_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'department_id' => 'required',
      'division_name' => 'required_if:erp_division_name,new_division'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $company_id = $request->company_id;
      $entity_id = $request->entity_id;
      $department_id = $request->department_id;
      $erp_department_id = $request->erp_department_id;
      // If user selected "other", take manual input
      if ($request->erp_division_name == 'new_division') {
          $division_name = $request->division_name;
          $erp_division_id = $request->erp_division_id;
      }
      else {
          $division_name = $request->division_name_hidden;
          $erp_division_id = $request->erp_division_name; // sno from ERP
      }
    
      $Desc = $request->division_desc;
      $branch_id = $request->branchId;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', $division_name)->where('company_type', 2)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = new DivisionModel();
        $add_division->company_type = 2;
        $add_division->company_id = $company_id;
        $add_division->entity_id = $entity_id;
        $add_division->branch_id = 0;
        $add_division->division_name = $division_name;
        $add_division->department_id = $department_id;
        $add_division->erp_division_id = $erp_division_id;
        $add_division->erp_department_id = $erp_department_id;
        $add_division->division_desc = $Desc;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
           if($request->erp_division_name == 'new_division'){
              $this->dispatchWebhooks($add_division, $user_id,'Division_Hook');
          }else{
              $this->dispatchWebhooks($add_division, $user_id=1,'Update_Division_uuid');
          }
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function Edit($id)
  {
    $data = DivisionModel::where('sno', $id)->first();
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Division not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Division fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'department_id' => 'required',
      'division_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $department_id = $request->department_id;
      $division_name = $request->division_name;
      $sno = $request->edit_id;
      $Desc = $request->division_desc;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', $division_name)->where('company_type', 2)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = DivisionModel::where('sno', $sno)->first();
        $add_division->division_name = $division_name;
        $add_division->department_id = $department_id;
        $add_division->division_desc = $Desc;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  // webhook Send
  protected function dispatchWebhooks(DivisionModel $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast->entity_id)->first();
        if($webhook){
            $dispatch = WebhookDispatchModel::create([
                'sub_erp_webhook_sno' => $webhook->sno,
                'dispatchable_type' => get_class($broadcast),
                'dispatchable_id' => $broadcast->sno,
                'message_uuid' => $broadcast->sno,
                'payload' => $broadcast->toArray(),
                'status' => 0,
                'attempts' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            // enqueue the job
           
            try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                if (!$result['success']) {
                    // If fails, dispatch to queue
                    SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
          
     
  }

    public function AddOldData(Request $request)
    {

      // return $request;
      // Validate incoming request
      $helper = new \App\Helpers\Helpers();
      $validator = Validator::make($request->all(), [
        'staff_company_name' => 'required',
        'staff_entity_name' => 'required',
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id ?? 1;
      
      $company_type=2;
      $company_id=$request->staff_company_name;
      $entity_id=$request->staff_entity_name;

      $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

        if (!$entity_url) {
            return response()->json([
                'status'  => 404,
                'message' => 'Entity URL not found for the given entity ID.',
            ], 200);
        }

        // 🧩 Step 3: Call external API using Http facade
        $verify_key = 'egcsecret2030datagetapierp';
        $api_url = rtrim($entity_url, '/') . '/api/division_data_get';

        try {
            $response = Http::get($api_url, ['auth_key' => $verify_key]);

            if (!$response->successful()) {
                return response()->json([
                    'status'  => 500,
                    'message' => 'Failed to fetch Data from entity API.',
                    'error'   => $response->body(),
                ], 200);
            }

            $ErpData = $response->json()['data'] ?? [];
            $filteredErpData = array_filter($ErpData, function($staff) {
                return $staff['external_uuid'] == null;
            });
            $filteredErpData = array_values($filteredErpData);

            // return $filteredErpData;


            if (empty($ErpData)) {
                return response()->json([
                    'status'  => 404,
                    'message' => 'No user roles found in API response.',
                ], 200);
            }

            // 🧩 Step 4: Loop and insert roles
            foreach ($ErpData as $staff) {

                $division_name = $staff['division_name'] ?? null;
                if (!$division_name) continue;

                $erp_division_id = $staff['sno'] ?? null;
                if (!$erp_division_id) continue;

                $erp_department_id = $staff['department_id'] ?? null;
                if (!$erp_department_id) continue;

                $department_id = $helper->get_sno_by_erpId($erp_department_id, 'egc_department', 'erp_department_id',$entity_id);
                $department_id = $department_id ?? 0;

                $company_type = 2;

                // 🔍 Check if role already exists
                $chk = DivisionModel::where('erp_division_id', $erp_division_id)
                    ->where('entity_id',$entity_id)
                    ->where('status', '!=', 2)
                    ->first();

                if ($chk){
                    $chk->division_name=$division_name;
                    $chk->department_id=$department_id;
                    $chk->update();
                    $this->dispatchWebhooks($chk, $user_id=1,'Update_Division_uuid');
                    continue; 
                }else{

                     
                      $user_id = $request->user()->user_id;

                      $add_division = new DivisionModel();
                      $add_division->company_type = 2;
                      $add_division->company_id = $company_id;
                      $add_division->entity_id = $entity_id;
                      $add_division->branch_id = 0;
                      $add_division->division_name = $division_name;
                      $add_division->department_id = $department_id;
                      $add_division->erp_division_id = $erp_division_id;
                      $add_division->erp_department_id = $erp_department_id;
                      $add_division->created_by = $user_id;
                      $add_division->updated_by = $user_id;

                    $add_division->save();

                  

                    if ($add_division) {
                      $this->dispatchWebhooks($add_division, $user_id=1,'Update_Division_uuid');
                    }
                }
            }

            return response()->json([
                'status'  => 200,
                'message' => 'Business Division imported successfully.',
            ]);

        } catch (\Throwable $e) {
            // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
            return response()->json([
                'status'  => 500,
                'message' => 'Something went wrong while fetching Division.',
                'error'   => $e->getMessage(),
            ], 200);
        }
    }

    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }



}