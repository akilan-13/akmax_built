<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PayslipTemplateModel;
use App\Models\CompanyModel;
use Illuminate\Support\Facades\Validator;

class PayslipTemplate extends Controller
{
    public function index(Request $request)
    {
        // return "sfjhgjh";
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PayslipTemplateModel::where( 'egc_payslip_template.status', '!=', 2 )->leftJoin('egc_company','egc_payslip_template.company_id','=','egc_company.sno')->select('egc_company.company_name','egc_payslip_template.*');
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'egc_payslip_template.sno', 'desc' )->paginate($perpage);

        $company_list = CompanyModel::where('status',0)->orderBy('sno','asc')->get();

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                $general_setting=$helper->general_setting_data();
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'company_name' => $item->company_name ?? $general_setting->title,
                    'company_id' => $item->company_id,
                    'payslip_template' => $item->payslip_template,
                    'letter_head_image' => $item->letter_head_image,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.payroll.payslip_template.payslip_template',[
            'Document' => $Document,
            'perpage' => $perpage,
            'company_list' => $company_list,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = PayslipTemplateModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {
        // return $request;
        $validator = Validator::make( $request->all(), [
            'company_id' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $company_id       = $request->company_id;
                

            $user_id = $request->user()->user_id ?? 1;
            $chk = PayslipTemplateModel::where( 'company_id', $company_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Payslip Template is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = PayslipTemplateModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                

                $add_branchtype = new PayslipTemplateModel();
                $add_branchtype->company_id       = $company_id;
                if ($request->hasFile('payslip_template_img')) {
                    $file = $request->file('payslip_template_img');
                    $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('settings/payslip_template/'), $fileName);
                    $add_branchtype->payslip_template = $fileName;
                }
                if ($request->hasFile('letter_head_img')) {
                    $file = $request->file('letter_head_img');
                    $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('settings/letter_head/'), $fileName);
                    $add_branchtype->letter_head_image = $fileName;
                }
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Payslip Template added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Payslip Template!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


        public function Update(Request $request)
    {

        // return $request;
        $validator = Validator::make($request->all(), [
            'edit_id'   => 'required|exists:egc_payslip_template,sno',
            'company_id'=> 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $user_id = $request->user()->user_id ?? 1;

        $data = PayslipTemplateModel::find($request->edit_id);

        if (!$data) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Record not found!'
            ]);
            return redirect()->back();
        }

        // ✅ Check duplicate (excluding current record)
        $chk = PayslipTemplateModel::where('company_id', $request->company_id)
            ->where('sno', '!=', $request->edit_id)
            ->where('status', '!=', 2)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Payslip Template exists!'
            ]);
            return redirect()->back();
        }

        // ✅ Update fields
        $data->company_id = $request->company_id;

        // ✅ Image Upload Handling
        if ($request->hasFile('payslip_template_img')) {

            // 🔥 Delete old image (if exists)
            if ($data->payslip_template && file_exists(public_path('settings/payslip_template/' . $data->payslip_template))) {
                unlink(public_path('settings/payslip_template/' . $data->payslip_template));
            }

            $file = $request->file('payslip_template_img');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('settings/payslip_template/'), $fileName);

            $data->payslip_template = $fileName;
        }
        if ($request->hasFile('letter_head_img')) {

            // 🔥 Delete old image (if exists)
            if ($data->letter_head_image && file_exists(public_path('settings/letter_head/' . $data->letter_head_image))) {
                unlink(public_path('settings/letter_head/' . $data->letter_head_image));
            }

            $file = $request->file('letter_head_img');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();

            $file->move(public_path('settings/letter_head/'), $fileName);

            $data->letter_head_image = $fileName;
        }

        $data->updated_by = $user_id;
        $data->save();

        if ($data) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Payslip Template updated successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Payslip Template!'
            ]);
        }

        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_PayslipTemplateModel = PayslipTemplateModel::where( 'sno', $id )->first();
        $upd_PayslipTemplateModel->status  = 2;
        $upd_PayslipTemplateModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Payroll Setting Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_PayslipTemplateModel =  PayslipTemplateModel::where( 'sno', $id )->first();
        $upd_PayslipTemplateModel->status = $request->input( 'status', 0 );
        $upd_PayslipTemplateModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
