<?php

namespace App\Http\Controllers\settings\payroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewPayrollComponentModel;
use App\Models\PayrollComponentModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class NewPayrollComponent extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = NewPayrollComponentModel::where('status', '!=', 2);
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {

                $subquery->where('component_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('component_code', 'LIKE', "%{$search_filter}%")
                    ->orWhere('category', 'LIKE', "%{$search_filter}%")
                    ->orWhere('calculation_type', 'LIKE', "%{$search_filter}%");
            });
        }
        $Document = $Document->orderBy('sno', 'desc')->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'component_code' => $item->component_code,
                    'component_name' => $item->component_name,
                    'category' => $item->category,
                    'calculation_type' => $item->calculation_type,
                    'percentage_of_component' => $item->percentage_of_component,
                    'percentage_value' => $item->percentage_value,
                    'formula_expression' => $item->formula_expression,
                    'rule_id' => $item->rule_id,
                    'affects_pf' => $item->affects_pf,
                    'affects_esi' => $item->affects_esi,
                    'affects_pt' => $item->affects_pt,
                    'affects_tds' => $item->affects_tds,
                    'taxable' => $item->taxable,
                    'lop_applicable' => $item->lop_applicable,
                    'variable_component' => $item->variable_component,
                    'include_in_ctc' => $item->include_in_ctc,
                    'include_in_payslip' => $item->include_in_payslip,
                    'display_order' => $item->display_order,
                    'status' => $item->status,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        $rules = DB::table('egc_payroll_rules')->where('status', 0)->get();
        return view('content.settings.payroll.new_payroll_component.new_payroll_component', [
            'Document' => $Document,
            'rules' => $rules,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }


    // Edit Function
    public function edit(Request $request)
    {
        $component = DB::table('egc_payroll_components')
            ->where('sno', $request->id)
            ->first();

        if (!$component) {

            return response()->json([
                'status' => 404,
                'message' => 'Component Not Found'
            ]);
        }

        return response()->json([
            'status' => 200,
            'data' => $component
        ]);
    }

    public function Delete($id)
    {

        // $upd_PayrollComponentModel = PayrollComponentModel::where( 'sno', $id )->first();
        // $upd_PayrollComponentModel->status  = 2;
        // $upd_PayrollComponentModel->Update();
        DB::table('egc_payroll_components')
            ->where('sno', $id)
            ->update(['status' => 2]);

        return response([
            'status'    => 200,
            'message'   => 'Payroll Setting Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $status = $request->input('status', 0);

        DB::table('egc_payroll_components')
            ->where('sno', $id)
            ->update(['status' => $status]);

        // $upd_PayrollComponentModel =  PayrollComponentModel::where( 'sno', $id )->first();
        // $upd_PayrollComponentModel->status = $request->input( 'status', 0 );
        // $upd_PayrollComponentModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function list()
    {

        $data = DB::table('egc_payroll_components')
            ->where('status', '!=', 2)
            ->get();

        return response()->json($data);
    }

    public function store(Request $req)
    {
        $validator = Validator::make($req->all(), [
            'component_name' => 'required|max:150',
            'component_code' => 'required|max:50',
            'category' => 'required',
            'calculation_type' => 'required',

        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ]);
        }

        $exists = DB::table('egc_payroll_components')
            ->where('component_code', strtoupper($req->component_code))
            ->where('status', '!=', 2)
            ->first();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'Component code already exists'
            ]);
        }
        DB::table('egc_payroll_components')->insert([
            'component_name' => $req->component_name,
            'component_code' => strtoupper($req->component_code),
            'category' => $req->category,
            'calculation_type' => $req->calculation_type,
            'percentage_value' => $req->percentage_value ?? 0,
            'formula_expression' => $req->formula_expression,
            'rule_id' => $req->rule_id,
            'display_order' => $req->display_order ?? 0,
            'taxable' => $req->taxable ?? 0,
            'lop_applicable' => $req->lop_applicable ?? 0,
            'variable_component' => $req->variable_component ?? 0,
            'include_in_ctc' => 1,
            'include_in_payslip' => $req->include_in_payslip ?? 1,
            'status' => 0,
            'created_by' => $req->user()->user_id ?? 0,
            'updated_by' => $req->user()->user_id ?? 0,
            'created_at' => now(),
            'updated_at' => now(),

        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Payroll Component Created Successfully'

        ]);
    }

    public function view($id)
    {

        $data = DB::table('egc_payroll_components')->where('sno', $id)->first();

        return response()->json($data);
    }

    // Update Function
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [

            'component_name' => 'required|max:150',

            'component_code' => 'required|max:50',

            'category' => 'required',

            'calculation_type' => 'required'
        ]);

        if ($validator->fails()) {

            return response()->json([
                'status' => 422,
                'message' => 'Validation Failed',
                'errors' => $validator->errors()
            ]);
        }

        $component = DB::table('egc_payroll_components')
            ->where('sno', $request->sno)
            ->first();

        if (!$component) {

            return response()->json([
                'status' => 404,
                'message' => 'Component Not Found'
            ]);
        }

        $duplicate = DB::table('egc_payroll_components')
            ->where('component_code', strtoupper($request->component_code))
            ->where('sno', '!=', $request->sno)
            ->first();

        if ($duplicate) {

            return response()->json([
                'status' => 409,
                'message' => 'Component Code Already Exists'
            ]);
        }

        DB::table('egc_payroll_components')
            ->where('sno', $request->sno)
            ->update([

                'component_name' => $request->component_name,

                'component_code' => strtoupper($request->component_code),

                'category' => $request->category,

                'calculation_type' => $request->calculation_type,

                'percentage_value' => $request->percentage_value ?? 0,

                'formula_expression' => $request->formula_expression,

                'rule_id' => $request->rule_id,

                'display_order' => $request->display_order ?? 0,

                'taxable' => $request->taxable ?? 0,

                'lop_applicable' => $request->lop_applicable ?? 0,

                'include_in_ctc' => $request->include_in_ctc ?? 0,

                'include_in_payslip' => $request->include_in_payslip ?? 0,

                'updated_at' => now()
            ]);

        return response()->json([
            'status' => 200,
            'message' => 'Payroll Component Updated Successfully'
        ]);
    }

    public function deletenew(Request $req)
    {

        DB::table('egc_payroll_components')
            ->where('sno', $req->id)
            ->update(['status' => 2]);

        return response()->json(['status' => 200]);
    }


    // paryroll setting 

    public function indexRule(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = PayrollComponentModel::where('status', '!=', 2);
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('component_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('component_type', 'LIKE', "%{$search_filter}%");
            });
        }
        $Document = $Document->orderBy('sno', 'desc')->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'component_name' => $item->component_name,
                    'component_code' => $item->component_code,
                    'is_taxable' => $item->is_taxable,
                    'is_statutory' => $item->is_statutory,
                    'is_prorated' => $item->is_prorated,
                    'component_type' => $item->component_type,
                    'show_in_payslip' => $item->show_in_payslip,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        $company_list = DB::table('egc_company')->where('status', 0)->get();
        return view('content.settings.payroll.new_payroll_setting.new_payroll_setting', [
            'company_list' => $company_list,
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }
    public function getRule(Request $req)
    {

        $data = DB::table('egc_payroll_settings_new')
            ->where('status', '!=', 2)
            ->get();

        return response()->json($data);
    }

    public function saveRule(Request $req)
    {

        foreach ($req->data as $key => $value) {

            DB::table('egc_payroll_settings_new')
                ->updateOrInsert(
                    ['setting_key' => $key],
                    [
                        'setting_value' => $value,
                        'updated_at' => now()
                    ]
                );
        }

        return response()->json(['status' => 200]);
    }
}
