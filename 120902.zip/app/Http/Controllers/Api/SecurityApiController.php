<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Security\SecurityAccessService;
use App\Services\Security\SecurityDeviceService;
use App\Services\Security\SecurityPinService;
use App\Services\Security\SecurityQrService;
use App\Services\Security\SecuritySessionService;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Config;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Passport\HasApiTokens;
use App\Models\OtpModel;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class SecurityApiController extends Controller
{
    protected SecuritySessionService $sessionService;
    protected SecurityQrService $qrService;
    protected SecurityPinService $pinService;
    protected SecurityDeviceService $deviceService;
    protected SecurityAccessService $accessService;

    public function __construct(
        SecuritySessionService $sessionService,
        SecurityQrService $qrService,
        SecurityPinService $pinService,
        SecurityDeviceService $deviceService,
        SecurityAccessService $accessService
    ) {
        $this->sessionService = $sessionService;
        $this->qrService = $qrService;
        $this->pinService = $pinService;
        $this->deviceService = $deviceService;
        $this->accessService = $accessService;
    }

    /**
     * Standard Success Response
     */
    protected function success( string $message, array $data = [], int $status = 200): JsonResponse {
        return response()->json([
            'status' => true,
            'message' => $message,
            'data' => $data
        ], $status);
    }

    /**
     * Standard Error Response
     */
    protected function error( string $message, int $status = 422, array $errors = []): JsonResponse {
        return response()->json([
            'status' => false,
            'message' => $message,
            'errors' => $errors
        ], $status);
    }

        public function EmployeeLogin(Request $request)
    {

        $user_name = $request->user_name;
        $mobile_no = $request->mobile_no;
        $password      = $request->password ? $request->password : 'null';
        $remember = $request->remember;
        $device_id = $request->device_id;
        $latitude = $request->latitude;
        $longitude = $request->longitude;

        $validator = Validator::make($request->all(), [
        'mobile_no' => 'required',
        ]);

        if ($validator->fails()) {
        return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {
            $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();

            if (!$user) {
                return response()->json([
                    'status' => 500,
                    'message' => 'User not found.',
                    'error_msg'=>'User not found.',
                    'data' => NULL
                ]);
            }


            if( $mobile_no == "7548834011"){
                $otp_value  = 123456; // Random 6-digit OTP
            }else{
                $otp_value  = rand(100000, 999999); // Random 6-digit OTP
            } // Random 6-digit OTP

            // Save OTP to Database
            
            $otp = new OtpModel();

            $otp->user_id                  = $user->sno;
            $otp->mobile_no                =  $mobile_no;
            $otp->otp_number               = $otp_value;
            $otp->created_by               = $user->sno;
            $otp->updated_by               = $user->sno;
            $otp->save();

            // sms otp 
            if( $mobile_no != "7548834011"){
                if ($otp_value) {

                    $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    $authkey         = $result_sms ? $result_sms->authkey : '';
                    $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    $template_id     = $result_sms ? $result_sms->template_id : '';
                    $country_code    = $result_sms ? $result_sms->country_code : '';
                    $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    $mobile_number   = $country_code . $mobile_no;
                    

                    $app_name = "EGC Authenticator App";
                    // $app_link = 'https://elysiumacademy.org/';
                    $app_code = "QgXqDZ/YbBO";
                    // Replace placeholders with actual values
                    $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                    $message_content    = preg_replace_callback(
                        '/\{#var#\}/',
                        function () use (&$replacement_values) {
                            return array_shift($replacement_values);
                        },
                        $message_content
                    );

                    $route    = "default";
                    $postData = [
                        'authkey' => $authkey,
                        'mobiles' => $mobile_number,
                        'message' => $message_content,
                        'sender'  => $sender_id,
                        'route'   => $route,
                    ];

                    // API URL
                    $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
                    // Initialize the resource
                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL            => $url,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $postData,
                        CURLOPT_SSL_VERIFYHOST => 0,
                        CURLOPT_SSL_VERIFYPEER => 0,
                    ]);

                    // Get response
                    $response = curl_exec($ch);
                    // return $response;
                    $err = curl_error($ch);
                    curl_close($ch);
                }
            }

            return $this->success(
                'OTP Sent Successfully.',
                [
                    'otp' => $otp_value,
                    'staff_id' =>  $user->sno,
                    'mobile_no' => $mobile_no,
                    'staff_name' => $user->staff_name,
                ]
            ); 

        }
    }
    public function verifyOtp(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);

        if ($validator->fails()) {
        return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {
            $mobile_no = $request->mobile_no;
            $otpInput  = $request->otp;
            $device_id = $request->device_id;
            $latitude = $request->latitude;
            $longitude = $request->longitude;

            $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                        ->latest()
                        ->first();
            if (!$otpRecord) {
                return response()->json([
                    'status'  => false,
                    'message' => 'No OTP found for this number.'
                ], 404);
            }

            $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
            $expiryTime = $createdAt->copy()->addMinutes(2);
            $currentTime = Carbon::now('UTC');
        
            if ($currentTime->greaterThan($expiryTime)) {
                return response()->json([
                    'status'  => false,
                    'message' => 'OTP expired. Please request a new one.'
                ], 410);
            }


            if ($otpRecord->otp_number != $otpInput) {
                return response()->json([
                    'status'  => false,
                    'message' => 'Invalid OTP.'
                ], 401);
            }

            $staff_id = $otpRecord->user_id;

            $user = StaffModel::select('egc_staff.*')
                ->where('egc_staff.sno', $staff_id)
                ->where('egc_staff.status', 0)
                ->first();

            if ($user->status == 1) {
                return response()->json([
                    'status' => 403,
                    'message' => 'This user is inactive. Please contact the administrator.',
                    'error_msg'=>'This user is inactive. Please contact the administrator.',
                    'data' => NULL
                ]);
            } elseif ($user->status > 1) {
                return response()->json([
                    'status' => 403,
                    'message' => 'This user is deactivated. Please contact the administrator.',
                    'error_msg'=>'This user is deactivated. Please contact the administrator.',
                    'data' => NULL
                ]);
            }


            $secret_key = env('JWT_SECRET', 'EGC_Authenticator_2026'); // Add JWT_SECRET in .env
            $issuer_claim = "EGC Athenticator App"; // this can be your app name
            $audience_claim = "mobile-app";
            $issued_at = time();
            $expiry_time = $issued_at + (60*60*168); // 7 day expiry, 

            $payload = [
                "iss" => $issuer_claim,
                "aud" => $audience_claim,
                "iat" => $issued_at,
                "exp" => $expiry_time,
                "staff_sno" => $staff_id
            ];
            
            $jwt_token = JWT::encode($payload, $secret_key, 'HS256');

            $token = new PersonalAccessToken();
            $token->forceFill([
                'tokenable_type' => \App\Models\StaffModel::class,
                'tokenable_id'   => $staff_id,
                'name'           => 'jwt_token',
                'token'          => hash('sha256', $jwt_token),
                'abilities'      => ['*'],
                'expires_at'     => Carbon::createFromTimestamp($expiry_time),
            ])->save();
        

            return $this->success(
                'Logged in Successfully.',
                [
                    'user_id' => $otpRecord->user_id,
                    'token' => $jwt_token,
                    'expires_at' => date('Y-m-d H:i:s', $expiry_time),
                ]
            );

        }
    }

    /**
     * Scan QR
     *
     * APK
     * ----
     * Scan QR
     * Validate Device
     * Validate Session
     * Return Session Details
     *
     * PIN IS NOT GENERATED HERE
     */
    public function scan(Request $request): JsonResponse
    {
       
        $validator = Validator::make($request->all(), [
            'session_uuid'      => 'required|string',
            'device_uuid'      => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 422,
                'message' => 'Validation failed',
                'errors'  => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff
            |--------------------------------------------------------------------------
            */

           

            $user = $request->user();
            $staff = StaffModel::where('status', 0)
                ->where('sno', $user->sno)
                ->first();
             $staffId = $user->sno;

            if (!$staff) {

                return $this->error(
                    'Unauthenticated.',
                    401
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Authenticate Device
            |--------------------------------------------------------------------------
            */

            $device = $this->deviceService->authenticate(
                $staffId,
                $request->device_uuid
            );

            /*
            |--------------------------------------------------------------------------
            | Load Session
            |--------------------------------------------------------------------------
            */

            $session = $this->qrService->getSession(
                $request->session_uuid
            );

            if (!$session) {

                DB::rollBack();

                return $this->error(
                    'Security session not found.',
                    404
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Validate Session
            |--------------------------------------------------------------------------
            */

            if (
                !$this->sessionService->validateSession(
                    $session
                )
            ) {

                DB::rollBack();

                return $this->error(
                    'Security session expired.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Mark QR Scanned
            |--------------------------------------------------------------------------
            */

            $session = $this->sessionService->markScanned(
                $session,
                $device->sno
            );

            /*
            |--------------------------------------------------------------------------
            | TODO (Next Step)
            |--------------------------------------------------------------------------
            |
            | Broadcast Reverb Event
            | event(new SecuritySessionUpdated(...));
            |
            */

            DB::commit();

            return $this->success(
                'QR scanned successfully.',
                [
                    'session_uuid' => $session->session_uuid,
                    'module_id' => $session->module_id,
                    'record_id' => $session->record_id,
                    'requested_staff_id' => $session->requested_staff_id,
                    'status' => $session->status,
                    'qr_expires_at' => $session->qr_expires_at,
                    'device_name' => $device->device_name,
                    'device_model' => $device->device_model,
                    'manufacturer' => $device->manufacturer
                ]
            );

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error('Security Scan Error', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return $this->error(
                'Unable to scan security QR.',
                500
            );

        }
    }

    // ============================
    // Part 2 Starts Below
    // approve()
    // ============================
        /**
     * --------------------------------------------------------------------------
     * Approve Session
     * --------------------------------------------------------------------------
     *
     * Flutter
     * -------
     * User presses APPROVE
     *
     * Device
     *      ↓
     * Validate Session
     *      ↓
     * Generate PIN
     *      ↓
     * Return PIN
     *
     */
    public function approve(Request $request): JsonResponse
    {

        $validator = Validator::make($request->all(), [
            'session_uuid'      => 'required|string',
            'device_uuid'      => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 422,
                'message' => 'Validation failed',
                'errors'  => $validator->errors()
            ], 422);
        }
       

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff
            |--------------------------------------------------------------------------
            */

            $user = $request->user();
            $staff = StaffModel::where('status', 0)
                ->where('sno', $user->sno)
                ->first();
             $staffId = $user->sno;

            if (!$staffId) {

                DB::rollBack();

                return $this->error(
                    'Unauthenticated.',
                    401
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Authenticate Device
            |--------------------------------------------------------------------------
            */

            $device = $this->deviceService->authenticate(
                $staffId,
                $request->device_uuid
            );

            /*
            |--------------------------------------------------------------------------
            | Get Session
            |--------------------------------------------------------------------------
            */

            $session = $this->sessionService->findByUuid(
                $request->session_uuid
            );

            if (!$session) {

                DB::rollBack();

                return $this->error(
                    'Security session not found.',
                    404
                );

            }

            $moduleData = DB::table('egc_security_modules')->where('sno', $session->module_id)->where('status','!=',2)->first();

            /*
            |--------------------------------------------------------------------------
            | Validate Session
            |--------------------------------------------------------------------------
            */

            if (
                !$this->sessionService->validateSession(
                    $session
                )
            ) {

                DB::rollBack();

                return $this->error(
                    'Security session expired.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Verify Device
            |--------------------------------------------------------------------------
            */

            if ($session->device_id != $device->sno) {

                DB::rollBack();

                return $this->error(
                    'This device is not authorised for this session.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Prevent Duplicate Approval
            |--------------------------------------------------------------------------
            */

            if ($session->status == 'PIN_GENERATED') {

                DB::rollBack();

                return $this->error(
                    'PIN already generated.'
                );

            }

            if ($session->status == 'VERIFIED') {

                DB::rollBack();

                return $this->error(
                    'Session already verified.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Generate PIN
            |--------------------------------------------------------------------------
            */

            $pin = $this->pinService->generatePin(
                $session
            );

            /*
            |--------------------------------------------------------------------------
            | Remaining Seconds
            |--------------------------------------------------------------------------
            */

            $remaining = $this->pinService->remainingSeconds(
                $session->fresh()
            );

            /*
            |--------------------------------------------------------------------------
            | TODO
            |--------------------------------------------------------------------------
            |
            | event(
            |     new SecuritySessionUpdated(
            |          $session->session_uuid,
            |          'PIN_GENERATED'
            |     )
            | );
            |
            */

            DB::commit();

            return $this->success(

                'PIN generated successfully.',

                [

                    'session_uuid' => $session->session_uuid,

                    'pin' => $pin,
                     'module_name' => $moduleData->module_name ?? '',
                    'expires_in' => $remaining,
                    'pin_expires_at' => $session->pin_expires_at
                                ? $session->pin_expires_at
                                    ->timezone('Asia/Kolkata')
                                    ->format('d-M-Y, h:i A')
                                : '',
                    'status' => 'PIN_GENERATED'

                ]

            );

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error(

                'Security Approve Error',

                [

                    'message' => $e->getMessage(),

                    'line' => $e->getLine(),

                    'file' => $e->getFile()

                ]

            );

            return $this->error(

                'Unable to approve security request.',

                500

            );

        }

    }

    // ============================================================
    // Part 3 Starts Below
    // verifyPin()
    // ============================================================
        /**
     * --------------------------------------------------------------------------
     * Verify PIN (ERP)
     * --------------------------------------------------------------------------
     *
     * ERP
     * ----
     * User enters PIN shown in APK.
     *
     * Verify PIN
     *      ↓
     * Grant Access
     *      ↓
     * Return Remaining Access Time
     */
    public function verifyPin(Request $request): JsonResponse
    {
        $request->validate([
            'session_uuid' => ['required', 'string'],
            'pin'          => ['required', 'string']
        ]);

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff (ERP User)
            |--------------------------------------------------------------------------
            */

            $staffId = Auth::id();

            if (!$staffId) {

                DB::rollBack();

                return $this->error(
                    'Unauthenticated.',
                    401
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Load Session
            |--------------------------------------------------------------------------
            */

            $session = $this->sessionService->findByUuid(
                $request->session_uuid
            );

            if (!$session) {

                DB::rollBack();

                return $this->error(
                    'Security session not found.',
                    404
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Validate Session
            |--------------------------------------------------------------------------
            */

            if (!$this->sessionService->validateSession($session)) {

                DB::rollBack();

                return $this->error(
                    'Security session expired.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Ensure PIN Exists
            |--------------------------------------------------------------------------
            */

            if ($session->status !== 'PIN_GENERATED') {

                DB::rollBack();

                return $this->error(
                    'PIN has not been generated.'
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Verify PIN
            |--------------------------------------------------------------------------
            */

            $verified = $this->pinService->verifyPin(
                $session,
                $request->pin
            );

            if (!$verified) {

                $session->refresh();

                DB::rollBack();

                return $this->error(
                    'Invalid PIN.',
                    422,
                    [
                        'pin_attempts' => $session->pin_attempts
                    ]
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Grant Temporary Access
            |--------------------------------------------------------------------------
            */

            $access = $this->accessService->grant(
                $session,
                $staffId
            );

            /*
            |--------------------------------------------------------------------------
            | Reset Failed Attempts
            |--------------------------------------------------------------------------
            */

            $this->pinService->resetAttempts(
                $session->fresh()
            );

            /*
            |--------------------------------------------------------------------------
            | Close Session
            |--------------------------------------------------------------------------
            |
            | Prevent the same PIN/session
            | from being reused.
            |
            */

            $this->sessionService->closeSession(
                $session->fresh()
            );

            /*
            |--------------------------------------------------------------------------
            | TODO
            |--------------------------------------------------------------------------
            |
            | event(
            |     new SecuritySessionUpdated(
            |          $session->session_uuid,
            |          'VERIFIED',
            |          [
            |              'expires_at' => $access->expires_at
            |          ]
            |     )
            | );
            |
            */

            DB::commit();

            return $this->success(

                'Access granted successfully.',

                [

                    'session_uuid' => $session->session_uuid,

                    'access_status' => 'ACTIVE',

                    'expires_at' => $access->expires_at,

                    'remaining_seconds' => $this->accessService->remaining(
                        $staffId,
                        $session->module_id,
                        $session->record_id
                    )

                ]

            );

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error(
                'Security Verify PIN Error',
                [
                    'message' => $e->getMessage(),
                    'line'    => $e->getLine(),
                    'file'    => $e->getFile()
                ]
            );

            return $this->error(
                'Unable to verify PIN.',
                500
            );

        }
    }

    // ==========================================================
    // Part 4 Starts Below
    // status()
    // ==========================================================
        /**
     * --------------------------------------------------------------------------
     * Access Status
     * --------------------------------------------------------------------------
     *
     * ERP
     * ----
     * Used by:
     *  - Countdown Timer
     *  - Auto Hide
     *  - Reverb Fallback
     *
     */
    public function status(Request $request): JsonResponse
    {
        $request->validate([
            'module_id' => ['required', 'integer'],
            'record_id' => ['required', 'integer']
        ]);

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff
            |--------------------------------------------------------------------------
            */

            $staffId = Auth::id();

            if (!$staffId) {

                return $this->error(
                    'Unauthenticated.',
                    401
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Access Available?
            |--------------------------------------------------------------------------
            */

            $hasAccess = $this->accessService->hasAccess(

                $staffId,

                (int) $request->module_id,

                (int) $request->record_id

            );

            /*
            |--------------------------------------------------------------------------
            | No Access
            |--------------------------------------------------------------------------
            */

            if (!$hasAccess) {

                return $this->success(

                    'Access expired.',

                    [

                        'access' => false,

                        'remaining_seconds' => 0,

                        'show_data' => false

                    ]

                );

            }

            /*
            |--------------------------------------------------------------------------
            | Remaining Time
            |--------------------------------------------------------------------------
            */

            $remaining = $this->accessService->remaining(

                $staffId,

                (int) $request->module_id,

                (int) $request->record_id

            );

            /*
            |--------------------------------------------------------------------------
            | Expired During Request
            |--------------------------------------------------------------------------
            */

            if ($remaining <= 0) {

                return $this->success(

                    'Access expired.',

                    [

                        'access' => false,

                        'remaining_seconds' => 0,

                        'show_data' => false

                    ]

                );

            }

            /*
            |--------------------------------------------------------------------------
            | Active
            |--------------------------------------------------------------------------
            */

            return $this->success(

                'Access active.',

                [

                    'access' => true,

                    'show_data' => true,

                    'remaining_seconds' => $remaining

                ]

            );

        } catch (Throwable $e) {

            Log::error(

                'Security Status Error',

                [

                    'message' => $e->getMessage(),

                    'line' => $e->getLine(),

                    'file' => $e->getFile()

                ]

            );

            return $this->error(

                'Unable to fetch security status.',

                500

            );

        }

    }

    // ==========================================================
    // Part 5 Starts Below
    // close()
    // ==========================================================

        /**
     * --------------------------------------------------------------------------
     * Close Security Session
     * --------------------------------------------------------------------------
     *
     * ERP / APK
     *
     * Used When
     * ----------
     * • User closes QR dialog
     * • User cancels request
     * • APK presses Cancel
     * • Session manually terminated
     *
     */
    public function close(Request $request): JsonResponse
    {
        $request->validate([
            'session_uuid' => ['required', 'string']
        ]);

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff
            |--------------------------------------------------------------------------
            */

            $staffId = Auth::id();

            if (!$staffId) {

                DB::rollBack();

                return $this->error(
                    'Unauthenticated.',
                    401
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Find Session
            |--------------------------------------------------------------------------
            */

            $session = $this->sessionService->findByUuid(
                $request->session_uuid
            );

            if (!$session) {

                DB::rollBack();

                return $this->error(
                    'Security session not found.',
                    404
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Authorization
            |--------------------------------------------------------------------------
            */

            if (

                $session->requested_staff_id != $staffId &&

                $session->verified_staff_id != $staffId

            ) {

                DB::rollBack();

                return $this->error(
                    'You are not authorised to close this session.',
                    403
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Already Closed
            |--------------------------------------------------------------------------
            */

            if (

                in_array(

                    $session->status,

                    [

                        'CLOSED',

                        'EXPIRED'

                    ]

                )

            ) {

                DB::rollBack();

                return $this->success(

                    'Session already closed.',

                    [

                        'session_uuid' => $session->session_uuid,

                        'status' => $session->status

                    ]

                );

            }

            /*
            |--------------------------------------------------------------------------
            | Revoke Active Access
            |--------------------------------------------------------------------------
            */

            $this->accessService->revoke(

                $staffId,

                $session->module_id,

                $session->record_id

            );

            /*
            |--------------------------------------------------------------------------
            | Close Session
            |--------------------------------------------------------------------------
            */

            $this->sessionService->closeSession(
                $session
            );

            /*
            |--------------------------------------------------------------------------
            | TODO (Reverb)
            |--------------------------------------------------------------------------
            |
            | event(
            |     new SecuritySessionUpdated(
            |          $session->session_uuid,
            |          'CLOSED'
            |     )
            | );
            |
            */

            DB::commit();

            return $this->success(

                'Security session closed successfully.',

                [

                    'session_uuid' => $session->session_uuid,

                    'status' => 'CLOSED'

                ]

            );

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error(

                'Security Close Error',

                [

                    'message' => $e->getMessage(),

                    'line' => $e->getLine(),

                    'file' => $e->getFile()

                ]

            );

            return $this->error(

                'Unable to close security session.',

                500

            );

        }

    }

    public function registerDevice(Request $request)
{

        $validator = Validator::make($request->all(), [
            'device_uuid'      => 'required|string|max:255',
            'device_name'      => 'required|string|max:255',
            'device_model'     => 'required|string|max:255',
            'manufacturer'     => 'required|string|max:255',
            'android_version'  => 'required|string|max:50',
            'app_version'      => 'required|string|max:50',
            'firebase_token'   => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 422,
                'message' => 'Validation failed',
                'errors'  => $validator->errors()
            ], 422);
        }
    

    DB::beginTransaction();

    try {
       
       $user = $request->user();
        $staff = StaffModel::where('status', 0)
            ->where('sno', $user->sno)
            ->first();
        if (!$staff) {
            return response()->json([
                'status' => false,
                'message' => 'Unauthenticated.'
            ],401);
        }

        $device = $this->deviceService->register(
            $user->sno, // use your actual authenticated staff/user ID field
            $request->only([
                'device_uuid',
                'device_name',
                'device_model',
                'manufacturer',
                'android_version',
                'app_version',
                'firebase_token'
            ])
        );

        DB::commit();

        return response()->json([
            'status' => true,
            'message' => 'Device registered successfully.',
            'data' => [
                'device_id' => $device->sno,
                'device_uuid' => $device->device_uuid,
                'status' => $device->status
            ]
        ]);

    } catch (Throwable $e) {
        DB::rollBack();
        Log::error('Register Device Error',[
            'message'=>$e->getMessage(),
            'line'=>$e->getLine(),
            'file'=>$e->getFile()
        ]);

        return response()->json([
            'status'=>false,
            'message'=>'Unable to register device.'
        ],500);

    }
}

 public function getStaffData(Request $request)
{
  
    $user = $request->user();
    $staff = StaffModel::where('sno', $user->sno)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ]);
    }

        $data =  StaffModel::where('egc_staff.status', '!=', 2)
        ->select('egc_staff.*',
        'egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_company.company_name',
        'egc_company.company_base_color',
        'egc_department.department_name',
        'egc_division.division_name',
        'egc_user_role.role_name',
        'egc_languages.name as mother_tongue',
        'egc_job_role.job_position_name as job_role_name',
        )
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->leftJoin('egc_user_role', 'egc_staff.role_id', 'egc_user_role.sno')
        ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_staff.sno', $user->sno)
        ->first();
        $languages_ids=$data->languages ? json_decode($data->languages):[];
        $hobby_ids=$data->hobby ? json_decode($data->hobby):[];
        $language_known=DB::table('egc_languages')->whereIn('sno',$languages_ids)->pluck('name');
        $hobbies=DB::table('egc_hobbies')->whereIn('sno',$hobby_ids)->pluck('hobby_name');
        $staff_family=DB::table('egc_staff_family')->where('staff_id',$user->sno)->where('status','!=',2)->first();
        $data->language_known=$language_known;
        $data->hobbies=$hobbies;
        // family details
        $data->father_name=$staff_family? $staff_family->father_name :'';
        $data->father_occup=$staff_family? $staff_family->father_occup :'';
        $data->mother_name=$staff_family? $staff_family->mother_name :'';
        $data->mother_occup=$staff_family? $staff_family->mother_occup :'';
        $data->has_children=$staff_family? $staff_family->has_children :'';
        $data->children_count=$staff_family? $staff_family->children_count :'';
        $data->has_siblings=$staff_family? $staff_family->has_siblings :'';

        $data->contact_person_name = $data->contact_person_name ? json_decode($data->contact_person_name) : [];
        $data->contact_person_no = $data->contact_person_no ? json_decode($data->contact_person_no) : [];
        $contact_person_relation_ids = $data->contact_person_relation ? json_decode($data->contact_person_relation) : [];
        $relation=DB::table('egc_relationship_type')->whereIn('sno',$contact_person_relation_ids)->pluck('relationship_name');
        $data->relationship=$relation;

        $work_details = DB::table('egc_staff_work_info')
            ->select('egc_staff_work_info.*')
            ->where('egc_staff_work_info.staff_id',$user->sno)
            ->where('egc_staff_work_info.status', '!=', 2)
            ->orderBy('egc_staff_work_info.sno','asc')
            ->get();
        
        $data->work_details =$work_details;
        $data->job_level = 'L1';

        $documents = DB::table('egc_staff_attachment')
            ->where('egc_staff_attachment.staff_id',$user->sno)
            ->select('egc_staff_attachment.*','egc_documents.document_name')
            ->where('egc_staff_attachment.status', '!=', 2)
            ->join('egc_documents', 'egc_staff_attachment.document_id', '=', 'egc_documents.sno')
            ->get();
            $documentData = [];

        foreach ($documents as $doc) {
            $fileNames = json_decode($doc->attachment_name); // Decode the JSON file names
            $documentData[] = [
                'document_name' => $doc->document_name,
                'files' => array_map(function($fileName) use ($doc) {
                    return asset("staff_attachments/{$doc->staff_id}/{$doc->document_id}/{$fileName}");
                }, $fileNames)
            ];
        }

        $qualification = DB::table('egc_staff_education_info')
            ->select('egc_staff_education_info.*','egc_qualification_level.qualification_level_name as qualification_name','egc_major.major_name')
            ->where('egc_staff_education_info.status', '!=', 2)
            ->where('egc_staff_education_info.staff_id', $user->sno)
            // ->join('egc_education', 'egc_staff_education_info.qualification_type', '=', 'egc_education.sno')
            ->join('egc_qualification_level', 'egc_staff_education_info.qualification_type', '=', 'egc_qualification_level.sno')
            ->leftJoin('egc_major', 'egc_staff_education_info.major', '=', 'egc_major.sno')
            ->get();

            $document_checkList = DB::table('egc_document_checklist')
            ->select('egc_document_checklist.*')
            ->where('egc_document_checklist.status', '!=', 2)
            ->get();
            $document_checklist_snos = $data->document_checklist ? json_decode($data->document_checklist) : [];

            foreach ($document_checkList as $document) {
                if (in_array($document->sno, $document_checklist_snos)) {
                    $document->is_checked = 1;
                } else {
                    $document->is_checked = 0;
                }
            }
            $data->documents =$documentData;
            $data->qualification =$qualification;
            $data->document_checkList =$document_checkList;

            if ($data->gender == 1) {
                $defaultPath = asset('assets/egc_images/auth/user_2.png');
            } else {
                $defaultPath = asset('assets/egc_images/auth/user_7.png');
            }
            if ($data->company_type == 1) {
                $relativePath = 'staff_images/Management/' . $data->staff_image;
            } else {
                $relativePath = 'staff_images/Buisness/' . $data->company_id . '/' . $data->entity_id . '/' . $data->staff_image;
            }
            //  Correct physical path
            $fullPath = public_path($relativePath);
            //  Correct URL
            $filePath = asset($relativePath);
            //  Proper check
            $isStaffImage = ($data->staff_image && file_exists($fullPath)) ? 1 : 0;

        $staffImageUrl = $isStaffImage ? $filePath : $defaultPath;
        
        $staffData =[
            "id"=>$data->sno,
            "employee_id"=>$data->staff_id,
            "staff_name"=>$data->staff_name,
            "nick_name"=>$data->nick_name ?? '',
            "staff_image"=>$staffImageUrl ?? '',
            "date_of_birth"=>$data->dob ? date('d-M-Y',strtotime($data->dob)) : '',
            "date_of_joining"=>$data->date_of_joining ? date('d-M-Y',strtotime($data->date_of_joining)) : '',
            "mobile_no"=>$data->mobile_no ?? '',
            "email_id"=>$data->email_id ?? '',
            "department_name"=>$data->department_name ?? '',
            "division_name"=>$data->division_name ?? '',
            "job_role_name"=>$data->job_role_name ?? '',
            
        ];

    return response()->json([
        'status' => 200,
        'message' => 'Staff data fetched successfully',
        'error_msg' => null,
        'data' => $staffData
    ]);
}


}