<?php

namespace App\Http\Controllers\corporate_admin\vehicle_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class VehicleMachinery extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.vehicle_management.asset_list');
    }

    public function add()
    {
        return view('content.corporate_admin.vehicle_management.add_asset');
    }

    public function edit()
    {
        return view('content.corporate_admin.vehicle_management.edit_asset');
    }

    public function active()
    {
        return view('content.corporate_admin.vehicle_management.active_vehicle');
    }

    public function in_service()
    {
        return view('content.corporate_admin.vehicle_management.inservice_vehicle');
    }

    public function idle()
    {
        return view('content.corporate_admin.vehicle_management.idle_vehicle');
    }

    public function lapsed()
    {
        return view('content.corporate_admin.vehicle_management.lapsed_vehicle');
    }

    public function expired()
    {
        return view('content.corporate_admin.vehicle_management.expired_vehicle');
    }
}