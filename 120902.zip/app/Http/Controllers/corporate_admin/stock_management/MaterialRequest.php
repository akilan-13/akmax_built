<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MaterialRequest extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.stock_management.material_request_list');
  }
  public function print()
  {
    return view('content.corporate_admin.stock_management.print_items');
  }

}
