<?php

namespace App\Http\Controllers\corporate_admin\stock_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class StockValidation extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.stock_management.stock_validation');
  }

}
