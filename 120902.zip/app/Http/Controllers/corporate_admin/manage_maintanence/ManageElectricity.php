<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageElectricity extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.manage_maintanence.manage_electricity.electricity_list');
    }
    public function payment()
    {
        return view('content.corporate_admin.manage_maintanence.manage_electricity.electricity_payment');
    }
    public function bill()
    {
        return view('content.corporate_admin.manage_maintanence.manage_electricity.electricity_bill');
    }
}   