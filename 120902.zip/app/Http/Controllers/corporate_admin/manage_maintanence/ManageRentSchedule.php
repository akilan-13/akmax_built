<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageRentSchedule extends Controller
{
    public function index()
    {
        return view('content.corporate_admin.manage_maintanence.manage_rent_schedule.rent_schedule_calendar');
    }
    public function table()
    {
        return view('content.corporate_admin.manage_maintanence.manage_rent_schedule.rent_schedule_table');
    }
    public function overview()
    {
        return view('content.corporate_admin.manage_maintanence.manage_rent_schedule.rent_schedule_overview');
    }
}