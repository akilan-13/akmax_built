<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageDocuments extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.manage_maintanence.manage_documents.document_list');
  }

}
