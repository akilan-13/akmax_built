<?php

namespace App\Http\Controllers\corporate_admin\manage_maintanence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageInternet extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.manage_maintanence.manage_internet.internet_list');
  }
   public function payment()
    {
        return view('content.corporate_admin.manage_maintanence.manage_internet.internet_payment');
    }
    public function bill()
    {
        return view('content.corporate_admin.manage_maintanence.manage_internet.internet_bill');
    }

}
