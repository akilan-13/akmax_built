<?php

namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageInsuranceAMC extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.Policies_and_yerd.manage_insurance_Amc.manage_insurance_AMC');
  }

}
