<?php

namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageHospitality extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.schedule_management.hospitality_schedule');
  }
  public function view()
  {
    return view('content.corporate_admin.schedule_management.calender_view');
  }

}
