<?php

namespace App\Http\Controllers\corporate_admin\schedule_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageVisitor extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.schedule_management.visitor_list');
  }

}
