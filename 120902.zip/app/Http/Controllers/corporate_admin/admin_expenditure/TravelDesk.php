<?php

namespace App\Http\Controllers\corporate_admin\admin_expenditure;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TravelDesk extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.admin_expenditure.travel_desk.travel_desk_list');
  }

}
