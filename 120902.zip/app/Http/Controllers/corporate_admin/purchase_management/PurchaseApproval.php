<?php

namespace App\Http\Controllers\corporate_admin\purchase_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PurchaseApproval extends Controller
{
  public function index()
  {
    return view('content.corporate_admin.purchase_management.request_list');
  }
  public function print()
  {
    return view('content.corporate_admin.purchase_management.purchase_print');
  }

}
