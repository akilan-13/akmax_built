<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\JobQRScannerModel;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Models\JobRequestModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewSessionModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewCandidateModel;
use App\Models\InterviewAnswerModel;
use App\Models\InterviewOtpModel;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;

class JobController extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
     $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', '>', 1);
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_short_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        if($company_fill != ''){
          if($company_fill == 'egc'){
             $staffData->where('egc_staff.company_type',1);
          }else{
            $staffData->where('egc_staff.company_id', 'LIKE', $company_fill);
          }
            
        }

        if ($entity_fill) {
          $staffData->where('egc_staff.entity_id', $entity_fill);
        }

        
        if ($department_fill) {
            $staffData->where('egc_staff.department_id', $department_fill);
        }

        if ($division_fill) {
            $staffData->where('egc_staff.division_id', $division_fill);
        }

        if ($job_role_fill) {
          $staffData->where('egc_staff.job_role_id', $job_role_fill);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $staffData->whereDate('egc_staff.date_of_joining', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $staffData->whereBetween('egc_staff.date_of_joining', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $staffData->whereBetween('egc_staff.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->whereBetween('egc_staff.date_of_joining', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $staffData->where('egc_staff.date_of_joining', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $staffData->where('egc_staff.date_of_joining', '<=', $toDate);
            }
          }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);
        
        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
            
           $educations = DB::table('egc_staff_education_info')
            ->select('egc_education.education')
            ->join('egc_education', 'egc_education.sno', '=', 'egc_staff_education_info.qualification_type')
            ->where('egc_staff_education_info.staff_id', $staff->sno) 
            ->where('egc_staff_education_info.status', 0)
            ->pluck('egc_education.education');
            $staff->education=$educations;
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staffData->currentPage(),
                'last_page' => $staffData->lastPage(),
                'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.manage_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }

 private function getValidSession(string $token)
  {
      return InterviewSessionModel::where('session_token', $token)
          ->where('status', 1)
          ->firstOrFail();
  }


  
  public function jobApplication($id=null,Request $request)
  {
     $decodeId = base64_decode($id);
     $qrcode=$request->qr;
     $decodeQr = base64_decode($qrcode);

      if($decodeQr == 'EGCJOBQR'){
        $scanTracked = session('job_scan_tracked_' . $decodeId);
        if (!$scanTracked) {
            // Save the scan details if not tracked already
            $this->saveScanDetails($decodeId, $request);
    
            // Set a session flag to indicate that the scan has been tracked for this event
            session(['job_scan_tracked_' . $decodeId => true]);
        }
      }

     
     $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)->where('egc_job_request.sno',$decodeId)->first();

     $other_db = DB::connection('mysql_secondary');
     
   
    //   return $other_db->table('user')->first();
    // Query to fetch user data and associated call logs
    $users_with_call_log_count = $other_db
      ->table('applicant')
      ->get();
      // return  $users_with_call_log_count ;
    $feedback_submitted =false;
    $customers =[];
    return view('content.hr_management.hr_recruiter.job_application.job_application_form',compact('feedback_submitted','customers','jobRequest'));
  }

  public function generateQrJob($id, Request $request)
  {
      // Encode sno in base64 (shorter than Crypt)
      $encodedId = base64_encode($id);
      $encodedcode = base64_encode('EGCJOBQR');
  
      
      $qrContent = url("/job_application/{$encodedId}?qr={$encodedcode}");
      // 'https://erp.elysium.community/job_application_qr';
  
      // Generate QR as base64 image
      $qrServerUrl = "https://api.qrserver.com/v1/create-qr-code/?data=" . urlencode($qrContent) . "&size=300x300";
      $qrImageData = @file_get_contents($qrServerUrl);
      $qrBase64 = $qrImageData ? 'data:image/png;base64,' . base64_encode($qrImageData) : null;
      // Save scan details
      
  
      return response()->json([
          'status'    => $qrBase64 ? 200 : 500,
          'qr_base64' => $qrBase64,
          'link'      => $qrContent,
      ]);
  }
    
  private function saveScanDetails($job_request_id,Request $request)
  {
      // Get the user's IP address
      $ipAddress = $request->ip();
  
      // Get latitude and longitude if provided by frontend (JavaScript geolocation)
      $latitude = $request->input('latitude', null);
      $longitude = $request->input('longitude', null);
  
      // Get area from IP address (you can use any IP geolocation API)
      // $area = $this->getAreaByIp($ipAddress);
      $area="";
      // Get device information (User-Agent string)
      $deviceInfo = $request->header('User-Agent');
      $isMobile = preg_match('/Mobile|Android|iP(hone|od|ad)|IEMobile|BlackBerry|Opera Mini/i', $deviceInfo);
              
      $deviceType = $isMobile ? 'Mobile' : 'Desktop';
  
      // Insert the scan data into the database
      JobQRScannerModel::create([
          'job_request_id'      => $job_request_id,
          'ipaddress' => $ipAddress,
          'latitude'   => $latitude,
          'longitude'  => $longitude,
          'area'       => $area,
          'device'=> $deviceType,
      ]);
  }

  
    public function startInterview($encodedId)
  {
      [$scheduleId] = explode('|', base64_decode($encodedId));
    
      $schedule = InterviewScheduleModel::where('egc_interview_schedule.sno', $scheduleId)
          ->select('egc_interview_schedule.share_code',
                   'egc_interview_schedule.sno as schedule_id',
                   'egc_job_request.*',
                   'egc_interview_schedule_stage.sno as schedule_stage_id',
                   'egc_interview_schedule_stage.duration_value',
                   'egc_interview_schedule_stage.duration_unit',
                   'egc_interview_schedule_stage.status as stage_status',
                   'egc_interview_category.interview_category_name',
                   'egc_interview_mode.interview_mode_name',
                   'egc_job_role.job_position_name as job_role_name',
          )
          ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
          ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
          ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
          ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
          ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
          ->where('egc_interview_schedule.status', 0)
          ->where('egc_job_request.status', 1)
          ->orderBy('egc_interview_schedule_stage.stage_order', 'asc')
          ->first();
          session([
            'interview_schedule_id' => $schedule->schedule_id ?? 0,
            'interview_schedule_stage_id' => $schedule->schedule_stage_id ?? 0,
          ]);
    // return $schedule;
      return view('content.hr_management.hr_recruiter.job_application.interview_login', compact('encodedId','scheduleId','schedule'));
  }


   public function sendOtp(Request $request)
  {
      $request->validate([
          'mobile'    => 'required|regex:/^[6-9]\d{9}$/',
          'email'     => 'required|email'
      ]);

      DB::beginTransaction();
      // return $request;
      // try {
          // create or get candidate
          $candidate = InterviewCandidateModel::firstOrCreate(
              ['mobile' => $request->mobile],
              [
                  'full_name' => $request->full_name,
                  'email'     => $request->email,
                  'status'    => 1
              ]
          );

          // email mismatch safety
          if ($candidate->email !== $request->email) {
              return response()->json([
                  'message' => 'Email does not match registered mobile number'
              ], 400);
          }

          // invalidate old OTPs
          InterviewOtpModel::where('candidate_id', $candidate->sno)
              ->update(['is_used' => 1]);

          $otp = rand(100000, 999999);

          InterviewOtpModel::create([
              'candidate_id' => $candidate->sno,
              'interview_schedule_id' => $request->interview_schedule_id,
              'job_request_id' => $request->job_request_id,
              'otp'          => $otp,
              'expires_at'   => now()->addMinutes(5),
              'is_used'      => 0
          ]);

          // TODO: SMS / Email integration
          // sendSms($candidate->mobile, $otp);

              if ($request->email) {
                $emailTemplate_id =2; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;

                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }
        
                $dynamicSubject = str_replace('#otp', $otp ?? '000000', $emailTemplate->email_name);
        
                $content = str_replace('#employee_name', $request->full_name ?? 'Student', $content);
                $content = str_replace('#otp', $otp ?? '000000', $content);
                $content = str_replace('#hr_contact',  $cre_mobile ?? '8220011465', $content);
                $content = str_replace('#hr_email',  $cre_mobile ?? 'email_id', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $branchNo,
                      'branchemail' => $branchemail, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $branchData->cre_mobile ?? '8220011465',
                  ];
        
                $to_address = $request->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups of Companies ';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));
              }

          DB::commit();

          return response()->json([
              'status' => true,
              'message' => 'OTP sent successfully'
          ]);

      // } catch (\Throwable $e) {
      //     DB::rollBack();
      //     return response()->json([
      //         'message' => 'Failed to send OTP'
      //     ], 500);
      // }
  }

  public function verifyOtp(Request $request)
{
    $request->validate([
        'mobile' => 'required',
        'otp'    => 'required'
    ]);

    $candidate = InterviewCandidateModel::where('mobile', $request->mobile)->first();

    if (!$candidate) {
        return response()->json(['message' => 'Candidate not found'], 400);
    }

    $otpRow = InterviewOtpModel::where('candidate_id', $candidate->sno)
        ->where('otp', $request->otp)
        ->where('is_used', 0)
        ->where('expires_at', '>', now())
        ->first();

    if (!$otpRow) {
        return response()->json(['message' => 'Invalid or expired OTP'], 400);
    }

    $otpRow->update(['is_used' => 1]);

    $session = InterviewSessionModel::create([
        'interview_schedule_id' => session('interview_schedule_id'),
        'interview_schedule_stage_id' => session('interview_schedule_stage_id'),
        'candidate_id' => $candidate->sno,
        'session_token' => \Str::uuid(),
        'started_at' => now(),
        'status' => 1,
        'created_at' => now()
    ]);

    return response()->json([
        'status' => true,
        'redirect' => url('/interview/' . $session->session_token)
    ]);
}

    public function runInterview($token)
{
    //  return $token;
    $session = InterviewSessionModel::where('egc_interview_session.session_token', $token)
        ->join('egc_interview_schedule', 'egc_interview_schedule.sno', 'egc_interview_session.interview_schedule_id')
        ->join('egc_interview_schedule_stage', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_session.interview_schedule_stage_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_interview_schedule.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
        ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
        ->select( 
                'egc_interview_schedule_stage.*',
                'egc_interview_category.interview_category_name',
                'egc_interview_mode.interview_mode_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_interview_session.session_token',
        ) 
        // ->where('egc_interview_session.status', 1)
        ->first();
        // return $session;
          session([
            'session_token' => $token ?? 0,
          ]);
      if($session->status == 2){
        return "Already Submitted";
      }
    return view('content.hr_management.hr_recruiter.job_application.interview_page', compact('session'));
}

public function fetchNextQuestion(Request $request)
{
    $session = InterviewSessionModel::where('session_token', $request->session_token)
        ->where('status', 1)
        ->first();

    // total questions for progress bar
    $totalQuestions = InterviewScheduleQuestionModel::where(
        'interview_schedule_stage_id',
        $session->interview_schedule_stage_id
    )->where('status', 0)->count();

    $nextQuestion = InterviewScheduleQuestionModel::query()
        ->join('egc_interview_question as q', 'q.sno', '=', 'egc_interview_schedule_questions.interview_question_id')
        ->leftJoin('egc_interview_answers as a', function ($join) use ($session) {
            $join->on('a.interview_question_id', '=', 'egc_interview_schedule_questions.interview_question_id')
                 ->where('a.interview_session_id', '=', $session->sno);
        })
        ->where('egc_interview_schedule_questions.interview_schedule_stage_id', $session->interview_schedule_stage_id)
        ->whereNull('a.sno') // unanswered only
        ->where('egc_interview_schedule_questions.status', 0)
        ->orderBy('egc_interview_schedule_questions.sno')
        ->select([
            'q.sno as question_id',
            'q.field_name',
            'q.field_value',
            'egc_interview_schedule_questions.thinking_time',
            'egc_interview_schedule_questions.allowed_time',
            'egc_interview_schedule_questions.retakes',
        ])
        ->first();
          // $session = $this->getValidSession($request->session_token);
  // return $$nextQuestion;
    if (!$nextQuestion) {
        $session->update([
            'status' => 2, // completed
            'completed_at' => now()
        ]);

        return response()->json([
            'completed' => true,
            'redirect' => route('interview.thankyou')
        ]);
    }


    // answered count for progress
    $answered = InterviewAnswerModel::where('interview_session_id', $session->sno)->count();

    return response()->json([
        'completed' => false,
        'question' => $nextQuestion,
        'progress' => [
            'current' => $answered + 1,
            'total'   => $totalQuestions
        ]
    ]);
}

public function logTabSwitch(Request $request)
{
  $session = $this->getValidSession($request->session_token);

    InterviewSessionModel::where('session_token', $request->session_token)
        ->increment('tab_switch_count');
}


public function saveAnswer(Request $request)
{
    $request->validate([
        'session_token' => 'required',
        'question_id'   => 'required|integer',
        // 'answer_type'   => 'required|in:text,audio,video',
        'answer_file' => 'nullable|max:51200'
    ]);

    // $session = InterviewSessionModel::where('session_token', $request->session_token)
    //     ->where('status', 1)
    //     ->firstOrFail();
    $session = $this->getValidSession($request->session_token);

    $filePath = null;

    if ($request->hasFile('answer_file')) {

        $file = $request->file('answer_file');

        // 1️⃣ Detect MIME TYPE (CRITICAL)
        $mime = $file->getMimeType();

        // 2️⃣ Map MIME → EXTENSION (DO NOT SKIP)
        $extensionMap = [
            'video/webm'  => 'webm',
            'video/mp4'   => 'mp4',
            'audio/webm'  => 'webm',
            'audio/wav'   => 'wav',
            'audio/mpeg'  => 'mp3',
        ];

        if (!isset($extensionMap[$mime])) {
            return response()->json([
                'message' => 'Unsupported media format: ' . $mime
            ], 422);
        }

        $extension = $extensionMap[$mime];

        // 3️⃣ Choose folder
        $folder = str_starts_with($mime, 'video')
            ? 'interview_file/video'
            : 'interview_file/audio';

        // 4️⃣ Ensure directory exists
        $destinationPath = public_path($folder);
        if (!is_dir($destinationPath)) {
            mkdir($destinationPath, 0775, true);
        }

        // 5️⃣ Generate SAFE filename (NO trailing dot)
        $filename = uniqid('ans_') . '.' . $extension;

        // 6️⃣ MOVE FILE (WINDOWS SAFE)
        $file->move($destinationPath, $filename);

        // 7️⃣ Save relative path
        $filePath = $folder . '/' . $filename;
    }

      $allowedRetakes = InterviewScheduleQuestionModel::where(
          'interview_question_id',
          $request->question_id
      )->value('retakes');

      $attempts = InterviewAnswerModel::where([
          'interview_session_id' => $session->sno,
          'interview_question_id' => $request->question_id
      ])->count();

      // if ($attempts >= $allowedRetakes + 1) {
      //     return response()->json([
      //         'message' => 'Retake limit exceeded'
      //     ], 403);
      // }

    InterviewAnswerModel::create([
        'interview_session_id'       => $session->sno,
        'interview_schedule_stage_id'=> $session->interview_schedule_stage_id,
        'interview_question_id'      => $request->question_id,
        'answer_type'                => $request->answer_type,
        'answer_text'                => $request->answer_text,
        'answer_file'                => $filePath,
        'time_taken'                 => $request->time_taken ?? 0,
        'retake_count' => $request->retake_count ?? 0,
        'status'                     => 1,
        'created_at'                 => now(),
        'created_by'                 => $session->candidate_id
    ]);

    return response()->json(['status' => true]);
}

public function checkResume(Request $request)
{
    $session = InterviewSessionModel::where('session_token', $request->session_token)
        ->where('status', 1)
        ->first();
  
    if (!$session) {
        return response()->json([
            'resume' => false
        ]);
    }

    // check unanswered questions
    $pending = InterviewScheduleQuestionModel::where(
        'interview_schedule_stage_id',
        $session->interview_schedule_stage_id
    )
    ->where('status', 1)
    ->whereNotIn('interview_question_id', function ($q) use ($session) {
        $q->select('interview_question_id')
          ->from('egc_interview_answers')
          ->where('interview_session_id', $session->sno);
    })
    ->exists();

    return response()->json([
        'resume' => $pending,
        'last_seen' => $session->updated_at
    ]);
}


}