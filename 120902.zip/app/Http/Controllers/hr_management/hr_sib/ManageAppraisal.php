<?php

namespace App\Http\Controllers\hr_management\hr_sib;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\StaffModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Cache;
use App\Services\AppraisalService;


class ManageAppraisal extends Controller
{
    protected $service;

    public function __construct(AppraisalService $service)
    {
        $this->service = $service;
    }

    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        
        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list  = ManageEntityModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        return view('content.hr_management.hr_sib.manage_appraisal.staff_salary_appraisal',[
            'company_list' => $company_list,
            'entity_list' => $entity_list ,
            'perpage' => $perpage,

        ]);
    }

    public function list(Request $request)
    {
        return response()->json(
            $this->service->list($request)
        );
    }

    public function details($staff)
    {
        return response()->json(
            $this->service->details($staff)
        );
    }

    public function history($staff)
    {
        return response()->json(
            $this->service->history($staff)
        );
    }
}
