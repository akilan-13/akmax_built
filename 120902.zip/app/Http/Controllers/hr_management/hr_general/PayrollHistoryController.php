<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use PDF;
class PayrollHistoryController extends Controller
{


public function index()
{
return view('content.hr_management.hr_general.manage_payroll.history');
}


public function runPayroll(Request $req)
{
    $month = $req->month;
    $year = $req->year;

    $staffs = DB::table('egc_staff')->where('status',0)->get();

    foreach($staffs as $staff){

        $components = DB::table('egc_staff_salary_components_new')
            ->where('staff_id',$staff->sno)
            ->where('is_active',1)
            ->get();

        $earnings = 0;
        $deductions = 0;
        $compData =[];

        foreach($components as $comp){

            $amount = $comp->amount;

            if($comp->calculation_type == 'percentage'){
                $amount = ($staff->basic_salary * $comp->amount)/100;
            }

            if($comp->component_id <= 10){
                $earnings += $amount;
                $type = 'earning';
            }else{
                $deductions += $amount;
                $type = 'deduction';
            }

            $compData[] = [
                'component_id'=>$comp->component_id,
                'component_name'=>'', // optional join
                'type'=>$type,
                'amount'=>$amount
            ];
        }

        // PF
        $pf = min($staff->basic_salary,15000) * 0.12;
        $deductions += $pf;

        // ESI
        if($earnings <= 21000){
            $esi = $earnings * 0.0075;
            $deductions += $esi;
        }

        $net = $earnings - $deductions;

        // Save payslip
        $payslip_id = DB::table('egc_payslips')->insertGetId([
            'staff_id'=>$staff->sno,
            'payroll_month'=>$month,
            'payroll_year'=>$year,
            'gross_salary'=>$earnings,
            'total_deductions'=>$deductions,
            'net_salary'=>$net,
            'created_at'=>now()
        ]);

        foreach($compData as $c){
            DB::table('egc_payslip_components')->insert([
                'payslip_id'=>$payslip_id,
                'component_id'=>$c['component_id'],
                'component_name'=>$c['component_name'],
                'type'=>$c['type'],
                'amount'=>$c['amount']
            ]);
        }

    }

    return response()->json(['status'=>200]);
}

public function getRuns()
{

$runs = DB::table('egc_payroll_runs')
->where('status',0)
->orderByDesc('sno')
->get();

return response()->json($runs);

}


public function getRunDetails($runId)
{

$data = DB::table('egc_payroll_entries as e')

->join('egc_staff as s','s.sno','=','e.staff_id')

->where('e.payroll_run_sno',$runId)

->select(

's.staff_name as name',
's.staff_id as staff_code',

'e.basic_salary',
'e.present_days',
'e.absent_days',

'e.lop_amount',
'e.pf_amount',
'e.pt_amount',
'e.esi_amount',
'e.net_salary'

)

->get();

return response()->json($data);

}


public function getPayslip($entryId)
{

    $data = DB::table('egc_payroll_entries_new as e')
            ->join('egc_staff as s','s.sno','=','e.staff_id')
            ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','e.payroll_run_sno')
            ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','s.sno')
            ->leftJoin('egc_company_bank_accounts as comp','comp.sno','=','s.salary_bank_id')
            ->where('e.sno',$entryId)
            ->select(
                's.staff_name as name',
                's.staff_id as staff_code',
                's.basic_salary',
                'b.bank_name',
                'b.bank_account_no as account_number',
                'e.created_at',
                's.company_id',
                'comp.company_id as salary_company_id',
                'e.net_salary',
                'e.total_earnings',
                'e.total_deductions',
                'egc_payroll_runs_new.payroll_month',
                'egc_payroll_runs_new.payroll_year',
            )
            ->first();

      
   
        $template = DB::table('egc_payslip_template')
            ->where('status', 0)
            ->where('company_id', $data->company_id)
            ->first();

        if ($template && $template->payslip_template) {
            $data->payslip_template_url = asset('settings/payslip_template/' . $template->payslip_template);
        } else {
            $data->payslip_template_url = asset('assets/egc_images/payslip_bg.jpg');
        }

        $components = DB::table('egc_payroll_entry_components_new')
        ->select(
            'egc_payroll_entry_components_new.amount',
            'egc_payroll_entry_components_new.type',
            'c.component_name',
            'c.calculation_type',
        )
        ->join('egc_salary_components as c','c.sno','=','egc_payroll_entry_components_new.component_id')
        ->where('egc_payroll_entry_components_new.payroll_entry_id',$entryId)
        ->get();

        $basicSalaryComponent = (object)[
            'amount' => $data->basic_salary,
            'type' => 'earning', // or whatever type you use for salary
            'component_name' => 'Basic Salary',
            'calculation_type' => 'fixed', // assuming fixed
        ];

        $components->prepend($basicSalaryComponent);

        //  $data->components = $components;
         $data->components = collect($components);

        return response()->json($data);

}

// public function getPayslip($entryId)
// {
//     $data = DB::table('egc_payroll_entries as e')
//         ->join('egc_staff as s','s.sno','=','e.staff_id')
//         ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','s.sno')
//         ->where('e.sno',$entryId)
//         ->select(
//             'e.*',
//             's.staff_name as name',
//             's.staff_id as staff_code',
//             'b.bank_name',
//             'b.bank_account_no as account_number'
//         )
//         ->first();

//     // 🔥 GET COMPONENTS
//     $components = DB::table('egc_payroll_entry_components')
//         ->where('payroll_entry_sno',$entryId)
//         ->get();

//     $earnings = [];
//     $deductions = [];

//     foreach($components as $comp){
//         if($comp->type == 'earning'){
//             $earnings[] = $comp;
//         }else{
//             $deductions[] = $comp;
//         }
//     }

//     $data->earnings = $earnings;
//     $data->deductions = $deductions;

//     return $data;
// }



public function downloadPDF($entryId)
{

    $data = $this->getPayslip($entryId)->getData();
    // return $data;
    return View('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);

// $pdf = PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);
// $pdf = PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_print', $data)
//           ->setPaper('a4', 'portrait')
//           ->setOptions([
//               'isHtml5ParserEnabled' => true,
//               'isRemoteEnabled' => true
//           ]);
// return $pdf->download('Payslip.pdf');

}

// public function downloadPDF($entryId)
// {
//     $data = $this->getPayslip($entryId)->getData();

//     $pdf = PDF::loadView(
//         'content.hr_management.hr_general.manage_payroll.payslip_print',
//         ['data' => $data]
//     )
//     ->setPaper('a4', 'portrait')
//     ->setOptions([
//         'isHtml5ParserEnabled' => true,
//         'isRemoteEnabled' => true,
//         'defaultFont' => 'DejaVu Sans'
//     ]);

//     return $pdf->download('Payslip.pdf');
// }

// public function PaySlipPrint($entryId){
   
//     $decrypt_entryId = decrypt($entryId);
   
//     // $data = $this->getPayslip($decrypt_entryId);
//     $data = $this->getPayslip($decrypt_entryId);
//     // return $data;
//     return View('content.hr_management.hr_general.manage_payroll.payslip_print',['data'=>$data]);

// }

public function PaySlipPrint($entryId)
{
    $decrypt_entryId = decrypt($entryId);
    $payroll_qr_verified_url = url("/payroll_qr_verified/{$entryId}");

    // Use the new function
    $data = $this->getPayslipData($decrypt_entryId);

    return view('content.hr_management.hr_general.manage_payroll.payslip_print', ['data' => $data, 'payroll_qr_verified_url' => $payroll_qr_verified_url]);
}

public function getPayslipData($entryId)
{
    
    $data = DB::table('egc_payroll_payslips as e')
        ->join('egc_staff as s','s.sno','=','e.employee_sno')
        ->join('egc_payroll_processes','egc_payroll_processes.sno','=','e.payroll_process_sno')
        ->join('egc_payroll_employee_payrolls','egc_payroll_employee_payrolls.sno','=','e.payroll_employee_sno')
        ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','s.sno')
        ->leftJoin('egc_company_bank_accounts as comp','comp.sno','=','s.salary_bank_id')
        ->leftJoin('egc_company as cm','cm.sno','=','s.salary_company_id')
        ->leftJoin('egc_company as staffComp','staffComp.sno','=','s.company_id')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')
        ->where('e.sno',$entryId)
        ->select(
            's.staff_name as name',
            's.company_type',
            's.staff_id as staff_code',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
            's.basic_salary',
            'b.bank_name',
            'b.bank_account_no as account_number',
            'e.generated_date as created_at',
            's.company_id',
            's.salary_company_id',
            'staffComp.company_name',
            'staffComp.company_base_color',
            'staffComp.company_logo',
            'staffComp.company_favicon',
            'cm.company_logo as salary_company_logo',
            'cm.company_favicon as salary_company_favicon',
            'cm.company_name as salary_company_name',
            'cm.company_base_color as salary_company_color',
            // 'comp.company_id as salary_company_id',
            'egc_payroll_employee_payrolls.gross_earnings',
            'egc_payroll_employee_payrolls.net_payable as net_salary',
            'egc_payroll_employee_payrolls.gross_earnings as total_earnings',
            'egc_payroll_employee_payrolls.gross_deductions as total_deductions',
            'egc_payroll_processes.payroll_month',
            'egc_payroll_processes.payroll_year',
        )
        ->first();


        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();

        // if($data->company_type == 1){
        //     $data->company_name=$general_setting->title;
        //     $data->company_base_color ='#ab2b22';
        //     $data->company_logo =$general_setting->logo;
        //     $data->company_favicon =$general_setting->fav_icon;

        // }

    $template = DB::table('egc_payslip_template')
        ->where('status', 0)
        ->where('company_id', $data->salary_company_id)
        ->first();

    $data->payslip_template_url = $template && $template->payslip_template
        ? asset('settings/payslip_template/' . $template->payslip_template)
        : asset('assets/egc_images/payslip_bg.jpg');

    $components = DB::table('egc_payroll_employee_payroll_details as ec')
        ->select('ec.actual_amount as amount', 'ec.component_category as type', 'c.component_name', 'c.calculation_type')
        ->join('egc_payroll_components as c','c.sno','=','ec.payroll_component_sno')
        ->where('ec.payroll_employee_sno',$entryId)
        ->get();

    // Add basic salary as a component
    // $basicSalaryComponent = (object)[
    //     'amount' => $data->basic_salary,
    //     'type' => 'earning',
    //     'component_name' => 'Basic Salary',
    //     'calculation_type' => 'fixed',
    // ];

    // $components->prepend($basicSalaryComponent);

    // Convert to collection (to allow where() in Blade)
    $data->components = collect($components);

    return $data;
}


public function verifyPayslip($entryId)
    {

        $decrypt_entryId = decrypt($entryId);

        $record = $this->getPayslipData($decrypt_entryId);

        if (!$record) {
            return view('verify.invalid');
        }
        
        return view('content.hr_management.hr_general.manage_payroll.verify_payslip', compact('record'));
    }

}