<?php

namespace App\Http\Controllers\hr_management\hr_general;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewCandidateModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewQuestionModel;
use App\Models\JobQRScannerModel;
use App\Models\ApplicantLogModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use App\Models\SourceModel;
use App\Models\MajorModel;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Services\GoogleDriveService;
use Google\Client;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\SocialMediaModel;
use App\Models\CompanyModel;
use PDF;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\PayrollExport;

class ManagePayroll extends Controller
{

   protected $googleDriveService;
    public function __construct(GoogleDriveService $googleDriveService)
    {
        $this->googleDriveService = $googleDriveService;
         date_default_timezone_set('Asia/Kolkata');
    }
    
    public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $company_fill = $request->company_fill ?? 'egc';
        $entity_fill = $request->entity_fill ?? '0';
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

        // ------------------ MONTH PARSING ------------------
        $month_filter = $request->get('month_filter', date('M-Y'));
        // return  $month_filter;
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
         
        // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
        // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

        $month = $parsedDate->month ?? date('m');
      
        $year  = $parsedDate->year ?? date('Y');
       
        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

       
        $pfPercentage = $helper->payroll_setting('pf_percentage');
        $pfDeductionAmount = $helper->payroll_setting('pf_deduction_amount');
        $PTDeductionAmount = $helper->payroll_setting('pt_deduction_amount');
        $esiPercentage = $helper->payroll_setting('esi_percentage');
        $esiLimit = $helper->payroll_setting('esi_salary_limit');

        $staff = DB::table('egc_staff as s')
        ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){
        $join->on('a.staff_id','=','s.sno')
        ->whereMonth('a.date',$month)
        ->whereYear('a.date',$year)
        ->where('a.status',0);
        })
        ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')

            ->where('s.role_id','!=',1)
            ->where('s.status',0)
            ->select(
                's.sno',
                's.staff_name as name',
                's.staff_id as staff_code',
                's.basic_salary',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_id',
                's.company_type',
                's.entity_id',
                's.gender',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',
                's.per_day_salary',
                's.casual_leave_count_per_month',
                DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
                DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),
                DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),
                DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
                DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
                // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
                // DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")
            );

            if($company_fill !== ""){
                if($company_fill == 'egc'){
                    $staff->where('s.company_type',1);
                } else {
                    if($entity_fill !== ""){
                        $staff->where('s.entity_id', $entity_fill);
                    }
                }
            }

            if ($search_filter != '') {
                $staff->where(function ($subquery) use ($search_filter) {
                    $subquery->where('s.staff_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.nick_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.mobile_no', 'LIKE', "%{$search_filter}%");
                        
                });
            }
            
            $staff=$staff->groupBy(
                        's.sno',
                        's.staff_id',
                        's.staff_name',
                        's.basic_salary',
                        's.nick_name',
                        's.mobile_no',
                        's.staff_image',
                        's.company_id',
                        's.company_type',
                        's.entity_id',
                        's.gender',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_name',
                        'egc_company.company_base_color',
                        'egc_department.department_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name',
                        's.per_day_salary',
                        's.casual_leave_count_per_month',
                    )
                    ->orderBy('s.staff_id', 'desc')
                    ->paginate($perpage);
        // return $staff;
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $staff->map(function ($item) use ($helper,$month,$year,$pfPercentage,$pfDeductionAmount,$PTDeductionAmount, $esiLimit, $esiPercentage) {

            $absentDays = $item->absent_days ?? 0;

            // $lateCount = DB::table('egc_staff_attendance')
            //     ->where('staff_id',$item->sno)
            //     ->whereMonth('date',$month)
            //     ->whereYear('date',$year)
            //     ->where('status',0)
            //     ->whereNotNull('in_time')
            //     ->whereTime('in_time','>','09:30:00')
            //     ->count();

            // $lateCount = DB::table('egc_staff_attendance as att')
            // ->join('egc_staff as s','s.sno','=','att.staff_id')
            // ->join('egc_shift_day_times as sd','sd.shift_id','=','s.shift_time_id')
            // ->where('att.staff_id',$item->sno)
            // ->whereMonth('att.date',$month)
            // ->whereYear('att.date',$year)
            // ->where('att.status',0)
            // ->where('sd.status',0)
            // ->whereNotNull('att.in_time')
            // ->whereRaw("LOWER(sd.day_name) = LOWER(LEFT(DAYNAME(att.date),3))")
            // ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
            //     ->count();
            $lateCount = DB::table('egc_staff_attendance as att')
                ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')
                ->join('egc_shift_time_log as stl', function ($join) {
                    $join->on('stl.staff_id', '=', 'att.staff_id');
                })
                ->join('egc_shift_day_times as sd', function ($join) {
                    $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                        ->where('sd.status', 0);
                })
                ->where('att.staff_id', $item->sno)
                ->whereMonth('att.date', $month)
                ->whereYear('att.date', $year)
                ->where('att.status', 0)
                ->whereNotNull('att.in_time')
                // ✅ Match shift date range
                ->whereRaw("DATE(att.date) BETWEEN stl.start_date AND IFNULL(stl.end_date, '9999-12-31')")
                // ✅ Match day (Mon, Tue...)
                ->whereRaw("LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))")
                // ✅ Late condition
                // ->whereRaw("TIME(att.in_time) > TIME(sd.time_from)")
                // ->whereRaw("
                //     TIME_FORMAT(att.in_time, '%H:%i') > 
                //     TIME_FORMAT(ADDTIME(sd.time_from, '00:05:00'), '%H:%i')
                // ")
                // ->whereRaw("
                //     TIME_FORMAT(att.in_time, '%H:%i') > TIME_FORMAT(sd.time_from, '%H:%i')
                // ")
                ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:11:00')")
                ->count();
            $allowedLeave = $item->casual_leave_count_per_month ?? 0;
            $lateAllowed = $helper->payroll_setting('late_allowed_per_month');
            $lopPerLate = $helper->payroll_setting('lop_per_late');

            // return  $allowedLeave ;

            // $lopDays = max(0,$absent - $allowedLeave);

            // absent LOP
            $absentLopDays = max(0, $absentDays - $allowedLeave);

            // late LOP
            $extraLate = max(0, $lateCount - $lateAllowed);
            $lateLopDays = $extraLate * $lopPerLate;

            // total LOP
            $totalLopDays = $absentLopDays + $lateLopDays;

            // LOP amount
            $lopAmount = $totalLopDays * $item->per_day_salary;
            // $lopAmount = $lopDays * $item->per_day_salary;
          
            $pfAmount = $pfDeductionAmount ? $pfDeductionAmount : ($item->basic_salary * $pfPercentage)/100;
            $esiAmount = 0;
            $ptAmount =$PTDeductionAmount ?? 0;
            if($esiLimit){
                if($item->basic_salary <= $esiLimit)
                $esiAmount = ($item->basic_salary * $esiPercentage)/100;
            }else{
                $esiAmount = ($item->basic_salary * $esiPercentage)/100;
            }
           
            $netSalary = $item->basic_salary - ($lopAmount + $pfAmount + $esiAmount +$ptAmount);
            $entry = DB::table('egc_payroll_entries')
            ->select('egc_payroll_entries.sno')
                ->join('egc_payroll_runs','egc_payroll_runs.sno','=','egc_payroll_entries.payroll_run_sno')
                ->where('egc_payroll_entries.staff_id',$item->sno)
                ->where('egc_payroll_runs.payroll_month',$month)
                ->where('egc_payroll_runs.payroll_year',$year)
                ->first();
            $isSaved = $entry ? true : false;
            $entryId = $entry->sno ?? null;
            // return $lateCount;

                return [
                    'sno' => $item->sno,
                    'name'=>$item->name,
                    'staff_id'=>$item->staff_code,
                    'basic_salary'=>$item->basic_salary,
                    'present_days'=>$item->present_days ?? 0,
                    'absent_days'=>$absentDays,
                    'leave_days'=>$item->leave_days ?? 0,
                    'permission_days'=>$item->permission_days ?? 0,
                    'onduty_days'=>$item->onduty_days ?? 0,
                    'late_count'=>$lateCount,
                    'lop_days'=>$totalLopDays,
                    'lop_amount'=>$lopAmount,
                    'pf_amount'=>$pfAmount,
                    'ptAmount'=>$ptAmount,
                    'esi_amount'=>$esiAmount,
                    'is_saved'=>$isSaved,
                    'entry_id'=>$entryId,
                    'net_salary'=>$netSalary,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    'base_encrypt' => encrypt($item->sno),
                    'entry_encrypt' => encrypt($entryId),
                    'short_encrypt_id' => base64_encode($item->sno),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'total' => $staff->total(),
            ]);
        }
        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = CompanyModel::where('status',0)->get();
        return view('content.hr_management.hr_general.manage_payroll.payroll_list', [
            'staff' => $staff,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'company_list' => $company_list,
            'source_list' => $source_list,
            'company_fill ' => $company_fill ,
        ]);
    }

    
    public function indexNew(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';
        $search_filter = $request->search_filter ?? '';
        $salary_date_fill = $request->salary_date_fill ?? '';
        $salary_type_fill = $request->salary_type_fill ?? '';

        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

        // ------------------ MONTH PARSING ------------------
        $month_filter = $request->get('month_filter', date('M-Y'));
        // return  $month_filter;
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
         
        // $month_filter = $request->get('month_filter', date('m-Y'));  // Default to numeric month (11-2025)
        // $parsedDate = Carbon::createFromFormat('m-Y', $month_filter);

        $month = $parsedDate->month ?? date('m');
      
        $year  = $parsedDate->year ?? date('Y');

        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

        // Limit end date to today if month is current
        if ($today->between($startDate, $endDate)) {
            $endDate = $today;
        }


        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })->get();

        $holidayDates = collect();
        foreach($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;
            foreach(CarbonPeriod::create($start, $end) as $d){
                $holidayDates->push($d->format('Y-m-d'));
            }
        }
        $holidayDates = $holidayDates->unique();
       
        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();
        $pfPercentage = $helper->payroll_setting('pf_percentage');
        $pfDeductionAmount = $helper->payroll_setting('pf_deduction_amount');
        $PTDeductionAmount = $helper->payroll_setting('pt_deduction_amount');
        $esiPercentage = $helper->payroll_setting('esi_percentage');
        $esiLimit = $helper->payroll_setting('esi_salary_limit');

        $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));

        $staff = DB::table('egc_staff as s')
        ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){
        $join->on('a.staff_id','=','s.sno')
        ->whereMonth('a.date',$month)
        ->whereYear('a.date',$year)
        ->where('a.status',0);
        })
        ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')

            ->where('s.role_id','!=',1)
            ->whereDate('s.date_of_joining', '<=', $endOfMonth)
            ->where('s.status',0)
            ->select(
                's.sno',
                's.staff_name',
                's.staff_id as staff_code',
                's.basic_salary',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_id',
                's.company_type',
                's.entity_id',
                's.gender',
                's.salary_type',
                's.salary_date',
                's.date_of_joining',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',
                's.per_day_salary',
                's.casual_leave_count_per_month',
                // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
                DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),
                DB::raw("
                    SUM(
                        CASE 
                            WHEN a.attendance IN ('P','OD','PR') THEN 1
                            WHEN a.attendance = 'L' AND a.leave_type IN ('first_half','second_half') THEN 0.5
                            ELSE 0
                        END
                    ) as present_days
                "),

                DB::raw("
                    SUM(
                        CASE 
                            WHEN a.attendance = 'L' AND a.leave_type = 'full' THEN 1
                            WHEN a.attendance = 'L' AND a.leave_type IN ('first_half','second_half') THEN 0.5
                            ELSE 0
                        END
                    ) as leave_days
                "),
                // DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),
                DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
                DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
            );

            

            if ($search_filter != '') {
                $staff->where(function ($subquery) use ($search_filter) {
                    $subquery->where('s.staff_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.nick_name', 'LIKE', "%{$search_filter}%")
                        ->orWhere('s.mobile_no', 'LIKE', "%{$search_filter}%");
                        
                });
            }

            if($company_fill != ''){
                if($company_fill == 'egc'){
                    $staff->where('s.company_type',1);
                }else{
                    $staff->where('s.company_id', 'LIKE', $company_fill);
                }
                
            }

            if ($entity_fill) {
                $staff->where('s.entity_id', $entity_fill);
            }

            if ($salary_date_fill) {
                $staff->where('s.salary_date', $salary_date_fill);
            }
            if ($salary_type_fill) {
                $staff->where('s.salary_type', $salary_type_fill);
            }

            
            if ($department_fill) {
                $staff->where('s.department_id', $department_fill);
            }

            // if ($division_fill) {
            //     $staff->where('s.division_id', $division_fill);
            // }

            // if ($job_role_fill) {
            //   $staff->where('s.job_role_id', $job_role_fill);
            // }
            $today = date('Y-m-d');
            if ($date_filter == "today") {
                $todayDate = date("Y-m-d");
                $staff->whereDate('s.date_of_joining', $todayDate);
            } elseif ($date_filter == "week") {
                $today = date('l');
                if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
                } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
                }
                $staff->whereBetween('s.date_of_joining', [$weekFromDate, $weekToDate]);
            } elseif ($date_filter == "monthly") {
                $firstDayOfMonth = date('Y-m-01');
                $lastDayOfMonth = date('Y-m-t');
                $staff->whereBetween('s.date_of_joining', [$firstDayOfMonth, $lastDayOfMonth]);
            } elseif ($date_filter == "custom_date") {
                if ($from_date_filter && $to_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $staff->whereBetween('s.date_of_joining', [$fromDate, $toDate]);
                } elseif ($from_date_filter) {
                $fromDate = date('Y-m-d', strtotime($from_date_filter));
                $staff->where('s.date_of_joining', '>=', $fromDate);
                } elseif ($to_date_filter) {
                $toDate = date('Y-m-d', strtotime($to_date_filter));
                $staff->where('s.date_of_joining', '<=', $toDate);
                }
            }elseif ($date_filter == "0_2_months"){
                $startDate = date('Y-m-d', strtotime('-2 months'));
                $staff->whereBetween('s.date_of_joining', [$startDate, $today]);
            }elseif ($date_filter == "2_4_months"){
                $startDate = date('Y-m-d', strtotime('-4 months'));
                $endDate = date('Y-m-d', strtotime('-2 months'));
                $staff->whereBetween('s.date_of_joining', [$startDate, $endDate]);
            }elseif ($date_filter == "4_6_months"){
                $startDate = date('Y-m-d', strtotime('-6 months'));
                $endDate = date('Y-m-d', strtotime('-4 months'));
                $staff->whereBetween('s.date_of_joining', [$startDate, $endDate]);
            }elseif ($date_filter == "6_12_months"){
                $startDate = date('Y-m-d', strtotime('-12 months'));
                $endDate = date('Y-m-d', strtotime('-6 months'));
                $staff->whereBetween('s.date_of_joining', [$startDate, $endDate]);
            }elseif ($date_filter == "1_2_years"){
                $startDate = date('Y-m-d', strtotime('-2 years'));
                $endDate = date('Y-m-d', strtotime('-1 year'));
                $staff->whereBetween('s.date_of_joining', [$startDate, $endDate]);

            }elseif ($date_filter == "gt_2_years"){
                $endDate = date('Y-m-d', strtotime('-2 years'));
                $staff->where('s.date_of_joining', '<=', $endDate);
            }elseif ($date_filter == "gt_1_year"){
                $endDate = date('Y-m-d', strtotime('-1 year'));
                $staff->where('s.date_of_joining', '<=', $endDate);
            }elseif ($date_filter == "gt_6_months"){
                $endDate = date('Y-m-d', strtotime('-6 months'));
                $staff->where('s.date_of_joining', '<=', $endDate);
            }
            
            $staff=$staff->groupBy(
                        's.sno',
                        's.staff_id',
                        's.staff_name',
                        's.basic_salary',
                        's.nick_name',
                        's.mobile_no',
                        's.staff_image',
                        's.company_id',
                        's.company_type',
                        's.entity_id',
                        's.gender',
                        's.salary_type',
                        's.salary_date',
                        's.date_of_joining',
                        'egc_entity.entity_name',
                        'egc_entity.entity_short_name',
                        'egc_company.company_name',
                        'egc_company.company_base_color',
                        'egc_department.department_name',
                        'egc_division.division_name',
                        'egc_job_role.job_position_name',
                        's.per_day_salary',
                        's.casual_leave_count_per_month',
                    )
                    ->orderBy('s.date_of_joining', 'desc');
                    $allStaffIds = $staff->pluck('s.sno');
                    $staffQuery = clone $staff;
                    $staff= $staff->paginate($perpage);
            
                    $is_payroll_saved = DB::table('egc_payroll_runs_new')
                        ->where('egc_payroll_runs_new.payroll_month',$month)
                        ->where('egc_payroll_runs_new.payroll_year',$year)
                        ->where('egc_payroll_runs_new.status',0)
                        ->exists();

         // ------------------ SHIFT LOGS & ATTENDANCE ------------------
            $allShiftLogs = DB::table('egc_shift_time_log as stl')
                ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
                ->whereIn('stl.staff_id', $allStaffIds)
                ->where('sdt.status', 0)
                ->select('stl.staff_id', 'stl.start_date', 'stl.end_date', 'sdt.day_name')
                ->orderBy('stl.start_date')
                ->get()
                ->groupBy('staff_id');

            $attendanceRecords = DB::table('egc_staff_attendance')
                ->whereIn('staff_id', $allStaffIds)
                ->whereBetween('date', [$startDate, $endDate])
                ->where('status', 0)
                ->get()
                ->groupBy('staff_id')
                ->map(fn($items) => $items->keyBy('date'));
        
        
        // return $staff;
        $totalGrossSalary = 0;
        $totalDeduction = 0;
        $totalNetSalary = 0;
        $allStaff = $staffQuery->get();
        $overallPayrollData = [];
        $earningsSummary = [];
        $deductionsSummary = [];
        $componentSummary = [];
        foreach ($allStaff as $item) {
            $presentDays = $item->present_days ?? 0;
            $absentDays = $item->absent_days ?? 0;
            $leaveDays = $item->leave_days ?? 0;
            $permissionDays = $item->permission_days ?? 0;
            $ondutyDays = $item->onduty_days ?? 0;

            $holidayCount = 0;
            $weekOffCount = 0;

            $staffShift = $allShiftLogs[$item->sno] ?? collect();
            foreach(CarbonPeriod::create(Carbon::create($year, $month, 1), Carbon::create($year, $month, 1)->endOfMonth()) as $d){
                $dateKey = $d->format('Y-m-d');

                if($holidayDates->contains($dateKey)) {
                    $holidayCount++;
                    continue;
                }

                $dayName = strtolower($d->format('D'));
                $shift = $staffShift->firstWhere('day_name', $dayName);
                if(!$shift) $weekOffCount++;
            }
                $item->weekOffCount =$weekOffCount;
                $item->holidayCount =$holidayCount;
                $totalPresentEarningWithoutWK= $presentDays+$permissionDays+$ondutyDays+$holidayCount;
                $totalSalaryEarning=$presentDays+$permissionDays+$ondutyDays+$holidayCount+$weekOffCount;
                $item->salary_earning_days=$totalSalaryEarning;
                $item->salary_earning_days_not_wk=$totalPresentEarningWithoutWK;
            $dataParoll = $this->calculatePayroll($item, $month, $year,$holidayDates, $allShiftLogs, $attendanceRecords);

            $overallPayrollData[] = $dataParoll;

            $totalGrossSalary += $dataParoll['earnings'] ?? 0;
            $totalDeduction += $dataParoll['deductions'] ?? 0;
            $totalNetSalary += $dataParoll['net'] ?? 0;
        }

        foreach ($overallPayrollData as $payroll) {
            if (!isset($payroll['components'])) continue;

            foreach ($payroll['components'] as $component) {
                $name = $component['name'];
                $type = $component['type']; // earning or deduction
                $amount = $component['amount'];

                if (!isset($componentSummary[$name])) {
                    $componentSummary[$name] = [
                        'name' => $name,
                        'type' => $type,
                        'total' => 0
                    ];
                }

                $componentSummary[$name]['total'] += $amount;
            }
        }

        foreach ($componentSummary as $comp) {
            if ($comp['type'] === 'earning') {
                $earningsSummary[] = $comp;
            } else {
                $deductionsSummary[] = $comp;
            }
        }
       
        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();

        if ($request->ajax()) {
            $data = $staff->map(function ($item) use ($helper,$month,$year,$pfPercentage,$pfDeductionAmount,$PTDeductionAmount, $esiLimit, $esiPercentage,$general_setting,&$totalGrossSalary,&$totalDeduction,&$totalNetSalary, $holidayDates, $allShiftLogs, $attendanceRecords) {

            // $absentDays = $item->absent_days ?? 0;
                $presentDays = $item->present_days ?? 0;
                $absentDays = $item->absent_days ?? 0;
                $leaveDays = $item->leave_days ?? 0;
                $permissionDays = $item->permission_days ?? 0;
                $ondutyDays = $item->onduty_days ?? 0;

                $holidayCount = 0;
                $weekOffCount = 0;

                $staffShift = $allShiftLogs[$item->sno] ?? collect();
                foreach(CarbonPeriod::create(Carbon::create($year, $month, 1), Carbon::create($year, $month, 1)->endOfMonth()) as $d){
                    $dateKey = $d->format('Y-m-d');

                    if($holidayDates->contains($dateKey)) {
                        $holidayCount++;
                        continue;
                    }

                    $dayName = strtolower($d->format('D'));
                    $shift = $staffShift->firstWhere('day_name', $dayName);
                    if(!$shift) $weekOffCount++;
                }
                 $item->weekOffCount =$weekOffCount;
                 $item->holidayCount =$holidayCount;
                 $totalPresentEarningWithoutWK= $presentDays+$permissionDays+$ondutyDays+$holidayCount;
                 $totalSalaryEarning=$presentDays+$permissionDays+$ondutyDays+$holidayCount+$weekOffCount;
                 $item->salary_earning_days=$totalSalaryEarning;
                 $item->salary_earning_days_not_wk=$totalPresentEarningWithoutWK;

            $dataParoll= $this->calculatePayroll($item,$month,$year,$holidayDates, $allShiftLogs, $attendanceRecords);

            // $totalGrossSalary += $dataParoll['earnings'] ?? 0;
            // $totalDeduction += $dataParoll['deductions'] ?? 0;
            // $totalNetSalary += $dataParoll['net'] ?? 0;

           if ($item->company_type == 1) {
                $filePath = public_path('staff_images/Management/' . $item->staff_image);
            } else {
                $filePath = public_path('staff_images/Buisness/' . $item->company_id . '/' . $item->entity_id . '/' . $item->staff_image);
            }

            $isStaffImage = $item->staff_image != '' && file_exists($filePath) ? 1 : 0;

            $components = DB::table('egc_staff_salary_components_new as ssc')
                ->join('egc_salary_components as pc', 'pc.sno', '=', 'ssc.component_id')
                ->where('ssc.staff_id', $item->sno)
                ->where('ssc.status', 0)
                ->select(
                    'pc.component_name',
                    'pc.type as component_type',
                    'pc.calculation_type',
                    'ssc.amount',
                )
                ->get();

            $entry = DB::table('egc_payroll_entries_new')
                ->select('egc_payroll_entries_new.sno')
                    ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','egc_payroll_entries_new.payroll_run_sno')
                    ->where('egc_payroll_entries_new.staff_id',$item->sno)
                    ->where('egc_payroll_runs_new.payroll_month',$month)
                    ->where('egc_payroll_runs_new.payroll_year',$year)
                    ->first();

            // $components = DB::table('egc_payroll_entry_components_new as c')
            //     ->join('egc_salary_components as sc','sc.sno','=','c.component_id')
            //     ->where('c.payroll_entry_id',$id)
            //     ->select('sc.component_name as name','c.amount')
            //     ->get();

                $isSaved = $entry ? true : false;
                $entryId = $entry->sno ?? null;

                $lateCount = DB::table('egc_staff_attendance as att')
                    ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

                    ->join('egc_shift_time_log as stl', function ($join) {
                        $join->on('stl.staff_id', '=', 'att.staff_id');
                    })

                    ->join('egc_shift_day_times as sd', function ($join) {
                        $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                            ->where('sd.status', 0);
                    })
                    ->where('att.staff_id', $item->sno)
                    // 👉 Month filter
                    ->whereMonth('att.date', $month)
                    ->whereYear('att.date', $year)
                    ->where('att.status', 0)
                    ->whereNotNull('att.in_time')
                    // ✅ JOINING DATE CHECK
                    ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")
                    // ✅ SHIFT DATE RANGE CHECK
                    ->whereRaw("
                        DATE(att.date) BETWEEN stl.start_date 
                        AND IFNULL(stl.end_date, '9999-12-31')
                    ")
                    // ✅ DAY MATCH (Mon, Tue...)
                    ->whereRaw("
                        LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
                    ")
                    // ✅ LATE CHECK
                    // ->whereRaw("
                    //     TIME(att.in_time) > TIME(sd.time_from)
                    // ")
                    ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:11:00')")
                    ->count();
            // return $lateCount;

                    if($item->company_type == 1){
                        $item->company_name=$general_setting->title;
                        $item->company_base_color ='#ab2b22';
                    }


                return [
                    'sno' => $item->sno,
                    'name'=>$item->staff_name,
                    'isStaffImage'=>$isStaffImage,
                    'company_name'=>$item->company_name,
                    'company_base_color'=>$item->company_base_color,
                    'present_days'=>$item->present_days ?? 0,
                    'absent_days'=>$absentDays,
                    'leave_days'=>$item->leave_days ?? 0,
                    'permission_days'=>$item->permission_days ?? 0,
                    'onduty_days'=>$item->onduty_days ?? 0,
                    'late_count'=>$lateCount,
                    'staff_id'=>$item->staff_code,
                    'basic_salary'=>$item->basic_salary,
                    'dataParoll' => $dataParoll,
                    'is_saved'=>$isSaved,
                    'entry_id'=>$entryId,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                    'base_encrypt' => encrypt($item->sno),
                    'entry_encrypt' => encrypt($entryId),
                    'short_encrypt_id' => base64_encode($item->sno),
                ];
            });

            return response()->json([
                'data' => $data,
                'is_payroll_saved' => $is_payroll_saved,
                'deductions_summary' => $deductionsSummary,
                'earnings_summary' => $earningsSummary,
                'total_gross_salary' => $totalGrossSalary,
                'total_deduction' => $totalDeduction,
                'total_net_salary' => $totalNetSalary,
                'current_page' => $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'total' => $staff->total(),
            ]);
        }
        $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $company_list = CompanyModel::where('status',0)->get();

        $payslipCount =DB::table('egc_staff')->where('status',0)->where('is_payslip',1)->count();
        return view('content.hr_management.hr_general.manage_payroll.payroll_list_new', [
            'staff' => $staff,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
            'company_list' => $company_list,
            'source_list' => $source_list,
            'company_fill' => $company_fill ,
            'payslipCount' => $payslipCount ,
        ]);
    }
    
 public function Payslip($id,Request $request)
  {
    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      
     
      return view('content.hr_management.hr_general.manage_payroll.payslip_print', [
          
      ]);
  }

public function create(Request $r)
{
    DB::table('egc_payroll_runs')
        ->insert([
        'payroll_month'=>$r->payroll_month,
        'payroll_year'=>$r->payroll_year,
        'run_status'=>'DRAFT',
        'created_by'=>$r->user()->user_id ?? 1
        ]);

    return response()->json(['status'=>true]);

}


public function process($runSno,Request $r)
{

    DB::transaction(function() use($runSno,$r){
        try{
            $run=DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->first();


            $employees=DB::table('egc_staff_payroll_profile')
            ->where('status','0')
            ->get();
            
            foreach($employees as $emp){

                $employeeSno=$emp->staff_id;
              
                // get salary structure
                $mapping=DB::table('egc_staff_salary_mapping')
                ->where('staff_id',$employeeSno)
                ->whereNull('effective_to')
                ->first();
                 
                if(!$mapping) continue;

                $components=DB::table('egc_salary_structure_components')
                ->where('salary_structure_sno',
                $mapping->salary_structure_sno)
                ->get();
                  
                $gross=0;
                $deduction=0;

                // create payroll entry

                $entryId=DB::table('egc_payroll_entries')
                            ->insertGetId([
                                'payroll_run_sno'=>$runSno,
                                'staff_id'=>$employeeSno,
                                'gross_salary'=>0,
                                'total_deductions'=>0,
                                'net_salary'=>0,
                                'created_by'=>$r->user()->user_id ?? 1
                            ]);

            // return $entryId;

                foreach($components as $c){

                    $amount=$c->value;
                    $type=DB::table('egc_pay_components')
                    ->where('sno',$c->component_sno)
                    ->value('component_type');
                    DB::table('egc_payroll_entry_components')
                        ->insert([
                            'payroll_entry_sno'=>$entryId,
                            'component_sno'=>$c->component_sno,
                            'amount'=>$amount,
                            'created_by'=>$r->user()->user_id ?? 1
                        ]);

                    if($type=='EARNING'){
                        $gross+=$amount;
                    }else{
                        $deduction+=$amount;
                    }
                
                }
                $net=$gross-$deduction;
                DB::table('egc_payroll_entries')
                    ->where('sno',$entryId)
                    ->update([
                        'gross_salary'=>$gross,
                        'total_deductions'=>$deduction,
                        'net_salary'=>$net
                    ]);
            }

            // finalize
            DB::table('egc_payroll_runs')
            ->where('sno',$runSno)
            ->update([
                'run_status'=>'FINALIZED'
            ]);
        }catch(\Exception $e){
            return response()->json([
                'status'=>false,
                'message'=>'Error processing payroll: '.$e->getMessage()
            ]);
        }
    });

    return response()->json([
    'status'=>true,
    'message'=>'Payroll processed successfully'
    ]);

}


public function indexPayslip()
{

    $payslips=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'e.sno',
            'emp.staff_name as employee_name',
            'emp.staff_id as employee_code',
            'r.payroll_month',
            'r.payroll_year',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary'
        )
        ->get();

    return view('content.hr_management.hr_general.manage_payroll.payslips',compact('payslips'));
}


public function viewpayslip ($entrySno)
{

    $data=$this->getPayslipData($entrySno);

    return view('content.hr_management.hr_general.manage_payroll.payslip_view',$data);

}


public function pdfpayslip($entrySno,Request $r)
{

    $data=$this->getPayslipData($entrySno);

    $pdf=PDF::loadView('content.hr_management.hr_general.manage_payroll.payslip_pdf',$data);

    DB::table('egc_payslip_logs')
    ->insert([
    'payroll_entry_sno'=>$entrySno,
    'generated_at'=>now(),
    'generated_by'=>$r->user()->user_id ?? 1
    ]);

    return $pdf->download('payslip.pdf');

}


private function getPayslipData($entrySno)
{

    $entry=DB::table('egc_payroll_entries as e')
        ->leftJoin('egc_staff as emp','emp.sno','=','e.staff_id')
        ->leftJoin('egc_staff_bank_details as b','b.staff_id','=','emp.sno')
        ->leftJoin('egc_payroll_runs as r','r.sno','=','e.payroll_run_sno')
        ->select(
            'emp.staff_name as name',
            'emp.staff_id as employee_code',
            'b.bank_account_no',
            'b.bank_name',
            'e.gross_salary',
            'e.total_deductions',
            'e.net_salary',
            'r.payroll_month',
            'r.payroll_year'
        )
        ->where('e.sno',$entrySno)
        ->first();


    $components=DB::table('egc_payroll_entry_components as c')
        ->leftJoin('egc_pay_components as p',
        'p.sno','=','c.component_sno')
        ->select(
            'p.component_name',
            'p.component_type',
            'c.amount'
        )
        ->where('c.payroll_entry_sno',$entrySno)
        ->get();

    return [
        'entry'=>$entry,
        'components'=>$components
    ];

}


public function getPreviewData(Request $request)
{

    $month = $request->month;
    $year = $request->year;
    $helper = new \App\Helpers\Helpers();
    $pfPercentage = $helper->payroll_setting('pf_percentage');
    $esiPercentage = $helper->payroll_setting('esi_percentage');
    $esiLimit = $helper->payroll_setting('esi_salary_limit');
    $pfDeductionAmount = $helper->payroll_setting('pf_deduction_amount');
    $PTDeductionAmount = $helper->payroll_setting('pt_deduction_amount');

    $staff = DB::table('egc_staff as s')

    ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){

    $join->on('a.staff_id','=','s.sno')
    ->whereMonth('a.date',$month)
    ->whereYear('a.date',$year)
    ->where('a.status',0);

    })

    ->where('s.status',0)
    ->where('s.role_id','>',1)

    ->select(

    's.sno',
    's.staff_name as name',
    's.staff_id as staff_code',
    's.basic_salary',
    's.per_day_salary',
    's.casual_leave_count_per_month',
    DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

    DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),

    DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),

    DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),

    DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
    // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),

    // DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")

    )

    ->groupBy('s.sno','s.staff_id','s.staff_name','s.basic_salary','s.per_day_salary','s.casual_leave_count_per_month',)

    ->get();




    $data = [];

    foreach($staff as $row)
    {

    $absentDays = $row->absent_days ?? 0;
    $lateCount = DB::table('egc_staff_attendance')
        ->where('staff_id',$row->sno)
        ->whereMonth('date',$month)
        ->whereYear('date',$year)
        ->where('status',0)
        ->whereNotNull('in_time')
        ->whereTime('in_time','>','09:30:00')
        ->count();

    $allowedLeave = $row->casual_leave_count_per_month ?? 0;
    $lateAllowed = $helper->payroll_setting('late_allowed_per_month');
    $lopPerLate = $helper->payroll_setting('lop_per_late');
    // $lopDays = max(0,$absent - $allowedLeave);

    // absent LOP
    $absentLopDays = max(0, $absentDays - $allowedLeave);


    // late LOP
    $extraLate = max(0, $lateCount - $lateAllowed);

    $lateLopDays = $extraLate * $lopPerLate;


    // total LOP
    $totalLopDays = $absentLopDays + $lateLopDays;


        // LOP amount
        $lopAmount = $totalLopDays * $row->per_day_salary;

        // $lopAmount = $lopDays * $row->per_day_salary;

        // $pfAmount = ($row->basic_salary * $pfPercentage)/100;

        $pfAmount = $pfDeductionAmount ? $pfDeductionAmount : ($row->basic_salary * $pfPercentage)/100;

        $esiAmount = 0;
        $ptAmount =$PTDeductionAmount ?? 0;
        if($esiLimit){
            if($row->basic_salary <= $esiLimit)
            $esiAmount = ($row->basic_salary * $esiPercentage)/100;
        }else{
            $esiAmount = ($row->basic_salary * $esiPercentage)/100;
        }


    // if($row->basic_salary <= $esiLimit)
    // $esiAmount = ($row->basic_salary * $esiPercentage)/100;

    $netSalary = $row->basic_salary - ($lopAmount + $pfAmount + $esiAmount + $ptAmount);

    $entry = DB::table('egc_payroll_entries')
        ->join('egc_payroll_runs','egc_payroll_runs.sno','=','egc_payroll_entries.payroll_run_sno')
        ->where('egc_payroll_entries.staff_id',$row->sno)
        ->where('egc_payroll_runs.payroll_month',$month)
        ->where('egc_payroll_runs.payroll_year',$year)
        ->first();

    $isSaved = $entry ? true : false;

    $entryId = $entry->sno ?? null;

    $data[] = [

    'staff_id'=>$row->sno,
    'name'=>$row->name,
    'staff_code'=>$row->staff_code,

    'basic_salary'=>$row->basic_salary,

    'present_days'=>$row->present_days ?? 0,

    'absent_days'=>$absentDays,

    'leave_days'=>$row->leave_days ?? 0,

    'permission_days'=>$row->permission_days ?? 0,

    'onduty_days'=>$row->onduty_days ?? 0,

    'late_count'=>$lateCount,

    'lop_days'=>$totalLopDays,

    'lop_amount'=>$lopAmount,

    'pf_amount'=>$pfAmount,

    'pt_amount'=>$ptAmount,

    'esi_amount'=>$esiAmount,

    'is_saved'=>$isSaved,
    'entry_id'=>$entryId,

    'net_salary'=>$netSalary

    ];

    }

    return response()->json($data);

}

public function savePayroll(Request $request)
{

    $month_filter = $request->month_filter;
    $month = $request->month;
    $year = $request->year;

    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
    $month = $parsedDate->month ?? date('m');
    $year  = $parsedDate->year ?? date('Y');
// return $request;

// prevent duplicate save

$exists = DB::table('egc_payroll_runs')

->where('payroll_month',$month)
->where('payroll_year',$year)
->where('status',0)
->exists();

if($exists)
{

return response()->json([
'status'=>false,
'message'=>'Payroll already saved for this month'
]);

}


DB::beginTransaction();

try {


// create payroll run

$runId = DB::table('egc_payroll_runs')

->insertGetId([

'payroll_month'=>$month,
'payroll_year'=>$year,
'run_type'=>'MANUAL',
'created_by'=>auth()->id()

]);


// get preview data using same logic

$preview = $this->getPreviewData($request)->getData();

// return $preview; 
foreach($preview as $row)
{


$entryId = DB::table('egc_payroll_entries')

->insertGetId([

'payroll_run_sno'=>$runId,

'staff_id'=>$row->staff_id,

'basic_salary'=>$row->basic_salary,

'per_day_salary'=>$row->basic_salary,

'present_days'=>$row->present_days,

'absent_days'=>$row->absent_days,

'allowed_leave'=>0,

'lop_days'=>$row->lop_days,

'lop_amount'=>$row->lop_amount,

'pf_amount'=>$row->pf_amount,
'pt_amount'=>$row->pt_amount,

'esi_amount'=>$row->esi_amount,

'incentive_amount'=>0,

'net_salary'=>$row->net_salary,

'created_by'=>auth()->id()

]);


// save components

    // DB::table('egc_payroll_entry_components')
    //     ->insert([
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'Basic Salary',
    //             'component_type'=>'EARNING',
    //             'amount'=>$row->basic_salary
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'LOP',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->lop_amount
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'PF',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->pf_amount
    //         ],
    //         [
    //             'payroll_entry_sno'=>$entryId,
    //             'component_name'=>'ESI',
    //             'component_type'=>'DEDUCTION',
    //             'amount'=>$row->esi_amount
    //         ]
    // ]);

   // Get all active components and map by component_code
    $componentMap = DB::table('egc_pay_components')
        ->where('status', 0)
        ->pluck('sno', 'component_code');

    $components = [];

    $amountMapping = [
        'BASIC'     => $row->basic_salary,
        'LOP'       => $row->lop_amount,
        'PF'        => $row->pf_amount,
        'ESI'       => $row->esi_amount,
        'INCENTIVE' => $row->incentive_amount ?? 0,
        'PT'        => $row->pt_amount ?? 0, // if exists
    ];

    foreach ($amountMapping as $code => $amount) {

        if (!empty($amount) && isset($componentMap[$code])) {

            $components[] = [
                'payroll_entry_sno' => $entryId,
                'component_sno'     => $componentMap[$code],
                'amount'            => $amount,
                'created_by'        => auth()->id(),
                'created_at'        => now(),
                'status'            => 0
            ];
        }
    }
  
    if (!empty($components)) {
        DB::table('egc_payroll_entry_components')->insert($components);
    }
}


DB::commit();

return response()->json([
'status'=>true,
'message'=>'Payroll saved successfully'
]);

}
catch(\Exception $e)
{

DB::rollBack();

return response()->json([
'status'=>false,
'message'=>$e->getMessage()
]);

}

}

public function getCompanyBank($id,Request $request)
  {
    $entity_id = $id;
    $branch_data = DB::table('egc_company_bank_accounts')->where('status', 0)->where('company_id', $entity_id)->orderBy('sno', 'desc')->get();
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $branch_data,
    ], 200);
  }
// public function getSalaryComponents(Request $request, $staff_id = null)
// {
//     $query = DB::table('egc_salary_components')->where('status', 1);

//     if ($staff_id) {
//         // Only include components assigned to staff (optional)
//         $staff_components = DB::table('egc_staff_salary_components')
//                             ->where('staff_id', $staff_id)
//                             ->pluck('component_id')
//                             ->toArray();

//         $query->whereIn('sno', $staff_components);
//     }

//     $branch_data = $query->orderBy('sno', 'desc')->get();

//     return response([
//         'status' => 200,
//         'data' => $branch_data,
//     ]);
// }
public function getSalaryComponentsold()
{
    $components = DB::table('egc_salary_components')
        ->where('status',0)
        ->orderBy('type')
        ->get();

    return response()->json([
        'status'=>200,
        'data'=>$components
    ]);
}

 public function getSalaryComponents(){

        $data = DB::table('egc_salary_components')
            ->where('status',0)
            ->get();

        return response()->json($data);
    }


     
public function export(Request $request)
{

    $month_filter = $request->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
     $month = $parsedDate->month;
    $year  = $parsedDate->year;

    return Excel::download(
        new PayrollExport($month, $year),
        'Payroll_'.$month.'.xlsx'
    );
}

public function payrollList(Request $req)
{
    $month = Carbon::parse($req->month)->month;
    $year  = Carbon::parse($req->month)->year;

    $data = DB::table('egc_payroll_entries_new as e')
        ->join('egc_payroll_runs_new as r','r.sno','=','e.payroll_run_sno')
        ->join('egc_staff as s','s.sno','=','e.staff_id')
        ->where('r.payroll_month',$month)
        ->where('r.payroll_year',$year)
        ->select(
            'e.sno as entry_id',
            's.staff_name as name',
            'e.basic_salary',
            'e.total_earnings',
            'e.total_deductions',
            'e.net_salary',
            'e.lop_days',
            DB::raw("TO_BASE64(e.sno) as entry_encrypt")
        )
        ->get();

    return response()->json($data);
}


public function previewPayroll(Request $req)
{
    $month_filter = $req->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
     $month = $parsedDate->month;
    $year  = $parsedDate->year;

    

    $staffList = DB::table('egc_staff')
        ->where('status',0)
        ->where('sno','>',0)
        ->get();

    $data = [];

    foreach($staffList as $staff){

        $data[] = $this->calculatePayroll($staff,$month,$year);

    }

    return response()->json($data);
}

public function lockPayroll(Request $req){

    $month_filter = $req->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
     $month = $parsedDate->month;
    $year  = $parsedDate->year;

    DB::table('egc_payroll_runs_new')
    ->where('payroll_month',$month)
    ->where('payroll_year',$year)
    ->update(['status'=>1]);

    return response()->json(['status'=>200]);
}
// private function calculatePayroll($staff,$month,$year)
// {
//     $basic = $staff->basic_salary;

//     $components = DB::table('egc_staff_salary_components as sc')
//         ->join('egc_salary_components as c','c.sno','=','sc.component_id')
//         ->where('sc.staff_id',$staff->sno)
//         ->where('sc.status',0)
//         ->select('sc.*','c.type','c.component_name')
//         ->get();

//     $earnings = $basic;
//     $deductions = 0;

//     $breakdown = [];

//     foreach($components as $c){

//         $amount = $c->amount;

//         if($c->calculation_type == 'percentage'){
//             $amount = ($basic * $c->amount)/100;
//         }

//         if($c->type == 'earning'){
//             $earnings += $amount;
//         }else{
//             $deductions += $amount;
//         }

//         $breakdown[] = [
//             'name'=>$c->component_name,
//             'amount'=>$amount,
//             'type'=>$c->type
//         ];
//     }

//     // 👉 RULE ENGINE
//     $rules = $this->applyRules($staff,$month,$year,$basic);
//     return  $rules;

//     $deductions += $rules['deductions'];

//     return [
//         'staff_id'=>$staff->sno,
//         'name'=>$staff->staff_name,
//         'basic'=>$basic,
//         'earnings'=>$earnings,
//         'deductions'=>$deductions,
//         'net'=>$earnings - $deductions,
//         'lop_days'=>$rules['lop_days'],
//         'lop_amount'=>$rules['lop_amount'],
//         'components'=>$breakdown
//     ];
// }

private function calculatePayroll($staff,$month,$year,$holidayDates, $allShiftLogs, $attendanceRecords)
{
    $basic = $staff->basic_salary;

    $components = DB::table('egc_staff_salary_components_new as sc')
        ->join('egc_salary_components as c','c.sno','=','sc.component_id')
        ->where('sc.staff_id',$staff->sno)
        ->where('sc.status',0)
        ->where('sc.is_active',1)
        ->select('sc.*','c.type','c.component_name','c.rule_type')
        ->get();
    
        $isDateOfJoiningPast = Carbon::parse($staff->date_of_joining)->lte(Carbon::create($year, $month, 1));

        
        

        // $presentDays = ($staff->salary_earning_days ?? 0);25-03-26
        // $perDaySalary = $staff->per_day_salary ?? 0;
        // $basicEarned = $presentDays * $perDaySalary;
        // $earnings = $basicEarned;

        $deductions = 0;
        $breakdown = [];

        // $earnings += $basic;

        // if(!$isDateOfJoiningPast){
        //     $presentDays = ($staff->salary_earning_days_not_wk ?? 0);
        //     $perDaySalary = $staff->per_day_salary ?? 0;
        //     $basicEarned = $presentDays * $perDaySalary;
        //     $earnings = round($basicEarned, 1);

        //      $breakdown[] = [  //25-03-26
        //         'name' => 'Basic Salary',
        //         'amount' => round($basicEarned, 1),
        //         'type' => 'earning'
        //     ];
        // }

        if(!$isDateOfJoiningPast){
            $perDaySalary = $staff->per_day_salary ?? 0;
            $start = Carbon::parse($staff->date_of_joining);
            $end   = Carbon::create($year, $month, 1)->endOfMonth();
            $earningDays = 0;
            $staffShift = $allShiftLogs[$staff->sno] ?? collect();
            foreach (CarbonPeriod::create($start, $end) as $d) {
                $dateKey = $d->format('Y-m-d');
                // ✅ HOLIDAY → count as present
                if($holidayDates->contains($dateKey)){
                    $earningDays++;
                    continue;
                }
                // ✅ CHECK WEEKOFF
                $dayName = strtolower($d->format('D'));
                $shift = $staffShift->firstWhere('day_name', $dayName);
                if(!$shift){
                    // 👉 NO SHIFT → default Sunday as weekoff
                    if($d->isSunday()){
                        $earningDays++;
                        continue;
                    }
                } else {
                    // 👉 SHIFT EXISTS → this day is weekoff
                    $earningDays++;
                    continue;
                }

                // ✅ ATTENDANCE CHECK
                $attendance = $attendanceRecords[$staff->sno][$dateKey] ?? null;
                if($attendance){
                    if(in_array($attendance->attendance, ['P','PR','OD'])){
                        $earningDays++;
                    }

                    if($attendance->attendance == 'L'){
                        if($attendance->leave_type == 'full'){
                            // no add
                        }elseif(in_array($attendance->leave_type,['first_half','second_half'])){
                            $earningDays += 0.5;
                        }
                    }
                }
            }

            $basicEarned = $earningDays * $perDaySalary;
            $earnings = round($basicEarned, 1);

            $breakdown[] = [
                'name' => 'Basic Salary',
                'amount' => round($basicEarned, 1),
                'type' => 'earning'
            ];
        }else{
            $earnings = $basic; 
            $breakdown[] = [ 
                'name' => 'Basic Salary',
                'amount' => round($basic, 1),
                'type' => 'earning'
            ];
        }

        

        // $breakdown[] = [25-03-26
        //     'name' => 'Basic Salary',
        //     'amount' => $basicEarned,
        //     'type' => 'earning'
        // ];

    foreach($components as $c){
        $amount = $c->amount;

        if($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
            $amount = ($basic * $c->amount)/100;
        }

        if($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
            $amount = $c->amount; 
        }

        if($c->rule_type == 'esi'){
            $esiRule = $this->getRule('esi');

            if($esiRule){
                $limit = $esiRule['condition']['salary_limit'] ?? 0;

                if($basic > $limit){
                    $amount = 0; 
                }else{
                    if($c->calculation_type == 'percentage'){
                        $amount = ($basic * $c->amount)/100;
                    }else{
                        $amount = $c->amount;
                    }
                }
            }
        }

        if($c->rule_type == 'pf'){
            $pfRule = $this->getRule('pf');

            if($pfRule){
                $max = $pfRule['action']['max_limit'] ?? 0;

                if($max > 0){
                    $amount = min($amount, $max);
                }
            }
        }

        if($c->type == 'earning'){
            $earnings += $amount;
        }else{
            $deductions += $amount;
        }

        $breakdown[] = [
            'name' => $c->component_name,
            'amount' => round($amount, 1),
            'type' => $c->type
        ];
    }

    
    // foreach($components as $c){

    //     //  $amount = 0;

    //         $amount = $c->amount;

    //         if($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
    //             $amount = ($basic * $c->amount)/100;
    //         }

    //         if($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
    //            $amount = $c->amount; 
    //         }
           

           
    //         if($c->rule_type == 'esi'){

    //             $esiRule = $this->getRule('esi');

    //             if($esiRule){
    //                 $limit = $esiRule['condition']['salary_limit'] ?? 0;

    //                 if($basic > $limit){
    //                     $amount = 0; 
    //                 }else{
    //                     if($c->calculation_type == 'percentage' ){
    //                         $amount = ($basic * $c->amount)/100;
    //                     }else{
    //                         $amount =  $c->amount;
    //                     }
    //                 }
    //             }
    //         }
            

    //         if($c->rule_type == 'pf'){

    //             $pfRule = $this->getRule('pf');
    //             // return $amount;

    //             if($pfRule){
    //                 $max = $pfRule['action']['max_limit'] ?? 0;

    //                 if($max > 0){
    //                     $amount = min($amount, $max);
    //                 }
    //             }
    //         }

    //         //  return $amount ;
    //         // return $amount;

    //         // if($c->rule_type == 'ot'){
    //         //     $amount = $this->getOvertime($staff,$month,$year);
    //         // }

    //         // if($c->rule_type == 'incentive'){
    //         //     $amount = $this->getIncentive($staff,$month,$year);
    //         // }

    //         // if($c->rule_type == 'travel'){
    //         //     $amount = $this->getTravel($staff,$month,$year);
    //         // }

    //     if($c->type == 'earning'){
    //         $earnings += $amount;
    //     }else{
    //         $deductions += $amount;
    //     }

    //     $breakdown[] = [
    //         'name'=>$c->component_name,
    //         'amount'=>$amount,
    //         'type'=>$c->type
    //     ];
    // }

    

    // ✅ APPLY RULE ENGINE
    $rules = $this->applyRules($staff,$month,$year,$basic);

    // foreach ($breakdown as &$comp) {
    //     if ($comp['name'] == 'Loss of Pay') {
    //         $comp['amount'] = round($rules['lop_amount'], 2);
    //     }
    // }
    // unset($comp);

        $lopFound = false;

        foreach ($breakdown as &$comp) {
            if ($comp['name'] == 'Loss of Pay') {
                $comp['amount'] = round($rules['lop_amount'], 2);
                $lopFound = true;
            }
        }
        unset($comp);

        // If not found → add manually
        if (!$lopFound && $rules['lop_amount'] > 0) {
            $breakdown[] = [
                'name' => 'Loss of Pay',
                'amount' => round($rules['lop_amount'], 2),
                'type' => 'deduction'
            ];
        }

    // return $rules;

    $deductions += round($rules['total_deductions'], 1) ;
     $net = $earnings - $deductions;

    // return [
    //     'staff_id'=>$staff->sno,
    //     'name'=>$staff->staff_name,
    //     'basic'=>$basic,
    //     'earnings'=>$earnings,
    //     'deductions'=>$deductions,
    //     'net'=>$earnings - $deductions,
    //     'lop_days'=>$rules['lop_days'],
    //     'lop_amount'=>$rules['lop_amount'],
    //     'rule_breakdown'=>$rules['breakdown'],
    //     'components'=>$breakdown
    // ];

    return [
        'staff_id'=>$staff->sno,
        'name'=>$staff->staff_name,
        'basic'=>$basic,
        'earnings'=>$earnings,
        'deductions'=>$deductions,
        'net'=>$net,
        'lop_days'=>$rules['lop_days'],
        'lop_amount'=>$rules['lop_amount'],
        'components'=>$breakdown,
        'rules'=>$rules['breakdown'],

        // ADD THESE 👇
        'present_days'=>$present ?? 0,
        'absent_days'=>$absent ?? 0,
        'late_count'=>$late ?? 0
    ];
}


public function runPayroll(Request $req)
{
    DB::beginTransaction();
    try {
        $month_filter = $req->get('month_filter', date('M-Y'));
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
        $month = $parsedDate->month;
        $year  = $parsedDate->year;


        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();
        if ($today->between($startDate, $endDate)) {
            $endDate = $today;
        }


        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })->get();

        $holidayDates = collect();
        foreach($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;
            foreach(CarbonPeriod::create($start, $end) as $d){
                $holidayDates->push($d->format('Y-m-d'));
            }
        }
        $holidayDates = $holidayDates->unique();
        
         $endOfMonth = date('Y-m-t', strtotime("$year-$month-01"));

        // $staffList = DB::table('egc_staff')
        //     ->where('status',0)
        //     ->get();

        $staffList = DB::table('egc_staff as s')
        ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){
        $join->on('a.staff_id','=','s.sno')
        ->whereMonth('a.date',$month)
        ->whereYear('a.date',$year)
        ->where('a.status',0);
        })
        ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')
        ->where('s.role_id','!=',1)
        ->whereDate('s.date_of_joining', '<=', $endOfMonth)
        ->where('s.status',0)
        ->select(
            's.sno',
            's.staff_name',
            's.staff_id as staff_code',
            's.basic_salary',
            's.nick_name',
            's.mobile_no',
            's.staff_image',
            's.company_id',
            's.company_type',
            's.entity_id',
            's.gender',
            's.salary_type',
            's.salary_date',
            's.date_of_joining',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
            's.per_day_salary',
            's.casual_leave_count_per_month',
            // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
            DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),
            DB::raw("
                SUM(
                    CASE 
                        WHEN a.attendance IN ('P','OD','PR') THEN 1
                        WHEN a.attendance = 'L' AND a.leave_type IN ('first_half','second_half') THEN 0.5
                        ELSE 0
                    END
                ) as present_days
            "),

            DB::raw("
                SUM(
                    CASE 
                        WHEN a.attendance = 'L' AND a.leave_type = 'full' THEN 1
                        WHEN a.attendance = 'L' AND a.leave_type IN ('first_half','second_half') THEN 0.5
                        ELSE 0
                    END
                ) as leave_days
            "),
            // DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),
            DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
            DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
        )->groupBy(
            's.sno',
            's.staff_id',
            's.staff_name',
            's.basic_salary',
            's.nick_name',
            's.mobile_no',
            's.staff_image',
            's.company_id',
            's.company_type',
            's.entity_id',
            's.gender',
            's.salary_type',
            's.salary_date',
            's.date_of_joining',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name',
            's.per_day_salary',
            's.casual_leave_count_per_month',
        );
        $allStaffIds = $staffList->pluck('s.sno');
        $staffList=$staffList->get();

        // create payroll run
        $runId = DB::table('egc_payroll_runs_new')->insertGetId([
            'payroll_month'=>$month,
            'payroll_year'=>$year,
            'created_at'=>now()
        ]);

        $allShiftLogs = DB::table('egc_shift_time_log as stl')
        ->join('egc_shift_day_times as sdt', 'stl.change_shift_id', '=', 'sdt.shift_id')
        ->whereIn('stl.staff_id', $allStaffIds)
        ->where('sdt.status', 0)
        ->select('stl.staff_id', 'stl.start_date', 'stl.end_date', 'sdt.day_name')
        ->orderBy('stl.start_date')
        ->get()
        ->groupBy('staff_id');

        $attendanceRecords = DB::table('egc_staff_attendance')
            ->whereIn('staff_id', $allStaffIds)
            ->whereBetween('date', [$startDate, $endDate])
            ->where('status', 0)
            ->get()
            ->groupBy('staff_id')
            ->map(fn($items) => $items->keyBy('date'));

        foreach($staffList as $staff){

                $presentDays = $staff->present_days ?? 0;
                $absentDays = $staff->absent_days ?? 0;
                $leaveDays = $staff->leave_days ?? 0;
                $permissionDays = $staff->permission_days ?? 0;
                $ondutyDays = $staff->onduty_days ?? 0;

                $holidayCount = 0;
                $weekOffCount = 0;

                $staffShift = $allShiftLogs[$staff->sno] ?? collect();
                foreach(CarbonPeriod::create(Carbon::create($year, $month, 1), Carbon::create($year, $month, 1)->endOfMonth()) as $d){
                    $dateKey = $d->format('Y-m-d');

                    if($holidayDates->contains($dateKey)) {
                        $holidayCount++;
                        continue;
                    }

                    $dayName = strtolower($d->format('D'));
                    $shift = $staffShift->firstWhere('day_name', $dayName);
                    if(!$shift) $weekOffCount++;
                }
                $staff->weekOffCount =$weekOffCount;
                $staff->holidayCount =$holidayCount;
                $totalPresentEarningWithoutWK= $presentDays+$permissionDays+$ondutyDays+$holidayCount;
                $totalSalaryEarning=$presentDays+$permissionDays+$ondutyDays+$holidayCount+$weekOffCount;
                $staff->salary_earning_days=$totalSalaryEarning;
                $staff->salary_earning_days_not_wk=$totalPresentEarningWithoutWK;

            $this->processStaffPayroll($staff,$runId,$month,$year,$holidayDates, $allShiftLogs, $attendanceRecords);

        }

        DB::commit();

        return response()->json([
            'status' => 200,
            'message' => 'Payroll generated successfully'
        ]);

    } catch (\Exception $e) {
        //  ROLLBACK EVERYTHING
        DB::rollBack();

        \Log::error('Payroll Error: '.$e->getMessage());

        return response()->json([
            'status' => 500,
            'message' => 'Payroll generation failed',
            'error' => $e->getMessage() // remove in production if needed
        ], 500);
    }
}


//  private function applyRules($staff,$month,$year,$basic)
// {
//     $helper = new \App\Helpers\Helpers();

//     $attendance = DB::table('egc_staff_attendance')
//         ->where('staff_id',$staff->sno)
//         ->whereMonth('date',$month)
//         ->whereYear('date',$year)
//         ->where('status',0)
//         ->get();

//     $present = 0;
//     $absent = 0;
//     $late = 0;

//     foreach($attendance as $a){

//         if($a->attendance == 'P') $present++;
//         if($a->attendance == 'A') $absent++;

//         // late logic (simple)
//         if($a->in_time && $a->in_time > '09:30:00'){
//             $late++;
//         }
//     }

//     // 👉 SETTINGS
//     $casualLeave = $staff->casual_leave_count_per_month;
//     $lateAllowed = $helper->payroll_setting('late_allowed_per_month');
//     $lopPerLate = $helper->payroll_setting('lop_per_late');

//     // 👉 LOP CALC
//     $absentLop = max(0, $absent - $casualLeave);
//     $extraLate = max(0, $late - $lateAllowed);
//     $lateLop = $extraLate * $lopPerLate;

//     $totalLop = $absentLop + $lateLop;

//     $lopAmount = $totalLop * $staff->per_day_salary;

//     // 👉 PF
//     $pf = ($basic * $helper->payroll_setting('pf_percentage'))/100;

//     // 👉 ESI
//     $esi = 0;
//     if($basic <= $helper->payroll_setting('esi_salary_limit')){
//         $esi = ($basic * $helper->payroll_setting('esi_percentage'))/100;
//     }

//     // 👉 PT
//     $pt = $helper->payroll_setting('pt_amount');

//     return [
//         'deductions'=>$lopAmount + $pf + $esi + $pt,
//         'lop_days'=>$totalLop,
//         'lop_amount'=>$lopAmount
//     ];
// }



private function applyRules($staff,$month,$year,$basic)
{

    // return $month;
    // 👉 load rules
    $rules = DB::table('egc_payroll_rules')
        ->where('status',0)
        ->get();


    // attendance
    $attendance = DB::table('egc_staff_attendance')
        ->where('staff_id',$staff->sno)
        ->whereMonth('date',$month)
        ->whereYear('date',$year)
        ->where('status',0)
        ->get();

        // return $staff->sno;

        $lateCount = DB::table('egc_staff_attendance as att')
            ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

            ->join('egc_shift_time_log as stl', function ($join) {
                $join->on('stl.staff_id', '=', 'att.staff_id');
            })

            ->join('egc_shift_day_times as sd', function ($join) {
                $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                    ->where('sd.status', 0);
            })

            ->where('att.staff_id', $staff->sno)

            // 👉 Month filter
            ->whereMonth('att.date', $month)
            ->whereYear('att.date', $year)

            ->where('att.status', 0)
            ->whereNotNull('att.in_time')

            // ✅ JOINING DATE CHECK
            ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")

            // ✅ SHIFT DATE RANGE CHECK
            ->whereRaw("
                DATE(att.date) BETWEEN stl.start_date 
                AND IFNULL(stl.end_date, '9999-12-31')
            ")

            // ✅ DAY MATCH (Mon, Tue...)
            ->whereRaw("
                LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
            ")

            // ✅ LATE CHECK
            // ->whereRaw("
            //     TIME(att.in_time) > TIME(sd.time_from)
            // ")
            ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:11:00')")

            ->count();

    $startDate = Carbon::create($year, $month, 1)->startOfMonth();
    $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
    $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
    $today = Carbon::today();

    // Limit end date to today if month is current
    if ($today->between($startDate, $endDate)) {
        $endDate = $today;
    }

        $holidays = DB::table('egc_holiday')
            ->where('status', 0)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('hol_date', [$startDate, $endDate])
                ->orWhereBetween('hol_end_date', [$startDate, $endDate]);
            })
            ->get();

        $holidayDates = collect();

        foreach ($holidays as $hol) {
            $start = Carbon::parse($hol->hol_date);
            $end   = $hol->hol_end_date ? Carbon::parse($hol->hol_end_date) : $start;

            foreach (CarbonPeriod::create($start, $end) as $d) {
                $holidayDates->push($d->format('Y-m-d'));
            }
        }

        $holidayDates = $holidayDates->unique();
    

    $present = 0;
    $absent = 0;
    $late = $lateCount;


    foreach($attendance as $a){
        $dateKey = $a->date;

        if($holidayDates->contains($dateKey)){
            continue;
        }
        if($a->attendance == 'P') $present++;
        if($a->attendance == 'OD') $present++;
        if($a->attendance == 'PR') $present++;
        if($a->attendance == 'A') $absent++;
        if ($a->attendance == 'L') {
            if ($a->leave_type == 'full') {
                $absent += 1;
            } elseif (in_array($a->leave_type, ['first_half','second_half'])) {
                $absent += 0.5;
            }
        }
        // if($a->attendance == 'L') $absent++; 25-03-26
        // if($a->in_time && $a->in_time > '09:30:00') $late++;
    }

    

    $totalDeduction = 0;
    $lopDays = 0;
    $lopAmount = 0;

    $ruleBreakdown = [];

    foreach($rules as $rule){

        $condition = json_decode($rule->condition_json,true);
        $action = json_decode($rule->action_json,true);

        // =====================
        //  LOP RULE
        // =====================
        if($rule->rule_type == 'lop'){

            $allowedLeave = $staff->casual_leave_count_per_month ?? 0;

            // return $absent;

            $lopDays = max(0, $absent - $allowedLeave);

            $perDay = $staff->per_day_salary;

            $lopAmount = $lopDays * $perDay;

            $totalDeduction += $lopAmount;

            $ruleBreakdown[] = [
                'rule'=>'LOP',
                'days'=>$lopDays,
                'amount'=>$lopAmount
            ];
        }

        // =====================
        //  LATE RULE
        // =====================
        if($rule->rule_type == 'late'){

            $allowed = $condition['allowed_per_month'] ?? 0;
            $lopPerLate = $action['lop_per_late'] ?? 0;

               

            $extraLate = max(0, $late - $allowed);
           

            $lateLopDays = $extraLate * $lopPerLate;

            $amount = $lateLopDays * $staff->per_day_salary;

            $totalDeduction += $amount;

            $ruleBreakdown[] = [
                'rule'=>'Late',
                'days'=>$lateLopDays,
                'total_late_Count' => $late,
                'allowed_late_Count' => $allowed,
                'lopPerLate' => $lopPerLate,
                'amount'=>$amount
            ];
        }

        // =====================
        //  Permission RULE
        // =====================

        if($rule->rule_type == 'permission'){

            $condition = json_decode($rule->condition_json, true);
            $action = json_decode($rule->action_json, true);

            $allowedHours = $condition['max_hours'] ?? 0;
            $deductionPerDay = $action['deduction'] ?? 0; // usually 0.5 or 1

            // 👉 GET TOTAL PERMISSION MINUTES
            $permissionMinutes = DB::table('egc_staff_attendance')
                ->where('staff_id', $staff->sno)
                ->whereMonth('date', $month)
                ->whereYear('date', $year)
                ->where('attendance', 'PR')
                ->where('status', 0)
                ->selectRaw("
                    SUM(
                        TIMESTAMPDIFF(MINUTE, start_time, end_time)
                    ) as total_minutes
                ")
                ->value('total_minutes');

            $permissionMinutes = $permissionMinutes ?? 0;

            // 👉 Convert to hours
            $permissionHours = $permissionMinutes / 60;

            // 👉 Calculate excess
            $extraHours = max(0, $permissionHours - $allowedHours);

            // 👉 Convert hours → days
            // assume 8 hours = 1 day (you can make dynamic later)
            $workingHoursPerDay = 8;

            $deductionDays = ($extraHours / $workingHoursPerDay) * $deductionPerDay;

            $amount = $deductionDays * $staff->per_day_salary;

            $totalDeduction += $amount;

            $ruleBreakdown[] = [
                'rule' => 'Permission',
                'total_hours' => round($permissionHours,2),
                'allowed_hours' => $allowedHours,
                'extra_hours' => round($extraHours,2),
                'deduction_days' => round($deductionDays,2),
                'amount' => round($amount,2)
            ];
        }

        // =====================
        //  ESI RULE
        // =====================
        // if($rule->rule_type == 'esi'){

        //     $limit = $condition['salary_limit'] ?? 0;
        //     $percent = $action['percentage'] ?? 0;

        //     if($basic <= $limit){
        //         $esi = ($basic * $percent)/100;
        //         $totalDeduction += $esi;

        //         $ruleBreakdown[] = [
        //             'rule'=>'ESI',
        //             'amount'=>$esi
        //         ];
        //     }
        // }

        if($rule->rule_type == 'esi'){

            $limit = $condition['salary_limit'] ?? 0;

            if($basic > $limit){

                $ruleBreakdown[] = [
                    'rule'=>'ESI',
                    'amount'=>0,
                    'note'=>'Not applicable (salary > limit)'
                ];

                //  DO NOT CALCULATE HERE
            }
        }

        // =====================
        //  PF RULE
        // =====================
        // if($rule->rule_type == 'pf'){

        //     $percent = $condition['percentage'] ?? 0;
        //     $max = $action['max_limit'] ?? 0;

        //     $pf = ($basic * $percent)/100;

        //     if($max > 0){
        //         $pf = min($pf,$max);
        //     }

        //     $totalDeduction += $pf;

        //     $ruleBreakdown[] = [
        //         'rule'=>'PF',
        //         'amount'=>$pf
        //     ];
        // }

    }

    return [
        'total_deductions'=>$totalDeduction,
        'lop_days'=>$lopDays,
        'lop_amount'=>$lopAmount,
        'breakdown'=>$ruleBreakdown
    ];
}


private function getOvertime($staff,$month,$year){
    return DB::table('egc_overtime')
        ->where('staff_id',$staff->sno)
        ->whereMonth('date',$month)
        ->whereYear('date',$year)
        ->sum('amount');
}

private function getIncentive($staff,$month,$year){
    return DB::table('egc_incentive')
        ->where('staff_id',$staff->sno)
        ->whereMonth('date',$month)
        ->whereYear('date',$year)
        ->sum('amount');
}

private function getTravel($staff,$month,$year){
    return DB::table('egc_travel_claim')
        ->where('staff_id',$staff->sno)
        ->whereMonth('date',$month)
        ->whereYear('date',$year)
        ->sum('amount');
}


    private function processStaffPayroll($staff,$runId,$month,$year,$holidayDates, $allShiftLogs, $attendanceRecords)
    {
        try {

            $basic = $staff->basic_salary;

            // 👉 GET COMPONENTS
            $components = DB::table('egc_staff_salary_components_new as sc')
                ->join('egc_salary_components as c','c.sno','=','sc.component_id')
                ->where('sc.staff_id',$staff->sno)
                ->where('sc.status',0)
                ->select('sc.*','c.type','c.rule_type','c.component_name')
                ->get();

            $earnings = $basic;

            $deductions = 0;
            $compBreak = [];

            $isDateOfJoiningPast = Carbon::parse($staff->date_of_joining)->lte(Carbon::create($year, $month, 1));


            // if(!$isDateOfJoiningPast){
            //     $presentDays = ($staff->salary_earning_days_not_wk ?? 0);
            //     $perDaySalary = $staff->per_day_salary ?? 0;
            //     $basicEarned = $presentDays * $perDaySalary;
            //     $earnings = round($basicEarned, 1);

            //     $compBreak[] = [  //25-03-26
            //         'component_id' => '0',
            //         'name' => 'Basic Salary',
            //         'amount' => round($basicEarned, 1),
            //         'type' => 'earning'
            //     ];
            // }
            if(!$isDateOfJoiningPast){
                $perDaySalary = $staff->per_day_salary ?? 0;
                $start = Carbon::parse($staff->date_of_joining);
                $end   = Carbon::create($year, $month, 1)->endOfMonth();
                $earningDays = 0;
                $staffShift = $allShiftLogs[$staff->sno] ?? collect();
                foreach (CarbonPeriod::create($start, $end) as $d) {
                    $dateKey = $d->format('Y-m-d');
                    // ✅ HOLIDAY → count as present
                    if($holidayDates->contains($dateKey)){
                        $earningDays++;
                        continue;
                    }
                    // ✅ CHECK WEEKOFF
                    $dayName = strtolower($d->format('D'));
                    $shift = $staffShift->firstWhere('day_name', $dayName);
                    if(!$shift){
                        // 👉 NO SHIFT → default Sunday as weekoff
                        if($d->isSunday()){
                            $earningDays++;
                            continue;
                        }
                    } else {
                        // 👉 SHIFT EXISTS → this day is weekoff
                        $earningDays++;
                        continue;
                    }

                    // ✅ ATTENDANCE CHECK
                    $attendance = $attendanceRecords[$staff->sno][$dateKey] ?? null;
                    if($attendance){
                        if(in_array($attendance->attendance, ['P','PR','OD'])){
                            $earningDays++;
                        }

                        if($attendance->attendance == 'L'){
                            if($attendance->leave_type == 'full'){
                                // no add
                            }elseif(in_array($attendance->leave_type,['first_half','second_half'])){
                                $earningDays += 0.5;
                            }
                        }
                    }
                }

                $basicEarned = $earningDays * $perDaySalary;
                $earnings = round($basicEarned, 1);

                $compBreak[] = [
                    'name' => '0',
                    'name'=>'Basic Salary',
                    'amount' => round($basicEarned, 1),
                    'type' => 'earning'
                ];
            }
            else{
                $earnings = $basic; 
                $compBreak[] = [ 
                    'component_id' => '0',
                    'name'=>'Basic Salary',
                    'amount' => round($basic, 1),
                    'type' => 'earning'
                ];
            }

            foreach($components as $c){

                $amount = $c->amount;

                if($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
                    $amount = ($basic * $c->amount)/100;
                }

                if($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
                    $amount = $c->amount; 
                }

                if($c->rule_type == 'esi'){
                    $esiRule = $this->getRule('esi');

                    if($esiRule){
                        $limit = $esiRule['condition']['salary_limit'] ?? 0;

                        if($basic > $limit){
                            $amount = 0; 
                        }else{
                            if($c->calculation_type == 'percentage'){
                                $amount = ($basic * $c->amount)/100;
                            }else{
                                $amount = $c->amount;
                            }
                        }
                    }
                }

                if($c->rule_type == 'pf'){
                    $pfRule = $this->getRule('pf');

                    if($pfRule){
                        $max = $pfRule['action']['max_limit'] ?? 0;

                        if($max > 0){
                            $amount = min($amount, $max);
                        }
                    }
                }

                // if($c->rule_type == 'ot'){
                //     $amount = $this->getOvertime($staff,$month,$year);
                // }

                // if($c->rule_type == 'incentive'){
                //     $amount = $this->getIncentive($staff,$month,$year);
                // }

                // if($c->rule_type == 'travel'){
                //     $amount = $this->getTravel($staff,$month,$year);
                // }

                if($c->type == 'earning'){
                    $earnings += $amount;
                }else{
                    $deductions += $amount;
                }

                $compBreak[] = [
                        'component_id'=>$c->component_id,
                        'name'=>$c->component_name,
                        'amount'=>round($amount, 1),
                        'type'=>$c->type
                    ];
            }

            //  APPLY RULE ENGINE
            $ruleData = $this->applyRules($staff,$month,$year,$basic);

                $lopFound = false;

                foreach ($compBreak as &$comp) {
                    if ($comp['name'] == 'Loss of Pay') {
                        $comp['amount'] = round($ruleData['lop_amount'], 2);
                        $lopFound = true;
                    }
                }
                unset($comp);

                // If not found → add manually
                if (!$lopFound && $ruleData['lop_amount'] > 0) {
                    $compBreak[] = [
                        'component_id' => 8,
                        'name' => 'Loss of Pay',
                        'amount' => round($ruleData['lop_amount'], 2),
                        'type' => 'deduction'
                    ];
                }

            $deductions += $ruleData['total_deductions'];

            $lopDays = $ruleData['lop_days'];
            $lopAmount = $ruleData['lop_amount'];

        
            $net = $earnings - $deductions;

            // SAVE ENTRY
            $entryId = DB::table('egc_payroll_entries_new')->insertGetId([
                'payroll_run_sno'=>$runId,
                'staff_id'=>$staff->sno,
                'basic_salary'=>$basic,
                'total_earnings'=>$earnings,
                'total_deductions'=>$deductions,
                'net_salary'=>$net,
                'lop_days'=>$lopDays,
                'lop_amount'=>$lopAmount,
                'created_at'=>now()
            ]);

                // SAVE COMPONENTS
            foreach($compBreak as $cb){

                DB::table('egc_payroll_entry_components_new')->insert([
                    'payroll_entry_id'=>$entryId,
                    'component_id'=>$cb['component_id'],
                    'amount'=>$cb['amount'],
                    'type'=>$cb['type']
                ]);
            }

        }catch (\Exception $e) {
            throw $e; 
        }
        
    }

     private function getRule($type)
{
    static $rules = null;

    if($rules === null){
        $rules = DB::table('egc_payroll_rules')
            ->where('status',0)
            ->get()
            ->keyBy('rule_type');
    }

    if(!isset($rules[$type])) return null;

    return [
        'condition' => json_decode($rules[$type]->condition_json,true),
        'action' => json_decode($rules[$type]->action_json,true)
    ];
}


public function getEntryold($id)
{
    

    return response()->json([
        'components'=>$components
    ]);
}


public function getEntry($id,Request $req)
{
    $month_filter = $req->get('month_filter', date('M-Y'));
    $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
     $month = $parsedDate->month;
    $year  = $parsedDate->year;


    $staff = DB::table('egc_payroll_entries_new as e')
        ->join('egc_staff as s', 's.sno', 'e.staff_id')
        ->leftJoin('egc_staff_attendance as a', function($join) use ($month,$year){
        $join->on('a.staff_id','=','s.sno')
        ->whereMonth('a.date',$month)
        ->whereYear('a.date',$year)
        ->where('a.status',0);
        })
        ->leftJoin('egc_company', 's.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 's.entity_id', 'egc_entity.sno')
        ->join('egc_department', 's.department_id', 'egc_department.sno')
        ->join('egc_division', 's.division_id', 'egc_division.sno')
        ->join('egc_job_role', 's.job_role_id', 'egc_job_role.sno')
        ->where('e.sno',$id)
        ->select(
            's.sno',
            's.staff_name',
            's.staff_id as staff_code',
            'e.basic_salary',
            'e.total_earnings',
            'e.total_deductions',
            'e.net_salary',
            's.nick_name',
            's.mobile_no',
            's.staff_image',
            's.company_id',
            's.company_type',
            's.entity_id',
            's.gender',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
            's.per_day_salary',
            's.casual_leave_count_per_month',
            DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
            DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days"),
            DB::raw("SUM(CASE WHEN a.attendance='L' THEN 1 ELSE 0 END) as leave_days"),
            DB::raw("SUM(CASE WHEN a.attendance='PR' THEN 1 ELSE 0 END) as permission_days"),
            DB::raw("SUM(CASE WHEN a.attendance='OD' THEN 1 ELSE 0 END) as onduty_days")
            // DB::raw("SUM(CASE WHEN a.attendance='P' THEN 1 ELSE 0 END) as present_days"),
            // DB::raw("SUM(CASE WHEN a.attendance='A' THEN 1 ELSE 0 END) as absent_days")
        )
        ->groupBy(
                's.sno',
                's.staff_id',
                's.staff_name',
                'e.basic_salary',
                'e.total_earnings',
                'e.total_deductions',
                'e.net_salary',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_id',
                's.company_type',
                's.entity_id',
                's.gender',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name',
                's.per_day_salary',
                's.casual_leave_count_per_month',
            )
            ->first();


            $helper = new \App\Helpers\Helpers();
            $general_setting=$helper->general_setting_data();

            $absentDays = $item->absent_days ?? 0;

            $dataParoll = $this->calculatePayrollEntry($staff,$id);
            // return $dataParoll;

            // return $dataParoll;
           if ($staff->company_type == 1) {
                $filePath = public_path('staff_images/Management/' . $staff->staff_image);
            } else {
                $filePath = public_path('staff_images/Buisness/' . $staff->company_id . '/' . $staff->entity_id . '/' . $staff->staff_image);
            }

            $isStaffImage = $staff->staff_image != '' && file_exists($filePath) ? 1 : 0;

            $components = DB::table('egc_staff_salary_components_new as ssc')
                ->join('egc_salary_components as pc', 'pc.sno', '=', 'ssc.component_id')
                ->where('ssc.staff_id', $staff->sno)
                ->where('ssc.status', 0)
                ->select(
                    'pc.component_name',
                    'pc.type as component_type',
                    'pc.calculation_type',
                    'ssc.amount',
                )
                ->get();

            $entry = DB::table('egc_payroll_entries_new')
                ->select('egc_payroll_entries_new.sno')
                    ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','egc_payroll_entries_new.payroll_run_sno')
                    ->where('egc_payroll_entries_new.staff_id',$staff->sno)
                    ->where('egc_payroll_runs_new.payroll_month',$month)
                    ->where('egc_payroll_runs_new.payroll_year',$year)
                    ->first();

         

                $isSaved = $entry ? true : false;
                $entryId = $entry->sno ?? null;

                $lateCount = DB::table('egc_staff_attendance as att')
                    ->join('egc_staff as s', 's.sno', '=', 'att.staff_id')

                    ->join('egc_shift_time_log as stl', function ($join) {
                        $join->on('stl.staff_id', '=', 'att.staff_id');
                    })

                    ->join('egc_shift_day_times as sd', function ($join) {
                        $join->on('sd.shift_id', '=', 'stl.change_shift_id')
                            ->where('sd.status', 0);
                    })
                    ->where('att.staff_id', $staff->sno)
                    // 👉 Month filter
                    ->whereMonth('att.date', $month)
                    ->whereYear('att.date', $year)
                    ->where('att.status', 0)
                    ->whereNotNull('att.in_time')
                    // ✅ JOINING DATE CHECK
                    ->whereRaw("DATE(att.date) >= DATE(s.date_of_joining)")
                    // ✅ SHIFT DATE RANGE CHECK
                    ->whereRaw("
                        DATE(att.date) BETWEEN stl.start_date 
                        AND IFNULL(stl.end_date, '9999-12-31')
                    ")
                    // ✅ DAY MATCH (Mon, Tue...)
                    ->whereRaw("
                        LOWER(sd.day_name) = LOWER(DATE_FORMAT(att.date, '%a'))
                    ")
                    // ✅ LATE CHECK
                    // ->whereRaw("
                    //     TIME(att.in_time) > TIME(sd.time_from)
                    // ")
                    ->whereRaw("TIME(att.in_time) > ADDTIME(sd.time_from, '00:11:00')")
                    ->count();
                 // return $lateCount;

                    if($staff->company_type == 1){
                        $staff->company_name=$general_setting->title;
                        $staff->company_base_color ='#ab2b22';
                    }


                $datastaff =  [
                    'sno' => $staff->sno,
                    'name'=>$staff->staff_name,
                    'isStaffImage'=>$isStaffImage,
                    'company_name'=>$staff->company_name,
                    'company_base_color'=>$staff->company_base_color,
                    'present_days'=>$staff->present_days ?? 0,
                    'absent_days'=>$absentDays,
                    'leave_days'=>$staff->leave_days ?? 0,
                    'permission_days'=>$staff->permission_days ?? 0,
                    'onduty_days'=>$staff->onduty_days ?? 0,
                    'late_count'=>$lateCount,
                    'staff_id'=>$staff->staff_code,
                    'basic_salary'=>$staff->basic_salary,
                    'dataParoll' => $dataParoll,
                    'is_saved'=>$isSaved,
                    'entry_id'=>$entryId,
                    'data' => $staff,
                ];
    
     return response()->json([
            'status' =>'success',
            'data' => $datastaff,
        ]);

   
}

// private function calculatePayrollEntry($staff,$id)
// {
//     $basic = $staff->basic_salary;

//     $components = DB::table('egc_payroll_entry_components_new as c')
//         ->join('egc_salary_components as sc','sc.sno','=','c.component_id')
//         ->join('egc_payroll_entries_new','egc_payroll_entries_new.sno','=','c.payroll_entry_id')
//         ->where('c.payroll_entry_id',$id)
//         ->where('c.status',0)
//         ->select('c.type','sc.component_name','sc.rule_type','c.amount','sc.calculation_type','c.component_id')
//         ->distinct('c.component_id')
//         ->get();
//     // return $components;

//     $payrollRuns = DB::table('egc_payroll_runs_new')
//                     ->join('egc_payroll_entries_new','egc_payroll_entries_new.payroll_run_sno','=','egc_payroll_runs_new.sno')
//                     ->where('egc_payroll_entries_new.sno',$id)
//                     ->first();
//     $month = $payrollRuns ? $payrollRuns->payroll_month :date('m');
//     $year = $payrollRuns ? $payrollRuns->payroll_year :date('m');
//     $earnings = $basic;
//     $deductions = 0;
//     $breakdown = [];

//     // $earnings += $basic;

//     $breakdown[] = [
//         'name' => 'Basic Salary',
//         'amount' => $basic,
//         'type' => 'earning'
//     ];
   
//     foreach($components as $c){
//         $amount = $c->amount;

//         if($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
//             $amount = ($basic * $c->amount)/100;
//         }

//         if($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
//             $amount = $c->amount; 
//         }

        
    
//         if($c->rule_type == 'esi'){
//             $esiRule = $this->getRule('esi');

//             if($esiRule){
//                 $limit = $esiRule['condition']['salary_limit'] ?? 0;

//                 if($basic > $limit){
//                     $amount = 0; 
//                 }else{
//                     if($c->calculation_type == 'percentage'){
//                         $amount = ($basic * $c->amount)/100;
//                     }else{
//                         $amount = $c->amount;
//                     }
//                 }
//             }
//         }

//         if($c->rule_type == 'pf'){
//             $pfRule = $this->getRule('pf');

//             if($pfRule){
//                 $max = $pfRule['action']['max_limit'] ?? 0;

//                 if($max > 0){
//                     $amount = min($amount, $max);
//                 }
//             }
//         }

//         if($c->type == 'earning'){
//             $earnings += $amount;
//         }else{
//             $deductions += $amount;
//         }

//         $breakdown[] = [
//             'name' => $c->component_name,
//             'amount' => $amount,
//             'type' => $c->type
//         ];
//     }

//     //  return $breakdown;
//     // foreach($components as $c){

//     //     //  $amount = 0;

//     //         $amount = $c->amount;

//     //         if($c->calculation_type == 'percentage' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
//     //             $amount = ($basic * $c->amount)/100;
//     //         }

//     //         if($c->calculation_type == 'fixed' && $c->rule_type != 'esi' && $c->rule_type != 'pf'){
//     //            $amount = $c->amount; 
//     //         }
           

           
//     //         if($c->rule_type == 'esi'){

//     //             $esiRule = $this->getRule('esi');

//     //             if($esiRule){
//     //                 $limit = $esiRule['condition']['salary_limit'] ?? 0;

//     //                 if($basic > $limit){
//     //                     $amount = 0; 
//     //                 }else{
//     //                     if($c->calculation_type == 'percentage' ){
//     //                         $amount = ($basic * $c->amount)/100;
//     //                     }else{
//     //                         $amount =  $c->amount;
//     //                     }
//     //                 }
//     //             }
//     //         }
            

//     //         if($c->rule_type == 'pf'){

//     //             $pfRule = $this->getRule('pf');
//     //             // return $amount;

//     //             if($pfRule){
//     //                 $max = $pfRule['action']['max_limit'] ?? 0;

//     //                 if($max > 0){
//     //                     $amount = min($amount, $max);
//     //                 }
//     //             }
//     //         }

//     //         //  return $amount ;
//     //         // return $amount;

//     //         // if($c->rule_type == 'ot'){
//     //         //     $amount = $this->getOvertime($staff,$month,$year);
//     //         // }

//     //         // if($c->rule_type == 'incentive'){
//     //         //     $amount = $this->getIncentive($staff,$month,$year);
//     //         // }

//     //         // if($c->rule_type == 'travel'){
//     //         //     $amount = $this->getTravel($staff,$month,$year);
//     //         // }

//     //     if($c->type == 'earning'){
//     //         $earnings += $amount;
//     //     }else{
//     //         $deductions += $amount;
//     //     }

//     //     $breakdown[] = [
//     //         'name'=>$c->component_name,
//     //         'amount'=>$amount,
//     //         'type'=>$c->type
//     //     ];
//     // }

    

//     // ✅ APPLY RULE ENGINE
//     $rules = $this->applyRules($staff,$month,$year,$basic);

//     // return $rules;

//     $deductions += $rules['total_deductions'];
//      $net = $earnings - $deductions;

//     return [
//         'staff_id'=>$staff->sno,
//         'name'=>$staff->staff_name,
//         'basic'=>$basic,
//         'earnings'=>$earnings,
//         'deductions'=>$deductions,
//         'net'=>$net,
//         'lop_days'=>$rules['lop_days'],
//         'lop_amount'=>$rules['lop_amount'],
//         'components'=>$breakdown,
//         'rules'=>$rules['breakdown'],

//         // ADD THESE 👇
//         'present_days'=>$present ?? 0,
//         'absent_days'=>$absent ?? 0,
//         'late_count'=>$late ?? 0
//     ];
// }

private function calculatePayrollEntry($staff, $id)
{
    // 👉 Get saved entry
    $entry = DB::table('egc_payroll_entries_new')
        ->where('sno', $id)
        ->first();

    if (!$entry) return [];

    // 👉 Get saved components (NO recalculation)
    $components = DB::table('egc_payroll_entry_components_new as c')
        ->join('egc_salary_components as sc', 'sc.sno', '=', 'c.component_id')
        ->where('c.payroll_entry_id', $id)
        ->where('c.status', 0)
        ->select(
            'sc.component_name',
            'c.amount',
            'c.type'
        )
        ->get();

    $breakdown = [];

    // 👉 Basic Salary
    $breakdown[] = [
        'name' => 'Basic Salary',
        'amount' => $entry->basic_salary,
        'type' => 'earning'
    ];

    foreach ($components as $c) {
        $breakdown[] = [
            'name' => $c->component_name,
            'amount' => $c->amount, // ✅ already final
            'type' => $c->type
        ];
    }

    return [
        'staff_id' => $staff->sno,
        'name' => $staff->staff_name,
        'basic' => $entry->basic_salary,
        'earnings' => $entry->total_earnings,
        'deductions' => $entry->total_deductions,
        'net' => $entry->net_salary,
        'lop_days' => $entry->lop_days,
        'lop_amount' => $entry->lop_amount,
        'components' => $breakdown
    ];
}

public function ViewPayslipStaffs($month_filter ,Request $request)
{

        // $month_filter = $request->get('month_filter', date('M-Y'));
        $parsedDate = Carbon::createFromFormat('M-Y', $month_filter);
        $month = $parsedDate->month ?? date('m');
      
        $year  = $parsedDate->year ?? date('Y');
        $monthFull = date('F', mktime(0,0,0,$month,1)) ;
       
        $startDate = Carbon::create($year, $month, 1)->startOfMonth();
        $endDate   = Carbon::create($year, $month, 1)->endOfMonth();
        $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
        $today = Carbon::today();

        $entry_staff_ids = DB::table('egc_payroll_entries_new')
                ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','egc_payroll_entries_new.payroll_run_sno')
                ->where('egc_payroll_runs_new.payroll_month',$month)
                ->where('egc_payroll_runs_new.payroll_year',$year)
                ->pluck('egc_payroll_entries_new.staff_id');
        // return $entry_staff_ids;

        $data =  DB::table('egc_staff')->where('egc_staff.status', '!=', 2)
            ->select('egc_staff.*',
            'egc_payroll_entries_new.sno as payroll_entry_id',
            'egc_payroll_entries_new.email_send',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_entity.entity_name',
            'egc_entity.entity_base_color',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_languages.name as mother_tongue',
            'egc_job_role.job_position_name as job_role_name',
            )
            ->join('egc_payroll_entries_new','egc_staff.sno','=','egc_payroll_entries_new.staff_id')
            ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','egc_payroll_entries_new.payroll_run_sno')
            ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
            ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
            ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
            ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
            ->where('egc_payroll_runs_new.payroll_month',$month)
            ->where('egc_payroll_runs_new.payroll_year',$year)
            ->where('egc_staff.is_payslip', 1)
            ->get();
    
        if (!$data) {
            return response([
                 'success' => false,
            'status' => 404,
            'message' => 'staff not found',
            'error_msg' => 'No record found with the given ID.',
            'data' => null,
            ], 404);
        }

        return response([
            'success' => true,
            'status' => 200,
            'message' => 'Staff fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'year' => $year,
            'month' => $monthFull,
        ], 200);
}


public function SendMonthPayslip(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'id'  => 'required',
            
        ]);
        // If validation fails, return a response with errors
        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }
        $branch_id  = $request->user()->branch_id;
        // $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

        $id=$request->id;
       
        $data =  DB::table('egc_staff')->where('egc_staff.status', '!=', 2)
            ->select('egc_staff.*',
            'egc_payroll_entries_new.sno as payroll_entry_id',
            'egc_payroll_entries_new.net_salary',
            'egc_entity.entity_name',
            'egc_payroll_runs_new.payroll_month',
            'egc_payroll_runs_new.payroll_year',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_entity.entity_name',
            'egc_entity.entity_base_color',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_languages.name as mother_tongue',
            'egc_job_role.job_position_name as job_role_name',
            )
            ->join('egc_payroll_entries_new','egc_staff.sno','=','egc_payroll_entries_new.staff_id')
            ->join('egc_payroll_runs_new','egc_payroll_runs_new.sno','=','egc_payroll_entries_new.payroll_run_sno')
            ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
            ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
            ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
            ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
            ->where('egc_payroll_entries_new.sno',$id)
            ->where('egc_staff.is_payslip', 1)
            ->first();

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();
            // $event_date =$event_certificate->event_date ? date($common_date_format, strtotime($event_certificate->event_date)) : '22 May 2025'  ;

            // Extract the validated data
            $staff_mobile           = $data->mobile_no;
            $staff_email           = $data->email_id;
            $staff_name= $data->staff_name;
            $employee_id= $data->staff_id;
            $company_name= $data->company_name;
            $net_pay= $data->net_salary ? '₹ '.number_format($data->net_salary) : '₹ 0';
            $month= $data->payroll_month;
            $year= $data->payroll_year;

            $monthFull = date('F', mktime(0,0,0,$month,1)) ;
            
            $month_year =$monthFull . '-'.$year;
            
            $user_id           = $request->user()->user_id ?? 0;
            $encrypted_values = encrypt($id);
    
       
            $Link =url('payroll/payslip_print/' . $encrypted_values);
        
        
                // if(!$event_certificate->payslip_link){
                //     $channelId = 12;
                //     $shortUrlData = $this->shortenUrl($Link,$channelId);
                //     $shortUrl = $shortUrlData['shorturl'];
                //     $urlId =$shortUrlData['id'];
                    
                //     if($shortUrl){
                //             DB::table('za_event_participant')
                //             ->where('sno', $id)
                //             ->update(['payslip_link' => $shortUrl]);
                //     }
                 
                // }
              
              $payrollEntryData=DB::table('egc_payroll_entries_new')->where('egc_payroll_entries_new.sno',$id)->first();
              $shortsendUrl = $payrollEntryData->payslip_link ?? $Link;
              
              $payslip_link_key = basename($shortsendUrl);
        
      
                if($staff_email){
                 

                        $socialMediaDetails = json_decode($general_setting->social_media_details, true);
                        $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                        $facebook_link = null;
                        $instagram_link = null;
                        $twitter_link = null;
                        $linkedin_link = null;
                        $youtube_link = null;
                        $pinterest_link = null;

                        foreach ($socialMediaList as $socialMedia) {
                            $sno = $socialMedia->sno;

                            if (isset($socialMediaDetails[$sno])) {
                                $url = $socialMediaDetails[$sno];
                                switch ($socialMedia->social_media_name) {
                                    case 'Instagram':
                                        $instagram_link = $url;
                                        break;
                                    case 'Facebook':
                                        $facebook_link = $url;
                                        break;
                                    case 'Twitter':
                                        $twitter_link = $url;
                                        break;
                                    case 'LinkedIn':
                                        $linkedin_link = $url;
                                        break;
                                    case 'YouTube':
                                        $youtube_link = $url;
                                        break;
                                    case 'Pinterest':
                                        $pinterest_link = $url;
                                        break;
                                }
                            }
                        }
            
                        $email_template_id = 7; // Event Certificate template
                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();
            
                        $dynamicSubject = $emailTemplate->email_name;
                        
                        $dynamicSubject = str_replace('#company_name', $company_name, $dynamicSubject);
                        $dynamicSubject = str_replace('#month_year', $month_year, $dynamicSubject);

                        $content = $emailTemplate->email_subject;

                        $content = str_replace('#company_name', $company_name ?? 'ElysiumGroups', $content);
                        $content = str_replace('#name', $staff_name ?? 'Staff', $content);
                        $content = str_replace('#month_year', $month_year ?? 'March-2026', $content);
                        $content = str_replace('#employee_id',  $employee_id ?? 'EGC003038', $content);
                        $content = str_replace('#payslip_link', $shortsendUrl ?? "url", $content);
                        $content = str_replace('#net_pay',  $net_pay ?? '₹0', $content);
                        $branchNo = $general_setting->hr_head_no;
                        $branchemail = $general_setting->hr_head_mail_id;
                        $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                        $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                        $url= 'www.elysiumgroup.com';
                
                        $mailData = [
                            'url'         => $url,
                            'subject'     => $dynamicSubject,
                            'content'     => $content,
                            'branchNo'    => $branchNo,
                            'branchemail' => $branchemail, // Use the message content from the request
                            'fbLink'      => $fbLink,      // Use the message content from the request
                            'instaLink'   => $instaLink,   // Use the message content from the request
                            'salesMobile' => $branchNo ?? '8220011465',
                        ];
                
                        $to_address = 'vetri4vijayan@gmail.com';
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name =  'Elysium Groups ';

                        $emailLogId = DB::table('egc_email_logs')->insertGetId([
                                'module' => 'payslip',
                                'reference_id' => $id,
                                'to_email' => $to_address,
                                'to_name' => $staff_name,
                                'template_id' => $email_template_id,
                                'subject' => $dynamicSubject,
                                'body' => $content,
                                'status' => 0,
                                'sent_by' => $user_id,
                                'attempt_count' => 0,
                                'created_at' => now()
                            ]);

                        try {
                            

                            Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));

                            DB::table('egc_payroll_entries_new')
                                ->where('sno', $id)
                                ->update(['email_send' => 1]);

                                DB::table('egc_email_logs')
                                ->where('sno', $emailLogId)
                                ->update([
                                    'status' => 1,
                                    'sent_at' => now(),
                                    'updated_at' => now()
                                ]);

                            return response([
                                'success' => true,
                                'message' => 'Email sent successfully'
                            ]);

                        } catch (\Exception $e) {

                            DB::table('egc_payroll_entries_new')
                                ->where('sno', $id)
                                ->update(['email_send' => 2]);

                            DB::table('egc_email_logs')
                                ->where('sno', $emailLogId)
                                ->update([
                                    'status' => 2,
                                    'error_message' => $e->getMessage(),
                                    'attempt_count' => DB::raw('attempt_count + 1'),
                                    'updated_at' => now()
                                ]);

                                return response([
                                    'success' => false,
                                    'message' => $e->getMessage()
                                ]);
                        }
                
                        // return $mailData;
                        
                        
                        
                   
                }
                    
                   
        return response([
            'success' => true,
            'message' => 'Email sent successfully'
        ]);
    }

}
