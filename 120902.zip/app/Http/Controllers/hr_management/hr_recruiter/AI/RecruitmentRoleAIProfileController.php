<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\RecruitmentRoleProfileService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Throwable;

class RecruitmentRoleAIProfileController
    extends Controller
{
    protected RecruitmentRoleProfileService $profiles;

    public function __construct(
        RecruitmentRoleProfileService $profiles
    ) {
        $this->profiles = $profiles;
    }

    /**
     * Show AI role profile.
     */
    public function show(
        int $sno
    ): JsonResponse {

        $role = $this->profiles
            ->getProfile($sno);

        if (!$role) {

            return response()->json([
                'status' => false,
                'message' => 'Recruitment role not found.'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $role
        ]);
    }

    /**
     * Update AI role profile.
     */
    public function update(
        Request $request,
        int $sno
    ): JsonResponse {

        $validator = Validator::make(
            $request->all(),
            [
                'role_description' =>
                    'nullable|string|max:10000',

                'mandatory_skills' =>
                    'nullable|array|max:100',

                'mandatory_skills.*' =>
                    'string|max:200',

                'preferred_skills' =>
                    'nullable|array|max:100',

                'preferred_skills.*' =>
                    'string|max:200',

                'responsibilities' =>
                    'nullable|array|max:100',

                'responsibilities.*' =>
                    'string|max:1000',

                'minimum_experience' =>
                    'nullable|string|max:200',

                'education_requirements' =>
                    'nullable|string|max:1000',

                'seniority' =>
                    'nullable|string|max:100',

                'ai_matching_enabled' =>
                    'nullable|boolean',
            ]
        );

        if ($validator->fails()) {

            return response()->json([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors()
            ], 422);
        }

        $role = DB::table(
            'egc_recruitment_roles'
        )
            ->where('sno', $sno)
            ->first();

        if (!$role) {

            return response()->json([
                'status' => false,
                'message' => 'Recruitment role not found.'
            ], 404);
        }

        try {

            DB::table(
                'egc_recruitment_roles'
            )
                ->where('sno', $sno)
                ->update([

                    'role_description' =>
                        trim(
                            (string) $request->input(
                                'role_description',
                                ''
                            )
                        ),

                    'mandatory_skills' =>
                        json_encode(
                            $this->cleanArray(
                                $request->input(
                                    'mandatory_skills',
                                    []
                                )
                            ),
                            JSON_UNESCAPED_UNICODE
                        ),

                    'preferred_skills' =>
                        json_encode(
                            $this->cleanArray(
                                $request->input(
                                    'preferred_skills',
                                    []
                                )
                            ),
                            JSON_UNESCAPED_UNICODE
                        ),

                    'responsibilities' =>
                        json_encode(
                            $this->cleanArray(
                                $request->input(
                                    'responsibilities',
                                    []
                                )
                            ),
                            JSON_UNESCAPED_UNICODE
                        ),

                    'minimum_experience' =>
                        trim(
                            (string) $request->input(
                                'minimum_experience',
                                ''
                            )
                        ),

                    'education_requirements' =>
                        trim(
                            (string) $request->input(
                                'education_requirements',
                                ''
                            )
                        ),

                    'seniority' =>
                        trim(
                            (string) $request->input(
                                'seniority',
                                ''
                            )
                        ),

                    'ai_matching_enabled' =>
                        (bool) $request->input(
                            'ai_matching_enabled',
                            true
                        ),

                    'ai_profile_version' =>
                        DB::raw(
                            'ai_profile_version + 1'
                        ),

                    'ai_profile_updated_at' =>
                        now(),

                    'ai_profile_updated_by' =>
                        auth()->id(),

                    'updated_at' =>
                        now(),
                ]);

            /*
             * IMPORTANT:
             *
             * Role definition changed.
             * Existing role-profile cache must be cleared.
             */
            $this->profiles->clearCache();

            return response()->json([
                'status' => true,
                'message' =>
                    'AI role profile updated successfully.'
            ]);

        } catch (Throwable $e) {

            report($e);

            return response()->json([
                'status' => false,
                'message' =>
                    'Unable to update AI role profile.'
            ], 500);
        }
    }

    /**
     * Clean array values.
     */
    protected function cleanArray(
        mixed $values
    ): array {

        if (!is_array($values)) {
            return [];
        }

        $values = array_map(
            function ($value) {

                return trim(
                    strip_tags(
                        (string) $value
                    )
                );

            },
            $values
        );

        $values = array_filter(
            $values,
            fn ($value) =>
                $value !== ''
        );

        return array_values(
            array_unique(
                $values
            )
        );
    }
}