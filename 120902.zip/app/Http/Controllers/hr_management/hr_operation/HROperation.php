<?php

namespace App\Http\Controllers\hr_management\hr_operation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\CourseTagModel;
use App\Models\SkillTagModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\HobbyModel;
use App\Models\RelationshipModel;
use App\Models\StaffTimestampModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffAttachmentModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\ApprovalHierarchyModel;
use App\Models\LeaveApprovalModel;
use App\Models\LeavePermissionModel;
use App\Models\ManageEntityModel;
use App\Models\User;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;

class HROperation extends Controller
{
  public function index(Request $request)
  {

  
    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

     $leaveRequests = LeavePermissionModel::
        select(
            'egc_leave_permission.*',
            'egc_staff.staff_name',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.staff_image',
            'egc_staff.mobile_no',
            'egc_staff.email_id',
            'egc_staff.company_type',
            'egc_staff.company_id',
            'egc_staff.entity_id',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
        )
        ->join('egc_staff', 'egc_staff.sno', 'egc_leave_permission.staff_id')
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_staff.sno', '>', 1)
        ->where('egc_leave_permission.status', '!=', 2)
        ->where('egc_staff.status', 0)
        ->orderBy('egc_leave_permission.created_at', 'desc');

            if ($request->has('search_filter') && $request->search_filter != '') {
                $leaveRequests->where('egc_leave_permission.reason', 'LIKE', "%" . $request->search_filter . "%")
                    ->orWhere('egc_leave_permission.leave_type', 'LIKE', "%" . $request->search_filter . "%");
            }

            // Apply date filter if provided (custom or predefined like "today", "week", "monthly")
            if ($request->has('date_filter')) {
                $date_filter = $request->date_filter;
                if ($date_filter == 'today') {
                    $leaveRequests->whereDate('egc_leave_permission.from_date', now()->toDateString());
                } elseif ($date_filter == 'week') {
                    $leaveRequests->whereBetween('egc_leave_permission.from_date', [
                        now()->startOfWeek()->toDateString(),
                        now()->endOfWeek()->toDateString()
                    ]);
                } elseif ($date_filter == 'monthly') {
                    $leaveRequests->whereMonth('egc_leave_permission.from_date', now()->month);
                } elseif ($date_filter == 'custom_date' && $request->has('from_date_filter') && $request->has('to_date_filter')) {
                    $leaveRequests->whereBetween('egc_leave_permission.from_date', [
                        date('Y-m-d', strtotime($request->from_date_filter)),
                        date('Y-m-d', strtotime($request->to_date_filter))
                    ]);
                }
            }

      $leaveRequests = $leaveRequests->paginate($perpage);

        if ($request->ajax()) {
            $data = $leaveRequests->map(function ($item) use ($helper) {
                  $approvalLevels = LeaveApprovalModel::where('request_id', $item->sno)
                                                ->join('egc_staff', 'egc_approval_tasks.approver_staff_id', '=', 'egc_staff.sno')
                                                ->select('egc_approval_tasks.approver_staff_id','egc_approval_tasks.level_no', 'egc_staff.staff_name', 'egc_approval_tasks.status as approval_status')
                                                ->orderBy('egc_approval_tasks.level_no')
                                                ->get();

                $approvedStaff = LeaveApprovalModel::where('request_id', $item->sno)
                                            ->join('egc_staff', 'egc_approval_tasks.approver_staff_id', '=', 'egc_staff.sno')
                                            ->select('egc_approval_tasks.approver_staff_id','egc_approval_tasks.level_no', 'egc_staff.staff_name', 'egc_approval_tasks.status as approval_status')
                                            ->where('egc_approval_tasks.status',1)
                                            ->orderBy('egc_approval_tasks.level_no','desc')
                                            ->first();
                $nextApprover = LeaveApprovalModel::where('request_id', $item->sno)
                                            ->join('egc_staff', 'egc_approval_tasks.approver_staff_id', '=', 'egc_staff.sno')
                                            ->select('egc_approval_tasks.approver_staff_id','egc_approval_tasks.level_no', 'egc_staff.staff_name', 'egc_approval_tasks.status as approval_status')
                                            ->where('egc_approval_tasks.status',0)
                                            ->orderBy('egc_approval_tasks.level_no','asc')
                                            ->first();
              
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'data' => $item,
                    'next_approver_id' =>$nextApprover ? $nextApprover->approver_staff_id :'',
                    'next_approver_name' => $nextApprover ? $nextApprover->staff_name :'',
                    'approve_level_id' => $nextApprover ? $nextApprover->sno :'',
                    'last_approver_id' => $approvedStaff ? $approvedStaff->approver_staff_id :'',
                    'last_approver_name' => $approvedStaff ? $approvedStaff->staff_name :'',
                    'approvalLevels' => $approvalLevels, 
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $leaveRequests->currentPage(),
                'last_page' => $leaveRequests->lastPage(),
                'total' => $leaveRequests->total(),
            ]);
        }
        
    
    //  return $staffProfile;
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_operation.leave_permission.leave_permission_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }

  public function View($id)
  {
    $data =  StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_languages.name as mother_tongue',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_languages', 'egc_staff.mother_tongue', 'egc_languages.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno', $id)
      ->first();
      $languages_ids=$data->languages ? json_decode($data->languages):[];
      $hobby_ids=$data->hobby ? json_decode($data->hobby):[];
      $language_known=DB::table('egc_languages')->whereIn('sno',$languages_ids)->pluck('name');
      $hobbies=DB::table('egc_hobbies')->whereIn('sno',$hobby_ids)->pluck('hobby_name');
      $staff_family=DB::table('egc_staff_family')->where('staff_id',$id)->where('status','!=',2)->first();
      $data->language_known=$language_known;
      $data->hobbies=$hobbies;
      // family details
      $data->father_name=$staff_family? $staff_family->father_name :'';
      $data->father_occup=$staff_family? $staff_family->father_occup :'';
      $data->mother_name=$staff_family? $staff_family->mother_name :'';
      $data->mother_occup=$staff_family? $staff_family->mother_occup :'';
      $data->has_children=$staff_family? $staff_family->has_children :'';
      $data->children_count=$staff_family? $staff_family->children_count :'';
      $data->has_siblings=$staff_family? $staff_family->has_siblings :'';

      $other_credential = DB::table('egc_staff_credential')
        ->select('egc_staff_credential.*', 'egc_credential.credential_name')
        ->join('egc_credential', 'egc_staff_credential.credential_id', 'egc_credential.sno')
        ->where('egc_staff_credential.staff_id', $id)
        ->where('egc_staff_credential.status', '!=', 2)
        ->get();
    $data->other_credential = $other_credential;
    $data->contact_person_name = $data->contact_person_name ? json_decode($data->contact_person_name) : [];
    $data->contact_person_no = $data->contact_person_no ? json_decode($data->contact_person_no) : [];
    $contact_person_relation_ids = $data->contact_person_relation ? json_decode($data->contact_person_relation) : [];
    $relation=DB::table('egc_relationship_type')->whereIn('sno',$contact_person_relation_ids)->pluck('relationship_name');
    $data->relationship=$relation;

    $work_details = DB::table('egc_staff_work_info')
        ->select('egc_staff_work_info.*')
        ->where('egc_staff_work_info.staff_id', $id)
        ->where('egc_staff_work_info.status', '!=', 2)
        ->orderBy('egc_staff_work_info.sno','asc')
        ->get();
    
    $data->work_details =$work_details;

    $documents = DB::table('egc_staff_attachment')
    ->where('egc_staff_attachment.staff_id', $id)
    ->select('egc_staff_attachment.*','egc_documents.document_name')
    ->where('egc_staff_attachment.status', '!=', 2)
    ->join('egc_documents', 'egc_staff_attachment.document_id', '=', 'egc_documents.sno')
    ->get();
    $documentData = [];
    foreach ($documents as $doc) {
        $fileNames = json_decode($doc->attachment_name); // Decode the JSON file names
        $documentData[] = [
            'document_name' => $doc->document_name,
            'files' => array_map(function($fileName) use ($doc) {
                return asset("staff_attachments/{$doc->staff_id}/{$doc->document_id}/{$fileName}");
            }, $fileNames)
        ];
    }

    $qualification = DB::table('egc_staff_education_info')
    ->select('egc_staff_education_info.*','egc_education.education as qualification_name')
    ->where('egc_staff_education_info.status', '!=', 2)
    ->where('egc_staff_education_info.staff_id', $id)
    ->join('egc_education', 'egc_staff_education_info.qualification_type', '=', 'egc_education.sno')
    ->get();

    $document_checkList = DB::table('egc_document_checklist')
    ->select('egc_document_checklist.*')
    ->where('egc_document_checklist.status', '!=', 2)
    ->get();
    $document_checklist_snos = $data->document_checklist ? json_decode($data->document_checklist) : [];

      foreach ($document_checkList as $document) {
          if (in_array($document->sno, $document_checklist_snos)) {
              $document->is_checked = 1;
          } else {
              $document->is_checked = 0;
          }
      }
    $data->documents =$documentData;
    $data->qualification =$qualification;
    $data->document_checkList =$document_checkList;
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'staff not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Staff fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  
  public function Status($id, Request $request)
  {

    $staff =  StaffModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_StaffModel = StaffModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function getStaffByBranch(Request $request)
  {
      $department_id = $request->department_id;

      $staff = StaffModel::where('egc_staff.department_id', $department_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function getStaffByRole(Request $request)
  {
      $role_id = $request->role_id;

      $staff = StaffModel::where('egc_staff.job_role_id', $role_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function getStaffByDepart(Request $request)
  {
      $department_id = $request->department_id;

      $staff = StaffModel::where('egc_staff.department_id', $department_id)
          ->where('egc_staff.status', '!=', 2)
          ->select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', '>', 1)
          ->orderBy('egc_staff.staff_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'Staff data fetched Successfully',
      ]);
  }
  public function get_role_by_department(Request $request)
  {
      $department_id = $request->department_id;

      $staff = DB::table('egc_job_role')->where('egc_job_role.department_id', $department_id)
          ->where('egc_job_role.status',0)
          ->orderBy('egc_job_role.job_position_name', 'ASC')
          ->get();


      return response()->json([
          'status' => 200,
          'success' => true,
          'data' => $staff,
          'message' => 'role data fetched Successfully',
      ]);
  }



  public function save(Request $request)
{

    $user_id = $request->user()->user_id ?? 1;
  
    DB::transaction(function() use ($request,$user_id){
        $company_id= $request->company_id ?? 0;
        $enyity_id= $request->entity_id ?? 0 ;
        $workflow = ApprovalHierarchyModel::updateOrCreate(
            [
                'company_id'=>$company_id,
                'entity_id'=>$enyity_id,
                'department_id'=>$request->department_id,
                'job_role_id'=>$request->role_id
            ],
            [
              'approve_level'=>json_encode($request->levels),
              'updated_by'=>$user_id,
              'created_by'=>$user_id,
            ]
        ); 
    });

    return response()->json(['status'=>true]);
}


  function staffDataById(Request $request){
    $staff_id = $request->staff_id;

      $staff = StaffModel::select(
              'egc_staff.*',
              'egc_entity.entity_name',
              'egc_entity.entity_short_name',
              'egc_company.company_name',
              'egc_company.company_base_color',
              'egc_department.department_name',
              'egc_division.division_name',
              'egc_job_role.job_position_name as job_role_name'
          )
          ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
          ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
          ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
          ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
          ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
          ->where('egc_staff.sno', $staff_id)
          ->first();

      return response()->json([
          'status' => 200,
          'data' => $staff
      ]);
  }


  public function myApprovals()
  {
      return ApprovalTask::with('leave','employee')
          ->where('approver_staff_id',auth()->user()->staff_id)
          ->where('status',0)
          ->get();
  }

public function reject(Request $request)
{
    $task = ApprovalTask::findOrFail($request->task_id);

    DB::transaction(function() use ($task){

        $task->update([
            'status'=>2,
            'action_date'=>now(),
            'remarks'=>request('remarks')
        ]);

        LeaveRequest::where('sno',$task->request_id)
            ->update(['status'=>2]);
    });

    return response()->json(['message'=>'Rejected']);
}


public function approve(Request $request)
{
    $task = ApprovalTask::where('sno',$request->task_id)
            ->where('approver_staff_id',auth()->user()->staff_id)
            ->firstOrFail();

    DB::transaction(function() use ($task){

        // mark approved
        $task->update([
            'status'=>1,
            'action_date'=>now(),
            'remarks'=>request('remarks')
        ]);

        $leave = LeaveRequest::find($task->request_id);

        // next level?
        $nextLevel = ApprovalTask::where('request_id',$leave->sno)
                        ->where('level_no','>',$task->level_no)
                        ->where('status',0)
                        ->orderBy('level_no')
                        ->first();

        if($nextLevel){
            // move to next approver
            $leave->update([
                'current_level'=>$nextLevel->level_no
            ]);
        }else{
            // FINAL APPROVED
            $leave->update([
                'status'=>1
            ]);
        }
    });

    return response()->json(['message'=>'Approved']);
}


public function createApprovalFlow($leaveRequestId)
{
    $leave = LeaveRequest::find($leaveRequestId);

    $workflow = ApprovalHierarchyModel::where([
        'company_id'=>$leave->company_id,
        'entity_id'=>$leave->entity_id,
        'department_id'=>$leave->department_id,
        'role_id'=>$leave->role_id
    ])->first();

    if(!$workflow){
        throw new \Exception('Approval workflow not configured');
    }

    $levels = $workflow->approve_level ? json_decode($approve_level) : [];
   
    foreach($levels as $level){

        ApprovalTask::create([
            'request_id'=>$leave->sno,
            'level_no'=>$level->level_no,
            'approver_staff_id'=>$level->staff_id
        ]);
    }
}

public function getLeaveApprovalChain(Request $request)
{
    $staffId = $request->staff_id;

    // find staff department & role
    $staff = Staff::find($staffId);

    $workflow = ApprovalMatrix::where([
        'company_id' => $staff->company_id,
        'entity_id' => $staff->entity_id,
        'department_id' => $staff->department_id,
        'role_id' => $staff->role_id
    ])->first();

    if(!$workflow){
        return response()->json(['status'=>false]);
    }

    $levels = json_decode($workflow->levels,true);

    $result=[];

    foreach($levels as $lvl){

        $emp = Staff::find($lvl['staff_id']);

        if($emp){
            $result[]=[
                'staff_name'=>$emp->staff_name,
                'role_name'=>$emp->job_role_name,
                'role_type'=>$emp->role_type ?? 'Manager'
            ];
        }
    }

    return response()->json([
        'status'=>true,
        'data'=>$result
    ]);
}

public function indexMyself(Request $request)
  {

    $user_id = $request->user()->user_id;
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $company_fill = $request->company_fill ?? '';
    $entity_fill = $request->entity_fill ?? '';
    $department_fill = $request->department_fill ?? '';
    $division_fill = $request->division_fill ?? '';
    $job_role_fill = $request->job_role_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->to_dt_iss_rpt ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';

     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffProfile = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_entity.entity_base_color',
      'egc_department.department_name',
      'egc_branch.branch_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno',$user_id)->first();
        if($staffProfile->company_type == 1){
              $staffProfile->company_name=$general_setting->title;
              $staffProfile->company_base_color ='#ab2b22';
        }

    $approve_level = ApprovalHierarchyModel::where('job_role_id', $staffProfile->job_role_id)
    ->where('status', 0)
    ->value('approve_level');

    $approve_level = $approve_level
        ? collect(json_decode($approve_level))
        : collect();
      $approve_level_final =[];
    if ($approve_level->count() > 0) {

        $approve_level_final = $approve_level->map(function ($item) {

            $approver = StaffModel::where('egc_staff.status', '!=', 2)
                ->select(
                    'egc_staff.*',
                    'egc_entity.entity_name',
                    'egc_entity.entity_short_name',
                    'egc_company.company_name',
                    'egc_company.company_base_color',
                    'egc_entity.entity_base_color',
                    'egc_department.department_name',
                    'egc_branch.branch_name',
                    'egc_division.division_name',
                    'egc_job_role.job_position_name as job_role_name'
                )
                ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
                ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
                ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
                ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
                ->where('egc_staff.sno', $item->staff_id)
                ->first();

            if (!$approver) {
                return null; 
            }

            return [
                'level'               => $item->level,
                'company_id'          => $item->company,
                'entity_id'           => $item->entity,
                'department_id'       => $item->department,
                'staff_id'            => $item->staff_id,
                'nick_name'           => $approver->nick_name,
                'staff_name'           => $approver->staff_name,
                'gender'              => $approver->gender,
                'department_name'     => $approver->department_name,
                'division_name'       => $approver->division_name,
                'job_role_name'       => $approver->job_role_name,
                'company_base_color'  => $approver->company_base_color,
                'company_name'        => $approver->company_name,
                'entity_name'         => $approver->entity_name,
            ];
        })->filter()->values(); // remove nulls
    }
    

     $leaveRequests = LeavePermissionModel::where('staff_id', $user_id)
        ->orderBy('created_at', 'desc');

            if ($request->has('search_filter') && $request->search_filter != '') {
                $leaveRequests->where('reason', 'LIKE', "%" . $request->search_filter . "%")
                    ->orWhere('leave_type', 'LIKE', "%" . $request->search_filter . "%");
            }

            // Apply date filter if provided (custom or predefined like "today", "week", "monthly")
            if ($request->has('date_filter')) {
                $date_filter = $request->date_filter;
                if ($date_filter == 'today') {
                    $leaveRequests->whereDate('from_date', now()->toDateString());
                } elseif ($date_filter == 'week') {
                    $leaveRequests->whereBetween('from_date', [
                        now()->startOfWeek()->toDateString(),
                        now()->endOfWeek()->toDateString()
                    ]);
                } elseif ($date_filter == 'monthly') {
                    $leaveRequests->whereMonth('from_date', now()->month);
                } elseif ($date_filter == 'custom_date' && $request->has('from_date_filter') && $request->has('to_date_filter')) {
                    $leaveRequests->whereBetween('from_date', [
                        date('Y-m-d', strtotime($request->from_date_filter)),
                        date('Y-m-d', strtotime($request->to_date_filter))
                    ]);
                }
            }

      $leaveRequests = $leaveRequests->paginate($perpage);
                
               
       

        if ($request->ajax()) {
            $data = $leaveRequests->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $leaveRequests->currentPage(),
                'last_page' => $leaveRequests->lastPage(),
                'total' => $leaveRequests->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    //  return $staffProfile;
    return view('content.my_self.leave_permission.leave_permission_list',[
        'staffProfile' => $staffProfile,
        'approve_level' => $approve_level_final,
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        'company_fill' => $company_fill,
        'date_filter' => $date_filter,
        'job_role_fill' => $job_role_fill,
        'division_fill' => $division_fill,
        'department_fill' => $department_fill,
        'entity_fill' => $entity_fill,
        ]);
  }


public function AddLeavePermissionMyself(Request $request)
{
    // Get user ID and staff data
    $user_id = $request->user()->user_id ?? 1;
    $staff = staffModel::where('sno', $request->staff_id)->first();

    if (!$staff) {
        return response()->json([
            'status' => false,
            'message' => 'Staff not found',
            'error' => 'Staff not found',
        ]);
    }

    DB::transaction(function () use ($request, $user_id, $staff) {
        // Retrieve necessary staff details
        $company_id = $staff->company_id ?? 0;
        $entity_id = $staff->entity_id ?? 0;
        $department_id = $staff->department_id ?? 0;
        $job_role_id = $staff->job_role_id ?? 0;
        $request_type = $request->request_type;

        // Handle workflow creation or update
        $workflow = ApprovalHierarchyModel::firstOrCreate(
            [
                'company_id' => $company_id,
                'entity_id' => $entity_id,
                'department_id' => $department_id,
                'job_role_id' => $job_role_id,
            ],
            [
                'approve_level' => json_encode([
                    [
                        'level' => '1',
                        'company' => '0', 
                        'entity' => '0',   
                        'department' => '1', 
                        'staff_id' => $this->getHrStaff(),
                    ]
                ]),
                'updated_by' => $user_id,
                'created_by' => $user_id,
            ]
        );

        // Decode approve levels
        $levels = json_decode($workflow->approve_level);

        // Generate request ID
        $request_id = $this->generateRequestId();

        // Process leave data
        foreach ($request->leaveData as $data) {
            $date = date('Y-m-d', strtotime($data['date']));
            $from_time = $request_type == 'Leave' ? null : date('H:i:s', strtotime($data['fromTime']));
            $to_time = $request_type == 'Leave' ? null : date('H:i:s', strtotime($data['toTime']));
            $type = $request_type == 'Leave' ? $data['type'] : null;

            // Create LeavePermission entry
            $leave = LeavePermissionModel::create([
                'request_id' => $request_id,
                'staff_id' => $request->staff_id,
                'from_date' => $date,
                'reason' =>  $data['reason'],
                'leave_type' => $type,
                'request_type' => $request_type,
                'from_time' => $from_time,
                'to_time' => $to_time,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
            
            // Create LeaveApproval entries for each approval level
            foreach ($levels as $level) {
                LeaveApprovalModel::create([
                    'request_id' => $leave->sno,
                    'level_no' => $level->level,
                    'approver_staff_id' => $level->staff_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                ]);
            }
        }
    });

    return response()->json([
        'status' => true,
        'message' => 'Leave/Permission request submitted successfully.',
    ]);
}

  // Helper method to get HR Staff
  private function getHrStaff()
  {
      $HrStaff = staffModel::where('department_id', 1)
          ->where('division_id', 1)
          ->where('job_role_id', 1)
          ->where('status', 0)
          ->orderBy('sno', 'asc')
          ->first();

      return $HrStaff ? $HrStaff->sno : 2;  // Fallback to staff ID 2 if no HR staff is found
  }

  // Helper method to generate a unique request ID
  private function generateRequestId()
  {
      $lastLeaveData = LeavePermissionModel::orderBy('sno', 'desc')->first();
      $year = date('y');
      $month = date('m');

      if (!$lastLeaveData) {
          return "REQST-0001-{$month}-{$year}";
      } else {
          preg_match('/REQST-(\d+)/', $lastLeaveData->request_id, $matches);
          $nextNumber = isset($matches[1]) ? ((int)$matches[1] + 1) : 1;
          return 'REQST-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT) . '-' . $month . '-' . $year;
      }
  }


  public function StaffDetails(Request $request)
  {

    $user_id = $request->user()->user_id;
    $staff_id = $request->staff_id;
    $date = $request->date;
     
    $helper = new \App\Helpers\Helpers();
    $general_setting=$helper->general_setting_data();

    $staffProfile = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_entity.entity_base_color',
      'egc_department.department_name',
      'egc_branch.branch_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
      ->where('egc_staff.sno',$staff_id)->first();
        if($staffProfile->company_type == 1){
              $staffProfile->company_name=$general_setting->title;
              $staffProfile->company_base_color ='#ab2b22';
        }

    $approve_level = ApprovalHierarchyModel::where('job_role_id', $staffProfile->job_role_id)
    ->where('status', 0)
    ->value('approve_level');

    $approve_level = $approve_level
        ? collect(json_decode($approve_level))
        : collect();
    $approve_level_final =[];
    if ($approve_level->count() > 0) {

        $approve_level_final = $approve_level->map(function ($item) {

            $approver = StaffModel::where('egc_staff.status', '!=', 2)
                ->select(
                    'egc_staff.*',
                    'egc_entity.entity_name',
                    'egc_entity.entity_short_name',
                    'egc_company.company_name',
                    'egc_company.company_base_color',
                    'egc_entity.entity_base_color',
                    'egc_department.department_name',
                    'egc_branch.branch_name',
                    'egc_division.division_name',
                    'egc_job_role.job_position_name as job_role_name'
                )
                ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
                ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
                ->leftJoin('egc_branch', 'egc_staff.branch_id', 'egc_branch.sno')
                ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
                ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
                ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
                ->where('egc_staff.sno', $item->staff_id)
                ->first();

            if (!$approver) {
                return null; 
            }

            return [
                'level'               => $item->level,
                'company_id'          => $item->company,
                'entity_id'           => $item->entity,
                'department_id'       => $item->department,
                'staff_id'            => $item->staff_id,
                'nick_name'           => $approver->nick_name,
                'staff_name'           => $approver->staff_name,
                'gender'              => $approver->gender,
                'department_name'     => $approver->department_name,
                'division_name'       => $approver->division_name,
                'job_role_name'       => $approver->job_role_name,
                'company_base_color'  => $approver->company_base_color,
                'company_name'        => $approver->company_name,
                'entity_name'         => $approver->entity_name,
            ];
        })->filter()->values(); // remove nulls
    }
    //  return $staffProfile;
   

    return response()->json([
        'status' => true,
        'message' => 'Staff Data Get SuccessFully',
        'error' => NULL,
        'staffProfile' => $staffProfile,
        'approve_level' => $approve_level_final,
    ]);
  }


// public function updateStatus(Request $request)
// {
//     $request->validate([
//         'request_id' => 'required|exists:egc_leave_permission,sno',
//         'status' => 'required|in:1,3,4', // 1 = Approved, 3 = OnHold, 4 = Rejected
//         'remarks' => 'nullable|string|max:255'
//     ]);

//     $leaveRequest = LeavePermissionModel::find($request->request_id);

//     // Check if the current user is the approver for this request
//     $approver = LeaveApprovalModel::where('request_id', $request->request_id)
//         ->where('approver_staff_id', auth()->user()->user_id)
//         ->where('status', 0) // Pending approval
//         ->first();

//     if (!$approver) {
//         return response()->json(['error' => 'You are not authorized to update the status.'], 403);
//     }

//     // Update the status
//     $leaveRequest->status = $request->status;
//     $leaveRequest->remarks = $request->remarks;
//     $leaveRequest->save();

//     // Return a response
//     return response()->json(['success' => true]);
// }

public function updateStatus(Request $request)
{
    $request->validate([
        'request_id' => 'required|exists:egc_leave_permission,sno',
        'status' => 'required|in:1,3,4', // 1 = Approved, 3 = OnHold, 4 = Rejected
        'remarks' => 'nullable|string|max:255',
        'approver_staff_id' => 'required' // Validate the approver_staff_id
    ]);

    $leaveRequest = LeavePermissionModel::find($request->request_id);

    // Check if the current user is the approver for this request
    $approver = LeaveApprovalModel::where('request_id', $request->request_id)
        ->where('approver_staff_id', $request->approver_staff_id) // Use approver_staff_id from request
        ->where('status', 0) // Pending approval
        ->first();

    if (!$approver) {
        return response()->json(['error' => 'You are not authorized to update the status.'], 403);
    }

    // Update the LeaveApprovalModel status
    $approver->status = $request->status;
    $approver->remarks = $request->remarks;
    $approver->action_date = now();
    $approver->save();

    // Check if all approval levels are completed
    $allLevelsUpdated = LeaveApprovalModel::where('request_id', $request->request_id)
        ->where('status', 0) // still pending approval
        ->count() === 0;

    // Determine the highest approver level
    $highestLevelApprover = LeaveApprovalModel::where('request_id', $request->request_id)
        ->orderByDesc('level_no')
        ->first(); // Get the highest approver based on level_no

    // If all levels are updated or if the current approver is the highest level approver, update LeavePermissionModel status
    if ($allLevelsUpdated || $approver->level_no === $highestLevelApprover->level_no) {
        // Update the status in LeavePermissionModel based on the highest status
        $leaveRequest->status = $this->determineLeaveRequestStatus($request->status);
        $leaveRequest->save();
    }

    return response()->json(['success' => true]);
}

// Determine the final status of the LeaveRequest
private function determineLeaveRequestStatus($status)
{
    switch ($status) {
        case 1: return 1; // Approved
        case 3: return 3; // OnHold
        case 4: return 4; // Rejected
        default: return 0; // Pending
    }
}

public function getApprovalLevels(Request $request)
{
    $request->validate([
        'request_id' => 'required|exists:egc_leave_permission,sno',
    ]);

    $leaveRequest = LeavePermissionModel::select(
            'egc_leave_permission.*',
            'egc_staff.staff_name',
            'egc_staff.nick_name',
            'egc_staff.gender',
            'egc_staff.staff_image',
            'egc_staff.mobile_no',
            'egc_staff.email_id',
            'egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
        )
        ->join('egc_staff', 'egc_staff.sno', 'egc_leave_permission.staff_id')
        ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
        ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
        ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
        ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
        ->where('egc_leave_permission.sno', $request->request_id)
        ->first();

    // Get current leave counts and approval levels
    $currentMonth = date('m');
    $currentYear = date('Y');

    $approvalLevels = LeaveApprovalModel::where('request_id', $request->request_id)
        ->join('egc_staff', 'egc_approval_tasks.approver_staff_id', '=', 'egc_staff.sno')
        ->select('egc_approval_tasks.level_no', 'egc_staff.staff_name','egc_approval_tasks.approver_staff_id', 'egc_approval_tasks.status as approval_status')
        ->orderBy('egc_approval_tasks.level_no')
        ->get();

    return response()->json([
        'leaveRequest' => $leaveRequest,
        'approvalLevels' => $approvalLevels,
    ]);
}
  
}