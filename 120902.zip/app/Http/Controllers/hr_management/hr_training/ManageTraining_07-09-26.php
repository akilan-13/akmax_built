<?php

namespace App\Http\Controllers\hr_management\hr_training;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CompanyModel;
use App\Models\DepartmentModel;
use App\Models\JobRoleModel;
use App\Models\StaffModel;
use App\Models\TrainingPlannerAttendeeModel;
use App\Models\TrainingPlannerModel;
use App\Models\TrainingPlannerSessionModel;
use App\Models\TrainingPlannerSessionAttendanceModel;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ManageTraining extends Controller
{
    private const ACTIVE_STATUS = 0;
    private const DELETED_STATUS = 2;

    private const PLANNER_SCHEDULED = 'scheduled';
    private const PLANNER_CANCELLED = 'cancelled';
    private const PLANNER_RESCHEDULED = 'rescheduled';
    private const PLANNER_COMPLETED = 'completed';

    public function index()
    {
        return view('content.hr_management.hr_training.manage_training.list');
    }

    /**
     * AJAX list + KPI + calendar source.
     * mode=list      => paginated table rows
     * mode=calendar  => events in requested date window
     */
    public function data(Request $request): JsonResponse
    {
        $mode = $request->input('mode', 'list');
        $query = TrainingPlannerModel::query()
            ->where('egc_training_planner.status', '!=', self::DELETED_STATUS)
            ->orderByDesc('sno');

        $this->applyFilters($query, $request);

        if ($mode === 'calendar') {
            $start = $request->filled('start') ? Carbon::parse($request->start)->startOfDay() : now()->startOfMonth();
            $end = $request->filled('end') ? Carbon::parse($request->end)->endOfDay() : now()->endOfMonth();

            $query->where(function ($q) use ($start, $end) {
                $q->whereDate('schedule_from_date', '<=', $end->toDateString())
                    ->whereDate(DB::raw('COALESCE(schedule_to_date, schedule_date)'), '>=', $start->toDateString());
            });

            $rows = $query->get();
            return response()->json([
                'status' => 200,
                'data' => $rows->map(fn ($training) => $this->serializeTraining($training))->values(),
            ]);
        }

        $perPage = min(max((int) $request->input('per_page', 25), 10), 100);
        $paginator = $query->paginate($perPage);

        $rows = $paginator->getCollection()->map(fn ($training) => $this->serializeTraining($training));
        $paginator->setCollection($rows);

        $base = TrainingPlannerModel::where('status', '!=', self::DELETED_STATUS);
        $stats = [
            'total' => (clone $base)->count(),
            'scheduled' => (clone $base)->where('planner_status', self::PLANNER_SCHEDULED)->count(),
            'rescheduled' => (clone $base)->where('planner_status', self::PLANNER_RESCHEDULED)->count(),
            'completed' => (clone $base)->where('planner_status', self::PLANNER_COMPLETED)->count(),
            'cancelled' => (clone $base)->where('planner_status', self::PLANNER_CANCELLED)->count(),
            'upcoming' => (clone $base)
                ->whereIn('planner_status', [self::PLANNER_SCHEDULED, self::PLANNER_RESCHEDULED])
                ->whereDate(DB::raw('COALESCE(schedule_to_date, schedule_date)'), '>=', now()->toDateString())
                ->count(),
        ];

        return response()->json([
            'status' => 200,
            'data' => $paginator,
            'stats' => $stats,
            
        ]);
    }

    private function applyFilters($query, Request $request): void
    {
        $search = trim((string) $request->input('search', ''));
        $mode = $request->input('training_mode');
        $status = $request->input('planner_status');
        $trainer = $request->input('trainer');
        $from = $request->input('from_date');
        $to = $request->input('to_date');

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('training_planner_name', 'like', "%{$search}%")
                    ->orWhere('training_planner_id', 'like', "%{$search}%")
                    ->orWhere('trainer_name', 'like', "%{$search}%")
                    ->orWhere('training_desc', 'like', "%{$search}%");
            });
        }

        if ($mode !== null && $mode !== '') {
            $query->where('training_mode', (int) $mode);
        }

        if ($status !== null && $status !== '') {
            $query->where('planner_status', $status);
        }

        if ($trainer !== null && $trainer !== '') {
            $query->where('trainer', (int) $trainer);
        }

        if ($from) {
            $query->whereDate(DB::raw('COALESCE(schedule_to_date, schedule_date)'), '>=', Carbon::parse($from)->toDateString());
        }

        if ($to) {
            $query->whereDate(DB::raw('COALESCE(schedule_from_date, schedule_date)'), '<=', Carbon::parse($to)->toDateString());
        }
    }

    public function lookups(): JsonResponse
    {
        return response()->json([
            'status' => 200,
            'data' => [
                'companies' => CompanyModel::where('status', 0)->orderBy('company_name')->get(['sno', 'company_name']),
                'branches' => BranchModel::where('status', '!=', 2)->orderBy('sno')->get(['sno', 'branch_name', 'franchise_name', 'branch_type', 'entity_id', 'company_id']),
                'departments' => DepartmentModel::where('status', '!=', 2)->orderBy('department_name')->get(['sno', 'department_name']),
                'job_roles' => JobRoleModel::where('status', '!=', 2)->orderBy('job_position_name')->get(['sno', 'job_position_name']),
            ],
        ]);
    }

    public function entities(Request $request): JsonResponse
    {
        $companyIds = $this->normaliseIds($request->input('company_ids', []));
        $query = DB::table('egc_entity')->where('status', '!=', 2);

        $otherCompanyIds = array_values(array_filter($companyIds, fn ($id) => $id !== 0));
        if ($otherCompanyIds) {
            $query->whereIn('company_id', $otherCompanyIds);
        }

        return response()->json([
            'status' => 200,
            'data' => $query->orderBy('entity_name')->get(['sno', 'entity_name', 'entity_short_name', 'company_id']),
        ]);
    }

    public function branches(Request $request): JsonResponse
    {
        $entityIds = $this->normaliseIds($request->input('entity_ids', []));
        $companyIds = $this->normaliseIds($request->input('company_ids', []));

        $query = BranchModel::where('status', '!=', 2);

        $otherCompanyIds = array_values(array_filter($companyIds, fn ($id) => $id !== 0));
        if ($entityIds && !in_array(0, $entityIds, true)) {
            $query->whereIn('entity_id', $entityIds);
        } elseif ($otherCompanyIds) {
            $query->whereIn('company_id', $otherCompanyIds);
        }

        return response()->json([
            'status' => 200,
            'data' => $query->orderBy('sno')->get(['sno', 'branch_name', 'franchise_name', 'branch_type', 'entity_id', 'company_id']),
        ]);
    }

    /**
     * Staff list with server-side availability. The same rules are rechecked during save.
     */
    public function staffAvailability(Request $request): JsonResponse
    {
        $payload = Validator::make($request->all(), [
            'company_ids' => 'required|array|min:1',
            'entity_ids' => 'nullable|array',
            'branch_ids' => 'nullable|array',
            'schedule_type' => 'required|in:range,custom',
            'from_date' => 'required_if:schedule_type,range|nullable|date',
            'to_date' => 'required_if:schedule_type,range|nullable|date|after_or_equal:from_date',
            'from_time' => 'required|date_format:H:i',
            'to_time' => 'required|date_format:H:i',
            'custom_dates' => 'required_if:schedule_type,custom|array|min:1',
            'custom_dates.*' => 'required_if:schedule_type,custom|date',
            'exclude_training_id' => 'nullable|integer',
        ])->validate();
        $this->normaliseBusinessScope($payload);
        $segments = $this->scheduleSegmentsFromPayload($payload);

        $staff = $this->staffQuery($payload)->get();
        $busy = $this->busyStaffMap($segments, (int) ($payload['exclude_training_id'] ?? 0));
        $selectedTrainerId = (int) $request->input('selected_trainer', 0);

        $data = $staff->map(function ($person) use ($busy, $selectedTrainerId) {
            $conflicts = $busy[(int) $person->sno] ?? [];
            $isTrainer = $selectedTrainerId > 0 && (int) $person->sno === $selectedTrainerId;

            $helper = new \App\Helpers\Helpers();
            $general_setting = $helper->general_setting_data();
            $entity_name = $person->entity_name ?? $general_setting->title;
            $entity_base_color = $person->entity_base_color ?? '#ab2b22';
            return [
                'sno' => (int) $person->sno,
                'staff_name' => $person->staff_name,
                'staff_image_url' => $person->profile_image_url,
                'entity_name' => $entity_name,
                'entity_base_color' => $entity_base_color,
                'email_id' => $person->email_id ?? null,
                'department_id' => (int) ($person->department_id ?? 0),
                'department_name' => $person->department_name ?? '-',
                'job_role_id' => (int) ($person->job_role_id ?? 0),
                'job_role_name' => $person->job_role_name ?? '-',
                'company_id' => (int) ($person->company_id ?? 0),
                'entity_id' => (int) ($person->entity_id ?? 0),
                'branch_id' => (int) ($person->branch_id ?? 0),
                'available' => empty($conflicts),
                'conflicts' => $conflicts,
                'is_trainer' => $isTrainer,
            ];
        })->values();

        return response()->json(['status' => 200, 'data' => $data]);
    }

    public function checkConflicts(Request $request): JsonResponse
    {
        $validated = $this->validatePlannerPayload($request, true);
        $ignoreId = (int) ($request->input('training_id') ?: 0);
        $segments = $this->scheduleSegmentsFromPayload($validated);
        $conflicts = $this->findConflicts($validated, $segments, $ignoreId);

        return response()->json([
            'status' => 200,
            'conflicts' => $conflicts,
            'has_conflict' => !empty($conflicts['trainer']) || !empty($conflicts['attendees']),
        ]);
    }

    public function show($id): JsonResponse
    {
        $training = $this->trainingForApi($id);
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        return response()->json(['status' => 200, 'data' => $this->serializeTraining($training, true)]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validatePlannerPayload($request);
        $this->normaliseBusinessScope($validated);

        DB::beginTransaction();
        try {
            $segments = $this->scheduleSegmentsFromPayload($validated);
            [$start, $end] = $this->segmentBounds($segments);
            $conflicts = $this->findConflicts($validated, $segments, 0);
            if (!empty($conflicts['trainer']) || !empty($conflicts['attendees'])) {
                DB::rollBack();
                return response()->json([
                    'status' => 422,
                    'message' => 'Schedule conflict detected. Please review the highlighted trainer/attendees.',
                    'conflicts' => $conflicts,
                ], 422);
            }

            $id = $this->generatePlannerId();
            $userId = auth()->user()->user_id ?? auth()->id() ?? 0;
            $staffIds = $this->normaliseIds($validated['staff_ids'] ?? []);

            $training = TrainingPlannerModel::create([
                'training_planner_id' => $id,
                'company_ids' => $validated['company_ids'],
                'entity_ids' => $validated['entity_ids'],
                'branch_ids' => $validated['branch_ids'],
                'training_planner_name' => $this->titleCase($validated['training_planner_name']),
                'training_mode' => (int) $validated['training_mode'],
                'trainer' => (int) $validated['trainer'],
                'trainer_name' => (int) $validated['trainer'] === 0 ? $validated['trainer_name'] : null,
                'training_duration' => $this->durationHoursFromSegments($segments),
                'schedule_date' => $start->toDateString(),
                'schedule_time' => $start->format('H:i:s'),
                'schedule_type' => $validated['schedule_type'],
                'schedule_sessions' => $validated['schedule_type'] === 'custom' ? $segments : [],
                'schedule_from_date' => $start->toDateString(),
                'schedule_to_date' => $end->toDateString(),
                'schedule_from_time' => $start->format('H:i:s'),
                'schedule_to_time' => $end->format('H:i:s'),
                'training_desc' => $validated['training_desc'] ?? null,
                'all_check' => (int) ($validated['all_attendees'] ?? 0),
                'staff_check' => $staffIds,
                'attendance_status' => null,
                'certificate_available' => (int) ($validated['certificate_available'] ?? 0),
                'assessment_required' => (int) ($validated['assessment_required'] ?? 0),
                'certificate_name' => $validated['certificate_name'] ?? null,
                'assessment_pass_percentage' => $validated['assessment_pass_percentage'] ?? null,
                'planner_status' => self::PLANNER_SCHEDULED,
                'created_by' => $userId,
                'updated_by' => $userId,
                'status' => self::ACTIVE_STATUS,
            ]);

            $this->syncAttendees($training, $staffIds);
            $this->syncSessions($training, $segments);
            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Training planner created successfully.',
                'data' => $this->serializeTraining($training->fresh(), true),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);
            return response()->json(['status' => 500, 'message' => 'Unable to create training planner.'], 500);
        }
    }

    public function update(Request $request, $id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)->where('status', '!=', self::DELETED_STATUS)->first();
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        if (in_array($training->planner_status, [self::PLANNER_COMPLETED, self::PLANNER_CANCELLED], true)) {
            return response()->json(['status' => 422, 'message' => 'Completed or cancelled training cannot be edited.'], 422);
        }

        $validated = $this->validatePlannerPayload($request, true);
        $this->normaliseBusinessScope($validated);

        DB::beginTransaction();
        try {
            $segments = $this->scheduleSegmentsFromPayload($validated);
            [$start, $end] = $this->segmentBounds($segments);
            $conflicts = $this->findConflicts($validated, $segments, (int) $training->sno);
            if (!empty($conflicts['trainer']) || !empty($conflicts['attendees'])) {
                DB::rollBack();
                return response()->json([
                    'status' => 422,
                    'message' => 'Schedule conflict detected. Please review the highlighted trainer/attendees.',
                    'conflicts' => $conflicts,
                ], 422);
            }

            $newStatus = $request->input('planner_status', $training->planner_status);
            if (!in_array($newStatus, [self::PLANNER_SCHEDULED, self::PLANNER_RESCHEDULED], true)) {
                $newStatus = self::PLANNER_SCHEDULED;
            }

            $userId = auth()->user()->user_id ?? auth()->id() ?? 0;
            $staffIds = $this->normaliseIds($validated['staff_ids'] ?? []);
            $oldSchedule = $this->scheduleSignature($training);
            $newSchedule = $start->format('Y-m-d H:i:s') . '|' . $end->format('Y-m-d H:i:s');
            $changedSchedule = $oldSchedule !== $newSchedule;

            $training->fill([
                'company_ids' => $validated['company_ids'],
                'entity_ids' => $validated['entity_ids'],
                'branch_ids' => $validated['branch_ids'],
                'training_planner_name' => $this->titleCase($validated['training_planner_name']),
                'training_mode' => (int) $validated['training_mode'],
                'trainer' => (int) $validated['trainer'],
                'trainer_name' => (int) $validated['trainer'] === 0 ? $validated['trainer_name'] : null,
                'training_duration' => $this->durationHoursFromSegments($segments),
                'schedule_date' => $start->toDateString(),
                'schedule_time' => $start->format('H:i:s'),
                'schedule_type' => $validated['schedule_type'],
                'schedule_sessions' => $validated['schedule_type'] === 'custom' ? $segments : [],
                'schedule_from_date' => $start->toDateString(),
                'schedule_to_date' => $end->toDateString(),
                'schedule_from_time' => $start->format('H:i:s'),
                'schedule_to_time' => $end->format('H:i:s'),
                'training_desc' => $validated['training_desc'] ?? null,
                'all_check' => (int) ($validated['all_attendees'] ?? 0),
                'staff_check' => $staffIds,
                'certificate_available' => (int) ($validated['certificate_available'] ?? 0),
                'assessment_required' => (int) ($validated['assessment_required'] ?? 0),
                'certificate_name' => $validated['certificate_name'] ?? null,
                'assessment_pass_percentage' => $validated['assessment_pass_percentage'] ?? null,
                'planner_status' => $changedSchedule ? self::PLANNER_RESCHEDULED : $newStatus,
                'reschedule_reason' => $changedSchedule ? ($request->input('reschedule_reason') ?: 'Schedule updated') : $training->reschedule_reason,
                'updated_by' => $userId,
            ]);
            $training->save();

            $this->syncAttendees($training, $staffIds);
            $this->syncSessions($training, $segments);
            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => $changedSchedule ? 'Training rescheduled successfully.' : 'Training planner updated successfully.',
                'data' => $this->serializeTraining($training->fresh(), true),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);
            return response()->json(['status' => 500, 'message' => 'Unable to update training planner.'], 500);
        }
    }

    public function changeStatus(Request $request, $id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)->where('status', '!=', self::DELETED_STATUS)->first();
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $validated = $request->validate([
            'planner_status' => 'required|in:scheduled,cancelled,rescheduled',
            'reason' => 'nullable|string|max:1000',
            'schedule_type' => 'nullable|in:range,custom',
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date|after_or_equal:from_date',
            'from_time' => 'nullable|date_format:H:i',
            'to_time' => 'nullable|date_format:H:i',
            'custom_dates' => 'nullable|array',
            'custom_dates.*' => 'date',
        ]);

        if ($validated['planner_status'] === self::PLANNER_CANCELLED && trim((string) ($validated['reason'] ?? '')) === '') {
            return response()->json(['status' => 422, 'message' => 'Cancellation reason is required.'], 422);
        }

        if ($validated['planner_status'] === self::PLANNER_RESCHEDULED) {
            $scheduleType = $validated['schedule_type'] ?? 'custom';

            if (empty($validated['from_time']) || empty($validated['to_time'])) {
                return response()->json(['status' => 422, 'message' => 'Start time and end time are required for rescheduling.'], 422);
            }

            if ($scheduleType === 'custom' && empty($validated['custom_dates'])) {
                return response()->json(['status' => 422, 'message' => 'Select at least one custom date for rescheduling.'], 422);
            }

            if ($scheduleType === 'range' && (empty($validated['from_date']) || empty($validated['to_date']))) {
                return response()->json(['status' => 422, 'message' => 'From date and To date are required for rescheduling.'], 422);
            }
        }

        DB::beginTransaction();
        try {
            $userId = auth()->user()->user_id ?? auth()->id() ?? 0;

            if ($validated['planner_status'] === self::PLANNER_RESCHEDULED) {
                $schedulePayload = [
                    'schedule_type' => $validated['schedule_type'] ?? 'range',
                    'from_date' => $validated['from_date'] ?? null,
                    'to_date' => $validated['to_date'] ?? null,
                    'from_time' => $validated['from_time'] ?? null,
                    'to_time' => $validated['to_time'] ?? null,
                    'custom_dates' => $validated['custom_dates'] ?? [],
                ];
                $segments = $this->scheduleSegmentsFromPayload($schedulePayload);
                [$start, $end] = $this->segmentBounds($segments);
                $conflicts = $this->findConflicts([
                    'trainer' => $training->trainer,
                    'trainer_name' => $training->trainer_name,
                    'staff_ids' => $training->staff_check ?: [],
                ], $segments, (int) $training->sno);

                if (!empty($conflicts['trainer']) || !empty($conflicts['attendees'])) {
                    DB::rollBack();
                    return response()->json(['status' => 422, 'message' => 'The new schedule conflicts with another training.', 'conflicts' => $conflicts], 422);
                }

                $training->schedule_date = $start->toDateString();
                $training->schedule_time = $start->format('H:i:s');
                $training->schedule_type = $schedulePayload['schedule_type'];
                $training->schedule_sessions = $schedulePayload['schedule_type'] === 'custom' ? $segments : [];
                $training->schedule_from_date = $start->toDateString();
                $training->schedule_to_date = $end->toDateString();
                $training->schedule_from_time = $start->format('H:i:s');
                $training->schedule_to_time = $end->format('H:i:s');
                $training->training_duration = $this->durationHoursFromSegments($segments);
                $training->reschedule_reason = trim((string) $validated['reason']);
                $this->syncSessions($training, $segments);
            }

            $training->planner_status = $validated['planner_status'];
            $training->cancelled_reason = $validated['planner_status'] === self::PLANNER_CANCELLED
                ? trim((string) $validated['reason']) : $training->cancelled_reason;
            $training->cancelled_at = $validated['planner_status'] === self::PLANNER_CANCELLED ? now() : null;
            $training->updated_by = $userId;
            $training->save();

            DB::commit();
            return response()->json(['status' => 200, 'message' => 'Training status updated successfully.', 'data' => $this->serializeTraining($training->fresh(), true)]);
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);
            return response()->json(['status' => 500, 'message' => 'Unable to update training status.'], 500);
        }
    }

    public function complete(Request $request, $id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)->where('status', '!=', self::DELETED_STATUS)->first();
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }
        if ($training->planner_status === self::PLANNER_CANCELLED) {
            return response()->json(['status' => 422, 'message' => 'Cancelled training cannot be completed.'], 422);
        }

        [, $trainingEnd] = $this->trainingRange($training);
        if ($trainingEnd->isFuture()) {
            return response()->json(['status' => 422, 'message' => 'Training can be completed only after its scheduled end time.'], 422);
        }

        $sessions = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)->get();
        if ($sessions->isNotEmpty()) {
            $unfinished = $sessions->where(fn ($session) => $session->session_status !== 'completed' || !(bool) $session->syllabus_completed);
            if ($unfinished->isNotEmpty()) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Complete every training session attendance and syllabus before completing the training planner.',
                    'unfinished_sessions' => $unfinished->pluck('session_no')->values(),
                ], 422);
            }
        }

        $payload = $request->validate([
            'attendance' => 'required|array|min:1',
            'attendance.*.staff_id' => 'required|integer|min:1',
            'attendance.*.attendance_status' => 'required|in:0,1',
            'attendance.*.certificate_issued' => 'nullable|boolean',
            'attendance.*.assessment_status' => 'nullable|in:0,1',
            'attendance.*.assessment_score' => 'nullable|numeric|min:0|max:100',
        ]);

        $allowed = $this->normaliseIds($training->staff_check ?: []);
        $submitted = collect($payload['attendance'])->pluck('staff_id')->map(fn ($id) => (int) $id)->unique()->values()->all();
        $invalid = array_diff($submitted, $allowed);
        if (!empty($invalid)) {
            return response()->json(['status' => 422, 'message' => 'One or more attendees do not belong to this training.'], 422);
        }

        DB::beginTransaction();
        try {
            $now = now();
            $attendanceLegacy = [];

            foreach ($payload['attendance'] as $item) {
                $staffId = (int) $item['staff_id'];
                $present = (int) $item['attendance_status'];
                TrainingPlannerAttendeeModel::updateOrCreate(
                    ['training_planner_id' => $training->sno, 'staff_id' => $staffId],
                    [
                        'attendance_status' => $present,
                        'attendance_marked_at' => $now,
                        'certificate_issued' => (int) ($item['certificate_issued'] ?? 0),
                        'assessment_status' => array_key_exists('assessment_status', $item) && $item['assessment_status'] !== null ? (int) $item['assessment_status'] : null,
                        'assessment_score' => $item['assessment_score'] ?? null,
                        'assessment_passed_at' => ((int) ($item['assessment_status'] ?? 0) === 1) ? $now : null,
                    ]
                );
                $attendanceLegacy[] = ['staff_id' => (string) $staffId, 'attendance' => $present === 1 ? 0 : 1];
            }

            $training->attendance_status = $attendanceLegacy;
            $training->planner_status = self::PLANNER_COMPLETED;
            $training->completed_at = $now;
            $training->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
            $training->save();

            DB::commit();
            return response()->json(['status' => 200, 'message' => 'Training completed and attendance saved successfully.', 'data' => $this->serializeTraining($training->fresh(), true)]);
        } catch (\Throwable $e) {
            DB::rollBack();
            report($e);
            return response()->json(['status' => 500, 'message' => 'Unable to complete training.'], 500);
        }
    }

    public function destroy($id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)->where('status', '!=', self::DELETED_STATUS)->first();
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $training->status = self::DELETED_STATUS;
        $training->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
        $training->save();

        return response()->json(['status' => 200, 'message' => 'Training planner deleted successfully.']);
    }

    /**
     * Return all materialized sessions for a training planner.
     */
    public function sessions($id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $sessions = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)
            ->withCount([
                'attendance as present_count' => fn ($q) => $q->where('attendance_status', 1),
                'attendance as absent_count' => fn ($q) => $q->where('attendance_status', 0),
            ])
            ->orderBy('session_date')
            ->orderBy('start_time')
            ->get()
            ->map(fn ($session) => $this->serializeSession($session, true))
            ->values();

        return response()->json([
            'status' => 200,
            'data' => [
                'training' => $this->serializeTraining($training, true),
                'sessions' => $sessions,
            ],
        ]);
    }

    /**
     * Return attendees for the dedicated attendee-management modal.
     */
    public function showAttendees($id): JsonResponse
    {
        $training = $this->trainingForApi($id);
        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $assigned = $this->normaliseIds($training->staff_check ?: []);
        $people = StaffModel::whereIn('sno', $assigned)
            ->where('status', 0)
            ->orderBy('staff_name')
            ->get()
            ->map(fn ($person) => [
                'staff_id' => (int) $person->sno,
                'staff_name' => $person->staff_name,
                'staff_image_url' => $person->profile_image_url ?? '',
                'department_id' => (int) ($person->department_id ?? 0),
                'job_role_id' => (int) ($person->job_role_id ?? 0),
            ])->values();

        $counts = $this->attendeeCounts($training, $assigned);

        return response()->json([
            'status' => 200,
            'data' => [
                'assigned' => $people,
                'assigned_ids' => $assigned,
                'counts' => $counts,
            ],
        ]);
    }

    /**
     * Add one or more attendees to an existing planner with full server-side conflict checking.
     */
    public function addAttendees(Request $request, $id): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        if (in_array($training->planner_status, [self::PLANNER_COMPLETED, self::PLANNER_CANCELLED], true)) {
            return response()->json(['status' => 422, 'message' => 'Attendees cannot be changed for completed or cancelled training.'], 422);
        }

        $validated = $request->validate([
            'staff_ids' => 'required|array|min:1',
            'staff_ids.*' => 'integer|min:1',
        ]);

        $currentIds = $this->normaliseIds($training->staff_check ?: []);
        $newIds = array_values(array_diff($this->normaliseIds($validated['staff_ids']), $currentIds));

        if (!$newIds) {
            return response()->json(['status' => 422, 'message' => 'All selected attendees are already assigned to this training.'], 422);
        }

        $segments = $this->trainingSegments($training);
        $conflicts = $this->findConflicts([
            'trainer' => (int) $training->trainer,
            'trainer_name' => $training->trainer_name,
            'staff_ids' => $newIds,
        ], $segments, (int) $training->sno);

        if (!empty($conflicts['trainer']) || !empty($conflicts['attendees'])) {
            return response()->json([
                'status' => 422,
                'message' => 'One or more attendees have a schedule conflict.',
                'conflicts' => $conflicts,
            ], 422);
        }

        $allowedStaff = StaffModel::whereIn('sno', $newIds)
            ->where('status', 0)
            ->where('sno', '>', 1)
            ->where('role_id', '!=', 1)
            ->pluck('sno')
            ->map(fn ($id) => (int) $id)
            ->all();

        $missing = array_values(array_diff($newIds, $allowedStaff));
        if ($missing) {
            return response()->json(['status' => 422, 'message' => 'One or more selected staff members are not active or valid.'], 422);
        }

        DB::transaction(function () use ($training, $currentIds, $newIds) {
            $all = array_values(array_unique(array_merge($currentIds, $newIds)));
            $training->staff_check = $all;
            $training->all_check = 0;
            $training->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
            $training->save();
            $this->syncAttendees($training, $all);
            $this->syncSessionAttendanceRows($training, $newIds);
        });

        return response()->json([
            'status' => 200,
            'message' => count($newIds) . ' attendee(s) added successfully.',
            'data' => $this->serializeTraining($training->fresh(), true),
        ]);
    }

    /**
     * Remove one attendee. Removal is blocked after any session attendance has been recorded.
     */
    public function removeAttendee(Request $request, $id, $staffId): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $staffId = (int) $staffId;
        if ((int) $training->trainer === $staffId) {
            return response()->json(['status' => 422, 'message' => 'The trainer cannot be removed as an attendee.'], 422);
        }

        $assigned = $this->normaliseIds($training->staff_check ?: []);
        if (!in_array($staffId, $assigned, true)) {
            return response()->json(['status' => 422, 'message' => 'Attendee is not assigned to this training.'], 422);
        }

        $hasAttendance = TrainingPlannerSessionAttendanceModel::where('training_planner_id', $training->sno)
            ->where('staff_id', $staffId)
            ->whereNotNull('attendance_status')
            ->exists();

        if ($hasAttendance) {
            return response()->json(['status' => 422, 'message' => 'This attendee cannot be removed because attendance has already been recorded.'], 422);
        }

        $assigned = array_values(array_diff($assigned, [$staffId]));

        DB::transaction(function () use ($training, $assigned, $staffId) {
            $training->staff_check = $assigned;
            $training->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
            $training->save();
            TrainingPlannerAttendeeModel::where('training_planner_id', $training->sno)->where('staff_id', $staffId)->delete();
            TrainingPlannerSessionAttendanceModel::where('training_planner_id', $training->sno)->where('staff_id', $staffId)->delete();
        });

        return response()->json(['status' => 200, 'message' => 'Attendee removed successfully.']);
    }

    /**
     * Update a single training session: title, syllabus, notes, completion and status.
     */
    public function updateSession(Request $request, $id, $sessionId): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $session = TrainingPlannerSessionModel::where('sno', $sessionId)
            ->where('training_planner_id', $training->sno)
            ->first();

        if (!$session) {
            return response()->json(['status' => 404, 'message' => 'Training session not found.'], 404);
        }

        $validated = $request->validate([
            'session_title' => 'nullable|string|max:255',
            'syllabus_details' => 'nullable|string|max:10000',
            'trainer_notes' => 'nullable|string|max:10000',
            'session_status' => 'required|in:scheduled,in_progress,completed,cancelled',
            'syllabus_completed' => 'nullable|boolean',
        ]);

        $completed = (int) ($validated['syllabus_completed'] ?? 0) === 1;
        if ($validated['session_status'] === 'completed') {
            $attendeeCount = count($this->normaliseIds($training->staff_check ?: []));
            $markedCount = TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)
                ->whereNotNull('attendance_status')
                ->count();
            if ($attendeeCount > 0 && $markedCount < $attendeeCount) {
                return response()->json([
                    'status' => 422,
                    'message' => 'Mark attendance for every attendee before completing this session.',
                    'attendance_marked' => $markedCount,
                    'attendance_total' => $attendeeCount,
                ], 422);
            }
            $completed = true;
        }

        $session->fill([
            'session_title' => $validated['session_title'] ?? $session->session_title,
            'syllabus_details' => $validated['syllabus_details'] ?? null,
            'trainer_notes' => $validated['trainer_notes'] ?? null,
            'session_status' => $validated['session_status'],
            'syllabus_completed' => $completed,
            'syllabus_completed_at' => $completed ? ($session->syllabus_completed_at ?: now()) : null,
            'updated_by' => auth()->user()->user_id ?? auth()->id() ?? 0,
        ]);
        $session->save();

        $this->syncPlannerCompletionFromSessions($training->fresh());

        return response()->json([
            'status' => 200,
            'message' => 'Training session updated successfully.',
            'data' => $this->serializeSession($session->fresh(), true),
        ]);
    }

    /**
     * Return attendance for one specific schedule date/session.
     */
    public function sessionAttendance($id, $sessionId): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $session = TrainingPlannerSessionModel::where('sno', $sessionId)
            ->where('training_planner_id', $training->sno)
            ->first();

        if (!$session) {
            return response()->json(['status' => 404, 'message' => 'Training session not found.'], 404);
        }

        $attendeeIds = $this->normaliseIds($training->staff_check ?: []);
        $staff = StaffModel::whereIn('sno', $attendeeIds)->get()->keyBy('sno');
        $rows = TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)
            ->where('training_planner_id', $training->sno)
            ->get()->keyBy('staff_id');

        $data = collect($attendeeIds)->map(function ($staffId) use ($staff, $rows) {
            $person = $staff->get($staffId);
            $row = $rows->get($staffId);
            return [
                'staff_id' => $staffId,
                'staff_name' => $person->staff_name ?? 'Unknown Staff',
                'staff_image_url' => $person->profile_image_url ?? '',
                'department_name' => $person->department_name ?? null,
                'attendance_status' => $row?->attendance_status,
                'attendance_marked_at' => optional($row?->attendance_marked_at)->toIso8601String(),
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'data' => [
                'session' => $this->serializeSession($session, true),
                'attendees' => $data,
            ],
        ]);
    }

    /**
     * Save attendance for one training date/session.
     */
    public function updateSessionAttendance(Request $request, $id, $sessionId): JsonResponse
    {
        $training = TrainingPlannerModel::where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();

        if (!$training) {
            return response()->json(['status' => 404, 'message' => 'Training planner not found.'], 404);
        }

        $session = TrainingPlannerSessionModel::where('sno', $sessionId)
            ->where('training_planner_id', $training->sno)
            ->first();

        if (!$session) {
            return response()->json(['status' => 404, 'message' => 'Training session not found.'], 404);
        }

        $payload = $request->validate([
            'attendance' => 'required|array|min:1',
            'attendance.*.staff_id' => 'required|integer|min:1',
            'attendance.*.attendance_status' => 'nullable|in:0,1',
        ]);

        $allowed = $this->normaliseIds($training->staff_check ?: []);
        $submitted = collect($payload['attendance'])->pluck('staff_id')->map(fn ($id) => (int) $id)->unique()->values()->all();
        if ($invalid = array_diff($submitted, $allowed)) {
            return response()->json(['status' => 422, 'message' => 'One or more attendees are not assigned to this training.'], 422);
        }

        DB::transaction(function () use ($payload, $training, $session) {
            $now = now();
            foreach ($payload['attendance'] as $item) {
                $status = $item['attendance_status'] === null || $item['attendance_status'] === ''
                    ? null
                    : (int) $item['attendance_status'];

                TrainingPlannerSessionAttendanceModel::updateOrCreate(
                    [
                        'training_session_id' => $session->sno,
                        'training_planner_id' => $training->sno,
                        'staff_id' => (int) $item['staff_id'],
                    ],
                    [
                        'attendance_status' => $status,
                        'attendance_marked_at' => $status === null ? null : $now,
                        'updated_by' => auth()->user()->user_id ?? auth()->id() ?? 0,
                    ]
                );
            }

            $attendeeCount = $training->staff_check ? count($this->normaliseIds($training->staff_check)) : 0;
            $markedCount = TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)
                ->whereNotNull('attendance_status')
                ->count();

            $session->session_status = ($attendeeCount > 0 && $markedCount >= $attendeeCount)
                ? 'completed'
                : 'in_progress';
            $session->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
            $session->save();
        });

        $this->syncPlannerCompletionFromSessions($training->fresh());

        return response()->json(['status' => 200, 'message' => 'Session attendance saved successfully.']);
    }

    public function storeImage(Request $request): JsonResponse
    {
        $request->validate(['image' => 'required|string']);
        $data = preg_replace('/^data:image\/(png|jpeg|jpg|webp);base64,/', '', $request->input('image'));
        $decoded = base64_decode(str_replace(' ', '+', $data), true);

        if ($decoded === false) {
            return response()->json(['status' => 422, 'message' => 'Invalid image payload.'], 422);
        }

        $fileName = 'training_editor_' . now()->format('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.png';
        $path = 'images/' . $fileName;
        Storage::disk('public')->put($path, $decoded);

        return response()->json(['status' => 200, 'success' => true, 'path' => asset('storage/' . $path)]);
    }

    private function validatePlannerPayload(Request $request, bool $isUpdate = false): array
    {
        $validated = Validator::make($request->all(), [
            'company_ids' => 'required|array|min:1',
            'company_ids.*' => 'integer|min:0',
            'entity_ids' => 'nullable|array',
            'entity_ids.*' => 'integer|min:0',
            'branch_ids' => 'nullable|array',
            'branch_ids.*' => 'integer|min:0',
            'training_planner_name' => 'required|string|max:255',
            'training_mode' => 'required|integer|in:1,2,3',
            'trainer' => 'required|integer|min:0',
            'trainer_name' => 'nullable|string|max:255',
            'schedule_type' => 'required|in:range,custom',
            'from_date' => 'nullable|date',
            'to_date' => 'nullable|date',
            'from_time' => 'required|date_format:H:i',
            'to_time' => 'required|date_format:H:i',
            'custom_dates' => 'nullable|array',
            'custom_dates.*' => 'date',
            'staff_ids' => 'required|array|min:1',
            'staff_ids.*' => 'integer|min:1',
            'all_attendees' => 'nullable|boolean',
            'training_desc' => 'nullable|string|max:10000',
            'certificate_available' => 'nullable|boolean',
            'assessment_required' => 'nullable|boolean',
            'certificate_name' => 'nullable|string|max:255',
            'assessment_pass_percentage' => 'nullable|numeric|min:0|max:100',
            'planner_status' => 'nullable|in:scheduled,rescheduled',
            'reschedule_reason' => 'nullable|string|max:1000',
        ])->validate();

        $validated['company_ids'] = array_values(array_unique(array_map('intval', $validated['company_ids'])));
        $validated['entity_ids'] = array_values(array_unique(array_map('intval', $validated['entity_ids'] ?? [])));
        $validated['branch_ids'] = array_values(array_unique(array_map('intval', $validated['branch_ids'] ?? [])));
        $validated['custom_dates'] = array_values(array_unique(array_map(
            fn ($date) => Carbon::parse($date)->toDateString(),
            $validated['custom_dates'] ?? []
        )));
        sort($validated['custom_dates']);

        $hasElysium = in_array(0, $validated['company_ids'], true);
        $otherCompanyIds = array_values(array_filter($validated['company_ids'], fn ($id) => $id !== 0));

        if ($hasElysium && !$otherCompanyIds) {
            $validated['entity_ids'] = [];
            $validated['branch_ids'] = [0];
        } else {
            if (empty($validated['entity_ids']) || empty($validated['branch_ids'])) {
                abort(response()->json([
                    'status' => 422,
                    'message' => 'Entity and branch are required for company-based training.',
                ], 422));
            }
        }

        if ((int) $validated['trainer'] === 0 && trim((string) ($validated['trainer_name'] ?? '')) === '') {
            abort(response()->json([
                'status' => 422,
                'message' => 'Trainer name is required when using an external trainer.',
            ], 422));
        }

        // if ((int) ($validated['assessment_required'] ?? 0) === 1 && !isset($validated['assessment_pass_percentage'])) {
        //     abort(response()->json([
        //         'status' => 422,
        //         'message' => 'Assessment pass percentage is required when assessment is enabled.',
        //     ], 422));
        // }

        if (($validated['schedule_type'] ?? 'custom') === 'custom') {
            if (empty($validated['custom_dates'])) {
                abort(response()->json(['status' => 422, 'message' => 'Select at least one custom training date.'], 422));
            }

            if (count($validated['custom_dates']) > 366) {
                abort(response()->json(['status' => 422, 'message' => 'You can select a maximum of 366 custom training dates.'], 422));
            }
        } else {
            if (empty($validated['from_date']) || empty($validated['to_date'])) {
                abort(response()->json(['status' => 422, 'message' => 'From date and To date are required.'], 422));
            }

            if (Carbon::parse($validated['to_date'])->lt(Carbon::parse($validated['from_date']))) {
                abort(response()->json(['status' => 422, 'message' => 'To date cannot be before From date.'], 422));
            }

            if (Carbon::parse($validated['from_date'])->diffInDays(Carbon::parse($validated['to_date'])) > 365) {
                abort(response()->json(['status' => 422, 'message' => 'Training date range cannot exceed 366 days.'], 422));
            }
        }

        $segments = $this->scheduleSegmentsFromPayload($validated);
        if (empty($segments)) {
            abort(response()->json(['status' => 422, 'message' => 'At least one valid training schedule is required.'], 422));
        }

        $pastSegments = [];

        foreach ($segments as $segment) {
            $segmentStart = Carbon::parse($segment['from']);
            $segmentEnd = Carbon::parse($segment['to']);

            if ($segmentEnd->lessThanOrEqualTo($segmentStart)) {
                abort(response()->json([
                    'status' => 422,
                    'message' => 'End time must be after start time for every training date.',
                ], 422));
            }

            if (!$isUpdate && $segmentStart->isPast()) {
                $pastSegments[] = [
                    'date' => $segmentStart->toDateString(),
                    'from_time' => $segmentStart->format('H:i'),
                    'to_time' => $segmentEnd->format('H:i'),
                ];
            }
        }

        // if (!empty($pastSegments)) {
        //     abort(response()->json([
        //         'status' => 422,
        //         'message' => 'One or more selected training dates/times are already in the past.',
        //         'past_segments' => $pastSegments,
        //     ], 422));
        // }

        return $validated;
    }

    private function normaliseBusinessScope(array &$payload): void
    {
        $payload['company_ids'] = $this->normaliseIds($payload['company_ids'] ?? []);
        $payload['entity_ids'] = $this->normaliseIds($payload['entity_ids'] ?? []);
        $payload['branch_ids'] = $this->normaliseIds($payload['branch_ids'] ?? []);
        $payload['staff_ids'] = $this->normaliseIds($payload['staff_ids'] ?? []);
    }

    private function buildDateRange(array $payload): array
    {
        $start = Carbon::createFromFormat('Y-m-d H:i', $payload['from_date'] . ' ' . $payload['from_time']);
        $end = Carbon::createFromFormat('Y-m-d H:i', $payload['to_date'] . ' ' . $payload['to_time']);
        return [$start, $end];
    }

    private function staffQuery(array $payload)
    {
        $query = StaffModel::query()
            ->where('egc_staff.status', 0)
            ->where('egc_staff.sno', '>', 1)
            ->where('egc_staff.role_id', '!=', 1)
            ->leftJoin('egc_company', 'egc_staff.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_staff.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', '=', 'egc_job_role.sno')
            ->select([
                'egc_staff.*',
                'egc_department.department_name',
                'egc_entity.entity_base_color',
                'egc_entity.entity_name',
                'egc_job_role.job_position_name as job_role_name',
            ]);

        $companyIds = $this->normaliseIds($payload['company_ids'] ?? []);
        $entityIds = $this->normaliseIds($payload['entity_ids'] ?? []);
        $branchIds = $this->normaliseIds($payload['branch_ids'] ?? []);

        $hasElysium = in_array(0, $companyIds, true);
        $otherCompanyIds = array_values(array_filter($companyIds, fn ($id) => $id !== 0));

        $query->where(function ($scope) use ($hasElysium, $otherCompanyIds, $entityIds, $branchIds) {
            $hasBusinessScope = !empty($otherCompanyIds) || !empty($entityIds) || (!empty($branchIds) && !in_array(0, $branchIds, true));

            if ($hasElysium) {
                $scope->orWhere('egc_staff.company_id', 0);
            }

            if ($hasBusinessScope) {
                $scope->orWhere(function ($business) use ($otherCompanyIds, $entityIds, $branchIds) {
                    if ($branchIds && !in_array(0, $branchIds, true)) {
                        $business->whereIn('egc_staff.branch_id', $branchIds);
                        return;
                    }

                    if ($entityIds && !in_array(0, $entityIds, true)) {
                        $business->whereIn('egc_staff.entity_id', $entityIds);
                        return;
                    }

                    if ($otherCompanyIds) {
                        $business->whereIn('egc_staff.company_id', $otherCompanyIds);
                    }
                });
            }
        });

        return $query->orderBy('egc_staff.staff_name');
    }

    private function busyStaffMap(array $segments, int $ignoreTrainingId = 0): array
    {
        $trainings = TrainingPlannerModel::where('status', '!=', self::DELETED_STATUS)
            ->whereIn('planner_status', [self::PLANNER_SCHEDULED, self::PLANNER_RESCHEDULED])
            ->when($ignoreTrainingId > 0, fn ($q) => $q->where('sno', '!=', $ignoreTrainingId))
            ->get();

        $map = [];
        foreach ($trainings as $training) {
            foreach ($this->trainingSegments($training) as $existingSegment) {
                $tStart = Carbon::parse($existingSegment['from']);
                $tEnd = Carbon::parse($existingSegment['to']);
                foreach ($segments as $segment) {
                    $start = Carbon::parse($segment['from']);
                    $end = Carbon::parse($segment['to']);
                    if (!$this->rangesOverlap($start, $end, $tStart, $tEnd)) continue;

                    if ((int) $training->trainer > 0) {
                        $map[(int) $training->trainer][] = [
                            'training_id' => (int) $training->sno,
                            'training_name' => $training->training_planner_name,
                            'from' => $tStart->toDateTimeString(),
                            'to' => $tEnd->toDateTimeString(),
                            'type' => 'trainer',
                        ];
                    }

                    foreach ($this->normaliseIds($training->staff_check ?: []) as $staffId) {
                        $map[$staffId][] = [
                            'training_id' => (int) $training->sno,
                            'training_name' => $training->training_planner_name,
                            'from' => $tStart->toDateTimeString(),
                            'to' => $tEnd->toDateTimeString(),
                            'type' => 'attendee',
                        ];
                    }
                    break;
                }
            }
        }
        return $map;
    }

    private function findConflicts(array $payload, array $segments, int $ignoreTrainingId): array
    {
        $trainings = TrainingPlannerModel::where('status', '!=', self::DELETED_STATUS)
            ->whereIn('planner_status', [self::PLANNER_SCHEDULED, self::PLANNER_RESCHEDULED])
            ->when($ignoreTrainingId > 0, fn ($q) => $q->where('sno', '!=', $ignoreTrainingId))
            ->get();

        $trainerConflicts = [];
        $attendeeConflicts = [];
        $staffIds = $this->normaliseIds($payload['staff_ids'] ?? []);
        $trainerId = (int) ($payload['trainer'] ?? 0);

        foreach ($trainings as $existing) {
            $overlapping = false;
            foreach ($this->trainingSegments($existing) as $existingSegment) {
                $existingStart = Carbon::parse($existingSegment['from']);
                $existingEnd = Carbon::parse($existingSegment['to']);
                foreach ($segments as $segment) {
                    if ($this->rangesOverlap(Carbon::parse($segment['from']), Carbon::parse($segment['to']), $existingStart, $existingEnd)) {
                        $overlapping = true;
                        break 2;
                    }
                }
            }
            if (!$overlapping) continue;

            if ($trainerId > 0 && (int) $existing->trainer === $trainerId) {
                $trainerConflicts[] = $this->conflictEntry($existing, 'Trainer is already booked');
            }

            $existingStaff = $this->normaliseIds($existing->staff_check ?: []);
            $overlap = array_values(array_intersect($staffIds, $existingStaff));
            if ($overlap) {
                $attendeeConflicts[] = [
                    'training' => $this->conflictEntry($existing, 'Attendee is already enrolled'),
                    'staff_ids' => $overlap,
                ];
            }
        }

        if ($trainerId > 0 && in_array($trainerId, $staffIds, true)) {
            $attendeeConflicts[] = [
                'training' => null,
                'staff_ids' => [$trainerId],
                'message' => 'Trainer cannot also be an attendee for the same training.',
            ];
        }

        return ['trainer' => $trainerConflicts, 'attendees' => $attendeeConflicts];
    }

    private function conflictEntry(TrainingPlannerModel $training, string $message): array
    {
        [$start, $end] = $this->trainingRange($training);
        $segments = $this->trainingSegments($training);

        return [
            'training_id' => (int) $training->sno,
            'training_planner_id' => $training->training_planner_id,
            'training_name' => $training->training_planner_name,
            'message' => $message,
            'from' => $start->toDateTimeString(),
            'to' => $end->toDateTimeString(),
            'segments' => $segments,
        ];
    }

    private function scheduleSegmentsFromPayload(array $payload): array
    {
        $fromTime = substr((string) ($payload['from_time'] ?? ''), 0, 5);
        $toTime = substr((string) ($payload['to_time'] ?? ''), 0, 5);

        if (empty($fromTime) || empty($toTime)) {
            return [];
        }

        if (($payload['schedule_type'] ?? 'custom') === 'custom') {
            $dates = $payload['custom_dates'] ?? [];
            $dates = array_values(array_unique(array_filter(array_map(
                fn ($date) => Carbon::parse($date)->toDateString(),
                is_array($dates) ? $dates : []
            ))));
            sort($dates);

            return array_map(function ($date) use ($fromTime, $toTime) {
                return [
                    'date' => $date,
                    'from_time' => $fromTime,
                    'to_time' => $toTime,
                    'from' => Carbon::parse($date . ' ' . $fromTime)->toDateTimeString(),
                    'to' => Carbon::parse($date . ' ' . $toTime)->toDateTimeString(),
                ];
            }, $dates);
        }

        if (empty($payload['from_date']) || empty($payload['to_date'])) {
            return [];
        }

        return [[
            'date' => Carbon::parse($payload['from_date'])->toDateString(),
            'to_date' => Carbon::parse($payload['to_date'])->toDateString(),
            'from_time' => $fromTime,
            'to_time' => $toTime,
            'from' => Carbon::parse($payload['from_date'] . ' ' . $fromTime)->toDateTimeString(),
            'to' => Carbon::parse($payload['to_date'] . ' ' . $toTime)->toDateTimeString(),
        ]];
    }

    private function segmentBounds(array $segments): array
    {
        $starts = array_map(fn ($s) => Carbon::parse($s['from']), $segments);
        $ends = array_map(fn ($s) => Carbon::parse($s['to']), $segments);
        return [collect($starts)->sort()->first(), collect($ends)->sortDesc()->first()];
    }

    private function durationHoursFromSegments(array $segments): float
    {
        return round(collect($segments)->sum(fn ($s) => Carbon::parse($s['from'])->diffInMinutes(Carbon::parse($s['to']))) / 60, 2);
    }

    private function trainingSegments(TrainingPlannerModel $training): array
    {
        if ($training->schedule_type === 'custom' && is_array($training->schedule_sessions) && count($training->schedule_sessions)) {
            return array_values(array_map(function ($session) {
                $from = $session['from'] ?? Carbon::parse($session['date'] . ' ' . $session['from_time'])->toDateTimeString();
                $to = $session['to'] ?? Carbon::parse($session['date'] . ' ' . $session['to_time'])->toDateTimeString();

                return [
                    'date' => $session['date'],
                    'from_time' => substr($session['from_time'], 0, 5),
                    'to_time' => substr($session['to_time'], 0, 5),
                    'from' => $from,
                    'to' => $to,
                ];
            }, $training->schedule_sessions));
        }

        [$start, $end] = $this->legacyTrainingRange($training);
        $fromTime = $start->format('H:i');
        $toTime = $end->format('H:i');

        // A range schedule means the same daily time window is active on each date.
        // Expanding it to daily segments makes conflict checking accurate and prevents
        // a booking at a different time on an intermediate date from being flagged.
        $segments = [];
        $cursor = $start->copy()->startOfDay();
        $lastDay = $end->copy()->startOfDay();

        while ($cursor->lte($lastDay)) {
            $date = $cursor->toDateString();
            $dayStart = Carbon::parse($date . ' ' . $fromTime);
            $dayEnd = Carbon::parse($date . ' ' . $toTime);

            // For a single-day legacy record, keep the original exact range.
            if ($cursor->isSameDay($start) && $cursor->isSameDay($end)) {
                $dayStart = $start->copy();
                $dayEnd = $end->copy();
            }

            $segments[] = [
                'date' => $date,
                'from_time' => $fromTime,
                'to_time' => $toTime,
                'from' => $dayStart->toDateTimeString(),
                'to' => $dayEnd->toDateTimeString(),
            ];

            $cursor->addDay();
        }

        return $segments;
    }

    private function legacyTrainingRange(TrainingPlannerModel $training): array
    {
        $fromDate = $training->schedule_from_date ?: $training->schedule_date;
        $toDate = $training->schedule_to_date ?: $training->schedule_date;
        $fromTime = $training->schedule_from_time ?: $training->schedule_time;
        $toTime = $training->schedule_to_time ?: Carbon::parse($fromTime)->addHours(max(1, (int) $training->training_duration))->format('H:i:s');
        return [Carbon::parse($fromDate.' '.$fromTime), Carbon::parse($toDate.' '.$toTime)];
    }

    private function trainingRange(TrainingPlannerModel $training): array
    {
        if ($training->schedule_type === 'custom' && is_array($training->schedule_sessions) && count($training->schedule_sessions)) {
            return $this->segmentBounds($this->trainingSegments($training));
        }
        return $this->legacyTrainingRange($training);
    }

    private function rangesOverlap(Carbon $aStart, Carbon $aEnd, Carbon $bStart, Carbon $bEnd): bool
    {
        return $aStart->lt($bEnd) && $bStart->lt($aEnd);
    }

    private function durationHours(Carbon $start, Carbon $end): float
    {
        return round($start->diffInMinutes($end) / 60, 2);
    }

    private function syncAttendees(TrainingPlannerModel $training, array $staffIds): void
    {
        $staffIds = $this->normaliseIds($staffIds);
        if ((int) $training->trainer > 0) {
            $staffIds = array_values(array_diff($staffIds, [(int) $training->trainer]));
        }
        TrainingPlannerAttendeeModel::where('training_planner_id', $training->sno)
            ->whereNotIn('staff_id', $staffIds ?: [0])
            ->delete();

        foreach ($staffIds as $staffId) {
            TrainingPlannerAttendeeModel::firstOrCreate([
                'training_planner_id' => $training->sno,
                'staff_id' => $staffId,
            ]);
        }
    }

    private function trainingForApi($id): ?TrainingPlannerModel
    {
        return TrainingPlannerModel::with(['attendees.staff'])
            ->where('sno', $id)
            ->where('status', '!=', self::DELETED_STATUS)
            ->first();
    }

    private function serializeTraining(TrainingPlannerModel $training, bool $withAttendees = false): array
    {
        [$start, $end] = $this->trainingRange($training);
        $scheduleSegments = $this->trainingSegments($training);
        $staffIds = $this->normaliseIds($training->staff_check ?: []);
        $attendees = [];

        if ($withAttendees) {
            $attendeeRows = $training->attendees;
            if ($attendeeRows->isEmpty() && $staffIds) {
                $attendeeRows = TrainingPlannerAttendeeModel::where('training_planner_id', $training->sno)->get();
            }

            $attendeeRows = $attendeeRows->keyBy('staff_id');
            $staff = StaffModel::whereIn('sno', $staffIds)->get()->keyBy('sno');
            $sessionRows = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)->get()->keyBy('sno');
            $sessionAttendance = TrainingPlannerSessionAttendanceModel::where('training_planner_id', $training->sno)
                ->get()
                ->groupBy('training_session_id');
            foreach ($staffIds as $staffId) {
                $a = $attendeeRows->get($staffId);
                $person = $staff->get($staffId);
                $attendees[] = [
                    'staff_id' => $staffId,
                    'staff_name' => $person->staff_name ?? 'Unknown Staff',
                    'attendee_image_url' => $person->profile_image_url ?? '',
                    'department_id' => $person->department_id ?? null,
                    'job_role_id' => $person->job_role_id ?? null,
                    'attendance_status' => $a?->attendance_status,
                    'certificate_issued' => (bool) ($a?->certificate_issued ?? false),
                    'assessment_status' => $a?->assessment_status,
                    'assessment_score' => $a?->assessment_score,
                    'session_attendance' => $sessionRows->mapWithKeys(function ($session) use ($sessionAttendance, $staffId) {
                        $row = optional($sessionAttendance->get($session->sno))->firstWhere('staff_id', $staffId);
                        return [(string) $session->sno => $row?->attendance_status === null ? null : (int) $row->attendance_status];
                    })->all(),
                ];
            }
        }

        $trainerName = (int) $training->trainer > 0
            ? (StaffModel::find($training->trainer)->staff_name ?? $training->trainer_name ?? '-')
            : ($training->trainer_name ?: 'External Trainer');

        $trainerImage = (int) $training->trainer > 0
            ? (StaffModel::find($training->trainer)->profile_image_url ?? '')
            : '';

        $scopeNames = ['companies' => [], 'entities' => [], 'branches' => []];
        if ($withAttendees) {
            $companyIds = $this->normaliseIds($training->company_ids ?: []);
            $entityIds = $this->normaliseIds($training->entity_ids ?: []);
            $branchIds = $this->normaliseIds($training->branch_ids ?: []);
            $scopeNames['companies'] = in_array(0, $companyIds, true)
                ? ['Elysium Groups']
                : CompanyModel::whereIn('sno', $companyIds)->pluck('company_name')->values()->all();
            $scopeNames['entities'] = $entityIds
                ? DB::table('egc_entity')->whereIn('sno', $entityIds)->pluck('entity_name')->values()->all()
                : [];
            $scopeNames['branches'] = $branchIds && !in_array(0, $branchIds, true)
                ? BranchModel::whereIn('sno', $branchIds)->get()->map(fn ($b) => $b->branch_type == 2 ? ($b->franchise_name ?: $b->branch_name) : $b->branch_name)->values()->all()
                : [];
        }

        return [
            'sno' => (int) $training->sno,
            'training_planner_id' => $training->training_planner_id,
            'training_planner_name' => $training->training_planner_name,
            'company_ids' => $this->normaliseIds($training->company_ids ?: []),
            'entity_ids' => $this->normaliseIds($training->entity_ids ?: []),
            'branch_ids' => $this->normaliseIds($training->branch_ids ?: []),
            'training_mode' => (int) $training->training_mode,
            'training_mode_label' => [1 => 'Online', 2 => 'Offline', 3 => 'Video'][$training->training_mode] ?? 'Unknown',
            'trainer' => (int) $training->trainer,
            'trainer_name' => $trainerName,
            'trainer_imge_url' => $trainerImage,
            'training_duration' => (float) $training->training_duration,
            'schedule_type' => $training->schedule_type ?: 'range',
            'custom_sessions' => $scheduleSegments,
            'from_date' => $start->toDateString(),
            'to_date' => $end->toDateString(),
            'from_time' => $start->format('H:i'),
            'to_time' => $end->format('H:i'),
            'start' => $start->toIso8601String(),
            'end' => $end->toIso8601String(),
            'training_desc' => $training->training_desc,
            'all_attendees' => (bool) $training->all_check,
            'staff_ids' => $staffIds,
            'certificate_available' => (bool) $training->certificate_available,
            'assessment_required' => (bool) $training->assessment_required,
            'certificate_name' => $training->certificate_name,
            'assessment_pass_percentage' => $training->assessment_pass_percentage !== null ? (float) $training->assessment_pass_percentage : null,
            'planner_status' => $training->planner_status ?: self::PLANNER_SCHEDULED,
            'cancelled_reason' => $training->cancelled_reason,
            'reschedule_reason' => $training->reschedule_reason,
            'completed_at' => optional($training->completed_at)->toIso8601String(),
            'cancelled_at' => optional($training->cancelled_at)->toIso8601String(),
            'created_at' => optional($training->created_at)->toIso8601String(),
            'attendees' => $attendees,
            'attendance_summary' => $this->attendanceSummary($training, $staffIds),
            'attendee_counts' => $this->attendeeCounts($training, $staffIds),
            'session_summary' => $this->sessionSummary($training),
            'scope_names' => $scopeNames,
        ];
    }

    private function attendanceSummary(TrainingPlannerModel $training, array $staffIds): array
    {
        $rows = TrainingPlannerAttendeeModel::where('training_planner_id', $training->sno)->get();
        if ($rows->isEmpty()) {
            $legacy = $training->attendance_status ?: [];
            $present = 0;
            $absent = 0;
            foreach (is_array($legacy) ? $legacy : [] as $item) {
                if (($item['attendance'] ?? null) === 0 || ($item['attendance'] ?? null) === '0') $present++;
                if (($item['attendance'] ?? null) === 1 || ($item['attendance'] ?? null) === '1') $absent++;
            }
            return ['total' => count($staffIds), 'present' => $present, 'absent' => $absent, 'pending' => max(0, count($staffIds) - $present - $absent)];
        }

        $present = $rows->where('attendance_status', 1)->count();
        $absent = $rows->where('attendance_status', 0)->count();
        return ['total' => count($staffIds), 'present' => $present, 'absent' => $absent, 'pending' => $rows->whereNull('attendance_status')->count()];
    }

    private function attendeeCounts(TrainingPlannerModel $training, array $staffIds): array
    {
        $rows = TrainingPlannerAttendeeModel::where('training_planner_id', $training->sno)->get();
        if ($rows->isEmpty()) {
            return [
                'total' => count($staffIds),
                'present' => 0,
                'absent' => 0,
                'pending' => count($staffIds),
            ];
        }

        return [
            'total' => count($staffIds),
            'present' => $rows->where('attendance_status', 1)->count(),
            'absent' => $rows->where('attendance_status', 0)->count(),
            'pending' => $rows->whereNull('attendance_status')->count(),
        ];
    }

    private function sessionSummary(TrainingPlannerModel $training): array
    {
        $sessions = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)->get();
        $sessionIds = $sessions->pluck('sno')->all();
        $attendance = $sessionIds
            ? TrainingPlannerSessionAttendanceModel::whereIn('training_session_id', $sessionIds)->get()
            : collect();

        return [
            'total' => $sessions->count(),
            'completed' => $sessions->where('session_status', 'completed')->count(),
            'in_progress' => $sessions->where('session_status', 'in_progress')->count(),
            'scheduled' => $sessions->where('session_status', 'scheduled')->count(),
            'cancelled' => $sessions->where('session_status', 'cancelled')->count(),
            'attendance_marked' => $attendance->whereNotNull('attendance_status')->count(),
            'attendance_present' => $attendance->where('attendance_status', 1)->count(),
            'attendance_absent' => $attendance->where('attendance_status', 0)->count(),
            'attendance_pending' => $attendance->whereNull('attendance_status')->count(),
        ];
    }

    private function generatePlannerId(): string
    {
        $year = now()->format('y');
        $lastNumber = 0;
        $rows = TrainingPlannerModel::lockForUpdate()
            ->where('status', '!=', self::DELETED_STATUS)
            ->where('training_planner_id', 'like', 'TP-%/' . $year)
            ->pluck('training_planner_id');

        foreach ($rows as $plannerId) {
            if (preg_match('/^TP-(\d+)\/' . preg_quote($year, '/') . '$/', (string) $plannerId, $m)) {
                $lastNumber = max($lastNumber, (int) $m[1]);
            }
        }

        return sprintf('TP-%04d/%s', $lastNumber + 1, $year);
    }

    private function scheduleSignature(TrainingPlannerModel $training): string
    {
        [$start, $end] = $this->trainingRange($training);
        return $start->format('Y-m-d H:i:s') . '|' . $end->format('Y-m-d H:i:s');
    }

    private function syncSessions(TrainingPlannerModel $training, array $segments): void
    {
        $segments = array_values($segments);
        $existing = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)
            ->get()->keyBy(fn ($row) => Carbon::parse($row->session_date)->format('Y-m-d') . '|' . substr($row->start_time, 0, 5) . '|' . substr($row->end_time, 0, 5));

        $keepIds = [];
        foreach ($segments as $index => $segment) {
            $date = Carbon::parse($segment['date'])->toDateString();
            $from = substr($segment['from_time'], 0, 5);
            $to = substr($segment['to_time'], 0, 5);
            $key = $date . '|' . $from . '|' . $to;
            $row = $existing->get($key);

            if (!$row) {
                $row = TrainingPlannerSessionModel::create([
                    'training_planner_id' => $training->sno,
                    'session_no' => $index + 1,
                    'session_date' => $date,
                    'start_time' => $from . ':00',
                    'end_time' => $to . ':00',
                    'session_title' => 'Session ' . ($index + 1),
                    'session_status' => 'scheduled',
                    'syllabus_completed' => 0,
                    'created_by' => auth()->user()->user_id ?? auth()->id() ?? 0,
                    'updated_by' => auth()->user()->user_id ?? auth()->id() ?? 0,
                ]);
            } else {
                $row->session_no = $index + 1;
                $row->session_date = $date;
                $row->start_time = $from . ':00';
                $row->end_time = $to . ':00';
                $row->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
                $row->save();
            }

            $keepIds[] = $row->sno;
            $this->syncSessionAttendanceRows($training, $this->normaliseIds($training->staff_check ?: []), $row->sno);
        }

        $obsolete = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)
            ->whereNotIn('sno', $keepIds ?: [0])
            ->get();

        foreach ($obsolete as $oldSession) {
            $hasMarkedAttendance = TrainingPlannerSessionAttendanceModel::where('training_session_id', $oldSession->sno)
                ->whereNotNull('attendance_status')
                ->exists();

            if ($hasMarkedAttendance) {
                $oldSession->session_status = 'cancelled';
                $oldSession->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
                $oldSession->save();
            } else {
                $oldSession->delete();
            }
        }
    }

    private function syncSessionAttendanceRows(TrainingPlannerModel $training, array $staffIds, ?int $sessionId = null): void
    {
        $staffIds = $this->normaliseIds($staffIds);
        $sessions = $sessionId
            ? TrainingPlannerSessionModel::where('sno', $sessionId)->get()
            : TrainingPlannerSessionModel::where('training_planner_id', $training->sno)->get();

        foreach ($sessions as $session) {
            TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)
                ->whereNotIn('staff_id', $staffIds ?: [0])
                ->delete();

            foreach ($staffIds as $staffId) {
                TrainingPlannerSessionAttendanceModel::firstOrCreate([
                    'training_session_id' => $session->sno,
                    'training_planner_id' => $training->sno,
                    'staff_id' => $staffId,
                ]);
            }
        }
    }

    private function syncPlannerCompletionFromSessions(TrainingPlannerModel $training): void
    {
        $sessions = TrainingPlannerSessionModel::where('training_planner_id', $training->sno)->get();
        if ($sessions->isEmpty()) return;

        $allCompleted = $sessions->every(fn ($session) => $session->session_status === 'completed' && (bool) $session->syllabus_completed);
        if ($allCompleted && $training->planner_status !== self::PLANNER_CANCELLED) {
            $training->planner_status = self::PLANNER_COMPLETED;
            $training->completed_at = $training->completed_at ?: now();
            $training->updated_by = auth()->user()->user_id ?? auth()->id() ?? 0;
            $training->save();
        }
    }

    private function serializeSession(TrainingPlannerSessionModel $session, bool $withAttendance = false): array
    {

    
        $data = [
            'sno' => (int) $session->sno,
            'training_planner_id' => (int) $session->training_planner_id,
            'session_no' => (int) $session->session_no,
            'session_date' => Carbon::parse($session->session_date)->toDateString(),
            'start_time' => substr((string) $session->start_time, 0, 5),
            'end_time' => substr((string) $session->end_time, 0, 5),
            'session_title' => $session->session_title,
            'syllabus_details' => $session->syllabus_details,
            'syllabus_completed' => (bool) $session->syllabus_completed,
            'syllabus_completed_at' => optional($session->syllabus_completed_at)->toIso8601String(),
            'trainer_notes' => $session->trainer_notes,
            'session_status' => $session->session_status,
            'present_count' => isset($session->present_count) ? (int) $session->present_count : 0,
            'absent_count' => isset($session->absent_count) ? (int) $session->absent_count : 0,
            'attendance_total' => TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)->count(),
            'attendance_marked' => TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)->whereNotNull('attendance_status')->count(),
        ];

        if ($withAttendance) {
            $rows = TrainingPlannerSessionAttendanceModel::where('training_session_id', $session->sno)->get();
            $data['attendance'] = $rows->map(fn ($row) => [
                'staff_id' => (int) $row->staff_id,
                'attendance_status' => $row->attendance_status === null ? null : (int) $row->attendance_status,
                'attendance_marked_at' => optional($row->attendance_marked_at)->toIso8601String(),
            ])->values()->all();
        }

        return $data;
    }

    private function normaliseIds($ids): array
    {
        if ($ids === null || $ids === '') return [];
        if (is_string($ids)) {
            $decoded = json_decode($ids, true);
            $ids = json_last_error() === JSON_ERROR_NONE && is_array($decoded) ? $decoded : explode(',', $ids);
        }
        if (!is_array($ids)) $ids = [$ids];
        return array_values(array_unique(array_filter(array_map(fn ($id) => (int) $id, $ids), fn ($id) => $id >= 0)));
    }

    private function titleCase(string $value): string
    {
        return mb_convert_case(trim($value), MB_CASE_TITLE, 'UTF-8');
    }
}
