<?php

namespace App\Http\Controllers\Security;

use App\Http\Controllers\Controller;
use App\Services\Security\SecurityQrService;
use App\Services\Security\SecuritySessionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class SecurityController extends Controller
{
    protected SecuritySessionService $sessionService;
    protected SecurityQrService $qrService;

    public function __construct(
        SecuritySessionService $sessionService,
        SecurityQrService $qrService
    ) {
        $this->sessionService = $sessionService;
        $this->qrService = $qrService;
    }

    /**
     * --------------------------------------------------------------------------
     * Create Security Session
     * --------------------------------------------------------------------------
     *
     * ERP Flow
     *
     * User Clicks:
     *
     *      Reveal Password
     *      Reveal Salary
     *      Reveal Aadhaar
     *      Reveal Bank
     *
     * Creates:
     *
     *      Security Session
     *      QR Code
     *
     */
    public function createSession(Request $request): JsonResponse
    {
        $request->validate([
            'module_id' => ['required', 'integer'],
            'record_id' => ['required', 'integer']
        ]);

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Logged Staff
            |--------------------------------------------------------------------------
            */

            $staffId = $request->user()->user_id;
            
            // return $staffId;

            if ($staffId == '') {

                DB::rollBack();

                return response()->json([
                    'status' => false,
                    'staffId' => $staffId,
                    'message' => 'Unauthenticated.'
                ], 401);

            }

            /*
            |--------------------------------------------------------------------------
            | Create Session
            |--------------------------------------------------------------------------
            */

            $session = $this->sessionService->createSession(
                (int) $request->module_id,
                (int) $request->record_id,
                (int) $staffId
            );

            /*
            |--------------------------------------------------------------------------
            | Generate QR Image
            |--------------------------------------------------------------------------
            */

            $qrImage = $this->qrService->generate(
                $session,
                300
            );

            DB::commit();

            return response()->json([

                'status' => true,
                'message' => 'Security session created.',
                'data' => [
                    'session_id' => $session->sno,
                    'session_uuid' => $session->session_uuid,
                    'module_id' => $session->module_id,
                    'record_id' => $session->record_id,
                    'status' => $session->status,
                    'qr_expires_at' => $session->qr_expires_at,
                    'qr_image' => $qrImage
                ]

            ]);

        } catch (Throwable $e) {

            DB::rollBack();

            Log::error('Create Security Session Error', [
                'message' => $e->getMessage(),
                'line' => $e->getLine(),
                'file' => $e->getFile()
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to create security session.'
            ], 500);

        }
    }

    // ==========================================================
    // Part 2 Starts Below
    // qr()
    // session()
    // ==========================================================
        /**
     * --------------------------------------------------------------------------
     * Get QR Image
     * --------------------------------------------------------------------------
     *
     * ERP can request the QR again without creating a new session.
     */
    public function qr(string $sessionUuid): JsonResponse
    {
        try {

            $session = $this->sessionService->findByUuid(
                $sessionUuid
            );

            if (!$session) {

                return response()->json([
                    'status' => false,
                    'message' => 'Security session not found.'
                ], 404);

            }

            if (!$this->sessionService->validateSession($session)) {

                return response()->json([
                    'status' => false,
                    'message' => 'Security session expired.'
                ], 422);

            }

            $qrImage = $this->qrService->generate(
                $session,
                300
            );

            return response()->json([

                'status' => true,

                'message' => 'QR generated successfully.',

                'data' => [

                    'session_uuid' => $session->session_uuid,

                    'status' => $session->status,

                    'qr_expires_at' => $session->qr_expires_at,

                    'qr_image' => $qrImage

                ]

            ]);

        } catch (Throwable $e) {

            Log::error('Security QR Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile()

            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to generate QR.'
            ], 500);

        }

    }

    /**
     * --------------------------------------------------------------------------
     * Session Details
     * --------------------------------------------------------------------------
     *
     * ERP uses this endpoint to load the current session state.
     */
    public function session(string $sessionUuid): JsonResponse
    {
        try {

            $session = $this->sessionService->findByUuid(
                $sessionUuid
            );

            if (!$session) {

                return response()->json([
                    'status' => false,
                    'message' => 'Security session not found.'
                ], 404);

            }

            return response()->json([

                'status' => true,

                'message' => 'Session loaded successfully.',

                'data' => [

                    'session_id' => $session->sno,

                    'session_uuid' => $session->session_uuid,

                    'module_id' => $session->module_id,

                    'record_id' => $session->record_id,

                    'requested_staff_id' => $session->requested_staff_id,

                    'verified_staff_id' => $session->verified_staff_id,

                    'device_id' => $session->device_id,

                    'status' => $session->status,

                    'generated_at' => $session->generated_at,

                    'qr_expires_at' => $session->qr_expires_at,

                    'pin_generated_at' => $session->pin_generated_at,

                    'pin_expires_at' => $session->pin_expires_at,

                    'verified_at' => $session->verified_at,

                    'access_expires_at' => $session->access_expires_at,

                    'closed_at' => $session->closed_at

                ]

            ]);

        } catch (Throwable $e) {

            Log::error('Security Session Error', [

                'message' => $e->getMessage(),

                'line' => $e->getLine(),

                'file' => $e->getFile()

            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to load security session.'
            ], 500);

        }

    }

    // ==========================================================
    // Part 3 Starts Below
    // Reverb Events / Helper Methods / End Class
    // ==========================================================
        /**
     * --------------------------------------------------------------------------
     * Security Response Helper
     * --------------------------------------------------------------------------
     *
     * Common response format for ERP security module.
     *
     */
    protected function responseSuccess(
        string $message,
        array $data = []
    ): JsonResponse {

        return response()->json([

            'status' => true,

            'message' => $message,

            'data' => $data

        ]);

    }


    /**
     * --------------------------------------------------------------------------
     * Security Error Response
     * --------------------------------------------------------------------------
     */
    protected function responseError(
        string $message,
        int $code = 422,
        array $errors = []
    ): JsonResponse {

        return response()->json([

            'status' => false,

            'message' => $message,

            'errors' => $errors

        ], $code);

    }


    public function staffPassword(Request $request ,$UUID)
    {
        
        $user_id = $request->user()->user_id;

        $moduleId = 1;

        
        $session = $this->sessionService->findByUuid( $UUID );

        if (!$session) {

            return response()->json([
                'status'=>false,
                'message'=>'Session not found.'
            ],404);

        }

        $staffId = $session ? $session->record_id : NULL;

        $employee = StaffModel::query()
            ->where('sno',$staffId)
            ->first();

        if (!$employee) {
            return response()->json([
                'status'=>false,
                'message'=>'Staff not found.'
            ],404);

        }
        return response()->json([
            'status'=>true,
            'message'=>'Get Staff Password Successfully.',
            'data'=>[
                'staff_id'=>$staffId,
                'user_name'=>$employee->user_name,
                'password'=>$employee->password,
                'expires_at'=>$session->pin_expires_at
                                ? $session->pin_expires_at
                                : NULL,
            ],
            
            

        ]);

    }


}