<?php

namespace App\Http\Controllers\EmployeeApp;

use App\Http\Controllers\Controller;
use App\Mail\ETPLMail;
use App\Models\ChatModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\ManageTickickModel;
use App\Models\CugManagementModel;
use App\Models\OtpModel;
use App\Models\cugUser;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\ProductModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\AppointmentModel;
use App\Models\FollowupReasonModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Laravel\Sanctum\PersonalAccessToken;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

use App\Models\CallContactsModel;
use App\Models\CallTrackerModel;
use App\Models\NotificationMobileModel;
use App\Traits\NotifiableTrait;
use Illuminate\Support\Facades\Log;

class CallerPilot extends Controller
{
     use NotifiableTrait;
     
    public function StaffLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $latitude = $request->latitude;
        $longitude = $request->longitude;
        $device_id = $request->deviceId;
        $brand = $request->brand;
        $model = $request->model;
        $device_name = $request->deviceName;
        $os = $request->os;
        $android_version = $request->androidVersion;
        $sdk_version = $request->sdkVersion;
        $key      = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {

            // $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();
            $staffuser = DB::table('egc_cug_numbers')
            ->where('egc_cug_numbers.cug_number', $mobile_no)
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*')
            ->first();
            
            // return $staffuser;
            if ($staffuser) {
                $user = StaffModel::where('sno', $staffuser->staff_id)->where('status', 0)->first();

                if(!$user){
                    DB::table('mobile_user_login_logs')->insert([
                        'user_id'    => 0,        
                        'login_at'   => Carbon::now('Asia/Kolkata'),
                        'ip_address' => $request->ip(),
                        'user_agent' => $request->header('User-Agent'),
                        'mobile_no'  => $mobile_no,
                        'latitude'   => $latitude,
                        'longitude'   => $longitude,
                        'device_id'   => $device_id ?? NULL,
                        'brand'   => $brand ?? NULL,
                        'model'   => $model ?? NULL,
                        'device_name'   => $device_name ?? NULL,
                        'os'   => $os ?? NULL,
                        'android_version'   => $android_version ?? NULL,
                        'sdk_version'   => $sdk_version ?? NULL,
                        'type'       => 1, // failed
                        'failed_type'       => 2, // cug match but staff not found or inctive
                        'created_at' => Carbon::now('Asia/Kolkata'),
                        'updated_at' => Carbon::now('Asia/Kolkata'),
                    ]);
                    $response = [
                        'status' => "2",
                        'message' => 'User does not exist',
                        "error_msg" => 'User does not exist',
                        'data' => null
                    ];
                    return response($response, 422);
                }
                // return $user;

                if( $mobile_no == "9790464324"){
                    $otp_value  = 123456; // Random 6-digit OTP
                }else if( $mobile_no == "7339663111"){
                     $otp_value  = 123456;
                }else{
                    $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                } // Random 6-digit OTP

                // Save OTP to Database
                
                $otp = new OtpModel();

                $otp->user_id                  = $user->sno;
                $otp->mobile_no                =  $mobile_no;
                $otp->otp_number               = $otp_value;
                $otp->created_by               = $user->sno;
                $otp->updated_by               = $user->sno;
                $otp->save();
                // sms otp 
                 if( $mobile_no != "9790464324" && $mobile_no != "7339663111"){
                    if ($otp_value) {

                        $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                        $authkey         = $result_sms ? $result_sms->authkey : '';
                        $sender_id       = $result_sms ? $result_sms->sender_id : '';
                        $template_id     = $result_sms ? $result_sms->template_id : '';
                        $country_code    = $result_sms ? $result_sms->country_code : '';
                        $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                        $mobile_number   = $country_code . $mobile_no;
                        

                        $app_name = "Sales App";
                        // $app_link = 'https://elysiumacademy.org/';
                        $app_code = "8dc%2BJrcYXcg";
                        // Replace placeholders with actual values
                        $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                        $message_content    = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                                return array_shift($replacement_values);
                            },
                            $message_content
                        );

                        $route    = "default";
                        $postData = [
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender'  => $sender_id,
                            'route'   => $route,
                        ];

                        // API URL
                        $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                        
                        // Initialize the resource
                        $ch = curl_init();
                        curl_setopt_array($ch, [
                            CURLOPT_URL            => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                        ]);

                        // Get response
                        $response = curl_exec($ch);
                        // return $response;
                        $err = curl_error($ch);
                        curl_close($ch);
                    }
                 }
      
                return response()->json([
                    'otp'        => $otp_value,
                    'status'     => strval($user->status),
                    'staff_id'   => $user->sno,
                    'Gender'   => $user->gender,
                    'staff_name'   => $user->staff_name,
                    'staff_image'       => $user->staff_image ?  url('/staff_images').'/'. $user->staff_image : null,
                    'message'    => 'Successfully',
                    "error_msg"  => null,
                    'data'       => null,
                ], 200);
            } else {
                DB::table('mobile_user_login_logs')->insert([
                        'user_id'    => 0,        
                        'login_at'   => Carbon::now('Asia/Kolkata'),
                        'ip_address' => $request->ip(),
                        'user_agent' => $request->header('User-Agent'),
                        'mobile_no'  => $mobile_no,
                        'latitude'   => $latitude,
                        'longitude'   => $longitude,
                        'device_id'   => $device_id ?? NULL,
                        'brand'   => $brand ?? NULL,
                        'model'   => $model ?? NULL,
                        'device_name'   => $device_name ?? NULL,
                        'os'   => $os ?? NULL,
                        'android_version'   => $android_version ?? NULL,
                        'sdk_version'   => $sdk_version ?? NULL,
                        'type'       => 1, // failed
                        'failed_type'       => 1, // incorrect mobile or Mobile no not in cug
                        'created_at' => Carbon::now('Asia/Kolkata'),
                        'updated_at' => Carbon::now('Asia/Kolkata'),
                    ]);
                $response = [
                    'status' => "2",
                    'message' => 'User does not exist',
                    "error_msg" => 'User does not exist',
                    'data' => null
                ];
                return response($response, 422);
            }
        }
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
         $latitude = $request->latitude;
        $longitude = $request->longitude;
        $device_id = $request->deviceId;
        $brand = $request->brand;
        $model = $request->model;
        $device_name = $request->deviceName;
        $os = $request->os;
        $android_version = $request->androidVersion;
        $sdk_version = $request->sdkVersion;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('mobile_no', $mobile_no)->where('otp_number', $otpInput)
                    ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            DB::table('mobile_user_login_logs')->insert([
                    'user_id'    => 0,        
                    'login_at'   => Carbon::now('Asia/Kolkata'),
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->header('User-Agent'),
                    'mobile_no'  => $mobile_no,
                    'otp'  => $otpInput,
                    'latitude'   => $latitude,
                    'longitude'   => $longitude,
                    'device_id'   => $device_id ?? NULL,
                    'brand'   => $brand ?? NULL,
                    'model'   => $model ?? NULL,
                    'device_name'   => $device_name ?? NULL,
                    'os'   => $os ?? NULL,
                    'android_version'   => $android_version ?? NULL,
                    'sdk_version'   => $sdk_version ?? NULL,
                    'type'       => 1, // failed
                    'failed_type'       => 3, // Otp Not Match
                    'created_at' => Carbon::now('Asia/Kolkata'),
                    'updated_at' => Carbon::now('Asia/Kolkata'),
                ]);
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        $expiryTime = $createdAt->copy()->addMinutes(2);
        $currentTime = Carbon::now('UTC');
    
        if ($currentTime->greaterThan($expiryTime)) {
            DB::table('mobile_user_login_logs')->insert([
                    'user_id'    => 0,        
                    'login_at'   => Carbon::now('Asia/Kolkata'),
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->header('User-Agent'),
                    'mobile_no'  => $mobile_no,
                    'otp'  => $otpInput,
                    'latitude'   => $latitude,
                    'longitude'   => $longitude,
                    'device_id'   => $device_id ?? NULL,
                    'brand'   => $brand ?? NULL,
                    'model'   => $model ?? NULL,
                    'device_name'   => $device_name ?? NULL,
                    'os'   => $os ?? NULL,
                    'android_version'   => $android_version ?? NULL,
                    'sdk_version'   => $sdk_version ?? NULL,
                    'type'       => 1, // failed
                    'failed_type'       => 4, // OTP expired
                    'created_at' => Carbon::now('Asia/Kolkata'),
                    'updated_at' => Carbon::now('Asia/Kolkata'),
                ]);
            return response()->json([
                'status'  => false,
                'message' => 'OTP expired. Please request a new one.'
            ], 410);
        }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }

        $staff_id = $otpRecord->user_id;

        // $user = User::select('users.*', 'egc_staff.status as staff_status')
        //     ->where('users.user_id', $staff_id)
        //     ->leftJoin('egc_staff', 'users.user_id', '=', 'egc_staff.sno')
        //     ->where('egc_staff.status', 0)
        //     ->first();

      

         $user = DB::table('egc_cug_numbers')
            ->where('egc_cug_numbers.cug_number', $mobile_no)
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id')
            ->first();

        if ($user->staff_status == 1) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is inactive. Please contact the administrator.',
                'error_msg'=>'This user is inactive. Please contact the administrator.',
                'data' => NULL
            ]);
        } elseif ($user->staff_status == 2) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is deactivated. Please contact the administrator.',
                'error_msg'=>'This user is deactivated. Please contact the administrator.',
                'data' => NULL
            ]);
        }

          $secret_key = env('JWT_SECRET', 'EGC_CALLERPILOT_2026'); // Add JWT_SECRET in .env
            $issuer_claim = "Sales App"; // this can be your app name
            $audience_claim = "Sales-app";
            $issued_at = time();
            // $expiry_time_jwt = $issued_at + (60*60*168); // 7 day expiry, 
            $expiry_time_jwt = $issued_at + (60 * 60 * 24 * 365 * 10); // 20 years
            

            $payload = [
                "iss" => $issuer_claim,
                "aud" => $audience_claim,
                "iat" => $issued_at,
                "exp" => $expiry_time_jwt,
                "staff_sno" => $staff_id,
                "mobile_no" => $mobile_no,
            ];

            $jwt_token = JWT::encode($payload, $secret_key, 'HS256');

            $newCugUser = new cugUser();
            $newCugUser->name = $user->staff_name;
            $newCugUser->cug_id = $user->sno;
            $newCugUser->cug_mobile = $mobile_no;
            $newCugUser->user_id = $user->staff_id;
            $newCugUser->token = $jwt_token;
            $newCugUser->branch_id = $user->branch_id;
            $newCugUser->created_at =Carbon::now('Asia/Kolkata');
            $newCugUser->updated_at = Carbon::now('Asia/Kolkata');

            $newCugUser->save();

            $token = new PersonalAccessToken();
            $token->forceFill([
                'tokenable_type' => \App\Models\cugUser::class,
                'tokenable_id'   => $newCugUser->id,
                'name'           => 'jwt_token',
                'token'          => hash('sha256', $jwt_token),
                'abilities'      => ['*'],
                'expires_at'     => Carbon::createFromTimestamp($expiry_time_jwt),
            ])->save();

        DB::table('mobile_user_login_logs')->insert([
                    'user_id'    => $user->staff_id,        
                    'login_at'   => Carbon::now('Asia/Kolkata'),
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->header('User-Agent'),
                    'mobile_no'  => $mobile_no,
                    'otp'  => $otpInput,
                    'latitude'   => $latitude,
                    'longitude'   => $longitude,
                    'device_id'   => $device_id ?? NULL,
                    'brand'   => $brand ?? NULL,
                    'model'   => $model ?? NULL,
                    'device_name'   => $device_name ?? NULL,
                    'os'   => $os ?? NULL,
                    'android_version'   => $android_version ?? NULL,
                    'sdk_version'   => $sdk_version ?? NULL,
                    'type'       => 0, 
                    'failed_type'       => 0,
                    'created_at' => Carbon::now('Asia/Kolkata'),
                    'updated_at' => Carbon::now('Asia/Kolkata'),
                ]);
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
            'jwt_token' => $jwt_token
        ], 200);
    }

   

    public function staffDetails(Request $request)
    {
        $user = $request->user();

    
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
           
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

            $data =  StaffModel::where('egc_staff.status', '!=', 2)
            ->select('egc_staff.*',
            'egc_department.department_name',
            'egc_division.division_name',
            'egc_job_role.job_position_name as job_role_name',
            )
            ->leftJoin('egc_department', 'egc_staff.department_id', 'egc_department.sno')
            ->leftJoin('egc_division', 'egc_staff.division_id', 'egc_division.sno')
            ->leftJoin('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno')
            ->where('egc_staff.sno', $user->user_id)
            ->first();
        
            $staffCug = DB::table('egc_cug_numbers')
                ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
                ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
                ->where('egc_cug_assignments.is_current', 1)
                ->where('egc_cug_assignments.status', 0)
                ->where('egc_cug_numbers.status', 1)
                ->where('egc_cug_assignments.sno', $user->cug_id)
                ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id')
                ->first();
            
          
            
            $staffData =[
                "id"=>$data->sno,
                "staff_name"=>$data->staff_name,
                "nick_name"=>$data->nick_name ?? '',
                "staff_image"=>$data->profile_image_url ?? '',
                "mobile_no"=>$staffCug ? $staffCug->cug_number : $data->mobile_no,
                "email_id"=>$data->email_id ?? '',
                "department_name"=>$data->department_name ?? '',
                "division_name"=>$data->division_name ?? '',
                "job_role_name"=>$data->job_role_name ?? '', 
                
            ];

        return response()->json([
            'status' => 200,
            'message' => 'Staff data fetched successfully',
            'error_msg' => null,
            'data' => $staffData
        ]);
    }

    public function LeadList(Request $request)
    {
        $user = $request->user();
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

            $page = max((int)$request->page, 1);
            $limit = min(max((int)$request->limit, 10), 100);

            $leads = LeadModel::select(
                'egc_lead.sno',
                'egc_lead.lead_id',
                'egc_lead.is_hot_lead',
                'egc_lead.created_at',
                'egc_lead.created_by',
                'egc_lead.registered_date',
                'egc_lead.lead_mobile',
                'egc_lead.spam_verified',
                'egc_lead.drop_verified',
                'egc_lead.spam_tl_verified',
                'egc_lead.drop_tl_verified',
                'egc_lead.lead_email_id',
                'egc_staff.staff_name',
                'egc_lead.status',
                'egc_lead.lead_name',
                'egc_lead_source.lead_source_name'
            )
            ->leftJoin('egc_staff', 'egc_lead.created_by', '=', 'egc_staff.sno')
            ->leftJoin('egc_lead_source', 'egc_lead.lead_source_id', '=', 'egc_lead_source.sno')
            ->where('egc_lead.internal_status', '!=', 1)
            ->where('egc_lead.created_by', $user->user_id)
            ->whereIn('egc_lead.status', [0,1,4,5,7,10]);

            if ($request->filled('search')) {
                $search = $request->search;
                $leads->where(function ($query) use ($search) {
                    $query->where('egc_lead.lead_name', 'like', "%{$search}%")
                        ->orWhere('egc_lead.lead_mobile', 'like', "%{$search}%")
                        ->orWhere('egc_lead.lead_email_id', 'like', "%{$search}%")
                        ->orWhere('egc_lead.lead_id', 'like', "%{$search}%");
                });
            }

            if ($request->filled('status')) {
                $leads->where('egc_lead.status', $request->status);
            }

            if ($request->filled('lead_source_id')) {
                $leads->where('egc_lead.lead_source_id', $request->lead_source_id);
            }

            if ($request->filled('product_id')) {
                $leads->whereJsonContains('egc_lead.service_id', $request->product_id);
            }

            if ($request->filled('from_date') && $request->filled('to_date')) {
                $leads->whereBetween('egc_lead.created_at', [$request->from_date . ' 00:00:00', $request->to_date . ' 23:59:59']);
            } elseif ($request->filled('from_date')) {
                $leads->where('egc_lead.created_at', '>=', $request->from_date . ' 00:00:00');
            } elseif ($request->filled('to_date')) {
                $leads->where('egc_lead.created_at', '<=', $request->to_date . ' 23:59:59');
            }

            if ($request->filled('is_hot_lead')) {
                $leads->where('egc_lead.is_hot_lead', $request->is_hot_lead);
            }

            $leads = $leads->paginate($limit, ['*'], 'page', $page);

            $leadItems = collect($leads->items());

                $phones = [];

                foreach ($leadItems as $lead) {

                    $mobile = ltrim($lead->lead_mobile, '0');

                    $phones[] = $lead->lead_mobile;
                    $phones[] = '+91' . $mobile;
                }

            $callData = DB::table('egc_call_tracker')
            ->select(
                'customer_phone_no',
                DB::raw('MAX(call_start_date) as last_call_date')
            )
            ->whereIn('customer_phone_no', $phones)
            ->groupBy('customer_phone_no')
            ->get()
            ->keyBy('customer_phone_no');
               $data = $leadItems->map(function ($item) use ($callData) {

                    $mobile = $item->lead_mobile;
                    $mobile91 = '+91' . ltrim($mobile, '0');

                    $lastCallDate = null;

                    if(isset($callData[$mobile])) {
                        $lastCallDate = $callData[$mobile]->last_call_date;
                    } elseif(isset($callData[$mobile91])) {
                        $lastCallDate = $callData[$mobile91]->last_call_date;
                    }

                    $lead_status = 'Active';
                    $status_color = 'Active';
                    if( $item->status == 0){
                         $lead_status = 'Active';
                        $status_color = 'bg-info';
                    }
                    elseif($item->status == 1){
                        $lead_status = 'In Active';
                        $status_color = 'bg-warning';
                    }
                    elseif( $item->status == 4){
                        $lead_status = 'Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($item->status == 10){
                        $lead_status = 'Old Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($item->status == 5 && ($item->drop_verified == 0 || $item->drop_tl_verified == 0)){
                        $lead_status = 'Dead Lead Awaiting';
                        $status_color = 'bg-danger';
                    }
                    elseif($item->status == 7 && ($item->spam_verified == 0 || $item->spam_tl_verified == 0)){
                        $lead_status = 'Spam Awaiting';
                        $status_color = 'bg-primary';
                    }

                    return [
                        'lead_id'         => $item->sno,
                        'status_code'          => $item->status,
                        'lead_name'       => $item->lead_name,
                        'lead_mobile'     => $item->lead_mobile,
                        'lead_email_id'   => $item->lead_email_id,
                        'is_hot_lead'     => $item->is_hot_lead,
                        'last_call_date'  => $lastCallDate,
                        'created_at'      => $item->created_at,
                        'sales_staff'     => $item->staff_name,
                        'source_name'     => $item->lead_source_name,
                        'registered_date' => $item->registered_date,
                        'status_color' => $status_color,
                        'lead_status' => $lead_status,
                    ];
                });

            

        return response()->json([
            'status' => 200,
            'message' => 'Staff data fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $leads->currentPage(),
                'per_page' => $leads->perPage(),
                'total' => $leads->total(),
                'last_page' => $leads->lastPage(),
                'has_more' => $leads->hasMorePages()
            ]
        ]);
    }

    public function LeadDetail(Request $request)
    {
        $user = $request->user();
        $lead_id = $request->lead_id;
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }
        if (!$lead_id) {
            return response()->json([
                'status' => 404,
                'message' => 'Lead Id is required',
                'error_msg' => 'Lead Id is required',
                'data' => null
            ]);
        }
            $leadData = LeadModel::select(
                'egc_lead.sno',
                'egc_lead.lead_id',
                'egc_lead.is_hot_lead',
                'egc_lead.created_at',
                'egc_lead.created_by',
                'egc_lead.registered_date',
                'egc_lead.lead_mobile',
                'egc_lead.spam_verified',
                'egc_lead.drop_verified',
                'egc_lead.spam_tl_verified',
                'egc_lead.drop_tl_verified',
                'egc_lead.lead_email_id',
                'egc_staff.staff_name',
                'egc_lead.status',
                'egc_lead.lead_name',
                'egc_lead.lead_comments',
                'egc_lead.pincode',
                'egc_lead.address',
                'egc_lead.door_no',
                'egc_lead.service_id',
                'egc_lead_source.lead_source_name',
                'egc_cities.name as city_name', 
                'egc_countries.name as country_name', 
                'egc_states.name as state_name'
            )
            ->leftJoin('egc_staff', 'egc_lead.created_by', '=', 'egc_staff.sno')
            ->leftJoin('egc_lead_source', 'egc_lead.lead_source_id', '=', 'egc_lead_source.sno')
            ->leftJoin('egc_cities', 'egc_cities.id', '=', 'egc_lead.city')
            ->leftJoin('egc_states', 'egc_states.id', '=', 'egc_lead.state')
            ->leftJoin('egc_countries', 'egc_lead.country', '=', 'egc_countries.id')
            ->where('egc_lead.internal_status', '!=', 1)
            ->where('egc_lead.sno', $lead_id)
            ->first();

            if (!$leadData) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Lead Not Found',
                    'error_msg' => 'Lead Not Found',
                    'data' => null
                ]);
            }


        

                $phones = [];

                    $mobile = ltrim($leadData->lead_mobile, '0');

                    $phones[] = $leadData->lead_mobile;
                    $phones[] = '+91' . $mobile;
              

                    $callData = DB::table('egc_call_tracker')
                        ->select(
                            'customer_phone_no',
                            DB::raw('MAX(call_start_date) as last_call_date')
                        )
                        ->whereIn('customer_phone_no', $phones)
                        ->groupBy('customer_phone_no')
                        ->get()
                        ->keyBy('customer_phone_no');
              

                    $mobile = $leadData->lead_mobile;
                    $mobile91 = '+91' . ltrim($mobile, '0');

                    $lastCallDate = null;

                    if(isset($callData[$mobile])) {
                        $lastCallDate = $callData[$mobile]->last_call_date;
                    } elseif(isset($callData[$mobile91])) {
                        $lastCallDate = $callData[$mobile91]->last_call_date;
                    }

                    $lead_status = 'Active';
                    $status_color = 'Active';
                    if( $leadData->status == 0){
                         $lead_status = 'Active';
                        $status_color = 'bg-info';
                    }
                    elseif($leadData->status == 1){
                        $lead_status = 'In Active';
                        $status_color = 'bg-warning';
                    }
                    elseif( $leadData->status == 4){
                        $lead_status = 'Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($leadData->status == 10){
                        $lead_status = 'Old Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($leadData->status == 5 && ($leadData->drop_verified == 0 || $leadData->drop_tl_verified == 0)){
                        $lead_status = 'Dead Lead Awaiting';
                        $status_color = 'bg-danger';
                    }
                    elseif($leadData->status == 7 && ($leadData->spam_verified == 0 || $leadData->spam_tl_verified == 0)){
                        $lead_status = 'Spam Awaiting';
                        $status_color = 'bg-primary';
                    }
                  
                    $service_ids =$leadData->service_id ? json_decode($leadData->service_id ) : [];
            $address = ( $leadData->door_no ? $leadData->door_no.", ":"" ).''.( $leadData->area_street ? $leadData->area_street.", ":"" ).''.( $leadData->city_name ? $leadData->city_name.", ":"" ).''.($leadData->state_name ? $leadData->state_name:"" ).''.( $leadData->pincode ? " - ".$leadData->pincode:"" );
            $product_tags = DB::table('egc_product')->whereIn('sno',$service_ids)->pluck('product_name');
            $data =[
                'lead_id'         => $leadData->sno,
                'status_code'          => $leadData->status,
                'lead_name'       => $leadData->lead_name,
                'lead_mobile'     => $leadData->lead_mobile,
                'lead_email_id'   => $leadData->lead_email_id,
                'is_hot_lead'     => $leadData->is_hot_lead,
                'last_call_date'  => $lastCallDate,
                'created_at'      => $leadData->created_at,
                'sales_staff'     => $leadData->staff_name,
                'source_name'     => $leadData->lead_source_name,
                'registered_date' => $leadData->registered_date,
                'status_color' => $status_color,
                'lead_status' => $lead_status,
                'notes' => $leadData->lead_comments,
                'address' => $address,
                'product_tags' => $product_tags,
                
            ];

        return response()->json([
            'status' => 200,
            'message' => 'Lead data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function leadSourceList(Request $request)
    {
        $leadSource = LeadSourceModel::select('sno', 'lead_source_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Lead source list fetched successfully',
            'error_msg' => null,
            'data' => $leadSource
        ], 200);
    }

    public function productList(Request $request)
    {
        $products = ProductModel::select('sno', 'product_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Product list fetched successfully',
            'error_msg' => null,
            'data' => $products
        ], 200);
    }

     public function FollowupList(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $page = max((int)$request->page, 1);
        $limit = min(max((int)$request->limit, 10), 100);

        $followups = DB::table('egc_appointment')
            ->select(
                'egc_appointment.sno',
                'egc_appointment.lead_id as ld_name_id',
                'egc_appointment.appointment_date',
                'egc_appointment.appointment_time',
                'egc_appointment.status as appointment_status',
                'egc_appointment.reason as appointment_reason',
                'egc_appointment.created_by as staff_id',
                'egc_appointment.created_at',
                'egc_lead.lead_name',
                'egc_lead.lead_mobile',
                'egc_lead.lead_email_id',
                'egc_lead.lead_id',
                'egc_lead.status as lead_status',
                'egc_staff.staff_name'
            )
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->join('egc_staff', 'egc_appointment.created_by', '=', 'egc_staff.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1);

        if ($request->filled('search')) {
            $search = $request->search;
            $followups->where(function ($query) use ($search) {
                $query->where('egc_lead.lead_name', 'like', "%{$search}%")
                    ->orWhere('egc_lead.lead_mobile', 'like', "%{$search}%")
                    ->orWhere('egc_lead.lead_email_id', 'like', "%{$search}%")
                    ->orWhere('egc_staff.staff_name', 'like', "%{$search}%")
                    ->orWhere('egc_staff.nick_name', 'like', "%{$search}%");
            });
        }

        if ($request->filled('from_date') && $request->filled('to_date')) {
            $followups->whereBetween('egc_appointment.appointment_date', [$request->from_date, $request->to_date]);
        } elseif ($request->filled('from_date')) {
            $followups->where('egc_appointment.appointment_date', '>=', $request->from_date);
        } elseif ($request->filled('to_date')) {
            $followups->where('egc_appointment.appointment_date', '<=', $request->to_date);
        }

        if ($request->filled('status')) {
            $followups->where('egc_appointment.status', $request->status);
        }
        if ($request->filled('lead_id')) {
            $followups->where('egc_appointment.lead_id', $request->lead_id);
        }

        $followups = $followups->orderBy('egc_appointment.sno', 'desc')->paginate($limit, ['*'], 'page', $page);

        $followupItems = collect($followups->items());

        $data = $followupItems->map(function ($item) {
            $followup_status = 'Followup Pending';
            $followup_status_color = 'bg-warning';
            if ($item->appointment_status == 1) {
                $followup_status = 'Followup Pending';
                $followup_status_color = 'bg-warning';
            } elseif ($item->appointment_status == 4) {
                $followup_status = 'Completed';
                $followup_status_color = 'bg-success';
            } elseif ($item->appointment_status == 3) {
                $followup_status = 'Cancelled';
                $followup_status_color = 'bg-danger';
            }

            $lead_status = 'Active';
            $lead_status_color = 'Active';
            if ($item->lead_status == 0) {
                $lead_status = 'Active';
                $lead_status_color = 'bg-info';
            } elseif ($item->lead_status == 1) {
                $lead_status = 'In Active';
                $lead_status_color = 'bg-warning';
            } elseif ($item->lead_status == 4) {
                $lead_status = 'Customer';
                $lead_status_color = 'bg-success';
            } elseif ($item->lead_status == 10) {
                $lead_status = 'Old Customer';
                $lead_status_color = 'bg-success';
            }

            return [
                'followup_id'         => $item->sno,
                'lead_id'             => $item->ld_name_id,
                'lead_name'           => $item->lead_name,
                'lead_mobile'         => $item->lead_mobile,
                'lead_email_id'       => $item->lead_email_id,
                'lead_status_code'    => $item->lead_status,
                'lead_status'         => $lead_status,
                'lead_status_color'   => $lead_status_color,
                'appointment_date'    => $item->appointment_date,
                'appointment_time'    => $item->appointment_time,
                'followup_status'     => $followup_status,
                'followup_status_color' => $followup_status_color,
                'appointment_status'  => $item->appointment_status,
                'appointment_reason'  => $item->appointment_reason,
                'sales_staff'         => $item->staff_name,
                'created_at'          => $item->created_at,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => 'Followup list fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $followups->currentPage(),
                'per_page' => $followups->perPage(),
                'total' => $followups->total(),
                'last_page' => $followups->lastPage(),
                'has_more' => $followups->hasMorePages()
            ]
        ]);
    }


    public function FollowupAdd(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'appointment_date' => 'required',
            'appointment_time' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $lead_id = $request->lead_id;
        $appointment_date =$request->appointment_date ? date('Y-m-d', strtotime($request->appointment_date)) : null;
        $appointment_time = $request->appointment_time ? date('H:i:s', strtotime($request->appointment_time)) : null;
        $reason = $request->reason ?? '';

        $followupPending = AppointmentModel::where('lead_id',$lead_id)
            ->where('appointment_date',$appointment_date)
            ->where('appointment_time',$appointment_time)
            ->where('status',1)
            ->first();
        if($followupPending){
            return response()->json([
                'status' => 404,
                'message' => 'Followup already exists',
                'error_msg' => 'Followup already exists',
                'data' => null
            ]);
        }

        $lead = LeadModel::where('sno', $lead_id)->where('internal_status', '!=', 1)->first();
        if (!$lead) {
            return response()->json([
                'status' => 404,
                'message' => 'Lead not found',
                'error_msg' => 'Lead not found',
                'data' => null
            ]);
        }

        $last = AppointmentModel::lockForUpdate()
                ->orderByDesc('sno')
                ->first();

            if(!$last){
                $appointmentId = 'AP-0001/'.date('y');
            }else{
                preg_match('/AP-(\d+)/',$last->appointment_id,$match);
                $next = isset($match[1]) ? ((int)$match[1])+1: 1;
                $appointmentId = sprintf('AP-%04d/%s', $next,date('y'));
            }

        $followup = new AppointmentModel();
        $followup->lead_id = $lead_id;
        $followup->appointment_id = $appointmentId;
        $followup->appointment_date = $appointment_date;
        $followup->appointment_time = $appointment_time;
        // $followup->reason = $reason;
        $followup->created_by = $user->user_id;
        $followup->updated_by = $user->user_id;
        $followup->branch_id = $staff->branch_id ?? 1;
        $followup->status = 1;
        $followup->save();

        return response()->json([
            'status' => 200,
            'message' => 'Followup added successfully',
            'error_msg' => null,
            'data' => [
                'followup_id' => $followup->sno,
                'lead_id' => $followup->lead_id,
                'appointment_date' => $followup->appointment_date,
                'appointment_time' => $followup->appointment_time,
                // 'reason' => $followup->reason,
            ]
        ], 200);
    }

    public function TeamCallList(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $page = max((int)$request->page, 1);
        $limit = min(max((int)$request->limit, 10), 100);

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $search = $request->filled('search') ? $request->search : '';

        $salesStaff = DB::table('egc_staff')
            ->select(
                'egc_staff.sno',
                'egc_staff.staff_name',
                'egc_staff.staff_image',
                'egc_staff.gender',
                'egc_staff.mobile_no',
                'egc_cug_numbers.cug_number as cug_mobile'
            )
           ->leftJoin('egc_cug_assignments', 'egc_staff.sno', '=', 'egc_cug_assignments.staff_id')
            ->leftJoin('egc_cug_numbers', 'egc_cug_numbers.sno', '=', 'egc_cug_management.cug_id')
            ->where('egc_staff.department_id', 1)
            ->where('egc_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('egc_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('egc_staff.status', [4, 5, 6, 7]);
                    });
            });

        if ($search != '') {
            $salesStaff->where(function ($query) use ($search) {
                $query->where('egc_staff.staff_name', 'LIKE', "%{$search}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search}%")
                    ->orWhere('egc_cug_management.staff_mobile', 'LIKE', "%{$search}%");
            });
        }

        $totalStaff = $salesStaff->count();
        $salesStaff = $salesStaff->orderBy('egc_staff.sno', 'desc')->paginate($limit, ['*'], 'page', $page);

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $callData = DB::table('egc_call_tracker')
            ->select(
                'branch_staff_id',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count")
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray())
            ->groupBy('branch_staff_id')
            ->get()
            ->keyBy('branch_staff_id');

        $staffItems = collect($salesStaff->items());

        $data = $staffItems->map(function ($item) use ($callData, $dayCount) {
            $callStats = $callData[$item->sno] ?? (object) [
                'incoming_call_count' => 0,
                'outgoingcall_count' => 0,
                'missedcall_count' => 0,
                'rejected_call_count' => 0,
                'dialedcall_count' => 0,
            ];

            $total_calls = $callStats->incoming_call_count + $callStats->missedcall_count + $callStats->rejected_call_count;
            $missed_call_ratio = $total_calls > 0 ? ($callStats->missedcall_count / $total_calls) * 100 : 0;

            $defaultPath = $item->gender == 1
                ? asset('assets/phdizone_images/auth/user_2.png')
                : asset('assets/phdizone_images/auth/user_7.png');

            $staffImageUrl = $item->staff_image
                ? url('/staff_images') . '/' . $item->staff_image
                : $defaultPath;

            return [
                'staff_id' => $item->sno,
                'staff_name' => $item->staff_name,
                'staff_image' => $staffImageUrl,
                'mobile_no' => $item->mobile_no,
                'cug_mobile' => $item->cug_mobile,
                'incoming_call_count' => $callStats->incoming_call_count,
                'outgoingcall_count' => $callStats->outgoingcall_count,
                'missedcall_count' => $callStats->missedcall_count,
                'rejected_call_count' => $callStats->rejected_call_count,
                'dialedcall_count' => $callStats->dialedcall_count,
                'outgoing_call_ratio' => $dayCount > 0 ? round($callStats->outgoingcall_count / $dayCount) : 0,
                'incoming_call_ratio' => $dayCount > 0 ? round($callStats->incoming_call_count / $dayCount) : 0,
                'missed_call_rate' => $dayCount > 0 ? round($callStats->missedcall_count / $dayCount) : 0,
                'missed_call_ratio' => round($missed_call_ratio, 2),
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => 'Team call list fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $salesStaff->currentPage(),
                'per_page' => $salesStaff->perPage(),
                'total' => $salesStaff->total(),
                'last_page' => $salesStaff->lastPage(),
                'has_more' => $salesStaff->hasMorePages()
            ]
        ]);
    }

    public function FollowupDetail(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'followup_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $followup_id = $request->followup_id;

        $followupData = DB::table('egc_appointment')
            ->select(
                'egc_appointment.sno',
                'egc_appointment.lead_id',
                'egc_appointment.appointment_date',
                'egc_appointment.appointment_time',
                'egc_appointment.status as appointment_status',
                'egc_appointment.reason as appointment_reason',
                'egc_appointment.created_by as staff_id',
                'egc_appointment.created_at',
                'egc_lead.lead_name',
                'egc_lead.lead_mobile',
                'egc_lead.lead_email_id',
                'egc_lead.lead_id as lead_unique_id',
                'egc_lead.status as lead_status',
                'egc_staff.staff_name'
            )
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->join('egc_staff', 'egc_appointment.created_by', '=', 'egc_staff.sno')
            ->where('egc_appointment.sno', $followup_id)
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->first();

        if (!$followupData) {
            return response()->json([
                'status' => 404,
                'message' => 'Followup not found',
                'error_msg' => 'Followup not found',
                'data' => null
            ]);
        }

        $followup_status = 'Followup Pending';
        $followup_status_color = 'bg-warning';
        if ($followupData->appointment_status == 1) {
            $followup_status = 'Followup Pending';
            $followup_status_color = 'bg-warning';
        } elseif ($followupData->appointment_status == 4) {
            $followup_status = 'Completed';
            $followup_status_color = 'bg-success';
        } elseif ($followupData->appointment_status == 3) {
            $followup_status = 'Cancelled';
            $followup_status_color = 'bg-danger';
        }

        $lead_status = 'Active';
        $lead_status_color = 'Active';
        if ($followupData->lead_status == 0) {
            $lead_status = 'Active';
            $lead_status_color = 'bg-info';
        } elseif ($followupData->lead_status == 1) {
            $lead_status = 'In Active';
            $lead_status_color = 'bg-warning';
        } elseif ($followupData->lead_status == 4) {
            $lead_status = 'Customer';
            $lead_status_color = 'bg-success';
        } elseif ($followupData->lead_status == 10) {
            $lead_status = 'Old Customer';
            $lead_status_color = 'bg-success';
        }

        $data = [
            'followup_id' => $followupData->sno,
            'lead_id' => $followupData->lead_id,
            'lead_unique_id' => $followupData->lead_unique_id,
            'lead_name' => $followupData->lead_name,
            'lead_mobile' => $followupData->lead_mobile,
            'lead_email_id' => $followupData->lead_email_id,
            'lead_status_code' => $followupData->lead_status,
            'lead_status' => $lead_status,
            'lead_status_color' => $lead_status_color,
            'appointment_date' => $followupData->appointment_date,
            'appointment_time' => $followupData->appointment_time,
            'followup_status' => $followup_status,
            'followup_status_color' => $followup_status_color,
            'appointment_status' => $followupData->appointment_status,
            'appointment_reason' => $followupData->appointment_reason,
            'sales_staff' => $followupData->staff_name,
            'created_at' => $followupData->created_at,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Followup data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

     public function teamCallByStaffId(Request $request)
    {
        $user = $request->user();

        $staff = DB::table('egc_cug_numbers')
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->where('egc_cug_assignments.sno', $user->cug_id)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'staff_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $staff_id = $request->staff_id;

        $salesStaff = DB::table('egc_staff')
            ->select(
                'egc_staff.sno',
                'egc_staff.staff_name',
                'egc_staff.staff_image',
                'egc_staff.gender',
                'egc_staff.mobile_no',
                'egc_cug_numbers.cug_number as cug_mobile'
            )
            ->leftJoin('egc_cug_assignments', 'egc_staff.sno', '=', 'egc_cug_assignments.staff_id')
            ->leftJoin('egc_cug_numbers', 'egc_cug_numbers.sno', '=', 'egc_cug_management.cug_id')
            ->where('egc_staff.department_id', 1)
            ->where('egc_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('egc_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('egc_staff.status', [4, 5, 6, 7]);
                    });
            })
            ->where('egc_staff.sno', $staff_id)
            ->first();

        if (!$salesStaff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $callData = DB::table('egc_call_tracker')
            ->select(
                'branch_staff_id',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count")
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('branch_staff_id', $staff_id)
            ->groupBy('branch_staff_id')
            ->first();

        $callStats = $callData ?: (object) [
            'incoming_call_count' => 0,
            'outgoingcall_count' => 0,
            'missedcall_count' => 0,
            'rejected_call_count' => 0,
            'dialedcall_count' => 0,
        ];

        $total_calls = $callStats->incoming_call_count + $callStats->missedcall_count + $callStats->rejected_call_count;
        $missed_call_ratio = $total_calls > 0 ? ($callStats->missedcall_count / $total_calls) * 100 : 0;

        $defaultPath = $salesStaff->gender == 1
            ? asset('assets/phdizone_images/auth/user_2.png')
            : asset('assets/phdizone_images/auth/user_7.png');

        $staffImageUrl = $salesStaff->staff_image
            ? url('/staff_images') . '/' . $salesStaff->staff_image
            : $defaultPath;

        $data = [
            'staff_id' => $salesStaff->sno,
            'staff_name' => $salesStaff->staff_name,
            'staff_image' => $staffImageUrl,
            'mobile_no' => $salesStaff->mobile_no,
            'cug_mobile' => $salesStaff->cug_mobile,
            'incoming_call_count' => $callStats->incoming_call_count,
            'outgoingcall_count' => $callStats->outgoingcall_count,
            'missedcall_count' => $callStats->missedcall_count,
            'rejected_call_count' => $callStats->rejected_call_count,
            'dialedcall_count' => $callStats->dialedcall_count,
            'outgoing_call_ratio' => $dayCount > 0 ? round($callStats->outgoingcall_count / $dayCount) : 0,
            'incoming_call_ratio' => $dayCount > 0 ? round($callStats->incoming_call_count / $dayCount) : 0,
            'missed_call_rate' => $dayCount > 0 ? round($callStats->missedcall_count / $dayCount) : 0,
            'missed_call_ratio' => round($missed_call_ratio, 2),
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Team call data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function LeadDashboardCard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $monthStart = Carbon::now()->startOfMonth()->toDateString();

        $totalLeads = 0;

        $activeLeads = 0;

        $inactiveLeads = 0;

        $customerLeads = 0;

        $oldCustomerLeads = 0;

        $hotLeads = 0;

        $newLeadsToday = 0;

        $newLeadsMonth = 0;

        $data = [
            'total_leads' => $totalLeads,
            'active_leads' => $activeLeads,
            'inactive_leads' => $inactiveLeads,
            'customer_leads' => $customerLeads,
            'old_customer_leads' => $oldCustomerLeads,
            'hot_leads' => $hotLeads,
            'new_leads_today' => $newLeadsToday,
            'new_leads_month' => $newLeadsMonth,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Lead dashboard card fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function FollowupDashboard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $weekStart = Carbon::now()->startOfWeek(Carbon::MONDAY)->toDateString();

        $totalFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->count();

        $pendingFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->where('egc_appointment.status', 1)
            ->count();

        $completedFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->where('egc_appointment.status', 4)
            ->count();

        $cancelledFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->where('egc_appointment.status', 3)
            ->count();

        $todayFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->whereDate('egc_appointment.appointment_date', $today)
            ->count();

        $thisWeekFollowups = DB::table('egc_appointment')
            ->join('egc_lead', 'egc_appointment.lead_id', '=', 'egc_lead.sno')
            ->where('egc_appointment.created_by', $user->user_id)
            ->where('egc_lead.internal_status', '!=', 1)
            ->whereBetween('egc_appointment.appointment_date', [$weekStart, $today])
            ->count();

        $data = [
            'total_followups' => $totalFollowups,
            'pending_followups' => $pendingFollowups,
            'completed_followups' => $completedFollowups,
            'cancelled_followups' => $cancelledFollowups,
            'today_followups' => $todayFollowups,
            'this_week_followups' => $thisWeekFollowups,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Followup dashboard fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function TeamCallDashboard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $monthStart = Carbon::now()->startOfMonth()->toDateString();

        $salesStaffIds = DB::table('egc_staff')
            ->where('egc_staff.department_id', 1)
            ->where('egc_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('egc_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('egc_staff.status', [4, 5, 6, 7]);
                    });
            })
            ->pluck('egc_staff.sno')
            ->toArray();

        $todayCalls = DB::table('egc_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->whereIn('branch_staff_id', $salesStaffIds)
            ->whereDate('call_start_date', $today)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $monthCalls = DB::table('egc_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->whereIn('branch_staff_id', $salesStaffIds)
            ->whereDate('call_start_date', '>=', $monthStart)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $getCount = function ($calls, $status) {
            return isset($calls[$status]) ? $calls[$status]->count : 0;
        };

        $data = [
            'today' => [
                'incoming_calls' => $getCount($todayCalls, 1),
                'outgoing_calls' => $getCount($todayCalls, 0),
                'missed_calls' => $getCount($todayCalls, 2),
                'rejected_calls' => $getCount($todayCalls, 3),
                'dialed_calls' => $getCount($todayCalls, 4),
            ],
            'this_month' => [
                'incoming_calls' => $getCount($monthCalls, 1),
                'outgoing_calls' => $getCount($monthCalls, 0),
                'missed_calls' => $getCount($monthCalls, 2),
                'rejected_calls' => $getCount($monthCalls, 3),
                'dialed_calls' => $getCount($monthCalls, 4),
            ],
            'team_members_count' => count($salesStaffIds),
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Team call dashboard fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function CallDashboard(Request $request)
    {
        $user = $request->user();

        $staff = DB::table('egc_cug_numbers')
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->where('egc_cug_assignments.sno', $user->cug_id)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
            ->first();
        
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }


        $today = Carbon::today()->toDateString();
        $monthStart = Carbon::now()->startOfMonth()->toDateString();

        $todayCalls = DB::table('egc_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->where('staff_phone_no', $staff->cug_number)
            ->whereDate('call_start_date', $today)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $monthCalls = DB::table('egc_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->where('staff_phone_no', $staff->cug_number)
            ->whereDate('call_start_date', '>=', $monthStart)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $getCount = function ($calls, $status) {
            return isset($calls[$status]) ? $calls[$status]->count : 0;
        };

        $data = [
            'today' => [
                'incoming_calls' => $getCount($todayCalls, 1),
                'outgoing_calls' => $getCount($todayCalls, 0),
                'missed_calls' => $getCount($todayCalls, 2),
                'rejected_calls' => $getCount($todayCalls, 3),
                'dialed_calls' => $getCount($todayCalls, 4),
            ],
            'this_month' => [
                'incoming_calls' => $getCount($monthCalls, 1),
                'outgoing_calls' => $getCount($monthCalls, 0),
                'missed_calls' => $getCount($monthCalls, 2),
                'rejected_calls' => $getCount($monthCalls, 3),
                'dialed_calls' => $getCount($monthCalls, 4),
            ],
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Call dashboard fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

      public function FollowupClose(Request $request)
{
    $user = $request->user();

    $staff = StaffModel::find($user->user_id);
    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ],404);
    }
    $validator = Validator::make($request->all(), [

        'followup_id'      => 'required|integer',
        'progressed'       => 'required|in:2,1',

        // required only while rescheduling
        'appointment_date' => 'required_if:progressed,2',
        'appointment_time' => 'required_if:progressed,2',

        'reason'           => 'nullable|string',
        'convo_message'    => 'nullable|string',
        // 'app_score'        => 'nullable|numeric',
        // 'follow_through'   => 'nullable|numeric',
        // 'hot_lead'         => 'nullable',
        // 'pb'               => 'nullable'
    ]);

    if ($validator->fails()) {

        return response()->json([
            'status'=>422,
            'message'=>'Validation Error',
            'error_msg'=>$validator->errors(),
            'data'=>null
        ],422);

    }

    DB::beginTransaction();

    try {
        $followup = AppointmentModel::where('sno',$request->followup_id)
            ->where('branch_id',$user->branch_id)
            ->where('status',1)
            ->lockForUpdate()
            ->first();
        if(!$followup){
            DB::rollBack();
            return response()->json([
                'status'=>404,
                'message'=>'Follow-up not found',
                'error_msg'=>'Follow-up not found',
                'data'=>null
            ],404);
        }

        $appointment_date =$request->appointment_date ? date('Y-m-d', strtotime($request->appointment_date)) : null;
        $appointment_time = $request->appointment_time ? date('H:i:s', strtotime($request->appointment_time)) : null;

    
        if($request->progressed == 1){
            $followup->progressed      = $request->progressed;
            $followup->follow_through  = $request->follow_through ?? 0;
            $followup->convo_message   = $request->convo_message;
            $followup->status          = 4;
            $followup->updated_by      = $user->user_id;
            $followup->save();

        }else{
            $followup->status      = 5;
            $followup->reason      = $request->reason;
            $followup->updated_by  = $user->user_id;
            $followup->save();

            $last = AppointmentModel::lockForUpdate()
                ->orderByDesc('sno')
                ->first();

            if(!$last){
                $appointmentId = 'AP-0001/'.date('y');
            }else{
                preg_match('/AP-(\d+)/',$last->appointment_id,$match);
                $next = isset($match[1]) ? ((int)$match[1])+1: 1;
                $appointmentId = sprintf('AP-%04d/%s', $next,date('y'));
            }

           

            AppointmentModel::create([
                'appointment_id'   => $appointmentId,
                'lead_id'          => $followup->lead_id,
                'branch_id'        => $followup->branch_id,
                'progressed'       => $request->progressed,
                'app_score'        => $request->app_score ?? 0,
                'follow_through'   => $request->follow_through ?? 0,
                'appointment_date' => $appointment_date,
                'appointment_time' => $appointment_time,
                'status'           => 1,
                'created_by'       => $user->user_id,
                'updated_by'       => $user->user_id
            ]);

        }
        DB::commit();
        return response()->json([
            'status'=>200,
            'message'=>'Follow-up updated successfully.',
            'error_msg'=>null,
            'data'=>null
        ]);
    } catch (\Exception $e){
        DB::rollBack();
        return response()->json([
            'status'=>500,
            'message'=>'Something went wrong.',
            'error_msg'=>$e->getMessage(),
            'data'=>null
        ],500);
    }
}


public function followupReasonList(Request $request)
    {
        $reasonList = FollowupReasonModel::select('sno', 'reason_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Followup reason list fetched successfully',
            'error_msg' => null,
            'data' => $reasonList
        ], 200);
    }

    public function CallTrackerLogSave(Request $request)
    {
        $user = $request->user();

        $staffCug = DB::table('egc_cug_numbers')
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->where('egc_cug_assignments.sno', $user->cug_id)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_numbers.sno as cug_number_id','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
            ->first();

        if (!$staffCug) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'customer_phone_no' => 'required|string',
            'customer_name' => 'nullable|string',
            'call_status' => 'required|integer|in:0,1,2,3,4',
            'call_duration' => 'nullable|string',
            'call_start_date' => 'required|date',
            'call_start_time' => 'required',
            'call_end_date' => 'nullable|date',
            'call_end_time' => 'nullable',
            'latitude' => 'nullable',
            'longitude' => 'nullable',
            'customer_status' => 'nullable',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $staffId = $user->user_id;
        $cugId = $staffCug->sno;
        $entityId = $staffCug->entity_id ?? 0;
        $branchId = $staffCug->branch_id ?? 0;

        DB::beginTransaction();
        try {

            $alreadyExist = CallTrackerModel::where('staff_phone_no', $staffCug->cug_number)
                    ->where('customer_phone_no', $request->customer_phone_no)
                    ->where('call_status', $request->call_status)
                    ->whereDate('call_start_date', $request->call_start_date)
                    ->whereTime('call_start_time', $request->call_start_time)
                    ->exists();
 
                if ($alreadyExist) {
                    DB::rollBack();
 
                    return response()->json([
                        'status' => 200,
                        'message' => 'Call tracker log already exists.',
                        'error_msg' => null,
                    ]);
                }
                
            $audioFileName = null;
            if ($request->hasFile('call_record_file')) {
                $audio = $request->file('call_record_file');
                $audioDestination = public_path('call_audios');
                if (!file_exists($audioDestination)) {
                    mkdir($audioDestination, 0777, true);
                }
                $audioExtension = $audio->getClientOriginalExtension();
                $audioFileName  = uniqid('call_') . '_' . time() . '.' . $audioExtension;
                $audio->move($audioDestination, $audioFileName);
            }

            $callTracker = new CallTrackerModel();
            $callTracker->entity_id = $entityId;
            $callTracker->branch_id = $branchId;
            $callTracker->cug_id = $staffCug->cug_number_id;
            $callTracker->cug_assignment_id = $staffCug->sno;
            $callTracker->branch_staff_id = $staffId;
            $callTracker->call_tracker_staff_id = $staffId;
            $callTracker->staff_phone_no = $staffCug->cug_number ?? '';
            $callTracker->customer_phone_no = $request->customer_phone_no;
            $callTracker->customer_name = $request->customer_name;
            $callTracker->customer_status = $request->customer_status;
            $callTracker->call_start_date = $request->call_start_date;
            $callTracker->call_start_time = $request->call_start_time;
            $callTracker->call_end_date = $request->call_end_date;
            $callTracker->call_end_time = $request->call_end_time;
            $callTracker->call_duration = $request->call_duration;
            $callTracker->call_status = $request->call_status;
            $callTracker->count_status = 1;
            $callTracker->latitude = $request->latitude;
            $callTracker->longitude = $request->longitude;
            $callTracker->audio_file = $audioFileName;
            $callTracker->created_at = Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');
            $callTracker->updated_at = Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');
            $callTracker->save();

            $staff_mobile = $callTracker->customer_phone_no;
            $phoneWithCountryCode = '+91' . $staff_mobile;
            $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $staff_mobile);

            $lead_update = StaffModel::where(function ($query) use ($staff_mobile, $phoneWithCountryCode, $phoneWithoutCountryCode) {
                $query->where('mobile_no', 'LIKE', "%{$staff_mobile}%")
                    ->orWhere('mobile_no', $phoneWithCountryCode)
                    ->orWhere('mobile_no', $phoneWithoutCountryCode);
            })->where('status', '!=', 2)->first();

            $derivedLeadId = $lead_update ? $lead_update->sno : null;

            $communicator_mobile = $callTracker->customer_phone_no;

            $phoneWithCountryCode = '+91' . ltrim($communicator_mobile, '0');

            $phoneWithoutCountryCode = preg_replace('/^\+91/', '', $communicator_mobile);
            $phoneWithoutCountryCode = ltrim($phoneWithoutCountryCode, '0');

            $phonesToCheck = array_values(array_unique([
                $communicator_mobile,
                $phoneWithCountryCode,
                $phoneWithoutCountryCode,
            ]));

            $contact = CallContactsModel::whereIn('phone', $phonesToCheck)
                        ->first();

            if (!$contact) {

                try {

                    $contact = new CallContactsModel();

                    $contact->phone = $communicator_mobile;
                    $contact->name = $request->customer_name;
                    $contact->staff_id = $derivedLeadId;

                    $contact->outgoing_count = 0;
                    $contact->incoming_count = 0;
                    $contact->missed_count = 0;
                    $contact->rejected_count = 0;
                    $contact->dialed_count = 0;

                    $contact->last_staff_id = $staffId;
                    $contact->created_by = $staffId;
                    $contact->updated_by = $staffId;

                    $contact->created_at = now('Asia/Kolkata');
                    $contact->updated_at = now('Asia/Kolkata');

                    $contact->status = 0;

                    $contact->save();

                } catch (\Illuminate\Database\QueryException $e) {

                    // MySQL duplicate entry
                    if ((int) $e->errorInfo[1] === 1062) {

                        // Another simultaneous request created this contact.
                        $contact = CallContactsModel::whereIn('phone', $phonesToCheck)
                            ->first();

                        if (!$contact) {
                            throw $e;
                        }

                    } else {
                        throw $e;
                    }
                }
            }

            /* Update contact information */

            $contactUpdate = [
                'name' => $request->customer_name,
                'last_staff_id' => $staffId,
                'updated_by' => $staffId,
                'updated_at' => now('Asia/Kolkata'),
            ];

            if ($derivedLeadId && empty($contact->staff_id)) {
                $contactUpdate['staff_id'] = $derivedLeadId;
            }

            CallContactsModel::where('sno', $contact->sno)
                ->update($contactUpdate);


            /*Increment call counter atomically */

            $counterColumn = match ((int) $request->call_status) {
                0 => 'outgoing_count',
                1 => 'incoming_count',
                2 => 'missed_count',
                3 => 'rejected_count',
                4 => 'dialed_count',
                default => null,
            };

            if ($counterColumn) {
                CallContactsModel::where('sno', $contact->sno)
                    ->increment($counterColumn);
            }


            /* Refresh contact */

            $contact->refresh();

            $callTracker->contact_id = $contact->sno;
            $callTracker->save();


            if($request->call_status == 2){
                $customerName = $request->customer_name ?: 'Unknown Customer';
                $customerPhone = $request->customer_phone_no;

                $title = "Missed Call Alert";

                $message = "You missed a call from {$customerName} ({$customerPhone}) on {$request->call_start_date} at {$request->call_start_time}.";

                $this->sendNotification(
                    $user->branch_id,
                    $staffId,
                    $message,
                    $title,
                    $staffId
                );
            }

            DB::commit();

           

            return response()->json([
                'status' => 200,
                'message' => 'Call tracker log saved successfully',
                'error_msg' => null,
                'data' => [
                    'sno' => $callTracker->sno,
                    'contact_id' => $contact->sno,
                    'customer_phone_no' => $callTracker->customer_phone_no,
                    'call_status' => $callTracker->call_status,
                    'call_duration' => $callTracker->call_duration,
                    'call_start_date' => $callTracker->call_start_date,
                    'call_start_time' => $callTracker->call_start_time,
                ]
            ]);

        } catch (\Exception $e) {
            
            DB::rollBack();
            
           Log::error('Notification List Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }


    public function StaffCallLogList(Request $request)
    {
        $user = $request->user();

        // Get Staff
        $staff = DB::table('egc_cug_numbers')
        ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
        ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
        ->where('egc_cug_assignments.is_current', 1)
        ->where('egc_cug_assignments.status', 0)
        ->where('egc_cug_numbers.status', 1)
        ->where('egc_cug_assignments.sno', $user->cug_id)
        ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
        ->first();
       
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }


        // Pagination
        $page = max((int) $request->input('page', 1), 1);
        $limit = min(max((int) $request->input('limit', 20), 10), 100);

        $mobile_filter = $request->filled('mobile_filter');
        $contact_filter = $request->filled('contact_filter');

        // Base Query
        $query = CallTrackerModel::query()
            ->select([
                'sno',
                'contact_id',
                'customer_phone_no',
                'customer_name',
                'customer_status',
                'customer_reason',
                'call_start_date',
                'call_end_date',
                'call_start_time',
                'call_end_time',
                'call_duration',
                'call_status',
                'count_status',
                'latitude',
                'longitude',
                'audio_file',
                'created_at'
            ])
            ->where('staff_phone_no', $staff->cug_number);

        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {

            $search = trim($request->search);

            $query->where(function ($q) use ($search) {
                $q->where('customer_name', 'LIKE', "%{$search}%")
                    ->orWhere('customer_phone_no', 'LIKE', "%{$search}%");
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Call Status
        |--------------------------------------------------------------------------
        */

        if ($request->filled('call_status')) {

            $query->where('call_status', $request->call_status);
        }

        if ($request->filled('contact_filter')) {
            $query->where('contact_id', $contact_filter);
        }
        
        if ($request->filled('mobile_filter')) {
            $query->where('customer_phone_no', $mobile_filter);
        }

        /*
        |--------------------------------------------------------------------------
        | Date Filter
        |--------------------------------------------------------------------------
        */

        if ($request->filled('from_date') && $request->filled('to_date')) {

            $query->whereBetween('call_start_date', [
                $request->from_date,
                $request->to_date
            ]);

        } elseif ($request->filled('from_date')) {

            $query->whereDate('call_start_date', '>=', $request->from_date);

        } elseif ($request->filled('to_date')) {

            $query->whereDate('call_start_date', '<=', $request->to_date);
        }

        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */

        $callLogs = $query
            ->orderBy('call_start_date', 'desc')->orderBy('call_start_time', 'desc')
            ->simplePaginate(
                $limit,
                ['*'],
                'page',
                $page
            );

            $callTrackerItems = collect($callLogs->items());

                $contactIds = $callTrackerItems
                    ->pluck('contact_id')
                    ->filter()
                    ->unique()
                    ->values();
        
                $contacts = DB::table('egc_call_contacts')
                            ->select(
                                'sno',
                                'staff_id'
                            )
                            ->whereIn('sno', $contactIds)
                            ->get()
                            ->keyBy('sno');

                $staffIds = $contacts
                    ->pluck('staff_id')
                    ->filter()
                    ->unique()
                    ->values();

                $staffs = DB::table('egc_staff')
                        ->select(
                            'sno',
                            'staff_name',
                            'mobile_no',
                        )
                        ->whereIn('sno', $staffIds)
                        ->where('status', '!=', 2)
                        ->get()
                        ->keyBy('sno');

            $mobileLookup = DB::table('egc_staff')
                            ->select(
                                'sno',
                                'staff_name',
                                'mobile_no'
                            )
                            ->whereIn(
                                DB::raw("REPLACE(REPLACE(mobile_no,'+91',''),'0','')"),
                                $callTrackerItems
                                    ->pluck('customer_phone_no')
                                    ->map(function ($phone) {
                                        return preg_replace('/[^0-9]/', '', str_replace('+91', '', $phone));
                                    })
                                    ->unique()
                                    ->values()
                            )
                            ->get();

                $mobileLookup = $mobileLookup->keyBy(function ($item) {

                    return preg_replace('/[^0-9]/', '', str_replace('+91', '', $item->mobile_no));

                });

             
        /*Build Response  */

        $statusMap = [
            0 => ['Outgoing', 'bg-success'],
            1 => ['Incoming', 'bg-info'],
            2 => ['Missed', 'bg-warning'],
            3 => ['Rejected', 'bg-danger'],
            4 => ['Dialed', 'bg-primary'],
        ];

        $data = $callTrackerItems->map(function ($item) use ($contacts, $staffs, $mobileLookup, $statusMap) {

            // Contact
            $contact = $contacts->get($item->contact_id);

            // Lead by staff_id
            $staffData = null;

            if ($contact && !empty($contact->staff_id)) {
                $staffData = $staffs->get($contact->staff_id);
            }

            /*
            |--------------------------------------------------------------------------
            | Fallback : Search by Mobile
            |--------------------------------------------------------------------------
            */

            if (!$staffData) {

                $mobile = preg_replace(
                    '/[^0-9]/',
                    '',
                    str_replace('+91', '', $item->customer_phone_no)
                );

                $staffData = $mobileLookup->get($mobile);
            }

            $status = $statusMap[$item->call_status] ?? ['Unknown', 'bg-secondary'];

                $item->audio_url = null;
                $item->audio_size = null;
                if (!empty($item->audio_file)) {
                    $audioName = basename($item->audio_file);
                    $audioPath = public_path('call_audios/' . $audioName);
                    if (is_file($audioPath)) {
                        $item->audio_url = asset('call_audios/' . rawurlencode($audioName));
                        $bytes = filesize($audioPath);
                        if ($bytes >= 1048576) {
                            $item->audio_size = round($bytes / 1048576, 2) . ' MB';
                        } else {
                            $item->audio_size =  round($bytes / 1024, 2) . ' KB';
                        }
                    }
                }

            return [
                'call_log_id' => $item->sno,
                'customer_phone_no' => $item->customer_phone_no,
                'customer_name' => $item->customer_name,
                'lead_id' => $staffData->sno ?? ($contact->staff_id ?? null),
                'lead_name' => $staffData->staff_name ?? null,
                'lead_mobile' => $staffData->mobile_no ?? null,
                'call_status' => $item->call_status,
                'call_status_text' => $status[0],
                'call_status_color' => $status[1],
                'call_duration' => $item->call_duration,
                'call_start_date' => $item->call_start_date,
                'call_end_date' => $item->call_end_date,
                'call_start_time' => $item->call_start_time,
                'call_end_time' => $item->call_end_time,
                'customer_status' => $item->customer_status,
                'count_status' => $item->count_status,
                'latitude' => $item->latitude,
                'longitude' => $item->longitude,
                'audio_url' => $item->audio_url,
                'audio_size' => $item->audio_size,
                'created_at' => $item->created_at,

            ];

        });
       
        return response()->json([
            'status' => 200,
            'message' => 'Staff call log list fetched successfully',
            'error_msg' => null,
            'data' => $data->values(),
            'pagination' => [
                'current_page' => $callLogs->currentPage(),
                'per_page' => $callLogs->perPage(),
                'has_more' => $callLogs->hasMorePages(),
                'next_page_url' => $callLogs->nextPageUrl(),
                'previous_page_url' => $callLogs->previousPageUrl(),

            ]

        ]);

    }

    public function ContactCallHistoryByPhone(Request $request)
    {
        $user = $request->user();

         $staff = DB::table('egc_cug_numbers')
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->where('egc_cug_assignments.sno', $user->cug_id)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
            ->first();
       
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }

        $validator = Validator::make($request->all(), [
            'phone_no' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $phoneInput = trim($request->phone_no);

        $phonesToCheck = [
            $phoneInput,
            '+91' . ltrim($phoneInput, '0'),
            ltrim($phoneInput, '0'),
            '0' . ltrim($phoneInput, '0'),
            preg_replace('/^\+91/', '', $phoneInput),
            preg_replace('/[^0-9]/', '', str_replace('+91', '', $phoneInput)),
        ];
        $phonesToCheck = array_values(array_unique(array_filter($phonesToCheck)));

        $page = max((int) $request->input('page', 1), 1);
        $limit = min(max((int) $request->input('limit', 20), 10), 100);

        $query = CallTrackerModel::query()
            ->select([
                'sno',
                'contact_id',
                'branch_staff_id',
                'staff_phone_no',
                'customer_phone_no',
                'customer_name',
                'customer_status',
                'customer_reason',
                'call_start_date',
                'call_end_date',
                'call_start_time',
                'call_end_time',
                'call_duration',
                'call_status',
                'count_status',
                'audio_file',
                'latitude',
                'longitude',
                'created_at'
            ])
            ->where('staff_phone_no', $staff->cug_number)
            ->whereIn('customer_phone_no', $phonesToCheck);

        if ($request->filled('call_status')) {
            $query->where('call_status', $request->call_status);
        }

        if ($request->filled('from_date') && $request->filled('to_date')) {
            $query->whereBetween('call_start_date', [$request->from_date, $request->to_date]);
        } elseif ($request->filled('from_date')) {
            $query->whereDate('call_start_date', '>=', $request->from_date);
        } elseif ($request->filled('to_date')) {
            $query->whereDate('call_start_date', '<=', $request->to_date);
        }

        $callLogs = $query
            ->orderByDesc('call_start_date')
            ->orderByDesc('sno')
            ->simplePaginate($limit, ['*'], 'page', $page);

        $callItems = collect($callLogs->items());

        $staffIds = $callItems->pluck('branch_staff_id')->filter()->unique()->values();

        $staffLookup = DB::table('egc_staff')
            ->select('sno', 'staff_name', 'staff_image', 'gender')
            ->whereIn('sno', $staffIds)
            ->get()
            ->keyBy('sno');

        $contactIds = $callItems->pluck('contact_id')->filter()->unique()->values();
        $contacts = DB::table('egc_call_contacts')
            ->select('sno', 'staff_id')
            ->whereIn('sno', $contactIds)
            ->get()
            ->keyBy('sno');

        $staffIds = $contacts->pluck('staff_id')->filter()->unique()->values();
        $staffs = DB::table('egc_staff')
            ->select('sno', 'staff_name', 'mobile_no')
            ->whereIn('sno', $staffIds)
            ->where('status', '!=', 2)
            ->get()
            ->keyBy('sno');

        $normalizedInput = preg_replace('/[^0-9]/', '', str_replace('+91', '', $phoneInput));
        $mobileLookup = DB::table('egc_staff')
            ->select('sno', 'staff_name', 'mobile_no')
            ->whereIn(
                DB::raw("REPLACE(REPLACE(mobile_no,'+91',''),'0','')"),
                [$normalizedInput]
            )
            ->get()
            ->keyBy(function ($item) {
                return preg_replace('/[^0-9]/', '', str_replace('+91', '', $item->mobile_no));
            });

        $statusMap = [
            0 => ['Outgoing', 'bg-success'],
            1 => ['Incoming', 'bg-info'],
            2 => ['Missed', 'bg-warning'],
            3 => ['Rejected', 'bg-danger'],
            4 => ['Dialed', 'bg-primary'],
        ];

        $data = $callItems->map(function ($item) use ($staffLookup, $contacts, $staffs, $mobileLookup, $statusMap) {
            $contact = $contacts->get($item->contact_id);

            $staffData = null;
            if ($contact && !empty($contact->staff_id)) {
                $staffData = $staffs->get($contact->staff_id);
            }

            if (!$staffData) {
                $mobile = preg_replace('/[^0-9]/', '', str_replace('+91', '', $item->customer_phone_no));
                $staffData = $mobileLookup->get($mobile);
            }

            $staffData = $staffLookup->get($item->branch_staff_id);

            $staffimg = StaffModel::where('sno', $item->branch_staff_id)->first();

            
            $staffImageUrl = $staffimg->profile_image_url;

            $status = $statusMap[$item->call_status] ?? ['Unknown', 'bg-secondary'];

            $item->audio_url = null;
            $item->audio_size = null;
            if (!empty($item->audio_file)) {
                $audioName = basename($item->audio_file);
                $audioPath = public_path('call_audios/' . $audioName);
                if (is_file($audioPath)) {
                    $item->audio_url = asset('call_audios/' . rawurlencode($audioName));
                    $bytes = filesize($audioPath);
                    if ($bytes >= 1048576) {
                        $item->audio_size = round($bytes / 1048576, 2) . ' MB';
                    } else {
                        $item->audio_size =  round($bytes / 1024, 2) . ' KB';
                    }
                }
            }

            return [
                'call_log_id' => $item->sno,
                'contact_id' => $item->contact_id,
                'customer_phone_no' => $item->customer_phone_no,
                'customer_name' => $item->customer_name,
                'staff_name' => $staff->staff_name ?? null,
                'staff_image' => $staffImageUrl,
                'lead_id' => $staffData->sno ?? ($contact->staff_id ?? null),
                'lead_name' => $staffData->staff_name ?? null,
                'lead_mobile' => $staffData->mobile_no ?? null,
                'call_status' => $item->call_status,
                'call_status_text' => $status[0],
                'call_status_color' => $status[1],
                'call_duration' => $item->call_duration,
                'call_start_date' => $item->call_start_date,
                'call_end_date' => $item->call_end_date,
                'call_start_time' => $item->call_start_time,
                'call_end_time' => $item->call_end_time,
                'customer_status' => $item->customer_status,
                'count_status' => $item->count_status,
                'latitude' => $item->latitude,
                'longitude' => $item->longitude,
                'audio_url' => $item->audio_url,
                'audio_size' => $item->audio_size,
                'created_at' => $item->created_at,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => 'Contact call history fetched successfully',
            'error_msg' => null,
            'data' => $data->values(),
            'pagination' => [
                'current_page' => $callLogs->currentPage(),
                'per_page' => $callLogs->perPage(),
                'has_more' => $callLogs->hasMorePages(),
                'next_page_url' => $callLogs->nextPageUrl(),
                'previous_page_url' => $callLogs->previousPageUrl(),
            ]
        ]);
    }

    public function ContactDetailByPhone(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::select('sno')
            ->where('sno', $user->user_id)
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'phone_no' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $phoneInput = trim($request->phone_no);

        $phonesToCheck = [
            $phoneInput,
            '+91' . ltrim($phoneInput, '0'),
            ltrim($phoneInput, '0'),
            '0' . ltrim($phoneInput, '0'),
            preg_replace('/^\+91/', '', $phoneInput),
            preg_replace('/[^0-9]/', '', str_replace('+91', '', $phoneInput)),
        ];
        $phonesToCheck = array_values(array_unique(array_filter($phonesToCheck)));

        $normalizedInput = preg_replace('/[^0-9]/', '', str_replace('+91', '', $phoneInput));

        $communicator = StaffModel::select(
            'egc_staff.sno',
            'egc_staff.staff_id',
            'egc_staff.staff_name',
            'egc_staff.email_id',
            'egc_staff.mobile_no'
        )
            ->whereIn('egc_staff.mobile_no', $phonesToCheck)
            ->orWhereIn(
                DB::raw("REPLACE(REPLACE(egc_staff.mobile_no,'+91',''),'0','')"),
                [$normalizedInput]
            )
            ->where('egc_staff.status', '!=', 2)
            ->first();

        if ($communicator) {
            $data = [
                'is_lead'     => true,
                'lead_id'     => $communicator->sno,
                'lead_unique_id' => $communicator->staff_id,
                'lead_name'   => $communicator->staff_name,
                'lead_email_id' => $communicator->email_id,
                'lead_mobile' => $communicator->mobile_no,
            ];
        } else {
            $contact = CallContactsModel::select('name', 'phone')
                ->whereIn('phone', $phonesToCheck)
                ->orWhereIn(
                    DB::raw("REPLACE(REPLACE(phone,'+91',''),'0','')"),
                    [$normalizedInput]
                )
                ->first();

            $data = [
                'is_lead'     => false,
                'lead_id'     => null,
                'lead_unique_id' => null,
                'lead_name'   => $contact ? $contact->name : null,
                'lead_email_id' => null,
                'lead_mobile' => $contact ? $contact->phone : null,
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => $communicator ? 'contact detail fetched successfully' : 'No Contacts found for this phone number',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function roleCheckByUserId(Request $request)
    {
         $user = $request->user();

        $staff = StaffModel::where('egc_staff.sno', $user->user_id)
             ->leftJoin('egc_user_role', 'egc_user_role.sno', '=', 'egc_staff.role_id')
             ->select('egc_staff.*', 'egc_user_role.role_name')
            ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $role_id = $staff->role_id;


        if (in_array($role_id, [1])) {
            $role_check = 1;
            $role_name =$staff->role_name ?? '-' ;
            $menu = [
                "calls"=> true,
                "lead"=> false,
                "customer"=> false,
                "follow_up"=> false,
                "team_call"=> true
            ];
        } elseif ($role_id == 33) {
            $role_check = 3;
            $role_name =$staff->role_name ?? '-' ;
            $menu = [
                "calls"=> true,
                "lead"=> false,
                "customer"=> false,
                "follow_up"=> false,
                "team_call"=> false
            ];
        } else {
            $role_check = 3;
            $role_name =$staff->role_name ?? '-' ;
            $menu = [
                "calls"=> true,
                "lead"=> false,
                "customer"=> false,
                "follow_up"=> false,
                "team_call"=> false
            ];
        }

        $data = [
            'user_id'    => $staff->sno,
            'role_id'    => $role_id,
            'role_check' => $role_check,
            'role_name' => $role_name,
            'menu' => $menu,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Role check fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }


     public function NotificationList(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notifications = NotificationMobileModel::where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                ->where('status', '!=', 2)
                ->latest('notification_date')
                ->get();

            $notifications = $notifications->map(function ($item) {

                $dt = Carbon::parse($item->notification_date);

                return [
                    'id' => $item->sno,
                    'message' => $item->notification_content,
                    'notification_date' => $item->notification_date,
                    'time_ago' => $dt->diffForHumans(),
                    'formatted_date' => $dt->format('d-M-Y'),
                    'formatted_time' => $dt->format('h:i A'),
                    'status' => $item->status,
                ];
            });

            return response()->json([
                'status' => 200,
                'message' => 'Notification list fetched successfully',
                'data' => $notifications
            ]);
        } catch (\Exception $e) {

            \Log::error('Notification List Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

     public function GetUnreadNotificationCount(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notifications = NotificationMobileModel::where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->latest('notification_date')
                ->count();

           

            return response()->json([
                'status' => 200,
                'message' => 'Get Unread Count successfully',
                'data' => [
                    "unread_count" => $notifications,
                ]
            ]);
        } catch (\Exception $e) {

            \Log::error('Notification Count Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }

    public function ClearAllNotifications(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            NotificationMobileModel::where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                // ->where('status', 0)
                ->update([
                    'status' => 2
                ]);

            return response()->json([
                'status' => 200,
                'message' => 'All notifications cleared successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Clear All Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }


    public function ClearSingleNotification(Request $request, $id)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notification = NotificationMobileModel::where('sno', $id)
                ->where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                // ->where('status', 0)
                ->first();

            if (!$notification) {

                return response()->json([
                    'status' => 404,
                    'message' => 'Notification not found or already cleared'
                ], 404);
            }

            $notification->update([
                'status' => 2
            ]);

            return response()->json([
                'status' => 200,
                'message' => 'Notification cleared successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Clear Single Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }


    public function MarkasReadAllNotifications(Request $request)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            NotificationMobileModel::where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->update([
                    'status' => 1
                ]);

            return response()->json([
                'status' => 200,
                'message' => 'All notifications Read successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Read All Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }


    public function ReadSingleNotification(Request $request, $id)
    {
        try {

            $user = $request->user();

            $staff = StaffModel::where('status', '!=', 2)
                ->where('sno', $user->user_id)
                ->first();

            if (!$staff) {

                return response()->json([
                    'status' => 401,
                    'message' => 'Unauthorized'
                ], 401);
            }

            $notification = NotificationMobileModel::where('sno', $id)
                ->where('staff_id', $user->user_id)
                ->where('branch_id', $staff->branch_id)
                ->where('status', 0)
                ->first();

            if (!$notification) {

                return response()->json([
                    'status' => 404,
                    'message' => 'New Notification not found or already Read'
                ], 404);
            }

            $notification->update([
                'status' => 1
            ]);

            return response()->json([
                'status' => 200,
                'message' => 'Notification Read successfully'
            ]);
        } catch (\Exception $e) {

            \Log::error('Read Single Notification Error : ' . $e->getMessage());

            return response()->json([
                'status' => 500,
                'message' => 'Server Error'
            ], 500);
        }
    }



    public function CallTrackerLogCheck(Request $request)
    {
       

        $validator = Validator::make($request->all(), [
            'log_text' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $log_text = $request->log_text;

        DB::beginTransaction();
        try {
            DB::table('egc_call_log')->insert([
                'log_text' => $log_text,
            ]);

            DB::commit();

            return response()->json([
                'status' => 200,
                'message' => 'Call tracker check log saved successfully',
                'error_msg' => null,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::info('call Log Check Error:', $e->getMessage());
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function CallTrackerLogCheckList(Request $request)
    {
       
        try {

            $log = DB::table('egc_call_log')
                    ->get();

            return response()->json([
                'status' => 200,
                'message' => 'get Call tracker check log List',
                'error_msg' => null,
                'data' => $log,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function updateOnlineStatus(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'online_status' => 'required|integer|in:0,1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $staffCug = CugManagementModel::where('sno', $user->cug_id)->where('status', 0)->first();

        if (!$staffCug) {
            return response()->json([
                'status' => 404,
                'message' => 'CUG staff record not found',
                'error_msg' => 'CUG staff record not found',
                'data' => null
            ], 404);
        }

        DB::beginTransaction();
        try {
            $staffCug->online_status = $request->online_status;
            if($request->online_status == 1){
                 $staffCug->last_online_at =  Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');
            }else{
                $staffCug->last_terminate_at =  Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');
            }
           
            $staffCug->save();

            DB::commit();

            $statusText = $request->online_status == 1 ? 'online' : 'offline';

            return response()->json([
                'status' => 200,
                'message' => 'Online status updated successfully',
                'error_msg' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function updateAppVersion(Request $request)
    {
        $user = $request->user();

       

        $staff = DB::table('egc_cug_numbers')
        ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
        ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
        ->where('egc_cug_assignments.is_current', 1)
        ->where('egc_cug_assignments.status', 0)
        ->where('egc_cug_numbers.status', 1)
        ->where('egc_cug_assignments.sno', $user->cug_id)
        ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
        ->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'app_version' => 'required',
            'build_number' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $staffCug = CugManagementModel::where('sno', $user->cug_id)->where('status', 0)->first();

        if (!$staffCug) {
            return response()->json([
                'status' => 404,
                'message' => 'CUG staff record not found',
                'error_msg' => 'CUG staff record not found',
                'data' => null
            ], 404);
        }

        DB::beginTransaction();
        try {
            $staffCug->app_version = $request->app_version;
            $staffCug->build_number = $request->build_number;
            
           
            $staffCug->save();

            DB::commit();

            

            return response()->json([
                'status' => 200,
                'message' => 'App version updated successfully',
                'error_msg' => null,
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }

    public function thisWeekCallBarChartCount(Request $request)
    {
        $user = $request->user();

         $staff = DB::table('egc_cug_numbers')
            ->join('egc_cug_assignments','egc_cug_assignments.cug_id','=','egc_cug_numbers.sno')
            ->join('egc_staff', 'egc_cug_assignments.staff_id', '=', 'egc_staff.sno')
            ->where('egc_cug_assignments.is_current', 1)
            ->where('egc_cug_assignments.status', 0)
            ->where('egc_cug_numbers.status', 1)
            ->where('egc_cug_assignments.sno', $user->cug_id)
            ->select('egc_cug_numbers.provider','egc_cug_numbers.cug_number','egc_cug_assignments.*','egc_staff.staff_name', 'egc_staff.status as staff_status','egc_staff.branch_id','egc_staff.entity_id')
            ->first();
       
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ],404);
        }

        $today = Carbon::today();
        $sunday = $today->copy()->startOfWeek(Carbon::SUNDAY);
        $saturday = $sunday->copy()->addDays(6);

        $data = [];
        for ($i = 0; $i < 7; $i++) {
            $date = $sunday->copy()->addDays($i);
            $dateString = $date->toDateString();
            $dayName = $date->format('l');

            $outgoingCallCount = DB::table('egc_call_tracker')
                ->where('staff_phone_no', $staff->cug_number)
                ->whereDate('call_start_date', $dateString)
                ->where('call_status', 0)
                ->where('call_duration', '!=', '00:00:00')
                ->count();

            $data[] = [
                'date' => $dateString,
                'day' => $dayName,
                'outgoing_call_count' => $outgoingCallCount,
            ];
        }

        return response()->json([
            'status' => 200,
            'message' => 'This week call bar chart data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

public function applicationAlive(Request $request)
    {
        $user = $request->user();
 
        $staff = StaffModel::where('sno', $user->user_id)->first();
 
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ], 404);
        }
 
        $validator = Validator::make($request->all(), [
            'is_alive' => 'required|integer|in:0,1',
        ]);
 
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }
 
        $staffCug = CugManagementModel::where('sno', $user->cug_id)->where('status', 0)->first();
 
        if (!$staffCug) {
            return response()->json([
                'status' => 404,
                'message' => 'CUG staff record not found',
                'error_msg' => 'CUG staff record not found',
                'data' => null
            ], 404);
        }
 
        DB::beginTransaction();
        try {
            $staffCug->live_status = $request->is_alive;
            $staffCug->last_checking = Carbon::now('Asia/Kolkata')->format('Y-m-d H:i:s');
            $staffCug->save();
 
            DB::commit();
 
            return response()->json([
                'status' => 200,
                'message' => 'Application status updated successfully',
                'error_msg' => null,
                'data' => [
                    'live_status' => $staffCug->live_status,
                    'last_checking' => $staffCug->last_checking,
                ]
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong',
                'error_msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }
    
}