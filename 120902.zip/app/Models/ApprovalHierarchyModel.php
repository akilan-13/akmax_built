<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApprovalHierarchyModel extends Model
{
    use HasFactory;

    protected $table = 'egc_approval_hierarchy';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'company_id',
        'entity_id',
        'department_id',
        'job_role_id',
        'approve_level',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];

     public function model()
    {
        return $this->belongsTo(AiModel::class, 'ai_model_id');
    }

}
