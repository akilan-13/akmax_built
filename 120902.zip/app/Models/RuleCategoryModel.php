<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RuleCategoryModel extends Model
{
    use HasFactory;
    public $table      = "egc_payroll_rules";
    public $primaryKey = 'id';


    protected $fillable = [
        'rule_name',
        'rule_code',
        'rule_category',
        'rule_expression',
        'effective_from',
        'effective_to',
        'priority_order',
        'is_active',
        'description',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}
