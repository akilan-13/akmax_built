<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollComponentModel extends Model
{
    use HasFactory;
    public $table      = "egc_pay_components";
    public $primaryKey = 'sno';


    protected $fillable = [
        'component_name',
        'component_code',
        'component_type',
        'is_taxable',
        'is_statutory',
        'is_prorated',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}