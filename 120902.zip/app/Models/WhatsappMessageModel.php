<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappMessageModel extends Model
{
    use HasFactory;
    
    public $table = "egc_wb_messages";
    public $primaryKey = "sno";
    
    protected $fillable = ['contact_id', 'message', 'type','reaction_emoji','reaction_status', 'from','wama_id','message_date_time','message_status','media_url','media_type','location','status','created_by','updated_by','media_caption','mime_type'];

    public function contact()
    {
        return $this->belongsTo(WhatsappContactModel::class, 'contact_id', 'sno');
    }
}
