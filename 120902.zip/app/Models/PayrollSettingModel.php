<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollSettingModel extends Model
{
    use HasFactory;
    public $table      = "egc_payroll_settings";
    public $primaryKey = 'sno';


    protected $fillable = [
        'setting_key',
        'setting_value',
        'description',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}