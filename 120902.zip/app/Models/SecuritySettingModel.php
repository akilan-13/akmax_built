<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecuritySettingModel extends Model
{
    protected $table = 'egc_security_settings';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'enable_qr_security',

        'enable_audit',

        'cleanup_days',

        'company_name',

        'timezone',

        'status'
    ];
}