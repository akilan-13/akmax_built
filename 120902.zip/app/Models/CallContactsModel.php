<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CallContactsModel extends Model
{
  use HasFactory;
  protected $table = 'egc_call_contacts'; // Table name
  protected $primaryKey = 'sno'; // Primary key
  protected $fillable = [
    'phone',
    'name',
    'staff_id',
    'outgoing_count',
    'incoming_count',
    'missed_count',
    'rejected_count',
    'dialed_count',
    'last_staff_id',
    'created_by',
    'updated_by',
    'status',
    'updated_at',
    'created_at'
  ];
}
