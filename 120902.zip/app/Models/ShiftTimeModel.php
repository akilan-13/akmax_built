<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShiftTimeModel extends Model
{
    use HasFactory;
    public $table      = "egc_shift_time";
    public $primaryKey = 'sno';


    protected $fillable = [
        'shift_name',
        'created_by',
        'updated_by',
        'status'
    ];

    public function days()
{
    return $this->hasMany(
        ShiftDayTimeModel::class,
        'shift_id',
        'sno'
    );
}
}