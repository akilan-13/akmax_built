<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecurityModuleSettingModel extends Model
{
    protected $table = 'egc_security_module_settings';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'module_id',

        'pin_length',

        'pin_expiry_seconds',

        'access_expiry_seconds',

        'qr_expiry_seconds',

        'max_attempts',

        'allow_multiple_devices',

        'allow_rescan',

        'require_login',

        'status'
    ];

    public function module()
    {
        return $this->belongsTo(
            SecurityModuleModel::class,
            'module_id',
            'sno'
        );
    }
}