<?php
 
namespace App\Models;
 
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
 
class OtpModel extends Model
{
    use HasFactory;
    public $table      = "egc_otp";
    public $primaryKey = 'sno';
 
    protected $fillable = [
        'user_id',
        'check',
        'mobile_no',
        'otp_number',
        'created_by',
        'updated_by',
        'status',
    ];
}