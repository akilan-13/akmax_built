<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupportTicketModel extends Model {
    use HasFactory;
    public $table      = 'egc_support_ticket';
    public $primaryKey = 'sno';

    protected $fillable = [
        'ticket_no',
        'staff_id',
        'staff_name',
        'department_id',
        'category_id',
        'subject',
        'description',
        'priority',
        'assigned_to',
        'assigned_at',
        'is_reopened',
        'reopened_count',
        'first_response_at',
        'resolved_at',
        'closed_at',
        'sla_response_hours',
        'sla_resolution_hours',
        'is_sla_breached',
        'staff_rating',
        'staff_feedback',
        'last_reply_by',
        'last_reply_at',
        'last_activity_at',
        'created_ip',
        'created_browser',
        'created_device',
        'status_flag',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];


    public function department()
{
    return $this->belongsTo(
        SupportDepartmentModel::class,
        'department_id',
        'sno'
    );
}

public function category()
{
    return $this->belongsTo(
        SupportCategoryModel::class,
        'category_id',
        'sno'
    );
}

public function assignedStaff()
{
    return $this->belongsTo(
        StaffModel::class,
        'assigned_to',
        'sno'
    );
}
}