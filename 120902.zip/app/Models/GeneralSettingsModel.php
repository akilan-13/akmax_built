<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeneralSettingsModel extends Model
{
    use HasFactory;
    public $table      = "egc_general_settings";
    public $primaryKey = 'sno';


    protected $fillable = [
        'title',
        'logo',
        'fav_icon',
        'url',
        'email_id',
        'phone_number',
        'whatsapp_number',
        'date_format',
        'registered_name',
        'tax_no',
        'language',
        'country',
        'state',
        'city',
        'currency_id',
        'address',
        'pincode',
        'currency_format',
        'created_by',
        'created_at',
        'max_document_send_limit',
        'hot_lead_days',
        'hot_lead_limit',
        'maintenance_chk',
        'updated_by',
        'updated_at',
        'call_tracker_branch_id',
        'min_product_cost',
        'cloud_call_api_key',
        'bank_ifsc',
        'bank_account_no',
        'bank_holder',
        'bank_branch',
        'bank_name',
        'social_media_details',
        'status',
    ];
}
