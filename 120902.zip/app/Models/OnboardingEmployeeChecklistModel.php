<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OnboardingEmployeeChecklistModel extends Model
{
    use HasFactory;
    public $table      = "egc_onboarding_employee_checklist";
    public $primaryKey = 'sno';


    protected $fillable = [
        'onboarding_employee_id',
        'checklist_id',
        'remarks',
        'verified_by',
        'verified_at',
        'department_id',
        'division_id',
        'job_role_id',
        'metrics_check',
        'metrics_ids',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}