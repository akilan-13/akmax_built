<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RuleCategoryModel extends Model
{
    use HasFactory;
    public $table      = "egc_rule_category";
    public $primaryKey = 'sno';


    protected $fillable = [
        'rule_category',
        'category_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}