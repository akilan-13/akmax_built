<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MonthTargetModel extends Model
{
    use HasFactory;
    public $table = 'egc_entity_month_targets';
    public $primaryKey = 'id';

    protected $fillable = [
        'quarter_id',
        'month',
        'target_amount',
        'pre_sale',
        'post_sale',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function quarter()
    {
        return $this->belongsTo(QuarterTargetModel::class, 'quarter_id');
    }

    public function weeks()
    {
        return $this->hasMany(WeekTargetModel::class, 'month_id');
    }
}
