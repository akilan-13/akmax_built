<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuildingDocumentModel extends Model
{
    use HasFactory;

    protected $table = 'egc_building_documents';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'building_id',
        'agreement_id',
        'document_name',
        'document_path',
        'document_type',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}