<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ITTicketLogModel extends Model
{
    use HasFactory;

    protected $table = 'egc_it_ticket_logs';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'ticket_id',
        'action',
        'message',
        'user_type',
        'created_by',
        'created_at',
        'updated_by',
        'status',
        'updated_at'
    ];

     

}
