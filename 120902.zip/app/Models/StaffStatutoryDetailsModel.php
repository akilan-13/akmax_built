<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffStatutoryDetailsModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_statutory_details';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'uan_no',
        'esi_no',
        'pan_no',
        'aadhar_no',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

}
