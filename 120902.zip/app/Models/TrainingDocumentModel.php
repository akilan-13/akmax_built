<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingDocumentModel extends Model
{
    use HasFactory;
    public $table      = "egc_training_document";
    public $primaryKey = 'sno';


    protected $fillable = [
        'branch_id',
        'training_id',
        'training_category_id',
        'training_sub_category_id',
        'traning_name',
        'traning_mode',
        'text_content',
        'video_link',
        'pdf_id',
        'dept_id',
        'role_ids',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
