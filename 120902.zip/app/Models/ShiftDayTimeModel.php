<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShiftDayTimeModel extends Model
{
    use HasFactory;
    public $table      = "egc_shift_day_times";
    public $primaryKey = 'sno';


    protected $fillable = [
        'shift_id',
        'day_name',
        'time_from',
        'time_to',
        'duration_minutes',
        'created_by',
        'updated_by',
        'status'
    ];
}