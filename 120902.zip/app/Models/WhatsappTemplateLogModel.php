<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhatsappTemplateLogModel extends Model
{
    use HasFactory;
    
    public $table = "egc_wb_template";
    public $primaryKey = "sno";
    
    protected $fillable = ['branch_id','unique_id','module_name','id_source','reaction_at','phone_no','template_name','payload', 'message', 'type','reaction_emoji','reaction_status', 'from','wama_id','message_date_time','delivered_date_time','read_date_time','failed_date_time','message_status','media_url','media_type','location','status','created_by','updated_by','media_caption','mime_type'];

    
}
