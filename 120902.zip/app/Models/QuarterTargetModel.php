<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuarterTargetModel extends Model
{
    use HasFactory;
    public $table = 'egc_entity_quarter_targets';
    public $primaryKey = 'id';

    protected $fillable = [
        'yearly_id',
        'quarter',
        'financial_year_id',
        'financial_year',
        'target_amount',
        'pre_sale',
        'post_sale',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];

    public function yearly()
    {
        return $this->belongsTo(YearlyTargetModel::class, 'yearly_id');
    }

    public function months()
    {
        return $this->hasMany(MonthTargetModel::class, 'quarter_id');
    }
}
