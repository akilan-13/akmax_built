<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingDocumentViewerModel extends Model
{
    use HasFactory;
    public $table      = "egc_training_document_viewers";
    public $primaryKey = 'sno';


    protected $fillable = [
        'training_document_id',
        'staff_id',
        'view_count',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
