<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffBankDetailsModel extends Model
{
    use HasFactory;

    protected $table = 'egc_staff_bank_details';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'bank_account_no',
        'bank_name',
        'bank_branch',
        'account_holder',
        'ifsc_code',
        'created_by',
        'updated_by',
        'updated_at',
        'created_at',
        'status',
    ];

}
