<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeavePermissionModel extends Model
{
    use HasFactory;

    protected $table = 'egc_leave_permission';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'staff_id',
        'request_type',
        'from_date',
        'to_date',
        'request_id',
        'from_time',
        'to_time',
        'leave_type',
        'reason_id',
        'total_days',
        'reason',
        'hr_reason',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];

}
