<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollStaffStructureDetailModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payroll_employee_structure_details';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'payroll_employee_structure_sno',
        'payroll_component_sno',
        'payroll_rule_sno',
        'component_type',
        'calculation_type',
        'calculated_on',
        'percentage_value',
        'fixed_amount',
        'calculated_amount',
        'monthly_variable',
        'include_in_gross',
        'include_in_ctc',
        'include_in_payslip',
        'display_order',
        'remarks',
        'status',
        'created_by',
        'updated_by',
    ];
}
