<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupportDepartmentModel extends Model {
    use HasFactory;
    public $table      = 'egc_support_department';
    public $primaryKey = 'sno';

    protected $fillable = [
        'department_code',
        'department_name',
        'phone',
        'email',
        'sla_response_hours',
        'sla_resolution_hours',
        'display_order',
        'color_code',
        'icon',
        'default_assignee_id',
        'department_head_id',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];


    public function department()
{
    return $this->belongsTo(
        SupportDepartmentModel::class,
        'department_id',
        'sno'
    );
}

public function category()
{
    return $this->belongsTo(
        SupportCategoryModel::class,
        'category_id',
        'sno'
    );
}

public function assignedStaff()
{
    return $this->belongsTo(
        StaffModel::class,
        'assigned_to',
        'sno'
    );
}
}