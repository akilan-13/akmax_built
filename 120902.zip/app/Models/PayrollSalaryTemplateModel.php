<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PayrollSalaryTemplateModel extends Model
{
    use HasFactory;

    protected $table = 'egc_payroll_salary_templates';

    protected $primaryKey = 'sno';

    public $timestamps = true;

    protected $fillable = [

        'template_name',
        'template_code',
        'gross_salary',
        'effective_from',
        'template_type',
        'description',
        'total_earnings',
        'total_deductions',
        'net_salary',
        'monthly_ctc',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [

        'gross_salary'      => 'float',
        'total_earnings'    => 'float',
        'total_deductions'  => 'float',
        'net_salary'        => 'float',
        'monthly_ctc'       => 'float',
        'effective_from'    => 'date',
    ];

    // =====================================================
    // RELATIONS
    // =====================================================

    public function details()
    {
        return $this->hasMany(
            PayrollSalaryTemplateDetailModel::class,
            'template_sno',
            'sno'
        );
    }
}
