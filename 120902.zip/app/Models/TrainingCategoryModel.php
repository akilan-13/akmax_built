<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainingCategoryModel extends Model
{
    use HasFactory;
    public $table = 'egc_training_category';
    public $primaryKey = 'sno';

    protected $fillable = [
        'category_name',
        'category_desc',
        'created_by',
        'updated_by',
        'updated_at',
        'created_at',
        'status',
    ];
}
