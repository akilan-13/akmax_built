<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyBankModel extends Model
{
    use HasFactory;
    public $table      = "egc_company_bank_accounts";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'company_id',
        'bank_name',
        'account_holder',
        'account_number',
        'bank_branch',
        'ifsc_code',
        'created_by',
        'updated_by',
        'updated_at',
        'status',
    ];
}