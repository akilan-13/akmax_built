<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffModel extends Model
{
  use HasFactory;

  protected $table = 'egc_staff';
  protected $primaryKey = 'sno';
  public $timestamps = true;
  protected $appends = ['profile_image_url'];

  protected $fillable = [
    'staff_id',
    'erp_staff_id',
    'timechamp_id',
    'company_type',
    'company_id',
    'entity_id',
    'branch_id',
    'department_id',
    'division_id',
    'role_id',
    'exp_type',
    'total_experience',
    'total_company_shift',
    'staff_name',
    'mobile_no',
    'is_Course',
    'applied_company_ids',
    'course_tag',
    'alternative_no',
    'email_id',
    'gender',
    'dob',
    'discount',
    'coupon_code',
    'login_access',
    'date_of_joining',
    'contact_person_name',
    'contact_person_no',
    'martial_status',
    'address',
    'residential_address',
    'location_url',
    'latitude',
    'longitude',
    'completion_percentage',
    'staff_image',
    'source_details',
    'source_id',
    'user_name',
    'attachment',
    'knowledge_tag',
    'nick_name',
    'applied_position',
    'password',
    'credential',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
    'shift_time_id',
    'basic_salary',
    'per_hour_cost',
    'dep_reason',
    'notice_end_date',
    'contact_person_relation',
    'notice_start_date',
    'welcome_status',
    'staff_last_date',
    'social_media_details',
    'application_details',
    'mother_tongue',
    'document_checklist',
    'job_role_id',
    'languages',
    'hobby',
    'casual_leave_count_per_month',
    'per_day_salary',
    'is_payslip',
    'is_multiple_account',
    'salary_bank_id',
    'salary_company_id',
    'salary_date',
    'salary_type',
    'transfer_status',
    'face_id',
    'birth_place',
    'blood_group',
    'height',
    'weight',
    'nationality_id',
    'religion_id',
    'community_id',
    'caste_id',
    'identification_mark',
    'license_expiry',
    'driving_license_no',
    'vehicle_check',
    'vehicle_register_no',
    'step_progress',
  ];

  public function getProfileImageUrlAttribute()
  {
    if ($this->staff_image) {

      if ($this->company_type == 1) {
        return asset('staff_images/Management/' . $this->staff_image);
      } else {
        return asset(
          'staff_images/Buisness/' .
            $this->company_id . '/' .
            $this->entity_id . '/' .
            $this->staff_image
        );
      }
    }
    return asset('assets/staff_images/member.png');
  }
  public function salaryAccounts()
{
    return $this->hasMany(
        StaffSalaryAccountModel::class,
        'staff_id',
        'sno'
    );
}
}
