<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LessorModel extends Model
{
    protected $table = 'egc_lessor';

    protected $primaryKey = 'sno';

    protected $fillable = [

        'lessor_code',

        'lessor_name',

        'contact_person',

        'mobile_no',

        'alternate_mobile_no',

        'email',

        'gst_no',

        'pan_no',

        'door_no',

        'street',

        'area',

        'city',

        'state',

        'country',

        'pincode',

        'bank_name',

        'account_holder_name',

        'account_number',

        'ifsc_code',

        'branch_name',

        'remarks',

        'status',

        'created_by',

        'updated_by'

    ];

    protected $casts = [

        'status' => 'boolean',

    ];

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */

    public function buildings()
    {
        return $this->hasMany(
            Building::class,
            'lessor_id',
            'sno'
        );
    }
}