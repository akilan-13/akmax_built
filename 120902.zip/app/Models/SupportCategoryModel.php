<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupportCategoryModel extends Model {
    use HasFactory;
    public $table      = 'egc_support_category';
    public $primaryKey = 'sno';

    protected $fillable = [
        'department_id',
        'category_code',
        'category_name',
        'description',
        'display_order',
        'allow_attachment',
        'is_approval_required',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];


    public function department()
{
    return $this->belongsTo(
        SupportDepartmentModel::class,
        'department_id',
        'sno'
    );
}

public function category()
{
    return $this->belongsTo(
        SupportCategoryModel::class,
        'category_id',
        'sno'
    );
}

public function assignedStaff()
{
    return $this->belongsTo(
        StaffModel::class,
        'assigned_to',
        'sno'
    );
}
}