<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BloodGroupModel extends Model {
    use HasFactory;
    public $table      = 'egc_blood_group';
    public $primaryKey = 'sno';

    protected $fillable = [
        'blood_group',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}