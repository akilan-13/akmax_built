<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveReasonModel extends Model {
    use HasFactory;
    public $table      = 'egc_leave_reason';
    public $primaryKey = 'sno';

    protected $fillable = [
        'reason_name',
        'description',
        'comments_check',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}