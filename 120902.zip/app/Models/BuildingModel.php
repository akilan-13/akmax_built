<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BuildingModel extends Model
{
    use HasFactory;

    protected $table = 'egc_buildings';

    protected $primaryKey = 'sno';

    protected $fillable = [
        'building_code',
        'building_name',
        'location_id',
        'lessor_id',
        'ownership_type',
        'door_no',
        'street',
        'landmark',
        'google_map_link',
        'address',
        'total_floors',
        'builtup_area',
        'builtup_area_unit',
        'latitude',
        'longitude',
        'remarks',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}