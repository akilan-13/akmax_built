<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ManageExamModel extends Model
{
    use HasFactory;
    public $table      = 'egc_manage_exam';
    public $primaryKey = 'sno';
    protected $fillable = [
        'sno',
        'branch_id',
        'exam_name',
        'level_id',
        'role_id',
        'bank_id',
        'schedule_id',
        'question_count',
        'duration',
        'positive_mark',
        'negative_mark',
        'exam_attempt',
        'question_generate',
        'pass_mark',
        'attempts',
        'badge_check',
        'tips_check',
        'explanation_check',
        'case_study_check',
        'badge',
        'description',
        'question_ids',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status'
    ];
}
