<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecurityAccessModel extends Model
{
    protected $table = 'egc_security_access';

    protected $primaryKey = 'sno';

    public $timestamps = false;

    protected $fillable = [

        'session_id',

        'staff_id',

        'module_id',

        'record_id',

        'expires_at',

        'status'
    ];

    protected $casts = [

        'expires_at' => 'datetime'
    ];

    public function session()
    {
        return $this->belongsTo(
            SecuritySessionModel::class,
            'session_id',
            'sno'
        );
    }
}