<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffAttendanceModel extends Model
{
    use HasFactory;
    public $table      = "egc_staff_attendance";
    public $primaryKey = 'sno';


    protected $fillable = [
        'staff_attendance_id',
        'branch_id',
        'date',
        'staff_id',
        'attendance',
        'time_start',
        'time_end',
        'in_time',
        'out_time',
        'type',
        'reason',
        'reason_id',
        'leave_type',
        'created_by',
        'updated_by',
        'status',
        'check_in_longitude',
        'check_in_latitude',
        'check_in_time',
        'checkin_verified',
        'check_out_logitude',
        'check_out_latitude',
        'check_out_time',
        'checkout_verified',
        'paid_leave',
    ];
}
