<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NewPayrollComponentModel extends Model
{
    use HasFactory;
    public $table      = "egc_payroll_components";
    public $primaryKey = 'sno';


    protected $fillable = [
        'component_name',
        'component_code',
        'category',
        'component_type',
        'affects_pf',
        'affects_esi',
        'affects_pt',
        'affects_tds',
        'prorate_on_lop',
        'taxable',
        'display_order',
        'effective_from',
        'effective_to',
        'priority',
        'default_value',
        'calculation_type',
        'percentage_value',
        'lop_applicable',
        'variable_component',
        'include_in_ctc',
        'percentage_of_component',
        'formula_expression',
        'rule_id',
        'is_mandatory',
        'is_statutory',
        'include_in_payslip',
        'pf_applicable',
        'esi_applicable',
        'pt_applicable',
        'tds_applicable',
        'display_order',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}
