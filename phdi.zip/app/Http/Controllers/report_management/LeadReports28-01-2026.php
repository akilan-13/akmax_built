<?php

namespace App\Http\Controllers\report_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\StaffModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use DateTime;

class LeadReports extends Controller
{
    public static $report_heading = 'Analysis';
    public function index()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        $days = range(1,31);
        $year = date('Y');
        $yearShort = date('y');

        return view('content.report_management.lead_report.total_lead_list', compact(
            'months',
            'days',
            'yearShort'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetLeadConversionDetails($branch_id);

            // return $result;

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            
            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $increment_data  = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($days as $day) {

                    $date_format = sprintf('%02d-%02d-%d', $day, $monthNum, $year);
                    
                    $paymentSums = isset($result) && !empty($result) ? $result : [];
                    $monthly_data = isset($monthlyData) && !empty($monthlyData) ? $monthlyData : [];

                    foreach ($types_list as $type_key => $type_name) {

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $amount = isset($dailyData[$year][$monthNum][$day][$type_key]) ? round($dailyData[$year][$monthNum][$day][$type_key]) : 0;
                        } else {
                            $amount = 0;
                        }

                        if (strtotime($date_format) <= strtotime($currentDate)) {
                            $incre_amount = isset($dailyData[$year][$monthNum][$day]['increment_'.$type_key]) ? round($dailyData[$year][$monthNum][$day]['increment_'.$type_key]) : 0;
                        } else {
                            $incre_amount = 0;
                        }

                        $pre_amount = isset($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) ? round($dailyData[$pre_year][12][$pre_daysInMonth][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$day][$type_key] = $amount;

                        $increment_data[$monthNum][$day][$type_key] = $incre_amount;

                        $pre_data[12][$pre_daysInMonth][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + ($totals[$monthNum][$type_key] ?? 0);

                        $percentages[$monthNum] = ($monthly_data[$year][$monthNum]['conversion_percentage'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$day] = ($typeDayTotals[$type_key][$day] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'increment_data' => $increment_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function yearly_lead()
    {
        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        return view('content.report_management.lead_report.total_lead_yearly_list', compact(
            'months'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $result = $this->GetLeadConversionDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($months as $monthNum => $monthName) {

                        $date_format = sprintf('%02d-%d', $monthNum, $year);
                        
                        $paymentSums = isset($result) && !empty($result) ? $result : [];

                        $monthly_data = !empty($yearlyData) ? $yearlyData : [];

                        foreach ($types_list as $type_key => $type_name) {

                            if (strtotime($date_format) <= strtotime($currentDate)) {
                                $amount = isset($monthlyData[$year][$monthNum][$type_key]) ? $monthlyData[$year][$monthNum][$type_key] : 0;
                            } else {
                                $amount = 0;
                            }

                            // Save raw monthly data
                            $data[$year][$monthNum][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($monthly_data[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = 0;

                                // Day totals across months
                                $typeDayTotals[$type_key][$monthNum] = ($typeDayTotals[$type_key][$monthNum] ?? 0) + $amount;

                                $percentages[$year] = ($monthly_data[$year]['conversion_percentage'] ?? 0);

                                $typeMonthTotals[$type_key][$year] = ($monthly_data[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function lead_src_month()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

        $months = $this->getYearBasedMonths($currentYear);

        $days = range(1, $daysInMonth);

        return view('content.report_management.lead_report.total_lead_src_list', compact(
            'days','currentMonth', 'currentYear','months'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsSourceData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetLeadSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            $lead_source_list = collect($lead_source_list)->mapWithKeys(function ($value, $key) {return [(string)$key => $value];})->sort(function ($a, $b) {
                return strcasecmp($a, $b);
            })->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);
        
            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                foreach ($days as $day) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $dailyData[$lead_source_id][$year][$Month][$day][$type_key] ?? 0;

                        $data[$lead_source_id][$day][$type_key] = $amount;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }

                        $pre_count = $dailyData[$lead_source_id][$prevYear][$prevMonth][$prevDay][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevDay][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        $percentages[$lead_source_id] =
                            $monthlyData[$lead_source_id][$year][$Month]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }

    }

    public function yearly_lead_src()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);
        
        return view('content.report_management.lead_report.total_lead_src_yearly_list', compact(
            'months',
            'short_months',
            'currentMonth',
            'currentYear'
        ))->with('report_heading', self::$report_heading);
    }

    public function getLeadsSourceYearData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate  = date('m-Y');

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? '';

            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = date('Y-01-01');
            }

            $year       = date('Y', strtotime($filterDate));
            $yearShort  = date('y', strtotime($filterDate));
            $Month      = date('n', strtotime($filterDate));

            $months       = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();
            $branch_id = $user->branch_id;

            // ================================
            //  🔥 GET LEAD SOURCE DATA
            // ================================
            $result = $this->GetLeadSourceDetails($branch_id, $search_lead_src_fill);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData        = $result['daily'] ?? [];
            $monthlyData      = $result['monthly'] ?? [];
            $yearlyData       = $result['yearly'] ?? [];
            $lead_source_list = $result['lead_source_list'] ?? [];

            // ================================
            //  🔥 SORT LEAD SOURCE LIST BY NAME (A → Z)
            //  AND KEEP KEYS AS STRINGS
            // ================================
            // $lead_source_list = collect($lead_source_list)
            //     ->mapWithKeys(fn($value, $key) => [(string)$key => $value])
            //     ->sort(function ($a, $b) {
            //         return strcasecmp($a, $b);
            //     })
            //     ->toArray();

            $lead_source_list = collect($lead_source_list)
                ->mapWithKeys(function ($value, $key) {return [(string)$key => $value];})
                ->sort(function ($a, $b) {
                    return strcasecmp($a, $b);
                })
                ->toArray();

            // ================================
            //  TYPE LIST
            // ================================
            $types_list = [
                'lead_count'       => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys  = array_keys($types_list);
            $type_count = count($types_list);

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = [];
            $grandTotals     = [];
            $typeDayTotals   = [];
            $percentages     = [];
            $grandTypeTotals = [];
            $typeMonthTotals = [];

            $pre_year = $year - 1;

            // ================================
            //  🔥 MAIN LOOP (All Lead Sources)
            // ================================
            foreach ($lead_source_list as $lead_source_id => $lead_source_name) {

                foreach ($months as $monthNum => $monthName) {

                    $Trend_data_list = [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = $monthlyData[$lead_source_id][$year][$monthNum][$type_key] ?? 0;

                        $data[$lead_source_id][$monthNum][$type_key] = $amount;

                        // Previous Month / Year logic
                        if ($monthNum == 1) {
                            $prevYear  = $year - 1;
                            $prevMonth = 12;
                        } else if ($monthNum != 1) {
                            $prevYear  = $year;
                            $prevMonth = $monthNum - 1;
                        }

                        $pre_count = $monthlyData[$lead_source_id][$prevYear][$prevMonth][$type_key] ?? 0;
                        $pre_data[$lead_source_id][$prevMonth][$type_key] = $pre_count;

                        $Trend_data_list[$type_key] = $amount;

                        // Totals
                        $totals[$lead_source_id][$type_key] =
                            ($totals[$lead_source_id][$type_key] ?? 0) + $amount;

                        // Conversion %
                        $percentages[$lead_source_id] =
                            $yearlyData[$lead_source_id][$year]['conversion_percentage'] ?? 0;

                        // Month totals by type
                        $typeMonthTotals[$type_key][$lead_source_id] =
                            ($typeMonthTotals[$type_key][$lead_source_id] ?? 0) + $amount;

                        // Grand totals by type
                        $grandTypeTotals[$type_key] =
                            ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$lead_source_id][] = $Trend_data_list;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($lead_source_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'currentYear' => $currentYear,
                'year' => $year,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'leadTypes' => $lead_source_list,   // ← SORTED OUTPUT
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'percentages' => $percentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors,
            ]);

        } catch (\Exception $e) {

            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function yearly_lead_sales()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.lead_report.sales_lead_yearly_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function getSalesYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = isset($request->is_existing_val) ? (int)$request->is_existing_val : 2;

            // Validate year
            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = (int) date('Y', strtotime($filterDate));
            $yearShort = (int) date('y', strtotime($filterDate));
            $querycurrentMonth = (int) date('m', strtotime($filterDate));
            $Month = (int) date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPostSaleDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name alphabetically
            // uasort($leadTypesMapped, function ($a, $b) {
            //     return strcmp($a['staff_name'], $b['staff_name']);
            // });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                $exist_status = isset($leadType['exist_status']) ? $leadType['exist_status'] : false;
                $exist_date = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : '';
                $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                // ---------- Exit Staff Tracking ----------
                if ($exist_status) {
                    $exist_y = (int) date('Y', strtotime($exist_date));
                    $exist_m = (int) date('n', strtotime($exist_date));

                    while ($exist_m <= (int)$currentMonth) {
                        $exit_staff_details[$exist_y][$exist_m][$lead_type_id] = [
                            'exist_status' => true,
                            'exist_date' => null
                        ];
                        $exist_m++;
                    }

                    $exit_status_staffs[$lead_type_id] = $exist_status;
                }

                // ---------- Month Loop ----------
                foreach ($months as $monthNum => $monthName) {

                    $paymentSums = $monthlyData[$lead_type_id] ?? [];
                    $count = $paymentSums[$year][$monthNum]['conversion_count'] ?? 0;

                    $leadData[$monthNum][$lead_type_id] = $count;
                    $sourceTotals[$lead_type_id] = $yearlyData[$lead_type_id][$year]['conversion_count'] ?? 0;
                    $monthTotals[$monthNum] = ($monthTotals[$monthNum] ?? 0) + $count;

                    // Previous month calc
                    if ((int)$monthNum === 1) {
                        $prevYear = $year - 1;
                        $prevMonth = 12;
                    } else {
                        $prevYear = $year;
                        $prevMonth = (int)$monthNum - 1;
                    }

                    $pre_count = $paymentSums[$prevYear][$prevMonth]['conversion_count'] ?? 0;
                    $preleadData[$prevMonth][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {
                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === $year) {
                            if ($monthNum >= $doj_m) {
                                $doj_status = true;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        if ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        if ($doj_y > $year) {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$year][$monthNum][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];
                }

                $grandTotalAll += (int) ($sourceTotals[$lead_type_id] ?? 0);
            }

            // ---------- Prepare monthly trends for JS chart ----------
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    $trend[] = $leadData[$monthNum][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => $currentMonth,
                'currentYear' => $currentYear,
                'currentDay' => (int) date('j'),
                'Month' => $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => $year,
                'yearShort' => $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function sales_lead_month()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.lead_report.sales_lead_list', compact(
           'months','days'
        ))->with('report_heading', self::$report_heading);
    }

    public function getSalesMonthlyData(Request $request)
    {
        try {
            
            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPostSaleDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($days as $day) {

                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                    // ---------- Exit Staff Tracking ----------
                    $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                    $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                    if ($exist_status && $exist_date) {

                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));
                        $exist_d = (int) date('j', strtotime($exist_date));

                        // If exit is before selected month/year → mark as inactive
                        if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
                            $exist_status = false;
                        }
                        // If same month but exited before current day → inactive for remaining days
                        elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
                            $exist_status = false;
                        }

                        $exit_staff_details[$day][$lead_type_id] = [
                            'exist_status' => $exist_status,
                            'exist_date'   => $exist_date
                        ];

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }
                    
                    $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                    $count = isset($paymentSums[$year][$Month][$day]['conversion_count']) ? $paymentSums[$year][$Month][$day]['conversion_count'] : 0;
                    // $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;
                    
                    // $count = rand(5, 50); // Replace with DB query
                    $leadData[$day][$lead_type_id] = $count;
                    // $percentages[$lead_type_id][$monthNum] = $earned_per;
                    
                    $sourceTotals[$lead_type_id] = ($sourceTotals[$lead_type_id] ?? 0) + $count;

                    $dayTotals[$day] = ($dayTotals[$day] ?? 0) + $count;

                    $prevMonth = 0;
                    $prevYear = 0;
                    $prevDay = 0;

                    if ((int)$Month == 1 && $day == 1) {
                        $prevYear = (int)$year - 1;
                        $prevMonth = 12;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }else if($day == 1){
                        $prevYear = (int)$year;
                        $prevMonth = (int)$Month - 1;
                        $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                    }
                    
                    $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay]['conversion_count']) ? $paymentSums[$prevYear][$prevMonth][$prevDay]['conversion_count'] : 0;

                    $preleadData[$prevDay][$lead_type_id] = $pre_count;

                    // ---------- DOJ (Date of Joining) Logic ----------
                    $doj_status = false;

                    if ($doj) {

                        $doj_y = (int) date('Y', strtotime($doj));
                        $doj_m = (int) date('n', strtotime($doj));
                        $doj_d = (int) date('j', strtotime($doj));

                        // Case 1: DOJ is this year
                        if ($doj_y === (int)$year) {

                            // Same month
                            if ((int)$Month === $doj_m) {
                                if ($day >= $doj_d) {
                                    $doj_status = true;
                                }
                            }

                            // Month after DOJ month (still same year)
                            elseif ((int)$Month > $doj_m) {
                                $doj_status = true;
                            }

                            // Month before DOJ month → false
                            else {
                                $doj_status = false;
                            }
                        }

                        // Case 2: DOJ is before this year → always true
                        elseif ($doj_y < $year) {
                            $doj_status = true;
                        }

                        // Case 3: DOJ is after this year → always false
                        else {
                            $doj_status = false;
                        }
                    }

                    $exit_staff_doj_details[$day][$lead_type_id] = [
                        'doj_status' => $doj_status,
                    ];

                    // $dayTotals[$day] = $dayTotal;
                }
                
                
                $grandTotalAll += $dayTotal;
                
                // Calculate percentages
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    $trend[] = $leadData[$day][$lead_type_id] ?? 0;
                }
                $sourceTrends[$lead_type_id] = $trend;
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'staff_details' => $leadTypesMapped,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function yearly_lead_sales_pre()
    {
        $currentMonth = date('n'); // 1-12
        $currentYear = date('Y');

        $months = $this->getYearBasedMonths($currentYear);
        $short_months = $this->getYearBasedMonths($currentYear,2);

        return view('content.report_management.lead_report.sales_lead_pre_yearly_list', compact(
            'months','short_months'
        ))->with('report_heading', self::$report_heading);
    }

    public function getSalesPreYearlyData(Request $request)
    {
        try {

            $selected_year = $request->year;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = isset($request->is_existing_val) ? (int)$request->is_existing_val : 2;

            // Validate year
            if ($request->filled('year') && preg_match('/^\d{4}$/', $selected_year)) {
                $filterDate = $selected_year . '-01-01';
            } else {
                $filterDate = now()->format('Y-01-01');
            }

            $year = (int) date('Y', strtotime($filterDate));
            $yearShort = (int) date('y', strtotime($filterDate));
            $querycurrentMonth = (int) date('m', strtotime($filterDate));
            $Month = (int) date('n', strtotime($filterDate));

            $months = $this->getYearBasedMonths($year);
            $short_months = $this->getYearBasedMonths($year, 2);

            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPreSaleDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');

            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayNames = [];
            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];
            $grandTotalAll = 0;

            $days = range(1, 31);

            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {

                foreach ($types_list as $type_key => $type_name) {

                    $exist_status = isset($leadType['exist_status']) ? $leadType['exist_status'] : false;
                    $exist_date = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : '';
                    $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                    // ---------- Exit Staff Tracking ----------
                    if ($exist_status) {
                        $exist_y = (int) date('Y', strtotime($exist_date));
                        $exist_m = (int) date('n', strtotime($exist_date));

                        while ($exist_m <= (int)$currentMonth) {
                            $exit_staff_details[$exist_y][$exist_m][$lead_type_id][$type_key] = [
                                'exist_status' => true,
                                'exist_date' => null
                            ];
                            $exist_m++;
                        }

                        $exit_status_staffs[$lead_type_id] = $exist_status;
                    }

                    // ---------- Month Loop ----------
                    foreach ($months as $monthNum => $monthName) {

                        $paymentSums = $monthlyData[$lead_type_id] ?? [];
                        $count = $paymentSums[$year][$monthNum][$type_key] ?? 0;

                        $leadData[$monthNum][$lead_type_id][$type_key] = $count;
                        $sourceTotals[$lead_type_id][$type_key] = ($sourceTotals[$lead_type_id][$type_key] ?? 0) + $count;
                        $monthTotals[$monthNum][$type_key] = ($monthTotals[$monthNum][$type_key] ?? 0) + $count;
                        $typeMonthTotals[$type_key][$lead_type_id] = ($typeMonthTotals[$type_key][$lead_type_id] ?? 0) + $count;
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $count;

                        // Previous month calc
                        if ((int)$monthNum === 1) {
                            $prevYear = $year - 1;
                            $prevMonth = 12;
                        } else {
                            $prevYear = $year;
                            $prevMonth = (int)$monthNum - 1;
                        }

                        $pre_count = $paymentSums[$prevYear][$prevMonth][$type_key] ?? 0;
                        $preleadData[$prevMonth][$lead_type_id][$type_key] = $pre_count;

                        // ---------- DOJ (Date of Joining) Logic ----------
                        $doj_status = false;

                        if ($doj) {

                            $doj_y = (int) date('Y', strtotime($doj));
                            $doj_m = (int) date('n', strtotime($doj));

                            // Case 1: DOJ is this year
                            if ($doj_y === $year) {
                                if ($monthNum >= $doj_m) {
                                    $doj_status = true;
                                }
                            }else if ($doj_y < $year) {
                                $doj_status = true;
                            }else if ($doj_y > $year) {
                                $doj_status = false;
                            }
                        }

                        $exit_staff_doj_details[$year][$monthNum][$lead_type_id][$type_key] = [
                            'doj_status' => $doj_status,
                        ];
                    }

                    // $grandTotalAll += (int) ($sourceTotals[$lead_type_id][$type_key] ?? 0);
                }
            }

            // ---------- Prepare monthly trends for JS chart ----------
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($months as $monthNum => $monthName) {
                    foreach ($types_list as $type_key => $type_name) {
                        $trend[$type_key] = $leadData[$monthNum][$lead_type_id][$type_key] ?? 0;
                    }
                    $sourceTrends[$lead_type_id][] = $trend;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors)
                ? array_values($line_MonthColors)
                : [];

            return response()->json([
                'days' => $days,
                'months' => $months,
                'short_months' => $short_months,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'staff_details' => $leadTypesMapped,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'sourceTotals' => $sourceTotals,
                'monthTotals' => $monthTotals,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => $currentMonth,
                'currentYear' => $currentYear,
                'currentDay' => (int) date('j'),
                'Month' => $Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => $year,
                'yearShort' => $yearShort,
                'line_MonthColors' => $line_MonthColors,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'type_count' => $type_count,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTypeTotals' => $grandTypeTotals,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function sales_lead_pre_month()
    {
        $days = range(1, 31);

        $months = [
            1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
            7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
        ];

        return view('content.report_management.lead_report.sales_lead_pre_list', compact(
           'months','days'
        ))->with('report_heading', self::$report_heading);
    }

    public function getSalesPreMonthlyData(Request $request)
    {
        try {
            
            $selected_year = $request->year;
            $selected_month = $request->month;
            $search_lead_src_fill = $request->search_lead_src_fill ?? null;
            $is_existing_val = (int)$request->is_existing_val ?? 2;

            if (
                $request->filled('year') && preg_match('/^\d{4}$/', $selected_year) &&
                $request->filled('month') && preg_match('/^(0?[1-9]|1[0-2])$/', $selected_month)
            ) {
                $monthFormatted = str_pad($selected_month, 2, '0', STR_PAD_LEFT);
                $filterDate = $selected_year . '-' . $monthFormatted . '-01';
            } else {
                $filterDate = now()->format('Y-m-01');
            }

            $year = date('Y', strtotime($filterDate));
            $yearShort = date('y', strtotime($filterDate));
            $querycurrentMonth = date('m', strtotime($filterDate));
            $Month = date('n', strtotime($filterDate));
            $today = date('d');
            $today_month = date('n');
            $today_year = date('Y');

            $user = $request->user(); // Fetch user details only once
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetPreSaleDetails($branch_id, $search_lead_src_fill, $is_existing_val, $year);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            // return $result;

            $currentDate  = date('Y-m-d');
            $currentYear  = (int) date('Y');
            $currentMonth = (int) date('n');
            
            $leadTypesMapped = isset($result['staff_details']) && !empty($result['staff_details']) ? $result['staff_details'] : [];

            // Sort by staff_name
            uasort($leadTypesMapped, function($a, $b) {
                return strcmp($a['staff_name'], $b['staff_name']);
            });

            $leadTypesMapped = array_filter($leadTypesMapped, function ($staff) use ($year, $Month) {

                $keep = true;

                // --- DOJ (Date of Joining) filter ---
                if (!empty($staff['doj'])) {

                    $dojDate  = strtotime($staff['doj']);
                    $dojYear  = (int) date('Y', $dojDate);
                    $dojMonth = (int) date('n', $dojDate);

                    // Exclude staff who joined after the selected year-month
                    if ($dojYear > (int)$year || ($dojYear === (int)$year && $dojMonth > (int)$Month)) {
                        $keep = false;
                    }
                }

                // --- Exit filter ---
                if ($staff['exist_status'] && !empty($staff['exist_date'])) {

                    $exitDate  = strtotime($staff['exist_date']);
                    $exitYear  = (int) date('Y', $exitDate);
                    $exitMonth = (int) date('n', $exitDate);

                    // Exclude staff whose exit date is before the selected year-month
                    if ($exitYear < (int)$year || ($exitYear === (int)$year && $exitMonth < (int)$Month)) {
                        $keep = false;
                    }
                }

                return $keep;
            });

            $leadTypes_list = isset($leadTypesMapped) && !empty($leadTypesMapped) ? array_keys($leadTypesMapped) : [];

            $currentMonth = date('n');
            $currentYear = date('Y');
            $currentDay = date('j');

            $leadData = [];
            $preleadData = [];
            $percentages = [];
            $sourceTotals = [];
            $monthTotals = [];
            $dayLabels = [];
            $dayTotals = [];
            $dayNames = [];
            $grandTotalAll = 0;

            $exit_staff_details = [];
            $exit_staff_doj_details = [];
            $exit_status_staffs = [];

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $Month, $year);

            if($today_year == $year && $today_month == $Month){
                $daysInMonth = (int)$today;
            }
            
            $days = range(1, $daysInMonth);

            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $lastMonth = ($year == $currentYear) ? $currentMonth : max(array_keys($months));

            // return $leadTypesMapped;

            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                
                $dayTotal = 0;

                foreach ($types_list as $type_key => $type_name) {

                    foreach ($days as $day) {

                        $doj = !empty($leadType['doj']) ? date('Y-m-d', strtotime($leadType['doj'])) : null;

                        // ---------- Exit Staff Tracking ----------
                        $exist_status = isset($leadType['exist_status']) ? (bool)$leadType['exist_status'] : false;
                        $exist_date   = !empty($leadType['exist_date']) ? date('Y-m-d', strtotime($leadType['exist_date'])) : null;

                        if ($exist_status && $exist_date) {

                            $exist_y = (int) date('Y', strtotime($exist_date));
                            $exist_m = (int) date('n', strtotime($exist_date));
                            $exist_d = (int) date('j', strtotime($exist_date));

                            // If exit is before selected month/year → mark as inactive
                            if ($exist_y > (int)$year || ($exist_y === (int)$year && $exist_m > (int)$Month)) {
                                $exist_status = false;
                            }
                            // If same month but exited before current day → inactive for remaining days
                            elseif ($exist_y === (int)$year && $exist_m === (int)$Month && $exist_d > (int)$day) {
                                $exist_status = false;
                            }

                            $exit_staff_details[$day][$lead_type_id][$type_key] = [
                                'exist_status' => $exist_status,
                                'exist_date'   => $exist_date
                            ];

                            $exit_status_staffs[$lead_type_id][$type_key] = $exist_status;
                        }
                        
                        $paymentSums = isset($result['daily'][$lead_type_id]) && !empty($result['daily'][$lead_type_id]) ? $result['daily'][$lead_type_id] : [];

                        $count = isset($paymentSums[$year][$Month][$day][$type_key]) ? $paymentSums[$year][$Month][$day][$type_key] : 0;
                        // $earned_per = isset($paymentSums[$year][$monthNum]['earned_per']) ? $paymentSums[$year][$monthNum]['earned_per'] : 0;
                        
                        // $count = rand(5, 50); // Replace with DB query
                        $leadData[$day][$lead_type_id][$type_key] = $count;
                        // $percentages[$lead_type_id][$monthNum] = $earned_per;
                        
                        $sourceTotals[$lead_type_id][$type_key] = ($sourceTotals[$lead_type_id][$type_key] ?? 0) + $count;

                        $dayTotals[$day][$type_key] = ($dayTotals[$day][$type_key] ?? 0) + $count;

                        $typeMonthTotals[$type_key][$lead_type_id] = ($typeMonthTotals[$type_key][$lead_type_id] ?? 0) + $count;
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $count;

                        $prevMonth = 0;
                        $prevYear = 0;
                        $prevDay = 0;

                        if ((int)$Month == 1 && $day == 1) {
                            $prevYear = (int)$year - 1;
                            $prevMonth = 12;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }else if($day == 1){
                            $prevYear = (int)$year;
                            $prevMonth = (int)$Month - 1;
                            $prevDay = cal_days_in_month(CAL_GREGORIAN, $prevMonth, $prevYear);
                        }
                        
                        $pre_count = isset($paymentSums[$prevYear][$prevMonth][$prevDay][$type_key]) ? $paymentSums[$prevYear][$prevMonth][$prevDay][$type_key] : 0;

                        $preleadData[$prevDay][$lead_type_id][$type_key] = $pre_count;

                        // ---------- DOJ (Date of Joining) Logic ----------
                        $doj_status = false;

                        if ($doj) {

                            $doj_y = (int) date('Y', strtotime($doj));
                            $doj_m = (int) date('n', strtotime($doj));
                            $doj_d = (int) date('j', strtotime($doj));

                            // Case 1: DOJ is this year
                            if ($doj_y === (int)$year) {

                                // Same month
                                if ((int)$Month === $doj_m) {
                                    if ($day >= $doj_d) {
                                        $doj_status = true;
                                    }
                                }

                                // Month after DOJ month (still same year)
                                elseif ((int)$Month > $doj_m) {
                                    $doj_status = true;
                                }

                                // Month before DOJ month → false
                                else {
                                    $doj_status = false;
                                }
                            }

                            // Case 2: DOJ is before this year → always true
                            elseif ($doj_y < $year) {
                                $doj_status = true;
                            }

                            // Case 3: DOJ is after this year → always false
                            else {
                                $doj_status = false;
                            }
                        }

                        $exit_staff_doj_details[$day][$lead_type_id][$type_key] = [
                            'doj_status' => $doj_status,
                        ];

                        // $dayTotals[$day] = $dayTotal;
                    }
                    
                    
                    // $grandTotalAll += $dayTotal;
                }
            }
            
            // Prepare source-wise day trends for JS
            $sourceTrends = [];
            foreach ($leadTypesMapped as $lead_type_id => $leadType) {
                $trend = [];
                foreach ($days as $day) {
                    foreach ($types_list as $type_key => $type_name) {
                        $trend[$type_key] = $leadData[$day][$lead_type_id][$type_key] ?? 0;
                    }
                    $sourceTrends[$lead_type_id][] = $trend;
                }
            }

            $line_MonthColors = $this->generateLeadSourceAttractiveColors($leadTypes_list);
            $pie_MonthColors = !empty($line_MonthColors) && is_array($line_MonthColors) ? array_values($line_MonthColors) : [];

            return response()->json([
                'days' => $days,
                'dayLabels' => $dayLabels,
                'leadTypes' => $leadTypes_list,
                'leadData' => $leadData,
                'preleadData' => $preleadData,
                'percentages' => $percentages,
                'sourceTotals' => $sourceTotals,
                'dayTotals' => $dayTotals,
                'staff_details' => $leadTypesMapped,
                'grandTotalAll' => $grandTotalAll,
                'currentMonth' => (int)$currentMonth,
                'currentYear' => (int)$currentYear,
                'currentDay' => (int)$currentDay,
                'exit_staff_details' => $exit_staff_details,
                'exit_status_staffs' => $exit_status_staffs,
                'exit_staff_doj_details' => $exit_staff_doj_details,
                'Month' => (int)$Month,
                'dayNames' => $dayNames,
                'sourceTrends' => $sourceTrends,
                'year' => (int)$year,
                'yearShort' => (int)$yearShort,
                'line_MonthColors' => $line_MonthColors,
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'type_count' => $type_count,
                'typeMonthTotals' => $typeMonthTotals,
                'grandTypeTotals' => $grandTypeTotals,
                'pie_MonthColors' => $pie_MonthColors
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load Faculty data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function week_lead_month()
    {
        $weekdays = [
            1 => 'Mon',
            2 => 'Tue',
            3 => 'Wed',
            4 => 'Thu',
            5 => 'Fri',
            6 => 'Sat',
            7 => 'Sun',
        ];
        return view('content.report_management.lead_report.weekly_lead_list', compact(
            'weekdays'
        ))->with('report_heading', self::$report_heading);
    }

    public function getWeeklyMonthData(Request $request)
    {
        try {

            $inputYear = $request->year;

            if ($request->filled('year') && preg_match('/^\d{4}$/', $inputYear)) {
                $filter_year = $inputYear . '-01-01';
            } else {
                $filter_year = now()->format('Y-01-01');
            }

            $year  = date('Y', strtotime($filter_year));
            $pre_year  = (int)$year - 1;
            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate = date('d-m-Y');

            $pre_daysInMonth = cal_days_in_month(CAL_GREGORIAN, 12, $pre_year);

            $months = $this->getYearBasedMonths($year);

            $short_months = $this->getYearBasedMonths($year, 2);

            $user = $request->user();

            $user_id = $user->user_id;
            $branch_id = $user->branch_id;

            $result = $this->GetLeadConversionWeeklyDetails($branch_id);

            // return ['result' => $result];

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }

            $dailyData = $result['daily'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];
            $weekday_monthly = $result['weekday_monthly'] ?? [];
            $weekday_yearly = $result['weekday_yearly'] ?? [];
            
            $weekdays = [
                1 => 'Mon',
                2 => 'Tue',
                3 => 'Wed',
                4 => 'Thu',
                5 => 'Fri',
                6 => 'Sat',
                7 => 'Sun',
            ];

            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            $days = range(1, 31);

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $increment_data  = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];

            foreach ($months as $monthNum => $monthName) {

                $Trend_data_list = [];

                foreach ($weekdays as $weekday_id => $weekday_name) {

                    $monthly_data = isset($monthlyData) && !empty($monthlyData) ? $monthlyData : [];

                    foreach ($types_list as $type_key => $type_name) {

                        $amount = isset($weekday_monthly[$year][$monthNum][$weekday_id][$type_key]) ? round($weekday_monthly[$year][$monthNum][$weekday_id][$type_key]) : 0;

                        $pre_amount = isset($weekday_monthly[$pre_year][12][7][$type_key]) ? round($weekday_monthly[$pre_year][12][7][$type_key]) : 0;

                        // Save raw daily data
                        $data[$monthNum][$weekday_id][$type_key] = $amount;

                        $pre_data[12][7][$type_key] = $pre_amount;

                        $Trend_data_list[$type_key] = $amount;

                        // Month totals per type
                        $totals[$monthNum][$type_key] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;

                        // Month grand total
                        $grandTotals[$monthNum] = ($grandTotals[$monthNum] ?? 0) + ($totals[$monthNum][$type_key] ?? 0);

                        $percentages[$monthNum] = ($monthly_data[$year][$monthNum]['conversion_percentage'] ?? 0);

                        $daypercentages[$monthNum][$weekday_id] = ($weekday_monthly[$year][$monthNum][$weekday_id]['conversion_percentage'] ?? 0);

                        // Day totals across months
                        $typeDayTotals[$type_key][$weekday_id] = ($typeDayTotals[$type_key][$weekday_id] ?? 0) + $amount;

                        $typeMonthTotals[$type_key][$monthNum] = isset($monthly_data[$year][$monthNum][$type_key]) ? round($monthly_data[$year][$monthNum][$type_key]) : 0;
                        
                        $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                    }

                    $Trend_data[$monthName][] = $Trend_data_list;
                }
            }

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'weekdays' => $weekdays,
                'increment_data' => $increment_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'percentages' => $percentages,
                'daypercentages' => $daypercentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'year' => $year,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to load leads data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    public function yearly_lead_weekly()
    {
        $weekdays = [
            1 => 'Mon',
            2 => 'Tue',
            3 => 'Wed',
            4 => 'Thu',
            5 => 'Fri',
            6 => 'Sat',
            7 => 'Sun',
        ];
        return view('content.report_management.lead_report.week_lead_yearly_list', compact(
            'weekdays'
        ))->with('report_heading', self::$report_heading);
    }

    public function getWeeklyYearlyData(Request $request)
    {
        try {

            $currentYear  = date('Y');
            $currentMonth = date('n');
            $currentDay   = date('j');
            $currentDate   = date('m-Y');

            $user = $request->user();
            $user_id = $user->user_id;
            $branch_id = $user->branch_id;
            $result = $this->GetLeadConversionWeeklyDetails($branch_id);

            if ($result === null) {
                return response()->json(['error' => 'Failed to get data'], 500);
            }
            
            // return $result;

            // $dailyData = $result['daily'] ?? [];
            $weekday_monthly = $result['weekday_monthly'] ?? [];
            $weekday_yearly = $result['weekday_yearly'] ?? [];
            $monthlyData = $result['monthly'] ?? [];
            $yearlyData = $result['yearly'] ?? [];

            // return $result;

            $types_list = [
                'lead_count' => 'Lead',
                'conversion_count' => 'Conversion',
            ];

            $months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];

            $short_months = [
                1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',
                7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'
            ];
            
            $days = range(1, 31);

            $type_keys = array_keys($types_list);

            $type_count = !empty($types_list) && is_array($types_list) ? count($types_list) : 0;

            // Step 1: Extract years from result safely
            $collection_years = isset($result['years']) && !empty($result['years']) ? collect($result['years']) : collect();

            // Step 2: Merge, deduplicate, sort
            $allYears = $collection_years->unique()->sort()->values();

            // Step 3: Convert to array
            $out_Years = $allYears->toArray();

            // Step 4: Generate year string (e.g., "2024 - 2025")
            $yearList = collect($out_Years);
            $firstYear = $yearList->get(0, '');
            $lastYear = $yearList->count() > 1 ? ' - ' . $yearList->last() : '';
            $year_string = $firstYear . $lastYear;

            // Step 5: Add previous year if missing
            $previousYear = !empty($firstYear) ? (int)$firstYear - 1 : null;
            if ($previousYear && !$yearList->contains($previousYear)) {
                $yearList->push($previousYear);
            }

            // Step 6: Sort again after appending previous year
            $finalYears = $yearList->sort()->values()->toArray();

            // Optionally assign final list to `$years`
            $years = $out_Years;

            $years = array_filter($years, function($filter_year) use ($currentYear) {
                return (int)$filter_year <= (int)$currentYear;
            });

            $data            = [];
            $Trend_data      = [];
            $pre_data        = [];
            $totals          = []; // per month per type
            $grandTotals     = []; // per month (all types)
            $typeDayTotals   = []; // per day per type (across months)
            $percentages     = [];
            $daypercentages  = [];
            $grandTypeTotals = []; 
            $typeMonthTotals = [];
            $weekdays = [
                1 => 'Mon',
                2 => 'Tue',
                3 => 'Wed',
                4 => 'Thu',
                5 => 'Fri',
                6 => 'Sat',
                7 => 'Sun',
            ];

            foreach ($finalYears as $year_index => $year) {

                if((int)$year <= (int)$currentYear){

                    $pre_year  = (int)$year - 1;

                    $Trend_data_list = [];

                    foreach ($weekdays as $weekday_id => $weekday_name) {                        

                        $monthly_data = !empty($weekday_yearly) ? $weekday_yearly : [];

                        foreach ($types_list as $type_key => $type_name) {

                            $amount = isset($weekday_yearly[$year][$weekday_id][$type_key]) ? $weekday_yearly[$year][$weekday_id][$type_key] : 0;

                            // Save raw monthly data
                            $data[$year][$weekday_id][$type_key] = $amount;

                            if($year_index != 0){

                                $Trend_data_list[$type_key] = $amount;

                                // Month totals per type
                                $totals[$year][$type_key] = ($yearlyData[$year][$type_key] ?? 0);

                                // Month grand total
                                $grandTotals[$year] = 0;

                                // Day totals across months
                                $typeDayTotals[$type_key][$weekday_id] = ($typeDayTotals[$type_key][$weekday_id] ?? 0) + $amount;

                                $percentages[$year] = ($yearlyData[$year]['conversion_percentage'] ?? 0);

                                $daypercentages[$year][$weekday_id] = ($weekday_yearly[$year][$weekday_id]['conversion_percentage'] ?? 0);

                                $typeMonthTotals[$type_key][$year] = ($yearlyData[$year][$type_key] ?? 0);
                                
                                $grandTypeTotals[$type_key] = ($grandTypeTotals[$type_key] ?? 0) + $amount;
                            }
                        }

                        if($year_index != 0){
                            $Trend_data[$year][] = $Trend_data_list;
                        }
                    }
                }
            }

            $year_colors = $this->generateAttractiveColors($years);

            return response()->json([
                'currentYear' => $currentYear,
                'currentMonth' => $currentMonth,
                'months' => $months,
                'short_months' => $short_months,
                'days' => $days,
                'types' => [],
                'types_list' => $types_list,
                'type_keys' => $type_keys,
                'inern_cal_data' => $data,
                'inern_trend_data' => $Trend_data,
                'pre_inern_cal_data' => $pre_data,
                'totals' => $totals,
                'type_count' => $type_count,
                'grandTotals' => $grandTotals,
                'typeDayTotals' => $typeDayTotals,
                'weekdays' => $weekdays,
                'percentages' => $percentages,
                'daypercentages' => $daypercentages,
                'grandTypeTotals' => $grandTypeTotals,
                'typeMonthTotals' => $typeMonthTotals,
                'years' => $years,
                'year_colors' => $year_colors
            ]);

        } catch (Exception $e) {
            return response()->json([
                'error' => 'An error occurred: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getYearBasedMonths($year, $type = 1) {

        $months = [
            1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
            7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'
        ];

        if($type == 2){
            $months = [
                1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun',
                7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec'
            ];
        }

        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        if ($year < $currentYear) {
            // Past year: return full months
            return $months;
        } elseif ($year == $currentYear) {
            // Current year: return months up to current month
            return array_filter($months, function($key) use ($currentMonth) {
                return $key <= $currentMonth;
            }, ARRAY_FILTER_USE_KEY);
        } else {
            // Future year: return empty or handle as needed
            return [];
        }
    }

    private function generateAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        for ($i = 0; $i < $count; $i++) {
            $hue = ($baseHue + $i * (360 / $count)) % 360;
            $year_id = !empty($list[$i]) ? $list[$i] : 0;
            $colors[$year_id] = 'hsl('.$hue.', 65%, 55%)';
        }
        return $colors;
    }

    private function generateLeadSourceAttractiveColors($list, $baseHue = 200)
    {
        $count = is_array($list) ? count($list) : 0;
        $colors = [];
        if($count > 0){
            $i = 0;
            foreach ($list as $key => $value) {
                $hue = ($baseHue + $i * (360 / $count)) % 360;
                $colors[] = 'hsl('.$hue.', 65%, 55%)';
                $i++;
            }
        }
        return $colors;
    }

    public function get_lead_source_list()
    {
        $CourseCategory = LeadSourceModel::where('status', '!=', 2)->orderBy('lead_source_name', 'asc')->get();
        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function SalesExcutiveStaffList(Request $request)
    {
        $user      = $request->user(); // Fetch user details only once
        $user_id   = $user->user_id;
        $branch_id = $user->branch_id;
        $is_existing = ($request->checked_val == 1) ? 1 : 2;
        $sales_type = ($request->sale_type == 1) ? 1 : 2;

        $currentDate  = date('Y-m-d');
        $currentYear  = (int) date('Y');
        $currentMonth = (int) date('n');
        $department_id = ((int)$sales_type == 1) ? 1 : 15; // Post-sale

        $staff_query = DB::table('et_staff')
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', $department_id)
            ->where('et_staff.branch_id', $branch_id)
            ->where('et_staff.sno', '!=', 1);

        if ($is_existing == 2) {
            $staff_query->where(function ($q) use ($currentYear, $currentMonth) {
                $q->where(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 4)
                        ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                        ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 5)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 6)
                        ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                        ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 7)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere('et_staff.status',0);
            });
        } else {
            $staff_query->whereNotIn('et_staff.status', [1,2]);
        }

        $staff = $staff_query->orderBy('et_staff.staff_name', 'asc')->distinct()->get(['et_staff.*']);

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $staff ?? null,
        ], 200);
    }

    private function GetLeadConversionDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $dailyData   = [];
            $monthlyData = [];
            $yearlyData  = [];
            $years       = [];


            /* ==========================================================================
                1. FETCH ALL LEADS
            ========================================================================== */
            $lead_query = DB::table('et_lead')
                ->select('registered_date')
                ->whereNotIn('status', [2, 6])
                ->where('spam_verified', 0)
                ->where('drop_verified', 0)
                ->where('internal_status', 0);

            if ($branch_id != 0) {
                $lead_query->where('branch_id', $branch_id);
            }

            $lead_list = $lead_query->get();


            /* ==========================================================================
                2. FETCH ALL CONVERSIONS
            ========================================================================== */
            $conversion_query = DB::table('et_customer')
                ->select('et_payment.transaction_date')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function ($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1);

            if ($branch_id != 0) {
                $conversion_query->where('et_customer.branch_id', $branch_id);
            }

            $conversion_list = $conversion_query->get();


            /* ==========================================================================
                3. LOOP LEADS — DAILY / MONTHLY / YEARLY COUNTS
            ========================================================================== */
            foreach ($lead_list as $lead) {

                if (empty($lead->registered_date)) continue;

                $date = date('Y-m-d', strtotime($lead->registered_date));

                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));

                $yearlyData[$y]['lead_count'] = ($yearlyData[$y]['lead_count'] ?? 0) + 1;
                $monthlyData[$y][$m]['lead_count'] = ($monthlyData[$y][$m]['lead_count'] ?? 0) + 1;
                $dailyData[$y][$m][$d]['lead_count'] = ($dailyData[$y][$m][$d]['lead_count'] ?? 0) + 1;

                $years[$y] = $y;
            }


            /* ==========================================================================
                4. LOOP CONVERSIONS — DAILY / MONTHLY / YEARLY COUNTS
            ========================================================================== */
            foreach ($conversion_list as $conv) {

                if (empty($conv->transaction_date)) continue;

                $date = date('Y-m-d', strtotime($conv->transaction_date));

                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));

                $yearlyData[$y]['conversion_count'] = ($yearlyData[$y]['conversion_count'] ?? 0) + 1;
                $monthlyData[$y][$m]['conversion_count'] = ($monthlyData[$y][$m]['conversion_count'] ?? 0) + 1;
                $dailyData[$y][$m][$d]['conversion_count'] = ($dailyData[$y][$m][$d]['conversion_count'] ?? 0) + 1;

                $years[$y] = $y;
            }


            /* ==========================================================================
                5. POST-PROCESS: ADD conversion_percentage + cumulative totals
            ========================================================================== */


            /* ====================== YEARLY ====================== */

            $yearlyLeadTotal = 0;
            $yearlyConvTotal = 0;

            ksort($yearlyData);

            foreach ($yearlyData as $y => &$yData) {

                $lead = $yData['lead_count'] ?? 0;
                $conv = $yData['conversion_count'] ?? 0;

                // conversion %
                $yData['conversion_percentage'] = ($lead > 0)
                    ? round(($conv / $lead) * 100, 2)
                    : 0;

                // cumulative yearly totals
                $yearlyLeadTotal += $lead;
                $yearlyConvTotal += $conv;

                $yData['increment_lead_count'] = $yearlyLeadTotal;
                $yData['increment_conversion_count'] = $yearlyConvTotal;
            }


            /* ====================== MONTHLY ====================== */

            foreach ($monthlyData as $y => &$months) {

                $monthlyLeadTotal = 0;
                $monthlyConvTotal = 0;

                ksort($months); // sort by month

                foreach ($months as $m => &$mData) {

                    $lead = $mData['lead_count'] ?? 0;
                    $conv = $mData['conversion_count'] ?? 0;

                    // conversion %
                    $mData['conversion_percentage'] = ($lead > 0)
                        ? round(($conv / $lead) * 100, 2)
                        : 0;

                    // cumulative monthly totals
                    $monthlyLeadTotal += $lead;
                    $monthlyConvTotal += $conv;

                    $mData['increment_lead_count'] = $monthlyLeadTotal;
                    $mData['increment_conversion_count'] = $monthlyConvTotal;
                }
            }


            /* ====================== DAILY ====================== */

            foreach ($dailyData as $y => &$months) {

                foreach ($months as $m => &$days) {

                    $dailyLeadTotal = 0;
                    $dailyConvTotal = 0;

                    ksort($days); // sort by day

                    foreach ($days as $d => &$dData) {

                        $lead = $dData['lead_count'] ?? 0;
                        $conv = $dData['conversion_count'] ?? 0;

                        // cumulative daily totals
                        $dailyLeadTotal += $lead;
                        $dailyConvTotal += $conv;

                        $dData['increment_lead_count'] = $dailyLeadTotal;
                        $dData['increment_conversion_count'] = $dailyConvTotal;
                    }
                }
            }


            /* ==========================================================================
                6. FINAL RETURN
            ========================================================================== */
            return [
                'yearly'  => $yearlyData,
                'monthly' => $monthlyData,
                'daily'   => $dailyData,
                'years'   => array_values($years)
            ];


        } catch (\Exception $e) {
            \Log::error("Error in GetLeadConversionDetails: " . $e->getMessage());
            return null;
        }
    }

    public function GetLeadSourceDetails(int $branch_id, $search_lead_src_fill = [])
    {
        if (!$branch_id) {
            throw new \Exception("Branch ID required");
        }

        $leadSources = [];
        $daily = [];
        $monthly = [];
        $yearly = [];
        // $leadSourceList = [];

        /* ------------------------------------
        * 1. Lead Sources List (ASC order)
        * ------------------------------------ */
        $leadSource_list = DB::table('et_lead_source')
        ->select('sno', 'lead_source_name as source_name')
        ->where('status', '!=', 2)
        ->when(!empty($search_lead_src_fill), function ($q) use ($search_lead_src_fill) {
            $q->whereIn('sno', $search_lead_src_fill);
        })
        ->get();

        // Ensure alphabetical sorting A → Z
        $sortedLeadSource = $leadSource_list->sortBy(function ($item) {
            return strtolower($item->source_name);
        });

        // Final arrays
        $leadSourceListIds = $sortedLeadSource->pluck('sno')->toArray();
        $leadSourceList    = $sortedLeadSource->pluck('source_name', 'sno')->toArray();

        /* ---------------------------------------------------------
        | 1. LEAD DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $leadData = DB::table('et_lead')
            ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->select(
                'et_lead_source.sno as source_id',
                'et_lead_source.lead_source_name as source_name',
                DB::raw('DAY(et_lead.registered_date) as d'),
                DB::raw('MONTH(et_lead.registered_date) as m'),
                DB::raw('YEAR(et_lead.registered_date) as y'),
                DB::raw('COUNT(et_lead.sno) as lead_count')
            )
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.spam_verified', 0)
            ->where('et_lead.created_by', '>', 0)
            ->where('et_lead.branch_id', $branch_id)
            ->whereIn('et_lead_source.sno', $leadSourceListIds)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | 2. CONVERSION DATA (ALL YEARS, ALL MONTHS)
        --------------------------------------------------------- */
        $conversionData = DB::table('et_customer')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->select(
                'et_lead_source.sno as source_id',
                'et_lead_source.lead_source_name as source_name',
                DB::raw('DAY(et_payment.transaction_date) as d'),
                DB::raw('MONTH(et_payment.transaction_date) as m'),
                DB::raw('YEAR(et_payment.transaction_date) as y'),
                DB::raw('COUNT(et_customer.sno) as conversion_count')
            )
            ->where('et_transaction.payment_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereIn('et_lead_source.sno', $leadSourceListIds)
            ->where('et_lead.created_by', '>', 0)
            ->groupBy('source_id', 'source_name', 'y', 'm', 'd')
            ->get();


        /* ---------------------------------------------------------
        | Merge both LEAD + CONVERSION
        --------------------------------------------------------- */
        foreach ($leadData as $row) {

            // build lead source list
            // $leadSourceList[$row->source_id] = [
            //     "source_id" => $row->source_id,
            //     "source_name" => $row->source_name
            // ];

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            $leadSources[$s]['source_name'] = $row->source_name;
            $leadSources[$s][$y][$m][$d]['lead_count'] = $row->lead_count;
            $leadSources[$s][$y][$m][$d]['conversion_count'] = 0;
        }

        foreach ($conversionData as $row) {

            // ensure lead source exists
            // if (!isset($leadSourceList[$row->source_id])) {
            //     $leadSourceList[$row->source_id] = [
            //         "source_id" => $row->source_id,
            //         "source_name" => $row->source_name
            //     ];
            // }

            $s = $row->source_id;
            $y = $row->y;
            $m = $row->m;
            $d = $row->d;

            if (!isset($leadSources[$s]['source_name'])) {
                $leadSources[$s]['source_name'] = $row->source_name;
            }

            if (!isset($leadSources[$s][$y][$m][$d]['lead_count'])) {
                $leadSources[$s][$y][$m][$d]['lead_count'] = 0;
            }

            $leadSources[$s][$y][$m][$d]['conversion_count'] = $row->conversion_count;
        }


        /* ---------------------------------------------------------
        | DAILY / MONTHLY / YEARLY summary
        --------------------------------------------------------- */
        foreach ($leadSources as $sourceId => $srcData) {

            foreach ($srcData as $y => $mData) {
                if ($y === 'source_name') continue;

                foreach ($mData as $m => $dData) {

                    // DAILY
                    foreach ($dData as $d => $v) {

                        $lead = $v['lead_count'];
                        $conv = $v['conversion_count'];

                        $daily[$sourceId][$y][$m][$d] = [
                            'lead_count' => $lead,
                            'conversion_count' => $conv,
                            'conversion_percentage' =>
                                ($lead > 0 ? round(($conv / $lead) * 100, 2) : 0)
                        ];
                    }

                    // MONTHLY
                    $monthLead = array_sum(array_column($dData, 'lead_count'));
                    $monthConv = array_sum(array_column($dData, 'conversion_count'));

                    $monthly[$sourceId][$y][$m] = [
                        'lead_count' => $monthLead,
                        'conversion_count' => $monthConv,
                        'conversion_percentage' =>
                            ($monthLead > 0 ? round(($monthConv / $monthLead) * 100, 2) : 0)
                    ];
                }

                // YEARLY
                $yearLead = 0;
                $yearConv = 0;

                foreach ($monthly[$sourceId][$y] as $m => $vals) {
                    $yearLead += $vals['lead_count'];
                    $yearConv += $vals['conversion_count'];
                }

                $yearly[$sourceId][$y] = [
                    'lead_count' => $yearLead,
                    'conversion_count' => $yearConv,
                    'conversion_percentage' =>
                        ($yearLead > 0 ? round(($yearConv / $yearLead) * 100, 2) : 0)
                ];
            }
        }


        /* ---------------------------------------------------------
        | FINAL RETURN
        --------------------------------------------------------- */
        return [
            "lead_source_list" => $leadSourceList, // clean list
            "daily"   => $daily,
            "monthly" => $monthly,
            "yearly"  => $yearly
        ];
    }

    private function GetLeadConversionWeeklyDetails(int $branch_id)
    {
        try {

            if (!$branch_id) {
                throw new \InvalidArgumentException("Branch ID is required");
            }

            $dailyData        = [];
            $monthlyData      = [];
            $yearlyData       = [];
            $weekdayData      = []; // overall weekday
            $weekdayYearly    = []; // weekday → yearly
            $weekdayMonthly   = []; // weekday → monthly
            $years            = [];


            /* ==========================================================================
                1. FETCH ALL LEADS
            ========================================================================== */
            $lead_query = DB::table('et_lead')
                ->select('registered_date')
                ->whereNotIn('status', [2, 6])
                ->where('spam_verified', 0)
                ->where('drop_verified', 0)
                ->where('internal_status', 0);

            if ($branch_id != 0) {
                $lead_query->where('branch_id', $branch_id);
            }

            $lead_list = $lead_query->get();


            /* ==========================================================================
                2. FETCH ALL CONVERSIONS
            ========================================================================== */
            $conversion_query = DB::table('et_customer')
                ->select('et_payment.transaction_date')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function ($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1);

            if ($branch_id != 0) {
                $conversion_query->where('et_customer.branch_id', $branch_id);
            }

            $conversion_list = $conversion_query->get();



            /* ==========================================================================
                3. LOOP LEADS — YEAR / MONTH / DAY / WEEKDAY
            ========================================================================== */
            foreach ($lead_list as $lead) {

                if (empty($lead->registered_date)) continue;

                $date = date('Y-m-d', strtotime($lead->registered_date));

                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));
                $w = (int) date('N', strtotime($date)); // 1..7

                // YEARLY
                $yearlyData[$y]['lead_count'] = ($yearlyData[$y]['lead_count'] ?? 0) + 1;

                // MONTHLY
                $monthlyData[$y][$m]['lead_count'] =
                    ($monthlyData[$y][$m]['lead_count'] ?? 0) + 1;

                // DAILY
                $dailyData[$y][$m][$d]['lead_count'] =
                    ($dailyData[$y][$m][$d]['lead_count'] ?? 0) + 1;

                // WEEKDAY (overall)
                $weekdayData[$w]['lead_count'] =
                    ($weekdayData[$w]['lead_count'] ?? 0) + 1;

                // WEEKDAY → YEARLY
                $weekdayYearly[$y][$w]['lead_count'] =
                    ($weekdayYearly[$y][$w]['lead_count'] ?? 0) + 1;

                // WEEKDAY → MONTHLY
                $weekdayMonthly[$y][$m][$w]['lead_count'] =
                    ($weekdayMonthly[$y][$m][$w]['lead_count'] ?? 0) + 1;

                $years[$y] = $y;
            }




            /* ==========================================================================
                4. LOOP CONVERSIONS — YEAR / MONTH / DAY / WEEKDAY
            ========================================================================== */
            foreach ($conversion_list as $conv) {

                if (empty($conv->transaction_date)) continue;

                $date = date('Y-m-d', strtotime($conv->transaction_date));

                $y = (int) date('Y', strtotime($date));
                $m = (int) date('n', strtotime($date));
                $d = (int) date('j', strtotime($date));
                $w = (int) date('N', strtotime($date)); // weekday

                // YEARLY
                $yearlyData[$y]['conversion_count'] =
                    ($yearlyData[$y]['conversion_count'] ?? 0) + 1;

                // MONTHLY
                $monthlyData[$y][$m]['conversion_count'] =
                    ($monthlyData[$y][$m]['conversion_count'] ?? 0) + 1;

                // DAILY
                $dailyData[$y][$m][$d]['conversion_count'] =
                    ($dailyData[$y][$m][$d]['conversion_count'] ?? 0) + 1;

                // WEEKDAY (overall)
                $weekdayData[$w]['conversion_count'] =
                    ($weekdayData[$w]['conversion_count'] ?? 0) + 1;

                // WEEKDAY → YEARLY
                $weekdayYearly[$y][$w]['conversion_count'] =
                    ($weekdayYearly[$y][$w]['conversion_count'] ?? 0) + 1;

                // WEEKDAY → MONTHLY
                $weekdayMonthly[$y][$m][$w]['conversion_count'] =
                    ($weekdayMonthly[$y][$m][$w]['conversion_count'] ?? 0) + 1;

                $years[$y] = $y;
            }




            /* ==========================================================================
                5. POST-PROCESS — CALCULATE %
            ========================================================================== */

            /* ---------- YEARLY ---------- */
            $yearlyLeadTotal = 0;
            $yearlyConvTotal = 0;
            ksort($yearlyData);

            foreach ($yearlyData as $y => &$yData) {

                $lead = $yData['lead_count'] ?? 0;
                $conv = $yData['conversion_count'] ?? 0;

                $yData['conversion_percentage'] =
                    ($lead > 0) ? round(($conv / $lead) * 100, 2) : 0;

                $yearlyLeadTotal += $lead;
                $yearlyConvTotal += $conv;

                $yData['increment_lead_count']      = $yearlyLeadTotal;
                $yData['increment_conversion_count'] = $yearlyConvTotal;
            }


            /* ---------- MONTHLY ---------- */
            foreach ($monthlyData as $y => &$months) {

                $monthlyLeadTotal = 0;
                $monthlyConvTotal = 0;

                ksort($months);

                foreach ($months as $m => &$mData) {

                    $lead = $mData['lead_count'] ?? 0;
                    $conv = $mData['conversion_count'] ?? 0;

                    $mData['conversion_percentage'] =
                        ($lead > 0) ? round(($conv / $lead) * 100, 2) : 0;

                    $monthlyLeadTotal += $lead;
                    $monthlyConvTotal += $conv;

                    $mData['increment_lead_count']      = $monthlyLeadTotal;
                    $mData['increment_conversion_count'] = $monthlyConvTotal;
                }
            }


            /* ---------- DAILY ---------- */
            foreach ($dailyData as $y => &$months) {
                foreach ($months as $m => &$days) {

                    $dailyLeadTotal = 0;
                    $dailyConvTotal = 0;

                    ksort($days);

                    foreach ($days as $d => &$dData) {

                        $lead = $dData['lead_count'] ?? 0;
                        $conv = $dData['conversion_count'] ?? 0;

                        $dailyLeadTotal += $lead;
                        $dailyConvTotal += $conv;

                        $dData['increment_lead_count']      = $dailyLeadTotal;
                        $dData['increment_conversion_count'] = $dailyConvTotal;
                    }
                }
            }


            /* ---------- WEEKDAY OVERALL ---------- */
            ksort($weekdayData);

            foreach ($weekdayData as $w => &$wData) {
                $lead = $wData['lead_count'] ?? 0;
                $conv = $wData['conversion_count'] ?? 0;

                $wData['conversion_percentage'] =
                    ($lead > 0) ? round(($conv / $lead) * 100, 2) : 0;
            }


            /* ---------- WEEKDAY YEARLY ---------- */
            foreach ($weekdayYearly as $y => &$weekdays) {
                ksort($weekdays);
                foreach ($weekdays as $w => &$data) {
                    $lead = $data['lead_count'] ?? 0;
                    $conv = $data['conversion_count'] ?? 0;

                    $data['conversion_percentage'] =
                        ($lead > 0) ? round(($conv / $lead) * 100, 2) : 0;
                }
            }


            /* ---------- WEEKDAY MONTHLY ---------- */
            foreach ($weekdayMonthly as $y => &$months) {
                foreach ($months as $m => &$weekdays) {
                    ksort($weekdays);
                    foreach ($weekdays as $w => &$data) {

                        $lead = $data['lead_count'] ?? 0;
                        $conv = $data['conversion_count'] ?? 0;

                        $data['conversion_percentage'] =
                            ($lead > 0) ? round(($conv / $lead) * 100, 2) : 0;
                    }
                }
            }




            /* ==========================================================================
                6. FINAL RETURN
            ========================================================================== */
            return [
                'yearly'           => $yearlyData,
                'monthly'          => $monthlyData,
                'daily'            => $dailyData,

                'weekday'          => $weekdayData,      // overall weekday summary
                'weekday_yearly'   => $weekdayYearly,    // weekday → year
                'weekday_monthly'  => $weekdayMonthly,   // weekday → month

                'years'            => array_values($years)
            ];


        } catch (\Exception $e) {
            \Log::error("Error in GetLeadConversionDetails: " . $e->getMessage());
            return null;
        }
    }

    // public function GetSalesPersonDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2, int $year)
    // {
    //     try {
    //         if (!$branch_id) {
    //             throw new \InvalidArgumentException("Branch ID is required");
    //         }

    //         $currentDate  = date('Y-m-d');
    //         $currentYear  = (int) date('Y');
    //         $currentMonth = (int) date('n');

    //         $dailyData     = [];
    //         $monthlyData   = [];
    //         $yearlyData    = [];
    //         $staff_details = [];
    //         $months        = $this->getYearBasedMonths($year);

    //         $staffGroups = [
    //             'pre_sale'  => 1,
    //             'post_sale' => 15,
    //         ];

    //         foreach ($staffGroups as $groupKey => $department_id) {

    //             // -------------------------------
    //             // Fetch staff list
    //             // -------------------------------
    //             $staff_query = DB::table('et_staff')
    //                 ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
    //                 ->where('et_staff.department_id', $department_id)
    //                 ->where('et_staff.sno', '!=', 1)
    //                 ->where('et_staff.branch_id', $branch_id);

    //             if ($is_existing_val == 2) {
    //                 $staff_query->where(function ($q) use ($currentYear, $currentMonth) {
    //                     $q->where(function ($sq) use ($currentYear, $currentMonth) {
    //                         $sq->where('et_staff.status', 4)
    //                             ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
    //                             ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
    //                     })
    //                     ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
    //                         $sq->where('et_staff.status', 5)
    //                             ->whereYear('et_staff.updated_at', '>=', $currentYear)
    //                             ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
    //                     })
    //                     ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
    //                         $sq->where('et_staff.status', 6)
    //                             ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
    //                             ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
    //                     })
    //                     ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
    //                         $sq->where('et_staff.status', 7)
    //                             ->whereYear('et_staff.updated_at', '>=', $currentYear)
    //                             ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
    //                     })
    //                     ->orWhere('et_staff.status', 0);
    //                 });
    //             } else {
    //                 $staff_query->where('et_staff.status', '!=', 2);
    //             }

    //             if (!empty($search_lead_src_fill)) {
    //                 $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
    //             }

    //             $staff_list = $staff_query->orderBy('staff_name', 'asc')->get(['et_staff.*']);
    //             if ($staff_list->isEmpty()) continue;

    //             $staff_ids = $staff_list->pluck('sno')->toArray();

    //             // -------------------------------
    //             // Fetch all payments in bulk
    //             // -------------------------------
    //             if ($groupKey === 'post_sale') {
    //                 $allPayments = DB::table('et_customer')
    //                     ->select(
    //                         'et_customer.sno as customer_id',
    //                         'et_proposal.created_by as staff_id',
    //                         DB::raw('YEAR(et_payment.transaction_date) as year'),
    //                         DB::raw('MONTH(et_payment.transaction_date) as month'),
    //                         DB::raw('DAY(et_payment.transaction_date) as day')
    //                     )
    //                     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //                     ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //                     ->join('et_payment', function($join) {
    //                         $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
    //                             ->whereRaw('et_payment.transaction_date = (
    //                                 SELECT MIN(ep.transaction_date)
    //                                 FROM et_payment ep
    //                                 WHERE ep.proposal_id = et_proposal.sno
    //                             )');
    //                     })
    //                     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //                     ->where('et_customer.status', 0)
    //                     ->where('et_customer.post_sale_check', 1)
    //                     ->where('et_proposal.post_sale_check', 1)
    //                     ->where('et_customer.branch_id', $branch_id)
    //                     ->whereIn('et_proposal.created_by', $staff_ids)
    //                     ->where('et_transaction.payment_status', 1)
    //                     ->whereYear('et_payment.transaction_date', $year)
    //                     ->get();
    //             } else { // pre_sale
    //                 $allPayments = DB::table('et_customer')
    //                     ->select(
    //                         'et_customer.sno as customer_id',
    //                         'et_lead.created_by as staff_id',
    //                         DB::raw('YEAR(et_payment.transaction_date) as year'),
    //                         DB::raw('MONTH(et_payment.transaction_date) as month'),
    //                         DB::raw('DAY(et_payment.transaction_date) as day')
    //                     )
    //                     ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //                     ->join('et_payment', function($join) {
    //                         $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                             ->whereRaw('et_payment.transaction_date = (
    //                                 SELECT MIN(ep.transaction_date)
    //                                 FROM et_payment ep
    //                                 WHERE ep.customer_id = et_customer.sno
    //                             )');
    //                     })
    //                     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //                     ->where('et_customer.status', 0)
    //                     ->where('et_customer.branch_id', $branch_id)
    //                     ->whereIn('et_lead.created_by', $staff_ids)
    //                     ->where('et_transaction.payment_status', 1)
    //                     ->whereYear('et_payment.transaction_date', $year)
    //                     ->get();
    //             }

    //             // -------------------------------
    //             // Map staff details & build arrays
    //             // -------------------------------
    //             foreach ($staff_list as $staff) {

    //                 $doj = $staff->date_of_joining ?: null;
    //                 $exist_date = match ($staff->status) {
    //                     4 => $staff->notice_end_date,
    //                     5 => $staff->updated_at,
    //                     6 => $staff->staff_last_date,
    //                     7 => $staff->updated_at,
    //                     default => null
    //                 };
    //                 $toDate = $exist_date ?: $currentDate;

    //                 $staff_details[$groupKey][] = [
    //                     'staff_id'     => $staff->sno,
    //                     'staff_name'   => $staff->staff_name ?? 'None',
    //                     'group'        => $groupKey,
    //                     'doj'          => $doj,
    //                     'exist_status' => in_array($staff->status, [4, 5, 6, 7]),
    //                     'exist_date'   => $exist_date
    //                 ];

    //                 if (!$doj) continue;

    //                 $staffPayments = $allPayments->where('staff_id', $staff->sno);

    //                 // Yearly
    //                 $yearlyData[$year][$groupKey . "_" . $staff->sno] = $staffPayments->count();

    //                 // Monthly
    //                 foreach ($months as $m => $mName) {
    //                     $monthlyData[$year][$m][$groupKey . "_" . $staff->sno] = $staffPayments->where('month', $m)->count();
    //                 }

    //                 // Daily
    //                 foreach ($months as $m => $mName) {
    //                     $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $m, $year);
    //                     for ($d = 1; $d <= $daysInMonth; $d++) {
    //                         $dailyData[$year][$m][$d][$groupKey . "_" . $staff->sno] = $staffPayments->where('month', $m)->where('day', $d)->count();
    //                     }
    //                 }
    //             }
    //         }

    //         // After building $staff_details
    //         $slugs = [
    //             'pre_sale' => 'Pre Sale',
    //             'post_sale' => 'Post Sale'
    //         ];

    //         // Add staff counts
    //         foreach ($staffGroups as $groupKey => $department_id) {
    //             $count = isset($staff_details[$groupKey]) ? count($staff_details[$groupKey]) : 0;
    //             $slugs[$groupKey . '_staff_count'] = $count;
    //         }

    //         return [
    //             'yearly'       => $yearlyData,
    //             'monthly'      => $monthlyData,
    //             'daily'        => $dailyData,
    //             'staff_details'=> $staff_details,
    //             'years'        => [$year],
    //             'slugs'        => $slugs,
    //         ];

    //     } catch (\Exception $e) {
    //         \Log::error("Error in GetSalesPersonDetails: " . $e->getMessage());
    //         return null;
    //     }
    // }

    private function GetPostSaleDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2, int $year)
    {
        $currentDate  = date('Y-m-d');
        $currentYear  = (int) date('Y');
        $currentMonth = (int) date('n');

        $dailyData   = [];
        $monthlyData = [];
        $yearlyData  = [];
        $staff_details = [];

        $months = $this->getYearBasedMonths($year);
        $department_id = 15; // Post-sale

        /* =======================================================
            1. FETCH STAFF LIST (Same Conditions – Optimized)
        ========================================================*/
        $staff_query = DB::table('et_staff')
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', $department_id)
            ->where('et_staff.branch_id', $branch_id)
            ->where('et_staff.sno', '!=', 1);

        if ($is_existing_val == 2) {
            $staff_query->where(function ($q) use ($currentYear, $currentMonth) {
                $q->where(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 4)
                        ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                        ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 5)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 6)
                        ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                        ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 7)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere('et_staff.status', 0);
            });
        } else {
            $staff_query->whereNotIn('et_staff.status', [1,2]);
        }

        if (!empty($search_lead_src_fill)) {
            $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
        }

        $staff_list = $staff_query
            ->orderBy('staff_name', 'asc')
            ->get(['et_staff.*']);

        /* =======================================================
            2. PRELOAD ALL LEADS FOR YEAR (instead of 365×staff)
        ========================================================*/
        $all_leads = DB::table('et_lead')
            ->select('sno', 'created_by', 'registered_date')
            ->where('branch_id', $branch_id)
            ->whereYear('registered_date', $year)
            ->whereNotIn('status',[2,6])
            ->where('spam_verified',0)
            ->where('drop_verified',0)
            ->where('internal_status',0)
            ->get();

        /* =======================================================
            3. PRELOAD ALL CONVERSIONS FOR YEAR
        ========================================================*/
        $all_conversions = DB::table('et_customer')
            ->select(
                'et_customer.sno',
                'et_proposal.created_by',
                'et_payment.transaction_date'
            )
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.proposal_id = et_proposal.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->where('et_transaction.payment_status', 1)
            ->get();

        /* =======================================================
            4. BUILD STAFF WISE DATA
        ========================================================*/
        foreach ($staff_list as $staff) {

            $doj = $staff->date_of_joining ?: null;
            $exist_date = match ($staff->status) {
                4 => $staff->notice_end_date,
                5 => $staff->updated_at,
                6 => $staff->staff_last_date,
                7 => $staff->updated_at,
                default => null,
            };

            $staff_details[$staff->sno] = [
                'staff_id' => $staff->sno,
                'staff_name' => $staff->staff_name ?? 'None',
                'group' => 'post_sale',
                'doj' => $doj,
                'exist_status' => in_array($staff->status, [4,5,6,7]),
                'exist_date' => $exist_date,
            ];

            if (!$doj) continue;

            /* ----------------------------
                FILTER STAFF LEADS
            -----------------------------*/
            $staff_leads = $all_leads->where('created_by', $staff->sno);
            $staff_conversions = $all_conversions->where('created_by', $staff->sno);

            /* ----------------------------
                YEARLY
            -----------------------------*/
            $yearlyData[$staff->sno][$year]['lead_count'] = $staff_leads->count();
            $yearlyData[$staff->sno][$year]['conversion_count'] = $staff_conversions->count();

            /* ----------------------------
                MONTHLY + DAILY
            -----------------------------*/
            foreach ($months as $m => $mName) {

                $monthly_leads = $staff_leads->filter(fn($l) => date('n', strtotime($l->registered_date)) == $m);
                $monthly_conversions = $staff_conversions->filter(fn($c) => date('n', strtotime($c->transaction_date)) == $m);

                $monthlyData[$staff->sno][$year][$m]['lead_count'] = $monthly_leads->count();
                $monthlyData[$staff->sno][$year][$m]['conversion_count'] = $monthly_conversions->count();

                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $m, $year);

                for ($d = 1; $d <= $daysInMonth; $d++) {

                    $dailyData[$staff->sno][$year][$m][$d]['lead_count'] =
                        $monthly_leads->filter(fn($l) => date('j', strtotime($l->registered_date)) == $d)->count();

                    $dailyData[$staff->sno][$year][$m][$d]['conversion_count'] =
                        $monthly_conversions->filter(fn($c) => date('j', strtotime($c->transaction_date)) == $d)->count();
                }
            }
        }

        return [
            'staff_details' => $staff_details,
            'daily' => $dailyData,
            'monthly' => $monthlyData,
            'yearly' => $yearlyData,
        ];
    }

    private function GetPreSaleDetails(int $branch_id, $search_lead_src_fill = null, int $is_existing_val = 2, int $year)
    {
        $currentDate  = date('Y-m-d');
        $currentYear  = (int) date('Y');
        $currentMonth = (int) date('n');

        $dailyData   = [];
        $monthlyData = [];
        $yearlyData  = [];
        $staff_details = [];

        $months = $this->getYearBasedMonths($year);
        $department_id = 1; // Post-sale

        /* =======================================================
            1. FETCH STAFF LIST (Same Conditions – Optimized)
        ========================================================*/
        $staff_query = DB::table('et_staff')
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', $department_id)
            ->where('et_staff.sno','>', 1)
            ->where('et_staff.branch_id', $branch_id);

        if ($is_existing_val == 2) {
            $staff_query->where(function ($q) use ($currentYear, $currentMonth) {
                $q->where(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 4)
                        ->whereYear('et_staff.notice_end_date', '>=', $currentYear)
                        ->whereMonth('et_staff.notice_end_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 5)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 6)
                        ->whereYear('et_staff.staff_last_date', '>=', $currentYear)
                        ->whereMonth('et_staff.staff_last_date', '>=', $currentMonth);
                })
                ->orWhere(function ($sq) use ($currentYear, $currentMonth) {
                    $sq->where('et_staff.status', 7)
                        ->whereYear('et_staff.updated_at', '>=', $currentYear)
                        ->whereMonth('et_staff.updated_at', '>=', $currentMonth);
                })
                ->orWhere('et_staff.status', 0);
            });
        } else {
            $staff_query->whereNotIn('et_staff.status', [1,2]);
        }

        if (!empty($search_lead_src_fill)) {
            $staff_query->whereIn('et_staff.sno', $search_lead_src_fill);
        }

        $staff_list = $staff_query
            ->orderBy('et_staff.sno', 'asc')
            ->get(['et_staff.*']);

        /* =======================================================
            2. PRELOAD ALL LEADS FOR YEAR (instead of 365×staff)
        ========================================================*/
        $all_leads = DB::table('et_lead')
            ->select('sno', 'created_by', 'registered_date')
            ->where('branch_id', $branch_id)
            ->whereYear('registered_date', $year)
            ->whereNotIn('status',[2,6])
            ->where('spam_verified',0)
            ->where('drop_verified',0)
            ->where('internal_status',0)
            ->get();

        /* =======================================================
            3. PRELOAD ALL CONVERSIONS FOR YEAR
        ========================================================*/
        $all_conversions = DB::table('et_customer')
            ->select(
                'et_customer.sno',
                'et_lead.created_by',
                'et_payment.transaction_date'
            )
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                        SELECT MIN(ep.transaction_date)
                        FROM et_payment ep
                        WHERE ep.customer_id = et_customer.sno
                    )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->where('et_transaction.payment_status', 1)
            ->get();

        /* =======================================================
            4. BUILD STAFF WISE DATA
        ========================================================*/
        foreach ($staff_list as $staff) {

            $doj = $staff->date_of_joining ?: null;
            $exist_date = match ($staff->status) {
                4 => $staff->notice_end_date,
                5 => $staff->updated_at,
                6 => $staff->staff_last_date,
                7 => $staff->updated_at,
                default => null,
            };

            $staff_details[$staff->sno] = [
                'staff_id' => $staff->sno,
                'staff_name' => $staff->staff_name ?? 'None',
                'group' => 'pre_sale',
                'doj' => $doj,
                'exist_status' => in_array($staff->status, [4,5,6,7]),
                'exist_date' => $exist_date,
            ];

            if (!$doj) continue;

            /* ----------------------------
                FILTER STAFF LEADS
            -----------------------------*/
            $staff_leads = $all_leads->where('created_by', $staff->sno);
            $staff_conversions = $all_conversions->where('created_by', $staff->sno);

            /* ----------------------------
                YEARLY
            -----------------------------*/
            $yearlyData[$staff->sno][$year]['lead_count'] = $staff_leads->count();
            $yearlyData[$staff->sno][$year]['conversion_count'] = $staff_conversions->count();

            /* ----------------------------
                MONTHLY + DAILY
            -----------------------------*/
            foreach ($months as $m => $mName) {

                $monthly_leads = $staff_leads->filter(fn($l) => date('n', strtotime($l->registered_date)) == $m);
                $monthly_conversions = $staff_conversions->filter(fn($c) => date('n', strtotime($c->transaction_date)) == $m);

                $monthlyData[$staff->sno][$year][$m]['lead_count'] = $monthly_leads->count();
                $monthlyData[$staff->sno][$year][$m]['conversion_count'] = $monthly_conversions->count();

                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $m, $year);

                for ($d = 1; $d <= $daysInMonth; $d++) {

                    $dailyData[$staff->sno][$year][$m][$d]['lead_count'] =
                        $monthly_leads->filter(fn($l) => date('j', strtotime($l->registered_date)) == $d)->count();

                    $dailyData[$staff->sno][$year][$m][$d]['conversion_count'] =
                        $monthly_conversions->filter(fn($c) => date('j', strtotime($c->transaction_date)) == $d)->count();
                }
            }
        }

        return [
            'staff_details' => $staff_details,
            'daily' => $dailyData,
            'monthly' => $monthlyData,
            'yearly' => $yearlyData,
        ];
    }
}
