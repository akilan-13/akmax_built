<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CompanyTypeModel;
use Carbon\Carbon;

class Company_type extends Controller
{
    public function index()
    {
        $Department = CompanyTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        // return $Department;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.base_settings.company_type', [
            'ListTable' => $Department,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'company_name' => 'required'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->company_name;
            $company_des = $request->company_des;
            $company_slug = $request->company_slug;

            $user_id = 1;
            $chk = CompanyTypeModel::where('company_type_name', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Company Type Name Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $category_check = CompanyTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'CT-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('CT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new CompanyTypeModel();
                $add_company->company_type_id = $company_id;
                $add_company->company_type_name = Ucfirst($company_name);
                $add_company->company_type_desc = $company_des;
                $add_company->branch_id = 1;
                $add_company->slug_name = $company_slug;
                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Company type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Company type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Edit($id)
    {
        $editcompany = CompanyTypeModel::where('sno', $id)->first();

        return view('content.settings.base_settings.company_type', [
            'editcompany' => $editcompany,
            'id' => $id,
        ]);
    }
    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'company_name' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->company_name;
            $company_slug = $request->company_slug;
            $company_type_desc = $request->company_des;
            $sno = $request->edit_id;
            $chk = CompanyTypeModel::where('company_type_name', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Company Type Name Already Exists!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = CompanyTypeModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->company_type_name = Ucfirst($company_name);
                $upd_CompanyTypeModel->slug_name = $company_slug;
                $upd_CompanyTypeModel->company_type_desc = $company_type_desc;
                $upd_CompanyTypeModel->branch_id = 1;
                $upd_CompanyTypeModel->slug_name = $company_slug;
                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Company Type Updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Company type!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = CompanyTypeModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = CompanyTypeModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}