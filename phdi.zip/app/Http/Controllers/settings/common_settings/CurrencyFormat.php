<?php

namespace App\Http\Controllers\settings\common_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CurrencyFormatModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\CurrencyRateModel;
use Carbon\Carbon;

class CurrencyFormat extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    $currency_format = CurrencyFormatModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    
   $currencyRate = CurrencyRateModel::orderBy('sno', 'desc')->first();
            $currencyData=[];
        foreach ($currency_format as $format) {
            if($currencyRate){
                $currencyData = json_decode($currencyRate->currency_data, true);
                
                $code = $format->currency_code;

                if (isset($currencyData[$code]) && $currencyData[$code] != 0) {
                    $rate = 1 / $currencyData[$code]; // Convert to INR
                } else {
                    $rate = 1; // Handle missing or zero rate
                }
                $format->rate_per=$rate;
            }
        }
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.settings.common_setting.currency_format', [
      'currency_format' => $currency_format
    ]);
  }
  
  public function List()
  {
    $sms_template = CurrencyFormatModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
      $description = $request->description;
      $user_id = $request->user()->user_id ?? 1;
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      }

      $add_currencyformat = new CurrencyFormatModel();
      $add_currencyformat->country_name = $country_name;
      $add_currencyformat->currency_code = $currency_code;
      $add_currencyformat->currency_name = $currency_name;
      $add_currencyformat->currency_symbol = $currency_symbol;
      $add_currencyformat->description = $description;

      $add_currencyformat->save();

      if ($add_currencyformat) {

        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Currency Format added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Currency Format!'
        ]);
      }
      return redirect()->back();
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
      $description = $request->description;
      $edit_id = $request->edit_id;
      $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $edit_id)->first();
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      } else {
        $upd_CurrencyFormatModel->country_name = $country_name;
        $upd_CurrencyFormatModel->currency_code = $currency_code;
        $upd_CurrencyFormatModel->currency_name = $currency_name;
        $upd_CurrencyFormatModel->currency_symbol = $currency_symbol;
        $upd_CurrencyFormatModel->description = $description;

        $upd_CurrencyFormatModel->update();

        if ($upd_CurrencyFormatModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Currency Format Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Currency Format!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = 2;
    $upd_CurrencyFormatModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = $request->input('status', 0);
    $upd_CurrencyFormatModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  
   public function updateCurrencyRates()
        {
            $previousDay = Carbon::yesterday()->format('Y-m-d');
        
            // ✅ Step 1: Check if today's data already exists
            $existing = CurrencyRateModel::where('date', $previousDay)->first();
        
            if ($existing) {
                return response()->json([
                    'message' => "Currency data for {$previousDay} already exists. No API call made."
                ], 200);
            }
        
            // ✅ Step 2: Fetch from API only if not in DB
            $url = "https://api.currencyapi.com/v3/latest?apikey=cur_live_I3Kx5s9wIIiZdaQoBQJlbw73LSIpRcjXjiKM92ya&base_currency=INR";
        
            $response = Http::get($url);
        
            if (!$response->ok()) {
                Log::error('Failed to fetch data from currency API.');
                return response()->json(['error' => 'Failed to fetch currency data.'], 500);
            }
        
            $data = $response->json();
        
            $lastUpdated = $data['meta']['last_updated_at']; // e.g. "2025-08-24T23:59:59Z"
            $dateOnly = substr($lastUpdated, 0, 10);         // Should match $today
            $dateTimeFormatted = Carbon::parse($lastUpdated)->format('Y-m-d H:i:s');
        
            $currencies = $data['data'];
            $currencyDataArray = [];
        
            foreach ($currencies as $currency) {
                $currencyDataArray[$currency['code']] = $currency['value'];
            }
        
            // ✅ Step 3: Save to DB
            CurrencyRateModel::create([
                'date' => $dateOnly,
                'date_time' => $dateTimeFormatted,
                'currency_data' => json_encode($currencyDataArray),
            ]);
        
            return response()->json([
                'message' => "Currency data saved for date {$dateOnly}."
            ], 201);
        }
        
        public function convertCurrency(Request $request)
        {
            $amount = $request->input('amount');
            $fromCurrency = $request->input('from_currency');
            $toCurrency = $request->input('to_currency');
            $helper = new \App\Helpers\Helpers();
            $convertedAmount =$helper->ConvertedAmountAny($fromCurrency, $toCurrency, $amount);
        
            return response()->json([
                'success' => true,
                'amount'  => $convertedAmount
            ]);
        }
  
  
}
