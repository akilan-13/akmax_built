<?php

namespace App\Http\Controllers\settings\common_settings;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\IntegrationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class Integration extends Controller
{
    public function index() {

        $integrations = IntegrationModel::where('status', '!=', 2)->get();
        $branches = BranchModel::where('status', '!=', 2)->pluck('branch_name', 'sno');

        return view('content.settings.common_setting.integration', compact('integrations', 'branches'));
    }

    public function Create(Request $request) {
        $validator = Validator::make($request->all(), [
            'api_name' => 'required|string'
        ]);

        if($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $name_check = IntegrationModel::where('api_name', $request->api_name)->where('status', '!=', 2)->first();

        if($name_check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'API Name Already Exists !'
            ]);
        }

        $user_id = $request->user()->user_id;

        $upd_integration = new IntegrationModel();
        $upd_integration->api_name = $request->api_name;
        $upd_integration->branch_id = json_encode($request->branch_name);
        $upd_integration->entity_id = $request->entity_id;
        $upd_integration->api_key = $request->api_key;
        $upd_integration->developer_link = $request->developer_link;
        
        // Image Upload
        if ( $request -> hasFile('api_image')) {
            $file = $request->file('api_image');

            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $path = 'settings/integrations/';

            $file->move(public_path($path), $fileName);
            $upd_integration->image = $fileName;
        }

        $upd_integration->created_by = $user_id;
        $upd_integration->updated_by = $user_id;
        $upd_integration->save();

        if($upd_integration) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Integration Added Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Integration Adding Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $integrations =  IntegrationModel::where('sno', $id)->first();
        $integrations->status = $request->input('status', 0);
        $integrations->update();

        if ($integrations) {
            return response([
                'status'    => 200,
                'message'   => 'Integration  Status Successfully Updated!',
                'error_msg' => 'Could not, update  Integration  Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Integration  Status!',
                'error_msg' => 'Could not, update  Integration  Status!',
                'data'      => null,
            ], 200);
        }
    }

    public function Delete($id)
    {
        $del_integration = IntegrationModel::where('sno', $id)->first();
        $del_integration->status = 2;
        $del_integration->update();



        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Edit($id)
    {
        $edit_integration = IntegrationModel::where('sno', $id)->where('status', '!=', 2)->first();
        if (!$edit_integration) {
            return response([
                'status' => 404,
                'message' => 'Integration not found',
                'error_msg' => 'No record found with the given ID.',
                'data' => null,
            ], 404);
        }

        return response([
            'status' => 200,
            'message' => 'Integration fetched successfully',
            'error_msg' => null,
            'data' => $edit_integration,
        ], 200);
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'api_name_edit' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $sno = $request->edit_id;

        $name_check = IntegrationModel::where('api_name', $request->api_name_edit)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($name_check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'API Name Already Exists !'
            ]);
        }

        $user_id = $request->user()->user_id;

        $upd_integration = IntegrationModel::where('sno', $sno)->where('status', '!=', 2)->first();
        $upd_integration->api_name = $request->api_name_edit;
        $upd_integration->branch_id = json_encode($request->branchId_edit);
        $upd_integration->entity_id = $request->entityId_edit;
        $upd_integration->api_key = $request->api_key_edit;
        $upd_integration->developer_link = $request->developer_link_edit;

        // return $request->hasFile('image_upload_edit');

        // Image Upload
        if ($request->hasFile('image_upload_edit')) {
            $file = $request->file('image_upload_edit');

            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $path = 'settings/integrations/';

            $file->move(public_path($path), $fileName);
            $upd_integration->image = $fileName;
        }

        $upd_integration->updated_by = $user_id;
        $upd_integration->update();

        if ($upd_integration) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Integration Updated Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Integration Updation Failed!'
            ]);

            return redirect()->back();
        }
    }
}
