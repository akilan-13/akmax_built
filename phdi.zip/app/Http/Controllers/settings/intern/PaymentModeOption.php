<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentOptionModel;
use App\Models\PaymentModeModel;
use Illuminate\Support\Facades\Validator;

class PaymentModeOption extends Controller
{


    public function index()
    {

        $Paymentmode = PaymentOptionModel::select('et_payment_option.payment_mode_id', 'et_payment_option.sno AS mode_sno','et_payment_option.payment_option_id',
            'et_payment_option.field_name','et_payment_option.field_value','et_payment_option.field_option','et_payment_option.is_depends',
            'et_payment_mode.paymentmode_name', 'et_payment_option.depends_on', 'et_payment_option.is_mandatory', 'et_payment_option.created_by',
            'et_payment_option.status', 'et_payment_option.created_at', 'et_payment_option.updated_at', 'et_payment_option.updated_by', 'et_payment_mode.paymentmode_name')
            ->leftjoin('et_payment_mode', 'et_payment_option.payment_mode_id', '=', 'et_payment_mode.sno')
            ->where('et_payment_option.status', '!=', 2)
            ->groupBy('et_payment_option.payment_mode_id', 'et_payment_option.sno','et_payment_option.payment_option_id',
            'et_payment_option.field_name','et_payment_option.field_value','et_payment_option.field_option','et_payment_option.is_depends',
            'et_payment_mode.paymentmode_name', 'et_payment_option.depends_on', 'et_payment_option.is_mandatory', 'et_payment_option.created_by',
            'et_payment_option.status', 'et_payment_option.created_at', 'et_payment_option.updated_at', 'et_payment_option.updated_by', 
            'et_payment_mode.sno','et_payment_mode.paymentmode_id', 'et_payment_mode.branch_id', 'et_payment_mode.paymentmode_name', 
            'et_payment_mode.paymentmode_desc', 'et_payment_mode.created_at','et_payment_mode.created_by', 'et_payment_mode.updated_at', 
            'et_payment_mode.updated_by','et_payment_mode.status')
            ->orderBy('et_payment_option.sno', 'desc')
            ->get();

        $groupedModes = $Paymentmode->groupBy('payment_mode_id');

        $pageConfigs = ['myLayout' => 'default'];

        // return $Paymentmode;

        return view('content.settings.payment_mode_option.payment_mode_option_list', [
            'Paymentmode' => $Paymentmode,
            'pageConfigs' => $pageConfigs,
            'groupedModes' => $groupedModes
        ]);
    }

    public function ListDisplay($id, Request $request)
    {
        $customer_type_id = $id;

        $options = PaymentOptionModel::select(
            'et_payment_mode.paymentmode_name',
            'et_payment_option.sno as payment_mode_option_id',
            'et_payment_mode.sno as payment_mode_id',
            'et_payment_option.payment_option_id',
            'et_payment_option.field_name',
            'et_payment_option.field_value',
            'et_payment_option.field_option',
            'et_payment_option.is_depends',
            'et_payment_option.depends_on',
            'et_payment_option.is_mandatory',
            'et_payment_option.created_by',
            'et_payment_option.created_at',
            'et_payment_option.updated_by',
            'et_payment_option.updated_at',
            'et_payment_option.status'
        )
            ->join('et_payment_mode', 'et_payment_option.payment_mode_id', '=', 'et_payment_mode.sno')
            ->where('et_payment_option.payment_mode_id', $customer_type_id)
            ->where('et_payment_option.status', 0) // Assuming status check for active records
            ->orderBy('et_payment_option.sno', 'asc') // Order by sno ascending to maintain order
            ->get();

        $result = $options->map(function ($item) {
            // Process dependencies
            $dependsOnArray = $item->depends_on ? json_decode($item->depends_on, true) : [];

            return [
                'payment_mode_id' => $item->payment_mode_id,
                'payment_option_id' => $item->payment_option_id,
                'paymentmode_name' => $item->paymentmode_name,
                'payment_mode_option_id' => $item->payment_mode_option_id,
                'field_name' => $item->field_name,
                'field_value' => $item->field_value,
                'field_option' => $item->field_option ? json_decode($item->field_option, true) : [],
                'is_depends' => $item->is_depends,
                'depends_on' => $dependsOnArray,
                'is_mandatory' => $item->is_mandatory,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    public function View($id)
    {
        $cus_ids = explode(',', $id);

        // Get the first value from the array
        $cus_type_opt_id = $cus_ids[0];

        $editcategory = PaymentOptionModel::where('sno', $cus_type_opt_id)->first();
        $option = PaymentOptionModel::select(
            'et_customer_type.customer_type_name',
            'et_customer_type.sno as customer_type_id',
            'et_customer_type_option.cus_type_opt_id',
            'et_customer_type_option.field_name',
            'et_customer_type_option.field_value',
            'et_customer_type_option.field_option',
            'et_customer_type_option.is_depends',
            'et_customer_type_option.depends_on',
            'et_customer_type_option.is_mandatory',
            'et_customer_type_option.created_by',
            'et_customer_type_option.created_at',
            'et_customer_type_option.updated_by',
            'et_customer_type_option.updated_at',
            'et_customer_type_option.status'
        )
            ->join('et_customer_type', 'et_customer_type_option.customer_type_id', '=', 'et_customer_type.sno')
            ->where('et_customer_type_option.cus_type_opt_id', $editcategory->cus_type_opt_id)
            ->where('et_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('et_customer_type_option.sno', 'asc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            $fieldOptions = $items->pluck('field_option')->map(function ($option) {
                return json_decode($option);
            })->toArray();

            return [
                'customer_type_name' => $firstItem->customer_type_name,
                'fields' => $items->map(function ($item) {
                    return [
                        'field_name' => $item->field_name,
                        'field_value' => $item->field_value,
                        'field_option' => json_decode($item->field_option, true),
                        'is_depends' => $item->is_depends,
                        'depends_on' => $item->depends_on,
                        'is_mandatory' => $item->is_mandatory,
                    ];
                })->toArray()
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_mode_id' => 'required|max:255',
            'label_names' => 'required|array',
            'label_values' => 'required|array',
            'options' => 'required|array',
            'options.*.*.label' => 'nullable', // Allow label to be nullable
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields!'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            $payment_mode_id = $request->payment_mode_id;
            $user_id = $request->user()->user_id; // Assuming user ID is 1 for simplicity
            $payment_option_id = $this->generateCustomerTypeOptionId();

            $allOptions = [];
            // Iterate through label names and values
            foreach ($request->label_names as $index => $label_name) {
                $field_name = ucfirst($label_name);
                $field_value = $request->label_values[$index];
                $field_options = [];

                foreach ($request->options[$index] as $optionIndex => $option) {
                    if (!empty($option['label'])) {
                        $option_label = $option['label'];
                        $option_value = $optionIndex;
                        $allOptions[] = $option_value;

                        $field_options[] = [
                            'value' => $option_value,
                            'label' => $option_label,
                        ];
                    }
                }

                $is_depends = isset($request->depends[$index]) ? 1 : 0;
                $is_mandatory = isset($request->mandatory[$index]) ? 1 : 0;

                $add_category = new PaymentOptionModel();
                $add_category->payment_option_id = $payment_option_id;
                $add_category->payment_mode_id = $payment_mode_id;
                $add_category->field_name = $field_name;
                $add_category->field_value = $field_value;
                $add_category->field_option = empty($field_options) ? null : json_encode($field_options);
                $add_category->is_depends = $is_depends;
                $add_category->is_mandatory = $is_mandatory;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;


                if ($is_depends && isset($request->depends_checkbox[$index])) {
                    $dependency_label = $request->depends_checkbox[$index];
                    $dependency_value = '';

                    // Iterate through label names and values to find the matching option
                    foreach ($request->label_names as $optIndex => $label_name) {
                        foreach ($request->options[$optIndex] as $optionIndex => $option) {
                            if ($option['label'] == $dependency_label) {
                                $dependency_value = $optionIndex;
                                break 2; // Exit both foreach loops once match is found
                            }
                        }
                    }

                    // Construct depends_on as JSON array
                    $depends_on = [];
                    if ($dependency_value !== '') {
                        $depends_on[] = [
                            'value' => $dependency_value,
                            'label' => $dependency_label,
                        ];
                    }

                    $add_category->depends_on = json_encode($depends_on);
                }


                $add_category->save();
            }

            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Payment Mode Option added Successfully!'
            ]);

            return redirect()->route('settings-sales-payment-mode-option');
        }
    }

    private function generateCustomerTypeOptionId()
    {
        $latestRecord = PaymentOptionModel::orderBy('sno', 'desc')->first();

        if (!$latestRecord) {
            $year = substr(date("y"), -2);
            $payment_option_id = "PMO-0001/" . $year;
        } else {
            $latestId = $latestRecord->payment_option_id;
            $year = substr(date("y"), -2);

            // Extract numeric part from the latest ID
            preg_match('/PMO-(\d{4})\/\d{2}/', $latestId, $matches);
            $nextNumber = intval($matches[1]) + 1;

            // Format the new ID
            $newId = sprintf("PMO-%04d", $nextNumber);
            $payment_option_id = $newId . '/' . $year;
        }

        return $payment_option_id;
    }


    public function Delete($id)
    {
        // return $id;
        $upd_PaymentModeModel = PaymentOptionModel::where('sno', $id)->first();
        $upd_PaymentModeModel->status = 2;
        // return $upd_PaymentModeModel;
        $upd_PaymentModeModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        // return $request;
        $upd_PaymentModeModel = PaymentOptionModel::where('sno', $id)->first();
        $upd_PaymentModeModel->status = $request->status;
        // return $upd_PaymentModeModel;
        $upd_PaymentModeModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }   

    public function AddIndex()
    {
        return view('content.settings.payment_mode_option.add');
    }

    public function EditIndex($id, Request $request)
    {
        // return $id;
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        // return $decryptedValue;

        $PaymentModeOption = PaymentOptionModel::select('et_payment_option.*', 'et_payment_mode.paymentmode_name')
            ->leftjoin('et_payment_mode', 'et_payment_option.payment_mode_id', '=', 'et_payment_mode.sno')
            ->where('et_payment_option.status', '!=', 2)
            ->where('et_payment_option.sno', $decryptedValue)
            ->orderBy('et_payment_option.sno', 'desc')
            ->first();

        // return $PaymentModeOption;

        $paymentMode = PaymentModeModel::select('*')->where('status', '!=', 2)->get();
        
        // return $paymentMode;
        
        return view('content.settings.payment_mode_option.edit', [
            'decryptedValue' => $decryptedValue,
            'payment_mode_option'   => $PaymentModeOption,
            'payment_mode'  => $paymentMode
        ]);
    }

    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'payment_option_id' => 'required|max:255',// Allow label to be nullable
        ]);

        
        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields!'
            ]);
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            $payment_mode_id = $request->payment_mode_id;
            $payment_sno = $request->payment_option_id;
            $user_id = $request->user()->user_id; // Assuming user ID is 1 for simplicity

            $payment_mode_option = PaymentOptionModel::select('*')->where('sno', $payment_sno)->first();

            // return json_encode($request->options);

            $formattedOptions = [];

            // Loop through the options and convert to key-value pairs
            foreach ($request->options as $option) {
                // $option will be something like {"option0":"option 1 of 0 index"}
                foreach ($option as $key => $value) {
                    $formattedOptions[$key] = $value;
                }
            }


            if($payment_mode_option){
                $payment_mode_option->payment_mode_id = $payment_mode_id;
                $payment_mode_option->field_name = $request->field_name;
                $payment_mode_option->field_value = $request->payment_mode_option_label_value_edit;
                $payment_mode_option->field_option = empty($formattedOptions) ? null : json_encode($formattedOptions);
                // $payment_mode_option->is_depends = $is_depends;
                $payment_mode_option->is_mandatory = $request->mandatory ?? 0;
                $payment_mode_option->created_by = $user_id;
                $payment_mode_option->updated_by = $user_id;
                // return $payment_mode_option;
                $payment_mode_option->update();
            }else{
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Payment Mode Option not available !'
                ]);
                return redirect()->route('settings-sales-payment-mode-option');
            }

            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Payment Mode Option updated Successfully!'
            ]);

            return redirect()->route('settings-sales-payment-mode-option');
        }

    }
}