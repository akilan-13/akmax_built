<?php

namespace App\Http\Controllers\settings\intern;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InternCompanyModel;
use Illuminate\Support\Facades\Validator;

class InternCompany extends Controller
{


    public function index()
    {
        $letterPad = InternCompanyModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.intern.company.company_list', [
            'letterPad' => $letterPad,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List(Request $request)
    {
        $branch_id = (string) $request->user()->branch_id;

        $allPads = InternCompanyModel::where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        $filtered = $allPads->filter(function ($item) use ($branch_id) {
            $branchIds = json_decode($item->branch_id, true); // decode the string
            return in_array((string)$branch_id, $branchIds ?? []);
        });

        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $filtered->values()
        ], 200);
    }

    public function Add(Request $request)
    {
        // Validate required inputs
        $validator = Validator::make($request->all(), [
            'company' => 'required|max:255',
            'email' => 'nullable|email',
            // You can add validation for images if needed like:
            // 'header_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            // 'footer_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            // 'logo_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            // 'signature' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        $company     = $request->company;
        $email       = $request->email;
        $phone       = $request->phone;
        $short_code = $request->short_code;
        $letter_desc = $request->letter_desc;
        $logo_width = $request->logo_width;
        $logo_height = $request->logo_height;

        $branchId = $request->branchId;
        $user_id     = $request->user()->user_id;

        // Check for the latest serial number
        $latestRecord = InternCompanyModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        $sno = $latestRecord ? $latestRecord->sno + 1 : 1;

        // Check if company already exists
        $existingCompany = InternCompanyModel::where('company', ucwords($company))
            ->where('status', '!=', 2)
            ->first();

        if ($existingCompany) {
            return response([
                'status'    => 401,
                'message'   => 'Error',
                'error_msg' => 'Name has already been created!',
                'data'      => null,
            ], 200);
        }

        // Initialize image variables
        $header_image = null;
        $footer_image = null;
        $logo_image = null;
        $signature = null;

        // Handle image uploads
        if ($request->hasFile('header_image')) {
            $header_image = 'header_' . $sno . '.' . $request->file('header_image')->extension();
            $request->file('header_image')->move(public_path('header_image'), $header_image);
        }

        if ($request->hasFile('footer_image')) {
            $footer_image = 'footer_' . $sno . '.' . $request->file('footer_image')->extension();
            $request->file('footer_image')->move(public_path('footer_image'), $footer_image);
        }

        if ($request->hasFile('logo_image')) {
            $logo_image = 'logo_' . $sno . '.' . $request->file('logo_image')->extension();
            $request->file('logo_image')->move(public_path('logo_image'), $logo_image);
        }

        if ($request->hasFile('signature')) {
            $signature = 'signature_' . $sno . '.' . $request->file('signature')->extension();
            $request->file('signature')->move(public_path('signature'), $signature);
        }

        // Save new InternCompanyModel record
        $add_letter = new InternCompanyModel();
        $add_letter->company         = ucfirst($company);
        $add_letter->letter_pad_desc = $letter_desc;
        $add_letter->branch_id           = json_encode($branchId);
        $add_letter->logo_width = $logo_width;
        $add_letter->logo_height = $logo_height;
        $add_letter->email           = $email;
        $add_letter->phone           = $phone;
        $add_letter->letter_header   = $header_image;
        $add_letter->letter_footer   = $footer_image;
        $add_letter->letter_logo     = $logo_image;
        $add_letter->signature       = $signature;
        $add_letter->short_code      = $short_code;
        $add_letter->created_by      = $user_id;
        $add_letter->updated_by      = $user_id;

        if ($add_letter->save()) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Company added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Company!'
            ]);
        }

        return redirect()->back();
    }

    public function Edit($id)
    {
        $editcategory = InternCompanyModel::where('sno', $id)->first();

        return view('content.settings.intern.letter_pad.letter_pad_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {
        // Validation rules including optional image validations
        $validator = Validator::make($request->all(), [
            'company'       => 'required|max:255',
            'email'         => 'nullable|email|max:255',
            'logo_width'    => 'nullable|integer|min:1',
            'logo_height'   => 'nullable|integer|min:1',
            'header_image'  => 'nullable|image|mimes:jpeg,png,jpg|max:800',  // max size in KB
            'footer_image'  => 'nullable|image|mimes:jpeg,png,jpg|max:800',
            'logo_image'    => 'nullable|image|mimes:jpeg,png,jpg|max:800',
            'signature_image' => 'nullable|image|mimes:jpeg,png,jpg|max:800',
        ]);

        if ($validator->fails()) {
            return response([
                'status'    => 401,
                'message'   => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        }

        // Extract inputs
        $company = $request->company;
        $letter_pad_desc = $request->letter_pad_desc;
        $company_id = $request->company_id;
        $email = $request->email;
        $phone = $request->phone;
        $logo_width = $request->logo_width;
        $logo_height = $request->logo_height;
        $edit_id = $company_id;
        $branchId = $request->branchId;
        $short_code = $request->edit_short_code;

        // Check duplicate company name except current record
        $chk = InternCompanyModel::where('company', ucwords($company))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $company_id)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name has already been assigned!'
            ]);
            return redirect()->back();
        }

        // Fetch existing model record
        $upd_CourseCategoryModel = InternCompanyModel::where('sno', $company_id)->first();

        if (!$upd_CourseCategoryModel) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Company record not found!'
            ]);
            return redirect()->back();
        }

        // Update basic fields
        $upd_CourseCategoryModel->company = ucfirst($company);
        $upd_CourseCategoryModel->phone = $phone;
        $upd_CourseCategoryModel->letter_pad_desc = $letter_pad_desc;
        $upd_CourseCategoryModel->email = $email;
        $upd_CourseCategoryModel->branch_id           = json_encode($branchId);
        $upd_CourseCategoryModel->logo_height = $logo_height;
        $upd_CourseCategoryModel->logo_width = $logo_width;
        $upd_CourseCategoryModel->short_code = $short_code;

        // Handle header image upload
        if ($request->hasFile('header_image')) {
            $fileName = 'header_' . $edit_id . '.' . $request->file('header_image')->extension();
            $request->file('header_image')->move(public_path('header_image'), $fileName);
            $upd_CourseCategoryModel->letter_header = $fileName;
        }

        // Handle footer image upload
        if ($request->hasFile('footer_image')) {
            $fileName = 'footer_' . $edit_id . '.' . $request->file('footer_image')->extension();
            $request->file('footer_image')->move(public_path('footer_image'), $fileName);
            $upd_CourseCategoryModel->letter_footer = $fileName;
        }

        // Handle logo image upload
        if ($request->hasFile('logo_image')) {
            $fileName = 'logo_' . $edit_id . '.' . $request->file('logo_image')->extension();
            $request->file('logo_image')->move(public_path('logo_image'), $fileName);
            $upd_CourseCategoryModel->letter_logo = $fileName;
        }

        // Handle signature image upload
        if ($request->hasFile('signature_image')) {
            $fileName = 'signature_' . $edit_id . '.' . $request->file('signature_image')->extension();
            $request->file('signature_image')->move(public_path('signature'), $fileName);
            $upd_CourseCategoryModel->signature = $fileName;
        }

        // Save the updated model
        $updated = $upd_CourseCategoryModel->update();

        if ($updated) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Company Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the Company!'
            ]);
        }

        return redirect()->back();
    }


    public function Delete($id)
    {
        $upd_CourseCategoryModel =  InternCompanyModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Company Successfully Deleted!',
            'error_msg' => 'Could not Delete Company!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  InternCompanyModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
