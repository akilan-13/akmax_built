<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductDelivarablesModel;
use Illuminate\Support\Facades\Validator;

class Product_delivarables extends Controller
{
    public function index()
    {
        $delivarables = ProductDelivarablesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.product_settings.delivarables', compact('delivarables'));
    }

    public function create(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'delivarable_name' => 'required|array',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format input field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $delivarable_name = $request->input('delivarable_name');

        foreach ($delivarable_name as $delivarable_names) {
            $check = ProductDelivarablesModel::where('delivarable_name', ucwords($delivarable_names))->where('status', '!=', 2)->first();


        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Name is exist!'
            ]);
           continue;
        }

        $delivarables = new ProductDelivarablesModel();
        $delivarables->delivarable_name = $delivarable_names;
            $delivarables->created_by = $user_id;
            $delivarables->updated_by = $user_id;
            $delivarables->save();


        if ($delivarables) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product Delivarable added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Product Delivarable!'
                    ]);
                }
    }
         
       return redirect()->back();
}

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_delivarable' => 'required|max:255|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Format Input Field',
                'error-msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);
        } else {
            $edit_delivarable = $request->edit_delivarable;
            $sno = $request->edit_id;

            $check = ProductDelivarablesModel::where('delivarable_name', ucwords($edit_delivarable))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Alreaady Name Exists'
                ]);
                return redirect()->back();
            } else {
                $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $sno)->first();
                $upd_DelivarableModel->delivarable_name = Ucfirst($edit_delivarable);


                $upd_DelivarableModel->update();

                if ($upd_DelivarableModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Delivarable Updated Succesfully',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Delivarable '
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {

        $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $id)->first();
        $upd_DelivarableModel->status = $request->input('status', 0);
        $upd_DelivarableModel->update();
        if ($upd_DelivarableModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }


    public function Delete($id)
    {
        $upd_DelivarableModel = ProductDelivarablesModel::where('sno', $id)->first();
        $upd_DelivarableModel->status = 2;
        $upd_DelivarableModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}
