<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\NotesModel;
use Illuminate\Support\Facades\Validator;




Class Notes extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';

        $query=DB::table('et_notes')
          ->select('et_notes.*','et_entity.entity_name')
          ->Join('et_entity', 'et_entity.sno', '=', 'et_notes.entity_id')
          ->where('et_notes.status','!=',2);

          if($search_filter != '') {
            $query->where(function ($list) use ($search_filter) {
              $list->where('et_notes.notes_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('et_entity.entity_name', 'LIKE', "%{$search_filter}%");
            });
          }
          
        $notes_list=$query->paginate($perpage);
        return view('content.settings.product_settings.notes',[
            'notes_list' => $notes_list,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

     public function List(Request $request)
  {


      $entity_id = $request->input('entity_id');

      $notes = NotesModel::where('status', 0)->where('entity_id', $entity_id)
          ->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $notes
      ], 200);
  }

    public function Edit($id){

        $notes = NotesModel::where('sno', $id)->where('status', '!=', 2)->first();

    
        return  response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $notes
        ], 200);


    }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'notes_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $notes_name                   = $request->notes_name;
      $notes_details                   = $request->notes_details;
      $entity_id                 = $request->entity_id;

      $user_id                    = $request->user()->user_id ?? 1;
      $branch_id                    = $request->user()->branch_id ?? 1;
      $chk = NotesModel::where('notes_name', $notes_name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
      } else {
        $category_check = NotesModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $notes_id = "NT-0001/" . $year;
        } else {

          $data = $category_check->notes_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("NT-%04d", $next_number);

          $year = substr(date("y"), -2);
          $notes_id = $request . '/' . $year;
        }

        $add_category = new NotesModel();
        $add_category->notes_id  = $notes_id;
        $add_category->notes_name = $notes_name;
        $add_category->notes_details = $notes_details;
        $add_category->branch_id = $branch_id;
        $add_category->entity_id = $entity_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Notes added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Notes!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Notes Created successfully!');
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'notes_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $notes_name                   = $request->notes_name;
      $notes_details                   = $request->notes_details;
      $entity_id                 = $request->entity_id;

      $upd_CourseCategoryModel =  NotesModel::where('sno', $id)->first();

      $chk = NotesModel::where('notes_name', $notes_name)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Notes has been  already assigned!'
        ]);
        return redirect()->back();
      } else {

        $upd_CourseCategoryModel->notes_name  = $notes_name;
        $upd_CourseCategoryModel->notes_details  = $notes_details;
        $upd_CourseCategoryModel->entity_id  = $entity_id;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Notes updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Notes !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  NotesModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  NotesModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}