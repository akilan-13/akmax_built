<?php

namespace App\Http\Controllers\settings\product_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductVariableModel;
use Illuminate\Support\Facades\Validator;
use App\Models\Product_Variant_Model;

class ProductVariable extends Controller
{
    public function index()
    {
        $varient = Product_Variant_Model::where('status', 0)->get();
        $University = ProductVariableModel::where('et_product_variable.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('et_product_variable.*','et_product_variant.product_variant_name as servicevarientname')
      ->leftJoin('et_product_variant','et_product_variable.service_varientid','et_product_variant.sno')
      ->orderBy('et_product_variable.sno', 'desc')->get();
        // return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.product_settings.product_variable', [
            'ListTable' => $University,
            'varient_list'=>$varient,
            'pageConfigs' => $pageConfigs

        ]);
    }
    public function Add(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'service_variablename' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->service_variablename;
            $company_des = $request->service_des;
            $servicevarient = $request->servicevarientid;
            $mincost = $request->mincost;
            $maxcost = $request->maxcost;


            $user_id = 1;
            $chk = ProductVariableModel::where('service_variablename', ucwords($company_name))->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Variable is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = ProductVariableModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $company_id = 'SV-0001/' . $year;
                } else {

                    $data = $category_check->company_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf('SV-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $company_id = $request . '/' . $year;
                }

                $add_company = new ProductVariableModel();

                $add_company->service_variablename = Ucfirst($company_name);
                $add_company->service_des = $company_des;
                $add_company->servicevariable_id = $company_id;
                $add_company->service_varientid = $servicevarient;
                $add_company->min_cost = $mincost;
                $add_company->max_cost = $maxcost;
                $add_company->created_by = $user_id;
                $add_company->updated_by = $user_id;

                $add_company->save();

                if ($add_company) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product Variable added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Product Variable!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = ProductVariableModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Edit($id)
  {
    $role = ProductVariableModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }
    public function Update(Request $request)
    {
        //return $request;
        $validator = Validator::make($request->all(), [
            'edit_service_categoryname' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $company_name = $request->edit_service_categoryname;
            $service_id = $request->edit_servicevarientid;
            $maxcost = $request->edit_maxcost;
            $mincost = $request->edit_mincost;

            $company_type_desc = $request->edit_des;
            $sno = $request->edit_id;
            $chk = ProductVariableModel::where('service_variablename', ucwords($company_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();


            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Variable is exist!'
                ]);
                return redirect()->back();
            } else {
                $upd_CompanyTypeModel = ProductVariableModel::where('sno', $sno)->first();
                $upd_CompanyTypeModel->service_variablename = Ucfirst($company_name);

                $upd_CompanyTypeModel->service_des = $company_type_desc;
                $upd_CompanyTypeModel->service_varientid =  $service_id;
                $upd_CompanyTypeModel->max_cost =   $maxcost;
                $upd_CompanyTypeModel->min_cost =   $mincost;


                $upd_CompanyTypeModel->update();

                if ($upd_CompanyTypeModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Product Variable successfull updated !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Product Variable!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = ProductVariableModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Get_list()
    {
      // Retrieve the category ID from the POST request
      $dept_id = $_GET['id'] ?? '';

      $sub_department_list = ProductVariableModel::
        where('status', 0)
        ->where('service_varientid', $dept_id)
        ->orderBy('service_variablename', 'ASC')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $sub_department_list
      ], 200);
    }
    public function Get_list_by_id()
    {
      $id = $_GET['id'] ?? '';


      $sub_department_list = ProductVariableModel::where('sno', $id)->first();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $sub_department_list
      ], 200);
    }

}
