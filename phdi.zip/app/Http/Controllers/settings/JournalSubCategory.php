<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JournalSubCategoryModel;
use App\Models\JournalCategoryModel;
use Illuminate\Support\Facades\Validator;

class JournalSubCategory extends Controller
{
    public function index()
    {
      $Staff = JournalSubCategoryModel::where('et_journal_subcategory.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('et_journal_subcategory.*','et_journal_category.journal_category_name as journalname')
      ->leftJoin('et_journal_category','et_journal_subcategory.journal_category_id','et_journal_category.sno')
      ->orderBy('et_journal_subcategory.sno', 'desc')->get();

     // return $Staff;
      $pageConfigs = ['myLayout' => 'default'];
      return view('content.settings.journal.journal_subcategory', [
          'ListTable' => $Staff,
          'pageConfigs' => $pageConfigs
        ]);
    }
    public function Status($id, Request $request)
    {

        $upd_DepartmentModel = JournalSubCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();
        if ($upd_DepartmentModel) {
            return response([
                'status' => 200,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Successfully Status Updated!',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = JournalSubCategoryModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function List()
  {
    $user = JournalCategoryModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'journalsubcategoryname' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {



      $role_name          = $request->journalsubcategoryname;
      $role_des          = $request->journaldes;
      $user_role_id       = $request->select_service_id;
      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;
      $chk = JournalSubCategoryModel::where('journal_subcategoryname', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = JournalSubCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $role_id = "UR-0001/" . $year;
        } else {

          $data = $category_check->role_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("UR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $role_id = $request . '/' . $year;
        }


        $add_user = new JournalSubCategoryModel();

        $add_user->journal_subcategoryname         = Ucfirst($role_name);
        $add_user->journal_sub_des=$role_des;
        $add_user->journal_category_id      = $user_role_id;
        $add_user->created_by        = $user_id;
        $add_user->updated_by        = $user_id;

        $add_user->save();

        if ($add_user) {
            // Flash a success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'User Role added Successfully!'
            ]);

            // Store role_id and current time in the session
            session([
                'select_service_id' => $add_user->sno,
                'role_id_set_time' => now(),
            ]);

            // Redirect to the users manage add page
         
        } else {
            // Flash an error message
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the User Role!'
            ]);

            // Redirect back to the previous page
           
        }
         return redirect()->back();

      }

    }
  }
  public function Edit($id)
  {
    $role = JournalSubCategoryModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }
  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'journal_subcategoryname' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->journal_subcategoryname;
      $user_role_id       = $request->journal_category_id;
      $chk = JournalSubCategoryModel::where('journal_subcategoryname', ucwords($role_name))->where('sno', '!=', $id)->first();

      if ($chk) {
          $result = response([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has been  already assigned!',
            'data'      => null,

          ], 200);
          return redirect()->back();
        } else {
          $upd_user =  JournalSubCategoryModel::where('sno', $id)->first();
            $upd_user->journal_subcategoryname = Ucfirst($role_name);
              $upd_user->journal_category_id  = $user_role_id;
              $upd_user->update();


              if ($upd_user) {
                $result = response([
                  'status'    => 200,
                  'message'   => 'Successfully Updated!',
                  'error_msg' => null,
                  'data'      => null,
                ], 200);
              } else {
                $result = response([
                  'status'    => 401,
                  'message'   => 'Incorrect format input feilds',
                  'error_msg' => 'Incorrect format input feilds',
                  'data'      => null,
                ], 401);
              }
              return $result;
        }

    }

    // return redirect()->back();
  }

}
//content.settings.journal.journal_subcategory
