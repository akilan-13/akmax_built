<?php

namespace App\Http\Controllers\settings\journal_settings;

use App\Http\Controllers\Controller;
use App\Models\JournalIndexModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JournalIndex extends Controller
{
    public function index(){
        $indices = JournalIndexModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.journal.journal_index', compact('indices'));
    }

    public function create(Request $request){
        $validator = Validator::make($request->all(), [
            'index_name' => 'required|string',
        ]);

        if($validator->fails()){
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format.',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $name = $request->index_name;
        $user_id = $request->user()->user_id;

        // Check if the name is already exists
        $exists = JournalIndexModel::where('index_name', ucwords($name))->where('status', '!=', 2)->first();

        if($exists){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $create = new JournalIndexModel();
        $create->index_name = ucwords($name);
        $create->index_url = $request->index_link;
        $create->index_desc = $request->index_desc;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if($create){
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Journal Index Created Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Something Went Wrong !'
            ]);
        }

        return redirect()->back();
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format.',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 404);
        }

        $id = $request->edit_id;
        $name = $request->edit_name;
        $user_id = $request->user()->user_id;

        // Check if the name is already exists
        $exists = JournalIndexModel::where('index_name', ucwords($name))
            ->where('sno', '!=', $id)
            ->where('status', '!=', 2)->first();

        if ($exists) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists !'
            ]);

            return redirect()->back();
        }

        $Update = JournalIndexModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Update->index_name = ucwords($name);
        $Update->index_url = $request->edit_url;
        $Update->index_desc = $request->edit_desc;
        $Update->updated_by = $user_id;
        $Update->update();

        if ($Update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Journal Index Updated Successfully !'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Something Went Wrong !'
            ]);
        }

        return redirect()->back();
    }

    public function Status($id, Request $request)
    {
        $Status = JournalIndexModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = $request->input('status', 0);
        $Status->update();

        if ($Status) {
            return response([
                'status' => 200,
                'message' => 'Success! Your Journal Index Status Is Now Updated',
                'error_msg' => 'Failed to Change Journal Index Status. Please Try Again.',
                'data' => null
            ], 200);
        } else {
            return response([
                'status' => 401,
                'message' => 'Failed to Change Journal Index Status. Please Try Again.',
                'error_msg' => 'Failed to Change Journal Index Status. Please Try Again.',
                'data' => null
            ], 401);
        }
    }

    public function Delete($id)
    {
        $Delete = JournalIndexModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Delete->status = 2;
        $Delete->update();

        return response([
            'status' => 200,
            'message' => 'Journal Index Has Been Deleted Successfully',
            'error_msg' => 'Failed to Delete Journal Index. Please Try Again.',
            'data' => null
        ], 200);
    }
}
