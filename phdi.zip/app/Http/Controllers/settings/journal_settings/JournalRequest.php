<?php

namespace App\Http\Controllers\settings\journal_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DomainModel;
use App\Models\JournalRequestModel;
use Illuminate\Support\Facades\Validator;

class JournalRequest extends Controller
{
    public function index()
    {
        $requests = JournalRequestModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.journal.journal_request', compact('requests'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'request_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $name = $request->request_name;
        $desc = $request->request_desc;

        $checks = JournalRequestModel::where('request_name', ucwords($name))->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Journal Request Already Exists',
            ]);

            return redirect()->back();
        } else {
            $create = new JournalRequestModel();
            $create->request_name = $name;
            $create->request_desc = $desc;
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->save();

            if ($create) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Journal Request Created Succesfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Journal Request Creation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_request_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_request_name;
        $edit_desc = $request->edit_desc;

        // Check if the name is already exist
        $checks = JournalRequestModel::where('request_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if ($checks) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Journal Request Alredy Exixts',
            ]);

            return redirect()->back();
        } else {
            $update = JournalRequestModel::where('sno', $sno)->first();
            $update->request_name = $edit_name;
            $update->request_desc = $edit_desc;
            $update->updated_by = $user_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Journal Request Updated Succesfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Journal Request Updation Failed !',
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request)
    {
        $status = JournalRequestModel::where('sno', $id)->first();
        $status->status = $request->input('status', 0);
        $status->update();

        if ($status) {
            return response([
                'status' => 200,
                'message' => 'Status Changed Succesfully',
                'error_msg' => 'Status Changing Failed !',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Changing Failed',
                'error_msg' => null,
                'data' => null,
            ], 400);
        }
    }

    public function Delete($id)
    {
        $delete = JournalRequestModel::where('sno', $id)->first();
        $delete->status = 2;
        $delete->update();

        return response([
            'status' => 200,
            'message' => 'Journal Request Deleted Succesfully',
            'error_msg' => 'Journal Request Deletion Failed !',
            'data' => null,
        ]);
    }
}
