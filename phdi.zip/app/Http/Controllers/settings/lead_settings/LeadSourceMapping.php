<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\LeadSourceMappingModel;
use Illuminate\Http\Request;
use App\Models\LeadSourceModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class LeadSourceMapping extends Controller
{
    protected static $branch_id = 1;

    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $lead_source = LeadSourceMappingModel::where('et_lead_source_mapping.status', '!=', 2)
            ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_lead_source_mapping.branch_id')
            ->leftJoin('et_lead_source', 'et_lead_source.sno', '=', 'et_lead_source_mapping.source_id')
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead_source_mapping.staff_id')
            ->select(
                'et_lead_source_mapping.branch_id',
                'et_branch.branch_name',
                DB::raw('GROUP_CONCAT(DISTINCT et_lead_source.lead_source_name SEPARATOR ", ") as lead_source_names'),
                DB::raw('GROUP_CONCAT(DISTINCT et_staff.staff_name SEPARATOR ", ") as staff_names')
            )
            ->groupBy('et_lead_source_mapping.branch_id', 'et_branch.branch_name')
            ->orderBy('et_lead_source_mapping.sno', 'desc')
            ->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.lead_source_mapping', [
            'lead_source' => $lead_source,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function branch_dropdown_list()
    {
        $mappedBranchIds = LeadSourceMappingModel::where('status', '!=', 2)
            ->pluck('branch_id')
            ->toArray();

        $branch_data = BranchModel::where('status', 0)
            ->whereNotIn('sno', $mappedBranchIds)
            ->orderBy('sno', 'desc')
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $branch_data,
        ], 200);
    }


    public function List()
    {
        $CourseCategory = LeadSourceModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function lead_source_staff(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $data = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_job_position.job_position_name'
            )
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->where('et_staff.status', 0)
            ->where('et_staff.branch_id', $branch_id)
            ->where('et_staff.sno', '>', 1)
            ->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $data
        ], 200);
    }

    public function Add(Request $request)
    {

        $source_ids = $request->input('lead_source_id');
        $staff_ids = $request->input('staff_id');
        $branch_id = $request->branchId;

        foreach($source_ids as $i => $source_id) {
            $staff_id = $staff_ids[$i] ?? 0;

            $CREATE = new LeadSourceMappingModel();
            $CREATE->branch_id = $branch_id;
            $CREATE->source_id = $source_id;
            $CREATE->staff_id = $staff_id;
            $CREATE->created_by = $request->user()->user_id;
            $CREATE->updated_by = $request->user()->user_id;
            $CREATE->save();
        }

        // return $request;

        if($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Lead Source Mapping Created Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Lead Source Mapping Creation Failed!'
            ]);
        }

        return redirect()->back();
    }

    public function Edit($id)
    {
        $edit = LeadSourceMappingModel::where('branch_id', $id)->where('status', '!=', 2)->get();

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $edit
        ], 200);
    }

    public function edit_branch_list($id)
    {
        $mappedBranchIds = LeadSourceMappingModel::where('status', '!=', 2)
            ->where('branch_id', '!=', $id)
            ->pluck('branch_id')
            ->toArray();

        // Include current one
        $branch_data = BranchModel::where('status', 0)
            ->whereNotIn('sno', $mappedBranchIds)
            ->orderBy('sno', 'desc')
            ->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $branch_data,
        ], 200);
    }


    public function Update(Request $request)
    {
        $branch_id = $request->edit_branch_id;
        $edit_ids = $request->input('edit_id');
        $source_ids = $request->input('edit_lead_source_id');
        $staff_ids = $request->input('edit_staff_id');

        foreach ($edit_ids as $index => $edit_id) {
            $source_id = $source_ids[$index] ?? 0;
            $staff_id = $staff_ids[$index] ?? 0;
            
            $update = LeadSourceMappingModel::where('sno', $edit_id)->where('status', '!=', 2)->first();
            // $update->branch_id = $branch_id;
            $update->source_id = $source_id;
            $update->staff_id = $staff_id;
            $update->updated_by = $request->user()->user_id;
            $update->update();
        }

        if($update) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Lead Source Mapping Updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Lead Source Mapping Updation Failed!'
            ]);
        }
        
        return redirect()->back();
    }


    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadSourceModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Lead Source Deleted Successfully!',
            'error_msg' => 'Could not Delete Lead Source!',
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadSourceModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
