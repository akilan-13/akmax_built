<?php

namespace App\Http\Controllers\settings\lead_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LeadPotentialModel;
use Illuminate\Support\Facades\Validator;

class LeadPotentialType extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        // return view( 'content.settings.sales.lead_potential_type.lead_potential_type_list' );
        $CourseCategory = LeadPotentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.lead_settings.lead_potential_type', [
            'list_table' => $CourseCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function List()
    {
        $CourseCategory = LeadPotentialModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseCategory
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'lead_pot_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $potential_type_name       = $request->lead_pot_name;
            $potential_description     = $request->potential_description;
            $user_id                   = $request->user()->user_id;
            if ($request->hasFile('lead_pot_image')) {
                $imageName = idate('B') . rand(1, 50) . '.' . $request->file('lead_pot_image')->extension();
                $destinationPath = public_path('potential_image');
                // Path to the logos directory
                $request->file('lead_pot_image')->move($destinationPath, $imageName);
                $logo = $imageName;
            } else {
                $logo = '';
            }
            // return $logo;
            $chk = LeadPotentialModel::where('potential_type_name', ucwords($potential_type_name))->where('status', '!=', 2)->first();

            if ($chk) {

                $result = response([
                    'status'    => 401,
                    'message'   => 'Error',
                    'error_msg' => 'Lead potential Type Already Exists!',
                    'data'      => null,
                ], 200);
            } else {
                $category_check = LeadPotentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $potential_type_id = 'LPT-0001/' . $year;
                } else {

                    $data = $category_check->potential_type_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request2 = sprintf('LPT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $potential_type_id = $request2 . '/' . $year;
                }


                $add_category = new LeadPotentialModel();
                $add_category->potential_type_id         = $potential_type_id;
                $add_category->potential_type_name       = Ucfirst($potential_type_name);
                $add_category->potential_type_image      = $logo;
                $add_category->potential_description     = $potential_description;
                $add_category->created_by                = $user_id;
                $add_category->updated_by                = $user_id;
                // return  $add_category;
                $add_category->save();

                if ($add_category) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Potential Type Added Successfully !'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Add the Lead Pontential!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $editcategory = LeadPotentialModel::where('sno', $id)->first();

        return view('content.settings.sales.lead_source.lead_source_list', [
            'editcategory' => $editcategory,
            'id' => $id,
        ]);
    }

    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'potential_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $potential_type_name       = $request->potential_type_name;
            $lead_potential_score       = $request->lead_potential_score;
            $potential_description     = $request->potential_description;
            $lead_potential_id         = $request->lead_potential_id;

            $upd_CourseCategoryModel =  LeadPotentialModel::where('sno', $lead_potential_id)->first();

            $chk = LeadPotentialModel::where('potential_type_name', ucwords($potential_type_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $lead_potential_id) {

                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Lead potential Type Already Exists!'
                    ]);
                    return redirect()->back();
                }
            } else {
                $upd_CourseCategoryModel->potential_type_name  = Ucfirst($potential_type_name);
                $upd_CourseCategoryModel->lead_potential_score  = $lead_potential_score;
                $upd_CourseCategoryModel->potential_description  = $potential_description;

                $upd_CourseCategoryModel->update();

                if ($upd_CourseCategoryModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead Pontential Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Lead Pontential!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_CourseCategoryModel =  LeadPotentialModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  LeadPotentialModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}