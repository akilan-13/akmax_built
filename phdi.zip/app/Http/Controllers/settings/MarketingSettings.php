<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MarketingSettings extends Controller
{
  public function index()
  {
    return view('content.settings.marketing_settings');
  }
}
