<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModel;
use App\Models\AppointmentModeModel;
use App\Models\ConnectingWayModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class ConnectingWay extends Controller
{
    public function index(){
        $ways = ConnectingWayModel::where('status', '!=', 2)->orderBy('sno', 'desc')->with('appointment')->get();
        $modes = AppointmentModeModel::where('status', '!=', 2)->get();

        return view('content.settings.customer_settings.connecting_way', compact('ways', 'modes'));
    }

    public function Create(Request $request){
        $validator = Validator::make($request->all(), [
            'connecting_way_name' => 'required|string|max:255'
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $user_id = $request->user()->user_id;
        $name = $request->connecting_way_name;

        // Check if the name is already exists
        $checks = ConnectingWayModel::where('connecting_way_name', ucwords($name))->where('status', '!=', 2)->first();

        if($checks){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists',
            ]);

            return redirect()->back();
        } else {
            $Create = new ConnectingWayModel();
            $Create->connecting_way_name = $name;
            $Create->appointment_mode_id = $request->appointment_mode_id;
            $Create->url_link = $request->has('url_link') ? 1 : 0;
            $Create->connecting_way_desc = $request->connecting_way_desc;
            $Create->created_by = $user_id;
            $Create->updated_by = $user_id;
            $Create->save();

            if($Create){
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Connecting Way Created Successfully !',
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Connecting Way Creation Failed !'
                ]);
            }

            return redirect()->back();
        }
    }

    public function Status($id, Request $request){
        $Status = ConnectingWayModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Status->status = $request->input('status', 0);
        $Status->update();

        return response([
            'status' => 200,
            'message' => 'Connecting Way Status Updated Succesfully !',
            'error_msg' => 'Status Updation Failed !',
            'data' => null,
        ], 200);
    }

    public function Delete($id){
        $Delete = ConnectingWayModel::where('sno', $id)->where('status', '!=', 2)->first();
        $Delete->status = 2;
        $Delete->update();

        return response([
            'status' => 200,
            'message' => 'Connecting Way Deleted Successfully !',
            'error_msg' => 'Connecting Way Deletion Failed !',
            'data' => null,
        ], 200);
    }

    public function Update(Request $request){
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required',
            'edit_connecting_name' => 'required|string|max:255'
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        } 

        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $edit_name = $request->edit_connecting_name;

        // Check if the name is already exists
        $checks = ConnectingWayModel::where('connecting_way_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

        if($checks){
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Name Already Exists'
            ]);

            return redirect()->back();
        } else {
            $Update = ConnectingWayModel::where('sno', $sno)->where('status', '!=', 2)->first();
            $Update->connecting_way_name = $edit_name;
            $Update->appointment_mode_id = $request->edit_appointment_id;
            $Update->url_link = $request->has('edit_url_link') ? 1 : 0;
            $Update->connecting_way_desc = $request->edit_connecting_desc;
            $Update->updated_by = $user_id;
            $Update->update();

            if($Update){
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Connecting Way Updated Successfully !'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Connecting Way Updation Failed !'
                ]);
            }

            return redirect()->back();
        }
    }
}
