<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RefundChecklistModel;
use Illuminate\Support\Facades\Validator;

class RefundChecklist extends Controller
{


    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $refund_checklist = RefundChecklistModel::where('status', '!=', 2)->where('branch_id', $branch_id)->orderBy('sno', 'desc')->get();
        // return $highlightCategory;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.customer_settings.refund_checklist.refund_checklist_list', [
            'refund_checklist' => $refund_checklist,
            'pageConfigs' => $pageConfigs
        ]);
        // return view('content.settings.customer_settings.refund_checklist.refund_checklist_list');
    }
    public function Add(Request $request)
    {
        // return $request;
        $branch_id = $request->user()->branch_id;
        $validator = Validator::make($request->all(), [
            'refund_checklist_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $refund_checklist_name = $request->refund_checklist_name;
        $user_id =  $request->user()->user_id;

        // Check if the category already exists
        $chk = RefundChecklistModel::where('refund_checklist_name', ucwords($refund_checklist_name))
            ->where('branch_id', $branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Refund Checklist  has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $category_check = RefundChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
                $year = substr(date('y'), -2);
                $refund_checklist_id = 'RC-0001/' . $year;
            } else {
                $data = $category_check->refund_checklist_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $refund_checklist_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new RefundChecklistModel();
            $add->refund_checklist_id = $refund_checklist_id;
            $add->refund_checklist_name = ucfirst($refund_checklist_name);
            $add->branch_id = $branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;
            // return $add;
            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Refund Checklist added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the Refund Checklist!'
                ]);
            }
        }

        return redirect()->back();
    }
    public function Update(Request $request)
    {
        // return $request;

        $branch_id = $request->user()->branch_id;

        $validator = Validator::make($request->all(), [
            'refund_checklist_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes
        $sno = $request->edit_refund_checklist_id;
        $refund_checklist_name = $request->refund_checklist_name_edit;
        $user_id =  $request->user()->user_id;

        $update = RefundChecklistModel::where('sno', $sno)->first();

        $chk = RefundChecklistModel::where('refund_checklist_name', ucwords($refund_checklist_name))
            ->where('branch_id', $branch_id)
            ->where('sno', '!=', $sno)
            ->where('status', '!=', 2)->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Already Refund Checklist is exist!'
            ]);
            return redirect()->back();
        } else {

            $update->refund_checklist_name = Ucfirst($refund_checklist_name);
            $update->updated_by = $user_id;
            $update->branch_id = $branch_id;
            $update->update();

            if ($update) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Refund Checklist Updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not Updated the Refund Checklist!'
                ]);
            }
        }

        return redirect()->back();
    }

    public function Status($id, Request $request)
    {
        // return $id;
        $upd_DepartmentModel = RefundChecklistModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Delete($id)
    {
        $upd_DepartmentModel = RefundChecklistModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}