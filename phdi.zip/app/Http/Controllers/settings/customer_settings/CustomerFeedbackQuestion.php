<?php

namespace App\Http\Controllers\settings\customer_settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CustomerFeedBackQuestionModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class CustomerFeedbackQuestion extends Controller
{
  public function Index()
  {

    $cat_question = CustomerFeedBackQuestionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
    // return $cat_question;
    return view('content.settings.customer_settings.feedback.feedback_list', compact('cat_question'));
  }
  public function feedbackQuestionsAdd()
  {
    return view('content.settings.customer_settings.feedback.feedback_questions_add');
  }

  public function feedbackQuestionsEdit()
  {
    return view('content.settings.customer_settings.feedback.feedback_questions_edit');
  }


  public function List()
  {
    $leadquestion = CustomerFeedBackQuestionModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $leadquestion
    ], 200);
  }

  public function Add(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'question.*'      => 'required|max:255',
      'question_type.*' => 'required',
      'language.*'      => 'required',
      'section.*'       => 'nullable',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'All fields are required!'
      ]);
      return redirect()->back();
    }

    $user_id = $request->user()->user_id;

    foreach ($request->input('question') as $key => $question_name) {

      // NEW → fetch language & section
      // $language_id = $request->input("language.$key");
      // $section_id  = $request->input("section.$key");

      $question_type = $request->input("question_type.$key");

      $question_option = null;

      // switch ($question_type) {

      //   // case 'checkbox':
      //   // case 'radio_button':
      //   case 'list_box':

      //     // $options_key = "option_value_{$question_type}_{$key}";
      //     // $scores_key  = "option_score_{$question_type}_{$key}";

      //     // $options = $request->input($options_key, []);
      //     // $scores  = $request->input($scores_key, []);

      //     // $options_array = [];
      //     // foreach ($options as $option_key => $value) {
      //     //   if ($value !== '') {
      //     //     $options_array[] = [
      //     //       'value' => $value,
      //     //       'score' => $scores[$option_key] ?? null,
      //     //     ];
      //     //   }
      //     // }

      //     // $question_option = json_encode($options_array);
      //     break;
      // }

      // Duplicate check
      $chk = CustomerFeedBackQuestionModel::where('question_name', ucwords($question_name))
        ->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Question already exists!'
        ]);
        continue;
      }

      // CREATE NEW ROW
      $add_category = new CustomerFeedBackQuestionModel();
      $add_category->question_name   = ucfirst($question_name);
      $add_category->question_type   = $question_type;
      $add_category->question_option = $question_option;

      // NEW → save language + section
      // $add_category->language_id = $language_id;
      // $add_category->section_id  = $section_id;

      $add_category->created_by = $user_id;
      $add_category->updated_by = $user_id;
      $add_category->save();
    }

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Feedback Questions Saved Successfully!'
    ]);

    return redirect('settings/customer_settings/feedback/feedback_list');
  }

  public function Edit($id)
  {

    // return $id;
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

   $question = CustomerFeedBackQuestionModel::findOrFail($decryptedValue);

    // Parse question options if exists
    $options = [];
    // $slider_config = ['min' => 1, 'max' => 10];

    // if (!empty($question->question_option)) {
    //   if ($question->question_type === 'slider') {
    //     $slider_config = json_decode($question->question_option, true);
    //   } else {
    //     $options = json_decode($question->question_option, true);
    //   }
    // }

    return view('content.settings.customer_settings.feedback.feedback_questions_edit', [
      'question' => $question,
      // 'mapped_array' => $mapped_array,
    ]);
  }

  public function update(Request $request)
  {
    
    $validator = Validator::make($request->all(), [
      'question_name' => 'required|max:255',
      'question_type' => 'required|in:slider,text,radio_button,checkbox,list_box',
    ]);

    if ($validator->fails()) {
      return redirect()->back()
        ->withErrors($validator)
        ->withInput();
    }

    try {
      $user_id = $request->user()->user_id;
      $id = $request->edit_sno;
      $question = CustomerFeedBackQuestionModel::findOrFail($id);

      $question_option = null;

      // Prepare question options based on type
      // switch ($request->question_type) {
      //   case 'slider':
      //   case 'list_box':
      //   case 'radio_button':
      //   case 'checkbox':
      //     if ($request->has('option_value')) {
      //       $options_array = [];
      //       foreach ($request->option_value as $index => $value) {
      //         if ($value !== '') {
      //           $options_array[] = [
      //             'value' => $value,
      //             'score' => $request->option_score[$index] ?? null,
      //           ];
      //         }
      //       }
      //       $question_option = json_encode($options_array);
      //     }
      //     break;

      //   default:
      //     $question_option = null;
      // }

      // Check for duplicate question (excluding current one)
      $duplicateCheck = CustomerFeedBackQuestionModel::where('question_name', ucwords($request->question_name))
        ->where('sno', '!=', $id)
        ->where('status', '!=', 2)
        ->first();

      if ($duplicateCheck) {
        return redirect()->back()
          ->with('toastr', [
            'type' => 'error',
            'message' => 'Question already exists!'
          ])
          ->withInput();
      }

      // Update question
      $question->question_name = ucfirst($request->question_name);
      $question->question_type = $request->question_type;
      // $question->question_option = $question_option;
      $question->updated_by = $user_id;
      $question->save();

      return redirect('/settings/customer_settings/feedback/feedback_list')
        ->with('toastr', [
          'type' => 'success',
          'message' => 'Feedback Question updated successfully!'
        ]);
    } catch (\Exception $e) {
      return redirect('/settings/customer_settings/feedback/feedback_list')
        ->with('toastr', [
          'type' => 'error',
          'message' => 'Error updating question: ' . $e->getMessage()
        ])
        ->withInput();
    }
  }

  public function Delete($id)
  {
    $upd_CustomerFeedBackQuestionModel =  CustomerFeedBackQuestionModel::where('sno', $id)->first();
    $upd_CustomerFeedBackQuestionModel->status  = 2;
    $upd_CustomerFeedBackQuestionModel->Update();
    if ($upd_CustomerFeedBackQuestionModel) {
      return response([
        'status'    => 200,
        'message'   => 'Feedback Question Questions Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Feedback Question Questions!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Status($id, Request $request)
  {

    $upd_CustomerFeedBackQuestionModel =  CustomerFeedBackQuestionModel::where('sno', $id)->first();
    $upd_CustomerFeedBackQuestionModel->status = $request->input('status', 0);
    $upd_CustomerFeedBackQuestionModel->update();
    if ($upd_CustomerFeedBackQuestionModel) {
      return response([
        'status'    => 200,
        'message'   => ' Feedback Question Questions Successfully Updated!',
        'error_msg' => 'Could not ,update   Feedback Question Questions!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update  Feedback Question Questions!',
        'error_msg' => 'Could not ,update   Feedback Question Questions!',
        'data'      => null,
      ], 200);
    }
  }

  public function getSections($language_id)
  {
    $sections = DB::table('za_section')
      ->where('language_id', $language_id)
      ->select('sno', 'section')
      ->get();

    return response()->json($sections);
  }
}
