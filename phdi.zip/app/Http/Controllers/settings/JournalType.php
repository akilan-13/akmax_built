<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JournalTypeModel;
use Illuminate\Support\Facades\Validator;

class JournalType extends Controller
{
    public function index()
    {
        $JournalType = JournalTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        //return $University;
        $pageConfigs = ['myLayout' => 'default'];
        return view('content.settings.journal.journal_type', [
            'ListTable' => $JournalType,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'add_journaltype' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $lead_status_name       = $request->add_journaltype;
            $lead_bg_color                   = $request->add_bgcolor;
            $lead_status_desc       = $request->add_des;

            $user_id                    = $request->user()->user_id;
            $chk = JournalTypeModel::where('journal_type_name', ucwords($lead_status_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = JournalTypeModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $lead_status_id = 'JT-0001/' . $year;
                } else {

                    $data = $category_check->lead_status_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf('JT-%04d', $next_number);

                    $year = substr(date('y'), -2);
                    $lead_status_id = $request . '/' . $year;
                }

                $add_category = new JournalTypeModel();
                $add_category->journal_type_id         = $lead_status_id;
                $add_category->journal_type_name       = Ucfirst($lead_status_name);
                $add_category->journal_bg_color               = $lead_bg_color;
                $add_category->journal_des       = $lead_status_desc;

                $add_category->created_by             = $user_id;
                $add_category->updated_by             = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Journal Type added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Journal Type!'
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'Journal Created successfully!');
        }
    }
    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  JournalTypeModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
    public function Edit($id)
    {
        $knowledge = JournalTypeModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $knowledge
        ], 200);
    }
    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'edit_journaltype' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        } else {
            $id = $request->edit_id;
            $lead_status_name       = $request->edit_journaltype;
            $lead_bg_color          = $request->edit_bgcolor;
            $lead_status_desc       = $request->edit_des;

            $upd_CourseCategoryModel =  JournalTypeModel::where('sno', $id)->first();

            $chk = JournalTypeModel::where('journal_type_name', ucwords($lead_status_name))->where('sno', '!=', $id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Journal Type has been  already assigned!'
                ]);
                return redirect()->back();
            } else {

                $upd_CourseCategoryModel->journal_type_name  = Ucfirst($lead_status_name);
                $upd_CourseCategoryModel->journal_bg_color     = $lead_bg_color;
                $upd_CourseCategoryModel->journal_des  = $lead_status_desc;
                $upd_CourseCategoryModel->update();

                if ($upd_CourseCategoryModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Journal Status updated Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not update the Journal Status !'
                    ]);
                }
            }
        }
        return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  JournalTypeModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

}
