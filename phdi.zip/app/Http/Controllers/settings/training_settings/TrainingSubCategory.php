<?php

namespace App\Http\Controllers\settings\training_settings;

use App\Http\Controllers\Controller;
use App\Models\TrainingCategoryModel;
use App\Models\TrainingSubCategoryModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class TrainingSubCategory extends Controller
{
    public function index()
    {
        $ListTable = TrainingSubCategoryModel::where('et_training_sub_category.status', '!=', 2)
                    ->select('et_training_category.category_name','et_training_sub_category.*')
                    ->leftJoin('et_training_category', 'et_training_sub_category.category_id', 'et_training_category.sno')
                    ->orderBy('et_training_sub_category.sno', 'desc')->get();
        $Cats = TrainingCategoryModel::where('status', 0)->get();
        return view('content.settings.training_settings.training_sub_category', compact('ListTable', 'Cats'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);

            return redirect()->back();
        } else {
            $id = $request->category_id;
            $name = $request->category_name;
            $desc = $request->category_desc;
            $user_id = $request->user()->user_id;

            $check = TrainingSubCategoryModel::where('sub_cat_name', ucwords($name))->where('category_id',$id)->where('status', '!=', 2)->first();
            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $store = new TrainingSubCategoryModel();
                $store->sub_cat_name = ucwords($name);
                $store->category_id = $id;
                $store->sub_cat_desc = $desc;
                $store->created_by = $user_id;
                $store->updated_by = $user_id;
                $store->save();

                if ($store) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Training Document Sub Category created successfully !',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Training Document Sub Category creation failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function Edit($id) {
        $data = TrainingSubCategoryModel::where('status', '!=', 2)->where('sno', $id)->first();
        if($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ]);
        } else {
            return response([
                'status' => 302,
                'message' => 'Data Not Found',
                'error_msg' => null,
                'data' => null
            ]);
        }
    }

    public function Update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_category_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ]);

            return redirect()->back();
        } else {
            $sno = $request->edit_id;
            $id = $request->edit_category_id;
            $edit_name = $request->edit_category_name;
            $edit_desc = $request->edit_description;
            $user_id = $request->user()->user_id;

              $check = TrainingSubCategoryModel::where('sub_cat_name', ucwords($edit_name))->where('category_id',$id)->where('sno', '!=', $sno)->where('status', '!=', 2)->first();

            if ($check) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name already exists',
                ]);
            } else {
                $upgrade = TrainingSubCategoryModel::where('sno', $sno)->first();
                $upgrade->sub_cat_name = $edit_name;
                $upgrade->sub_cat_desc = $edit_desc;
                $upgrade->category_id = $id;
                $upgrade->created_by = $user_id;
                $upgrade->updated_by = $user_id;
                $upgrade->update();

                if ($upgrade) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Training Document Sub Category Updated successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Training Document Sub Category Update failed !',
                    ]);
                }
            }

            return redirect()->back();
        }
    }

    public function status($id, Request $request)
    {
        $updChargeModel = TrainingSubCategoryModel::where('sno', $id)->first();
        $updChargeModel->status = $request->input('status', 0);
        $updChargeModel->update();

        if ($updChargeModel) {
            return response([
                'status' => 200,
                'message' => 'Status Updated Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Status Updation failed',
                'error_msg' => 'Status Updation failed',
                'data' => null,
            ], 400);
        }
    }

    public function delete($id)
    {
        $updChargeModel = TrainingSubCategoryModel::where('sno', $id)->first();
        $updChargeModel->status = 2;
        $updChargeModel->update();

        if ($updChargeModel) {
            return response([
                'status' => 200,
                'message' => 'Training Document Sub Category deleted Succesfully !',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }
    }
}
