<?php

namespace App\Http\Controllers\settings\base_settings;

use App\Http\Controllers\Controller;
use App\Models\ProductToolsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ProductTools extends Controller{

    public function index(){
        $tools = ProductToolsModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        return view('content.settings.base_settings.product_tools', compact('tools'));
    }

    public function status($id, Request $request){
        $updProductToolsModel = ProductToolsModel::where('sno', $id)->first();
        $updProductToolsModel->status = $request->input('status', 0);
        $updProductToolsModel->update();

        if($updProductToolsModel){
            return response([
                'status' => 200,
                'message' => 'Succesfully status updated !',
                'error_msg' => 'Error updating status',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Error updating status !',
                'error_msg' => 'Error updating status !',
                'data' => null,
            ], 400);
        }
    }

    public function delete($id){
        $updProductToolsModel = ProductToolsModel::where('sno', $id)->first();
        $updProductToolsModel->status = 2;
        $updProductToolsModel->update();

        if($updProductToolsModel){
            return response([
                'status' => 200,
                'message' => 'Tools deleted succesfully',
                'error_msg' => 'Error deleting the tool',
                'data' => null,
            ], 200);
        } else {
            return response([
                'status' => 400,
                'message' => 'Tool deleting unsuccesfull',
                'error_msg' => 'Error deleting the tool',
                'data' => null,
            ], 400);
        }
    }

    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'product_tools_name' => 'required|string',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect input field format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        }

        $user_id = $request->user()->user_id;
        $product_tools_name = $request->product_tools_name;
        $product_tools_desc = $request->product_tools_desc;

        $check = ProductToolsModel::where('product_tools_name', ucwords($product_tools_name))->where('status', '!=', 2)->first();

        if ($check) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Tools Name Already Exists!'
            ]);
            return redirect()->back();
        }

        $store = new ProductToolsModel();
        $store->product_tools_name = $request->input('product_tools_name');
        $store->product_tools_desc = $request->input('product_tools_desc');
        $store->created_by = $user_id;
        $store->updated_by = $user_id;
        $store->save();

        if ($store) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Tools added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Tools!'
            ]);
        }

        return redirect()->back();
    }

    public function Update(Request $request){
        $validator = Validator::make($request->all(), [
            'edit_tools_name' => 'required|min:3|string',
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect input field',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {
            $edit_name = $request->edit_tools_name;
            $edit_desc = $request->edit_tools_desc;
            $sno = $request->edit_id;

            $check = ProductToolsModel::where('product_tools_name', ucwords($edit_name))->where('sno', '!=', $sno)->where('sno', '!=', 2)->first();

            if($check){
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Tools Name Already Exists',
                ]);
                return redirect()->back();
            } else {
                $updProductToolsModel = ProductToolsModel::where('sno', $sno)->first();
                $updProductToolsModel->product_tools_name = ucwords($edit_name);
                $updProductToolsModel->product_tools_desc = $edit_desc;

                $updProductToolsModel->update();

                if ($updProductToolsModel) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Tools Updated Succesfully',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Tool'
                    ]);
                }
            }
            return redirect()->back();
        }
    }
}