<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ServiceSettings extends Controller
{
  public function index()
  {
    return view('content.settings.services_settings');
  }
  public function service_properties_add()
  {
    return view('content.settings.service_properties.add');
  }
  public function service_properties_edit()
  {
    return view('content.settings.service_properties.edit');
  }
  public function service_product_add()
  {
    return view('content.settings.service_product.add');
  }
  public function service_product_edit()
  {
    return view('content.settings.service_product.edit');
  }
}
