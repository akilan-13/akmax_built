<?php

namespace App\Http\Controllers\settings;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\HolidayModel;




class Holiday extends Controller
{

    public function index()
    {
        $holi_list = HolidayModel::select('*')
            ->where('status', '!=', 2)
            ->orderBy('sno', 'desc')->get();

        // return $holi_list;

        return view('content.settings.holiday', [
            'holi_list' => $holi_list
        ]);
    }

    public function List()
    {
        $branch_id = 1;
        $CourseSubCategory = HolidayModel::where('branch_id', $branch_id)->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();
        // Prepare and return the response
        return response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $CourseSubCategory
        ], 200);
    }

    public function Add(Request $request)
    {
        // return $request;
        $branch_id = 1;

        $validator = Validator::make($request->all(), [
            'hol_date_add' => 'required|date|max:255'
        ]);

        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $hol_date       = date('Y-m-d', strtotime($request->hol_date_add));
            $hol_reason     = $request->hol_reason_add;
            $user_id        = 1;
            $chk = HolidayModel::where('hol_date', $hol_date)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'status'    => 401,
                    'type' => 'error',
                    'message' => 'Date has been  already created!'
                ]);
            } else {

                $add_category = new HolidayModel();
                $add_category->hol_date=$hol_date;
                $add_category->hol_reason=$hol_reason;
                $add_category->branch_id=$branch_id;
                $add_category->created_by=$user_id;
                $add_category->updated_by=$user_id;
                // return $add_category;
                $add_category->save();

                if ($add_category) {

                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Holiday added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Holiday!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }


    public function Update(Request $request)
    {
        $branch_id = 1;
        // return $request;
        $validator = Validator::make($request->all(), [
            'hol_date_edit' => 'required|date|max:255',
        ]);

        if ($validator->fails()) {
            return   response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {

            $hol_date       = date('Y-m-d', strtotime($request->hol_date_edit));
            $hol_reason     = $request->hol_reason_edit;
            $holiday_id   = $request->holiday_id;
            // return $request;

            $upd_CourseCategoryModel =  HolidayModel::where('sno', $holiday_id)->first();

            $chk = HolidayModel::where('hol_date', $hol_date)->where('status', '!=', 2)->where('sno', '!=', $holiday_id)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'status'    => 401,
                    'type' => 'error',
                    'message' => 'Date has been  already created!'
                ]);
            } else {
                $upd_CourseCategoryModel->sno         = $holiday_id;
                $upd_CourseCategoryModel->hol_date    = $hol_date;
                $upd_CourseCategoryModel->hol_reason  = $hol_reason;
                // return $upd_CourseCategoryModel;
                $upd_CourseCategoryModel->update();
            }
            if ($upd_CourseCategoryModel) {

                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => 'Holiday updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the Holiday!'
                ]);
            }
        }
        return redirect()->back();
    }


    public function Delete($id)
    {
        $upd_CourseCategoryModel =  HolidayModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        // return $upd_CourseCategoryModel;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    // public function Status($id, Request $request)
    // {

    //   $summary_reason =  HolidayModel::where('sno', $id)->first();
    //   $summary_reason->status = $request->input('status', 0);
    //   $summary_reason->update();

    //   return response([
    //     'status'    => 200,
    //     'message'   => 'Successfully Status Updated!',
    //     'error_msg' => null,
    //     'data'      => null,
    //   ], 200);
    // }
}
