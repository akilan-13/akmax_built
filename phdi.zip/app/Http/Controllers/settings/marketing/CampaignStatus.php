<?php

namespace App\Http\Controllers\settings\marketing;

use App\Models\MarketingCampStatusModel;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CampaignStatus extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        $marketing_campstatus = MarketingCampStatusModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();
        // return view( 'content.settings.course.course_type.course_type_list' );
        return view('content.settings.marketing.campaign_status', [
            'marketing_campstatus' => $marketing_campstatus
        ]);
    }

    //ADD NEW VENDOR
    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'campaign_status_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        // return $request;

        // If validation passes
        $campaign_status_name = $request->campaign_status_name;
        $campaign_status_id = $request->campaign_status_id;
        //  $campaign_status_desc = $request->campaign_status_desc;

        $user_id = $request->user()->user_id;

        // Check if the category already exists
        $chk = MarketingCampStatusModel::where('campaign_status_name', ucwords($campaign_status_name))
            ->where('branch_id', self::$branch_id)
            ->first();

        if ($chk) {
            // If category already exists, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Campaign Status has already been created!'
            ]);
        } else {
            // Generate a unique category ID
            $add_camp_status = MarketingCampStatusModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$add_camp_status) {
                $year = substr(date('y'), -2);
                $campaign_status_id = 'MC-0001/' . $year;
            } else {
                $data = $add_camp_status->campaign_status_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $requestId = sprintf('MC-%04d', $next_number);
                $year = substr(date('y'), -2);
                $campaign_status_id = $requestId . '/' . $year;
            }

            // Add the category to the database
            $add = new MarketingCampStatusModel();
            $add->campaign_status_id = $campaign_status_id;
            $add->campaign_status_name = ucfirst($campaign_status_name);

            $add->campaign_status_desc = $request->campaign_status_desc;
            $add->branch_id = self::$branch_id;
            $add->created_by = $user_id;
            $add->updated_by = $user_id;

            $add->save();

            if ($add) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => '  Campaign Status added Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not add the   Campaign Status !'
                ]);
            }
        }

        return redirect()->back();
    }



    //EDIT Campaign Status
    public function Update(Request $request)
    {
        // return $request;

        $validator = Validator::make($request->all(), [

            'campaign_status_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        //assaign our own name              blade field value
        $sno    = $request->sno_edit;
        $campaign_status_name_edit = $request->campaign_status_name_edit;
        $campaign_status_desc_edit = $request->campaign_status_desc_edit;




        $upd_camp_status = MarketingCampStatusModel::find($sno);

        if (!$upd_camp_status) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Campaign Status  not found!'
            ]);
            return redirect()->back();
        }
        // Campaign Status NAME
        $chk = MarketingCampStatusModel::where('campaign_status_name', ucwords($campaign_status_name_edit))
            ->where('branch_id', self::$branch_id)
            ->where('status', '!=', 2)
            ->where('sno', '!=', $sno)
            ->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Campaign Status has already been created!'
            ]);
            return redirect()->back();
        } else {
            // table colum name             fetched from our own value
            $upd_camp_status->campaign_status_name = ucfirst($campaign_status_name_edit);
            $upd_camp_status->campaign_status_desc = $campaign_status_desc_edit;
            $upd_camp_status->save();

            if ($upd_camp_status) {
                session()->flash('toastr', [
                    'type' => 'success',
                    'message' => ' Campaign Status updated Successfully!'
                ]);
            } else {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Could not update the  Campaign Status !'
                ]);
            }
        }
        // return $request;
        return redirect()->back();
    }

    // Status change 
    public function Status($id, Request $request)
    {

        $upd_Camp_status =  MarketingCampStatusModel::where('sno', $id)->first();
        $upd_Camp_status->status = $request->input('status', 0);
        $upd_Camp_status->update();
        if ($upd_Camp_status) {
            return response([
                'status'    => 200,
                'message'   => ' Campaign Status Status Successfully Updated!',
                'error_msg' => 'Could not ,update   Campaign Status Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Campaign Status Status!',
                'error_msg' => 'Could not ,update  Campaign Status Status!',
                'data'      => null,
            ], 200);
        }
    }

    // Delete
    public function Delete($id)
    {
        $upd_Camp_status =  MarketingCampStatusModel::where('sno', $id)->first();
        $upd_Camp_status->status  = 2;
        $upd_Camp_status->Update();
        if ($upd_Camp_status) {
            return response([
                'status'    => 200,
                'message'   => 'Campaign Status Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete Campaign Status!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
