<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\MarketingKitCategoryModel;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;

class MarketingKitCategory extends Controller
{
    protected static $branch_id = 1;
    public function index()
    {
        $MarketingKitCategory = MarketingKitCategoryModel::where('branch_id', self::$branch_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        $pageConfigs = ['myLayout' => 'default'];
        // return $MarketingKitcategory;
        return view('content.settings.marketing.marketing_kit_category', [
            'MarketingKitCategory' => $MarketingKitCategory,
            'pageConfigs' => $pageConfigs
        ]);
    }
    public function List()
    {
        $MarketingKitCategory = MarketingKitCategoryModel::where('branch_id', self::$branch_id)->where('status', 0)->orderBy('sno', 'desc')->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $MarketingKitCategory
        ], 200);
    }
    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:255',
            // 'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        // if ($request->hasFile('image')) {
        //   $image = $request->file('image')->move('marketing-kit-images', 'public'); // Save in storage/app/public/marketing-kit-images
        // } else {
        //     $image = null; // No image uploaded
        // }
        // $marketing_image = '';
        // if ($request->hasFile('image')) {
        //   $marketing_image =  '.' . $request->file('image')->extension();
        //   $request->file('image')->move(public_path('marketing_images'), $marketing_image);
        //   $marketing_image = $marketing_image;
        // }

        if ($request->hasFile('image')) {
            $fileName = idate('B') . rand(1, 50) . '.' . $request->file('image')->extension();
            $destinationPath = public_path('marketing_image');
            // Path to the logos directory
            $request->file('image')->move($destinationPath, $fileName);
            $filePath = $fileName;
        }

        if ($validator->fails()) {
            return  response([
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data'      => null,
            ], 200);
        } else {


            $category_name       = $request->category_name;
            $category_descr       = $request->category_descr;
            $image                = $filePath ?? null;
            $user_id                    = $request->user()->user_id;
            $chk = MarketingKitCategoryModel::where('category_name', ucwords($category_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!'
                ]);
            } else {
                $category_check = MarketingKitCategoryModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date("y"), -2);
                    $job_category_id = "CC-0001/" . $year;
                } else {

                    $data = $category_check->category_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int)$result + 1;
                    $request = sprintf("CC-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $category_id = $request . '/' . $year;
                }


                $add_category = new MarketingKitCategoryModel();
                // $add_category->job_category_id         = $job_category_id;
                $add_category->category_name       = Ucfirst($category_name);
                $add_category->category_descr       = $category_descr;
                $add_category->image                = $image;
                $add_category->branch_id                 =  self::$branch_id;
                $add_category->created_by                 = $user_id;
                $add_category->updated_by                 = $user_id;

                $add_category->save();

                if ($add_category) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Marketing Category Successfully added!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Marketing Category!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }


    public function Edit($id)
    {

        $editcategory = MarketingKitCategoryModel::where('sno', $id)->where('status', '!=', 2)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $editcategory
        ], 200);
    }

    public function Update($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_name' => 'required|max:255',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 401);
        }

        $upd_CategoryModel = MarketingKitCategoryModel::where('sno', $id)->first();

        if (!$upd_CategoryModel) {
            return response([
                'status' => 404,
                'message' => 'Category not found',
                'error_msg' => null,
                'data' => null,
            ], 200);
        }

        $category_name = $request->category_name;
        $category_desc = $request->category_desc;

        $chk = MarketingKitCategoryModel::where('category_name', ucwords($category_name))
            ->where('status', '!=', 2)
            ->where('sno', '!=', $id)
            ->first();

        if ($chk) {
            return response([
                'status' => 401,
                'message' => 'Name has already been created!',
                'error_msg' => null,
                'data' => null,
            ], 401);
        }

        $upd_CategoryModel->category_name = ucfirst($category_name);
        $upd_CategoryModel->category_descr = $category_desc;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = idate('B') . rand(1, 50) . '.' . $image->extension();
            $image->move(public_path('marketing_image'), $filename);

            // Delete old image if exists
            if ($upd_CategoryModel->image && file_exists(public_path('marketing_image/' . $upd_CategoryModel->image))) {
                File::delete(public_path('marketing_image/' . $upd_CategoryModel->image));
            }

            $upd_CategoryModel->image = $filename;
        }

        $upd_CategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }


    public function Delete($id)
    {
        $upd_CategoryModel =  MarketingKitCategoryModel::where('sno', $id)->first();
        $upd_CategoryModel->status  = 2;
        $upd_CategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_JobCategoryModel =  MarketingKitCategoryModel::where('sno', $id)->first();
        $upd_JobCategoryModel->status = $request->input('status', 0);
        $upd_JobCategoryModel->update();

        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }
}
