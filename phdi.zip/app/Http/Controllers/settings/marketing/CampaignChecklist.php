<?php

namespace App\Http\Controllers\settings\marketing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\MarketingCampaignChecklistModel;


class CampaignChecklist extends Controller
{

    protected static $branch_id = 1;

    public function index()
    {

        $camp_checklist = MarketingCampaignChecklistModel::select(
            'et_campaign_checklist.*',
            'et_marketing_category.marketing_category_name',
            'et_marketing_type.marketing_type_name'
        )
            ->join('et_marketing_category', 'et_marketing_category.sno', '=', 'et_campaign_checklist.camp_category_id')
            ->join('et_marketing_type', 'et_marketing_type.sno', '=', 'et_campaign_checklist.camp_type_id')
            ->where('et_campaign_checklist.status', '!=', 2)
            // ->where('et_marketing_type.status', '!=', 2)
            ->where('et_campaign_checklist.branch_id', self::$branch_id)
            ->orderBy('et_campaign_checklist.sno', 'desc')
            ->get();

        return view('content.settings.marketing.campaign_checklist', [
            'camp_checklist' => $camp_checklist

        ]);
    }


    // Add checklist
    public function Add(Request $request)
    {

        // return $request;
        $validator = Validator::make($request->all(), [
            'checklist_name' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            // If validation fails, return error response
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }

        // If validation passes

        $camp_checklist_id = $request->camp_checklist_id;
        $checklist_dropdown_category = $request->checklist_dropdown_category_select;
        $checklist_dropdown_type_select = $request->checklist_dropdown_type_select;
        $camp_checklist = $request->checklist_name;
        $camp_desc = $request->checklist_desc;
        $user_id = $request->user()->user_id;


        // Check if the category already exists
        // $chk = MarketingCampaignChecklistModel::where('checklist_name', ucwords($camp_checklist))

        //   ->where('branch_id', self::$branch_id)
        //   ->first();
        // return $chk;
        // if ($chk) {

        //   // If category already exists, return error response
        //   session()->flash('toastr', [
        //     'type' => 'error',
        //     'message' => ' Checklist has already been created!'
        //   ]);
        // } else {
        // Generate a unique category ID
        $checklist_check = MarketingCampaignChecklistModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$checklist_check) {
            $year = substr(date('y'), -2);
            $camp_checklist_id = 'MC-0001/' . $year;
        } else {
            $data = $checklist_check->camp_checklist_id;
            $slice = explode('/', $data);
            $result = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$result + 1;
            $requestId = sprintf('MC-%04d', $next_number);
            $year = substr(date('y'), -2);
            $camp_checklist_id = $requestId . '/' . $year;
        }

        // Add the category to the database

        $add = new MarketingCampaignChecklistModel();
        $add->camp_checklist_id = $camp_checklist_id;
        $add->camp_checklist = json_encode($camp_checklist);
        $add->camp_category_id = $checklist_dropdown_category;
        $add->camp_type_id = $checklist_dropdown_type_select;
        $add->camp_desc = $camp_desc;
        $add->branch_id = self::$branch_id;
        $add->created_by =  $request->user()->user_id;
        $add->updated_by = $request->user()->user_id;

        $add->save();

        if ($add) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => ' Campaign Checklist added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the Campaign Checklist!'
            ]);
        }
        // }

        return redirect()->back();
    }


    //EDIT VENDOR
    public function Update(Request $request)
    {

        $validator = Validator::make($request->all(), [

            'checklist_name_edit' => 'required|max:255'
        ]);

        if ($validator->fails()) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input fields'
            ]);
            return redirect()->back();
        }
        $checklist_dropdown_category_edit = $request->camp_check_cat_select_edit;
        $camp_check_type_select_edit = $request->camp_check_type_select_edit;
        $camp_checklist = $request->checklist_name_edit;
        $camp_desc = $request->camp_check_desc_edit;


        $sno    = $request->sno_edit;



        $upd_camp_checklist = MarketingCampaignChecklistModel::find($sno);

        if (!$upd_camp_checklist) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Campaign Checklist  not found!'
            ]);
            return redirect()->back();
        }
        //checklist NAME
        // $chk = MarketingCampaignChecklistModel::where('checklist_name_edit', $checklist_name_edit)
        //   ->where('branch_id', self::$branch_id)
        //   ->where('status', '!=', 2)
        //   ->where('sno', '!=', $sno)
        //   ->first();

        // if ($chk) {
        //   session()->flash('toastr', [
        //     'type' => 'error',
        //     'message' => ' Zone has already been created!'
        //   ]);
        //   return redirect()->back();
        // } else {
        //database colums         blade fields

        $upd_camp_checklist->camp_category_id = $checklist_dropdown_category_edit;
        $upd_camp_checklist->camp_type_id = $camp_check_type_select_edit;
        $upd_camp_checklist->camp_checklist = json_encode($camp_checklist);
        $upd_camp_checklist->camp_desc = $camp_desc;



        $upd_camp_checklist->save();




        if ($upd_camp_checklist) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => '  Campaign Checklist updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not update the  Campaign Checklist !'
            ]);
        }
        //   }
        // return $request;
        return redirect()->back();
    }


    // Status change 
    public function Status($id, Request $request)
    {

        $upd_CourseTypeModel =  MarketingCampaignChecklistModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status = $request->input('status', 0);
        $upd_CourseTypeModel->update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => 'Campaign Checklist Status Successfully Updated!',
                'error_msg' => 'Could not ,update  Campaign Checklist Status!',
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not update Campaign Checklist Status!',
                'error_msg' => 'Could not update Campaign Checklist Status!',
                'data'      => null,
            ], 200);
        }
    }


    public function Delete($id)
    {

        $upd_CourseTypeModel =  MarketingCampaignChecklistModel::where('sno', $id)->first();
        $upd_CourseTypeModel->status  = 2;
        $upd_CourseTypeModel->Update();
        if ($upd_CourseTypeModel) {
            return response([
                'status'    => 200,
                'message'   => ' Campaign Checklist Successfully Deleted!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        } else {
            return response([
                'status'    => 200,
                'message'   => 'Could not delete  Campaign Checklist!',
                'error_msg' => null,
                'data'      => null,
            ], 200);
        }
    }
}
