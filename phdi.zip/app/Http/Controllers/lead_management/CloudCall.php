<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Models\CloudCallModel;
use App\Models\LeadModel;
use App\Models\BranchModel;
use App\Models\LeadTransferLogModel;
use App\Models\SpamReasonModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;

class CloudCall extends Controller
{
    protected $apiUrl;
    protected $apiToken;

    public function __construct()
    {
        $this->apiUrl = env('MYOPERATOR_BASE_URL', 'https://in.app.myoperator.com');
        $this->apiToken = env('MYOPERATOR_API_TOKEN');
        // $this->apiUrl = 'https://in.app.myoperator.com';
        // $this->apiToken = 'elysium_academy_otp_erp';
    }
    public function Index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($month . $year == date('mY') || $year > date('Y')) {
            $month_chk = 0;
        } else {
            $month_chk = 1;
        }

        // Get the current date
        $currentDate = now()->toDateString();
        $customer_fill = $request->cus_fill ?? '';
        $unattended_fill = $request->get('unattended', $unattended ?? '');


        $Call_log = CloudCallModel::select(
            'et_cloud_call.*',
            'et_lead.lead_name',
            'et_lead.drop_verified',
            'et_lead.drop_tl_verified',
            'et_lead.spam_verified',
            'et_lead.spam_tl_verified',
            'et_lead.status AS lead_status',
            'et_lead.lead_mobile',
            'et_lead.created_by AS lead_created_by',
            'et_staff.staff_name',
            'et_Internal_cugs.user_name as internal_user_name'
        )
            ->leftJoin('et_lead', function ($join) {
                $join->on('et_lead.lead_mobile', '=', DB::raw("RIGHT(et_cloud_call.caller_number, 10)"));
            })
            ->leftJoin('et_Internal_cugs', function ($join) {
                $join->on('et_Internal_cugs.cug_mobile_no', '=', DB::raw("RIGHT(et_call_tracker.customer_phone_no, 10)"));
            })
            ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_lead.created_by') // Ensure correct column mapping
            ->whereYear('start_time', $year)
            ->where('et_cloud_call.branch_id', $branch_id)
            ->whereMonth('start_time', $month);

        if (!empty($customer_fill)) {
            $Call_log->where(function ($query) use ($customer_fill) {
                $query->where('received_by', 'LIKE', "%{$customer_fill}%")
                    ->orWhere('caller_number', 'LIKE', "%{$customer_fill}%")
                    ->orWhere('action', 'LIKE', "%{$customer_fill}%")
                    ->orWhere('department_name', 'LIKE', "%{$customer_fill}%");
            });
        }

        if (!empty($unattended_fill)) {
            $Call_log->whereNull('et_cloud_call.action') // Ensures 'action' is NULL
                ->where('et_cloud_call.status', 2)
                ->whereNotExists(function ($query) {
                    $query->select(DB::raw(1))
                        ->from('et_lead')
                        ->whereRaw("RIGHT(et_cloud_call.caller_number, 10) = et_lead.lead_mobile");
                });
        }

        // Assign paginated result
       return $Call_log = $Call_log->orderBy('start_time', 'DESC')->paginate($perpage);
    


        $missed_call_count = CloudCallModel::whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->where('branch_id', $branch_id)
            ->where('action', 'missed')
            ->count();

        $received_call_count = CloudCallModel::whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->where('branch_id', $branch_id)
            ->where('action', 'received')
            ->count();

        $not_atten_call_count = CloudCallModel::whereYear('start_time', $year)
            ->whereMonth('start_time', $month)
            ->where('branch_id', $branch_id)
            ->whereNull('action') // Correct way to check NULL in Laravel
            ->where('status', 2)
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('et_lead')
                    ->whereRaw("RIGHT(et_cloud_call.caller_number, 10) = et_lead.lead_mobile");
            })
            ->count();

        $reasonList = SpamReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();


        // Return the view with the data and total count
        return view('content.lead_management.manage_cloudcall.cloud_call_list', [
            'perpage' => $perpage,
            'month_chk' => $month_chk,
            'Call_log' => $Call_log,
            'reasonList' => $reasonList,
            'month' => $month,
            'year' => $year,
            'missed_call_count' => $missed_call_count,
            'not_atten_call_count' => $not_atten_call_count,
            'received_call_count' => $received_call_count,
            'customer_fill' => $customer_fill
        ])->with('filter_on', false);
    }

    public function getCallLogs()
    {

        $branches = BranchModel::select('sno AS branch_id', 'cloud_call_api_key')
            ->where('status', 0)
            ->where('cloud_call_api_key', '!=', '')
            ->get();
        $inserted_records = 0; // Array to store inserted records

        if ($branches->isEmpty()) {
            return response()->json(['message' => 'Branch not found'], 404);
        }

        foreach ($branches as $branch) {

            $branch_id = $branch->branch_id;

            $apiToken = $branch->cloud_call_api_key;
            $apiUrl = 'https://developers.myoperator.co/search';
            if (!$apiToken) {
                return response()->json(['error' => 'API token is missing'], 400);
            }
            $params = [
                'token' => $apiToken,
                // 'from' => strtotime('2025-02-01'),
                // 'to' => strtotime('2024-09-30'),
                'from' => strtotime('-1 days'),
                'to' => strtotime('now'),
                'page_size' => 100,
                'search_key' => '',
                'filters' => '',
            ];
            $response = Http::post($apiUrl, $params);
            if (!$response->successful()) {
                return response()->json([
                    'error' => 'Failed to fetch call logs',
                    'status_code' => $response->status(),
                    'message' => $response->body(),
                ], $response->status());
            }
            $data = $response->json();
            if (!isset($data['data']['hits'])) {
                return response()->json(['error' => 'No call logs found'], 404);
            }
            foreach ($data['data']['hits'] as $hit) {

                $call = $hit['_source'];
                // return $hit;
                $callId = $call['allcaller_id'];
                $status = $call['status'];

                $callerNumber = $call['caller_number'];
                $state = $call['state'] ?? null;
                $startTime = date('Y-m-d H:i:s', $call['start_time'] + 19800); // Add 5 hours 30 minutes (19800 seconds)
                $endTime = date('Y-m-d H:i:s', $call['end_time'] + 19800);


                // return $startTime;
                $duration = $call['duration'] ?? 0;
                $log_details = json_encode($call['log_details']);
                $action = isset($call['log_details'][0]['action']) ? $call['log_details'][0]['action'] : null;
                $departmentName = $call['department_name'] ?? null;

                $receivedBy = null;
                if (!empty($call['log_details']) && !empty($call['log_details'][0]['received_by'])) {
                    $receivedBy = $call['log_details'][0]['received_by'][0]['name'] ?? null;
                }

                // Handle audio file
                // $audioFilePath = null;
                // if (!empty($call['fileurl'])) {
                //     $audioUrl = $call['fileurl'];
                //     $fileName = $callId . '.mp3';
                //     $audioFilePath = 'call_recordings/' . $fileName;

                //     try {
                //         $audioContent = Http::get($audioUrl)->body();
                //         Storage::disk('public')->put($audioFilePath, $audioContent);
                //     } catch (\Exception $e) {
                //         \Log::error('Error saving audio file', ['error' => $e->getMessage()]);
                //         $audioFilePath = null;
                //     }
                // }
                $audioUrl = $call['fileurl'] ?? '';
                $audioFilePath = '';

                if (!empty($call['fileurl'])) {
                    $audioUrl = $call['fileurl'] ?? '';
                    $fileName = $callId . '.mp3';
                    $staffFolder = 'call_recordings';
                    $audioFilePath = $staffFolder . '/' . $fileName;

                    try {
                        // Fetch the audio file with authentication (if needed)
                        $audioResponse = Http::withHeaders([
                            'Authorization' => 'Bearer ' . $apiToken // Add if authentication is required
                        ])->get($audioUrl);

                        if ($audioResponse->successful() && !empty($audioResponse->body())) {
                            // Ensure storage folder exists
                            // Storage::disk('public')->makeDirectory($staffFolder);

                            // Save in storage
                            // Storage::disk('public')->put($audioFilePath, $audioResponse->body());

                            // Ensure the public folder exists
                            $publicDir = public_path($staffFolder);
                            if (!File::exists($publicDir)) {
                                File::makeDirectory($publicDir, 0777, true, true);
                            }

                            // Save file in public folder
                            $publicPath = $publicDir . '/' . $fileName;
                            file_put_contents($publicPath, $audioResponse->body());

                            $audioFilePath = null;

                            // \Log::info('Audio file saved successfully', ['file' => $audioFilePath]);
                        } else {
                            // \Log::error('Failed to download audio file', [
                            //     'url' => $audioUrl,
                            //     'status' => $audioResponse->status(),
                            //     'response' => $audioResponse->body()
                            // ]);
                            $audioFilePath = null;
                        }
                    } catch (\Exception $e) {
                        // \Log::error('Error saving audio file', ['error' => $e->getMessage()]);
                        $audioFilePath = null;
                    }
                }
                // if ($status != 2) {
                // Save call data in the database
                CloudCallModel::updateOrCreate(
                    ['call_id' => $callId],
                    [
                        'branch_id' => $branch_id,
                        'caller_number' => $callerNumber,
                        'state' => $state,
                        'start_time' => $startTime,
                        'end_time' => $endTime,
                        'duration' => $duration,
                        'action' => $action,
                        'log_details' => $log_details,
                        'department_name' => $departmentName,
                        'audioUrl' => $audioUrl,
                        'received_by' => $receivedBy,
                        'audio_file' => $audioFilePath,
                        'status' => $status,
                    ]
                );
                // }

                $inserted_records++;
            }
        }

        return response()->json([
            'inserted_records' => isset($inserted_records) ? $inserted_records : 0,
            'message' => 'Call logs stored successfully'
        ]);
    }

    public function spamLeadConvert(Request $request)
    {

        // return $request;
        $converted_to = $request->lead_convert_to;
        $cloud_call_id = $request->cloud_call_id;
        $created_by = $request->sales_staff_add;
        $lead_name = $request->lead_name;
        $spam_reason = $request->spam_reason;
        $reason_text = $request->reason_text;
        $spam_comments = $request->spam_comments;

        // return $request;

        $cloud_call = CloudCallModel::select('caller_number', 'start_time')->where('id', $cloud_call_id)->first();
        // return $cloud_call;

        if (strpos($cloud_call->caller_number, '+91') === 0) {
            $country_code = '91';
            $lead_mobile = substr($cloud_call->caller_number, 3); // Remove '+91'
        } elseif (strpos($cloud_call->caller_number, '+971') === 0) {
            $country_code = '971';
            $lead_mobile = substr($cloud_call->caller_number, 4); // Remove '+971'
        } else {
            $country_code = '';
            $lead_mobile = $cloud_call->caller_number; // No country code
        }

        if ($country_code == '') {
            $country_code = 91;
        }


        $registered_date    = date('Y-m-d', strtotime($cloud_call->start_time));
        $user_id            = $request->user()->user_id;
        $branch_id          = $request->user()->branch_id;

        // return $registered_date;

        $chk = LeadModel::where('lead_mobile', $lead_mobile)->where('et_lead.branch_id', $branch_id)->where('status', '!=', 2)->first();

        if ($chk) {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Mobile Number already created!'
            ]);
        } else {
            $branch_check = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();

            $branch_code = $branch_check->city_short_code;

            $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            $year = date("Y");
            if (!$category_check) {
                $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
            } else {
                $data = $category_check->lead_id;
                $slice = explode("/", $data);
                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number = (int)$resultcus + 1;
                $request_pay = sprintf("LED%04d", $next_number);
                $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
            }

            if ($converted_to == 1) {

                $add_category = new LeadModel();
                $add_category->lead_id                 = $lead_id;
                $add_category->lead_name               = Ucfirst($lead_name);
                $add_category->lead_mobile             = $lead_mobile;
                $add_category->inter_calls             = $country_code;
                $add_category->registered_date         = $registered_date;
                $add_category->branch_id               = $branch_id;
                $add_category->lead_source_id          = 4;
                $add_category->cloud_call_id           = $cloud_call_id;
                $add_category->created_by              = $created_by;
                $add_category->updated_by              = $user_id;
                $add_category->lead_status_id          = 1;
                $add_category->lead_condition          = 2;


                // return $add_category;
                // return $add_category;
                $add_category->save();

                if ($add_category) {
                    // return $add_category;
                    $add_history = new LeadTransferLogModel();
                    $add_history->lead_id = $add_category->sno;
                    $add_history->branch_id = $add_category->branch_id;
                    $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                    $add_history->current_staff_id = $add_category->created_by;
                    $add_history->change_staff_id = 0;
                    $add_history->end_date = null;
                    $add_history->transferred_from = 8; // from Cloud Call
                    $add_history->created_by = $user_id;
                    $add_history->updated_by = $user_id;
                    // return $add_history;
                    $add_history->save();
                }
                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Lead added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Lead!'
                    ]);
                }
            } else if ($converted_to == 2) {


                $add_category = new LeadModel();
                $add_category->lead_id                 = $lead_id;
                $add_category->lead_name               = Ucfirst($lead_name);
                $add_category->lead_mobile             = $lead_mobile;
                $add_category->inter_calls             = $country_code;
                $add_category->registered_date         = $registered_date;
                $add_category->branch_id               = $branch_id;
                $add_category->lead_source_id          = 4;
                $add_category->cloud_call_id           = $cloud_call_id;
                $add_category->created_by              = $created_by;
                $add_category->updated_by              = $user_id;
                $add_category->status                  = 7;
                $add_category->lead_status_id          = 6;
                $add_category->spam_verified           = 0;
                $add_category->spam_tl_verified        = 0;
                $add_category->lead_condition          = 2;

                if ($spam_reason == 1) {
                    $add_category->spam_reason = $request->reason_text;  // Set drop_reason from drop_reason_text
                } else {
                    $spam = SpamReasonModel::where('reason_name', $spam_reason)->first();
                    // return $spam;
                    if ($spam->comments_check == 1) {
                        $add_category->spam_comments = $request->spam_comments;
                    }
                    $add_category->spam_reason = $spam_reason;
                }

                // return $add_category;
                $add_category->save();

                if ($add_category) {
                    // return $add_category;
                    $add_history = new LeadTransferLogModel();
                    $add_history->lead_id = $add_category->sno;
                    $add_history->branch_id = $add_category->branch_id;
                    $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                    $add_history->current_staff_id = $add_category->created_by;
                    $add_history->change_staff_id = 0;
                    $add_history->end_date = null;
                    $add_history->transferred_from = 9; // from Cloud Call Spam
                    $add_history->created_by = $user_id;
                    $add_history->updated_by = $user_id;
                    // return $add_history;
                    $add_history->save();
                }
                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Spam Lead added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Lead!'
                    ]);
                }
            }
        }

        return redirect('/lead/cloudcall');
    }


    public function streamAudio()
    {
        $audioUrl = 'https://in.app.myoperator.com/audio/56930fde4fcadbb7fd5eb777d92de70b02c9cd37bac54d1abb0cbeec970845628787b777a0c900a9e843bea00693867f-v2';

        // Use an Authorization token (if available) or session cookie
        $response = Http::withHeaders([
            'User-Agent' => 'Mozilla/5.0',  // Avoid bot detection
            'Cookie' => '199.250.207.212:443',  // If MyOperator uses session-based authentication
            'Authorization' => $this->apiToken,
        ])->get($audioUrl);

        if ($response->failed()) {
            return response()->json(['error' => 'Unauthorized or audio access restricted'], 403);
        }

        return response($response->body(), 200)
            ->header('Content-Type', 'audio/mpeg');
    }
}
