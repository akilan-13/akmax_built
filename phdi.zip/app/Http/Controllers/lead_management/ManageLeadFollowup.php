<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\FollowupReasonModel;

class ManageLeadFollowup extends Controller
{

    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        $entity_id = $request->user()->entity_id;
        $currentMonth = date('m');
        $currentYear = date('Y');
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.lead_id as ld_name_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_lead.lead_name',
                'et_lead.lead_email_id',
                'et_lead.lead_gender',
                'et_lead.lead_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.status', 1)
            ->whereNotIn('et_lead.status', [2, 5, 6, 7])
            ->where('et_appointment.appointment_date', date('y-m-d'))
            ->where('et_appointment.branch_id', $branch_id);

        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list      = $lead_flw_list->orderBy('et_appointment.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();


        $completedCounts = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $completedCounts = $completedCounts->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $completedCounts = $completedCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCounts = $completedCounts->count();
        $cancelledCounts = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCounts = $cancelledCounts->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $cancelledCounts = $cancelledCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCounts = $cancelledCounts->count();
        $pendingCounts   = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            // ->where('et_appointment.progressed', null)
            ->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $pendingCounts = $pendingCounts->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $pendingCounts = $pendingCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCounts = $pendingCounts->count();


        $TotalCounts   = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->whereIn('et_lead.status', [0, 4])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $TotalCounts = $TotalCounts->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $TotalCounts = $TotalCounts;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCounts = $TotalCounts->count();



        $completedCountsMonth =  DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->whereMonth('et_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $completedCountsMonth = $completedCountsMonth->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $completedCountsMonth = $completedCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $completedCountsMonth = $completedCountsMonth->count();
        $cancelledCountsMonth = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->whereMonth('et_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $cancelledCountsMonth = $cancelledCountsMonth->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $cancelledCountsMonth = $cancelledCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $cancelledCountsMonth = $cancelledCountsMonth->count();
        $pendingCountsMonth   = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            // ->where('et_appointment.progressed', null)
            ->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'))->whereMonth('et_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $pendingCountsMonth = $pendingCountsMonth->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $pendingCountsMonth = $pendingCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $pendingCountsMonth = $pendingCountsMonth->count();
        $TotalCountsMonth   = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->whereIn('et_lead.status', [0, 4])->where('et_appointment.branch_id', $branch_id)->whereMonth('et_appointment.appointment_date', $currentMonth);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $TotalCountsMonth = $TotalCountsMonth->where('et_appointment.created_by', $user_id);
            // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data
            $TotalCountsMonth = $TotalCountsMonth;
            // return "global_lead";
        } else {
            // No permission
            abort(403, 'Unauthorized');
        }
        $TotalCountsMonth = $TotalCountsMonth->count();

        $successAppointmentRate = $TotalCounts > 0 ? ($completedCounts / $TotalCounts) * 100 : 0;
        $failAppointmentRate = $TotalCounts > 0 ? ($cancelledCounts / $TotalCounts) * 100 : 0;

        // month
        $successAppointmentRateMonth = $TotalCountsMonth > 0 ? ($completedCountsMonth / $TotalCountsMonth) * 100 : 0;
        $failAppointmentRateMonth = $TotalCountsMonth > 0 ? ($cancelledCountsMonth / $TotalCountsMonth) * 100 : 0;

        // return $lead_flw_list;
        return view('content.lead_management.manage_followup.followup_list', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'successAppointmentRate' => $successAppointmentRate,
            'failAppointmentRate' => $failAppointmentRate,
            'successAppointmentRateMonth' => $successAppointmentRateMonth,
            'failAppointmentRateMonth' => $failAppointmentRateMonth,
            'cancelledCountsMonth'   => $cancelledCountsMonth,
            'completedCountsMonth'   => $completedCountsMonth,
            'pendingCountsMonth'     => $pendingCountsMonth,
            'TotalCountsMonth'     => $TotalCountsMonth,
            'cancelledCounts'   => $cancelledCounts,
            'completedCounts'   => $completedCounts,
            'pendingCounts'     => $pendingCounts,
            'TotalCounts'     => $TotalCounts,
            'currentMonth'     => $currentMonth,
            'currentYear'     => $currentYear,

        ]);
    }

    public function closedFollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.convo_message',
                'et_appointment.app_score',
                'et_appointment.lead_id as ld_name_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_lead.lead_name',
                'et_lead.lead_email_id',
                'et_lead.lead_gender',
                'et_lead.lead_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.status', 4)
            ->whereNotIn('et_lead.status', [2, 5, 6, 7])
            ->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list = $lead_flw_list->orderBy('et_appointment.sno', 'desc')->paginate($perpage);

        $todayFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // return $lead_flw_list;
        return view('content.lead_management.manage_followup.closed_followup_list', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'staff_fill'              => $staff_fill,

        ]);
    }

    public function rescheduleFollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.reason',
                'et_appointment.lead_id as ld_name_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_lead.lead_name',
                'et_lead.lead_email_id',
                'et_lead.lead_gender',
                'et_lead.lead_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.status', 1)
            ->where('et_appointment.progressed', 2)
            ->whereNotIn('et_lead.status', [2, 5, 6, 7])
            ->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list = $lead_flw_list->orderBy('et_appointment.sno', 'desc')->paginate($perpage);

        $todayFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();

        // return $lead_flw_list;
        return view('content.lead_management.manage_followup.reschedule_followup', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'staff_fill'              => $staff_fill,

        ]);
    }
    public function unfollowup(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page      = $request->input('page', 1);
        $perpage   = (int) $request->input('sorting_filter', 25);
        $offset    = ($page - 1) * $perpage;
        $user_id   = $request->user()->user_id;
        // Filters

        $lead_fill  = $request->input('lead_fill', '');
        $staff_fill = $request->input('staff_fill', '');

        $lead_flw_list = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.progressed',
                'et_appointment.lead_id as ld_name_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_lead.lead_name',
                'et_lead.lead_mobile',
                'et_lead.lead_email_id',
                'et_lead.lead_gender',
                'et_lead.lead_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.status', 1)
            ->whereNotIn('et_lead.status', [2, 5, 6, 7])
            ->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'))
            ->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $lead_flw_list = $lead_flw_list->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }

        if ($lead_fill != '') {
            $lead_flw_list->where(function ($query) use ($lead_fill) {
                $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.staff_name', 'LIKE', "%{$lead_fill}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$lead_fill}%");
            });
        }

        $lead_flw_list      = $lead_flw_list->orderBy('et_appointment.sno', 'desc')->paginate($perpage);
        $todayFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', date('y-m-d'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $todayFollowupCount = $todayFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $todayFollowupCount  = $todayFollowupCount->count();
        $closedFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 4)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $closedFollowupCount = $closedFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $closedFollowupCount     = $closedFollowupCount->count();
        $rescheduleFollowupCount = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')->where('et_appointment.status', 1)->where('et_appointment.progressed', 2)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id);
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $rescheduleFollowupCount = $rescheduleFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $rescheduleFollowupCount = $rescheduleFollowupCount->count();
        $unFollowupCount         = DB::table('et_appointment')->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
        ->where('et_appointment.status', 1)->whereNotIn('et_lead.status', [2, 5, 6, 7])->where('et_appointment.branch_id', $branch_id)->where('et_appointment.appointment_date', '<=', date('y-m-d'))->where('et_appointment.appointment_time', '<=', now()->format('H:i'));
        if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'view_self_lead')) {
            // User can only view their own data
            $unFollowupCount = $unFollowupCount->where('et_appointment.created_by', $user_id);
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Followup', 'global_lead')) {
            // User can view all data (no additional filters needed)

        }
        $unFollowupCount = $unFollowupCount->count();
        $followupReasonList = FollowupReasonModel::select('*')
            ->where('status', 0)
            ->orderBy('sno', 'desc')->get();
        // return $lead_flw_list;
        return view('content.lead_management.manage_followup.unfollowup', [
            'lead_flw_list'           => $lead_flw_list,
            'todayFollowupCount'      => $todayFollowupCount,
            'closedFollowupCount'     => $closedFollowupCount,
            'rescheduleFollowupCount' => $rescheduleFollowupCount,
            'followupReasonList' => $followupReasonList,
            'unFollowupCount'         => $unFollowupCount,
            'perpage'                 => $perpage,
            'lead_fill'               => $lead_fill,
            'staff_fill'              => $staff_fill,

        ]);
    }
}
