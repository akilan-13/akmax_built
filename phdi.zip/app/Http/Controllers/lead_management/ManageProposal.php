<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ProposalModel;
use App\Models\PreProposalModel;
use App\Models\ManageProductVariableModel;
use App\Models\ManageProductVaiantModel;
use App\Models\TempProposalModel;
use App\Models\ProductModel;
use Illuminate\Support\Facades\Validator;
use App\Mail\ETPLMail;
use App\Models\EmailTemplateModel;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

class ManageProposal extends Controller
{
   public function index(Request $request)
  {
     $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $user_id   = $request->user()->user_id ;
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      
    //   if($user_id !=0){
    //       return view('content.working_on_progress');
    //   }

      $startTime = microtime(true);
      
      $lead_fill           = $request->lead_fill ?? '';

      $latestProposalPerLead = DB::table('et_proposal')
            ->select(DB::raw('MAX(sno) as latest_sno'))
            ->where('branch_id', $branch_id)
            ->whereNot('post_sale_check',1)
            ->where('status', '!=', 2)
            ->groupBy('lead_id');

        // Main query: join with et_proposal again to get full rows
        $proposal_list = DB::table('et_proposal')
            ->joinSub($latestProposalPerLead, 'latest', function ($join) {
                $join->on('et_proposal.sno', '=', 'latest.latest_sno');
            })
            ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
            // ->leftJoin('et_chotta_links', 'et_chotta_links.proposal_id', '=', 'et_proposal.sno')
            ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.lead_email_id','et_lead.registered_date','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
             ->where('et_proposal.status','!=', 2)
             ->whereNot('post_sale_check',1)
             ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->where('et_lead.status','!=', 2)
            ->orderBy('et_proposal.sno', 'desc')
            ->distinct('et_proposal.sno');
            
             if ($lead_fill != '') {
                      $proposal_list->where(function ($query) use ($lead_fill) {
                        $query->where('et_lead.lead_name', 'LIKE', "%{$lead_fill}%")
                          ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_fill}%")
                          ->orWhere('et_proposal.proposal_id', 'LIKE', "%{$lead_fill}%")
                          ->orWhere('et_proposal.service_title', 'LIKE', "%{$lead_fill}%")
                          ->orWhere('et_lead.lead_email_id', 'LIKE', "%{$lead_fill}%");
                      });
                    }
             if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Proposal', 'view_self_lead')) {
                    // User can only view their own data
                    $proposal_list = $proposal_list->where('et_lead.created_by', $user_id);
                    // return "view_self_lead";
                } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Proposal', 'global_lead')) {
                    // User can view all data
                    $proposal_list = $proposal_list;
                    // return "global_lead";
                } else {
                    // No permission
                    abort(403, 'Unauthorized');
                }
                
                
            $proposal_list=$proposal_list->paginate($perpage);
        
        // return $proposal_list;
        
       foreach( $proposal_list as $list){
           
           $proposal_payment = DB::table('et_proposal_pay_slot')
                    ->where('et_proposal_pay_slot.proposal_sno',$list->sno)
                    ->where('et_proposal_pay_slot.status','!=', 2)
                    ->where('et_proposal_pay_slot.paid_status',1)
                    ->get();
            $paid_amount = $proposal_payment->sum('paidAmount');
        
            $list->total_paidAmount =$paid_amount ?? 0;
           
            $proposal_data = DB::table('et_proposal')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                    ->select('et_proposal.*', 'et_lead.lead_name', 'et_lead.lead_mobile', 'et_lead.registered_date','et_lead.lead_email_id','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                    ->where('et_proposal.lead_id',$list->lead_id)
                    ->where('et_proposal.status','!=', 2)
                    ->whereNot('post_sale_check',1)
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->where('et_lead.status','!=', 2)
                    ->orderBy('et_proposal.sno', 'desc')
                    ->get();
              foreach( $proposal_data as $prlist){
                 if($prlist->discount_id >0){
                    $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$prlist->discount_id)->first();
            
                    $prlist->discount_value=$discount->coupon_value ;
                    $prlist->coupon_code=$discount->coupon_code ;
                    $prlist->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
                  }else{
                      $prlist->discount_value=null ;
                       $prlist->coupon_code=null ;
                      $prlist->discount_type=null;
                  }
              }
            $list->proposal_data =$proposal_data;
       }


    return view('content.lead_management.manage_proposal.proposal_list',[
      'proposal_list'=>$proposal_list,
      'lead_fill'=>$lead_fill,
      'perpage'=>$perpage,
      
    ]);
  }


  public function CreateProposal(Request $request){

    $lead_id= $request->proposal_lead_id ?? 0;

    $values = $request->input('lead_id');
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }

   public function manage_proposal_add($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $lead_id =$decryptedValue;
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
    //   if($user_id !=0){
    //       return view('content.working_on_progress');
    //   }
     $lead=DB::table('et_lead')->where('et_lead.sno',$decryptedValue)->first();

     $proposal =ProposalModel::orderBy('sno', 'desc')->first();
     $package_list =DB::table('et_package')->where('et_package.status',0)->orderBy('sno', 'desc')->get();
     $additional_charges_list =DB::table('et_additional_charges')->where('et_additional_charges.status',0)->orderBy('sno', 'desc')->get();

     $currencyList=DB::table('et_country_currencies')->where('et_country_currencies.status',0)->get();
     $domainList=DB::table('et_domain')->where('et_domain.status',0)->get();

     $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
         DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();

    $addOnProductList = DB::table('et_manage_addon')
    ->select(
      'et_manage_addon.sno',
      'et_manage_addon.addon_name'
    )
    ->where('et_manage_addon.status', 0)
    ->where('et_manage_addon.branch_id', $branch_id)
    ->get();

    foreach ($addOnProductList as $addOn){
      $manageVarient= DB::table('et_manage_addon_variant')
                      ->select(
                        'et_manage_addon_variant.sno',
                        'et_manage_addon_variant.amount',
                        'et_manage_addon_variant.free_paid',
                        'et_addon_variable.addon_variablename',
                      )
                      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                      ->where('et_manage_addon_variant.addon_id',$addOn->sno)
                      ->get();

      $addOn->add_varients=$manageVarient;
    }

    $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();
    
          // return $addOnProductList;

    $create_chk = PreProposalModel::where('lead_id', $lead_id)->where('status', 0)->first();

    if ($create_chk) {
      $Inserted_id = $create_chk->sno;
      $proposal_id_lead = $create_chk->proposal_id;
    } else {
      $category_check = PreProposalModel::orderBy('sno', 'desc')->first();

      if (!$category_check) {
       $year = date('Y');
          $month = date('m');
          $proposal_id = 'PRO-00001/' . $month.'/'. $year;
      } else {
          $year = date('Y');
          $month = date('m');
          $Inserted_id = $category_check->sno +1;
          $data = $category_check->proposal_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);
          $next_number = (int) $result + 1;
          $request_id = sprintf('PRO-%05d', $next_number);
          $proposal_id = $request_id . '/' .$month.'/'. $year;
      }
      $new_proposal_create = new PreProposalModel();
      $new_proposal_create->proposal_id = $proposal_id;
      $new_proposal_create->lead_id = $lead_id;
      $new_proposal_create->created_by = $user_id;
      $new_proposal_create->updated_by = $user_id;
      $new_proposal_create->save();
      $Inserted_id = $new_proposal_create->sno;
      $proposal_id_lead = $new_proposal_create->proposal_id;
    }
    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_id', $proposal_id_lead)->where('status',0)->where('package_id','!=',0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
     $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $proposal_id_lead)->first();
     
     $packageData = DB::table('et_proposal_package_cart')->where('proposal_id', $proposal_id_lead)->where('status',0)->orderBy('sno', 'asc')->get();
     
        $couponCode = null;

        if ($preProposal->discount_id >0) {
            $coupon = DB::table('et_manage_coupon')->where('sno', $preProposal->discount_id)->first();

            if ($coupon) {
                $couponCode = $coupon->coupon_code;
            }
        }
        
          $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();

          $oldstaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', '>' ,2)
                        ->where('et_staff.department_id', 1)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $oldstaff = $oldstaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          
           $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', '>',1)
                        // ->where('et_staff.department_id', 3)
                        // ->where('et_staff.sub_department_id', 6)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();

// return $preProposal;
    return view('content.lead_management.manage_proposal.proposal_add',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'currencyList' =>$currencyList,
      'Product_cat_list' =>$Product_cat_list,
      'Inserted_id' =>$Inserted_id,
      'addOnProductList' =>$addOnProductList,
      'branch_data' =>$branch_data,
      'proposal_id' =>$proposal_id_lead,
      'package_list' =>$package_list,
      'additional_charges_list' =>$additional_charges_list,
      'packageSlot' =>$packageSlot,
      'couponCode' => $couponCode,
        'preProposal' => $preProposal,
        'domainList' => $domainList,
        'crestaff' => $crestaff,
        'oldstaff' => $oldstaff,
        'referalStaff' => $referalStaff,
        'packageData' => $packageData,
    ]);
  }

  public function paymentSlotDetails($id,Request $request){

    $data = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_proposal_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();
    
    $productCart = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_proposal_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->first();
      if ($productCart === null) {
        $productCart = (object) [
            'product_names' => '',
            'product_category_names' => ''
        ];
    }
      $product_names=[];
      $product_Category_names=[];
    $slot_amount =0;
    $seen_product_ids = [];
    $seen_category_ids = [];
    
    $propsal_data=DB::table('et_pre_proposal')->where('sno',$id)->where('status',0)->first();
    
    $slotUpdate=0;
    $slotCount=0;

    foreach ($data as $single) {
        $slot = DB::table('et_proposal_pay_slot')
          ->where('proposal_id',$propsal_data->proposal_id)
          ->where('status', 0)
          ->get();
     
        if (!in_array($single->sno, $seen_product_ids)) {
            $product_names[] = $single->product_name;
            $seen_product_ids[] = $single->sno;
        }
         if (!in_array($single->product_category_id, $seen_category_ids)) {
            $product_Category_names[] = $single->product_category_name;
            $seen_category_ids[] = $single->product_category_id;
        }
     
      $slot_amount = $slot->sum('slot_amount');

      $slot_ids = $slot->pluck('sno')->toArray();
      $single->update_slot = $slot;
      if(count($slot) >0){
          $slotUpdate=1;
          $slotCount=count($slot);
      }
      
     }

$productCart->product_names = implode(', ', $product_names);
$productCart->product_category_names = implode(', ', $product_Category_names);

      $slot_amount =$slot_amount;
        return response()->json([
        'status' => 200,
        'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
        'error_msg' => null,
        'data' => $data,
        'slot_amount' => $slot_amount,
        'productCart' => $productCart,
        'slotUpdate' => $slotUpdate,
        'slotCount' => $slotCount,
      ]);

  }


   public function AddPaymentSlot(Request $request)
  {

    // return $request;
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;

     $pay_proposal_id = $request->input('pay_proposal_id');
     $propsal_data=DB::table('et_pre_proposal')->where('proposal_id',$pay_proposal_id)->where('status',0)->first();
          
       
     $total_amount_hidden = $request->input('payment_slot_total_hidden');
     $total_amount = $request->input('payment_slot_total_amt');
     $product_id = $request->input('payment_slot_product_id');
     $package = $request->input('package_payment_slot');
     $package_id = $request->input('payment_slot_package_id');
     $curency_format = $request->input('curency_format');
     
      $branch_data = DB::table('et_branch')->where('sno',$branch_id)->first();
      
      $gstPercentage=$branch_data->gst_percentage;

     if($package == 1){
        // $cart_ids=   DB::table('et_proposal_pay_slot')
        //     ->where('proposal_id', $pay_proposal_id)
        //     ->where('status', 0)
        //     ->where('product_cart_id' ,'!=',0)->pluck('product_cart_id');

           DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->where('product_cart_id' ,'!=',0)
            ->update(['status' => 2]);

    //   if($cart_ids){
    //         TempProposalModel::whereIn('sno', $cart_ids)->update(['status' => 2]);
    //     }

        $slots = [];
        foreach ($request->all() as $key => $value) {
            if (preg_match('/^payment_slot_id_packg_(\d+)$/', $key, $matches)) {
                $slots[] = (int)$matches[1];
            }
        }
        // return $slots;
      if($slots){
          $firstMilestoneSet = false;
       foreach ($slots as $index) {

        $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();
   

        $propo_pay_slot_id ='';
          if (!$category_check) {
              $year = date('Y');
              $month = date('m');
              $propo_pay_slot_id = 'PSLT-00001/' . $month.'/'. $year;
          } else {
              $year = date('Y');
              $month = date('m');
              $Inserted_id = $category_check->sno +1;
              $data = $category_check->propo_pay_slot_id;
              $slice = explode('/', $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
              $next_number = (int) $result + 1;
              $request_id = sprintf('PSLT-%05d', $next_number);
              $propo_pay_slot_id = $request_id . '/' .$month.'/'. $year;
            
          }

          $lastData = DB::table('et_proposal_pay_slot')->where('proposal_id',$pay_proposal_id)->where('status',0)->orderBy('sno', 'desc')->first();

          if($lastData){
            $total_amount =$lastData->balance_amount;
          }else{
            $total_amount = $request->input('payment_slot_total_amt');
          }
          $slot_id = $request->input("payment_slot_id_packg_{$index}");
          $slot_amount = $request->input("payment_slot_amount_packg_{$index}");
          
          $slot_description = $request->input("slot_description_packg_{$index}");
          $to_start_deliver = $request->input("to_start_deliver_packg_{$index}");
          
         
          
           $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
            $gst_amount = $slot_amount - $base_amount;

          $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
          // Get deliverables and notes as arrays and JSON encode them
          $slot_deliverables = $request->input("slot_deliverables_packg_{$index}", []);
          $slot_notes = $request->input("slot_notes_packg_{$index}", []);

          $json_deliverables = json_encode($slot_deliverables);
          $json_notes = json_encode($slot_notes);
          
           $first_milestone = $firstMilestoneSet ? 0 : 1;
            $firstMilestoneSet = true; // After first insert, all others become 0
           
           DB::table('et_proposal_pay_slot')->insert([
              'propo_pay_slot_id' => $propo_pay_slot_id, 
              'proposal_id' => $pay_proposal_id, 
              'lead_id' => $propsal_data->lead_id,
              'package_id' => $package_id,
              'slot_id' => $slot_id,
              'slot_amount' => $slot_amount,
              'start_deliver_work' => $to_start_deliver,
              'payable_amount' => $slot_amount,
              'total_amount' => $total_amount_hidden ?? $total_amount,
              'balance_amount' => $balance_amount,
              'slot_description' => $slot_description,
              'deliverable_ids' => $json_deliverables,
              'slot_notes_ids' => $json_notes,
              'gst_amount' => $gst_amount ?? 0,
              'branch_id' => $branch_id,
              'created_by' => $user_id,
              'updated_by' => $user_id,
              'first_milestone' => $first_milestone
          ]);

        }

       
      }
      

     }else{

       DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->where('package_id' ,'!=',0)
            ->update(['status' => 2]);

      // Count how many slots are in the request
      $slots = [];
      foreach ($request->all() as $key => $value) {
          if (preg_match('/^payment_slot_id_(\d+)$/', $key, $matches)) {
              $slots[] = (int)$matches[1];
          }
      }

        if($propsal_data){
             $firstMilestoneSet = false;
            foreach ($slots as $index) {

                $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = date('Y');
                    $month = date('m');
                    $propo_pay_slot_id = 'PSLT-00001/' . $month.'/'. $year;
                } else {
                    $year = date('Y');
                    $month = date('m');
                    $Inserted_id = $category_check->sno +1;
                    $data = $category_check->propo_pay_slot_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request_id = sprintf('PSLT-%05d', $next_number);
                    $propo_pay_slot_id = $request_id . '/' .$month.'/'. $year;
                }

                $lastData = DB::table('et_proposal_pay_slot')->where('proposal_id',$pay_proposal_id)->where('status',0)->orderBy('sno', 'desc')->first();

                if($lastData){
                  $total_amount =$lastData->balance_amount;
                }else{
                  $total_amount = $request->input('payment_slot_total_hidden');
                }

                $slot_id = $request->input("payment_slot_id_{$index}");
                $slot_amount = $request->input("payment_slot_amount_{$index}");
                  
                $to_start_deliver = $request->input("to_start_deliver_{$index}");
                $slot_description = $request->input("slot_description_{$index}");
                
               
                
                $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
                $gst_amount = $slot_amount - $base_amount;

                $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
                
               $slot_deliverables_raw = $request->input("slot_deliverables_{$index}", []);
                $deliverables_grouped = [];
                
                foreach ($slot_deliverables_raw as $item) {
                    if (strpos($item, '-') !== false) {
                        [$productIndex, $value] = explode('-', $item);
                        $deliverables_grouped[$productIndex][] = [
                            'value' => $value,
                            'status' => "0"
                        ];
                    }
                }
                
                // Same for notes
                $slot_notes_raw = $request->input("slot_notes_{$index}", []);
                $notes_grouped = [];
                
                foreach ($slot_notes_raw as $item) {
                    if (strpos($item, '-') !== false) {
                        [$productIndex, $value] = explode('-', $item);
                        $notes_grouped[$productIndex][] = [
                            'value' => $value,
                            'status' => "0"
                        ];
                    }
                }
                
                // Convert to JSON
                $json_deliverables = json_encode($deliverables_grouped);
                $json_notes = json_encode($notes_grouped);

                $first_milestone = $firstMilestoneSet ? 0 : 1;
                $firstMilestoneSet = true; // After first insert, all others become 0
                
                DB::table('et_proposal_pay_slot')->insert([
                    'propo_pay_slot_id' => $propo_pay_slot_id, 
                    'proposal_id' => $pay_proposal_id, 
                    'lead_id' => $propsal_data->lead_id,
                    'product_cart_id' => $product_id,
                    'cart_ids' => json_encode($request->input("product_cart_id_{$index}", [])),
                    'slot_id' => $slot_id,
                    'slot_amount' => $slot_amount,
                    'payable_amount' => $slot_amount,
                    'start_deliver_work' => $to_start_deliver,
                    'total_amount' => $total_amount_hidden,
                    'balance_amount' => $balance_amount,
                    'slot_description' => $slot_description,
                    'deliverable_ids' => $json_deliverables,
                    'slot_notes_ids' => $json_notes,
                    'gst_amount' => $gst_amount ?? 0,
                    'branch_id' => $branch_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'first_milestone' => $first_milestone
                ]);

            }

          // Example: Insert into DB (assuming you have a model or DB table for it)
          
        }
    }
   
    return redirect()->back();
  
  }


   public function UpdatePaymentSlot(Request $request)
  {
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
    // return $request;
       $pay_proposal_id = $request->input('pay_proposal_id');
        $package = $request->input('package_payment_slot');
        $package_id = $request->input('payment_slot_package_id');
     
        $propsal_data = DB::table('et_pre_proposal')
                ->where('proposal_id', $pay_proposal_id)
                ->where('status', 0)
                ->first();
      $update_ids = $request->input('update_ids', []);



    //  $total_amount_hidden = $request->input('payment_slot_total_hidden');
    //  $total_amount = $request->input('payment_slot_total_amt');
    //  $product_id = $request->input('payment_slot_product_id');
    //  $package = $request->input('package_payment_slot');
    //  $package_id = $request->input('payment_slot_package_id');
     DB::beginTransaction();
     if($package == 1){

        $cart_ids=   DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->where('product_cart_id' ,'!=',0)->pluck('product_cart_id');

           DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->where('product_cart_id' ,'!=',0)
            ->update(['status' => 2]);

       if($cart_ids){
            TempProposalModel::whereIn('sno', $cart_ids)->update(['status' => 2]);
        }

         $slotOldIds = DB::table('et_proposal_pay_slot')->where('proposal_id', $pay_proposal_id)
                               ->where('status', '!=', 2)
                               ->get();
            $existingSlotIds = $slotOldIds->pluck('sno')->toArray();

           
            $SlotToDelete = array_diff($existingSlotIds, $update_ids);
            $SlotToDelete = array_values($SlotToDelete);
       
      
            if (!empty($SlotToDelete)) {
                $deleteDoc= DB::table('et_proposal_pay_slot')->whereIn('sno', $SlotToDelete)
                                  ->update(['status' => 2]);
            }

          $previous_balance = null;

        foreach ($update_ids as $index => $id) {
            $slot_id = $request->input("payment_slot_id_packg_update_{$id}");
            $new_slot_amount = (float) $request->input("payment_slot_amount_packg_update_{$id}");
            $slot_description = $request->input("slot_description_packg_update_{$id}");

            $slot_deliverables = $request->input("slot_deliverables_packg_update_{$id}", []);
            $slot_notes = $request->input("slot_notes_packg_update_{$id}", []);

            $json_deliverables = json_encode((array) $slot_deliverables);
            $json_notes = json_encode((array) $slot_notes);

            // Fetch current DB record
            $existing_slot = DB::table('et_proposal_pay_slot')->where('sno', $id)->first();

            if ($existing_slot) {
                $old_payable = (float) $existing_slot->payable_amount;
                $old_balance = (float) $existing_slot->balance_amount;
                $total_amount = (float) $existing_slot->total_amount;

                if ($index === 0) {
                    // First record: only this one uses original balance logic
                    $diff = $new_slot_amount - $old_payable;
                    $new_balance = $old_balance - $diff;
                } else {
                    // Subsequent records: use last calculated balance
                    $new_balance = $previous_balance - $new_slot_amount;
                }

                // Update record
                DB::table('et_proposal_pay_slot')
                    ->where('sno', $id)
                    ->update([
                        'slot_id' => $slot_id,
                        'slot_amount' => $new_slot_amount,
                        'payable_amount' => $new_slot_amount,
                        'balance_amount' => $new_balance,
                        'slot_description' => $slot_description,
                        'deliverable_ids' => $json_deliverables,
                        'slot_notes_ids' => $json_notes,
                        'updated_by' => $user_id,
                    ]);

                // Set previous balance for next record
                $previous_balance = $new_balance;
            }
        }


        foreach ($request->all() as $key => $value) {
        if (preg_match('/^payment_slot_id_packg_edit_(\d+)$/', $key, $matches)) {
            $index = $matches[1];

            $slot_id = $request->input("payment_slot_id_packg_edit_{$index}");
            $slot_amount = $request->input("payment_slot_amount_packg_edit_{$index}");
            $slot_description = $request->input("slot_description_packg_edit_{$index}");

            $slot_deliverables = $request->input("slot_deliverables_packg_edit_{$index}", []);
            $slot_notes = $request->input("slot_notes_packg_edit_{$index}", []);

            $json_deliverables = json_encode((array)$slot_deliverables);
            $json_notes = json_encode((array)$slot_notes);

            // Generate new propo_pay_slot_id
            $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();
            $year = date('Y');
            $month = date('m');
            if (!$category_check) {
                $propo_pay_slot_id = 'PSLT-00001/' . $month . '/' . $year;
            } else {
                $data = $category_check->propo_pay_slot_id;
                $slice = explode('/', $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $request_id = sprintf('PSLT-%05d', $next_number);
                $propo_pay_slot_id = $request_id . '/' . $month . '/' . $year;
            }

            $lastData = DB::table('et_proposal_pay_slot')
                ->where('proposal_id', $pay_proposal_id)
                ->where('status', 0)
                ->orderBy('sno', 'desc')
                ->first();

            $slotData = DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->get();

            $payable_amount=$slotData->sum('payable_amount');


            $total_amount = $lastData ? $lastData->total_amount : $request->input('payment_slot_total_hidden');

            $balance_amount = $total_amount > 0 ? $total_amount - $payable_amount : 0;

            $new_balance_amount = $balance_amount - $slot_amount ;

            // return  $new_balance_amount;

            DB::table('et_proposal_pay_slot')->insert([
                'propo_pay_slot_id' => $propo_pay_slot_id,
                'proposal_id' => $pay_proposal_id,
                'lead_id' => $propsal_data->lead_id,
                'package_id' => $package_id,
                'slot_id' => $slot_id,
                'slot_amount' => $slot_amount,
                'payable_amount' => $slot_amount,
                'total_amount' => $total_amount,
                'balance_amount' => $new_balance_amount,
                'slot_description' => $slot_description,
                'deliverable_ids' => $json_deliverables,
                'slot_notes_ids' => $json_notes,
                'branch_id' => $branch_id,
                'created_by' => $user_id,
                'updated_by' => $user_id,
            ]);
        }
    }
      

     }else{

       DB::table('et_proposal_pay_slot')
            ->where('proposal_id', $pay_proposal_id)
            ->where('status', 0)
            ->where('package_id' ,'!=',0)
            ->update(['status' => 2]);

      // Count how many slots are in the request
      $slots = [];
      foreach ($request->all() as $key => $value) {
          if (preg_match('/^payment_slot_id_(\d+)$/', $key, $matches)) {
              $slots[] = (int)$matches[1];
          }
      }

        if($propsal_data){
            foreach ($slots as $index) {

                $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = date('Y');
                    $month = date('m');
                    $propo_pay_slot_id = 'PSLT-00001/' . $month.'/'. $year;
                } else {
                    $year = date('Y');
                    $month = date('m');
                    $Inserted_id = $category_check->sno +1;
                    $data = $category_check->propo_pay_slot_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request_id = sprintf('PSLT-%05d', $next_number);
                    $propo_pay_slot_id = $request_id . '/' .$month.'/'. $year;
                }

                $lastData = DB::table('et_proposal_pay_slot')->where('proposal_id',$pay_proposal_id)->where('status',0)->orderBy('sno', 'desc')->first();

                if($lastData){
                  $total_amount =$lastData->balance_amount;
                }else{
                  $total_amount = $request->input('payment_slot_total_hidden');
                }

                $slot_id = $request->input("payment_slot_id_{$index}");
                $slot_amount = $request->input("payment_slot_amount_{$index}");
                $slot_description = $request->input("slot_description_{$index}");

                $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
                // Get deliverables and notes as arrays and JSON encode them
                $slot_deliverables = $request->input("slot_deliverables_{$index}", []);
                $slot_notes = $request->input("slot_notes_{$index}", []);

                $json_deliverables = json_encode($slot_deliverables);
                $json_notes = json_encode($slot_notes);


                DB::table('et_proposal_pay_slot')->insert([
                    'propo_pay_slot_id' => $propo_pay_slot_id, 
                    'proposal_id' => $pay_proposal_id, 
                    'lead_id' => $propsal_data->lead_id,
                    'product_cart_id' => $product_id,
                    'slot_id' => $slot_id,
                    'slot_amount' => $slot_amount,
                    'payable_amount' => $slot_amount,
                    'total_amount' => $total_amount_hidden,
                    'balance_amount' => $balance_amount,
                    'slot_description' => $slot_description,
                    'deliverable_ids' => $json_deliverables,
                    'slot_notes_ids' => $json_notes,
                    'branch_id' => $branch_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id
                ]);

            }

          // Example: Insert into DB (assuming you have a model or DB table for it)
          
        }
     }
     DB::commit();
    return redirect()->back();
  
  }

  public function GeneratePropsal(Request $request){
    
        // return $request;
    
        $branch_id = $request->user()->branch_id;
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        


        $proposal_id = $request->input('proposal_hidden_id');
        $lead_id = $request->input('proposal_lead_id');
        $service_title = $request->input('prposal_service_title');
        $domain_ids = $request->input('proposal_domain');
        $milestone_count = $request->input('milestone_count');
        $topic = $request->input('proposal_topic');
        $cre_id = $request->input('proposal_cre');
        $due_date = $request->input('prposal_due_date') ? date('Y-m-d', strtotime($request->input('prposal_due_date'))) : null;
        $estimate_date = $request->input('estimate_date') ? date('Y-m-d', strtotime($request->input('estimate_date'))) : null;
        $currency_id = $request->input('prposal_currency');
        $proposal_date = date('Y-m-d');
        $package_check = $request->input('serv_prod_pckg_chk');
        $sub_total = $request->input('sub_total_amount');
        $discount_id = $request->input('discount_id_hidden');
        $discount_amount = $request->input('discounted_amount_hidden');
        $gst_amount = $request->input('gst_amount_hidden');
        $gst_perc = $request->input('gst_perc_hidden');
        $additional_charge_perc = $request->input('additional_charge_perc');
        $additional_charge_amount = $request->input('additional_charge_amount');
        $addtional_charges_id = $request->input('addtional_charges_id');
        $delivery_duration = $request->input('delivery_duration');
        $delivery_duration_end = $request->input('delivery_duration_end');
        $total_amount = $request->input('proposal_total_amount');
        $grant_total_amount = $request->input('grant_total_amount');
        $package_id = $request->input('package_id');
        $gst_inclusive = $request->input('gst_inclusive');
        $send_communication = $request->input('send_communication');
        $page_word = $request->input('page_word');
        $page_word_count = $request->input('page_word_count');
        $referral_id = $request->input('proposal_referral_staff');
        $old_customer_check = $request->input('old_customer_check') ?? 0;

        $addtional_charges_ids= $addtional_charges_id ? json_encode($addtional_charges_id) : null;
        $domain_ids= $domain_ids ? json_encode($domain_ids) : null;
        
        

        DB::beginTransaction();
        // 1. Insert into et_proposal
       
        $proposal_add = new ProposalModel();

        $proposal_add->proposal_id = $proposal_id;
        $proposal_add->lead_id = $lead_id;
        $proposal_add->service_title = $service_title;
        $proposal_add->domain_ids = $domain_ids;
        $proposal_add->topic = $topic;
        $proposal_add->cre_id = $cre_id;
        $proposal_add->milestone_count = $milestone_count;
        $proposal_add->product_package = $package_check;
        $proposal_add->package_id = $package_id ?? 0;
        $proposal_add->due_date = $due_date;
        $proposal_add->estimate_date = $estimate_date;
        $proposal_add->currency_id = $currency_id;
        $proposal_add->propsal_date = $proposal_date;
        $proposal_add->sub_total = $sub_total;
        $proposal_add->discount_id = $discount_id;
        $proposal_add->discount_amount = $discount_amount;
        $proposal_add->gst_amount = $gst_amount;
        $proposal_add->total_amount = $total_amount;
        $proposal_add->grant_total_amount = $grant_total_amount;
        $proposal_add->created_by = $user_id;
        $proposal_add->updated_by = $user_id;
        $proposal_add->branch_id = $branch_id;
        $proposal_add->delivery_duration = $delivery_duration;
        $proposal_add->delivery_duration_end = $delivery_duration_end;
        $proposal_add->gst_perc = $gst_perc;
        $proposal_add->gst_inclusive = $gst_inclusive ?? 0;
        $proposal_add->parent_id = $proposal_id;
        $proposal_add->additional_charge_perc = $additional_charge_perc;
        $proposal_add->additional_charge_amount = $additional_charge_amount;
        $proposal_add->addtional_charges_ids = $addtional_charges_ids;
        $proposal_add->send_status = $send_communication == 1 ? 1 : 0;
        $proposal_add->verify_status = $send_communication == 1 ? 1 : 0;
        $proposal_add->page_word = $page_word;
        $proposal_add->page_word_count = $page_word_count ?? 0;
        $proposal_add->referral_id = $referral_id ?? 0;
        $proposal_add->old_customer_check = $old_customer_check ?? 0;
        
        
        // Save the proposal and get the ID of the newly created record
        $add_category = $proposal_add->save() ? $proposal_add->sno : null; 
       
            DB::table('et_proposal_pay_slot')
                ->where('proposal_id', $proposal_id)
                ->where('status', 0)
                ->update(['proposal_sno' => $add_category]);
                
                $lead_update =  LeadModel::where('sno', $lead_id)->first();
 
    if ($lead_update) {
      if ($lead_update->potential_verify == 1) {
 
        $old_staff_id = $lead_update->created_by;
 
        // Close previous transfer history
        $lead_history = LeadTransferLogModel::where('lead_id', $lead_id)
          ->whereNull('end_date')
          ->where('current_staff_id', $old_staff_id)
          ->first();
 
        if ($lead_history) {
          $lead_history->end_date = date('Y-m-d');
          $lead_history->change_staff_id = $request->convert_staff_id ?? $user_id;
          // $lead_history->transferred_from = 15; // spam transfer
          $lead_history->save();
        }
 
        // New transfer history entry
        $add_history = new LeadTransferLogModel();
        $add_history->lead_id = $lead_update->sno;
        $add_history->branch_id = $lead_update->branch_id;
        $add_history->start_date = date('Y-m-d'); // new start date = today
        $add_history->current_staff_id = $request->convert_staff_id ?? $user_id;
        $add_history->change_staff_id = 0;
        $add_history->transferred_from = 17;
        $add_history->created_by = $user_id;
        $add_history->updated_by = $user_id;
        $add_history->save();
 
        // Update lead details
        $lead_update->status = 0;
        $lead_update->drop_verified = 0;
        $lead_update->drop_tl_verified = 0;
        $lead_update->spam_verified = 0;
        $lead_update->spam_tl_verified = 0;
        $lead_update->internal_status = 0;
        $lead_update->lead_status_id = 1;
        $lead_update->transfer_status = 1;
        $lead_update->potential_verify = 0;
        $lead_update->created_by = $request->convert_staff_id ?? $user_id;
        $lead_update->updated_by   = $user_id;
        $lead_update->converted_by = $user_id;
        $lead_update->save();
      }
    }

        if($package_check == 1){

          if ($request->has('addOn_chk')) {
            foreach ($request->input('addOn_chk') as $addOnId) {
                $variant_key = "addOn_varient_$addOnId";
                $variant_id = $request->input($variant_key);
        
                if ($currency_id != 70) {
                    // If currency_id is not 70, fetch amount from et_price_book
                    $priceDataAddon = DB::table('et_price_book')
                        ->where('currency_id', $currency_id)
                        ->where('status', 3)
                        ->get();
                        
                        $addon_data = DB::table('et_manage_addon_variant')
                        ->where('sno', $variant_id)
                        ->first();
        
                    // Find the addon amount from varient_details where variant_id matches
                    $addon_amount = 0; // Default to 0 if no match found
                    foreach ($priceDataAddon as $addon) {
                        $variantDetails = json_decode($addon->varient_details);
                        foreach ($variantDetails as $variant) {
                            if ($variant->variant_id == $variant_id) {
                                $addon_amount = $variant->amount; // Get the amount from varient_details
                                break 2; // Exit both loops once the matching variant is found
                            }
                        }
                    }
                } else {
                    // If currency_id is 70, fetch data from et_manage_addon_variant table
                    $addon_data = DB::table('et_manage_addon_variant')
                        ->where('sno', $variant_id)
                        ->first();
        
                    // Set the addon_amount based on the fetched data
                    $addon_amount = $addon_data ? $addon_data->amount : 0;
                }
        
                // Insert into et_proposal_addon_product table
                DB::table('et_proposal_addon_product')->insert([
                    'proposal_id' => $proposal_id,
                    'proposal_sno' => $add_category,
                    'add_on_id' => $addOnId,
                    'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
                    'addon_variant_id' => $variant_id,
                    'addon_amount' => $addon_amount,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'branch_id' => $branch_id,
                ]);
            }
        }

          // 3. Insert into et_proposal_product_cart
          $temp_id = $request->input('Inserted_id_product');
          $product_cart_data = DB::table('et_temp_proposal_cart')
              ->where('temp_proposal_id', $temp_id)
              ->where('status', 0)
              ->get();

          foreach ($product_cart_data as $cart) {
              DB::table('et_proposal_product_cart')->insert([
                  'proposal_id' => $proposal_id,
                  'proposal_sno' => $add_category,
                  'product_id' => $cart->product_id,
                  'product_amount' => $cart->cust_product_amount,
                  'original_amount' => $cart->product_amount,
                  'cart_id' => $cart->sno,
                  'variant_variable_ids' => $cart->variant_variable_ids,
                  'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'branch_id' => $branch_id,
              ]);
          }
        }else{
            
            if ($request->has('addOn_chk')) {
                foreach ($request->input('addOn_chk') as $addOnId) {
                    $variant_key = "addOn_varient_$addOnId";
                    $variant_id = $request->input($variant_key);
            
                    if ($currency_id != 70) {
                        // If currency_id is not 70, fetch amount from et_price_book
                        $priceDataAddon = DB::table('et_price_book')
                            ->where('currency_id', $currency_id)
                            ->where('status', 3)
                            ->get();
                            
                            $addon_data = DB::table('et_manage_addon_variant')
                            ->where('sno', $variant_id)
                            ->first();
            
                        // Find the addon amount from varient_details where variant_id matches
                        $addon_amount = 0; // Default to 0 if no match found
                        foreach ($priceDataAddon as $addon) {
                            $variantDetails = json_decode($addon->varient_details);
                            foreach ($variantDetails as $variant) {
                                if ($variant->variant_id == $variant_id) {
                                    $addon_amount = $variant->amount; // Get the amount from varient_details
                                    break 2; // Exit both loops once the matching variant is found
                                }
                            }
                        }
                    } else {
                        // If currency_id is 70, fetch data from et_manage_addon_variant table
                        $addon_data = DB::table('et_manage_addon_variant')
                            ->where('sno', $variant_id)
                            ->first();
            
                        // Set the addon_amount based on the fetched data
                        $addon_amount = $addon_data ? $addon_data->amount : 0;
                    }
            
                    // Insert into et_proposal_addon_product table
                    DB::table('et_proposal_addon_product')->insert([
                        'proposal_id' => $proposal_id,
                        'proposal_sno' => $add_category,
                        'add_on_id' => $addOnId,
                        'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
                        'addon_variant_id' => $variant_id,
                        'addon_amount' => $addon_amount,
                        'created_by' => $user_id,
                        'updated_by' => $user_id,
                        'branch_id' => $branch_id,
                    ]);
                }
            }
            
          $temp_id = $request->input('Inserted_id_product');
            DB::table('et_temp_proposal_cart')
                ->where('temp_proposal_id', $temp_id)
                ->where('status', 0)
                ->update(['status' => 2]);

                 $packageTemp = DB::table('et_package')->where('status', 0)
                    ->where('sno', $package_id)
                    ->first();

            $packageData = DB::table('et_package_product')->where('status', 0)
              ->where('package_id', $package_id)
              ->orderBy('sno', 'asc')
              ->get();
              
               DB::table('et_proposal_package_cart')
                ->where('proposal_id', $proposal_id)
                ->where('status', 0)
                ->update(['proposal_sno' => $add_category]);

            //   if(isset($packageData)){
            //       foreach($packageData as $package){
            //           $add_package_cart= DB::table('et_proposal_package_cart')->insert([
            //               'proposal_id' => $proposal_id,
            //               'proposal_sno' => $add_category,
            //               'package_id' => $package_id,
            //               'product_id' => $package->product_id,
            //               'product_amount' => $package->product_amount,
            //               'variant_variable_ids' => $package->variant_variable_ids,
            //               'created_by' => $user_id,
            //               'updated_by' => $user_id,
            //               'branch_id' => $branch_id,
            //           ]);
            //       }
            //   }

                 

        }

        // 2. Insert into et_proposal_addon_product
        

        DB::commit();
        // send Communication
        if ($add_category) {
            if($send_communication == 1){
            $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$add_category)->first();
            $leadData=DB::table('et_lead')->where('et_lead.sno',$lead_id)->first();
            $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
            
            $helper = new \App\Helpers\Helpers();
              $encrypted_values = $helper->encrypt_decrypt($proposalData->sno, 'encrypt');
        
            //   $Link ='https://erp.elysiumtechnologies.com/manage_proposal/send_proposal/'.$encrypted_values;
              $Link =url('manage_proposal/send_proposal/' . $encrypted_values);
              
            //  communication Proposal
            $communicationStatus=DB::table('et_communication_handle')->where('module_name','Proposal Send')->first();
             $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposalData->cre_id)->first();
            if($communicationStatus && $communicationStatus->status == 0){
       
             if(!$proposalData->temp_send_link){
                 $channelId = 4;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                  if($shortUrl){
                        DB::table('et_proposal')
                        ->where('sno', $proposalData->sno)
                        ->update(['temp_send_link' => $shortUrl]);
                        
                          DB::table('et_chotta_links')->insert([
                                  'branch_id' => $branch_id,
                                  'chotta_link_id' => $urlId,
                                  'chotta_short_link' => $shortUrl,
                                  'large_encrypt_link' => $Link,
                                  'link_type' => 'Proposal Send',
                                  'proposal_id' => $proposalData->sno,
                                  'created_by' => $user_id,
                                  'updated_by' => $user_id,
                              ]);
                        
                  }
              }
            
              $proposalUrl=DB::table('et_proposal')->where('et_proposal.sno',$add_category)->first();
              
              $shortsendUrl = $proposalUrl->temp_send_link ;
              
              $proposal_key = basename($shortsendUrl);
            
           
              $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
              $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
         
          
            $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
            
               $lead_name =$leadData->lead_name;
               $lead_email_id =$leadData->lead_email_id;
               $lead_mobile =$leadData->lead_mobile;
            // // sms proposal send
                if($communicationStatus->sms ==0){
                    if ($lead_mobile) {
        
                          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
                          $authkey = $result_sms ? $result_sms->authkey : '';
                          $sender_id = $result_sms ? $result_sms->sender_id : '';
                          $template_id = $result_sms ? $result_sms->template_id : '';
                          $country_code = $result_sms ? $result_sms->country_code : '';
                          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                          $mobile_number = $country_code . $lead_mobile;
                
                         
                          $proposal_sms_id=$proposalData->proposal_id ?? 'PRO-00001/06/2025';
                
                          // Replace placeholders with actual values
                          $replacement_values = [$lead_name,$proposal_sms_id, $shortsendUrl,$cre_mobile];
                          $message_content = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                              return array_shift($replacement_values);
                            },
                            $message_content
                          );
                
                          $route = "default";
                          $postData = array(
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender' => $sender_id,
                            'route' => $route,
                          );
                
                          // API URL
                          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                
                          // Initialize the resource
                          $ch = curl_init();
                          curl_setopt_array($ch, array(
                            CURLOPT_URL => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                          ));
                
                          // Get response
                          $response = curl_exec($ch);
                          // return $response;
                          $err = curl_error($ch);
                          curl_close($ch);
                        }
                }
                
                // email proposal Send
                 if($communicationStatus->email ==0){
                  if ($lead_email_id) {
                        $emailTemplate_id =1; // proposal send Template Id
                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
            
                    // Gender condition
                    $genderPrefix = 'Mr/Ms'; // Default value
                    if ($leadData->lead_gender == 1) {
                      $genderPrefix = 'Mr';
                    } elseif ($leadData->lead_gender == 2) {
                      $genderPrefix = 'Ms';
                    }
                    
                    
                   
                    
                    $content = $emailTemplate->email_subject;
            
                    $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
            
                    $content = str_replace('#customer_name', $lead_name, $content);
                    $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
                    $content = str_replace('#link', $shortsendUrl, $content);
                    $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                    $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
                    $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
                    $branchNo = $branch->mobile;
                    $branchemail = $branch->mail;
                    $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                    $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                    $url= 'phdizone.com';
            
                    $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $cre_mobile ?? '8220011465',
                      ];
            
                    $to_address = $lead_email_id;
                    $from_address = 'elysiumtechnology@elysium.community';
                    $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
            
            
                    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                 }
                 }
                // whatsapp proposal send
                 if($communicationStatus->whatsapp ==0){
                  if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "proposal_phdizone";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'proposal_phdizone') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg'; 
                                $headerImage =  url('public/assets/phdizone_images/OnBoard.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           => $lead_name,
                                        'parameter_name' => 'customer_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposalData->proposal_id,
                                        'parameter_name' => 'proposal_id',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposal_key,
                                        'parameter_name' => 'proposal_key',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $cre_mobile ?? '8220011465',
                                        'parameter_name' => 'customercare_number',
                                    ],
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $proposal_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$entity_id)->orderBy('sno', 'desc')->first();
                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                            $accessToken               = $whatsappApi->access_tokken ?? '';
                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                            $countryCode  = $leadData->inter_calls ? ($leadData->inter_calls == 0 ? '+91' : '+' . $leadData->inter_calls) : '+91';
                            $to           = $lead_mobile;
                            $languageCode = 'en';
                
                            if (strpos($to, $countryCode) !== 0) {
                                $to = $countryCode . $to;
                            }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {}
                         else{
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
                 }
                
            }else{
                $old_customer_check = 1 ;
                if(!$proposalData->temp_send_link){
                    //  Skip Communication For Old Customer
                    DB::table('et_proposal')
                            ->where('sno', $add_category)
                            ->update([
                                'temp_send_link' => $Link,
                                'old_customer_check'=>$old_customer_check,
                                ]);
                }
            }
            
        }
        }
        
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Proposal Created Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Create the Proposal!'
          ]);
        }
        return redirect('manage_proposal');
  }

   public function product_list_proposal($id,Request $request)
  {
    $data = DB::table('et_temp_proposal_cart')->where('status', 0)
      ->where('temp_proposal_id', $id)
      ->orderBy('sno', 'asc')
      ->get();
      $product_cart_count=count($data);
    //   $currency_id=$request->currency_id;
    //   return $currency_id;
      $productCounts = $data->groupBy('product_id')->map(function ($group) {
          return $group->count();
      });
    $html = '';
    $over_all_total = 0;
    $totalMinutes = 0;
    foreach ($data as $inx => $list) {
      $product_id = $list->product_id;
      $currency_id = $list->currency_id;
       $product_count = $productCounts[$product_id];
      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
      $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };
      
      $priceData = DB::table('et_price_book')->select('et_price_book.*','et_country_currencies.currency_symbol')
       ->join('et_country_currencies', 'et_price_book.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_price_book.currency_id', $currency_id)
        ->where('et_price_book.product_id', $product_id)
        ->first();
        

      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
      $variant = '';
      $variable_amount = 0;
    $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);

      // If json_decode returns a string instead of an array, ensure it defaults to an empty array
      if (!is_array($variant_variable_ids)) {
          $variant_variable_ids = [];
      }

      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
          // Ensure that $v is an array and has the keys you expect
          if (is_array($v) && isset($v['variant_id']) && isset($v['variable_id'])) {
              $selected_pairs[$v['variant_id']] = $v['variable_id'];
          }
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
        $variant .= '
                  <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                  <div class="d-flex align-items-center justify-content-between">
                      <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                      <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                  <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                              </svg>
                          </span>
                      </a>
                  </div>
                  <!-- Modal -->
                   <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" id="kt_modal_choose_me_triger_edit' . htmlspecialchars($product_id) . '">
                  <div class="modal fade" id="kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content rounded">
                              <div class="modal-header justify-content-end border-0 pb-0">
                                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                      <span class="svg-icon svg-icon-1">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                          </svg>
                                      </span>
                                  </div>
                              </div>

                              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                  <div class="mb-8 text-center">
                                      <h3 class="text-center mb-4 text-black">Update Product</h3>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_name) . '</div>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_category_name) . '</div>
                                  </div>

                                  <div class="divider mt-1 mb-1">
                                      <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                  </div>
                                  <input type="hidden"id="Inserted_id_product_edit" name="Inserted_id_product_edit" value="' . htmlspecialchars($list->temp_proposal_id) . '">
                                  <input type="hidden" name="product_id_edit" value="' . htmlspecialchars($product_id) . '">
                                  <div class="row">
                                      <div class="col-lg-12 mb-1">
                                          <div class="bg-gray-200i rounded">
                                              <div class="scroll-y max-h-400px py-2 px-3">';

                                                $get_variants_loop = ManageProductVaiantModel::where('product_id', $product_id)->get();

                                                if ($get_variants_loop->count()) {
                                                  foreach ($get_variants_loop as $vari) {
                                                    $variant_checked = in_array($vari->sno, $selected_variants);
                                                    $show_div = $variant_checked ? 'block' : 'none';
                                                    $get_variables_loop = ManageProductVariableModel::where('product_variant_id', $vari->sno)->get();
                                                    $variant .= '<div class="px-3 pt-1">
                                                                    <div class="form-check form-check-inline mb-1 mt-1">
                                                                        <input class="form-check-input" type="checkbox" id="variant_check_box_edit' . htmlspecialchars($vari->sno) . '" onclick="variant_check_func_edit(' . htmlspecialchars($vari->sno) . ');" ' . ($variant_checked ? 'checked' : '') . ' />
                                                                        <label class="text-black mb-1 fs-6 fw-semibold">' . htmlspecialchars($vari->product_variant_name) . '</label>
                                                                    </div>
                                                                    <div id="variant_check_div_edit' . htmlspecialchars($vari->sno) . '" style="display: ' . $show_div . ';">
                                                                        <div class="row mt-2">';

                                                  foreach ($get_variables_loop as $vrlist) {
                                                    $is_selected = (isset($selected_pairs[$vari->sno]) && $selected_pairs[$vari->sno] == $vrlist->sno);
                                                    $variant .= '<div class="col-lg-4 mb-1">
                                                                      <div class="form-check">
                                                                          <input class="form-check-input me-0 variable_radio_edit' . htmlspecialchars($vari->sno) . '" type="radio" name="variable_radio_[' . htmlspecialchars($vari->sno) . ']" value="' . htmlspecialchars($vrlist->sno) . '" ' . ($variant_checked ? '' : 'disabled') . ' ' . ($is_selected ? 'checked' : '') . ' />
                                                                          <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                              <span>' . htmlspecialchars($vrlist->variable_name) . '</span>
                                                                              <span class="ms-1 me-1">-</span>
                                                                              <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; ' . number_format($vrlist->variable_amount) . '</span>
                                                                          </label>
                                                                      </div>
                                                                  </div>';
                                                  }

                                                  $variant .= '</div>
                                                                  <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                              </div>
                                                          </div>';
                                                }
                                              } else {
                                                $variant .= '<label class="row text-center">
                                                                <span class="text-danger fs-5">No Variant found for this <b class="text-black">' . htmlspecialchars($product_data->product_name) . '</b> Product</span>
                                                            </label>';
                                              }

                                              $variant .= '
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="d-flex justify-content-center align-items-center mt-8">
                                      <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                      <button type="button" class="btn btn-primary" onclick="edit_product(' . htmlspecialchars($product_id) . ')" id="product_button_edit_' . htmlspecialchars($product_id) . '">Update Product</button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }

     

      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
          
          
          $priceBookAmount = $get_variables->variable_amount; // Default amount from loop
        if ($currency_id != 70) {
            $variant_details = json_decode($priceData->varient_details, true);
            // Check if $variant_details is an array and loop through it to find the correct amount
            if (is_array($variant_details)) {
                foreach ($variant_details as $variant_detail) {
                    if ($variant_detail['variable_id'] == $variable_id) {
                        $priceBookAmount = $variant_detail['amount'];
                        break;
                    }
                }
            }
        }
          if ($get_variants && $get_variables) {
            $variable_amount += $get_variables->variable_amount;
            
            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($priceBookAmount) . '</label>
                  </div>
              </div>';
          }
        }
      }


      $total_amount = $list->cust_product_amount ?? $variable_amount + $product_data->base_price;
      $over_all_total += $total_amount;
                $productBasePrice =$product_data->base_price;
                if ($currency_id != 70) {
                    $productBasePrice =$priceData->base_price;
                }

                $html .= '<div class="mb-1" id="cal_prod_az_' . $inx . '">
                      <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_hd_' . $inx . '">
                        <div class="d-flex align-items-center">
                          <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_on_of(' . $inx . ');" id="cal_prod_tlp_' . $inx . '">
                              <i class="mdi mdi-plus fs-4" id="cal_prod_plus_btton_' . $inx . '"></i>
                            </a>
                          </div>
                          <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                            <div class="d-block">
                              <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                            </div>
                          </div>
                        </div>
                        <div class="mb-0">
                          <label class="fs-4 fw-semibold text-black">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($total_amount) . '</label>
                          <input type="hidden" class="cart_product_amount" value="'.$total_amount.'">
                          <a href=" javascript:;" class="ms-1 fw-semibold fs-5" onclick="remove_product(' . intval($list->sno) . ',' . $product_id . ')">
                            <span title="Remove">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                  <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                    <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                      <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                      <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                    </g>
                                  </g>
                                </g>
                              </svg>
                            </span>
                          </a>
                        </div>
                      </div>
                      <div class="px-3 py-1 mb-0" id="cal_prod_tbox_' . $inx . '" style="display: none;">
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Products</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($productBasePrice) . '</label>
                          </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Durations</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                          </div>
                        </div>
                        ' . $variant . '
                      </div>
                    </div>';
    }
    // Time unit conversions
    $minutesInMonth = 30 * 1440; // 43,200
    $minutesInDay = 1440;
    $minutesInHour = 60;

    // Breakdown
    $months = floor($totalMinutes / $minutesInMonth);
    $remainingAfterMonths = $totalMinutes % $minutesInMonth;

    $days = floor($remainingAfterMonths / $minutesInDay);
    $remainingAfterDays = $remainingAfterMonths % $minutesInDay;

    $hours = floor($remainingAfterDays / $minutesInHour);
    $minutes = round($remainingAfterDays % $minutesInHour);

    // Build result string conditionally
    $durationParts = [];

    if ($months > 0) {
      $durationParts[] = "{$months} Month" . ($months != 1 ? 's' : '');
    }
    if ($days > 0 || $months > 0) {
      $durationParts[] = "{$days} Day" . ($days != 1 ? 's' : '');
    }
    if ($hours > 0 || $days > 0 || $months > 0) {
      if ($hours > 0) {
        $durationParts[] = "{$hours} Hour" . ($hours != 1 ? 's' : '');
      }
    }

    if ($minutes > 0 || empty($durationParts)) {
      $durationParts[] = "{$minutes} Minute" . ($minutes != 1 ? 's' : '');
    }

    $totalDuration = implode(' ', $durationParts);
    $overall_totalDuration = $totalDuration ?: '0';




    $product_ids = $data->pluck('product_id')->toArray();
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $html,
      'product_ids' => $product_ids,
      'over_all_total' => $over_all_total,
      'overall_totalDuration' => $overall_totalDuration,
      'productCounts' => $productCounts,
      'product_cart_count' => $product_cart_count,
    ]);
  }

   public function product_list_proposal_delete($id)
  {

    $upd_DepartmentModel = TempProposalModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

    public function proposal_product_add(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Get raw JSON input
    $payload = $request->all(); // use $request->getContent() and json_decode if content-type is not handled automatically

    $Inserted_id = $payload['inserted_id'] ?? null;
    $product_id  = $payload['product_id'] ?? null;
    $variants    = $payload['variants'] ?? [];
    $currency_id    = $payload['currency_id'] ?? [];
    $product_amount  = $payload['product_amount'] ?? null;
    $product_edit_amount  = $payload['product_edit_amount'] ?? null;
    if (!$Inserted_id || !$product_id) {
      return response()->json([
        'status' => false,
        'message' => 'Missing required data.',
        'data' => null
      ]);
    }

    // Store variants as JSON for now (you can normalize later if needed)
    $variant_variable_ids = !empty($variants) ? json_encode($variants) : null;

    // Check if record already exists
    // $existing = TempProposalModel::where('temp_proposal_id', $Inserted_id)
    //   ->where('product_id', $product_id)
    //   ->first();

    // if ($existing) {
    //   $existing->variant_variable_ids = $variant_variable_ids;
    //   $existing->updated_by = $user_id;
    //   $existing->status = 0;
    //   $existing->save();
    //   $record = $existing;
    // } else {
      $record = new TempProposalModel();
      $record->temp_proposal_id = $Inserted_id;
      $record->product_id = $product_id;
      $record->currency_id = $currency_id;
      $record->cust_product_amount = $product_edit_amount;
      $record->product_amount = $product_amount;
      $record->variant_variable_ids = $variant_variable_ids;
      $record->created_by = $user_id;
      $record->updated_by = $user_id;
      $record->status = 0;
      $record->save();
    // }
    
    DB::table('et_pre_proposal')
        ->where('sno', $Inserted_id)
        ->update([
            'currency_id' =>$currency_id,
        ]);

    return response()->json([
      'status' => true,
      'message' => 'Product variant(s) added to package successfully.',
      'data' => $record
    ]);
  }

   public function get_couponcode(Request $request)
  {
    $couponcode = $request->couponcode;
    // Check if a coupon code was provided and find the coupon details
    if ($couponcode != null || $couponcode != "") {
      $coupon_details = DB::table('et_manage_coupon')->where('coupon_code', $couponcode)->first();
    } else {
      $coupon_details = "";
    }
    if ($coupon_details) {

      if ($coupon_details->coupon_type == 'percentage') {
        // Coupon is valid
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 0;
      } else {
        $discount = $coupon_details->coupon_value ?? 0;
        $discount_type = 1;
      }


      return response()->json([
        'status' => 200,
        'discount_id' => $coupon_details ? $coupon_details->sno :0,
        'discount' => $discount,
        'discount_type' => $discount_type,
        'message' => 'Coupon code applied successfully.',
      ]);
    } elseif (empty($couponcode)) {
      return response()->json([
        'status' => 404,
        'discount' => '0',
        'discount_type' => '-',
        'message' => 'Invalid coupon code.',
      ]);
    } else {
      return response()->json([
        'status' => 404,
        'discount' => '0',
        'discount_type' => '-',
        'message' => 'Invalid coupon code.',
      ]);
    }
  }

  public function DeliverableList(Request $request)
  {

    $entity = DB::Table('et_product_delivarables')->where('et_product_delivarables.status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $entity
    ], 200);
  }

   public function PaymentSlotList(Request $request)
  {

    $entity = DB::Table('et_payment_slot')->where('et_payment_slot.status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $entity
    ], 200);
  }
   public function SlotNotesList(Request $request)
  {

    $entity = DB::Table('et_slot_notes')->where('et_slot_notes.status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $entity
    ], 200);
  }

 public function PackageData(Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $branch_id = $request->user()->branch_id;
    $id = $request->input('id');
    $proposal_id = $request->input('proposal_id');
    $currency_id = $request->input('currency_id');
    $package = DB::table('et_package')
            ->select('et_package.*')
            ->where('et_package.status',0)
            ->where('et_package.sno', $id)
            ->first();

              $html = '';
              $productHtml = '';
    $over_all_total = 0;
    $totalMinutes = 0;
      
    $package_product = DB::table('et_package_product')
          ->select('et_package_product.*')
          ->join('et_product', 'et_package_product.product_id', 'et_product.sno')
          ->where('et_package_product.status',0)
          ->where('et_package_product.package_id', $id)
          ->get();
     $priceData = DB::table('et_price_book')->select('et_price_book.*','et_country_currencies.currency_symbol')
       ->join('et_country_currencies', 'et_price_book.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_price_book.currency_id', $currency_id)
        ->where('et_price_book.package_id',  $id )
        ->first();
        
         $currencyData = DB::table('et_country_currencies')
            ->where('et_country_currencies.sno',  $currency_id )
            ->first();
    foreach($package_product as  $inx=> $list){

       $product_id = $list->product_id;
      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
         $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };

      $productBasePrice =$product_data->base_price;
      
      if ($priceData) {
          
            $variantDetails = json_decode($priceData->varient_details, true); 
                foreach ($variantDetails as $variant) {
                    if ($product_id == $variant['product_id']) {
                         $productBasePrice  = $variant['base_price']; // override amount
                     
                    }
                }
           
        }

      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
         $variant = '';
            $variable_amount = 0;
     $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);

     $facilities = json_decode($product_data->facility_ids ?? '[]', true);

     $faccility_count=count( $facilities);

      // If json_decode returns a string instead of an array, ensure it defaults to an empty array
      if (!is_array($variant_variable_ids)) {
          $variant_variable_ids = [];
      }

           
           $currency_symbol ='₹';
           $setpriceBook=true;
           if($priceData ){
                if ($currency_id != 70) {
                    $currency_symbol=$priceData->currency_symbol;
                    $package->actual_amount=$priceData->actual_price;
                } 
           }else{
               $setpriceBook= false;
           }
           
           if($currency_id == 70){
                $setpriceBook= true;
           }
        // return       $productBasePrice;                              

      $productHtml .= '
        <div class="col-lg-4 mb-3">
            <div class="card h-100 rounded" style="background-color: rgb(240, 240, 240) !important;">
                <div class="card-body px-3 py-3">
                    <div class="d-flex align-items-center h-35px mb-1">
                        <div class="me-2 cursor-pointer">
                            <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                <i class="mdi mdi-book-settings-outline fs-4"></i>
                            </div>
                        </div>
                        <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold facility_txt text-wrap">' . htmlspecialchars($product_data->product_name) . '</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center h-35px mb-1">
                        <div class="me-2 cursor-pointer">
                            <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product Category">
                                <i class="mdi mdi-diversify fs-4"></i>
                            </div>
                        </div>
                        <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold facility_txt text-wrap">' . htmlspecialchars($product_data->product_category_name) . '</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-1">
                        <div class="me-2 cursor-pointer">
                            <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                <i class="mdi mdi-calendar-today-outline fs-4"></i>
                            </div>
                        </div>
                        <div class="d-block mb-0">
                            <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">' . htmlspecialchars($dura) . '</label>
                            <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                            <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">' . number_format($faccility_count) . '</span>';

    if ($faccility_count > 0) {
        $productHtml .= '<span class="fs-8 text-info"><u>View Info</u></span>';
    }

    $productHtml .= '</label>';

    if ($faccility_count > 0) {
        $productHtml .= '
            <div class="dropdown-menu dropdown-menu-start w-350px">
                <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                <hr class="mt-0 mb-2 border-dark">
                <div class="scroll-y max-h-150px px-4 py-1 mb-2">';
        
        foreach ($facilities as $FSNO) {
            $fac_data = $helper->get_product_facility($FSNO);
            if ($fac_data) {
                $productHtml .= '
                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                    <label class="text-black fw-semibold text-justify fs-7">' . htmlspecialchars($fac_data->facility_name) . '</label>
                </div>';
            }
        }
        
        $productHtml .= '
                </div>
            </div>';
    }

    $productHtml .= '
                        </div>
                    </div>
                    <div class="d-flex align-items-center h-35px mb-3">
                        <div class="me-2 cursor-pointer">
                            <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                <i class="mdi mdi-tools fs-4"></i>
                            </div>
                        </div>
                        <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold facility_txt">LaTeX, Scrivener</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-center mb-2">
                        <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">' 
                                  . ($currency_id != 70 ? htmlspecialchars($currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($productBasePrice) . '</div>
                    </div>
                    '.(!$setpriceBook ? '<div class="text-danger fs-6 fw-semibold pricebook-warning text-center mb-2 ">Set '.$currencyData->currency_code .' Amount in Pricebook</div> ' : '').'
                </div>
            </div>
        </div>';

      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
          // Ensure that $v is an array and has the keys you expect
          if (is_array($v) && isset($v['variant_id']) && isset($v['variable_id'])) {
              $selected_pairs[$v['variant_id']] = $v['variable_id'];
          }
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
     
      }

      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();

          if ($get_variants && $get_variables) {
            // $variable_amount += $get_variables->variable_amount;
            $varAmount = $get_variables->variable_amount;
            
            if ($currency_id != 70 && $priceData) {
                $variantDetails = json_decode($priceData->varient_details, true);
                foreach ($variantDetails as $vd) {
                    if (
                        $vd['product_id'] == $product_id &&
                        $vd['variant_id'] == $variant_id &&
                        $vd['variable_id'] == $variable_id
                    ) {
                        $varAmount = $vd['amount'];
                        break;
                    }
                }
            }
            
             $variable_amount += $varAmount;

            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">'
                          . ($currency_id != 70 ? htmlspecialchars($currency_symbol) : '&#8377;')
                          . ' ' . number_format($varAmount) .
                      '</label>
                  </div>
              </div>';

              
          }
        }
      }


      $total_amount = $product_data->base_price + $variable_amount;

      $over_all_total += $total_amount;


      $html .= '
          <div class="mb-1" id="cal_packg_az_' . $inx . '">
            <div class="d-flex align-items-center justify-content-between  mb-1 cal_btt rounded px-1 py-1" id="cal_packg_hd_' . $inx . '">
              <div class="d-flex align-items-center">
                <div class="me-2 cursor-pointer">
                  <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_packg_on_of(' . $inx . ');" id="cal_packg_tlp_' . $inx . '">
                    <i class="mdi mdi-plus fs-4" id="cal_packg_plus_btton_' . $inx . '"></i>
                  </a>
                </div>
                <div class="mb-0">
                  <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                  <div class="d-block">
                    <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                  </div>
                </div>
              </div>
              <div class="mb-0 d-flex align-items-center gap-2">
                  <div class="d-flex align-items-center gap-1">
                    <label class="fs-4 fw-semibold text-black text-nowrap mb-0">'
                          . ($currency_id != 70 ? htmlspecialchars($currency_symbol) : '&#8377;') .
                      '</label>
                    <input type="text" class="form-control cust_product_amount  w-100px" data-product-id="'.$product_data->sno.'" data-min-value="'.$total_amount.'" name="cust_pack_prd_amount_'.$product_data->sno.'" value="'.$total_amount.'">
                    <input type="hidden" class="cart_product_amount" value="'.$total_amount.'">
                    
                  </div>
                  <br>
                  
              </div>
            </div>
            <div class="px-3 py-1 mb-0" id="cal_packg_tbox_' . $inx . '" style="display: none;">
              <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                <div class="mb-1">
                  <label class="text-black fw-semibold fs-7">Products</label>
                </div>
                <div class="mb-1">
                  <label class="text-black fw-semibold fs-6">' 
                                  . ($currency_id != 70 ? htmlspecialchars($currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($productBasePrice) . '</label>
                </div>
              </div>
              <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                <div class="mb-1">
                  <label class="text-black fw-semibold fs-7">Durations</label>
                </div>
                <div class="mb-1">
                  <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                </div>
              </div>
              ' . $variant . '
            </div>
          </div>';

    }
    
      $package_addon = DB::table('et_package_addon')
      ->select('et_package_addon.*')
      ->where('et_package_addon.status',0)
      ->where('et_package_addon.package_id', $id)
      ->get();
        $package_free_addon = DB::table('et_package_addon')
      ->select('et_package_addon.*','et_manage_addon.addon_name','et_addon_variable.addon_variablename','et_manage_addon_variant.amount')
      ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_package_addon.addon_variant_id')
      ->join('et_manage_addon','et_manage_addon.sno','=','et_package_addon.addon_id')
      ->join('et_addon_variable','et_addon_variable.sno','=','et_manage_addon_variant.variable_id')
      ->where('et_package_addon.status',0)
      ->where('et_package_addon.free_paid',0)
      ->where('et_package_addon.package_id', $id)
      ->get();
      $package_paid_addon = DB::table('et_package_addon')
      ->select('et_package_addon.*','et_manage_addon.addon_name','et_addon_variable.addon_variablename','et_manage_addon_variant.amount')
      ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_package_addon.addon_variant_id')
      ->join('et_manage_addon','et_manage_addon.sno','=','et_package_addon.addon_id')
      ->join('et_addon_variable','et_addon_variable.sno','=','et_manage_addon_variant.variable_id')
      ->where('et_package_addon.status',0)
      ->where('et_package_addon.free_paid',1)
      ->where('et_package_addon.package_id', $id)
      ->get();
      
      $package_paid_addon = DB::table('et_package_addon')
    ->select(
        'et_package_addon.*',
        'et_manage_addon.addon_name',
        'et_addon_variable.addon_variablename',
        'et_manage_addon_variant.amount'
    )
    ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_package_addon.addon_variant_id')
    ->join('et_manage_addon','et_manage_addon.sno','=','et_package_addon.addon_id')
    ->join('et_addon_variable','et_addon_variable.sno','=','et_manage_addon_variant.variable_id')
    ->where('et_package_addon.status',0)
    ->where('et_package_addon.free_paid',1)
    ->where('et_package_addon.package_id', $id)
    ->get();
     $priceDataAddon = DB::table('et_price_book')
                ->select('et_price_book.*','et_country_currencies.currency_symbol')
                ->join('et_country_currencies', 'et_price_book.currency_id', '=', 'et_country_currencies.sno')
                ->where('et_price_book.currency_id', $currency_id)
                ->where('et_price_book.status', 3)
                ->first();
                
        if ($currency_id != 70 && $priceDataAddon) {
        
            if ($priceDataAddon) {
                $variantDetails = json_decode($priceDataAddon->varient_details, true); // convert JSON to array
        
                foreach ($package_paid_addon as $addon) {
                    foreach ($variantDetails as $variant) {
                        if ($addon->addon_variant_id == $variant['variant_id']) {
                            $addon->amount = $variant['amount']; // override amount
                            break;
                        }
                    }
                }
            }
        }

      
      $package->package_product = $package_product ;
      $package->package_addon = $package_addon ;
      $package->package_paid_addon = $package_paid_addon ;
      $package->package_free_addon = $package_free_addon ;
      
      

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $package,
      'html' => $html,
      'productHtml' => $productHtml,
    ], 200);
  }

 


  public function SendProposal($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id =$decryptedValue;
     
      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
        if(!$proposal){
            $content="This proposal is no longer accessible because User Not Found!";
            return view('errors.link_expired',['content' =>$content,]);
        }
               
        if($proposal->link_status ==0){
            
             DB::table('et_proposal')
                ->where('sno', $prps_id)
                ->update(['send_status' => 1]);
            
                 $exchange_quote =1;
                // if ($proposal->currency_code !== 'INR') {
                //     $response= $helper->convertFromINR($proposal->currency_code);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                // }
           

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

        $domain_names = DB::table('et_domain')
            ->where('et_domain.status', 0)
            ->whereIn('sno', $domain_ids)
            ->pluck('domain_name')  // Get only domain_name column
            ->toArray();            // Convert Collection to array
        
        $domain_list = implode(', ', $domain_names);

   
      $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->orderBy('et_proposal_product_cart.sno','ASC')
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            $slotCount=0;
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                // $cart_total = $variable_amount + $product_data->base_price;
                 $cart_total = $product->product_amount;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->orderBy('et_proposal_pay_slot.sno','asc')
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

                        if (count($deliverable_ids) > 0) {
                            $deliverables = DB::table('et_product_delivarables')
                                ->whereIn('sno', $deliverable_ids)
                                ->where('status', 0)
                                ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                                ->pluck('delivarable_name', 'sno');
                        } else {
                            // Handle case where $deliverable_ids is empty
                            $deliverables = collect(); // Return an empty collection or handle accordingly
                        }
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
                    
            $package_cart = DB::table('et_proposal_package_cart')
            ->select('variant_variable_ids','cust_product_amount')
            ->where('status', 0)
            ->where('proposal_sno', $proposal->sno)
            ->get();
                
                    $packageTotal = 0;
                    $packageTotalCart = 0;
                    
                    foreach ($package_cart as $item) {
                        $variants = json_decode($item->variant_variable_ids, true); // decode as array
                            $packageTotalCart +=$item->cust_product_amount;
                        if (is_array($variants)) {
                            foreach ($variants as $variant) {
                                if (isset($variant['amount'])) {
                                    $packageTotal += $variant['amount'];
                                }
                            }
                        }
                    }
    
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
              $package_data->package_amount= $packageTotal ;
               $package_data->packageTotalCart= $packageTotalCart ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;

 $reasonList_reject = DB::table('et_proposal_reject_reason')->select('*')
        ->where('status', 0)
        ->orderBy('sno', 'desc')->get();
    // return $proposal;

    return view('content.lead_management.manage_proposal.proposal_send',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'exchange_quote' =>$exchange_quote,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
      'reasonList_reject' =>$reasonList_reject,
    ]);
        }else{
          return view('errors.link_expired',[]);
        }
  }

  public function PrintProposal($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id =$decryptedValue;
     
      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$prps_id)
                   ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
            if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

          $exchange_quote =1;
            // if ($proposal->currency_code !== 'INR') {
            //     $response= $helper->convertFromINR($proposal->currency_code);   
            //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
            // }

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();
            
             $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';


            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->orderBy('et_proposal_product_cart.sno', 'asc')
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            $slotCount=0;
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
           
                // $cart_total = $variable_amount + $product_data->base_price;
                $cart_total = $product->product_amount;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                    
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                     $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

                        if (count($deliverable_ids) > 0) {
                            $deliverables = DB::table('et_product_delivarables')
                                ->whereIn('sno', $deliverable_ids)
                                ->where('status', 0)
                                ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                                ->pluck('delivarable_name', 'sno');
                        } else {
                            // Handle case where $deliverable_ids is empty
                            $deliverables = collect(); // Return an empty collection or handle accordingly
                        }
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
         $package_cart = DB::table('et_proposal_package_cart')
                    ->select('variant_variable_ids','cust_product_amount')
                    ->where('status', 0)
                    ->where('proposal_sno', $proposal->sno)
                    ->get();
                
                $packageTotal = 0;
                $packageTotalCart = 0;
                
                foreach ($package_cart as $item) {
                    $variants = json_decode($item->variant_variable_ids, true); // decode as array
                        $packageTotalCart +=$item->cust_product_amount;
                    if (is_array($variants)) {
                        foreach ($variants as $variant) {
                            if (isset($variant['amount'])) {
                                $packageTotal += $variant['amount'];
                            }
                        }
                    }
                }
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
               $package_data->package_amount= $packageTotal ;
               $package_data->packageTotalCart= $packageTotalCart ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;


    // return $proposal;

    return view('content.lead_management.manage_proposal.proposal_print',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
      'exchange_quote' =>$exchange_quote,
    ]);
  }


   public function ProposalMessage(Request $request)
    {
       
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
        
        
        
      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

      $proposal_id  = $request->proposal_id;
      $old_customer_check  = $request->old_customer_check;

      $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
      // Extract the validated data
      $lead_id=$proposalData->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($proposal_id, 'encrypt');

      $description =$request->description ?? 'Your New Proposal is Generated , We Send Link Below .';
    //   $Link ='https://erp.elysiumtechnologies.com/manage_proposal/send_proposal/'.$encrypted_values;
    
       $Link =url('manage_proposal/send_proposal/' . $encrypted_values);
      
      //  communication Proposal
         $communicationStatus=DB::table('et_communication_handle')->where('module_name','Proposal Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposalData->cre_id)->first();
         
        if($communicationStatus && $communicationStatus->status == 0){
      
              if($old_customer_check == 1){
                  //   For Old Customer
                DB::table('et_proposal')
                        ->where('sno', $proposal_id)
                        ->update([
                            'temp_send_link' => $Link,
                            'old_customer_check'=>$old_customer_check,
                            ]);
              }else{
                     if(!$proposalData->temp_send_link){
                         $channelId = 4;
                         $shortUrlData = $this->shortenUrl($Link,$channelId);
                         $shortUrl = $shortUrlData['shorturl'];
                         $urlId =$shortUrlData['id'];
                          if($shortUrl){
                                DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update(['temp_send_link' => $shortUrl]);
                                
                                  DB::table('et_chotta_links')->insert([
                                          'branch_id' => $branch_id,
                                          'chotta_link_id' => $urlId,
                                          'chotta_short_link' => $shortUrl,
                                          'large_encrypt_link' => $Link,
                                          'link_type' => 'Proposal Send',
                                          'proposal_id' => $proposal_id,
                                          'created_by' => $user_id,
                                          'updated_by' => $user_id,
                                      ]);
                                
                          }
                      }
                    
                      $proposalUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
                      
                      $shortsendUrl = $proposalUrl->temp_send_link ;
                      
                      $proposal_key = basename($shortsendUrl);
                    
                        
                      $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
                
                      $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
                       $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branchData->cre_mobile;
                       
                       $customer=DB::table('et_customer')->where('et_customer.lead_id',$lead_id)->first();
                       
                       $lead_name =$customer ?$customer->cus_name : $lead->lead_name;
                       $lead_email_id =$customer ? $customer->cus_email_id : $lead->lead_email_id;
                       $lead_mobile =$customer ? $customer->cus_mobile : $lead->lead_mobile;
                       
                    // // sms proposal send
                    if($communicationStatus->sms ==0){
                        if ($sms == 1) {
            
                              $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '4_PhDiZone_Proposal_Template')->first();
                              $authkey = $result_sms ? $result_sms->authkey : '';
                              $sender_id = $result_sms ? $result_sms->sender_id : '';
                              $template_id = $result_sms ? $result_sms->template_id : '';
                              $country_code = $result_sms ? $result_sms->country_code : '';
                              $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                              $mobile_number = $country_code . $lead_mobile;
                    
                              if ($lead_email_id && $lead_mobile) {
                                    $message_contentEmail = "Link sent to Email & WhatsApp";
                                } elseif ($lead_email_id) {
                                    $message_contentEmail = "Link sent to your Email";
                                } elseif ($lead_mobile) {
                                    $message_contentEmail = "Link sent to your WhatsApp";
                                } else {
                                    $message_contentEmail = "Link ready. Please contact us";
                                }
                              $proposal_sms_id=$proposalData->proposal_id ;
                              
                              $proposal_Content= $proposal_sms_id.', '.$message_contentEmail;
                    
                              // Replace placeholders with actual values
                              $replacement_values = [$lead_name,$proposal_Content,$cre_mobile];
                              $message_content = preg_replace_callback(
                                '/\{#var#\}/',
                                function () use (&$replacement_values) {
                                  return array_shift($replacement_values);
                                },
                                $message_content
                              );
                    // return $message_content;
                              $route = "default";
                              $postData = array(
                                'authkey' => $authkey,
                                'mobiles' => $mobile_number,
                                'message' => $message_content,
                                'sender' => $sender_id,
                                'route' => $route,
                              );
                    
                              // API URL
                              $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                    
                              // Initialize the resource
                              $ch = curl_init();
                              curl_setopt_array($ch, array(
                                CURLOPT_URL => $url,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => $postData,
                                CURLOPT_SSL_VERIFYHOST => 0,
                                CURLOPT_SSL_VERIFYPEER => 0,
                              ));
                    
                              // Get response
                              $response = curl_exec($ch);
                              // return $response;
                              $err = curl_error($ch);
                              curl_close($ch);
                            }
                    }
                       
                    //   Send email if email flag is set to true
                     if($communicationStatus->email ==0){
                      if ($email == 1) {
                            $emailTemplate_id =1; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                        // Gender condition
                        $genderPrefix = 'Mr/Ms'; // Default value
                        if ($lead->lead_gender == 1) {
                          $genderPrefix = 'Mr';
                        } elseif ($lead->lead_gender == 2) {
                          $genderPrefix = 'Ms';
                        }
                        
                        
                       
                        
                        $content = $emailTemplate->email_subject;
                
                        $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                
                        $content = str_replace('#customer_name', $lead_name, $content);
                        $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
                        $content = str_replace('#link', $shortsendUrl, $content);
                        $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                        $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
                        $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
                        $branchNo = $branch->mobile;
                        $branchemail = $branch->mail;
                        $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                        $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                        $url= 'phdizone.com';
                
                        $mailData = [
                              'url'         => $url,
                              'subject'     => $dynamicSubject,
                              'content'     => $content,
                              'branchNo'    => $branchNo,
                              'branchemail' => $branchemail, // Use the message content from the request
                              'fbLink'      => $fbLink,      // Use the message content from the request
                              'instaLink'   => $instaLink,   // Use the message content from the request
                              'salesMobile' => $branchData->cre_mobile ?? '8220011465',
                          ];
                
                        $to_address = $lead_email_id;
                        $from_address = 'elysiumtechnology@elysium.community';
                        $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                
                
                        Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                     }
                     }
                     
                    //  Whatsapp proposal Send
                     if($communicationStatus->whatsapp ==0){
                      if ($whatsapp == 1) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "proposal_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'proposal_phdizone') {
                                    // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                    $headerImage =  url('public/assets/phdizone_images/OnBoard.jpg');
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead_name,
                                            'parameter_name' => 'customer_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposalData->proposal_id,
                                            'parameter_name' => 'proposal_id',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposal_key,
                                            'parameter_name' => 'proposal_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'customercare_number',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $proposal_key,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                     }
                    
                     DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update(['send_status' => 1]);
              }
    
        }else{
             $old_customer_check = 1 ;
                    //  Skip Communication For Old Customer
                    if(!$proposalData->temp_send_link){
                        DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update([
                                    'temp_send_link' => $Link,
                                    'old_customer_check'=>$old_customer_check,
                                    ]);
                    }
        }        
   
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }

  public function ConfirmProposal(Request $request)
{
    $proposal_status = $request->input('proposal_status');
    $id = $request->input('proposal_id');
    $proposal_reason = $request->input('proposal_reason');
    $proposal_reason_other = $request->input('proposal_reason_other');
    $reason_comments = $request->input('reason_comments');

    // Update the proposal
    $update = DB::table('et_proposal')
        ->where('sno', $id)
        ->where('status', 0)
        ->update([
            'proposal_status' => $proposal_status,
            'proposal_accept_date' => date('Y-m-d H:i:s'),
            'link_status' =>$proposal_status ==1? 1 : 0,
            'reject_reason' => $proposal_reason ?? null,
            'reject_reason_other' => $proposal_reason_other ?? null,
            'reason_comments' => $reason_comments ?? null,
        ]);
        
        $Proposal_data = DB::table('et_proposal')
            ->where('sno', $id)
            ->where('status', 0)
            ->orderBy('sno', 'asc')
            ->first();
        
        $slot_first = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $id)
            ->where('status', 0)
            ->orderBy('sno', 'asc')
            ->first();
        
        if ($slot_first) {
            DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_first->sno)
                ->where('status', 0)
                ->update([
                    'nextPayDate'     => $Proposal_data->due_date,
                    'initialPayDate'  => $Proposal_data->due_date,
                ]);
        }
        
     $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($id, 'encrypt');
      return response()->json([
        'status' => 200,
        'message' => 'Proposal Confirmation Submitted',
        'error_msg' => null,
        'data' => $encrypted_values,
        'proposal_status' => $proposal_status
      ]);
    


}


    public function proposalAccepted($id ,Request $request){

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_country_currencies.currency_symbol','et_country_currencies.currency_code')
                 ->where('et_proposal.sno',$decryptedValue)
                 ->where('et_proposal.status','!=',2)
                 ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
        $slotData = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                        ->where('et_proposal_pay_slot.status',0)
                        ->where('et_proposal_pay_slot.paid_status',0)
                        ->orderBy('et_proposal_pay_slot.sno', 'asc')
                        ->first();
        // return $slotData;
        
        $encrypt_id = $slotData->proposal_sno. '~' .$slotData->sno. '~' .$slotData->payable_amount;
        
        $generateId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)
                ->whereNotNull($column)
                ->where($column, '!=', '')
                ->orderByRaw("CAST(SUBSTRING_INDEX(SUBSTRING_INDEX($column, '/', 1), '-', -1) AS UNSIGNED) DESC")
                ->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };
            
            if($slotData->invoice_id){
                $invoice_id =$slotData->invoice_id;
            }else{
                 $invoice_id = $generateId('INV', 'et_proposal_pay_slot', 'invoice_id', 6);
            }
      
      


       $slot_update = DB::table('et_proposal_pay_slot')
                ->where('sno', $slotData->sno)
                ->where('status', 0)
                ->update([ 
                    'invoice_id' => $invoice_id, 
                ]);

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($encrypt_id, 'encrypt');
       $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
       $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slotData->sno)->first();
       
           $TargetCurrency = $proposal->currency_code ?? 'INR';
            $converted_amount =$slot->payable_amount;
                $endpoint = 'convert';
                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
        
                $helper = new \App\Helpers\Helpers();
                //   if ($TargetCurrency !== 'INR') {
                //     $response= $helper->convertFromINR($TargetCurrency);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                //     $converted_amount = ($exchange_quote != 0) ? $slot->payable_amount * $exchange_quote : 0;
                //   }else{
                //     $converted_amount =$slot->payable_amount;
                //   }
       
       
       $slotAmount = $proposal->currency_symbol . number_format($converted_amount, 2, '.', ',');

        
        
    //   $Link ='https://erp.elysiumtechnologies.com/manage_proposal/payments/'.$encrypted_values;
       $Link =url('manage_proposal/payments/' . $encrypted_values);
      
      //  communication Proposal
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Invoice Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposal->cre_id)->first();
        if($communicationStatus && $communicationStatus->status == 0){
      
          if($proposal->old_customer_check == 1){
              //   For Old Customer
            DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot->sno)
                    ->update([
                        'temp_send_link' => $Link,
                        'old_customer_check'=>1,
                        ]);
          }else{
                if(!$slotData->temp_send_link){
                    $channelId = 5;
                     $shortUrlData = $this->shortenUrl($Link,$channelId);
                     $shortUrl = $shortUrlData['shorturl'];
                     $urlId =$shortUrlData['id'];
                     if($shortUrl){
                         DB::table('et_proposal_pay_slot')
                            ->where('sno',  $slot->sno)
                            ->update(['temp_send_link' => $shortUrl]);
                            
                              DB::table('et_chotta_links')->insert([
                                  'branch_id' => $proposal->branch_id,
                                  'chotta_link_id' => $urlId,
                                  'chotta_short_link' => $shortUrl,
                                  'large_encrypt_link' => $Link,
                                  'link_type' => 'Invoice Send',
                                  'pay_slot_id' =>$slot->sno,
                                  'created_by' => $proposal->created_by,
                                  'updated_by' => $proposal->created_by,
                              ]);
                     }
                }
                     $slotUrl=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slotData->sno)->first();
                      $shortsendUrl = $slotUrl->temp_send_link ;
                      $slot_url_key = basename($shortsendUrl);
                      
                     $branch_data = BranchModel::where('sno', $proposal->branch_id)->orderBy('sno', 'desc')->first();
                     $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $branch_data->entity_id)->first();
                     
                     $cre = StaffModel::where('sno', $proposal->cre_id)->orderBy('sno', 'desc')->first();
     
      
                    $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
                    
                      $customer=DB::table('et_customer')->where('et_customer.lead_id',$proposal->lead_id)->first();
                       
                       $lead_name =$customer ?$customer->cus_name : $lead->lead_name;
                       $lead_email_id =$customer ? $customer->cus_email_id : $lead->lead_email_id;
                       $lead_mobile =$customer ? $customer->cus_mobile : $lead->lead_mobile;
                       
                       $invoice_send_no=$slot->invoice_id ?? 'INV-00001/06/2025';
                         // // sms Invoice send
                        if($communicationStatus->sms ==0){
                            if ($lead_mobile) {
                
                                  $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '5_PhdiZone_Invoice_Template')->first();
                                  $authkey = $result_sms ? $result_sms->authkey : '';
                                  $sender_id = $result_sms ? $result_sms->sender_id : '';
                                  $template_id = $result_sms ? $result_sms->template_id : '';
                                  $country_code = $result_sms ? $result_sms->country_code : '';
                                  $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                                  $mobile_number = $country_code . $lead_mobile;
                        
                                 
                                  
                        
                                  // Replace placeholders with actual values
                                  $replacement_values = [$lead_name,$invoice_send_no, $shortsendUrl,$cre_mobile];
                                  $message_content = preg_replace_callback(
                                    '/\{#var#\}/',
                                    function () use (&$replacement_values) {
                                      return array_shift($replacement_values);
                                    },
                                    $message_content
                                  );
                        
                                  $route = "default";
                                  $postData = array(
                                    'authkey' => $authkey,
                                    'mobiles' => $mobile_number,
                                    'message' => $message_content,
                                    'sender' => $sender_id,
                                    'route' => $route,
                                  );
                        
                                  // API URL
                                  $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                        
                                  // Initialize the resource
                                  $ch = curl_init();
                                  curl_setopt_array($ch, array(
                                    CURLOPT_URL => $url,
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_POST => true,
                                    CURLOPT_POSTFIELDS => $postData,
                                    CURLOPT_SSL_VERIFYHOST => 0,
                                    CURLOPT_SSL_VERIFYPEER => 0,
                                  ));
                        
                                  // Get response
                                  $response = curl_exec($ch);
                                  // return $response;
                                  $err = curl_error($ch);
                                  curl_close($ch);
                                }
                        }
                     
                    //  Email Invoice send
                      if($communicationStatus->email ==0){
                        if ($lead_email_id) {
                        $emailTemplate_id =4; // proposal send Template Id
                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
            
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                            
                            
                           
                            
                            $content = $emailTemplate->email_subject;
                    
                            $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                    
                            $content = str_replace('#customer_name', $lead_name, $content);
                            $content = str_replace('#invoice_number', $slot->invoice_id ?? 'INV-00001/06/2025', $content);
                            $content = str_replace('#link', $shortsendUrl, $content);
                            $content = str_replace('#service_name', $proposal->service_title ?? '', $content);
                            $content = str_replace('#invoice_amount', $slotAmount ?? '', $content);
                            $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                            $content = str_replace('#customercare_contact',  $cre_mobile ?? '8220011465', $content);
                            $branchNo = $branch_data->mobile;
                            $branchemail = $branch_data->mail;
                            $fbLink = $branch_data->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                            $instaLink = $branch_data->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                            $url= 'phdizone.com';
                    
                            $mailData = [
                                  'url'         => $url,
                                  'subject'     => $dynamicSubject,
                                  'content'     => $content,
                                  'branchNo'    => $branchNo,
                                  'branchemail' => $branchemail, // Use the message content from the request
                                  'fbLink'      => $fbLink,      // Use the message content from the request
                                  'instaLink'   => $instaLink,   // Use the message content from the request
                                  'salesMobile' => $cre_mobile ?? '8220011465',
                              ];
                    
                            $to_address = $lead_email_id;
                            $from_address = 'elysiumtechnology@elysium.community';
                            $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                    
                    
                            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                 }
                      }
                      
                    //   whatsapp Invoice Send
                    if($communicationStatus->whatsapp ==0){
                        if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "invoice_phdizone";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'invoice_phdizone') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Invoice.jpg';
                                $headerImage =  url('public/assets/phdizone_images/Invoice.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           => $lead->lead_name ?? '',
                                        'parameter_name' => 'custome_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $slot->invoice_id ?? 'INV-00001/06/2025',
                                        'parameter_name' => 'invoice_number',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposal->service_title ?? '',
                                        'parameter_name' => 'service_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $slotAmount ?? '',
                                        'parameter_name' => 'invoice_amount',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $slot_url_key,
                                        'parameter_name' => 'invoice_key',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $cre_mobile ?? '8220011465',
                                        'parameter_name' => 'customercare_contact',
                                    ],
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $slot_url_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch_data->entity_id)->orderBy('sno', 'desc')->first();
                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                            $accessToken               = $whatsappApi->access_tokken ?? '';
                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                            $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                            $to           = $lead_mobile;
                            $languageCode = 'en';
                
                            if (strpos($to, $countryCode) !== 0) {
                                $to = $countryCode . $to;
                            }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {}
                         else{
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
                    }
                
                 DB::table('et_proposal_pay_slot')
                            ->where('sno', $slot->sno)
                            ->update(['send_status' => 1]);
          }

        }else{
              if(!$slotData->temp_send_link){
                  DB::table('et_proposal_pay_slot')
                    ->where('sno', $slot->sno)
                    ->update([
                        'temp_send_link' => $Link,
                        'old_customer_check'=>1,
                        ]);
              }
        }
        
      return view('content.lead_management.manage_proposal.proposal_accepted',[
        'proposal'=>$proposal,
        'encrypt_id'=>$encrypt_id,
      ]);
    }


    public function CreateInvoice($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id =$decryptedValue;
     
      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
                 if($proposal){
                    if($proposal->post_sale_check==1){
                        $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                        $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                        $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                    }
                }
        

              $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name','et_transaction.payment_status')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->leftJoin('et_payment', function ($join) {
                                    $join->on('et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                                         ->where('et_payment.status', 0);  // Adding the status condition here
                                })
                        ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_proposal_pay_slot.proposal_id',$proposal->proposal_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->get();
                 $slot_total = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                        ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                        ->where('et_proposal_pay_slot.proposal_id',$proposal->proposal_id)
                        ->where('et_proposal_pay_slot.status',0)
                        ->first();
             
             $PaidAmount = $slots->sum('paidAmount');
             $total_balance =$slot_total->total_amount ? $slot_total->total_amount - $PaidAmount :0 ;
              $branch_data = DB::table('et_branch')
                ->select(
                    'et_branch.*', 
                    'et_cities.name as city_name', 
                    'et_countries.name as country_name', 
                    'et_states.name as state_name'
                )
                ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
                ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
                ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
                ->where('et_branch.sno', $proposal->branch_id)
                ->first();
      
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    return view('content.lead_management.manage_proposal.create_invoice',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'slots' =>$slots ,
      'total_balance' =>$total_balance ,
      'PaidAmount' =>$PaidAmount ,
      'branch_data' =>$branch_data ,
    ]);
  }

   public function InvoiceMessage(Request $request)
    {
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required', 
        'email'    => 'boolean',
        'sms'     => 'boolean',
        'whatsapp' => 'boolean'
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

      $proposal_id  = $request->proposal_id;
      $slotAmount  = $request->slotAmount;
      $slot_id  = $request->slot_id;
      $invoice_due_date  = $request->invoice_due_date;

      $encrypt_id = $proposal_id. '~' .$slot_id. '~' .$slotAmount;

    //   $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
       $proposalData =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$proposal_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
                 if($proposalData){
                        if($proposalData->post_sale_check==1){
                            $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposalData->created_by)->first();
                            $proposalData->nick_name=$staffdata ?$staffdata->nick_name :$proposalData->nick_name;
                            $proposalData->staff_name=$staffdata ?$staffdata->staff_name :$proposalData->staff_name;
                        }
                    }
      // Extract the validated data
      $lead_id=$proposalData->lead_id ?? 0;
      $email     = $request->email;
      $sms      = $request->sms;
      $whatsapp = $request->whatsapp;
      $message  = $request->message;
      $user_id  = $request->user()->user_id;
      $old_customer_check  = $request->old_customer_check;


      // return $request;
      // Find the lead based on lead_id
      $lead = LeadModel::where('sno', $lead_id)
        ->first();

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }

       $slot_data = DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id)
                ->where('status', 0)
               ->first();
      //  $totalAmount = $slot_data->total_amount;
      //   if($slot_data){

      //       $firstBalance = $totalAmount - $slotAmount;
      //        DB::table('et_proposal_pay_slot')
      //           ->where('sno', $slot_id)
      //           ->update([
      //               'payable_amount' => $slotAmount,
      //               'balance_amount' => $firstBalance,
      //           ]);

      //           $unpaidSlots = DB::table('et_proposal_pay_slot')
      //             ->where('proposal_id', $slot_data->proposal_id)
      //             ->where('paid_status', '!=', 1)
      //             ->where('sno', '!=', $slot_id)
      //             ->get();
              
      //          $remainingAmount = $totalAmount - $slotAmount;
      //          $slotCount = $unpaidSlots->count();
      //           if ($slotCount > 0) {
      //             $perSlotAmount = floor($remainingAmount / $slotCount);
      //             $leftover = $remainingAmount % $slotCount;
      //             foreach ($unpaidSlots as $index => $slot) {
      //                 $payable = $perSlotAmount;
      //                 // Add leftover to last slot
      //                 if ($index == $slotCount - 1) {
      //                     $payable += $leftover;
      //                 }

      //                 DB::table('et_proposal_pay_slot')
      //                     ->where('sno', $slot->sno)
      //                     ->update([
      //                         'payable_amount' => $payable,
      //                         'balance_amount' => $payable, 
      //                     ]);
      //             }
      //           }
      

      //  }
      
       $generateId = function ($prefix, $table, $column, $digits = 6) {
                $year = date('Y');
                $month = date('m');
                $lastRecord = DB::table($table)
                ->whereNotNull($column)
                ->where($column, '!=', '')
                ->orderByRaw("CAST(SUBSTRING_INDEX(SUBSTRING_INDEX($column, '/', 1), '-', -1) AS UNSIGNED) DESC")
                ->first();

                if (!$lastRecord) {
                    return sprintf("$prefix-%0{$digits}d/%s/%s", 1, $month, $year);
                } else {
                    $transData = $lastRecord->$column;
                    $slice = explode('/', $transData);
                    $numberPart = preg_replace('/[^0-9]/', '', $slice[0]);
                    $nextNumber = (int) $numberPart + 1;
                    $formattedNumber = sprintf("$prefix-%0{$digits}d", $nextNumber);
                    return $formattedNumber . '/' . $month . '/' . $year;
                }
            };
            
            if($slot_data->invoice_id){
                $invoice_id =$slot_data->invoice_id;
            }else{
                 $invoice_id = $generateId('INV', 'et_proposal_pay_slot', 'invoice_id', 6);
            }
      
      


       $slot_update = DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id)
                ->where('status', 0)
                ->update([
                    'payable_amount' => $slotAmount, 
                    'invoice_id' => $invoice_id, 
                    'due_date' =>$invoice_due_date ? date('Y-m-d', strtotime($invoice_due_date)) : null,
                ]);

      $helper = new \App\Helpers\Helpers();
      $encrypted_values = $helper->encrypt_decrypt($encrypt_id, 'encrypt');
       $slot=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slot_data->sno)->first();
       
       $TargetCurrency = $proposalData->currency_code ?? 'INR';
            $converted_amount =$slot->payable_amount;
                $endpoint = 'convert';
                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
        
                $helper = new \App\Helpers\Helpers();
                //   if ($TargetCurrency !== 'INR') {
                //     $response= $helper->convertFromINR($TargetCurrency);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                //     $converted_amount = ($exchange_quote != 0) ? $slot->payable_amount * $exchange_quote : 0;
                //   }else{
                //     $converted_amount =$slot->payable_amount;
                //   }
       
       $slotAmount = $proposalData->currency_symbol . number_format($converted_amount, 2, '.', ',');

      $description =$request->description ?? 'Your New Proposal is Generated , We Send Link Below .';
    //   $Link ='https://erp.elysiumtechnologies.com/manage_proposal/payments/'.$encrypted_values;
       $Link =url('manage_proposal/payments/' . $encrypted_values);
      
      //  communication Proposal
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Invoice Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposalData->cre_id)->first();
        if($communicationStatus && $communicationStatus->status == 0){
      
              if($old_customer_check == 1){
                  //   For Old Customer
                DB::table('et_proposal_pay_slot')
                        ->where('sno', $slot_id)
                        ->update([
                            'temp_send_link' => $Link,
                            'old_customer_check'=>$old_customer_check,
                            ]);
              }else{
                    if(!$slot_data->temp_send_link){
                        $channelId = 5;
                         $shortUrlData = $this->shortenUrl($Link,$channelId);
                         $shortUrl = $shortUrlData['shorturl'];
                         $urlId =$shortUrlData['id'];
                         if($shortUrl){
                             DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot_id)
                                ->update(['temp_send_link' => $shortUrl]);
                                
                                  DB::table('et_chotta_links')->insert([
                                      'branch_id' => $branch_id,
                                      'chotta_link_id' => $urlId,
                                      'chotta_short_link' => $shortUrl,
                                      'large_encrypt_link' => $Link,
                                      'link_type' => 'Invoice Send',
                                      'pay_slot_id' => $slot_id,
                                      'created_by' => $user_id,
                                      'updated_by' => $user_id,
                                  ]);
                         }
                    }
                    
                         $slotUrl=DB::table('et_proposal_pay_slot')->where('et_proposal_pay_slot.sno',$slot_id)->first();
                          $shortsendUrl = $slotUrl->temp_send_link ;
                          $slot_url_key = basename($shortsendUrl);
                          
                         $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
                         $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
                         
                         $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch->cre_mobile;
                    
                       $customer=DB::table('et_customer')->where('et_customer.lead_id',$lead_id)->first();
                       
                       $lead_name =$customer ?$customer->cus_name : $lead->lead_name;
                       $lead_email_id =$customer ? $customer->cus_email_id : $lead->lead_email_id;
                       $lead_mobile =$customer ? $customer->cus_mobile : $lead->lead_mobile;
                       
                       $invoice_send_no=$slot->invoice_id ?? 'INV-00001/06/2025';
                         // // sms Invoice send
                        if($communicationStatus->sms ==0){
                            if($sms== 1){
                         
                            if ($lead_mobile) {
                
                                  $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '5_PhdiZone_Invoice_Template')->first();
                                  $authkey = $result_sms ? $result_sms->authkey : '';
                                  $sender_id = $result_sms ? $result_sms->sender_id : '';
                                  $template_id = $result_sms ? $result_sms->template_id : '';
                                  $country_code = $result_sms ? $result_sms->country_code : '';
                                  $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                                  $mobile_number = $country_code . $lead_mobile;
                        
                                 
                                  
                        
                                  // Replace placeholders with actual values
                                  $replacement_values = [$lead_name,$invoice_send_no,$shortsendUrl,$cre_mobile];
                                  $message_content = preg_replace_callback(
                                    '/\{#var#\}/',
                                    function () use (&$replacement_values) {
                                      return array_shift($replacement_values);
                                    },
                                    $message_content
                                  );
                        
                                  $route = "default";
                                  $postData = array(
                                    'authkey' => $authkey,
                                    'mobiles' => $mobile_number,
                                    'message' => $message_content,
                                    'sender' => $sender_id,
                                    'route' => $route,
                                  );
                        
                                  // API URL
                                  $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                        
                                  // Initialize the resource
                                  $ch = curl_init();
                                  curl_setopt_array($ch, array(
                                    CURLOPT_URL => $url,
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_POST => true,
                                    CURLOPT_POSTFIELDS => $postData,
                                    CURLOPT_SSL_VERIFYHOST => 0,
                                    CURLOPT_SSL_VERIFYPEER => 0,
                                  ));
                        
                                  // Get response
                                  $response = curl_exec($ch);
                                  $err = curl_error($ch);
                                  curl_close($ch);
                                }
                                
                            }
                        }
                        // email send
                        if($communicationStatus->email ==0){
                         if($email==1){
                          if ($lead_email_id) {
                            $emailTemplate_id =4; // proposal send Template Id
                            $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
                
                            // Gender condition
                            $genderPrefix = 'Mr/Ms'; // Default value
                            if ($lead->lead_gender == 1) {
                              $genderPrefix = 'Mr';
                            } elseif ($lead->lead_gender == 2) {
                              $genderPrefix = 'Ms';
                            }
                            
                            
                           
                            
                            $content = $emailTemplate->email_subject;
                    
                            $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
                    
                            $content = str_replace('#customer_name', $lead->lead_name, $content);
                            $content = str_replace('#invoice_number', $slot->invoice_id ?? 'INV-00001/06/2025', $content);
                            $content = str_replace('#link', $shortsendUrl, $content);
                            $content = str_replace('#service_name', $proposalData->service_title ?? '', $content);
                            $content = str_replace('#invoice_amount', $slotAmount ?? '', $content);
                            $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                            $content = str_replace('#customercare_contact',  $cre_mobile ?? '8220011465', $content);
                            $branchNo = $branch->mobile;
                            $branchemail = $branch->mail;
                            $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                            $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                            $url= 'phdizone.com';
                    
                            $mailData = [
                                  'url'         => $url,
                                  'subject'     => $dynamicSubject,
                                  'content'     => $content,
                                  'branchNo'    => $branchNo,
                                  'branchemail' => $branchemail, // Use the message content from the request
                                  'fbLink'      => $fbLink,      // Use the message content from the request
                                  'instaLink'   => $instaLink,   // Use the message content from the request
                                  'salesMobile' => $cre_mobile ?? '8220011465',
                              ];
                    
                            $to_address = $lead_email_id;
                            $from_address = 'elysiumtechnology@elysium.community';
                            $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
                    
                    
                            Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                         }
                         }
                        }
                    // whatsapp Message
                    if($communicationStatus->whatsapp ==0){
                     if($whatsapp==1){
                      if ($lead_mobile) {
                          
                           
                                // $templateName  = "hello_world";
                                $templateName  = "invoice_phdizone";
                
                                $hasHeader  = false; // Example flag: set based on template
                                $hasBody    = false; // Example flag: set based on template
                                $hasFooter  = false; // Example flag: set based on template
                                $hasButton  = false;
                                $components = [];
                                $couponCode = " ";
                                date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                                $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                          // $currentHour = date('H'); // Get current hour in 24-hour format
                                if ($currentHour >= 5 && $currentHour < 12) {
                                    $greeting = 'Good Morning';
                                } elseif ($currentHour >= 12 && $currentHour < 18) {
                                    $greeting = 'Good Afternoon';
                                } else {
                                    $greeting = 'Good Evening';
                                }
                
                                if ($templateName == 'invoice_phdizone') {
                                    // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/Invoice.jpg';
                                    $headerImage =  url('public/assets/phdizone_images/Invoice.jpg');
                                    $couponCode  = 'NOOFFER';
                                    $buttonIndex = 1;
                                    $bodyText    = [
                                        [
                                            'type'           => 'text',
                                            'text'           => $lead_name ?? '',
                                            'parameter_name' => 'custome_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot->invoice_id ?? 'INV-00001/06/2025',
                                            'parameter_name' => 'invoice_number',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $proposalData->service_title ?? '',
                                            'parameter_name' => 'service_name',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slotAmount ?? '',
                                            'parameter_name' => 'invoice_amount',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $slot_url_key,
                                            'parameter_name' => 'invoice_key',
                                        ],
                                        [
                                            'type'           => 'text',
                                            'text'           => $cre_mobile ?? '8220011465',
                                            'parameter_name' => 'customercare_contact',
                                        ],
                                    ];
                                    $hasHeader = true;
                                    $hasBody   = true;
                                    $hasButton = true;
                                }
                
                                // Add Header if required
                                if ($hasHeader) {
                                    $components[] = [
                                        'type'       => 'header',
                                        'parameters' => [
                                            [
                                                'type'  => 'image',
                                                'image' => [
                                                    'link' => $headerImage, // Dynamically set header image
                                                ],
                                            ],
                                        ],
                                    ];
                                }
                
                                // Add Body if required
                                if ($hasBody) {
                                    $components[] = [
                                        'type'       => 'body',
                                        'parameters' => $bodyText,
                                    ];
                                }
                
                                // Add Footer if required
                                if ($hasButton) {
                                    $components[] = [
                                        'type'       => 'button',
                                        'sub_type'   => 'url',
                                        'index'      => 0,
                                        'parameters' => [
                                            [
                                                'type' => 'text',
                                                'text' => $slot_url_key,
                                            ],
                                        ],
                                    ];
                                }
                                
                                
                                $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$branch->entity_id)->orderBy('sno', 'desc')->first();
                                $dynamicParameters         = $templateParameters[$templateName] ?? [];
                                $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                                $accessToken               = $whatsappApi->access_tokken ?? '';
                                $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
                
                                $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
                
                                $countryCode  = $lead->inter_calls ? ($lead->inter_calls == 0 ? '+91' : '+' . $lead->inter_calls) : '+91';
                                $to           = $lead_mobile;
                                $languageCode = 'en';
                    
                                if (strpos($to, $countryCode) !== 0) {
                                    $to = $countryCode . $to;
                                }
                
                                $message = 'test~message';
                                if (empty($components)) {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'     => $templateName,
                                            'language' => [
                                                'code' => $languageCode,
                                            ],
                                        ],
                                    ];
                                } else {
                                    $payload = [
                                        'messaging_product' => 'whatsapp',
                                        'to'                => $to,
                                        'type'              => 'template',
                                        'template'          => [
                                            'name'       => $templateName,
                                            'language'   => [
                                                'code' => $languageCode,
                                            ],
                                            'components' => $components,
                                        ],
                                    ];
                                }
                
                                $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                             if ($response['status'] == 200) {}
                             else{
                                 return response([
                                      'status' => 404,
                                      'message' => 'Failed to send message',
                                      'error_msg' => $response['error'],
                                    ], 400);
                                }
                            
                      }
                     }
                    }
                         
        
                    
                     DB::table('et_proposal_pay_slot')
                                ->where('sno', $slot_id)
                                ->update(['send_status' => 1]);
              }
              
        }else{
             if(!$slot_data->temp_send_link){
             DB::table('et_proposal_pay_slot')
                        ->where('sno', $slot_id)
                        ->update([
                            'temp_send_link' => $Link,
                            'old_customer_check'=>1,
                            ]);
             }
        }

    
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }


     public function ProposalPayment($id ,Request $request)
    {

      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

     

      // Check if decryption failed
      if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }
      $exp = explode('~', $decryptedValue);
      $prps_id = str_replace(' ', '', $exp[0] ?? '');
      $slot_id_hidden = str_replace(' ', '', $exp[1] ?? '');
      $slot_amount_hidden = str_replace(' ', '', $exp[2] ?? '');

      
      
        $proposal =DB::table('et_proposal')
                  ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_country_currencies.country_name as currency_country_name')
                  ->where('et_proposal.sno',$prps_id)
                    ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                    ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                    ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                    ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->where('et_proposal.status','!=',2)
                  ->where('et_lead.status','!=',2)
                  ->orderBy('et_proposal.sno', 'desc')
                  ->first();
                  
                    if($proposal){
                        if($proposal->post_sale_check==1){
                            $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                            $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                            $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                        }
                    }
                  
      $slot_data =DB::table('et_proposal_pay_slot')
                  ->where('et_proposal_pay_slot.sno',$slot_id_hidden)
                  ->where('et_proposal_pay_slot.status','!=',2)
                  ->orderBy('et_proposal_pay_slot.sno', 'desc')
                  ->first();
          DB::table('et_proposal_pay_slot')
                ->where('sno', $slot_id_hidden)
                ->update(['send_status' => 2]);
                
            if(!$slot_data){
                 $content="This Invoice is no longer accessible Because Invoice Not Found!";
                return view('errors.link_expired',['content' =>$content,]);
            }
                
            if($slot_data->paid_status == 0){
                $AmountInR = $slot_data->payable_amount;
                $CurrentFormat = 'INR'; // base currency
                $TargetCurrency = $proposal->currency_code ?? 'INR';
    
                $convertedAmount = $AmountInR;
                $exchangeRate = 1;
                $converted_amount =$slot_data->payable_amount;
                 $exchange_inr_rate=1;
                    $exchange_quote=1;
                $endpoint = 'convert';
                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                $response ='';
                $helper = new \App\Helpers\Helpers();
                  // if ($TargetCurrency !== 'INR') {
                  //   $response= $helper->convertFromINR($TargetCurrency,$AmountInR);   
                  //    $converted_amount =$response['converted_amount']? $response['converted_amount'] : $slot_amount_hidden;
                  //   $exchange_quote =$response['exchange_quote']  ? $response['exchange_quote'] : 0;
                  //   $exchange_inr_rate =$response['exchange_quote'] != 0 || $response['exchange_quote'] ? 1/$response['exchange_quote'] : 0;
                  // }else{
                  //   $converted_amount =null;
                  //   $exchange_inr_rate=null;
                  //   $exchange_quote=null;
                  // }
                $data=[];
                //   if ($TargetCurrency !== 'INR') {
                //     $response= $helper->convertFromINR($TargetCurrency);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                //     $converted_amount = ($exchange_quote != 0) ? $slot_data->payable_amount * $exchange_quote : 0;
    
                    
                //      $data=[
                //       'exchange_rate' => $exchange_inr_rate,
                //       'exchange_quote' => $exchange_quote,
                //       'converted_amount' => $converted_amount,
                //       'slot_amount_hidden' => $slot_amount_hidden,
                //      ];
                //   }else{
                //     $converted_amount =$slot_data->payable_amount;
                //     $exchange_inr_rate=1;
                //     $exchange_quote=1;
                //   }
    
                  // return $data;
                
                
    
               
    
    
                
                $branch_data = DB::table('et_branch')
                  ->select(
                      'et_branch.*', 
                      'et_cities.name as city_name', 
                      'et_countries.name as country_name', 
                      'et_states.name as state_name'
                  )
                  ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
                  ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
                  ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
                  ->where('et_branch.sno', $proposal->branch_id)
                  ->first();
    
              
    
                $proposal->door_no =$branch_data->door_no ;
                $proposal->area_street = $branch_data->area_street ;
                $proposal->city_name =  $branch_data->city_name ;
                $proposal->state_name =  $branch_data->state_name ;
                $proposal->country_name =  $branch_data->country_name ;
                $proposal->pincode =  $branch_data->pincode ;
                $proposal->branch_mail =  $branch_data->mail ;
                $proposal->branch_mobile =  $branch_data->mobile ;
                $proposal->gst_no =  $branch_data->gst_no ?? "-" ;
    
    
                $lead_data = DB::table('et_lead')
                  ->select(
                      'et_lead.*', 
                      'et_cities.name as city_name', 
                      'et_countries.name as country_name', 
                      'et_states.name as state_name'
                  )
                  ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
                  ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
                  ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
                  ->where('et_lead.sno', $proposal->lead_id)
                  ->first();
    
                $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

                    $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
                    $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
                    $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
                    $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
                    $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
                    $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
                    $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
                    $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
                    $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';
            
                  
                    if($proposal->discount_id >0){
                    $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();
            
                    $proposal->discount_value=$discount->coupon_value ;
                    $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
                    }
    
         
        
                    $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
            
                
            
                
                $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
                $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
            
                $proposal_terms =[];
                if($terms){
                    $proposal_terms = json_decode($terms->terms_condition_list);
                }
            
                $signature= $terms->signature;
    
    
                // return $converted_amount;
                //   $converted_amount=1;
                $invoice_id=$slot_data->invoice_id;
            
                return view('content.lead_management.manage_proposal.payments',[
                    'lead' =>$lead,
                    'proposal' =>$proposal,
                    'branch_data' =>$branch_data,
                    'proposal_note' =>$proposal_note,
                    'proposal_terms' =>$proposal_terms,
                    'signature' =>$signature,
                    'slot_amount_hidden' =>$slot_amount_hidden,
                    'converted_amount' =>$converted_amount,
                    'exchange_quote' =>$exchange_quote,
                    'exchange_inr_rate' =>$exchange_inr_rate,
                    'slot_id_hidden' =>$slot_id_hidden,
                    'proposal_hidden_id' =>$prps_id,
                    'invoice_id' =>$invoice_id,
                ]);
            }elseif($slot_data->slot_balance > 0 ){
                $AmountInR = $slot_data->slot_balance;
                $CurrentFormat = 'INR'; // base currency
                $TargetCurrency = $proposal->currency_code ?? 'INR';
    
                $convertedAmount = $AmountInR;
                $exchangeRate = 1;
                $converted_amount =$slot_data->slot_balance;
                 $exchange_inr_rate=1;
                    $exchange_quote=1;
                $endpoint = 'convert';
                $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
                $response ='';
                $helper = new \App\Helpers\Helpers();
                  // if ($TargetCurrency !== 'INR') {
                  //   $response= $helper->convertFromINR($TargetCurrency,$AmountInR);   
                  //    $converted_amount =$response['converted_amount']? $response['converted_amount'] : $slot_amount_hidden;
                  //   $exchange_quote =$response['exchange_quote']  ? $response['exchange_quote'] : 0;
                  //   $exchange_inr_rate =$response['exchange_quote'] != 0 || $response['exchange_quote'] ? 1/$response['exchange_quote'] : 0;
                  // }else{
                  //   $converted_amount =null;
                  //   $exchange_inr_rate=null;
                  //   $exchange_quote=null;
                  // }
                $data=[];
                //   if ($TargetCurrency !== 'INR') {
                //     $response= $helper->convertFromINR($TargetCurrency);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                //     $exchange_inr_rate = ($exchange_quote != 0) ? 1 / $exchange_quote : 0;
                //     $converted_amount = ($exchange_quote != 0) ? $slot_data->payable_amount * $exchange_quote : 0;
    
                    
                //      $data=[
                //       'exchange_rate' => $exchange_inr_rate,
                //       'exchange_quote' => $exchange_quote,
                //       'converted_amount' => $converted_amount,
                //       'slot_amount_hidden' => $slot_amount_hidden,
                //      ];
                //   }else{
                //     $converted_amount =$slot_data->payable_amount;
                //     $exchange_inr_rate=1;
                //     $exchange_quote=1;
                //   }
    
                  // return $data;
                
                
    
               
    
    
                
                $branch_data = DB::table('et_branch')
                  ->select(
                      'et_branch.*', 
                      'et_cities.name as city_name', 
                      'et_countries.name as country_name', 
                      'et_states.name as state_name'
                  )
                  ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
                  ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
                  ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
                  ->where('et_branch.sno', $proposal->branch_id)
                  ->first();
    
              
    
                $proposal->door_no =$branch_data->door_no ;
                $proposal->area_street = $branch_data->area_street ;
                $proposal->city_name =  $branch_data->city_name ;
                $proposal->state_name =  $branch_data->state_name ;
                $proposal->country_name =  $branch_data->country_name ;
                $proposal->pincode =  $branch_data->pincode ;
                $proposal->branch_mail =  $branch_data->mail ;
                $proposal->branch_mobile =  $branch_data->mobile ;
                $proposal->gst_no =  $branch_data->gst_no ?? "-" ;
    
    
                $lead_data = DB::table('et_lead')
                  ->select(
                      'et_lead.*', 
                      'et_cities.name as city_name', 
                      'et_countries.name as country_name', 
                      'et_states.name as state_name'
                  )
                  ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
                  ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
                  ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
                  ->where('et_lead.sno', $proposal->lead_id)
                  ->first();
    
                $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

                    $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
                    $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
                    $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
                    $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
                    $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
                    $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
                    $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
                    $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
                    $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';
            
                  
                    if($proposal->discount_id >0){
                    $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();
            
                    $proposal->discount_value=$discount->coupon_value ;
                    $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
                    }
    
         
        
                    $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();
            
                
            
                
                $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
                $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();
            
                $proposal_terms =[];
                if($terms){
                    $proposal_terms = json_decode($terms->terms_condition_list);
                }
            
                $signature= $terms->signature;
    
    
                // return $converted_amount;
                //   $converted_amount=1;
                $invoice_id=$slot_data->invoice_id;
            
                return view('content.lead_management.manage_proposal.payments',[
                    'lead' =>$lead,
                    'proposal' =>$proposal,
                    'branch_data' =>$branch_data,
                    'proposal_note' =>$proposal_note,
                    'proposal_terms' =>$proposal_terms,
                    'signature' =>$signature,
                    'slot_amount_hidden' =>$slot_amount_hidden,
                    'converted_amount' =>$converted_amount,
                    'exchange_quote' =>$exchange_quote,
                    'exchange_inr_rate' =>$exchange_inr_rate,
                    'slot_id_hidden' =>$slot_id_hidden,
                    'proposal_hidden_id' =>$prps_id,
                    'invoice_id' =>$invoice_id,
                ]);
            }else {
                $content="This invoice has already been paid. No further action is required.";
                return view('errors.link_expired',['content' =>$content,]);
            }
    }

 public function updatePreProposal(Request $request)
{
    $request->validate([
        'proposal_id' => 'required',
    ]);

    $preProposal = DB::table('et_pre_proposal')
                    ->where('proposal_id', $request->proposal_id)
                    ->first();

    if (!$preProposal) {
        return response()->json(['status' => 'error', 'message' => 'Proposal not found'], 404);
    }
    
       $branch_id = $request->user()->branch_id;
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        
        $created_By= $request->post_sale_staff ?? $user_id;

    DB::table('et_pre_proposal')
        ->where('proposal_id', $request->proposal_id)
        ->update([
            'add_ons' => json_encode($request->add_ons),
            'additional_charges_ids' => json_encode($request->additional_charges_ids),
            'discount_id' => $request->discount_id_hidden,
            'service_title' => $request->service_title,
            'estimate_date' => $request->estimate_date ? date('Y-m-d', strtotime($request->estimate_date)) :'',
            'due_date' => $request->prposal_due_date ? date('Y-m-d', strtotime($request->prposal_due_date)) :'',
            'currency_id' => $request->prposal_currency,
            'cre_id' => $request->proposal_cre,
            'milestone_count' => $request->milestone_count,
            'delivery_duration' => $request->delivery_duration,
            'delivery_duration_end' => $request->delivery_duration_end,
            'topic' => $request->proposal_topic,
            'domain_ids' => json_encode($request->proposal_domain),
            'slot_balance' => $request->slot_balance,
            'package_id' => $request->package_id ?? 0,
            'page_word' => $request->page_word,
            'referral_id' => $request->proposal_referral_staff,
            'page_word_count' => $request->page_word_count ?? 0,
             'old_customer' => $request->old_customer_check ?? 0,
             'created_by' => $created_By,
        ]);
        
        if($request->package_id > 0){
             $packageData = DB::table('et_package_product')->where('status', 0)
              ->where('package_id', $request->package_id)
              ->orderBy('sno', 'asc')
              ->get();
              
              $packageTemp = DB::table('et_package')->where('status', 0)
                    ->where('sno', $request->package_id)
                    ->first();


              if(isset($packageData)){
                  foreach($packageData as $package){
                      $product_id = $package->product_id;
                        $cust_product_amount = $request->cust_product_amounts[$product_id] ?? $package->product_amount;
                        $original_product_amount = $request->original_product_amounts[$product_id] ?? $package->product_amount;
                        $total_amount = $request->package_actual_price_hidden ?? $packageTemp->actual_amount;
                
                        $add_package_cart = DB::table('et_proposal_package_cart')->insert([
                            'proposal_id' => $request->proposal_id,
                            'package_id' => $request->package_id,
                            'product_id' => $product_id,
                            'product_amount' => $package->product_amount,
                            'variant_variable_ids' => $package->variant_variable_ids,
                            'cust_product_amount' => $cust_product_amount,
                            'original_product_amount' => $original_product_amount,
                            'total_package_amount' => $total_amount,
                            'created_by' => $user_id,
                            'updated_by' => $user_id,
                            'branch_id'   => $branch_id,
                        ]);
                  }
              }
        }
       

    return response()->json(['status' => 'success']);
}



public function PaymentSlotByProposal(Request $request){

        $proposal_id =$request->id;
        $slot = DB::table('et_proposal_pay_slot')
          ->where('proposal_id', $proposal_id)
          ->where('status', 0)
          ->get();

          foreach( $slot as $single){
            $single->deliverable_ids=json_decode($single->deliverable_ids);
            $single->slot_notes_ids=json_decode($single->slot_notes_ids);
          }
   
        return response()->json([
        'status' => 200,
        'message' =>'package Slot details Successfull',
        'error_msg' => null,
        'data' => $slot,
      ]);

  }



  
public function manage_proposal_view($id,Request $request)
  {
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

     $user_id   = $request->user()->user_id ;

      // Check if decryption failed
      if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
      }
        
      
        $proposaldata =DB::table('et_proposal')
                  ->select('et_proposal.*','et_lead.lead_name','et_lead.registered_date','et_lead.lead_mobile','et_lead.lead_email_id','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_country_currencies.country_name as currency_country_name')
                  ->where('et_proposal.sno',$decryptedValue)
                     ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                     ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                    ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                    ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->where('et_proposal.status','!=',2)
                  ->where('et_lead.status','!=',2)
                  ->orderBy('et_proposal.sno', 'desc')
                  ->first();
                if($proposaldata){
                    if($proposaldata->post_sale_check==1){
                        $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposaldata->created_by)->first();
                        $proposaldata->nick_name=$staffdata ?$staffdata->nick_name :$proposaldata->nick_name;
                        $proposaldata->staff_name=$staffdata ?$staffdata->staff_name :$proposaldata->staff_name;
                    }
                }
        $proposalList = DB::table('et_proposal')
                  ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol','et_country_currencies.country_name as currency_country_name')
                  ->where('et_proposal.parent_id',$proposaldata->parent_id)
                     ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                     ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                    ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                    ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                  ->where('et_proposal.status','!=',2)
                  ->where('et_lead.status','!=',2)
                  ->orderBy('et_proposal.sno', 'desc')
                  ->get();
        $packages='';
      foreach($proposalList as $proposal){
          $proposal->discount_value='' ;
            $proposal->coupon_code='' ;
            $proposal->discount_type='';
          if($proposal->discount_id >0){
            $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();
    
            $proposal->discount_value=$discount->coupon_value ;
            $proposal->coupon_code=$discount->coupon_code ;
            $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
          }
          
          if($proposal){
                if($proposal->post_sale_check==1){
                    $staffdata=DB::table('et_staff')->where('et_staff.sno',$proposal->created_by)->first();
                    $proposal->nick_name=$staffdata ?$staffdata->nick_name :$proposal->nick_name;
                    $proposal->staff_name=$staffdata ?$staffdata->staff_name :$proposal->staff_name;
                }
            }
          
          $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

            $domain_names = DB::table('et_domain')
                ->where('et_domain.status', 0)
                ->whereIn('sno', $domain_ids)
                ->pluck('domain_name')  // Get only domain_name column
                ->toArray();            // Convert Collection to array
            
            $domain_list = implode(', ', $domain_names);
    
       
          $proposal->domain_names=$domain_list;
          
          $proposal->products=[];
          
       
          
        $proposal->slotCount=0;
        if($proposal->product_package == 1){
    
           $proposalProduct = DB::table('et_proposal_product_cart')
                              ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                              ->where('et_proposal_product_cart.status',0)
                              ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                              ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                              ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                              ->orderBy('et_proposal_product_cart.sno', 'asc')
                              ->get();
            //     if($user_id ==0){
            //       return $proposalProduct;
            //   }
           
           $groupedProducts = [];
            $allSlotIds = [];
            $slotCount=0;
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                $cart_total = $product->product_amount;
                // $cart_total = $variable_amount + $product_data->base_price;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                   
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            // return $deliverable_ids;
                   $deliverable_ids = array_filter($deliverable_ids); // Ensure no empty values

                    if (count($deliverable_ids) > 0) {
                        $deliverables = DB::table('et_product_delivarables')
                            ->whereIn('sno', $deliverable_ids)
                            ->where('status', 0)
                            ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                            ->pluck('delivarable_name', 'sno');
                    } else {
                       
                        // Handle case where $deliverable_ids is empty
                        $deliverables = collect(); // Return an empty collection or handle accordingly
                    }

            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
            
            

        }else{
    
          $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
    
            $package_cart = DB::table('et_proposal_package_cart')
                    ->select('variant_variable_ids','cust_product_amount')
                    ->where('status', 0)
                    ->where('proposal_sno', $proposal->sno)
                    ->get();
                
                $packageTotal = 0;
                $packageTotalCart = 0;
                
                foreach ($package_cart as $item) {
                    $variants = json_decode($item->variant_variable_ids, true); // decode as array
                        $packageTotalCart +=$item->cust_product_amount;
                    if (is_array($variants)) {
                        foreach ($variants as $variant) {
                            if (isset($variant['amount'])) {
                                $packageTotal += $variant['amount'];
                            }
                        }
                    }
                }
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
              
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
                $productSlot_amount =0 ;
                  foreach($slots as $slot){
                  $productSlot_amount += $slot->slot_amount;
                      $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                      $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                      $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderByRaw('FIELD(sno, ' . implode(',', $deliverables_ids) . ')')->pluck('delivarable_name');
                      $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                      $slot->deliverables =$deliverables;
                      $slot->slot_notes =$slot_notes;
                  }
                  $package_data->slots=$slots;
                  
                  
                  
                   $package_data->package_amount= $packageTotal ;
     
             $packages=$package_data;
             $proposal->package_name = $packages->package_name;
             $proposal->packageTotalCart = $packageTotalCart;
             $proposal->package_amount = $packageTotal;
             $proposal->package_slots = $slots;
             $proposal->product_package_name = $package_product_name ;
             
           
        }
    
        
        $additional_charges_ids= $proposal->addtional_charges_ids ? json_decode($proposal->addtional_charges_ids) : []; 
             
             $additional_charges=DB::table('et_additional_charges')->whereIn('et_additional_charges.sno',$additional_charges_ids)->get();
             $proposal->additional_charge_list = $additional_charges ;
    
         $proposalAddonProduct = DB::table('et_proposal_addon_product')
                              ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                              ->where('et_proposal_addon_product.status',0)
                              ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                              ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                              ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                              ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                              ->get();
    
              $freeAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 0)
                ->get();
    
                $paidAddonProduct = DB::table('et_proposal_addon_product')
                    ->select(
                        'et_manage_addon.addon_name',
                        'et_proposal_addon_product.*',
                        'et_addon_variable.addon_variablename'
                    )
                    ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                    ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                    ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                    ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                    ->where('et_proposal_addon_product.status', 0)
                    ->where('et_proposal_addon_product.free_paid', 1)
                    ->get();
                      
                    $proposal->freeAddonProducts = $freeAddonProduct;
                    $proposal->paidAddonProducts = $paidAddonProduct;
         $proposal->productAddon =$proposalAddonProduct;
         
         
          
      }
      
      
        //   if($user_id ==0){
        //       return $proposalList;
        //   }
        // return $packages;
    return view('content.lead_management.manage_proposal.proposal_view',[
        "proposal"=>$proposaldata,
        "proposalList"=>$proposalList,
         'packages' =>$packages,
        ]);
  }
  
 

       public function shortenUrl($longUrl,$channelId)
        {
            $response = Http::withToken('aFLQFlykraqpANsi')
                ->post('https://chotta.link/api/url/add', [
                    'url' => $longUrl
                ]);
        
            if ($response->successful() && isset($response['shorturl'])) {
                
                $shortUrl = $response['shorturl'];
                $urlId =$response['id'];
                
                $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

                $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
        
                if ($assignResponse->successful()) {
                    return $response; // success
                }
            }
            
        
            return null;
        }
        
        private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,
      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
  
  public function product_cart_List(Request $request){
      
      $id= $request->id;
        $data = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_proposal_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  
  public function ProposalVerify(Request $request){
      // Validate the incoming request data
      $validator = Validator::make($request->all(), [
        'proposal_id' => 'required',
      ]);
      // If validation fails, return a response with errors
      if ($validator->fails()) {
        return response([
          'status'    => 401,
          'message'   => 'Incorrect format input fields',
          'error_msg' => $validator->messages()->get('*'),
          'data'      => null,
        ], 200);
      }
      $branch_id = $request->user()->branch_id;
      $entity_id = $request->user()->entity_id;
      $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
      $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)->first();

      $branch_name = " ";
      if ($branchData->branch_type == 1) {
        $branch_name = $branchData->branch_name;
      } elseif ($branchData->branch_type == 2) {
        $branch_name = $branchData->franchise_name;
      }

      $proposal_id  = $request->proposal_id;

      $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
      // Extract the validated data
      $lead_id=$proposalData->lead_id ?? 0;
      $user_id  = $request->user()->user_id;

     DB::table('et_proposal')
                ->where('sno', $proposal_id)
                ->update([
                    'verify_status' => 1,
                    ]);
     
      $lead = LeadModel::where('sno', $lead_id)
        ->first();
        

      // If the lead is not found, return an error response
      if (!$lead) {
        return response([
          'status'    => 404,
          'message'   => 'Lead not found',
          'error_msg' => 'The lead with the given ID does not exist',
          'data'      => null,
        ], 200);
      }

     

    
        $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
        $leadData=DB::table('et_lead')->where('et_lead.sno',$lead_id)->first();
        $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
        
        $helper = new \App\Helpers\Helpers();
          $encrypted_values = $helper->encrypt_decrypt($proposalData->sno, 'encrypt');
    
        //   $Link ='https://erp.elysiumtechnologies.com/manage_proposal/send_proposal/'.$encrypted_values;
           $Link =url('manage_proposal/send_proposal/' . $encrypted_values);
          
        //  communication Proposal
        $communicationStatus=DB::table('et_communication_handle')->where('module_name','Proposal Send')->first();
         $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposalData->cre_id)->first();
        if($proposalData->old_customer_check !=1){
            if($communicationStatus && $communicationStatus->status == 0){
        
             if(!$proposalData->temp_send_link){
                 $channelId = 4;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                  if($shortUrl){
                        DB::table('et_proposal')
                        ->where('sno', $proposalData->sno)
                        ->update(['temp_send_link' => $shortUrl]);
                        
                          DB::table('et_chotta_links')->insert([
                                  'branch_id' => $branch_id,
                                  'chotta_link_id' => $urlId,
                                  'chotta_short_link' => $shortUrl,
                                  'large_encrypt_link' => $Link,
                                  'link_type' => 'Proposal Send',
                                  'proposal_id' => $proposalData->sno,
                                  'created_by' => $user_id,
                                  'updated_by' => $user_id,
                              ]);
                        
                  }
              }
            
              $proposalUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_id)->first();
              
              $shortsendUrl = $proposalUrl->temp_send_link ;
              
              $proposal_key = basename($shortsendUrl);
            
           
              $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
              $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
         
          
            $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branchData->cre_mobile;
            
               $lead_name =$leadData->lead_name;
               $lead_email_id =$leadData->lead_email_id;
               $lead_mobile =$leadData->lead_mobile;
               
            // // sms proposal send
                if($communicationStatus->sms ==0){
                    if ($lead_mobile) {
        
                          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', 'PhDiZone_Enquiry_Thankyou_Message')->first();
                          $authkey = $result_sms ? $result_sms->authkey : '';
                          $sender_id = $result_sms ? $result_sms->sender_id : '';
                          $template_id = $result_sms ? $result_sms->template_id : '';
                          $country_code = $result_sms ? $result_sms->country_code : '';
                          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                          $mobile_number = $country_code . $lead_mobile;
                
                         
                          $proposal_sms_id=$proposalData->proposal_id ?? 'PRO-00001/06/2025';
                
                          // Replace placeholders with actual values
                          $replacement_values = [$lead_name,$proposal_sms_id, $shortsendUrl,$cre_mobile];
                          $message_content = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                              return array_shift($replacement_values);
                            },
                            $message_content
                          );
                
                          $route = "default";
                          $postData = array(
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender' => $sender_id,
                            'route' => $route,
                          );
                
                          // API URL
                          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                
                          // Initialize the resource
                          $ch = curl_init();
                          curl_setopt_array($ch, array(
                            CURLOPT_URL => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                          ));
                
                          // Get response
                          $response = curl_exec($ch);
                          // return $response;
                          $err = curl_error($ch);
                          curl_close($ch);
                        }
                }
                
                // email proposal Send
                 if($communicationStatus->email ==0){
                  if ($lead_email_id) {
                        $emailTemplate_id =1; // proposal send Template Id
                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
            
                    // Gender condition
                    $genderPrefix = 'Mr/Ms'; // Default value
                    if ($leadData->lead_gender == 1) {
                      $genderPrefix = 'Mr';
                    } elseif ($leadData->lead_gender == 2) {
                      $genderPrefix = 'Ms';
                    }
                    
                    
                   
                    
                    $content = $emailTemplate->email_subject;
            
                    $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
            
                    $content = str_replace('#customer_name', $lead_name, $content);
                    $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
                    $content = str_replace('#link', $shortsendUrl, $content);
                    $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                    $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
                    $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
                    $branchNo = $branch->mobile;
                    $branchemail = $branch->mail;
                    $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                    $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                    $url= 'phdizone.com';
            
                    $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $cre_mobile ?? '8220011465',
                      ];
            
                    $to_address = $lead_email_id;
                    $from_address = 'elysiumtechnology@elysium.community';
                    $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
            
            
                    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                 }
                 }
                // whatsapp proposal send
                 if($communicationStatus->whatsapp ==0){
                  if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "proposal_phdizone";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'proposal_phdizone') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                $headerImage =  url('public/assets/phdizone_images/OnBoard.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           => $lead_name,
                                        'parameter_name' => 'customer_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposalData->proposal_id,
                                        'parameter_name' => 'proposal_id',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposal_key,
                                        'parameter_name' => 'proposal_key',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $cre_mobile ?? '8220011465',
                                        'parameter_name' => 'customercare_number',
                                    ],
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $proposal_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$entity_id)->orderBy('sno', 'desc')->first();
                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                            $accessToken               = $whatsappApi->access_tokken ?? '';
                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                            $countryCode  = $leadData->inter_calls ? ($leadData->inter_calls == 0 ? '+91' : '+' . $leadData->inter_calls) : '+91';
                            $to           = $lead_mobile;
                            $languageCode = 'en';
                
                            if (strpos($to, $countryCode) !== 0) {
                                $to = $countryCode . $to;
                            }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {}
                         else{
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
                 }
                
            }else{
                $old_customer_check = 1 ;
                    //  Skip Communication For Old Customer
                     if(!$proposalData->temp_send_link){
                        DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update([
                                    'temp_send_link' => $Link,
                                    'old_customer_check'=>$old_customer_check,
                                    ]);
                     }
                  
            }
        }else{
                   if(!$proposalData->temp_send_link){
                        DB::table('et_proposal')
                                ->where('sno', $proposal_id)
                                ->update([
                                    'temp_send_link' => $Link,
                                    ]);
                     }
        }
            
        
    
                
   
      // If the operation was successful, return a success response
      return response([
        'status'    => 200,
        'message'   => "Message sent successfully",
        'error_msg' => null,
        'data'      => null,
      ], 200);
  }
  
   public function manage_proposal_edit($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
   
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
     $proposal_data=DB::table('et_proposal')->where('et_proposal.sno',$decryptedValue)->first();
     $lead=DB::table('et_lead')->where('et_lead.sno',$proposal_data->lead_id)->first();

    $lead_id =$lead->sno;
    
     $package_list =DB::table('et_package')->where('et_package.status',0)->orderBy('sno', 'desc')->get();
     $additional_charges_list =DB::table('et_additional_charges')->where('et_additional_charges.status',0)->orderBy('sno', 'desc')->get();

     $currencyList=DB::table('et_country_currencies')->where('et_country_currencies.status',0)->get();
     $domainList=DB::table('et_domain')->where('et_domain.status',0)->get();

     $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
         DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();

    $addOnProductList = DB::table('et_manage_addon')
    ->select(
      'et_manage_addon.sno',
      'et_manage_addon.addon_name'
    )
    ->where('et_manage_addon.status', 0)
    ->where('et_manage_addon.branch_id', $branch_id)
    ->get();

    foreach ($addOnProductList as $addOn){
      $manageVarient= DB::table('et_manage_addon_variant')
                      ->select(
                        'et_manage_addon_variant.sno',
                        'et_manage_addon_variant.amount',
                        'et_manage_addon_variant.free_paid',
                        'et_addon_variable.addon_variablename',
                      )
                      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                      ->where('et_manage_addon_variant.addon_id',$addOn->sno)
                      ->get();

      $addOn->add_varients=$manageVarient;
    }

    $branch_data = DB::table('et_branch')->where('sno', $request->user()->branch_id)->first();
    
          // return $addOnProductList;

    $proposal = DB::table('et_proposal')->where('sno', $decryptedValue)->where('status', 0)->first();

  
    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_sno', $proposal->sno)->where('status',0)->where('package_id','!=',0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
    //  $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $proposal_id_lead)->first();
     
        $couponCode = null;

        if ($proposal->discount_id >0) {
            $coupon = DB::table('et_manage_coupon')->where('sno', $proposal->discount_id)->first();

            if ($coupon) {
                $couponCode = $coupon->coupon_code;
            }
        }
        $Inserted_id=$decryptedValue;
          $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          
          
           $ProposalAddOnProduct = DB::table('et_proposal_addon_product')
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.proposal_sno', $decryptedValue)
            ->get();
        $oldstaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', '>' ,2)
                        ->where('et_staff.department_id', 1)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $oldstaff = $oldstaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();

// return $preProposal;
    return view('content.lead_management.manage_proposal.proposal_edit',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'currencyList' =>$currencyList,
      'Product_cat_list' =>$Product_cat_list,
      'Inserted_id' =>$Inserted_id,
      'addOnProductList' =>$addOnProductList,
      'branch_data' =>$branch_data,
      'proposal_id' =>$proposal->proposal_id,
      'package_list' =>$package_list,
      'additional_charges_list' =>$additional_charges_list,
      'packageSlot' =>$packageSlot,
      'couponCode' => $couponCode,
        'preProposal' => $proposal,
        'domainList' => $domainList,
        'crestaff' => $crestaff,
        'oldstaff' => $oldstaff,
        'ProposalAddOnProduct' => $ProposalAddOnProduct,
    ]);
  }
  
    public function updateProposal(Request $request){
    
        // return $request;
    
        $branch_id = $request->user()->branch_id;
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        


        $proposal_id = $request->input('proposal_hidden_id');
        $lead_id = $request->input('proposal_lead_id');
        $service_title = $request->input('prposal_service_title');
        $domain_ids = $request->input('proposal_domain');
        $milestone_count = $request->input('milestone_count');
        $topic = $request->input('proposal_topic');
        $cre_id = $request->input('proposal_cre');
        $due_date = $request->input('prposal_due_date') ? date('Y-m-d', strtotime($request->input('prposal_due_date'))) : null;
        $estimate_date = $request->input('estimate_date') ? date('Y-m-d', strtotime($request->input('estimate_date'))) : null;
        $currency_id = $request->input('prposal_currency');
        $proposal_date = date('Y-m-d');
        $package_check = $request->input('serv_prod_pckg_chk');
        $sub_total = $request->input('sub_total_amount');
        $discount_id = $request->input('discount_id_hidden');
        $discount_amount = $request->input('discounted_amount_hidden');
        $gst_amount = $request->input('gst_amount_hidden');
        $gst_perc = $request->input('gst_perc_hidden');
        $additional_charge_perc = $request->input('additional_charge_perc');
        $additional_charge_amount = $request->input('additional_charge_amount');
        $addtional_charges_id = $request->input('addtional_charges_id');
        $delivery_duration = $request->input('delivery_duration');
        $delivery_duration_end = $request->input('delivery_duration_end');
        $total_amount = $request->input('proposal_total_amount');
        $grant_total_amount = $request->input('grant_total_amount');
        $package_id = $request->input('package_id');
        $gst_inclusive = $request->input('gst_inclusive');
        $send_communication = $request->input('send_communication');
        $page_word = $request->input('page_word');
        $page_word_count = $request->input('page_word_count');
        $proposal_edit_id = $request->input('proposal_edit_id');

        $addtional_charges_ids= $addtional_charges_id ? json_encode($addtional_charges_id) : null;
        $domain_ids= $domain_ids ? json_encode($domain_ids) : null;

        // 1. Insert into et_proposal
     $add_category= DB::table('et_proposal')
     ->where('et_proposal.sno',$proposal_edit_id)
     ->update([
            'service_title' => $service_title,
            'domain_ids' =>$domain_ids,
            'topic' => $topic,
            'cre_id' => $cre_id,
            'milestone_count' => $milestone_count,
            'product_package' => $package_check,
            'package_id' => $package_id,
            'due_date' => $due_date,
            'estimate_date' => $estimate_date,
            'currency_id' => $currency_id,
            'propsal_date' => $proposal_date,
            'package_id' => $package_id ?? 0,
            'sub_total' => $sub_total,
            'discount_id' => $discount_id,
            'discount_amount' => $discount_amount,
            'gst_amount' => $gst_amount,
            'total_amount' => $total_amount,
            'grant_total_amount' => $grant_total_amount,
            'created_by' => $user_id,
            'updated_by' => $user_id,
            'branch_id' => $branch_id,
            'delivery_duration' => $delivery_duration,
            'delivery_duration_end' => $delivery_duration_end,
            'gst_perc' => $gst_perc,
            'gst_inclusive' => $gst_inclusive ?? 0,
            'parent_id' => $proposal_id,
            'additional_charge_perc' => $additional_charge_perc,
            'additional_charge_amount' => $additional_charge_amount,
            'addtional_charges_ids' => $addtional_charges_ids,
            'send_status' => $send_communication == 1 ? 1 : 0,
            'verify_status' => $send_communication == 1 ? 1 : 0,
            'page_word' => $page_word,
            'page_word_count' => $page_word_count ?? 0,
        ]);
       
           

        // if($package_check == 1){

        //   if ($request->has('addOn_chk')) {
        //     foreach ($request->input('addOn_chk') as $addOnId) {
        //         $variant_key = "addOn_varient_$addOnId";
        //         $variant_id = $request->input($variant_key);

        //         // Get amount from DB or default to 0
               
        //           $addon_data = DB::table('et_manage_addon_variant')
        //             ->where('sno', $variant_id)
        //             ->first();

        //         DB::table('et_proposal_addon_product')->insert([
        //             'proposal_id' => $proposal_id,
        //             'proposal_sno' => $add_category,
        //             'add_on_id' => $addOnId,
        //             'free_paid' => $addon_data ? $addon_data->free_paid :null ,
        //             'addon_variant_id' => $variant_id,
        //             'addon_amount' => $addon_data ? $addon_data->amount :0 ,
        //              'created_by' => $user_id,
        //               'updated_by' => $user_id,
        //               'branch_id' => $branch_id,
        //         ]);
        //     }
        //   }

        //   // 3. Insert into et_proposal_product_cart
        //   $temp_id = $request->input('Inserted_id_product');
        //   $product_cart_data = DB::table('et_temp_proposal_cart')
        //       ->where('temp_proposal_id', $temp_id)
        //       ->where('status', 0)
        //       ->get();

        //   foreach ($product_cart_data as $cart) {
        //       DB::table('et_proposal_product_cart')->insert([
        //           'proposal_id' => $proposal_id,
        //           'proposal_sno' => $add_category,
        //           'product_id' => $cart->product_id,
        //           'cart_id' => $cart->sno,
        //           'variant_variable_ids' => $cart->variant_variable_ids,
        //           'created_by' => $user_id,
        //             'updated_by' => $user_id,
        //             'branch_id' => $branch_id,
        //       ]);
        //   }
        // }else{
        //   $temp_id = $request->input('Inserted_id_product');
        //     DB::table('et_temp_proposal_cart')
        //         ->where('temp_proposal_id', $temp_id)
        //         ->where('status', 0)
        //         ->update(['status' => 2]);

        //          $packageTemp = DB::table('et_package')->where('status', 0)
        //             ->where('sno', $package_id)
        //             ->first();

        //     $packageData = DB::table('et_temp_package_product')->where('status', 0)
        //       ->where('temp_package_id', $packageTemp->temp_package_id)
        //       ->orderBy('sno', 'asc')
        //       ->get();

        //       if(isset($packageData)){
        //           foreach($packageData as $package){
        //               $add_package_cart= DB::table('et_proposal_package_cart')->insert([
        //                   'proposal_id' => $proposal_id,
        //                   'proposal_sno' => $add_category,
        //                   'package_id' => $package_id,
        //                   'product_id' => $package->product_id,
        //                   'product_amount' => $package->product_amount,
        //                   'variant_variable_ids' => $package->variant_variable_ids,
        //                   'created_by' => $user_id,
        //                   'updated_by' => $user_id,
        //                   'branch_id' => $branch_id,
        //               ]);
        //           }
        //       }

                 

        // }

        
        
        

        DB::commit();
      
            
        
        
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Proposal Updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Proposal!'
          ]);
        }
        return redirect('manage_proposal');
  }
    
    public function ReviseProposal(Request $request){

    $lead_id= $request->proposal_lead_id ?? 0;

    $values = $request->input('proposal_id');
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');

    // Return the encrypted value as JSON
    return response()->json($encrypted_values);
  }

   public function manage_proposal_revise($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
        return redirect()->back()->with('error', 'Invalid Entry');
    }

    $prps_id = $decryptedValue;
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    
    

    // Get the latest proposal by ID and make sure it's not rejected (status != 2)
    $proposalLast = DB::table('et_proposal')
        ->where('sno', $prps_id)
        ->where('status', '!=', 2)
        ->orderByDesc('sno')
        ->first();

    if (!$proposalLast) {
        return redirect()->back()->with('error', 'Proposal not found or already rejected.');
    }

    // Check if a revised proposal already exists
    $category_check = DB::table('et_proposal')
        ->where('revised_from', $prps_id)
        ->where('revised', 1)
        ->orderByDesc('sno')
        ->first();
        


    if (!$category_check) {
        // Create a new revised proposal
        DB::beginTransaction();

        $proposal = new ProposalModel();
        
        $proposal->lead_id = $proposalLast->lead_id;
        $proposal->service_title = $proposalLast->service_title;
        $proposal->domain_ids = $proposalLast->domain_ids;
        $proposal->topic = $proposalLast->topic;
        $proposal->cre_id = $proposalLast->cre_id;
        $proposal->milestone_count = $proposalLast->milestone_count;
        $proposal->product_package = $proposalLast->product_package;
        $proposal->package_id = $proposalLast->package_id ?? 0;
        $proposal->due_date = $proposalLast->due_date;
        $proposal->estimate_date = $proposalLast->estimate_date;
        $proposal->currency_id = $proposalLast->currency_id;
        $proposal->propsal_date = date('Y-m-d');
        $proposal->sub_total = $proposalLast->sub_total;
        $proposal->gst_amount = $proposalLast->gst_amount;
        $proposal->total_amount = $proposalLast->total_amount;
        $proposal->grant_total_amount = $proposalLast->grant_total_amount;
        $proposal->created_by = $user_id;
        $proposal->updated_by = $user_id;
        $proposal->branch_id = $branch_id;
        $proposal->delivery_duration = $proposalLast->delivery_duration;
        $proposal->delivery_duration_end = $proposalLast->delivery_duration_end;
        $proposal->gst_perc = $proposalLast->gst_perc;
        $proposal->gst_inclusive = $proposalLast->gst_inclusive;
        $proposal->parent_id = $proposalLast->parent_id;
        $proposal->additional_charge_perc = $proposalLast->additional_charge_perc;
        $proposal->additional_charge_amount = $proposalLast->additional_charge_amount;
        $proposal->addtional_charges_ids = $proposalLast->addtional_charges_ids;
        $proposal->page_word = $proposalLast->page_word;
        $proposal->page_word_count = $proposalLast->page_word_count;
        $proposal->referral_id = $proposalLast->referral_id;
        $proposal->old_customer_check = $proposalLast->old_customer_check;
        $proposal->post_sale_check = $proposalLast->post_sale_check;
        $proposal->revised = 1;
        $proposal->status = 2;
        $proposal->revised_from = $prps_id;
        
        $proposal->save();
        
        $ProposalRevisedId = $proposal->sno; // assuming 'id' is the primary key
        
        DB::commit();
        
        
         // 3. Insert into et_proposal_product_cart
          $product_cart_data = DB::table('et_proposal_product_cart')
              ->where('proposal_sno', $proposalLast->sno)
              ->where('status', 0)
              ->get();

          foreach ($product_cart_data as $cart) {
              DB::table('et_temp_proposal_cart')->insert([ 
                  'temp_revised_id' => $ProposalRevisedId,
                  'product_id' => $cart->product_id,
                  'variant_variable_ids' => $cart->variant_variable_ids,
                  'currency_id' => $proposalLast->currency_id,
                  'product_amount' => $cart->original_amount,
                  'cust_product_amount' => $cart->product_amount,
                  'created_by' => $user_id,
                    'updated_by' => $user_id,
              ]);
          }
          
            $product_addOn_data = DB::table('et_proposal_addon_product')
              ->where('proposal_sno', $proposalLast->sno)
              ->where('status', 0)
              ->get();
              
            foreach ($product_addOn_data as $addOn) {
                  DB::table('et_proposal_addon_product')->insert([
                    'proposal_sno' => $ProposalRevisedId,
                    'add_on_id' => $addOn->add_on_id,
                    'free_paid' => $addOn->free_paid,
                    'addon_variant_id' => $addOn->addon_variant_id,
                    'addon_amount' => $addOn->addon_amount ,
                     'created_by' => $user_id,
                      'updated_by' => $user_id,
                      'branch_id' => $branch_id,
                ]);
              }
              
             if($proposalLast->product_package == 2){
                 
                     $package_cart_data = DB::table('et_proposal_package_cart')
                      ->where('proposal_sno', $proposalLast->sno)
                      ->where('status', 0)
                      ->get();
                    
                  if(isset($package_cart_data)){
                                foreach($package_cart_data as $package){
                                    $add_package_cart = DB::table('et_proposal_package_cart')->insert([
                                        'proposal_sno' => $ProposalRevisedId,
                                        'package_id' => $package->package_id,
                                        'product_id' => $package->product_id,
                                        'product_amount' => $package->product_amount,
                                        'variant_variable_ids' => $package->variant_variable_ids,
                                        'cust_product_amount' => $package->cust_product_amount,
                                        'original_product_amount' => $package->original_product_amount,
                                        'total_package_amount' => $package->total_package_amount,
                                        'created_by' => $user_id,
                                        'updated_by' => $user_id,
                                        'branch_id'   => $branch_id,
                                    ]);
                                }
                            }
             }
              
               
              
              

            
            
    
        // Fetch the newly created revised proposal
        $proposal = DB::table('et_proposal')
            ->where('sno', $ProposalRevisedId)
            ->first();
            
        
        

    } else {
        // Revised proposal already exists
        $proposal = DB::table('et_proposal')
            ->where('sno', $category_check->sno)
            ->first();
    }

     
     $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    $lead_id =$lead->sno;
    
     $package_list =DB::table('et_package')->where('et_package.status',0)->orderBy('sno', 'desc')->get();
     $additional_charges_list =DB::table('et_additional_charges')->where('et_additional_charges.status',0)->orderBy('sno', 'desc')->get();

     $currencyList=DB::table('et_country_currencies')->where('et_country_currencies.status',0)->get();
     $domainList=DB::table('et_domain')->where('et_domain.status',0)->get();

     $Product_cat_list = DB::table('et_product_category')
      ->select(
        'et_product_category.sno',
        'et_product_category.product_category_name',
         DB::raw("COUNT(CASE WHEN et_product.status = 0 THEN 1 END) as product_count")
      )
      ->leftJoin('et_product', 'et_product_category.sno', '=', 'et_product.product_category_id')
      ->where('et_product_category.status', 0)
      ->where('et_product.branch_id', $branch_id)
      ->groupBy('et_product_category.sno', 'et_product_category.product_category_name') // group by primary key of category
      ->orderBy('et_product_category.product_category_name', 'ASC')
      ->get();

    $addOnProductList = DB::table('et_manage_addon')
    ->select(
      'et_manage_addon.sno',
      'et_manage_addon.addon_name'
    )
    ->where('et_manage_addon.status', 0)
    ->where('et_manage_addon.branch_id', $branch_id)
    ->get();

    foreach ($addOnProductList as $addOn){
      $manageVarient= DB::table('et_manage_addon_variant')
                      ->select(
                        'et_manage_addon_variant.sno',
                        'et_manage_addon_variant.amount',
                        'et_manage_addon_variant.free_paid',
                        'et_addon_variable.addon_variablename',
                      )
                      ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                      ->where('et_manage_addon_variant.addon_id',$addOn->sno)
                      ->get();

      $addOn->add_varients=$manageVarient;
    }

    $branch_data = DB::table('et_branch')->where('sno', $branch_id)->first();
    
          // return $addOnProductList;
  
    $packageSlot = DB::table('et_proposal_pay_slot')->where('proposal_sno', $proposal->sno)->where('status',0)->where('package_id','!=',0)->orderBy('sno', 'desc')->first();
    // return $proposal_id;
    //  $preProposal = DB::table('et_pre_proposal')->where('proposal_id', $proposal_id_lead)->first();
     
        $couponCode = null;

        if ($proposal->discount_id >0) {
            $coupon = DB::table('et_manage_coupon')->where('sno', $proposal->discount_id)->first();

            if ($coupon) {
                $couponCode = $coupon->coupon_code;
            }
        }
        $Inserted_id=$proposal->sno;
          $crestaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)->where('et_staff.role_id', 16)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $crestaff = $crestaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
          
          
           $ProposalAddOnProduct = DB::table('et_proposal_addon_product')
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.proposal_sno', $proposal->sno)
            ->get();
            
            $packageData = DB::table('et_proposal_package_cart')->where('proposal_sno', $proposal->sno)->where('status',0)->orderBy('sno', 'asc')->get();
            
            $referalStaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', 0)
                        ->where('et_staff.role_id', '>',1)
                        // ->where('et_staff.department_id', 3)
                        // ->where('et_staff.sub_department_id', 6)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $referalStaff = $referalStaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();

        $oldstaff     = DB::table('et_staff')->select('et_staff.*', 'et_job_position.job_position_name as position_name')
                        ->where('et_staff.status', '>' ,2)
                        ->where('et_staff.department_id', 1)
                        ->join('et_job_position', 'et_job_position.sno', "=", "et_staff.position_role")
                        ->where('et_staff.branch_id', $branch_id);
          $oldstaff = $oldstaff->orderBy('et_staff.staff_name', 'asc')
          ->distinct() // Ensure unique rows
          ->get();
// return $preProposal;

    return view('content.lead_management.manage_proposal.proposal_revise',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'currencyList' =>$currencyList,
      'Product_cat_list' =>$Product_cat_list,
      'Inserted_id' =>$Inserted_id,
      'addOnProductList' =>$addOnProductList,
      'branch_data' =>$branch_data,
      'package_list' =>$package_list,
      'additional_charges_list' =>$additional_charges_list,
      'packageSlot' =>$packageSlot,
      'couponCode' => $couponCode,
        'preProposal' => $proposal,
        'domainList' => $domainList,
        'crestaff' => $crestaff,
        'oldstaff' => $oldstaff,
        'ProposalAddOnProduct' => $ProposalAddOnProduct,
        'referalStaff' => $referalStaff,
        'packageData' => $packageData,
    ]);
  }

  public function ProposalRevised(Request $request){
    
    
    
        $branch_id = $request->user()->branch_id;
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        
        
        


        $proposal_edit_id = $request->input('proposal_edit_id');
        $proposal_id = $request->input('proposal_hidden_id');
        $lead_id = $request->input('proposal_lead_id');
        $service_title = $request->input('prposal_service_title');
        $domain_ids = $request->input('proposal_domain');
        $milestone_count = $request->input('milestone_count');
        $topic = $request->input('proposal_topic');
        $cre_id = $request->input('proposal_cre');
        $due_date = $request->input('prposal_due_date') ? date('Y-m-d', strtotime($request->input('prposal_due_date'))) : null;
        $estimate_date = $request->input('estimate_date') ? date('Y-m-d', strtotime($request->input('estimate_date'))) : null;
        $currency_id = $request->input('prposal_currency');
        $proposal_date = date('Y-m-d');
        $package_check = $request->input('serv_prod_pckg_chk');
        $sub_total = $request->input('sub_total_amount');
        $discount_id = $request->input('discount_id_hidden');
        $discount_amount = $request->input('discounted_amount_hidden');
        $gst_amount = $request->input('gst_amount_hidden');
        $gst_perc = $request->input('gst_perc_hidden');
        $additional_charge_perc = $request->input('additional_charge_perc');
        $additional_charge_amount = $request->input('additional_charge_amount');
        $addtional_charges_id = $request->input('addtional_charges_id');
        $delivery_duration = $request->input('delivery_duration');
        $delivery_duration_end = $request->input('delivery_duration_end');
        $total_amount = $request->input('proposal_total_amount');
        $grant_total_amount = $request->input('grant_total_amount');
        $package_id = $request->input('package_id');
        $gst_inclusive = $request->input('gst_inclusive');
        $send_communication = $request->input('send_communication');
        $page_word = $request->input('page_word');
        $page_word_count = $request->input('page_word_count');
            $referral_id = $request->input('proposal_referral_staff');
        $old_customer_check = $request->input('old_customer_check') ?? 0;
        
        $CurrentProposal=DB::table('et_proposal')->where('et_proposal.sno',$proposal_edit_id)->first();
        
        $category_check = DB::table('et_proposal')->orderBy('sno', 'desc')->where('parent_id', $CurrentProposal->parent_id)->where('status', '!=',2)->where('revised',1)->first();

          if (!$category_check) {
              $proposal_id = $CurrentProposal->parent_id . '-01';
          } else {
              $last_id = $category_check->proposal_id; // e.g., PRO-00002/05/2025-02
              $parts = explode('-', $last_id);
              $last_number = array_pop($parts); 
    
              $new_number = str_pad((int)$last_number + 1, 2, '0', STR_PAD_LEFT); 
              $proposal_id = implode('-', $parts) . '-' . $new_number;
          }
        //  return $send_communication ;

        $addtional_charges_ids= $addtional_charges_id ? json_encode($addtional_charges_id) : null;
        $domain_ids= $domain_ids ? json_encode($domain_ids) : null;
 
            DB::beginTransaction();
            
            $proposal = ProposalModel::where('sno', $proposal_edit_id)->first();
            
            if ($proposal) {
                $proposal->proposal_id = $proposal_id;
                $proposal->lead_id = $lead_id;
                $proposal->service_title = $service_title;
                $proposal->domain_ids = $domain_ids;
                $proposal->topic = $topic;
                $proposal->cre_id = $cre_id;
                $proposal->milestone_count = $milestone_count;
                $proposal->product_package = $package_check;
                $proposal->package_id = $package_id ?? 0;
                $proposal->due_date = $due_date;
                $proposal->estimate_date = $estimate_date;
                $proposal->currency_id = $currency_id;
                $proposal->propsal_date = $proposal_date;
                $proposal->sub_total = $sub_total;
                $proposal->discount_id = $discount_id;
                $proposal->discount_amount = $discount_amount;
                $proposal->gst_amount = $gst_amount;
                $proposal->total_amount = $total_amount;
                $proposal->grant_total_amount = $grant_total_amount;
                $proposal->created_by = $user_id;
                $proposal->updated_by = $user_id;
                $proposal->branch_id = $branch_id;
                $proposal->delivery_duration = $delivery_duration;
                $proposal->delivery_duration_end = $delivery_duration_end;
                $proposal->gst_perc = $gst_perc;
                $proposal->gst_inclusive = $gst_inclusive ?? 0;
                $proposal->additional_charge_perc = $additional_charge_perc;
                $proposal->additional_charge_amount = $additional_charge_amount;
                $proposal->addtional_charges_ids = $addtional_charges_ids;
                $proposal->send_status = ($send_communication == 1) ? 1 : 0;
                $proposal->verify_status = ($send_communication == 1) ? 1 : 0;
                $proposal->page_word = $page_word;
                $proposal->page_word_count = $page_word_count ?? 0;
                $proposal->status = 0;
                $proposal->proposal_status = 0;
                $proposal->referral_id = $referral_id ?? 0;
                $proposal->old_customer_check = $old_customer_check ?? 0;
            
                $proposal->update();
                
              
            } 
       
            DB::table('et_proposal_pay_slot')
                ->where('proposal_sno', $proposal_edit_id)
                ->where('status', 0)
                ->update(['proposal_id' => $proposal_id]);

        if($package_check == 1){
             DB::table('et_proposal_addon_product')
                ->where('proposal_sno', $proposal_edit_id)
                ->where('status', 0)
                ->update(['proposal_id' => $proposal_id]);
          
                
            //   if ($request->has('addOn_chk')) {
        //     foreach ($request->input('addOn_chk') as $addOnId) {
        //         $variant_key = "addOn_varient_$addOnId";
        //         $variant_id = $request->input($variant_key);

        //         // Get amount from DB or default to 0
               
        //           $addon_data = DB::table('et_manage_addon_variant')
        //             ->where('sno', $variant_id)
        //             ->first();

        //         DB::table('et_proposal_addon_product')->insert([
        //             'proposal_id' => $proposal_id,
        //             'proposal_sno' => $proposal_edit_id,
        //             'add_on_id' => $addOnId,
        //             'free_paid' => $addon_data ? $addon_data->free_paid :null ,
        //             'addon_variant_id' => $variant_id,
        //             'addon_amount' => $addon_data ? $addon_data->amount :0 ,
        //              'created_by' => $user_id,
        //               'updated_by' => $user_id,
        //               'branch_id' => $branch_id,
        //         ]);
        //     }
        //   }

          // 3. Insert into et_proposal_product_cart
          $temp_id = $request->input('Inserted_id_product');
          $product_cart_data = DB::table('et_temp_proposal_cart')
              ->where('temp_revised_id', $temp_id)
              ->where('status', 0)
              ->get();

          foreach ($product_cart_data as $cart) {
              DB::table('et_proposal_product_cart')->insert([
                  'proposal_id' => $proposal_id,
                  'proposal_sno' => $proposal_edit_id,
                  'product_id' => $cart->product_id,
                  'product_amount' => $cart->cust_product_amount,
                  'original_amount' => $cart->product_amount,
                  'cart_id' => $cart->sno,
                  'variant_variable_ids' => $cart->variant_variable_ids,
                  'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'branch_id' => $branch_id,
              ]);
          }
          
              DB::table('et_proposal_package_cart')
                ->where('proposal_sno', $proposal_edit_id)
                ->where('status', 0)
                ->update(['status' => 2]);
          
          
        }else{
             DB::table('et_proposal_addon_product')
                ->where('proposal_sno', $proposal_edit_id)
                ->where('status', 0)
                ->update(['proposal_id' => $proposal_id]);
            
              DB::table('et_proposal_package_cart')
                    ->where('proposal_sno', $proposal_edit_id)
                    ->where('status', 0)
                    ->update(['proposal_id' => $proposal_id]);
                    
          $temp_id = $request->input('Inserted_id_product');
          
            DB::table('et_temp_proposal_cart')
                ->where('temp_revised_id', $proposal_edit_id)
                ->where('status', 0)
                ->update(['status' => 2]);
                
            DB::table('et_proposal_product_cart')
                ->where('proposal_sno', $proposal_edit_id)
                ->where('status', 0)
                ->update(['status' => 2]);

        }

        // 2. Insert into et_proposal_addon_product
        
        
        

        DB::commit();
        // send Communication
        if($send_communication == 1){
            $proposalData=DB::table('et_proposal')->where('et_proposal.sno',$proposal_edit_id)->first();
            $leadData=DB::table('et_lead')->where('et_lead.sno',$lead_id)->first();
            $entityData = DB::table('et_entity')->where('status', 0)->where('sno', $entity_id)->first();
            
            $helper = new \App\Helpers\Helpers();
              $encrypted_values = $helper->encrypt_decrypt($proposalData->sno, 'encrypt');
        
            //   $Link ='https://dev.erp.elysiumtechnologies.com/manage_proposal/send_proposal/'.$encrypted_values;
               $Link =url('manage_proposal/send_proposal/' . $encrypted_values);
              
            //  communication Proposal
            $communicationStatus=DB::table('et_communication_handle')->where('module_name','Proposal Send')->first();
             $cug_details = DB::table('et_cug_management')->where('status', 0)->where('staff_id',$proposalData->cre_id)->first();
            if($communicationStatus && $communicationStatus->status == 0){
       
             if(!$proposalData->temp_send_link){
                 $channelId = 4;
                 $shortUrlData = $this->shortenUrl($Link,$channelId);
                 $shortUrl = $shortUrlData['shorturl'];
                 $urlId =$shortUrlData['id'];
                  if($shortUrl){
                        DB::table('et_proposal')
                        ->where('sno', $proposalData->sno)
                        ->update(['temp_send_link' => $shortUrl]);
                        
                          DB::table('et_chotta_links')->insert([
                                  'branch_id' => $branch_id,
                                  'chotta_link_id' => $urlId,
                                  'chotta_short_link' => $shortUrl,
                                  'large_encrypt_link' => $Link,
                                  'link_type' => 'Proposal Send',
                                  'proposal_id' => $proposalData->sno,
                                  'created_by' => $user_id,
                                  'updated_by' => $user_id,
                              ]);
                        
                  }
              }
            
              $proposalUrl=DB::table('et_proposal')->where('et_proposal.sno',$proposal_edit_id)->first();
              
              $shortsendUrl = $proposalUrl->temp_send_link ;
              
              $proposal_key = basename($shortsendUrl);
            
           
              $branch = BranchModel::where('sno', $request->user()->branch_id)->orderBy('sno', 'desc')->first();
        
              $cre = StaffModel::where('sno', $proposalData->created_by)->orderBy('sno', 'desc')->first();
         
          
            $cre_mobile =$cug_details ? $cug_details->staff_mobile :  $branch_data->cre_mobile;
            
               $lead_name =$leadData->lead_name;
               $lead_email_id =$leadData->lead_email_id;
               $lead_mobile =$leadData->lead_mobile;
            // // sms proposal send
                if($communicationStatus->sms ==0){
                    if ($lead_mobile) {
        
                          $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '4_PhDiZone_Proposal_Template')->first();
                          $authkey = $result_sms ? $result_sms->authkey : '';
                          $sender_id = $result_sms ? $result_sms->sender_id : '';
                          $template_id = $result_sms ? $result_sms->template_id : '';
                          $country_code = $result_sms ? $result_sms->country_code : '';
                          $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                          $mobile_number = $country_code . $lead_mobile;
                
                         
                          $proposal_sms_id=$proposalData->proposal_id ?? 'PRO-00001/06/2025';
                
                          // Replace placeholders with actual values
                          $replacement_values = [$lead_name,$proposal_sms_id, $shortsendUrl,$cre_mobile];
                          $message_content = preg_replace_callback(
                            '/\{#var#\}/',
                            function () use (&$replacement_values) {
                              return array_shift($replacement_values);
                            },
                            $message_content
                          );
                
                          $route = "default";
                          $postData = array(
                            'authkey' => $authkey,
                            'mobiles' => $mobile_number,
                            'message' => $message_content,
                            'sender' => $sender_id,
                            'route' => $route,
                          );
                
                          // API URL
                          $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";
                
                          // Initialize the resource
                          $ch = curl_init();
                          curl_setopt_array($ch, array(
                            CURLOPT_URL => $url,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $postData,
                            CURLOPT_SSL_VERIFYHOST => 0,
                            CURLOPT_SSL_VERIFYPEER => 0,
                          ));
                
                          // Get response
                          $response = curl_exec($ch);
                          // return $response;
                          $err = curl_error($ch);
                          curl_close($ch);
                        }
                }
                
                // email proposal Send
                 if($communicationStatus->email ==0){
                  if ($lead_email_id) {
                        $emailTemplate_id =1; // proposal send Template Id
                        $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
            
                    // Gender condition
                    $genderPrefix = 'Mr/Ms'; // Default value
                    if ($leadData->lead_gender == 1) {
                      $genderPrefix = 'Mr';
                    } elseif ($leadData->lead_gender == 2) {
                      $genderPrefix = 'Ms';
                    }
                    
                    
                   
                    
                    $content = $emailTemplate->email_subject;
            
                    $dynamicSubject = str_replace('#entity_name', $entityData ? $entityData->entity_name :  'Elysium Technology', $emailTemplate->email_name);
            
                    $content = str_replace('#customer_name', $lead_name, $content);
                    $content = str_replace('#proposal_id', $proposalData->proposal_id ?? 'PRO-00001/06/2025', $content);
                    $content = str_replace('#link', $shortsendUrl, $content);
                    $content = str_replace('#entity_name',  $entityData ?$entityData->entity_name :  'Elysium Technology', $content);
                    $content = str_replace('#CREname', $cre->nick_name ?? "Alex", $content);
                    $content = str_replace('#customer_care_no',  $cre_mobile ?? '8220011465', $content);
                    $branchNo = $branch->mobile;
                    $branchemail = $branch->mail;
                    $fbLink = $branch->fb_link ?? 'https://www.facebook.com/PhDiZone/';
                    $instaLink = $branch->insta_link ?? 'https://www.instagram.com/phdizoneresearch/';
                    $url= 'phdizone.com';
            
                    $mailData = [
                          'url'         => $url,
                          'subject'     => $dynamicSubject,
                          'content'     => $content,
                          'branchNo'    => $branchNo,
                          'branchemail' => $branchemail, // Use the message content from the request
                          'fbLink'      => $fbLink,      // Use the message content from the request
                          'instaLink'   => $instaLink,   // Use the message content from the request
                          'salesMobile' => $cre_mobile ?? '8220011465',
                      ];
            
                    $to_address = $lead_email_id;
                    $from_address = 'elysiumtechnology@elysium.community';
                    $from_name = $entityData ? $entityData->entity_name :  'Elysium Technology ';
            
            
                    Mail::to($to_address)->send(new ETPLMail($mailData, $from_address, $from_name));
                 }
                 }
                // whatsapp proposal send
                 if($communicationStatus->whatsapp ==0){
                  if ($lead_mobile) {
                      
                       
                            // $templateName  = "hello_world";
                            $templateName  = "proposal_phdizone";
            
                            $hasHeader  = false; // Example flag: set based on template
                            $hasBody    = false; // Example flag: set based on template
                            $hasFooter  = false; // Example flag: set based on template
                            $hasButton  = false;
                            $components = [];
                            $couponCode = " ";
                            date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
                            $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
                                                                      // $currentHour = date('H'); // Get current hour in 24-hour format
                            if ($currentHour >= 5 && $currentHour < 12) {
                                $greeting = 'Good Morning';
                            } elseif ($currentHour >= 12 && $currentHour < 18) {
                                $greeting = 'Good Afternoon';
                            } else {
                                $greeting = 'Good Evening';
                            }
            
                            if ($templateName == 'proposal_phdizone') {
                                // $headerImage = 'https://erp.elysiumtechnologies.com/public/assets/phdizone_images/OnBoard.jpg';
                                $headerImage =  url('public/assets/phdizone_images/OnBoard.jpg');
                                $couponCode  = 'NOOFFER';
                                $buttonIndex = 1;
                                $bodyText    = [
                                    [
                                        'type'           => 'text',
                                        'text'           => $lead_name,
                                        'parameter_name' => 'customer_name',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposalData->proposal_id,
                                        'parameter_name' => 'proposal_id',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $proposal_key,
                                        'parameter_name' => 'proposal_key',
                                    ],
                                    [
                                        'type'           => 'text',
                                        'text'           => $cre_mobile ?? '8220011465',
                                        'parameter_name' => 'customercare_number',
                                    ],
                                ];
                                $hasHeader = true;
                                $hasBody   = true;
                                $hasButton = true;
                            }
            
                            // Add Header if required
                            if ($hasHeader) {
                                $components[] = [
                                    'type'       => 'header',
                                    'parameters' => [
                                        [
                                            'type'  => 'image',
                                            'image' => [
                                                'link' => $headerImage, // Dynamically set header image
                                            ],
                                        ],
                                    ],
                                ];
                            }
            
                            // Add Body if required
                            if ($hasBody) {
                                $components[] = [
                                    'type'       => 'body',
                                    'parameters' => $bodyText,
                                ];
                            }
            
                            // Add Footer if required
                            if ($hasButton) {
                                $components[] = [
                                    'type'       => 'button',
                                    'sub_type'   => 'url',
                                    'index'      => 0,
                                    'parameters' => [
                                        [
                                            'type' => 'text',
                                            'text' => $proposal_key,
                                        ],
                                    ],
                                ];
                            }
                            
                            
                            $whatsappApi = DB::table('et_whatsapp_api_configure')->where('entity_id',$entity_id)->orderBy('sno', 'desc')->first();
                            $dynamicParameters         = $templateParameters[$templateName] ?? [];
                            $WhatsAppBusinessAccountId = $whatsappApi->waba_id ?? '';
                            $accessToken               = $whatsappApi->access_tokken ?? '';
                            $fromPhoneNumberId         = $whatsappApi->phonenumber_id ?? '';
            
                            $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';
            
                            $countryCode  = $leadData->inter_calls ? ($leadData->inter_calls == 0 ? '+91' : '+' . $leadData->inter_calls) : '+91';
                            $to           = $lead_mobile;
                            $languageCode = 'en';
                
                            if (strpos($to, $countryCode) !== 0) {
                                $to = $countryCode . $to;
                            }
            
                            $message = 'test~message';
                            if (empty($components)) {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'     => $templateName,
                                        'language' => [
                                            'code' => $languageCode,
                                        ],
                                    ],
                                ];
                            } else {
                                $payload = [
                                    'messaging_product' => 'whatsapp',
                                    'to'                => $to,
                                    'type'              => 'template',
                                    'template'          => [
                                        'name'       => $templateName,
                                        'language'   => [
                                            'code' => $languageCode,
                                        ],
                                        'components' => $components,
                                    ],
                                ];
                            }
            
                            $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
                         if ($response['status'] == 200) {}
                         else{
                             return response([
                                  'status' => 404,
                                  'message' => 'Failed to send message',
                                  'error_msg' => $response['error'],
                                ], 400);
                            }
                        
                  }
                 }
                
            }else{
                $old_customer_check = 1 ;
                if(!$proposalData->temp_send_link){
                    //  Skip Communication For Old Customer
                    DB::table('et_proposal')
                            ->where('sno', $proposal_edit_id)
                            ->update([
                                'temp_send_link' => $Link,
                                'old_customer_check'=>$old_customer_check,
                                ]);
                }
            }
            
        }
        
        if ($proposal) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Proposal Created Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Create the Proposal!'
          ]);
        }
        return redirect('manage_proposal');
  }
  
  
  public function paymentSlotDetailsRevised($id,Request $request){

    $data = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();
    
    $productCart = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->first();
      if ($productCart === null) {
        $productCart = (object) [
            'product_names' => '',
            'product_category_names' => ''
        ];
    }
      $product_names=[];
      $product_Category_names=[];
    $slot_amount =0;
    $seen_product_ids = [];
    $seen_category_ids = [];
    
    $propsal_data=DB::table('et_proposal')->where('sno',$id)->first();
    
    $slotUpdate=0;
    $slotCount=0;

    foreach ($data as $single) {
        $slot = DB::table('et_proposal_pay_slot')
          ->where('proposal_sno',$propsal_data->sno)
          ->where('status', 0)
          ->get();
     
        if (!in_array($single->sno, $seen_product_ids)) {
            $product_names[] = $single->product_name;
            $seen_product_ids[] = $single->sno;
        }
         if (!in_array($single->product_category_id, $seen_category_ids)) {
            $product_Category_names[] = $single->product_category_name;
            $seen_category_ids[] = $single->product_category_id;
        }
     
      $slot_amount = $slot->sum('slot_amount');

      $slot_ids = $slot->pluck('sno')->toArray();
      $single->update_slot = $slot;
      
      if(count($slot) >0){
          $slotUpdate=1;
          $slotCount=count($slot);
      }
      
     }

$productCart->product_names = implode(', ', $product_names);
$productCart->product_category_names = implode(', ', $product_Category_names);

      $slot_amount =$slot_amount;
        return response()->json([
        'status' => 200,
        'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
        'error_msg' => null,
        'data' => $data,
        'slot_amount' => $slot_amount,
        'productCart' => $productCart,
        'slotUpdate' => $slotUpdate,
        'slotCount' => $slotCount,
      ]);

  }
  
   public function product_list_proposal_revised($id)
  {
    $data = DB::table('et_temp_proposal_cart')->where('status', 0)
      ->where('temp_revised_id', $id)
      ->orderBy('sno', 'asc')
      ->get();
      $product_cart_count=count($data);
    //   $currency_id=$request->currency_id;
    //   return $currency_id;
      $productCounts = $data->groupBy('product_id')->map(function ($group) {
          return $group->count();
      });
    $html = '';
    $over_all_total = 0;
    $totalMinutes = 0;
    
    
  
    foreach ($data as $inx => $list) {
      $product_id = $list->product_id;
      $currency_id = $list->currency_id;
       $product_count = $productCounts[$product_id];
      $product_data =  ProductModel::select('et_product.*', 'et_product_category.product_category_name')
        ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
        ->where('et_product.sno', $product_id)->first();
      $duration    = $product_data->duration ?? 0;
      $duration_in = $product_data->duration_in;
      $count = $list->count ?? 1; // If count is available
      // Convert everything to minutes
      $durationInMinutes = match ($duration_in) {
        0 => $duration,            // Already in Minutes
        1 => $duration * 60,       // Hours → Minutes
        2 => $duration * 1440,     // Days → Minutes
        default => 0,
      };
        
      $priceData = DB::table('et_price_book')->select('et_price_book.*','et_country_currencies.currency_symbol')
       ->join('et_country_currencies', 'et_price_book.currency_id', '=', 'et_country_currencies.sno')
        ->where('et_price_book.currency_id', $currency_id)
        ->where('et_price_book.product_id', $product_id)
        ->first();
        
      

      $totalMinutes += $durationInMinutes * $count;

      // Set unit
      $in = match ($duration_in) {
        0 => 'Minute',
        1 => 'Hours',
        2 => 'Days',
        default => '',
      };

      $dura = $duration . ' ' . $in;
      $variant = '';
      $variable_amount = 0;
    $variant_variable_ids = json_decode($list->variant_variable_ids ?? '[]', true);

      // If json_decode returns a string instead of an array, ensure it defaults to an empty array
      if (!is_array($variant_variable_ids)) {
          $variant_variable_ids = [];
      }

      $selected_pairs = [];
      foreach ($variant_variable_ids as $v) {
          // Ensure that $v is an array and has the keys you expect
          if (is_array($v) && isset($v['variant_id']) && isset($v['variable_id'])) {
              $selected_pairs[$v['variant_id']] = $v['variable_id'];
          }
      }

      $selected_variants = array_column($variant_variable_ids, 'variant_id');



      if (!empty($variant_variable_ids)) {
        $variant .= '
                  <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                  <div class="d-flex align-items-center justify-content-between">
                      <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                      <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '">
                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                  <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                              </svg>
                          </span>
                      </a>
                  </div>
                  <!-- Modal -->
                   <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" id="kt_modal_choose_me_triger_edit' . htmlspecialchars($product_id) . '">
                  <div class="modal fade" id="kt_modal_choose_me_edit_' . htmlspecialchars($product_id) . '" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content rounded">
                              <div class="modal-header justify-content-end border-0 pb-0">
                                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                      <span class="svg-icon svg-icon-1">
                                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                          </svg>
                                      </span>
                                  </div>
                              </div>

                              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                  <div class="mb-8 text-center">
                                      <h3 class="text-center mb-4 text-black">Update Product</h3>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_name) . '</div>
                                  </div>

                                  <div class="row mb-4">
                                      <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                      <label class="col-1 text-black fs-6 fw-bold">:</label>
                                      <div class="col-8 text-black fs-6 fw-bold">' . htmlspecialchars($product_data->product_category_name) . '</div>
                                  </div>

                                  <div class="divider mt-1 mb-1">
                                      <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                  </div>
                                  <input type="hidden"id="Inserted_id_product_edit" name="Inserted_id_product_edit" value="' . htmlspecialchars($list->temp_proposal_id) . '">
                                  <input type="hidden" name="product_id_edit" value="' . htmlspecialchars($product_id) . '">
                                  <div class="row">
                                      <div class="col-lg-12 mb-1">
                                          <div class="bg-gray-200i rounded">
                                              <div class="scroll-y max-h-400px py-2 px-3">';

                                                $get_variants_loop = ManageProductVaiantModel::where('product_id', $product_id)->get();

                                                if ($get_variants_loop->count()) {
                                                  foreach ($get_variants_loop as $vari) {
                                                    $variant_checked = in_array($vari->sno, $selected_variants);
                                                    $show_div = $variant_checked ? 'block' : 'none';
                                                    $get_variables_loop = ManageProductVariableModel::where('product_variant_id', $vari->sno)->get();
                                                    $variant .= '<div class="px-3 pt-1">
                                                                    <div class="form-check form-check-inline mb-1 mt-1">
                                                                        <input class="form-check-input" type="checkbox" id="variant_check_box_edit' . htmlspecialchars($vari->sno) . '" onclick="variant_check_func_edit(' . htmlspecialchars($vari->sno) . ');" ' . ($variant_checked ? 'checked' : '') . ' />
                                                                        <label class="text-black mb-1 fs-6 fw-semibold">' . htmlspecialchars($vari->product_variant_name) . '</label>
                                                                    </div>
                                                                    <div id="variant_check_div_edit' . htmlspecialchars($vari->sno) . '" style="display: ' . $show_div . ';">
                                                                        <div class="row mt-2">';

                                                  foreach ($get_variables_loop as $vrlist) {
                                                    $is_selected = (isset($selected_pairs[$vari->sno]) && $selected_pairs[$vari->sno] == $vrlist->sno);
                                                    $variant .= '<div class="col-lg-4 mb-1">
                                                                      <div class="form-check">
                                                                          <input class="form-check-input me-0 variable_radio_edit' . htmlspecialchars($vari->sno) . '" type="radio" name="variable_radio_[' . htmlspecialchars($vari->sno) . ']" value="' . htmlspecialchars($vrlist->sno) . '" ' . ($variant_checked ? '' : 'disabled') . ' ' . ($is_selected ? 'checked' : '') . ' />
                                                                          <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                              <span>' . htmlspecialchars($vrlist->variable_name) . '</span>
                                                                              <span class="ms-1 me-1">-</span>
                                                                              <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; ' . number_format($vrlist->variable_amount) . '</span>
                                                                          </label>
                                                                      </div>
                                                                  </div>';
                                                  }

                                                  $variant .= '</div>
                                                                  <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                              </div>
                                                          </div>';
                                                }
                                              } else {
                                                $variant .= '<label class="row text-center">
                                                                <span class="text-danger fs-5">No Variant found for this <b class="text-black">' . htmlspecialchars($product_data->product_name) . '</b> Product</span>
                                                            </label>';
                                              }

                                              $variant .= '
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="d-flex justify-content-center align-items-center mt-8">
                                      <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                      <button type="button" class="btn btn-primary" onclick="edit_product(' . htmlspecialchars($product_id) . ')" id="product_button_edit_' . htmlspecialchars($product_id) . '">Update Product</button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>';
      }

     

      foreach ($variant_variable_ids as $pair) {
        $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
        $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;

        if ($variant_id && $variable_id) {
          $get_variants = ManageProductVaiantModel::where('sno', $variant_id)->first();
          $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
          
          
          $priceBookAmount = $get_variables->variable_amount; // Default amount from loop
        if ($currency_id != 70) {
            $variant_details = json_decode($priceData->varient_details, true);
            // Check if $variant_details is an array and loop through it to find the correct amount
            if (is_array($variant_details)) {
                foreach ($variant_details as $variant_detail) {
                    if ($variant_detail['variable_id'] == $variable_id) {
                        $priceBookAmount = $variant_detail['amount'];
                        break;
                    }
                }
            }
        }
          if ($get_variants && $get_variables) {
            $variable_amount += $get_variables->variable_amount;
            
            $variant .= '
              <div class="d-flex align-items-center justify-content-between flex-wrap">
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variants->product_variant_name) . '">' . htmlspecialchars($get_variants->product_variant_name) . '</label>
                      <div class="d-block">
                          <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($get_variables->variable_name) . '">' . htmlspecialchars($get_variables->variable_name) . '</label>
                      </div>
                  </div>
                  <div class="mb-1">
                      <label class="text-black fw-semibold fs-6">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($priceBookAmount) . '</label>
                  </div>
              </div>';
          }
        }
      }


      $total_amount = $list->cust_product_amount ?? $variable_amount + $product_data->base_price;
      $over_all_total += $total_amount;
                $productBasePrice =$product_data->base_price;
                if ($currency_id != 70) {
                    $productBasePrice =$priceData->base_price;
                }

                $html .= '<div class="mb-1" id="cal_prod_az_' . $inx . '">
                      <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_hd_' . $inx . '">
                        <div class="d-flex align-items-center">
                          <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_on_of(' . $inx . ');" id="cal_prod_tlp_' . $inx . '">
                              <i class="mdi mdi-plus fs-4" id="cal_prod_plus_btton_' . $inx . '"></i>
                            </a>
                          </div>
                          <div class="mb-0">
                            <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_name) . '">' . htmlspecialchars($product_data->product_name) . '</div>
                            <div class="d-block">
                              <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="' . htmlspecialchars($product_data->product_category_name) . '">' . htmlspecialchars($product_data->product_category_name) . '</label>
                            </div>
                          </div>
                        </div>
                        <div class="mb-0">
                          <label class="fs-4 fw-semibold text-black">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($total_amount) . '</label>
                          <input type="hidden" class="cart_product_amount" value="'.$total_amount.'">
                          <a href=" javascript:;" class="ms-1 fw-semibold fs-5" onclick="remove_product(' . intval($list->sno) . ',' . $product_id . ')">
                            <span title="Remove">
                              <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                  <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                    <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                      <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                      <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                    </g>
                                  </g>
                                </g>
                              </svg>
                            </span>
                          </a>
                        </div>
                      </div>
                      <div class="px-3 py-1 mb-0" id="cal_prod_tbox_' . $inx . '" style="display: none;">
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Products</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' 
                                  . ($currency_id != 70 ? htmlspecialchars($priceData->currency_symbol) : '&#8377;') 
                                  . ' ' . number_format($productBasePrice) . '</label>
                          </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-7">Durations</label>
                          </div>
                          <div class="mb-1">
                            <label class="text-black fw-semibold fs-6">' . htmlspecialchars($dura) . '</label>
                          </div>
                        </div>
                        ' . $variant . '
                      </div>
                    </div>';
    }
    // Time unit conversions
    $minutesInMonth = 30 * 1440; // 43,200
    $minutesInDay = 1440;
    $minutesInHour = 60;

    // Breakdown
    $months = floor($totalMinutes / $minutesInMonth);
    $remainingAfterMonths = $totalMinutes % $minutesInMonth;

    $days = floor($remainingAfterMonths / $minutesInDay);
    $remainingAfterDays = $remainingAfterMonths % $minutesInDay;

    $hours = floor($remainingAfterDays / $minutesInHour);
    $minutes = round($remainingAfterDays % $minutesInHour);

    // Build result string conditionally
    $durationParts = [];

    if ($months > 0) {
      $durationParts[] = "{$months} Month" . ($months != 1 ? 's' : '');
    }
    if ($days > 0 || $months > 0) {
      $durationParts[] = "{$days} Day" . ($days != 1 ? 's' : '');
    }
    if ($hours > 0 || $days > 0 || $months > 0) {
      if ($hours > 0) {
        $durationParts[] = "{$hours} Hour" . ($hours != 1 ? 's' : '');
      }
    }

    if ($minutes > 0 || empty($durationParts)) {
      $durationParts[] = "{$minutes} Minute" . ($minutes != 1 ? 's' : '');
    }

    $totalDuration = implode(' ', $durationParts);
    $overall_totalDuration = $totalDuration ?: '0';



    $product_ids = $data->pluck('product_id')->toArray();
    return response()->json([
      'status' => 200,
      'message' => $data->isNotEmpty() ? 'Products fetched successfully.' : 'No products found for this package.',
      'error_msg' => null,
      'data' => $html,
      'product_ids' => $product_ids,
      'over_all_total' => $over_all_total,
      'overall_totalDuration' => $overall_totalDuration,
      'productCounts' => $productCounts,
      'product_cart_count' => $product_cart_count,
    ]);
  }
  
  public function product_cart_List_revised(Request $request){
      
      $id= $request->id;
        $data = DB::table('et_temp_proposal_cart')
      ->select(
          'et_product.*',
          'et_product_category.product_category_name',
          'et_temp_proposal_cart.sno as cart_id',
          DB::raw('IFNULL(slot_counts.slot_count, 0) as slot_count'),
          DB::raw('slot_counts.product_cart_id')
      )
      ->where('et_temp_proposal_cart.status', 0)
      ->where('et_temp_proposal_cart.temp_revised_id', $id)
      ->join('et_product', 'et_temp_proposal_cart.product_id', '=', 'et_product.sno')
      ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->leftJoin(DB::raw('(
          SELECT product_cart_id, COUNT(*) as slot_count
          FROM et_proposal_pay_slot
          GROUP BY product_cart_id
      ) as slot_counts'), 'slot_counts.product_cart_id', '=', 'et_temp_proposal_cart.sno')
      ->orderBy('et_temp_proposal_cart.sno', 'asc')
      ->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $data
    ], 200);
  }
  
    public function proposal_product_add_revised(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id   = $request->user()->user_id;

    // Get raw JSON input
    $payload = $request->all(); // use $request->getContent() and json_decode if content-type is not handled automatically

    $Inserted_id = $payload['inserted_id'] ?? null;
    $product_id  = $payload['product_id'] ?? null;
    $variants    = $payload['variants'] ?? [];
    $currency_id    = $payload['currency_id'] ?? [];
    $product_amount  = $payload['product_amount'] ?? null;
    $product_edit_amount  = $payload['product_edit_amount'] ?? null;

    if (!$Inserted_id || !$product_id) {
      return response()->json([
        'status' => false,
        'message' => 'Missing required data.',
        'data' => null
      ]);
    }

    // Store variants as JSON for now (you can normalize later if needed)
    $variant_variable_ids = !empty($variants) ? json_encode($variants) : null;

    // Check if record already exists
    // $existing = TempProposalModel::where('temp_revised_id', $Inserted_id)
    //   ->where('product_id', $product_id)
    //   ->first();

    // if ($existing) {
    //   $existing->variant_variable_ids = $variant_variable_ids;
    //   $existing->updated_by = $user_id;
    //   $existing->status = 0;
    //   $existing->save();
    //   $record = $existing;
    // } else {
      $record = new TempProposalModel();
      $record->temp_revised_id = $Inserted_id;
      $record->product_id = $product_id;
      $record->currency_id = $currency_id;
      $record->cust_product_amount = $product_edit_amount;
      $record->product_amount = $product_amount;
      $record->variant_variable_ids = $variant_variable_ids;
      $record->created_by = $user_id;
      $record->updated_by = $user_id;
      $record->status = 0;
      $record->save();
    // }
    
        $proposalPackageCart = DB::table('et_proposal_package_cart')->where('status', 0)
                    ->where('proposal_sno', $Inserted_id)
                    ->get();
                    
            if($proposalPackageCart){
                DB::table('et_proposal_package_cart')
                ->where('proposal_sno', $Inserted_id)
                ->update(['status' => 2]);
            }
          

    return response()->json([
      'status' => true,
      'message' => 'Product variant(s) added to package successfully.',
      'data' => $record
    ]);
  }
  
  
  public function AddPaymentSlotRevised(Request $request)
  {

    // return $request;
      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;

     $pay_proposal_id = $request->input('pay_proposal_id');
     $proposal_data=DB::table('et_proposal')->where('sno',$pay_proposal_id)->first();
          
       
     $total_amount_hidden = $request->input('payment_slot_total_hidden');
     $total_amount = $request->input('payment_slot_total_amt');
     $product_id = $request->input('payment_slot_product_id');
     $package = $request->input('package_payment_slot');
     $package_id = $request->input('payment_slot_package_id');
     $curency_format = $request->input('curency_format');
     
      $branch_data = DB::table('et_branch')->where('sno',$branch_id)->first();
      
      $gstPercentage=$branch_data->gst_percentage;

     if($package == 1){
        // $cart_ids=   DB::table('et_proposal_pay_slot')
        //     ->where('proposal_id', $pay_proposal_id)
        //     ->where('status', 0)
        //     ->where('product_cart_id' ,'!=',0)->pluck('product_cart_id');

           DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $pay_proposal_id)
            ->where('status', 0)
            ->where('product_cart_id' ,'!=',0)
            ->update(['status' => 2]);

    //   if($cart_ids){
    //         TempProposalModel::whereIn('sno', $cart_ids)->update(['status' => 2]);
    //     }

        $slots = [];
        foreach ($request->all() as $key => $value) {
            if (preg_match('/^payment_slot_id_packg_(\d+)$/', $key, $matches)) {
                $slots[] = (int)$matches[1];
            }
        }
        // return $slots;
      if($slots){
          $firstMilestoneSet = false; 
       foreach ($slots as $index) {

        $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();
   

        $propo_pay_slot_id ='';
          if (!$category_check) {
              $year = date('Y');
              $month = date('m');
              $propo_pay_slot_id = 'PSLT-00001/' . $month.'/'. $year;
          } else {
              $year = date('Y');
              $month = date('m');
              $Inserted_id = $category_check->sno +1;
              $data = $category_check->propo_pay_slot_id;
              $slice = explode('/', $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
              $next_number = (int) $result + 1;
              $request_id = sprintf('PSLT-%05d', $next_number);
              $propo_pay_slot_id = $request_id . '/' .$month.'/'. $year;
            
          }

          $lastData = DB::table('et_proposal_pay_slot')->where('proposal_sno',$pay_proposal_id)->where('status',0)->orderBy('sno', 'desc')->first();

          if($lastData){
            $total_amount =$lastData->balance_amount;
          }else{
            $total_amount = $request->input('payment_slot_total_amt');
          }
          $slot_id = $request->input("payment_slot_id_packg_{$index}");
          $slot_amount = $request->input("payment_slot_amount_packg_{$index}");
          
          $slot_description = $request->input("slot_description_packg_{$index}");
            $to_start_deliver = $request->input("to_start_deliver_packg_{$index}");
            
            
            
          
           $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
            $gst_amount = $slot_amount - $base_amount;

          $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
          // Get deliverables and notes as arrays and JSON encode them
          $slot_deliverables = $request->input("slot_deliverables_packg_{$index}", []);
          $slot_notes = $request->input("slot_notes_packg_{$index}", []);

          $json_deliverables = json_encode($slot_deliverables);
          $json_notes = json_encode($slot_notes);
          
            $first_milestone = $firstMilestoneSet ? 0 : 1;
            $firstMilestoneSet = true; // After first insert, all others become 0
          
           DB::table('et_proposal_pay_slot')->insert([
              'propo_pay_slot_id' => $propo_pay_slot_id, 
              'proposal_sno' => $pay_proposal_id, 
              'lead_id' => $proposal_data->lead_id,
              'package_id' => $package_id,
              'slot_id' => $slot_id,
              'slot_amount' => $slot_amount,
              'payable_amount' => $slot_amount,
               'start_deliver_work' => $to_start_deliver,
              'total_amount' => $total_amount_hidden ?? $total_amount,
              'balance_amount' => $balance_amount,
              'slot_description' => $slot_description,
              'deliverable_ids' => $json_deliverables,
              'slot_notes_ids' => $json_notes,
              'gst_amount' => $gst_amount ?? 0,
              'branch_id' => $branch_id,
              'created_by' => $user_id,
              'updated_by' => $user_id,
               'first_milestone' => $first_milestone
          ]);

        }

       
      }
      

     }else{

       DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $pay_proposal_id)
            ->where('status', 0)
            ->where('package_id' ,'!=',0)
            ->update(['status' => 2]);

      // Count how many slots are in the request
      $slots = [];
      foreach ($request->all() as $key => $value) {
          if (preg_match('/^payment_slot_id_(\d+)$/', $key, $matches)) {
              $slots[] = (int)$matches[1];
          }
      }

        if($proposal_data){
            $firstMilestoneSet = false; 
            foreach ($slots as $index) {

                $category_check = DB::table('et_proposal_pay_slot')->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = date('Y');
                    $month = date('m');
                    $propo_pay_slot_id = 'PSLT-00001/' . $month.'/'. $year;
                } else {
                    $year = date('Y');
                    $month = date('m');
                    $Inserted_id = $category_check->sno +1;
                    $data = $category_check->propo_pay_slot_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request_id = sprintf('PSLT-%05d', $next_number);
                    $propo_pay_slot_id = $request_id . '/' .$month.'/'. $year;
                }

                $lastData = DB::table('et_proposal_pay_slot')->where('proposal_sno',$pay_proposal_id)->where('status',0)->orderBy('sno', 'desc')->first();

                if($lastData){
                  $total_amount =$lastData->balance_amount;
                }else{
                  $total_amount = $request->input('payment_slot_total_hidden');
                }

                $slot_id = $request->input("payment_slot_id_{$index}");
                $slot_amount = $request->input("payment_slot_amount_{$index}");
               
                $to_start_deliver = $request->input("to_start_deliver_{$index}");
                $slot_description = $request->input("slot_description_{$index}");
                
                
              
                
                $base_amount = ($slot_amount * 100) / (100 + $gstPercentage);
                $gst_amount = $slot_amount - $base_amount;

                $balance_amount = $total_amount > 0 ? $total_amount - $slot_amount : 0;
                
               $slot_deliverables_raw = $request->input("slot_deliverables_{$index}", []);
                $deliverables_grouped = [];
                
                foreach ($slot_deliverables_raw as $item) {
                    if (strpos($item, '-') !== false) {
                        [$productIndex, $value] = explode('-', $item);
                        $deliverables_grouped[$productIndex][] = [
                            'value' => $value,
                            'status' => "0"
                        ];
                    }
                }
                
                // Same for notes
                $slot_notes_raw = $request->input("slot_notes_{$index}", []);
                $notes_grouped = [];
                
                foreach ($slot_notes_raw as $item) {
                    if (strpos($item, '-') !== false) {
                        [$productIndex, $value] = explode('-', $item);
                        $notes_grouped[$productIndex][] = [
                            'value' => $value,
                            'status' => "0"
                        ];
                    }
                }
                
                // Convert to JSON
                $json_deliverables = json_encode($deliverables_grouped);
                $json_notes = json_encode($notes_grouped);
                
                $first_milestone = $firstMilestoneSet ? 0 : 1;
                $firstMilestoneSet = true; // After first insert, all others become 0

                DB::table('et_proposal_pay_slot')->insert([
                    'propo_pay_slot_id' => $propo_pay_slot_id, 
                    'proposal_sno' => $pay_proposal_id, 
                    'lead_id' => $proposal_data->lead_id,
                    'product_cart_id' => $product_id,
                    'cart_ids' => json_encode($request->input("product_cart_id_{$index}", [])),
                    'slot_id' => $slot_id,
                    'slot_amount' => $slot_amount,
                    'payable_amount' => $slot_amount,
                    'start_deliver_work' => $to_start_deliver,
                    'total_amount' => $total_amount_hidden,
                    'balance_amount' => $balance_amount,
                    'slot_description' => $slot_description,
                    'deliverable_ids' => $json_deliverables,
                    'slot_notes_ids' => $json_notes,
                    'gst_amount' => $gst_amount ?? 0,
                    'branch_id' => $branch_id,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                     'first_milestone' => $first_milestone
                ]);

            }

          // Example: Insert into DB (assuming you have a model or DB table for it)
          
        }
    }
   
    return redirect()->back();
  
  }
  
   public function updateProposalRevised(Request $request)
    {
   
    $request->validate([
        'proposal_id' => 'required',
    ]);
    $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
    $preProposal = DB::table('et_proposal')
                    ->where('sno', $request->proposal_id)
                    ->first();

    if (!$preProposal) {
        return response()->json(['status' => 'error', 'message' => 'Proposal not found'], 404);
    }

    DB::table('et_proposal')
        ->where('sno', $request->proposal_id)
        ->update([
            'addtional_charges_ids' => json_encode($request->additional_charges_ids),
            'discount_id' => $request->discount_id_hidden,
            'service_title' => $request->service_title,
            'estimate_date' => $request->estimate_date ? date('Y-m-d', strtotime($request->estimate_date)) :'',
            'due_date' => $request->prposal_due_date ? date('Y-m-d', strtotime($request->prposal_due_date)) :'',
            'currency_id' => $request->prposal_currency,
            'cre_id' => $request->proposal_cre,
            'milestone_count' => $request->milestone_count,
            'delivery_duration' => $request->delivery_duration,
            'delivery_duration_end' => $request->delivery_duration_end,
            'topic' => $request->proposal_topic,
            'domain_ids' => json_encode($request->proposal_domain),
            'package_id' => $request->package_id ?? 0,
            'referral_id' => $request->proposal_referral_staff ?? 0,
            'old_customer_check' => $request->old_customer_check ?? 0,
            'page_word' => $request->page_word,
            'page_word_count' => $request->page_word_count ?? 0,
        ]);

    
    $proposal = DB::table('et_proposal')
                    ->where('sno', $request->proposal_id)
                    ->first();

   if ($request->has('add_ons')) {
                
                DB::table('et_proposal_addon_product')
                ->where('proposal_sno', $request->proposal_id)
                ->update(['status' => 2]);
                
                
                foreach ($request->input('add_ons') as $addOnId) {
                    $variant_id = $addOnId['varient_id'];
                    $add_on_id = $addOnId['add_on_id'];
                    $addon_amount = $addOnId['amount'];
                   
                    
                    if ($proposal->currency_id != 70) {
                        // If currency_id is not 70, fetch amount from et_price_book
                        $priceDataAddon = DB::table('et_price_book')
                            ->where('currency_id', $proposal->currency_id)
                            ->where('status', 3)
                            ->get();
                            
                            $addon_data = DB::table('et_manage_addon_variant')
                            ->where('sno', $variant_id)
                            ->first();
            
                        // Find the addon amount from varient_details where variant_id matches
                        $addon_amount = 0; // Default to 0 if no match found
                        foreach ($priceDataAddon as $addon) {
                            $variantDetails = json_decode($addon->varient_details);
                            foreach ($variantDetails as $variant) {
                                if ($variant->variant_id == $variant_id) {
                                    $addon_amount = $variant->amount; // Get the amount from varient_details
                                    break 2; // Exit both loops once the matching variant is found
                                }
                            }
                        }
                    } else {
                        // If currency_id is 70, fetch data from et_manage_addon_variant table
                        $addon_data = DB::table('et_manage_addon_variant')
                            ->where('sno', $variant_id)
                            ->first();
            
                        // Set the addon_amount based on the fetched data
                        $addon_amount = $addon_data ? $addon_data->amount : 0;
                    }
                    
                    //  return $addon_amount;
                    // Insert into et_proposal_addon_product table
                    DB::table('et_proposal_addon_product')->insert([
                        'proposal_sno' => $request->proposal_id,
                        'add_on_id' => $add_on_id,
                        'free_paid' => isset($addon_data) ? $addon_data->free_paid : null,
                        'addon_variant_id' => $variant_id,
                        'addon_amount' => $addon_amount,
                        'created_by' => $user_id?? 0,
                        'updated_by' => $user_id ?? 0,
                        'branch_id' => $branch_id ?? 0,
                    ]);
                }
            }
            
            
    if($request->package_id > 0){
        
         $proposalPackageCart = DB::table('et_proposal_package_cart')
            ->where('status', 0)
            ->where('proposal_sno', $request->proposal_id)
            ->pluck('product_id') 
            ->toArray();
        
            $packageData = DB::table('et_package_product')
                ->where('status', 0)
                ->where('package_id', $request->package_id)
                ->orderBy('sno', 'asc')
                ->get();
            
            $packageTemp = DB::table('et_package')
                ->where('status', 0)
                ->where('sno', $request->package_id)
                ->first();
                    
            if ($packageData->isNotEmpty()) {
                foreach ($packageData as $package) {
                    $product_id = $package->product_id;
            
                    $cust_product_amount = $request->cust_product_amounts[$product_id] ?? $package->product_amount;
                    $original_product_amount = $request->original_product_amounts[$product_id] ?? $package->product_amount;
                    $total_amount = $request->package_actual_price_hidden ?? $packageTemp->actual_amount;
            
                    $data = [
                        'package_id' => $request->package_id,
                        'product_id' => $product_id,
                        'product_amount' => $package->product_amount,
                        'variant_variable_ids' => $package->variant_variable_ids,
                        'cust_product_amount' => $cust_product_amount,
                        'original_product_amount' => $original_product_amount,
                        'total_package_amount' => $total_amount,
                        'updated_by' => $user_id,
                    ];
            
                    if (in_array($product_id, $proposalPackageCart)) {
                        // Update existing row
                        DB::table('et_proposal_package_cart')
                            ->where('proposal_sno', $request->proposal_id)
                            ->where('product_id', $product_id)
                            ->update($data);
                    } else {
                        // Insert new row
                        $data['proposal_sno'] = $request->proposal_id;
                        $data['created_by'] = $user_id;
                        $data['branch_id'] = $branch_id;
            
                        DB::table('et_proposal_package_cart')->insert($data);
                    }
                }
            }

              
        }
        
    return response()->json(['status' => 'success']);
}

public function updateDeliverableOrder(Request $request)
{
    $request->validate([
        'slot_id' => 'required|integer',
        'cart_id' => 'required|string',
        'ordered_ids' => 'required|array',
    ]);
    // return $request;
    // Fetch the slot
    $slot = DB::table('et_proposal_pay_slot')->where('sno', $request->slot_id)->first();

    if (!$slot) {
        return response()->json(['success' => false, 'message' => 'Slot not found']);
    }

    // Decode deliverables JSON (per cart_id)
    $deliverableMap = json_decode($slot->deliverable_ids ?? '{}', true);

    $cartId = $request->cart_id;
    $orderedIds = $request->ordered_ids;

    if (!isset($deliverableMap[$cartId])) {
        return response()->json(['success' => false, 'message' => 'Cart ID not found in deliverables']);
    }

    $originalList = $deliverableMap[$cartId];

    // Rebuild new list preserving structure
    $newList = [];

    foreach ($orderedIds as $id) {
        $found = collect($originalList)->firstWhere('value', (string)$id);
        if ($found) {
            $newList[] = $found;
        } else {
            return response()->json([
                'success' => false,
                'message' => "Deliverable ID {$id} not found under cart ID {$cartId}",
            ]);
        }
    }

    // Update only that cart's deliverables
    $deliverableMap[$cartId] = $newList;

    // Save JSON back to DB
    DB::table('et_proposal_pay_slot')
        ->where('sno', $request->slot_id)
        ->update(['deliverable_ids' => json_encode($deliverableMap)]);

    return response()->json(['success' => true]);
}

public function getProductPrice(Request $request) {
    $currencyId = $request->currency_id;
    $productId  = $request->product_id;
    $package_id  = $request->package_id;
        if($productId){
            $priceData = DB::table('et_price_book')
                ->where('currency_id', $currencyId)
                ->where('product_id', $productId)
                ->first();
        }elseif($package_id){
            $priceData = DB::table('et_price_book')
                ->where('currency_id', $currencyId)
                ->where('product_id', $package_id)
                ->first();
        }else{
            $priceData =[];
        }
     
     $priceDataAddon = DB::table('et_price_book')
                ->where('currency_id', $currencyId)
                ->where('status', 3)
                ->get();
    // return $priceDataAddon;

    if (!$priceData) {
        return response()->json(['found' => false]);
    }

    $currency = DB::table('et_country_currencies')
        ->where('sno', $currencyId)
        ->first();
   
    return response()->json([
        'found' => true,
        'currency_symbol' => $currency->currency_symbol,
        'base_price' => $priceData->base_price,
        'min_amount' => $priceData->min_amount,
        'max_amount' => $priceData->max_amount,
        'variant_details' => json_decode($priceData->varient_details, true)
    ]);
}


public function getAddonPrice(Request $request) {
    $currencyId = $request->currency_id;
    
    // Fetch price data for add-ons
    $priceDataAddon = DB::table('et_price_book')
        ->where('currency_id', $currencyId)
        ->where('status', 3)
        ->get();
    
    // Loop through each addon in the price data
    foreach ($priceDataAddon as $addon) {
        // Get the addon ID from the price data
        $addOnid = $addon->addon_id;
        
        // Decode the existing variant_details JSON string to get the variable_ids
        $variantDetails = json_decode($addon->varient_details);
        
        // For each variant, fetch the free_paid status based on the variable_id
        foreach ($variantDetails as $variant) {
            $variable_id = $variant->variable_id;
            
            // Fetch the free_paid status from the manage_addon_variant table
            $manageVarient = DB::table('et_manage_addon_variant')
                ->select('free_paid')
                ->where('addon_id', $addOnid)
                ->where('variable_id', $variable_id)
                ->first();
            
            // Add the free_paid value to the variant
            if ($manageVarient) {
                $variant->free_paid = $manageVarient->free_paid;
            }
        }
        
        // Re-encode the variant details with the free_paid field
        $addon->varient_details = json_encode($variantDetails);
    }
    
    // Get the currency symbol for the selected currency
    $currency = DB::table('et_country_currencies')
        ->where('sno', $currencyId)
        ->first();
    
    // Return the response with currency symbol and the price data with variant details
    return response()->json([
        'currency_symbol' => $currency->currency_symbol,
        'priceDataAddon' => $priceDataAddon,
    ]);
}

public function RejectProposal($id ,Request $request)
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $prps_id =$decryptedValue;
     
      $proposal =DB::table('et_proposal')
                 ->select('et_proposal.*','et_staff.nick_name','et_staff.staff_name','et_entity.entity_name','et_country_currencies.currency_code','et_country_currencies.currency_symbol')
                 ->where('et_proposal.sno',$prps_id)
                  ->join('et_lead', 'et_lead.sno', '=', 'et_proposal.lead_id')
                  ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                  ->join('et_branch', 'et_proposal.branch_id', '=', 'et_branch.sno')
                  ->join('et_entity', 'et_branch.entity_id', '=', 'et_entity.sno')
                  ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                 ->where('et_proposal.status','!=',2)
                 ->where('et_lead.status','!=',2)
                 ->orderBy('et_proposal.sno', 'desc')
                 ->first();
                 
        if(!$proposal){
            $content="This proposal is no longer accessible because User Not Found!";
            return view('errors.link_expired',['content' =>$content,]);
        }
               
   
            
             DB::table('et_proposal')
                ->where('sno', $prps_id)
                ->update(['send_status' => 1]);
            
                 $exchange_quote =1;
                // if ($proposal->currency_code !== 'INR') {
                //     $response= $helper->convertFromINR($proposal->currency_code);   
                //     $exchange_quote = !empty($response['exchange_rate']) ? $response['exchange_rate'] : 0;
                // }
           

           $branch_data = DB::table('et_branch')
            ->select(
                'et_branch.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->join('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->join('et_states', 'et_states.id', '=', 'et_branch.state_id')
            ->join('et_countries', 'et_branch.country_id', '=', 'et_countries.id')
            ->where('et_branch.sno', $proposal->branch_id)
            ->first();

        

          $proposal->door_no =$branch_data->door_no ;
          $proposal->area_street = $branch_data->area_street ;
          $proposal->city_name =  $branch_data->city_name ;
          $proposal->state_name =  $branch_data->state_name ;
          $proposal->country_name =  $branch_data->country_name ;
          $proposal->pincode =  $branch_data->pincode ;
          $proposal->branch_mail =  $branch_data->mail ;
          $proposal->branch_mobile =  $branch_data->mobile ;
          $proposal->gst_no =  $branch_data->gst_no ?? "-" ;


           $lead_data = DB::table('et_lead')
            ->select(
                'et_lead.*', 
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.sno', $proposal->lead_id)
            ->first();

          $customer =DB::table('et_customer')
                ->select('et_customer.*',
                 'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
                )
                 ->leftJoin('et_cities', 'et_cities.id', '=', 'et_customer.city')
                ->leftJoin('et_states', 'et_states.id', '=', 'et_customer.state')
                ->leftJoin('et_countries', 'et_customer.country', '=', 'et_countries.id')
                 ->where('et_customer.sno',$proposal->customer_id)
                 ->where('et_customer.status','!=',2)
                 ->orderBy('et_customer.sno', 'desc')
                 ->first();

            $proposal->lead_name         = $customer->cus_name        ?? $lead_data->lead_name        ?? '';
            $proposal->lead_door_no      = $customer->door_no         ?? $lead_data->door_no          ?? '';
            $proposal->lead_address      = $customer->address         ?? $lead_data->address          ?? '';
            $proposal->lead_city_name    = $customer->city_name       ?? $lead_data->city_name        ?? '';
            $proposal->lead_state_name   = $customer->state_name      ?? $lead_data->state_name       ?? '';
            $proposal->lead_country_name = $customer->country_name    ?? $lead_data->country_name     ?? '';
            $proposal->lead_pincode      = $customer->pincode         ?? $lead_data->pincode          ?? '';
            $proposal->lead_mail         = $customer->cus_email_id    ?? $lead_data->lead_email_id    ?? '';
            $proposal->lead_mobile       = $customer->cus_mobile      ?? $lead_data->lead_mobile      ?? '';

            
      if($proposal->discount_id >0){
        $discount=DB::table('et_manage_coupon')->where('et_manage_coupon.sno',$proposal->discount_id)->first();

        $proposal->discount_value=$discount->coupon_value ;
        $proposal->discount_type=$discount->coupon_type == 'percentage' ? '1':'2';
      }
      
      $domain_ids = json_decode($proposal->domain_ids ?? '[]', true);

        $domain_names = DB::table('et_domain')
            ->where('et_domain.status', 0)
            ->whereIn('sno', $domain_ids)
            ->pluck('domain_name')  // Get only domain_name column
            ->toArray();            // Convert Collection to array
        
        $domain_list = implode(', ', $domain_names);

   
      $proposal->domain_names=$domain_list;

      // return $proposal;
      $proposal->products=[];
      $packages='';
    
    if($proposal->product_package == 1){

       $proposalProduct = DB::table('et_proposal_product_cart')
                          ->select('et_proposal_product_cart.*','et_product.product_name','et_product_category.product_category_name')
                          ->where('et_proposal_product_cart.status',0)
                          ->join('et_product', 'et_proposal_product_cart.product_id', '=', 'et_product.sno')
                          ->join('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
                          ->where('et_proposal_product_cart.proposal_id',$proposal->proposal_id)
                          ->get();
       
         $groupedProducts = [];
            $allSlotIds = [];
            $slotCount=0;
            foreach ($proposalProduct as $product) {
                $product_id = $product->product_id;
                $cart_id = $product->cart_id;
            
                // Shared data fetched once per product_id
                if (!isset($groupedProducts[$product_id])) {
                    $product_data = ProductModel::select('et_product.*')
                        ->where('et_product.sno', $product_id)->first();
            
                    $tools_ids = json_decode($product_data->tools_ids ?? '[]', true);
                    $tools_ids = is_array($tools_ids) ? $tools_ids : [];
            
                    $tools = DB::table('et_product_tools')
                        ->whereIn('sno', $tools_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('product_tools_name')
                        ->toArray();
            
                    $base_product = clone $product; // Copy to modify
                    $base_product->tools_name = $tools;
                    $base_product->product_name = $product->product_name;
                    $base_product->product_category_name = $product->product_category_name;
                    $base_product->cart_variants = [];
                    $base_product->cart_slots = [];
                    $base_product->total_amount_cart = 0;
                    $base_product->product_amount = 0;
            
                    $groupedProducts[$product_id] = $base_product;
                }
            
                // Compute variant data per cart
                $variant_variable_ids = json_decode($product->variant_variable_ids ?? '[]', true);
                $variable_amount = 0;
                $variant_names = [];
                $product_variant_name = '';
                $variable_name = '';
            
                foreach ($variant_variable_ids as $pair) {
                    $variable_id = $pair->variable_id ?? $pair['variable_id'] ?? null;
                    $variant_id = $pair->variant_id ?? $pair['variant_id'] ?? null;
            
                    if ($variant_id) {
                        $get_variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                        $product_variant_name = $get_variant->product_variant_name ?? '';
                    }
            
                    if ($variable_id) {
                        $get_variables = ManageProductVariableModel::where('sno', $variable_id)->first();
                        if ($get_variables) {
                            $variable_name = $get_variables->variable_name;
                            $variable_amount += $get_variables->variable_amount;
                        }
                    }
            
                    if ($product_variant_name && $variable_name) {
                        $variant_names[] = "{$product_variant_name} - {$variable_name}";
                    } elseif ($product_variant_name) {
                        $variant_names[] = $product_variant_name;
                    }
                }
            
                // $cart_total = $variable_amount + $product_data->base_price;
                 $cart_total = $product->product_amount;
                $groupedProducts[$product_id]->total_amount_cart += $cart_total;
            
                // Add cart-specific variant names
                $groupedProducts[$product_id]->cart_variants[$cart_id] = $variant_names;
                $groupedProducts[$product_id]->cart_quantities[$cart_id] = $product->quantity_count ?? 1;

            
                // Fetch slots for this cart
                $slots = DB::table('et_proposal_pay_slot')
                    ->select('et_proposal_pay_slot.*', 'et_payment_slot.payment_slot_name')
                    ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                    ->where('et_proposal_pay_slot.proposal_sno', $product->proposal_sno)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->get();
                $slotCount=count($slots);
                
                foreach ($slots as $slot) {
                    $slot_cart_ids = json_decode($slot->cart_ids ?? '[]', true);
                    if (!in_array($cart_id, $slot_cart_ids)) {
                        continue;
                    }
            
                    $groupedProducts[$product_id]->product_amount += $slot->slot_amount;
            
                    $deliverables_map = json_decode($slot->deliverable_ids ?? '{}', true);
                    $slot_notes_map = json_decode($slot->slot_notes_ids ?? '{}', true);
            
                    $deliverable_items = $deliverables_map[$cart_id] ?? [];
                    $slot_notes_items = $slot_notes_map[$cart_id] ?? [];
            
                    $deliverable_ids = [];
                    foreach ($deliverable_items as $d) {
                        if (($d['status'] ?? '0') == '0') {
                            $deliverable_ids[] = $d['value'];
                        }
                    }
            
                    $slot_notes_ids = [];
                    foreach ($slot_notes_items as $s) {
                        if (($s['status'] ?? '0') == '0') {
                            $slot_notes_ids[] = $s['value'];
                        }
                    }
            
                    $deliverables = DB::table('et_product_delivarables')
                        ->whereIn('sno', $deliverable_ids)
                        ->where('status', 0)
                        ->orderByRaw('FIELD(sno, ' . implode(',', $deliverable_ids) . ')')
                        ->pluck('delivarable_name');
            
                    $slot_notes = DB::table('et_slot_notes')
                        ->whereIn('sno', $slot_notes_ids)
                        ->where('status', 0)
                        ->orderBy('sno', 'desc')
                        ->pluck('slot_notes_name');
            
                    // Assign deliverables and notes for this cart
                    $slot->deliverables = $deliverables;
                    $slot->slot_notes = $slot_notes;
            
                     if (!isset($groupedProducts[$product_id]->cart_slots)) {
                            $groupedProducts[$product_id]->cart_slots = [];
                        }
                        
                        // Find if the slot already exists in the array
                        $existingIndex = null;
                        foreach ($groupedProducts[$product_id]->cart_slots as $index => $existingSlot) {
                            if ($existingSlot['sno'] === $slot->sno) {
                                $existingIndex = $index;
                                break;
                            }
                        }
                        
                        if ($existingIndex === null) {
                            // Add new slot entry
                            $groupedProducts[$product_id]->cart_slots[] = [
                                'sno' => $slot->sno,
                                'propo_pay_slot_id' => $slot->propo_pay_slot_id,
                                'branch_id' => $slot->branch_id,
                                'lead_id' => $slot->lead_id,
                                'proposal_id' => $slot->proposal_id,
                                'proposal_sno' => $slot->proposal_sno,
                                'product_cart_id' => $slot->product_cart_id,
                                'package_id' => $slot->package_id,
                                'slot_id' => $slot->slot_id,
                                'slot_amount' => $slot->slot_amount,
                                'payable_amount' => $slot->payable_amount,
                                'paidAmount' => $slot->paidAmount,
                                'gst_amount' => $slot->gst_amount,
                                'balance_amount' => $slot->balance_amount,
                                'total_amount' => $slot->total_amount,
                                'slot_description' => $slot->slot_description,
                                'created_by' => $slot->created_by,
                                'created_at' => $slot->created_at,
                                'updated_by' => $slot->updated_by,
                                'updated_at' => $slot->updated_at,
                                'status' => $slot->status,
                                'due_date' => $slot->due_date,
                                'link_status' => $slot->link_status,
                                'paid_status' => $slot->paid_status,
                                'invoice_id' => $slot->invoice_id,
                                'temp_send_link' => $slot->temp_send_link,
                                'old_customer_check' => $slot->old_customer_check,
                                'send_status' => $slot->send_status,
                                'receipt_temp_link' => $slot->receipt_temp_link,
                                'receipt_send_status' => $slot->receipt_send_status,
                                'payment_slot_name' => $slot->payment_slot_name,
                                'start_deliver_work' => $slot->start_deliver_work,
                                'deliverables' => [
                                    (string)$cart_id => $deliverables->toArray()
                                ],
                                'slot_notes' => [
                                    (string)$cart_id => $slot_notes->toArray()
                                ]
                            ];
                        } else {
                            // Slot already exists — just append deliverables and slot_notes for this cart
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['deliverables'][(string)$cart_id] = $deliverables->toArray();
                            $groupedProducts[$product_id]->cart_slots[$existingIndex]['slot_notes'][(string)$cart_id] = $slot_notes->toArray();
                        }


                }
                
            //   $groupedProducts[$product_id]->cart_slots = array_values($groupedProducts[$product_id]->cart_slots);

            }
            
            // Set the grouped products
            $proposal->products = array_values($groupedProducts);
            $proposal->slotCount=$slotCount;
    }else{

      $package_data = DB::table('et_package')
                    ->select('et_package.*')
                    ->join('et_proposal', 'et_proposal.package_id', '=', 'et_package.sno')
                    ->where('et_package.status',0)
                    ->where('et_package.sno', $proposal->package_id)
                    ->first();
                    
            $package_cart = DB::table('et_proposal_package_cart')
            ->select('variant_variable_ids','cust_product_amount')
            ->where('status', 0)
            ->where('proposal_sno', $proposal->sno)
            ->get();
                
                    $packageTotal = 0;
                    $packageTotalCart = 0;
                    
                    foreach ($package_cart as $item) {
                        $variants = json_decode($item->variant_variable_ids, true); // decode as array
                            $packageTotalCart +=$item->cust_product_amount;
                        if (is_array($variants)) {
                            foreach ($variants as $variant) {
                                if (isset($variant['amount'])) {
                                    $packageTotal += $variant['amount'];
                                }
                            }
                        }
                    }
    
            
              
            $package_product_name = DB::table('et_package_product')
              ->join('et_product', 'et_package_product.product_id', '=', 'et_product.sno')
              ->where('et_package_product.status', 0)
              ->where('et_package_product.package_id', $proposal->package_id)
              ->pluck('et_product.product_name');
              
             $package_data->product_name = $package_product_name ;
             
            
    
            $slots = DB::table('et_proposal_pay_slot')->select('et_proposal_pay_slot.*','et_payment_slot.payment_slot_name')
                            ->join('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
                            ->where('et_proposal_pay_slot.proposal_sno',$proposal->sno)
                            ->where('et_proposal_pay_slot.status',0)
                            ->get();
            $productSlot_amount =0 ;
              foreach($slots as $slot){
              $productSlot_amount += $slot->slot_amount;
                  $deliverables_ids=$slot->deliverable_ids ? json_decode($slot->deliverable_ids) : [];
                  $slot_notes_ids=$slot->slot_notes_ids ? json_decode($slot->slot_notes_ids) : [];
                  $deliverables = DB::table('et_product_delivarables')->whereIn('sno', $deliverables_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('delivarable_name');
                  $slot_notes = DB::table('et_slot_notes')->whereIn('sno', $slot_notes_ids)->where('status',0)->orderBy('sno', 'desc')->pluck('slot_notes_name');
                  $slot->deliverables =$deliverables;
                  $slot->slot_notes =$slot_notes;
              }
              $package_data->slots=$slots;
              
              $package_data->package_amount= $packageTotal ;
               $package_data->packageTotalCart= $packageTotalCart ;

         $packages=$package_data;

    }

    // return  $packages;

     $proposalAddonProduct = DB::table('et_proposal_addon_product')
                          ->select('et_manage_addon.addon_name','et_proposal_addon_product.*','et_addon_variable.addon_variablename')
                          ->where('et_proposal_addon_product.status',0)
                          ->join('et_manage_addon','et_manage_addon.sno','=','et_proposal_addon_product.add_on_id')
                          ->join('et_manage_addon_variant','et_manage_addon_variant.sno','=','et_proposal_addon_product.addon_variant_id')
                          ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                          ->where('et_proposal_addon_product.proposal_id',$proposal->proposal_id)
                          ->get();

          $freeAddonProduct = DB::table('et_proposal_addon_product')
            ->select(
                'et_manage_addon.addon_name',
                'et_proposal_addon_product.*',
                'et_addon_variable.addon_variablename'
            )
            ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
            ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
            ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
            ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
            ->where('et_proposal_addon_product.status', 0)
            ->where('et_proposal_addon_product.free_paid', 0)
            ->get();

            $paidAddonProduct = DB::table('et_proposal_addon_product')
                ->select(
                    'et_manage_addon.addon_name',
                    'et_proposal_addon_product.*',
                    'et_addon_variable.addon_variablename'
                )
                ->join('et_manage_addon', 'et_manage_addon.sno', '=', 'et_proposal_addon_product.add_on_id')
                ->join('et_manage_addon_variant', 'et_manage_addon_variant.sno', '=', 'et_proposal_addon_product.addon_variant_id')
                ->join('et_addon_variable', 'et_manage_addon_variant.variable_id', '=', 'et_addon_variable.sno')
                ->where('et_proposal_addon_product.proposal_id', $proposal->proposal_id)
                ->where('et_proposal_addon_product.status', 0)
                ->where('et_proposal_addon_product.free_paid', 1)
                ->get();
                  
                $proposal->freeAddonProducts = $freeAddonProduct;
                $proposal->paidAddonProducts = $paidAddonProduct;
     $proposal->productAddon =$proposalAddonProduct;
   
  
      $lead=DB::table('et_lead')->where('et_lead.sno',$proposal->lead_id)->first();

    

    
    $proposal_note = DB::table('et_notes')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->value('notes_details');
    $terms = DB::table('et_terms_conditions')->where('entity_id', $branch_data->entity_id)->where('status',0)->orderBy('sno', 'desc')->first();

    $proposal_terms =[];
    if($terms){
      $proposal_terms = json_decode($terms->terms_condition_list);
    }

    $signature= $terms->signature;

 $reasonList_reject = DB::table('et_proposal_reject_reason')->select('*')
        ->where('status', 0)
        ->orderBy('sno', 'desc')->get();
    // return $proposal;

    return view('content.lead_management.manage_proposal.proposal_reject',[
      'lead' =>$lead,
      'proposal' =>$proposal,
      'exchange_quote' =>$exchange_quote,
      'branch_data' =>$branch_data,
      'proposal_note' =>$proposal_note,
      'proposal_terms' =>$proposal_terms,
      'signature' =>$signature,
      'packages' =>$packages,
      'reasonList_reject' =>$reasonList_reject,
    ]);
        
  }
  
  public function ConfirmRejectProposal(Request $request){
      $proposal_status = $request->input('proposal_status');
    $id = $request->input('proposal_id');
    $proposal_reason = $request->input('proposal_reason');
    $proposal_reason_other = $request->input('proposal_reason_other');
    $reason_comments = $request->input('reason_comments');
    $user_id   = $request->user()->user_id ;
    // Update the proposal
    $update = DB::table('et_proposal')
        ->where('sno', $id)
        ->where('status', 0)
        ->update([
            'proposal_status' => 2,
            'link_status' => 1,
            'reject_reason' => $proposal_reason ?? null,
            'reject_reason_other' => $proposal_reason_other ?? null,
            'reason_comments' => $reason_comments ?? null,
            'rejected_by' => $user_id ?? 0,
        ]);
        
        $Proposal_data = DB::table('et_proposal')
            ->where('sno', $id)
            ->where('status', 0)
            ->orderBy('sno', 'asc')
            ->first();
        
        $slot_first = DB::table('et_proposal_pay_slot')
            ->where('proposal_sno', $id)
            ->where('status', 0)
            ->orderBy('sno', 'asc')
            ->first();
        
        if ($slot_first) {
            DB::table('et_proposal_pay_slot')
                ->where('proposal_sno', $id)
                ->where('status', 0)
                ->update([
                    'link_status'     => 1,
                    'paid_status'     => 3,
                ]);
        }
        
     $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($id, 'encrypt');
      return response()->json([
        'status' => 200,
        'message' => 'Proposal Confirmation Submitted',
        'error_msg' => null,
        'data' => $encrypted_values,
        'proposal_status' => $proposal_status
      ]);
    
  }

    public function fetchProposalDetails(Request $request)
    {
        // Fetch the proposal by sno
        $proposalId = $request->input('proposal_id');
        $proposal = ProposalModel::where('sno', $proposalId)->first();
        // return $proposal;
        // Check if proposal exists
        if (!$proposal) {
            return response()->json(['error' => 'Proposal not found'], 404);
        }
    
        // If it's a product package
        if ($proposal->product_package == 1) {
            // Fetch product data from the product cart
            $productCart = DB::table('et_proposal_product_cart')
                ->where('proposal_sno', $proposalId)
                ->orderBy('sno','asc')
                ->get();
            
            $products = [];
            
            foreach ($productCart as $cart) {
                // Fetch product and category details
                $product = DB::table('et_product')->where('sno',$cart->product_id)->first();
                $category = DB::table('et_product_category')->where('sno',$product->product_category_id)->first();
                $variant_names = $this->getVariantNames($cart->variant_variable_ids);
    
                $products[] = [
                    'sno' => $cart->sno,
                    'product_name' => $product->product_name,
                    'product_category_id' => $product->product_category_id,
                    'category_name' => $category->product_category_name ?? '',
                    'variant_names' => $variant_names,
                    'total_pages' => $cart->total_pages
                ];
            }
    
            return response()->json([
                'id' => $proposal->sno,
                'products' => $products
            ]);
        }
    
        // If it's a package
        elseif ($proposal->product_package == 2) {
            // Fetch package cart data
            $packageCart = DB::table('et_proposal_package_cart')
                ->where('proposal_sno', $proposalId)
                ->orderBy('sno','asc')
                ->get();
            
            $packages = [];
            // Assuming the package details are stored in the 'et_package_cart' table
            $package = DB::table('et_package')->where('sno',$proposal->package_id)->first();
            
            if ($package) {
                foreach ($packageCart as $cart) {
                    // Fetch product and category details for each cart
                    $product = DB::table('et_product')->where('sno',$cart->product_id)->first();
                    $category = DB::table('et_product_category')->where('sno',$product->product_category_id)->first();
                    $variant_names = $this->getVariantNames($cart->variant_variable_ids);
    
                    $packages[] = [
                        'sno' => $cart->sno,
                        'product_name' => $product->product_name,
                         'product_category_id' => $product->product_category_id,
                        'category_name' => $category->product_category_name ?? '',
                        'variant_names' => $variant_names,
                        'total_pages' => $cart->total_pages
                    ];
                }
            }
    
            return response()->json([
                'id' => $proposal->sno,
                'products' => $packages,
                'package_name' => $package->package_name ?? ''
            ]);
        }
    
        // Return if no product package type found
        return response()->json(['error' => 'Invalid product package type'], 400);
    }
    private function getVariantNames($variant_variable_ids)
    {
        $variant_names = [];
        $variant_variable_ids = json_decode($variant_variable_ids ?? '[]', true);
        
        foreach ($variant_variable_ids as $pair) {
            $variable_id = $pair['variable_id'] ?? null;
            $variant_id = $pair['variant_id'] ?? null;
            
            $variant_name = '';
            $variable_name = '';
            
            if ($variant_id) {
                $variant = ManageProductVaiantModel::where('sno', $variant_id)->first();
                $variant_name = $variant->product_variant_name ?? '';
            }
            
            if ($variable_id) {
                $variable = ManageProductVariableModel::where('sno', $variable_id)->first();
                if ($variable) {
                    $variable_name = $variable->variable_name;
                }
            }
            
            if ($variant_name && $variable_name) {
                $variant_names[] = "{$variant_name} - {$variable_name}";
            } elseif ($variant_name) {
                $variant_names[] = $variant_name;
            }
        }
        
        return $variant_names;
    }
    
    public function updateProposalPages(Request $request)
    {
        // return $request;
        $proposal_id=$request->input('proposal_id');
        // DB::beginTransaction();
        try {
        
        $proposal = ProposalModel::where('sno', $proposal_id)->first();
        if($proposal->product_package == 1){
            foreach ($request->input('updatedPages') as $page) {
                $cart = DB::table('et_proposal_product_cart')->where('sno', $page['sno'])->first();
                
                if ($cart) {
                    // Just update the total_pages, no additional validation needed
                    DB::table('et_proposal_product_cart')
                        ->where('sno', $page['sno'])
                        ->update(['total_pages' => $page['total_pages']]);
                }
            }
        }else{
             foreach ($request->input('updatedPages') as $page) {
                $cart = DB::table('et_proposal_package_cart')->where('sno', $page['sno'])->first();
                
                if ($cart) {
                    // Just update the total_pages, no additional validation needed
                    DB::table('et_proposal_package_cart')
                        ->where('sno', $page['sno'])
                        ->update(['total_pages' => $page['total_pages']]);
                }
            }
        }
            // Check customer services by proposal_id
            $customerServices = DB::table('et_customer_services')
                ->where('proposal_id',$proposal_id)
                ->orderBy('created_at', 'asc')  // Ensure the earliest order is selected first
                ->get();
            
                if ($customerServices->isNotEmpty()) {
                    // Loop through the customer services
                    foreach ($customerServices as $index => $customerService) {
                        // Check if there's a corresponding page from updatedPages
                        if (isset($request->input('updatedPages')[$index])) {
                            $totalPages = $request->input('updatedPages')[$index]['total_pages'];
        
                            // Update the total_pages in the customer service table
                            DB::table('et_customer_services')
                                ->where('proposal_id', $proposal_id)
                                ->where('sno',$customerService->sno)
                                ->update(['total_page' => $totalPages]);
                        }
                    }
                }
    
            // DB::commit();
            return response()->json(['success' => true]);
    
        } catch (\Exception $e) {
            // DB::rollBack();
            return response()->json(['error' => 'Failed to update pages: ' . $e->getMessage()], 500);
        }
    }

 
}
