<?php

namespace App\Http\Controllers\lead_management;

use App\Http\Controllers\Controller;
use App\Mail\EAPLMail;
use App\Models\AppointmentModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\ProductModel;
use App\Models\Communication_config_Model;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\LeadExportModel;
use App\Models\StudentpointsModel;
use App\Models\ContactDetailsModel;
use App\Models\LeadModel;
use App\Models\LeadPotentialModel;
use App\Models\LeadsExport;
use App\Models\LeadSourceModel;
use App\Models\LeadStatusModel;
use App\Models\LeadTypeModel;
use App\Models\ManageCoursesModel;
use App\Models\RawLeadModel;
use App\Models\StaffModel;
use App\Models\WhatsappApiConfigureModel;
use App\Services\DoubletickService;
use App\Models\LeadAppointmentModel;
use App\Models\SmsTemplateModel;
use DateTime;
use App\Models\FollowupReasonModel;
use App\Models\LeadExportExcel;
use App\Mail\DynamicTemplateEmail;
use App\Models\PointsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Pagination\CursorPaginator;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use App\Models\SlotModel;
use App\Models\StaffpointsModel;
use App\Models\SpamReasonModel;
use App\Models\DropReasonModel;
use App\Models\InternalReasonModel;
use App\Models\LeadTransferLogModel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class ManageLeadSource extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $year  = $request->get('year', $year ?? date('Y'));
        $month = $request->get('month', $month ?? date('m'));

        if ($year == date('Y') || $year > date('Y')) {
            $year_chk = 0;
        } else {
            $year_chk = 1;
        }
        // Get the current date
        $currentDate = now()->toDateString();
        $months = [
            'January', 'February', 'March', 'April', 'May', 'June', 
            'July', 'August', 'September', 'October', 'November', 'December'
        ];
        $results = LeadSourceModel::select(
                DB::raw("COALESCE(et_lead_source.lead_source_name, 'No Source') as lead_source_name"), // Handle NULL as 'No Source'
                DB::raw("months.month_name")
            )
            ->crossJoin(DB::raw("(SELECT 'January' as month_name UNION ALL SELECT 'February'
                UNION ALL SELECT 'March' UNION ALL SELECT 'April' UNION ALL SELECT 'May'
                UNION ALL SELECT 'June' UNION ALL SELECT 'July' UNION ALL SELECT 'August'
                UNION ALL SELECT 'September' UNION ALL SELECT 'October' UNION ALL SELECT 'November'
                UNION ALL SELECT 'December') as months"))
            ->groupBy('et_lead_source.lead_source_name', 'months.month_name')
            ->orderBy('et_lead_source.lead_source_name', 'ASC')
            ->orderBy(DB::raw("FIELD(months.month_name, '" . implode("','", $months) . "')"))
            ->get();
            
        // return $results;
        // Map through the results and calculate customer_count for each row
        $results = $results->map(function ($single) use ($year, $request) {

            $currentMonth = $single->month_name;
            $branch_id = $request->user()->branch_id;
            
            $lead_count = DB::table('et_lead')
                ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno') // Correct lead source join
                ->whereYear('et_lead.registered_date', $year)
                ->whereRaw("MONTHNAME(et_lead.registered_date) = ?", [$currentMonth]) // Match current month
                ->where('et_lead.internal_status', '!=', 1)
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.created_by', '>', 0)
                ->where('et_lead.branch_id', '=',$branch_id)
                ->where('et_lead_source.lead_source_name', $single->lead_source_name)
                ->count(); // Get count instead of retrieving records
                
            $customerConvertData = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                // ->where('et_lead.created_by', $staff->sno)
                ->whereYear('et_payment.transaction_date', $year)
                // ->whereMonth('et_payment.transaction_date', $month)
                ->whereRaw("MONTHNAME(et_payment.transaction_date) = ?", [$currentMonth]) // Match current month
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();

            
            
            $customerConvertCount =count($customerConvertData);
            
            $customer_count = DB::table('et_customer')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id') // Assuming lead_id relates customers to leads
                ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno') // Correct lead source join
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereRaw("MONTHNAME(et_payment.transaction_date) = ?", [$currentMonth]) // Match current month
                ->where('et_transaction.payment_status', 1)
                // ->whereYear('et_customer.created_at', $year)
                // ->whereRaw("MONTHNAME(et_customer.created_at) = ?", [$currentMonth]) // Match current month
                // ->where('et_customer.status', 0)
                ->where('et_lead.created_by', '>', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead_source.lead_source_name', $single->lead_source_name)
                ->count(); // Get count instead of retrieving records
        
            // Add customer_count to the single result object
            $single->customer_count = $customer_count;
            $single->total_lead     = $lead_count;
            return $single;
        });
        
        // Ensure $results is a collection
        $results = collect($results);

        // Return the view with the data and total count
        return view('content.lead_management.manage_lead_source.lead_source_list', [
            'perpage' => $perpage,
            'year_chk' => $year_chk,
            'results' => $results,
        ])->with('filter_on', false);
    }
}
