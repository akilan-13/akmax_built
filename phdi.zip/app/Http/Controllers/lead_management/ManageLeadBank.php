<?php

namespace App\Http\Controllers\lead_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\DropReasonModel;
use App\Models\LeadModel;
use App\Models\LeadTransferLogModel;
use App\Models\RawLeadModel;
use App\Models\SpamReasonModel;
use App\Models\StaffModel;
use App\Models\LeadBankModel;
use Illuminate\Support\Facades\DB;

class ManageLeadBank extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $lead_grp_fill = $request->lead_grp_fill ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $login_branch_data = BranchModel::where('status', 0)->where('sno', $branch_id)->first();
   $rawLeadQuery = LeadBankModel::select(
                                        'et_lead_bank.*',
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.sno ELSE et_lead.sno END as lead_sno"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_name ELSE et_lead.lead_name END as lead_name"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.registered_date ELSE et_lead.registered_date END as registered_date"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_gender ELSE et_lead.lead_gender END as lead_gender"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_dob ELSE et_lead.lead_dob END as lead_dob"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_email_id ELSE et_lead.lead_email_id END as lead_email_id"),
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_mobile ELSE et_lead.lead_mobile END as lead_mobile"),
                                        'et_lead_source.lead_source_name',
                                        DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_group ELSE et_lead.lead_group END as lead_group"),
                                        'et_lead_source.sno as lead_source_id'
                                    )
                                    ->leftJoin('et_raw_lead', function($join) {
                                        $join->on('et_lead_bank.lead_id', '=', 'et_raw_lead.sno')
                                             ->where('et_lead_bank.lead_type', '=', 0);
                                    })
                                    ->leftJoin('et_lead', function($join) {
                                        $join->on('et_lead_bank.lead_id', '=', 'et_lead.sno')
                                             ->where('et_lead_bank.lead_type', '=', 1);
                                    })
                                    ->leftJoin('et_lead_source', function($join) {
                                        $join->on(DB::raw("CASE WHEN et_lead_bank.lead_type = 0 THEN et_raw_lead.lead_source_id ELSE et_lead.lead_source_id END"), '=', 'et_lead_source.sno');
                                    });
                                    
                                    // Apply filters
                                    if ($branch_id != 0) {
                                        $rawLeadQuery->where(function($query) use ($branch_id, $entity_id) {
                                            $query->where(function ($q) use ($branch_id, $entity_id) {
                                                $q->where('et_raw_lead.branch_id', $branch_id)
                                                  ->where('et_raw_lead.entity_id', $entity_id);
                                            })->orWhere(function ($q) use ($branch_id, $entity_id) {
                                                $q->where('et_lead.branch_id', $branch_id)
                                                  ->where('et_lead.entity_id', $entity_id);
                                            });
                                        });
                                    }
                                    
                                    if ($lead_grp_fill != '') {
                                        $rawLeadQuery->where(function ($query) use ($lead_grp_fill) {
                                            $query->where('et_raw_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_lead.lead_name', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_raw_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_lead.registered_date', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_raw_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_lead.lead_mobile', 'LIKE', "%{$lead_grp_fill}%")
                                                  ->orWhere('et_lead_source.lead_source_name', 'LIKE', "%{$lead_grp_fill}%");
                                        });
                                    }
                                    
    $rawLeads = $rawLeadQuery->where('et_lead_bank.status','!=',2)->orderBy('et_lead_bank.sno', 'desc')->paginate($perpage);



    $totalLeadCount = RawLeadModel::where('status', 6);
    if ($branch_id != 0) {
      $totalLeadCount->where('et_raw_lead.branch_id', $branch_id)->where('et_raw_lead.entity_id', $entity_id);
    }
    $totalLeadCount = $totalLeadCount->count();

    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
          // User can only view their own data
          $totalFollowup = DB::table('et_appointment')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
            ->where('et_appointment.branch_id', $branch_id)
            ->where('et_appointment.entity_id', $entity_id)
            ->where('et_appointment.status', '!=', 4)
            ->where('et_lead.status', '=', 0)
            ->where('et_appointment.created_by', $user_id)
            ->whereDate('et_appointment.appointment_date', '=', today())
            ->count();
          // return "view_self_lead";
        } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
          // User can view all data
          $totalFollowup = DB::table('et_appointment')
            ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_appointment.lead_id')
            ->where('et_appointment.branch_id', $branch_id)
            ->where('et_appointment.entity_id', $entity_id)
            ->where('et_appointment.status', '!=', 4)
            ->where('et_lead.status', '=', 0)
            ->whereDate('et_appointment.appointment_date', '=', today())
            ->count();
          // return "global_lead";
        }
     $leadbankCount = DB::table('et_lead_bank')
            ->where('et_lead_bank.branch_id', $branch_id)
            ->where('et_lead_bank.status', 0)
            ->count();

    $walletCount = DB::table('et_lead')
      ->where('et_lead.created_by', $user_id)
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.entity_id', $entity_id)
      ->where('et_lead.wallet_status', '=', 1)
      ->count();

    $not_verified_spam_count = 0;
    $not_verified_drop_count = 0;

    $not_verified_spam_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('entity_id', $entity_id)->where('status', 7)->where('spam_verified', 0)->count();

    $not_verified_drop_count = DB::table('et_lead')->where('branch_id', $branch_id)->where('entity_id', $entity_id)->where('status', 5)->where('drop_verified', 0)->count();

    $reasonList = SpamReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $reasonList_drop = DropReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    $leadOriginal = DB::table('et_lead')
      ->where('et_lead.branch_id', $branch_id)->where('et_lead.entity_id', $entity_id)->whereNotIn('et_lead.status', [ 2, 6])->where('et_lead.internal_status', '!=', 1)->where('et_lead.created_by', '!=', 0)
      ->distinct('et_lead.sno')->where('et_lead.drop_verified', 0)->where('et_lead.spam_verified',0);
    // Apply permission-based filtering
    if (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'view_self_lead')) {
      // User can only view their own data
      $leadOriginalCount = $leadOriginal->where('et_lead.created_by', $user_id)->count();
    } elseif (auth()->user()->hasPermissionradio('Lead Management', 'Manage Lead', 'global_lead')) {
      // User can view all data (no additional filters needed)

    }
    $leadOriginalCount = $leadOriginal->count();
    $staff_check = StaffModel::select('lead_bank_count')->where('sno', $request->user()->user_id)
      ->where('status', 0)
      ->first();
    $internal_calls_count = DB::table('et_lead')
      ->where('et_lead.internal_status', 1)
      ->where('et_lead.branch_id', $branch_id)
      ->where('et_lead.internal_verify', 0)
      ->where('et_lead.potential_verify', 0)
      ->where('et_lead.lead_bank_status', 0)
      ->count();
    // Return view with data
    return view('content.lead_management.manage_lead.lead_bank_list', compact('rawLeads', 'internal_calls_count', 'staff_check', 'leadOriginalCount', 'walletCount', 'leadbankCount', 'reasonList_drop', 'reasonList', 'not_verified_spam_count', 'not_verified_drop_count', 'totalLeadCount', 'login_branch_data', 'perpage', 'totalFollowup', 'lead_grp_fill'))->with('filter_on', true);
  }
  public function bulk_bank_lead_conversion(Request $request)
  {
    // return $request;
    $checked = $request->checked;
    // $lead_source_id = $request->bulk_lead_source_id;
    $assign_staff_id = $request->bulk_assign_staff_id;
    $user_id = $request->user()->user_id;
    $count = isset($checked) ? count($checked) : 0;
    if (isset($checked) && !empty($checked)) {

      $success = true; // Flag for successful lead conversion

      foreach ($checked as $id) {
        $raw_lead = RawLeadModel::where('sno', $id)->first();
        $bank_lead = LeadBankModel::where('lead_id', $lead_id)->where('lead_type', 0)->first();
        // return $bank_lead;
        if ($raw_lead) {
          // Get the branch information
          $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

          if (!$branch_check) {
            return response([
              'status' => 400,
              'message' => 'Branch not found.',
              'error_msg' => 'Invalid branch ID.',
              'data' => null
            ], 400);
          }

          $branch_code = $branch_check->city_short_code;

          // Generate lead ID
          $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
          $year = date("Y");

          if (!$category_check) {
            $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
          } else {
            $data = $category_check->lead_id;
            $slice = explode("/", $data);
            $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
            $next_number = (int)$resultcus + 1;
            $request_pay = sprintf("LED%04d", $next_number);
            $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
          }

          // Create new lead
          $add_category = new LeadModel();
          $add_category->lead_id = $lead_id;
          $add_category->lead_name = ucfirst($raw_lead->lead_name);
          $add_category->lead_mobile = $raw_lead->lead_mobile;
          $add_category->registered_date = $raw_lead->registered_date;
          // $add_category->lead_source_id = $lead_source_id;
          $add_category->lead_group = $raw_lead->lead_group;
          $add_category->created_by = $assign_staff_id; // Same for updated_by
          $add_category->branch_id = $branch_check->sno; // Correct branch ID
          $add_category->entity_id = $request->user()->entity_id;
          $add_category->updated_by = $user_id; // Same for updated_by
          $add_category->lead_status_id = 1; // new lead
          $add_category->lead_condition = 1; // standard lead
          // return $add_category;
          if (!$add_category->save()) {
            $success = false; // Mark as unsuccessful if save fails
          }

          $add_history = new LeadTransferLogModel();
          $add_history->lead_id = $add_category->sno;
          $add_history->branch_id = $add_category->branch_id;
          $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
          $add_history->current_staff_id = $add_category->created_by;
          $add_history->change_staff_id = 0;
          $add_history->transferred_from = 7; // from Bulk transfer  
          $add_history->created_by = $user_id;
          $add_history->updated_by = $user_id;
          // return $add_history;
          $add_history->save();

          // Update raw lead status
          //   $staff = StaffModel::where('sno', $add_category->created_by)->first();
          //   if ($staff) {
          //     $staff->actual_lead_count += 1;
          //     $staff->original_lead_count += 1;
          //     // return $staff;
          //     $staff->save();
          //   }
          $raw_lead->status = 2;
          $raw_lead->save(); // Save changes to raw lead
          
          $bank_lead->status = 2;
      $bank_lead->save(); // Save changes to raw lead
        }
      }

      // Set flash message based on success flag
      if ($success) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => $count . ' Leads Converted Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add some leads conversion!'
        ]);
      }
    }

    return redirect('/lead_bank');
  }

  public function bank_lead_conversion(Request $request)
  {
    // return $request;
    $lead_id = $request->lead_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id = $request->user()->user_id;

    $raw_lead = RawLeadModel::where('sno', $lead_id)->first();
    $bank_lead = LeadBankModel::where('lead_id', $lead_id)->where('lead_type', 0)->first();
    // return $raw_lead;

    if ($raw_lead) {
      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status' => 400,
          'message' => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data' => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id = $lead_id;
      $add_category->lead_name = ucfirst($raw_lead->lead_name);
      $add_category->lead_mobile = $raw_lead->lead_mobile;
      $add_category->registered_date = $raw_lead->registered_date;
      // $add_category->lead_source_id = $lead_source_id;
      $add_category->lead_group = $raw_lead->lead_group;
      $add_category->created_by = $assign_staff_id; // Same for updated_by
      $add_category->branch_id = $branch_check->sno; // Correct branch ID
      $add_category->entity_id = $request->user()->entity_id;
      $add_category->updated_by = $user_id; // Same for updated_by
      $add_category->lead_status_id = 1; // new lead
      $add_category->lead_condition = 1; // standard lead
      $add_category->transfer_status = 1;
      // return $add_category;
      if (!$add_category->save()) {
        $success = false; // Mark as unsuccessful if save fails
      }
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $add_category->sno;
      $add_history->branch_id = $add_category->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
      $add_history->current_staff_id = $add_category->created_by;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 6; // from Bulk transfer  
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save();

      $raw_lead->status = 2;
      $raw_lead->save(); // Save changes to raw lead
      $bank_lead->status = 2;
      $bank_lead->save(); // Save changes to raw lead
    }

    return redirect('/lead_bank');
  }
  
  public function bank_bank_conversion_lead(Request $request)
  {
    // return $request;
    $lead_id = $request->lead_id;
    $assign_staff_id = $request->assg_staff_add;
    $user_id = $request->user()->user_id;
    $lead  = LeadModel::where('sno', $lead_id)->first();
    $bank_lead = LeadBankModel::where('lead_id', $lead_id)->where('lead_type', 1)->first();
    // return $lead;

    if ($lead) {

    $lead->internal_status = 0;
    $lead->lead_bank_status = 0;
    $lead->status = 0;
    $lead->lead_status_id = 1;
    $lead->transfer_status = 1;
    $lead->created_by = $assign_staff_id;
    $lead->updated_by = $assign_staff_id;
    $lead->save();
      
      $add_history = new LeadTransferLogModel();
      $add_history->lead_id = $lead_id;
      $add_history->branch_id = $lead->branch_id;
      $add_history->start_date = date('Y-m-d', strtotime($lead->created_at));
      $add_history->current_staff_id = $assign_staff_id;
      $add_history->change_staff_id = 0;
      $add_history->transferred_from = 6; // from Bulk transfer  
      $add_history->created_by = $user_id;
      $add_history->updated_by = $user_id;
      // return $add_history;
      $add_history->save();
      
      $bank_lead->status = 2;
      $bank_lead->save(); // Save changes to Bank lead
    }
    // return $lead;
    return redirect('/lead_bank');
  }
  public function EditConvertBank($id)
  {
    $lead = RawLeadModel::where('status', 7)
      ->where('sno', $id)
      ->first();

    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    // return $lead;

    if ($lead && isset($lead->registered_date)) {
      $lead->registered_date = date($common_date_format, strtotime($lead->registered_date));
    } else {
      $lead->registered_date = date('Y-m-d');
    }

    if (!$lead->registered_date) {
      // Default to today's date
      $lead->registered_date = date('Y-m-d');
    }

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $lead,
    ], 200);
  }
  public function ConvertBanktoLead(Request $request)
  {
    // return $request;
    // Check if staff exists in the same branch with active status
    $staff_check = StaffModel::where('sno', $request->user()->user_id)
      ->where('status', 0)
      ->first(); // Get the first matching staff record
    $raw_lead = RawLeadModel::where('sno', $request->lead_id)->first();
    // return $staff_check;
    $lead_name       = $request->lead_name;
    $lead_id         = $request->lead_id;
    $lead_gender     = $request->lead_gender;
    $lead_mobile     = $request->lead_mobile;
    $inter_calls     = $request->country_code_name_edit;
    $lead_source_id     = $request->lead_source_id_edit;
    $Know_tag = is_array($request->lead_Knowledge_edit_tag) ? json_encode($request->lead_Knowledge_edit_tag) : $request->lead_Knowledge_edit_tag;
    $course_id       = json_encode($request->course_id_edit);
    $lead_dob = isset($request->lead_dob) ? date('Y-m-d', strtotime($request->lead_dob)) : null;
    $lead_reg_date_up = isset($request->lead_reg_date_up) ? date('Y-m-d', strtotime($request->lead_reg_date_up)) : null;
    $upd_lead =  LeadModel::where('lead_mobile', $lead_mobile)->first();
    if ($upd_lead) {
      session()->flash('toastr', [
        'type'    => 'error',
        'message' => 'Lead Already exists',
      ]);
      return redirect('/lead_bank');
    } else {


      // Get the branch information
      $branch_check = BranchModel::where('sno', $request->user()->branch_id)->first();

      if (!$branch_check) {
        return response([
          'status'    => 400,
          'message'   => 'Branch not found.',
          'error_msg' => 'Invalid branch ID.',
          'data'      => null
        ], 400);
      }

      $branch_code = $branch_check->city_short_code;

      // Generate lead ID
      $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
      $year = date("Y");

      if (!$category_check) {
        $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
      } else {
        $data = $category_check->lead_id;
        $slice = explode("/", $data);
        $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
        $next_number = (int)$resultcus + 1;
        $request_pay = sprintf("LED%04d", $next_number);
        $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
      }

      // Create new lead
      $add_category = new LeadModel();
      $add_category->lead_id        = $lead_id;
      $add_category->lead_name      = ucwords(strtolower($lead_name));
      $add_category->lead_mobile    = $lead_mobile;
      $add_category->lead_source_id = $lead_source_id;
      $add_category->registered_date = $raw_lead->registered_date;
      $add_category->inter_calls = $inter_calls;
      $add_category->created_by     = $request->user()->user_id;  // Passed from front-end
      $add_category->branch_id      = $branch_check->sno;
      $add_category->entity_id      = $request->user()->entity_id;
      $add_category->updated_by     = $request->user()->user_id;
      $add_category->lead_status_id = 1; // new lead
      $add_category->lead_condition = 1; // standard lead
      // return $add_category;
      $add_category->save();


      if ($add_category) {
        $staff_check->lead_bank_count = $staff_check->lead_bank_count - 1;
        $staff_check->save();
        $raw_lead = RawLeadModel::where('sno', $request->lead_id)->where('status', '=', 7)->first();
        if ($raw_lead) {
          $raw_lead->status = 2;
          $raw_lead->update();
        }
      }
      return redirect('/lead_bank');
    }
  }
}