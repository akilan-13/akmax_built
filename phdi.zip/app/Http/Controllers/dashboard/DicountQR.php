<?php

namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;
use App\Models\BranchModel;
use App\Models\LeadModel;
use App\Models\ParticipantModel;
use App\Models\LeadTransferLogModel;
use App\Models\WhatsappApiConfigureModel;
use App\Models\SmsTemplateModel;
use App\Services\DoubletickService;

class DicountQR extends Controller
{

    
    public function Index($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if (!$decryptedValue) {
            return view('errors.invalid_coupon');
        }

        $today = date('Y-m-d');

        $QR_data = DB::table('et_qr_promotion')
            ->where('sno', $decryptedValue)
            ->where('expiry_date', '>=', $today)
            ->where('status', 0)
            ->first();

        if (!$QR_data) {
            return view('errors.invalid_coupon');
        }

        $branch_data = BranchModel::where('sno', $QR_data->branch_id)
            ->select(
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mobile',
                'et_branch.branch_name',
                'et_branch.sno AS branch_id',
                'et_branch.branch_type',
                'et_branch.franchise_name',
                'et_branch.mail',
                'et_branch.area_street',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')->first();
        if (!$branch_data) {
            return view('errors.invalid_coupon');
        }

        return view('content.qr_promotion.discount_qr_list', [
            'Branch_details' => $branch_data,
            'QR_data' =>  $QR_data
        ]);
    }

    public function checkdDiscountMobileExists(Request $request)
    {
        $lead_mobile = $request->input('mobile');

        $existsInDiscountLead = DB::table('et_discount_lead')
            ->where('discount_lead_phone', $lead_mobile)
            ->exists();

        $existsInLead = DB::table('et_lead')
            ->where('lead_mobile', $lead_mobile)
            ->exists();

        $exists = $existsInDiscountLead || $existsInLead;

        return response()->json(['exists' => $exists]);
    }

    public function Add(Request $request)
    {
        $validated = $request->validate([
            'lead_mobile'    => 'required|string|max:15',
            'lead_name'      => 'required|string|max:255',
            'code'           => 'required|string|max:20',
            'branch_id'      => 'required|integer',
            'discount_id'    => 'required|integer',
            'discount_value' => 'required|numeric|min:0',
        ]);

        // Optional: check if the mobile number already exists
        $exists = DB::table('et_discount_lead')
            ->where('discount_lead_phone', $validated['lead_mobile'])
            ->exists();

        if ($exists) {
            return response()->json(['exists' => true, 'message' => 'Mobile number already registered.'], 409);
        }

        $existsInLead = DB::table('et_lead')
            ->where('lead_mobile', $validated['lead_mobile'])
            ->exists();

        if ($existsInLead) {
            return response()->json(['exists' => true, 'message' => 'Mobile number already registered.'], 409);
        }

        // Insert the new discount lead
        $inserted  = DB::table('et_discount_lead')->insertGetId([
            'discount_lead_phone' => $validated['lead_mobile'],
            'discount_lead_name'  => $validated['lead_name'],
            'type'  => 1,
            'discount_code'       => $validated['code'],
            'branch_id'           => $validated['branch_id'] ?? 6,
            'discount_id'         => $validated['discount_id'],
            'discount_value'      => $validated['discount_value']
        ]);

        if ($inserted) {

            $QR_data = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->first();
            $old_users = $QR_data->users_count;
            $updates_main = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->update(['users_count' => $old_users + 1]);

            if ($QR_data->discount_type == 4) {

                $branch_id = $validated['branch_id'];
                $user_id   = $QR_data->qr_staff_id;
                $event_id = $QR_data->event_id;
                $participant_name = $validated['lead_name'];
                $mobile_no = $validated['lead_mobile'];

                $chk = ParticipantModel::where('event_id', $event_id)
                    ->where('mobile_no', $mobile_no)
                    ->where('branch_id', $branch_id)
                    ->first();
                if ($chk) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Participant Mobile Number is Already Exists!',
                    ]);
                    return redirect()->back();
                } else {

                    $last_participant_entry = ParticipantModel::orderBy('sno', 'desc')->first();

                    if (!$last_participant_entry) {
                        $year = substr(date('y'), -2);
                        $participant_id = 'EPT-0001/' . $year;
                    } else {
                        $data = $last_participant_entry->participant_id;
                        $slice = explode('/', $data);
                        $result = preg_replace('/[^0-9]/', '', $slice[0]);
                        $next_number = (int)$result + 1;
                        $participant_id = sprintf('EPT-%04d', $next_number) . '/' . substr(date('y'), -2);
                    }

                    // Create a new participant entry for the student
                    $add = new ParticipantModel();
                    $add->participant_id = $participant_id;
                    $add->participant_name = $participant_name;
                    $add->event_id = $event_id;
                    $add->mobile_no = $mobile_no;
                    $add->branch_id = $branch_id;
                    $add->created_by = $user_id;
                    $add->updated_by = $user_id;
                    $add->save();
                }
            }
            
            $branch_check = BranchModel::where('sno', $validated['branch_id'])->orderBy('sno', 'desc')->first();
            $branch_code = $branch_check->city_short_code;
            $category_check = LeadModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
            $year = date("Y");
            if (!$category_check) {
                $lead_id = $year . '/' . $branch_code . '/' . "LED0001";
            } else {
                $data = $category_check->lead_id;
                $slice = explode("/", $data);
                $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                $next_number = (int)$resultcus + 1;
                $request_pay = sprintf("LED%04d", $next_number);
                $lead_id = $year . '/' . $branch_code . '/' . $request_pay;
            }
            $add_category = new LeadModel();
            $add_category->lead_id                 = $lead_id;
            $add_category->lead_name               = Ucfirst($validated['lead_name']);
            $add_category->lead_mobile             = $validated['lead_mobile'];
            $add_category->inter_calls             = 91;
            $add_category->registered_date         = date('Y-m-d');
            $add_category->country                 = $branch_check->country_id;
            $add_category->state                   = $branch_check->state_id;
            $add_category->city                    = $branch_check->city_id;
            $add_category->branch_id               = $branch_check->sno;
            $add_category->entity_id               = $branch_check->entity_id;
            $add_category->created_by              = $QR_data->qr_staff_id;
            $add_category->updated_by              = $QR_data->qr_staff_id;
            $add_category->lead_status_id          = 1;
            // $add_category->lead_event_id       = 0;
            $add_category->lead_source_id      = 20;
            $add_category->is_qr_discount          = $inserted;
            // if ($QR_data->discount_type == 4) {
            //     $add_category->lead_event_id       = $QR_data->event_id;
            //     $add_category->lead_source_id      = 22;
            // } else {
            //     $add_category->lead_event_id       = 0;
            //     $add_category->lead_source_id      = 21;
            // }
            $add_category->save();

            if ($add_category) {
                $add_history = new LeadTransferLogModel();
                $add_history->lead_id   = $add_category->sno;
                $add_history->branch_id = $add_category->branch_id;
                $add_history->start_date = date('Y-m-d', strtotime($add_category->created_at));
                $add_history->current_staff_id = $add_category->created_by;
                $add_history->change_staff_id = 0;
                $add_history->transferred_from = 0; // from Bulk transfer  
                $add_history->created_by = $QR_data->qr_staff_id;
                $add_history->updated_by = $QR_data->qr_staff_id;
                // return $add_history;
                $add_history->save();
            }

            $branch_data = BranchModel::where('sno', $validated['branch_id'])->first();
            $branch_name = " ";
            if ($branch_data->branch_type == 1) {
                $branch_name = $branch_data->branch_name;
            } elseif ($branch_data->branch_type == 2) {
                $branch_name = $branch_data->franchise_name;
            }
            $lead_mobile = $validated['lead_mobile'];
            $lead_name = $validated['lead_name'];
            // sms thank you lead
            // if ($add_category && $lead_mobile) {

            //     $result_sms = SmsTemplateModel::where('status', 0)->where('template_name', '001_ThankyouEnquiry')->first();
            //     $authkey = $result_sms ? $result_sms->authkey : '';
            //     $sender_id = $result_sms ? $result_sms->sender_id : '';
            //     $template_id = $result_sms ? $result_sms->template_id : '';
            //     $country_code = $result_sms ? $result_sms->country_code : '';
            //     $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
            //     $mobile_number = $country_code . $lead_mobile;
            //     $cre_mobile = $branch_data->cre_mobile ?? '9677781155';

            //     // Replace placeholders with actual values
            //     $replacement_values = [$lead_name, $cre_mobile];
            //     $message_content = preg_replace_callback(
            //         '/\{#var#\}/',
            //         function () use (&$replacement_values) {
            //             return array_shift($replacement_values);
            //         },
            //         $message_content
            //     );

            //     $route = "default";
            //     $postData = array(
            //         'authkey' => $authkey,
            //         'mobiles' => $mobile_number,
            //         'message' => $message_content,
            //         'sender' => $sender_id,
            //         'route' => $route,
            //     );

            //     // API URL
            //     $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

            //     // Initialize the resource
            //     $ch = curl_init();
            //     curl_setopt_array($ch, array(
            //         CURLOPT_URL => $url,
            //         CURLOPT_RETURNTRANSFER => true,
            //         CURLOPT_POST => true,
            //         CURLOPT_POSTFIELDS => $postData,
            //         CURLOPT_SSL_VERIFYHOST => 0,
            //         CURLOPT_SSL_VERIFYPEER => 0,
            //     ));

            //     // Get response
            //     $response = curl_exec($ch);
            //     // return $response;
            //     $err = curl_error($ch);
            //     curl_close($ch);
            // }

            // whatsapp message
            // if ($add_category) {
            //     $templateName = "elysium_academy_welcome_message";
            //     $hasHeader  = false; // Example flag: set based on template
            //     $hasBody    = false; // Example flag: set based on template
            //     $hasFooter  = false; // Example flag: set based on template
            //     $hasButton  = false;
            //     $components = [];
            //     $couponCode = " ";
            //     date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
            //     $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
            //     // $currentHour = date('H'); // Get current hour in 24-hour format
            //     if ($currentHour >= 5 && $currentHour < 12) {
            //         $greeting = 'Good Morning';
            //     } elseif ($currentHour >= 12 && $currentHour < 18) {
            //         $greeting = 'Good Afternoon';
            //     } else {
            //         $greeting = 'Good Evening';
            //     }

            //     if ($templateName == 'elysium_academy_welcome_message') {

            //         $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/Welcome_Message_Header.jpg';
            //         $couponCode  = 'NOOFFER';
            //         $buttonIndex = 0;
            //         $bodyText    = [
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $greeting,
            //                 'parameter_name' => 'greet_msg',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $lead_name,
            //                 'parameter_name' => 'customer_name',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->website ?? 'https://elysiumacademy.org',
            //                 'parameter_name' => 'web_link',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_name,
            //                 'parameter_name' => 'branch_name',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->cre_mobile ?? '7708053111',
            //                 'parameter_name' => 'contact_no',
            //             ],
            //             [
            //                 'type'           => 'text',
            //                 'text'           => $branch_data->mail ?? 'info@elysiumacademy.org',
            //                 'parameter_name' => 'contact_email',
            //             ],
            //         ];
            //         $hasHeader = true;
            //         $hasBody   = true;
            //         $hasButton = true;
            //     }

            //     // Add Header if required
            //     if ($hasHeader) {
            //         $components[] = [
            //             'type'       => 'header',
            //             'parameters' => [
            //                 [
            //                     'type'  => 'image',
            //                     'image' => [
            //                         'link' => $headerImage, // Dynamically set header image
            //                     ],
            //                 ],
            //             ],
            //         ];
            //     }

            //     // Add Body if required
            //     if ($hasBody) {
            //         $components[] = [
            //             'type'       => 'body',
            //             'parameters' => $bodyText,
            //         ];
            //     }

            //     // Add Footer if required
            //     if ($hasFooter) {
            //         $components[] = [
            //             'type'       => 'footer',
            //             'parameters' => [
            //                 [
            //                     'type'           => 'text',
            //                     'text'           => 'This is the footer text.',
            //                     'parameter_name' => 'footer_text',
            //                 ],
            //             ],
            //         ];
            //     }

            //     // Add Button if required
            //     if ($hasButton) {
            //         $components[] = [
            //             'type'       => 'button',
            //             'sub_type'   => 'copy_code',
            //             'index'      => $buttonIndex,
            //             'parameters' => [
            //                 [
            //                     'type'        => 'coupon_code',
            //                     'coupon_code' => $couponCode,
            //                 ],
            //             ],
            //         ];
            //     }

            //     $dynamicParameters         = $templateParameters[$templateName] ?? [];
            //     $WhatsAppBusinessAccountId = $this->businessId;
            //     $accessToken               = $this->accessToken;
            //     $fromPhoneNumberId         = $this->phoneNumberId;

            //     $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

            //     $to           = $lead_mobile;
            //     $languageCode = 'en_US';

            //     if (strpos($to, '+91') !== 0) {
            //         $to = '+91' . $to;
            //     }

            //     $message = 'test~message';
            //     if (empty($components)) {
            //         $payload = [
            //             'messaging_product' => 'whatsapp',
            //             'to'                => $to,
            //             'type'              => 'template',
            //             'template'          => [
            //                 'name'     => $templateName,
            //                 'language' => [
            //                     'code' => $languageCode,
            //                 ],
            //             ],
            //         ];
            //     } else {
            //         $payload = [
            //             'messaging_product' => 'whatsapp',
            //             'to'                => $to,
            //             'type'              => 'template',
            //             'template'          => [
            //                 'name'       => $templateName,
            //                 'language'   => [
            //                     'code' => $languageCode,
            //                 ],
            //                 'components' => $components,
            //             ],
            //         ];
            //     }

            //     $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
            // }


            // Get the values sent from JavaScript
            $values = $inserted;
            // Encrypt the combined values
            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($values, 'encrypt');
            return response()->json(['success' => true, 'link' => $encrypted_values]);
        } else {
            return response()->json(['error' => false, 'message' => 'Error inserting record.'], 500);
        }
    }

    private function sendRequestToWhatsApp($url, $token, $data)
    {
        try {
            $client = new \GuzzleHttp\Client();
            $response = $client->post($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            return [
                'status' => $response->getStatusCode(),
                'data' => json_decode($response->getBody(), true),
            ];
        } catch (\Exception $e) {
            return [
                'status' => 400,
                'error' => $e->getMessage(),
            ];
        }
    }

    public function Add_scanner_count(Request $request)
    {
        $validated = $request->validate([
            'branch_id'      => 'required|integer',
            'discount_id'    => 'required|integer',
        ]);

        $QR_data = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->first();
        $old_users = $QR_data->scanners_count;
        $updates_main = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->update(['scanners_count' => $old_users + 1]);
        if ($updates_main) {
            return response()->json(['success' => true]);
        }
    }
    public function Add_call_try_count(Request $request)
    {
        $validated = $request->validate([
            'branch_id'      => 'required|integer',
            'lead_id'    => 'required|integer',
            'discount_id'    => 'required|integer',
        ]);
        $lead_Data = DB::table('et_discount_lead')->where('sno', $validated['lead_id'])->first();
        $lead_try_count = $lead_Data->lead_call_try_count ?? 0;
        $updates_lead = DB::table('et_discount_lead')->where('sno', $validated['lead_id'])->update(['lead_call_try_count' => $lead_try_count + 1]);

        $QR_data = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->first();
        $old_users = $QR_data->call_try_count;
        $updates_main = DB::table('et_qr_promotion')->where('sno', $validated['discount_id'])->update(['call_try_count' => $old_users + 1]);
        if ($updates_main) {
            return response()->json(['success' => true]);
        }
    }



    public function Discount_View($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if (!$decryptedValue) {
            return view('errors.invalid_coupon');
        }

        $QR_data = DB::table('et_discount_lead')->where('sno', $decryptedValue)->first();
        if (!$QR_data) {
            return view('errors.invalid_coupon');
        }
        $QR_main = DB::table('et_qr_promotion')->where('sno', $QR_data->discount_id)->first();
        $course_name = '';
        if ($QR_main->course_id) {
            $course = DB::table('et_course')->where('sno', $QR_main->course_id)->first();
            if (isset($course)) {
                $course_name = $course->course_name;
            }
        }
        $branch_data = BranchModel::where('sno', $QR_data->branch_id)
            ->select(
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mobile',
                'et_branch.branch_name',
                'et_branch.sno AS branch_id',
                'et_branch.branch_type',
                'et_branch.franchise_name',
                'et_branch.mail',
                'et_branch.area_street',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')->first();
        if (!$branch_data) {
            return view('errors.invalid_coupon');
        }

        return view('content.qr_promotion.view_discount_qr', [
            'QR_data' =>  $QR_data,
            'QR_main' =>  $QR_main,
            'Branch_data' =>  $branch_data,
            'Course_name' =>  $course_name,
            'Verifed' =>  0,
        ]);
    }

    public function Event_View($id, Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

        if (!$decryptedValue) {
            return view('errors.invalid_event', [
                'Pass' =>  1,
            ]);
        }

        $QR_data = DB::table('et_discount_lead')->where('sno', $decryptedValue)->first();
        if (!$QR_data) {
            return view('errors.invalid_event', [
                'Pass' =>  1,
            ]);
        }
        $QR_main = DB::table('et_qr_promotion')->where('sno', $QR_data->discount_id)->first();
        $course_name = '';
        if ($QR_main->course_id) {
            $course = DB::table('et_course')->where('sno', $QR_main->course_id)->first();
            if (isset($course)) {
                $course_name = $course->course_name;
            }
        }
        $branch_data = BranchModel::where('sno', $QR_data->branch_id)
            ->select(
                'et_branch.door_no',
                'et_branch.pincode',
                'et_branch.mobile',
                'et_branch.branch_name',
                'et_branch.sno AS branch_id',
                'et_branch.branch_type',
                'et_branch.franchise_name',
                'et_branch.mail',
                'et_branch.area_street',
                'et_states.name as state_name',
                'et_cities.name as city_name'
            )
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_branch.city_id')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_branch.state_id')->first();
        if (!$branch_data) {
            return view('errors.invalid_event', [
                'Pass' =>  1,
            ]);
        }

        return view('content.qr_promotion.view_discount_qr', [
            'QR_data' =>  $QR_data,
            'QR_main' =>  $QR_main,
            'Branch_data' =>  $branch_data,
            'Verifed' =>  1,
        ]);
    }
}
