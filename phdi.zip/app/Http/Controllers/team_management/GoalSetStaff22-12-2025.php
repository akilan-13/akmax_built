<?php

namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\PaymentModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\TrainingModel;
use App\Models\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;

class GoalSetStaff extends Controller
{


  public function index()
  {

    return view('content.team_management.goal_set');
  }
  // Fetch Departments based on Branch
  public function getDepartmentsGoal(Request $request)
  {

    $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
  }

  public function getTeamGoal(Request $request)
  {
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $request_month_id = $request->month_id;
    $month = date('n', strtotime($month_id));
    $year = $request->year;
    $branch_id = $request->user()->branch_id;

    // Convert month name to number if necessary
    if (!empty($request_month_id)) {
      if (!is_numeric($request_month_id)) {
        $monthNumber = date('m', strtotime($request_month_id . ' 1'));
        $request_month_id = (int) $monthNumber;
      } else {
        $request_month_id = (int) $request_month_id;
      }
    }
    // Fetch the department details
    $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

    // Get goal records for the selected department and month
    $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('team_goal_month', $request_month_id)
      ->first();


    $staff = DB::table('et_staff')
      ->select(
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.staff_image',
        'et_staff.gender',
        'et_staff.mobile_no',
        'et_staff.role_id',
        'et_staff.lead_bank_count',
        'et_staff.status as staff_status',
        'et_cug_management.staff_mobile as cug_mobile'
      )
      ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
      ->where('et_staff.department_id', $departmentId)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.branch_id', $branch_id)
      ->where('et_staff.status', 0)
      ->orderBy('et_staff.sno', 'desc')->get();
    // Initialize Totals

    $totalDepartmentAllLead = 0;
    $totalDepartmentMonthLead = 0;
    $totalDepartmentHotLead = 0;
    $totalDepartmentSpamLead = 0;
    $totalDepartmentDeadLead = 0;
    $totalDepartmentConvertCustomer = 0;
    $totalDepartmentBusinessValue = 0;
    $totalDepartmentCollectionValue = 0;
    $totalDepartmentPaidPayment = 0;
    $totalDepartmentTotalPayment = 0;
    $totalmonthFollowupCount = 0;
    $totalmonthwalkincount = 0;
    $totalmonthcall_outcount = 0;

    $working_hoursActual   = 0;
    $rework_countActual   = 0;

    // return $departmentId;
    // Goal Completed
    if (isset($goalteam->goal_completed)) {
      // return $goalteam->goal_completed;
      if ($goalteam->goal_completed == 1) {
        // PRE & Post Sales
        $totalDepartmentConvertCustomer =  $goalteam->conversion_actual;
        $totalConvertRatio =  $goalteam->cr_actual;
        $totalDepartmentBusinessValue =  $goalteam->abv_actual;
        $totalDepartmentCollectionValue =  $goalteam->acv_actual;
        $total_outgoing_call_ratio =  $goalteam->avg_call_out_actual;
        $totalmonthwalkincount =  $goalteam->no_of_walk_actual;
        $totalmonthFollowupCount =  $goalteam->no_of_followup_actual;
        // PRODUCTION
        $working_hoursActual =  $goalteam->working_hours_actual;
        $rework_countActual =  $goalteam->rework_actual;


        $goalteamDetails = [
          'department_name' => optional($department)->department_name ?? '',
          'department_id'   => optional($department)->sno ?? '',
          'team_id'         => optional($goalteam)->sno ?? '',
          'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
          'status'          => optional($goalteam)->status == 1 ? true : false,
          'month'           => $month_id,

          'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
          'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
          'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
          'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

          'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
          'cr_check'                      => optional($goalteam)->cr_check ?? 0,
          'cr_type'                       => optional($goalteam)->cr_type ?? 0,
          'cr_actual'                     => $totalConvertRatio ?? 'N/A',


          'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
          'abv_check'                     => optional($goalteam)->abv_check ?? 0,
          'abv_type'                      => optional($goalteam)->abv_type ?? 0,
          'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

          'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
          'acv_check'                     => optional($goalteam)->acv_check ?? 0,
          'acv_type'                      => optional($goalteam)->acv_type ?? 0,
          'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

          'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
          'avg_call_out_check'            => optional($goalteam)->avg_call_out_check ?? 0,
          'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
          'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

          'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
          'no_of_walk_check'              => optional($goalteam)->no_of_walk_check ?? 0,
          'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
          'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

          'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
          'no_of_followup_check'          => optional($goalteam)->no_of_followup_check ?? 0,
          'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
          'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

          'working_hours_over_all'        => optional($goalteam)->working_hours_over_all ?? 0,
          'working_hours_check'           => optional($goalteam)->working_hours_check ?? 0,
          'working_hours_type'            => optional($goalteam)->working_hours_type ?? 0,
          'working_hours_actual'          => $working_hoursActual ?? 0,

          'rework_over_all'   => optional($goalteam)->rework_over_all ?? 0,
          'rework_check'      => optional($goalteam)->rework_check ?? 0,
          'rework_type'       => optional($goalteam)->rework_type ?? 0,
          'rework_actual'     => $rework_countActual ?? 0,

        ];
      } else {

        // ##############################################################################################
        // ******************************** Pre Sales Department ****************************************
        // ##############################################################################################
        if ($departmentId == 1) {
          foreach ($staff as $member) {
            // Leads Count
            $allLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereNotIn('status', [2, 6])
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->where('internal_status', 0)
              ->count();
            $monthLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->whereNotIn('status', [2, 6])
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->where('internal_status', 0)
              ->count();
            $hotLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->whereNotIn('status', [2, 6])
              ->where('lead_status_id', 3)
              ->where('internal_status', 0)
              ->where('spam_verified', 0)
              ->where('drop_verified', 0)
              ->count();
            $customerConvertCount =  DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_payment', function ($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                  ->whereRaw('et_payment.transaction_date = (
                                  SELECT MIN(ep.transaction_date)
                                  FROM et_payment ep
                                  WHERE ep.customer_id = et_customer.sno
                              )');
              })
              ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
              ->where('et_customer.branch_id', $branch_id)
              ->where('et_lead.created_by', $member->sno)
              ->whereYear('et_payment.transaction_date', $year)
              ->whereMonth('et_payment.transaction_date', $month)
              ->where('et_transaction.payment_status', 1)
              ->count();

            $spamLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->where('spam_verified', 1)
              ->where('status', 7)
              ->count();

            $deadLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
              ->where('branch_id', $branch_id)
              ->whereYear('registered_date', $year)
              ->whereMonth('registered_date', $month)
              ->where('drop_verified', 1)
              ->where('status', 5)
              ->count();

            // Follow-ups & Walk-ins
            $monthFollowupCount = DB::table('et_appointment')
              ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
              ->whereIn('et_lead.status', [0, 4])
              ->where('et_appointment.created_by', $member->sno)
              ->whereYear('et_appointment.appointment_date', $year)
              ->whereMonth('et_appointment.appointment_date', $month)
              ->count();

            $monthwalkincount = DB::table('et_lead_appointment')
              ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
              ->where('et_lead_appointment.appointment_category', 3)
              ->where('et_lead_appointment.created_by', $member->sno)
              ->whereYear('et_lead_appointment.appointment_date', $year)
              ->whereMonth('et_lead_appointment.appointment_date', $month)
              ->count();

            // Call Out Count
            $monthcall_out = DB::table('et_call_tracker')
              ->whereYear('call_start_date', $year)
              ->whereMonth('call_start_date', $month)
              ->where('et_call_tracker.branch_id', $branch_id)
              ->where('et_call_tracker.branch_staff_id', $member->sno)
              ->where('call_status', 0)
              ->count();

            // Update Department Totals
            $totalDepartmentAllLead += $allLeadCount;
            $totalDepartmentMonthLead += $monthLeadCount;
            $totalDepartmentHotLead += $hotLeadCount;
            $totalDepartmentSpamLead += $spamLeadCount;
            $totalDepartmentDeadLead += $deadLeadCount;
            $totalDepartmentConvertCustomer += $customerConvertCount;
            $totalmonthFollowupCount += $monthFollowupCount;
            $totalmonthwalkincount += $monthwalkincount;
            $totalmonthcall_outcount += $monthcall_out;

            // Payments Calculation
            $totalPayment = 0;
            $totalPaidPayment = 0;

            if ($customerConvertCount > 0) {
              $currentMonthCustomer = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function ($join) {
                  $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereRaw('et_payment.transaction_date = (
                          SELECT MIN(ep.transaction_date)
                          FROM et_payment ep
                          WHERE ep.customer_id = et_customer.sno
                      )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by', $member->sno)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();



              $customerConvertCount = count($currentMonthCustomer);
            }

            $gst_percent = 18;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $base_amount_paid = 0; // keep track of GST-excluded total
            if ($customerConvertCount > 0) {
              if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                  $proposal_ids = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->whereNot('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();
                  // return $proposal_ids;

                  $proposals = DB::table('et_proposal')
                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereIn('et_proposal.sno', $proposal_ids)
                    ->get();

                  foreach ($proposals as $proposal) {
                    // Paid slots for this proposal
                    $paidAmount = DB::table('et_proposal_pay_slot')
                      ->where('proposal_sno', $proposal->sno)
                      ->where('status', 0)
                      ->sum('paidAmount');

                    $grantAmount = $proposal->grant_total_amount;

                    // First remove GST from paidAmount (base value in proposal's currency)
                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                    if ($proposal->currency_id == 70) {
                      // INR: add directly
                      $total_paid_payment += $paidAmount;
                      $total_payment += $grantAmount;
                      $base_amount_paid += $basePaidLocal;
                    } else {
                      // Non-INR: convert both amounts and base value
                      $helper = new \App\Helpers\Helpers();
                      $currency_code = $proposal->currency_code;
                      $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                      $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                      $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                    }
                  }
                }
              }
              // average 
              $totalDepartmentTotalPayment += $total_payment;
              $totalDepartmentPaidPayment += $base_amount_paid;
            }


            // Sales Exc *****************************************************
            $drop_ids = DB::table('et_drop_refund')
              ->where('et_drop_refund.bh_status', 1)
              ->where('et_drop_refund.branch_id', $branch_id);

            // $OutstandingPayment_count = 0;
            // $post_sale_count = 0;
            // $placement_count = 0;
            // $OutstandingPayment_count_total += $OutstandingPayment_count;
            // $post_sale_count_total += $post_sale_count;
            // $placement_count_total += $placement_count;


            // $working_hoursAmount = 0;
            // $working_hoursActual += $working_hoursAmount;
            // $total_basic_salary += $member->basic_salary ?? 0;
          }

          // Business and Collection Value Calculation
          $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

          $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

          // Conversion Rate
          $convertion_rate = $totalDepartmentMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

          $totalConvertRatio = number_format($convertion_rate, 2);


          $startDate = Carbon::create($year, $month, 1);
          $currentDate = Carbon::now();
          $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
          $dayCount = $startDate->diffInDays($endDate) + 1;
          $total_staff = count($staff) ?? 0;
          $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
          $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
          $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;


          // Prepare goal details response
          $goalteamDetails = [
            'department_name' => optional($department)->department_name ?? '',
            'department_id'   => optional($department)->sno ?? '',
            'team_id'         => optional($goalteam)->sno ?? '',
            'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
            'status'          => optional($goalteam)->status == 1 ? true : false,
            'month'           => $month_id,

            'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
            'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
            'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
            'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

            'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
            'cr_check'                      => optional($goalteam)->cr_check ?? 0,
            'cr_type'                       => optional($goalteam)->cr_type ?? 0,
            'cr_actual'                     => $totalConvertRatio ?? 'N/A',


            'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
            'abv_check'                     => optional($goalteam)->abv_check ?? 0,
            'abv_type'                      => optional($goalteam)->abv_type ?? 0,
            'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

            'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
            'acv_check'                     => optional($goalteam)->acv_check ?? 0,
            'acv_type'                      => optional($goalteam)->acv_type ?? 0,
            'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

            'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
            'avg_call_out_check'            => optional($goalteam)->avg_call_out_check ?? 0,
            'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
            'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

            'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
            'no_of_walk_check'              => optional($goalteam)->no_of_walk_check ?? 0,
            'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
            'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

            'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
            'no_of_followup_check'          => optional($goalteam)->no_of_followup_check ?? 0,
            'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
            'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,
          ];
        }

        // ##############################################################################################
        // ******************************** Post Sales Department **************************************
        // ##############################################################################################
        if ($departmentId == 15) {
          // return 'Post Sale Department';          
          $total_staff = $staff->count();
          $salesStaff = $staff;
          $totalAverageconvertRatio     = 0;
          $totalconvertRatio     = 0;
          $totalSpamLeadRatio     = 0;
          $totalDeadLeadRatio     = 0;
          $totalAllLead             = 0;
          $totalMonthLead            = 0;
          $totalHotLead        = 0;
          $totalSpamLead      = 0;
          $totalDeadLead    = 0;
          $totalAllPayment             = 0;
          $totalAllPaidPayment        = 0;
          $helper = new \App\Helpers\Helpers();
          foreach ($salesStaff as $staff) {
            $allpostSaleData = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
              ->where('et_customer.status', 0)
              ->where('et_customer.post_sale_check', 1)
              ->where('et_proposal.post_sale_check', 1)
              ->whereNotIn('et_proposal.proposal_status', [0, 2])
              ->where('et_customer.branch_id', $branch_id)
              ->where('et_proposal.created_by', $staff->sno)
              ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
              ->get();
            $allLeadCount = count($allpostSaleData);
            $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.branch_id', $branch_id)
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->whereNotIn('et_lead.status', [2, 6])
              ->where('et_lead.spam_verified', 0)
              ->where('et_lead.drop_verified', 0)
              ->where('et_lead.internal_status', 0)
              ->count();
            $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.branch_id', $branch_id)
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->whereNotIn('et_lead.status', [2, 6])
              ->where('et_lead.lead_status_id', 3)
              ->where('et_lead.internal_status', 0)
              ->where('et_lead.spam_verified', 0)
              ->where('et_lead.drop_verified', 0)
              ->count();
            $customerConvertData = DB::table('et_customer')
              ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
              ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
              ->join('et_payment', function ($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                  ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
              })
              ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
              ->where('et_customer.status', 0)
              ->where('et_customer.post_sale_check', 1)
              ->where('et_proposal.post_sale_check', 1)
              ->where('et_customer.branch_id', $branch_id)
              ->where('et_proposal.created_by', $staff->sno)
              ->whereYear('et_payment.transaction_date', $year)
              ->whereMonth('et_payment.transaction_date', $month)
              ->where('et_transaction.payment_status', 1)
              ->orderBy('et_customer.sno', 'asc')
              ->get();
            $customerConvertCount = count($customerConvertData);
            $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.spam_verified', 1)
              ->where('et_lead.branch_id', $branch_id)
              ->where('et_lead.status', 7)->count();
            $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
              ->whereYear('et_lead.registered_date', $year)
              ->whereMonth('et_lead.registered_date', $month)
              ->where('et_lead.created_by', $staff->sno)
              ->where('et_lead.drop_verified', 1)
              ->where('et_lead.branch_id', $branch_id)
              ->where('et_lead.status', 5)->count();
            // Spam Ratio 
            $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
            $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

            // Dead ratio
            $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
            $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

            // customer ratio
            $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
            $convertion_rate = number_format($convertion_rate, 2);

            //acr
            $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
            $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
            $total_payment             = 0;
            $total_paid_payment        = 0;

            $base_amount_paid = 0; // keep track of GST-excluded total

            $gst_percent = 18;


            if ($customerConvertCount > 0) {
              $currentMonthCustomer = $customerConvertData;
              if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                  $proposal_ids = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $customer->sno)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.post_sale_check', 1)
                    ->whereYear('et_proposal.estimate_date', $year)
                    ->whereMonth('et_proposal.estimate_date', $month)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->pluck('sno')
                    ->toArray();

                  $proposals = DB::table('et_proposal')
                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereIn('et_proposal.sno', $proposal_ids)
                    ->get();

                  foreach ($proposals as $proposal) {
                    // Paid slots for this proposal
                    $paidAmount = DB::table('et_proposal_pay_slot')
                      ->where('proposal_sno', $proposal->sno)
                      ->where('status', 0)
                      ->sum('paidAmount');

                    $grantAmount = $proposal->grant_total_amount;

                    // First remove GST from paidAmount (base value in proposal's currency)
                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                    if ($proposal->currency_id == 70) {
                      // INR: add directly
                      $total_paid_payment += $paidAmount;
                      $total_payment += $grantAmount;
                      $base_amount_paid += $basePaidLocal;
                    } else {
                      // Non-INR: convert both amounts and base value
                      $currency_code = $proposal->currency_code;
                      $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                      $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                      $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                    }
                  }
                }
              }

              $totalAllPayment += $total_payment;
              $totalAllPaidPayment += $base_amount_paid;
            }
            // total cal
            $totalAllLead             += $allLeadCount;
            $totalMonthLead            += $monthLeadCount;
            $totalHotLead        += $hotLeadCount;
            $totalDepartmentConvertCustomer            += $customerConvertCount;
            $totalSpamLead      += $spamLeadCount;
            $totalDeadLead    += $deadLeadCount;
          }
          // Calculate total ratio
          // Spam Ratio 
          $totalSpamLeadRatio = $totalMonthLead > 0 ? ($totalSpamLead / $totalMonthLead) * 100 : 0;
          $totalSpamLeadRatio = number_format($totalSpamLeadRatio, 2);
          // Dead ratio
          $totalDeadLeadRatio      = $totalMonthLead > 0 ? ($totalDeadLead / $totalMonthLead) * 100 : 0;
          $totalDeadLeadRatio      = number_format($totalDeadLeadRatio, 2);
          // Customer ratio
          $totalconvertRatio = $totalAllLead > 0 ? ($totalDepartmentConvertCustomer / $totalAllLead) * 100 : 0;
          $totalconvertRatio = number_format($totalconvertRatio, 2);
          //Acr
          $totalAverageconvertRatio = $totalMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalMonthLead) * 100 : 0;
          $totalAverageconvertRatio = number_format($totalAverageconvertRatio, 2);
          $totalDepartmentBusinessValue   = $totalDepartmentConvertCustomer > 0 ? $totalAllPayment / $totalDepartmentConvertCustomer : 0;
          $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? $totalAllPaidPayment / $totalDepartmentConvertCustomer : 0;
          // Conversion Rate
          $convertion_rate = $totalMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalMonthLead) * 100 : 0;
          $totalConvertRatio = number_format($convertion_rate, 2);
          // Prepare goal details response
          $goalteamDetails = [
            'department_name' => optional($department)->department_name ?? '',
            'department_id'   => optional($department)->sno ?? '',
            'team_id'         => optional($goalteam)->sno ?? '',
            'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
            'status'          => optional($goalteam)->status == 1 ? true : false,
            'month'           => $month_id,

            'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
            'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
            'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
            'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

            'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
            'cr_check'                      => optional($goalteam)->cr_check ?? 0,
            'cr_type'                       => optional($goalteam)->cr_type ?? 0,
            'cr_actual'                     => $totalConvertRatio ?? 'N/A',


            'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
            'abv_check'                     => optional($goalteam)->abv_check ?? 0,
            'abv_type'                      => optional($goalteam)->abv_type ?? 0,
            'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

            'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
            'acv_check'                     => optional($goalteam)->acv_check ?? 0,
            'acv_type'                      => optional($goalteam)->acv_type ?? 0,
            'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

          ];
        }
        // ##############################################################################################
        // ******************************** Production Department ***************************************
        // ##############################################################################################
        if ($departmentId == 2) {
          $salesStaff = $staff;
          $helper = new \App\Helpers\Helpers();
          foreach ($salesStaff as $member) {


            $working_hour = DB::table('et_task_log')
              ->where('et_task_log.branch_id', $branch_id)
              ->whereYear('et_task_log.end_time', $year)
              ->whereMonth('et_task_log.end_time', $month)
              ->where('et_task_log.status', 1)
              ->where('et_task_log.staff_id', $member->sno)
              ->sum(DB::raw('TIME_TO_SEC(duration)'));

            $working_hoursActual += $working_hour / 3600;

            $rework_count = DB::table('et_daily_tasks')
              ->whereYear('et_daily_tasks.task_date', $year)
              ->whereMonth('et_daily_tasks.task_date', $month)
              ->where('et_daily_tasks.rework_check', 1)
              ->where('et_daily_tasks.staff_id', $member->sno)
              ->count();

            $rework_countActual += $rework_count;
          }
          // Prepare goal details response
          $goalteamDetails = [
            'department_name' => optional($department)->department_name ?? '',
            'department_id'   => optional($department)->sno ?? '',
            'team_id'         => optional($goalteam)->sno ?? '',
            'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
            'status'          => optional($goalteam)->status == 1 ? true : false,
            'month'           => $month_id,



            'working_hours_over_all'        => optional($goalteam)->working_hours_over_all ?? 0,
            'working_hours_check'           => optional($goalteam)->working_hours_check ?? 0,
            'working_hours_type'            => optional($goalteam)->working_hours_type ?? 0,
            'working_hours_actual'          => $working_hoursActual ?? 0,

            'rework_over_all'   => optional($goalteam)->rework_over_all ?? 0,
            'rework_check'      => optional($goalteam)->rework_check ?? 0,
            'rework_type'       => optional($goalteam)->rework_type ?? 0,
            'rework_actual'     => $rework_countActual ?? 0,

          ];
        }

        // ##############################################################################################
        // ******************************** Journal Department ***************************************
        // ##############################################################################################
        if ($departmentId == 14) {
          $salesStaff = $staff;
          $no_of_papers_countActual = 0;
          $helper = new \App\Helpers\Helpers();
          foreach ($salesStaff as $member) {
            if (in_array($member->role_id, [33, 36])) {
              $field = $member->role_id == 33 ? 'jc_id' : 'jc_staff';

              $pub_count = DB::table('et_customer_services')
                ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->whereYear('et_manage_journal.published_at', $year)
                ->whereMonth('et_manage_journal.published_at', $month)
                ->where('et_manage_journal.status', 6)
                ->where("et_customer_services.{$field}", $member->sno)
                ->count();

              $acp_count = DB::table('et_customer_services')
                ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                ->whereYear('et_manage_journal.accepted_at', $year)
                ->whereMonth('et_manage_journal.accepted_at', $month)
                ->where('et_manage_journal.status', 4)
                ->where("et_customer_services.{$field}", $member->sno)
                ->count();

              $no_of_papers_countActual += $pub_count + $acp_count;
            }
          }

          // Prepare goal details response
          $goalteamDetails = [
            'department_name' => optional($department)->department_name ?? '',
            'department_id'   => optional($department)->sno ?? '',
            'team_id'         => optional($goalteam)->sno ?? '',
            'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),
            'status'          => optional($goalteam)->status == 1 ? true : false,
            'month'           => $month_id,

            'no_of_papers_over_all'   => optional($goalteam)->no_of_papers_over_all ?? 0,
            'no_of_papers_check'      => optional($goalteam)->no_of_papers_check ?? 0,
            'no_of_papers_type'       => optional($goalteam)->no_of_papers_type ?? 0,
            'no_of_papers_actual'     => $no_of_papers_countActual ?? 0,

          ];
        }
      }
    }



    return response()->json([
      'status' => 200,
      'data'   => $goalteamDetails
    ]);
  }

  public function saveTeamGoal(Request $request)
  {
    // Validate incoming data
    $validatedData = $request->validate([
      'department_id' => 'required|numeric',
      'month_id'      => 'required',
      'year_id'      => 'required',
      'branch_id'      => 'required',
      'conversion_over_all' => 'nullable|numeric',
      'conversion_check' => 'nullable|numeric',
      'conversion_type' => 'nullable|numeric',
      'cr_over_all'   => 'nullable|numeric',
      'cr_check'      => 'nullable|numeric',
      'cr_type'       => 'nullable|numeric',
      'abv_over_all'  => 'nullable|numeric',
      'abv_check'     => 'nullable|numeric',
      'abv_type'      => 'nullable|numeric',
      'acv_over_all'  => 'nullable|numeric',
      'acv_type'      => 'nullable|numeric',
      'acv_check'     => 'nullable|numeric',
      'avg_call_out_over_all'   => 'nullable|numeric',
      'avg_call_out_check'      => 'nullable|numeric',
      'avg_call_out_type'       => 'nullable|numeric',
      'no_of_walk_over_all'     => 'nullable|numeric',
      'no_of_walk_check'        => 'nullable|numeric',
      'no_of_walk_type'         => 'nullable|numeric',
      'no_of_followup_over_all' => 'nullable|numeric',
      'no_of_followup_check'    => 'nullable|numeric',
      'no_of_followup_type'     => 'nullable|numeric',
      'working_hours_over_all'            => 'nullable|numeric',
      'working_hours_check'               => 'nullable|numeric',
      'working_hours_type'                => 'nullable|numeric',
      'no_of_post_sale_over_all' => 'nullable|numeric',
      'no_of_post_sale_check'    => 'nullable|numeric',
      'no_of_post_sale_type'     => 'nullable|numeric',
      'no_of_outstanding_over_all' => 'nullable|numeric',
      'no_of_outstanding_check'    => 'nullable|numeric',
      'no_of_outstanding_type'     => 'nullable|numeric',
      'min_no_of_students_over_all' => 'nullable|numeric',
      'min_no_of_students_check'    => 'nullable|numeric',
      'min_no_of_students_type'     => 'nullable|numeric',
      'rework_over_all' => 'nullable|numeric',
      'rework_check'    => 'nullable|numeric',
      'rework_type'     => 'nullable|numeric',
      'productions_over_all'  => 'nullable|numeric',
      'productions_check'     => 'nullable|numeric',
      'productions_type'      => 'nullable|numeric',
      'no_of_reviews_over_all' => 'nullable|numeric',
      'no_of_reviews_check'   => 'nullable|numeric',
      'no_of_reviews_type'    => 'nullable|numeric',
      'given_links_over_all'  => 'nullable|numeric',
      'given_links_check'     => 'nullable|numeric',
      'given_links_type'      => 'nullable|numeric',
      'no_of_placements_over_all' => 'nullable|numeric',
      'no_of_placements_check'  => 'nullable|numeric',
      'no_of_placements_type'  => 'nullable|numeric',
      'mou_over_all'          => 'nullable|numeric',
      'mou_check'             => 'nullable|numeric',
      'mou_type'              => 'nullable|numeric',
      'reference_sales_over_all' => 'nullable|numeric',
      'reference_sales_check'    => 'nullable|numeric',
      'reference_sales_type'     => 'nullable|numeric',
    ]);

    $branchId = $validatedData['branch_id'];
    $departmentId = $validatedData['department_id'];
    $month_id = $validatedData['month_id'];
    $year_id = $validatedData['year_id'];
    $createdBy = $request->user()->user_id;
    return $year_id;
    // Convert month_id if it's a string
    if (!is_numeric($month_id)) {
      $month_id = date('m', strtotime($month_id . ' 1'));
    }

    // Update or create the goal record
    $goal = GoalSetTeamModel::updateOrCreate(
      [
        'team_goal_month' => (int)$month_id,
        'team_goal_year'  => (int)$year_id,
        'branch_id'       => $branchId,
        'department_id'   => $departmentId,
      ],
      array_merge($validatedData, [
        'created_by' => $createdBy,
        'updated_by' => $createdBy,
        'status'     => 1 // Mark as 'Goal Set'
      ])
    );

    return response()->json([
      'status'  => 200,
      'message' => 'Team goal successfully updated!',
      'data'    => $goal
    ]);
  }





  public function addOrUpdateStaffGoal(Request $request)
  {
    // Convert month name to numeric format
    $monthName = $request->input('month_id');
    $monthNumber = date('m', strtotime($monthName . ' 1')); // Converts "February" to "02"

    // Replace month_id in the request before validation
    $request->merge(['month_id' => (int)$monthNumber]);
    $validatedData = $request->validate([
      'team_id' => 'required|integer',
      'month_id' => 'required|integer',
      'year' => 'required|integer',
      'department_id' => 'required|integer',
      'staff_goals' => 'required|array',
      'staff_goals.*.staff_id' => 'required|integer',
      'staff_goals.*.conversion' => 'nullable|integer',
      'staff_goals.*.cr' => 'nullable|integer',
      'staff_goals.*.abv' => 'nullable|integer',
      'staff_goals.*.acv' => 'nullable|integer',
      'staff_goals.*.avg_call_out' => 'nullable|integer',
      'staff_goals.*.no_of_walk' => 'nullable|integer',
      'staff_goals.*.no_of_followup' => 'nullable|integer',
      'staff_goals.*.working_hours' => 'nullable|integer',
      'staff_goals.*.no_of_post_sale' => 'nullable|integer',
      'staff_goals.*.no_of_outstanding' => 'nullable|integer',
      'staff_goals.*.rework' => 'nullable|integer',
      'staff_goals.*.min_no_of_students' => 'nullable|integer',
      'staff_goals.*.productions' => 'nullable|integer',
      'staff_goals.*.no_of_reviews' => 'nullable|integer',
      'staff_goals.*.no_of_placements' => 'nullable|integer',
      'staff_goals.*.mou' => 'nullable|integer',
      'staff_goals.*.reference_sales' => 'nullable|integer',
    ]);

    $branchId = $request->user()->branch_id;
    $departmentId = $validatedData['department_id'];
    $month = $validatedData['month_id'];
    $year = $validatedData['year'];
    $team_id = $validatedData['team_id'];
    $createdBy = $request->user()->user_id;
    // return $request->all();
    $branch_check = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first();

    $branch_code = $branch_check->city_short_code;


    foreach ($validatedData['staff_goals'] as $goalData) {
      GoalSetStaffModel::updateOrCreate(
        [
          'goal_month' => $month,
          'goal_date' => "{$year}-{$month}-01", // Proper date format
          'branch_id' => $branchId,
          'department_id' => $departmentId,
          'staff_id' => $goalData['staff_id'],
        ],
        [
          'team_id' => $team_id,
          'conversion' => $goalData['conversion'] ?? 0,
          'CR' => $goalData['cr'] ?? 0,
          'ABV' => $goalData['abv'] ?? 0,
          'ACV' => $goalData['acv'] ?? 0,
          'avg_call_out' => $goalData['avg_call_out'] ?? 0,
          'no_of_walk' => $goalData['no_of_walk'] ?? 0,
          'no_of_followup' => $goalData['no_of_followup'] ?? 0,
          'working_hours' => $goalData['working_hours'] ?? 0,
          'no_of_post_sale' => $goalData['no_of_post_sale'] ?? 0,
          'no_of_outstanding' => $goalData['no_of_outstanding'] ?? 0,
          'rework' => $goalData['rework'] ?? 0,
          'min_no_of_students' => $goalData['min_no_of_students'] ?? 0,
          'productions' => $goalData['productions'] ?? 0,
          'no_of_reviews' => $goalData['no_of_reviews'] ?? 0,
          'no_of_placements' => $goalData['no_of_placements'] ?? 0,
          'mou' => $goalData['mou'] ?? 0,
          'reference_sales' => $goalData['reference_sales'] ?? 0,
          'created_by' => $createdBy,
          'updated_by' => $createdBy,
          'status' => 1, // Default status
        ]
      );
    }


    return response()->json([
      'status' => 200,
      'message' => 'Goals updated successfully'
    ]);
  }
}
