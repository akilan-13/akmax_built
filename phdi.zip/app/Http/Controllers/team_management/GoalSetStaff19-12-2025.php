<?php

namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\PaymentModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\TrainingModel;
use App\Models\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;

class GoalSetStaff extends Controller
{


  public function index()
  {

    return view('content.team_management.goal_set');
  }
  // Fetch Departments based on Branch
  public function getDepartmentsGoal(Request $request)
  {

    $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
    return response()->json(['status' => 200, 'data' => $departments]);
  }

  public function getTeamGoal(Request $request)
  {
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id;
    $month = date('n', strtotime($month_id)); // Returns 3
    $year = $request->year;
    $branch_id = $request->user()->branch_id;


    // Convert month name to number if necessary
    if (!empty($request->month_id)) {
      if (!is_numeric($request->month_id)) {
        $monthNumber = date('m', strtotime($request->month_id . ' 1'));
        $request->month_id = (int) $monthNumber;
      } else {
        $request->month_id = (int) $request->month_id;
      }
    }
    // Fetch the department details
    $department = DepartmentModel::where('status', 0)->where('sno', $departmentId)->first(['sno', 'department_name']);

    // Get goal records for the selected department and month
    $goalteam = GoalSetTeamModel::where('department_id', $departmentId)
      ->where('branch_id', $branchId)
      ->where('team_goal_month', $request->month_id)
      ->first();

    $staff = StaffModel::where('et_staff.branch_id', $branch_id)
      ->where('et_staff.department_id', $departmentId)
      ->where('et_staff.status', 0)
      ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
      ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.nick_name',
        'et_staff.gender',
        'et_staff.staff_image',
        'et_staff.basic_salary',
        'et_department.department_name',
        'et_user_role.role_name'
      ]);

    // Initialize Totals
    $totalDepartmentAllLead = 0;
    $totalDepartmentMonthLead = 0;
    $totalDepartmentHotLead = 0;
    $totalDepartmentSpamLead = 0;
    $totalDepartmentDeadLead = 0;
    $totalDepartmentConvertCustomer = 0;
    $totalDepartmentBusinessValue = 0;
    $totalDepartmentCollectionValue = 0;
    $totalDepartmentPaidPayment = 0;
    $totalDepartmentTotalPayment = 0;
    $totalmonthFollowupCount = 0;
    $totalmonthwalkincount = 0;
    $totalmonthcall_outcount = 0;

    $totalcosting_amount = 0;
    $totalrefferal_count = 0;
    $totalreview_count   = 0;
    $OutstandingPayment_count_total   = 0;
    $post_sale_count_total   = 0;
    $working_hoursAmount_total   = 0;
    $placement_count_total   = 0;
    $std_count_total   = 0;
    $total_basic_salary   = 0;
    $totalmou_count   = 0;

    foreach ($staff as $member) {

      // Leads Count
      $allLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
        ->where('branch_id', $branch_id)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('internal_status', 0)
        ->count();

      $monthLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->whereNotIn('status', [2, 6])
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->where('internal_status', 0)
        ->count();

      $hotLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->whereNotIn('status', [2, 6])
        ->where('lead_status_id', 3)
        ->where('internal_status', 0)
        ->where('spam_verified', 0)
        ->where('drop_verified', 0)
        ->count();

    //   $customerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //     ->where('et_customer.branch_id', $branch_id)
    //     ->whereIn('et_customer.status',[0,6])
    //     ->where('et_lead.created_by', $member->sno)
    //     ->whereYear('et_customer.created_at', $year)
    //     ->whereMonth('et_customer.created_at', $month)
    //     ->count();
        
        $customerConvertCount =  DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    // ->where('et_customer.status', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_lead.created_by', $member->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    //  ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    // ->orderBy('et_customer.sno', 'asc')
                    ->count();
                    
      $spamLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('spam_verified', 1)
        ->where('status', 7)
        ->count();

      $deadLeadCount = DB::table('et_lead')->where('created_by', $member->sno)
        ->where('branch_id', $branch_id)
        ->whereYear('registered_date', $year)
        ->whereMonth('registered_date', $month)
        ->where('drop_verified', 1)
        ->where('status', 5)
        ->count();

      // Follow-ups & Walk-ins
      $monthFollowupCount = DB::table('et_appointment')
        ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
        ->whereIn('et_lead.status', [0, 4])
        ->where('et_appointment.created_by', $member->sno)
        ->whereYear('et_appointment.appointment_date', $year)
        ->whereMonth('et_appointment.appointment_date', $month)
        ->count();

      $monthwalkincount = DB::table('et_lead_appointment')
        ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
        ->where('et_lead_appointment.appointment_category', 'walk-in')
        ->where('et_lead_appointment.created_by', $member->sno)
        ->whereYear('et_lead_appointment.appointment_date', $year)
        ->whereMonth('et_lead_appointment.appointment_date', $month)
        ->count();

      // Call Out Count
      $monthcall_out = DB::table('et_call_tracker')
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->where('et_call_tracker.branch_id', $branch_id)
        ->where('et_call_tracker.branch_staff_id', $member->sno)
        ->where('call_status', 0)
        ->count();

      // Update Department Totals
      $totalDepartmentAllLead += $allLeadCount;
      $totalDepartmentMonthLead += $monthLeadCount;
      $totalDepartmentHotLead += $hotLeadCount;
      $totalDepartmentSpamLead += $spamLeadCount;
      $totalDepartmentDeadLead += $deadLeadCount;
      $totalDepartmentConvertCustomer += $customerConvertCount;
      $totalmonthFollowupCount += $monthFollowupCount;
      $totalmonthwalkincount += $monthwalkincount;
      $totalmonthcall_outcount += $monthcall_out;

      // Payments Calculation
      $totalPayment = 0;
      $totalPaidPayment = 0;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $member->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

            
            
            $customerConvertCount =count($currentMonthCustomer);
      }
      
      $gst_percent = 18;
      $currentMonthCustomerCount = 0;
            $total_business_amount     = 0;
            $total_payment             = 0;
            $total_paid_payment        = 0;
            $averageBusinessValue      = 0;
            $averageCollectionValue    = 0;
            
            $base_amount_paid = 0; // keep track of GST-excluded total
      if ($customerConvertCount > 0) {
        if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                    $proposal_ids = DB::table('et_proposal')
                        ->where('et_proposal.customer_id', $customer->sno)
                        ->where('et_proposal.status', 0)
                        ->whereNot('et_proposal.post_sale_check', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->pluck('sno')
                        ->toArray();
                        // return $proposal_ids;
            
                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposal_ids)
                        ->get();
            
                    foreach ($proposals as $proposal) {
                        // Paid slots for this proposal
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');
            
                        $grantAmount = $proposal->grant_total_amount;
            
                        // First remove GST from paidAmount (base value in proposal's currency)
                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
            
                        if ($proposal->currency_id == 70) {
                            // INR: add directly
                            $total_paid_payment += $paidAmount;
                            $total_payment += $grantAmount;
                            $base_amount_paid += $basePaidLocal;
                        } else {
                            // Non-INR: convert both amounts and base value
                            $helper = new \App\Helpers\Helpers();
                            $currency_code = $proposal->currency_code;
                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                        }
                    }
                }
            }
        
        
        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
        $totalDepartmentTotalPayment +=$total_payment;
        $totalDepartmentPaidPayment +=$base_amount_paid;
    }

      // Update Total Department Payments
    //   $totalDepartmentTotalPayment += $total_payment;
    //   $totalDepartmentPaidPayment += $base_amount_paid;


      // Production Goal***********************************************

      $current_date = date('Y-m-d'); // Define the current date
      $std_count = 0;

      $std_count_total = $std_count;

      $staffproduction = StaffModel::select(
        'et_staff.sno',
        'et_staff.staff_id',
        'et_staff.staff_name',
        'et_staff.gender',
        'et_staff.dob',
        'et_staff.mobile_no',
        'et_staff.email_id',
        'et_staff.staff_image',
        'et_staff.nick_name',
        'et_staff.knowledge_tag',
        'et_staff.per_hour_cost',
        'et_job_position.job_position_name',
        'et_staff.avaiable_points',
        'et_staff.basic_salary',
        'et_staff.status AS staff_status'
      )
        ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
        ->where([
          ['et_staff.status', 0],
          ['et_staff.branch_id', $branch_id],
          ['et_staff.sno', $member->sno]
        ])
        ->orderByDesc('et_staff.sno')
        ->first();

      // Initialize variables
      $total_batch = $total_student = $total_free_batch = $total_staff = 0;
      $overall_earned = $overall_earned_per = $success_staff_count = 0;
      $slotType = $staffproduction;

      $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
      $slotType->present_count = $slotType->course_count = 0;
      $slotType->slotDetails = [];
      $slotType->avg_amnt = $slotType->salary = 0;

      // Fetch batch IDs associated with staff
      $batchIds = ["0"];

      $slotType->batch_ids = (array) $batchIds; // Ensure it's an arra

      // Student count
      $slotType->student_count = 0;

      // Course count
      $slotType->course_count = 0;

      // Batch count
      $slotType->batch_count = 0;

      // Salary calculation
      $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
      // Average earned percentage calculation
      $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
      // Calculate free batch count
      $total_free_batch = max(0, 8 - $slotType->batch_count);
      $overall_earned += $slotType->earned_amount;
      $overall_earned_per += $slotType->avg_amnt;
      // Count success staff
      if ($slotType->salary < $slotType->earned_amount) {
        $success_staff_count++;
      }
      $staffproduction = $slotType;



      $totalcosting_amount += $staffproduction->earned_amount ?? 0;

      $refferal_count = DB::table('et_referral_persons')
        ->where('branch_id', $branch_id)
        ->where('referral_id', $member->sno)
        ->where('status', 0)
        ->where('referral_type', 2)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      $totalrefferal_count += $refferal_count ?? 0;

      $review_count = 0;

      $totalreview_count += $review_count ?? 0;

      $mou_count = 0;

      $totalmou_count += $mou_count ?? 0;




      // Sales Exc *****************************************************
      $drop_ids = DB::table('et_drop_refund')
        ->where('et_drop_refund.bh_status', 1)
        ->where('et_drop_refund.branch_id', $branch_id);

      $OutstandingPayment_count = 0;

      $post_sale_count = 0;

      $placement_count = 0;




      $OutstandingPayment_count_total += $OutstandingPayment_count;
      $post_sale_count_total += $post_sale_count;
      $placement_count_total += $placement_count;

      $working_hoursAmount = 0;

      $working_hoursAmount_total += $working_hoursAmount;
      $total_basic_salary += $member->basic_salary ?? 0;
      // Sales Exc ****************************************************

    }

    // Business and Collection Value Calculation
    $totalDepartmentBusinessValue  = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentTotalPayment / $totalDepartmentConvertCustomer, 2) : 0;

    $totalDepartmentCollectionValue = $totalDepartmentConvertCustomer > 0 ? round($totalDepartmentPaidPayment / $totalDepartmentConvertCustomer, 2) : 0;

    // Conversion Rate
    $convertion_rate = $totalDepartmentMonthLead > 0 ? ($totalDepartmentConvertCustomer / $totalDepartmentMonthLead) * 100 : 0;

    $totalConvertRatio = number_format($convertion_rate, 2);


    $startDate = Carbon::create($year, $month, 1);
    $currentDate = Carbon::now();
    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
    $dayCount = $startDate->diffInDays($endDate) + 1;
    $total_staff = count($staff) ?? 0;
    $total_outgoing_call_ratio = $dayCount > 0 && $total_staff > 0 ? round($totalmonthcall_outcount / ($total_staff * $dayCount)) : 0;
    $totalmonthwalkincount     = $dayCount > 0 && $total_staff > 0 ? round($totalmonthwalkincount / ($total_staff * $dayCount)) : 0;
    $totalmonthFollowupCount   = $dayCount > 0 && $total_staff > 0 ? round($totalmonthFollowupCount / ($total_staff * $dayCount)) : 0;


    $basic_pay = $total_basic_salary ?? 0;
    $total_basic_pay_pro  = $total_basic_salary * 10;
    $costing_amount_asign = optional($goalteam)->rework_over_all ?? 0;
    // $totalcosting_amount  = $basic_pay > 0  ? round(($totalcosting_amount /  $basic_pay) *  $costing_amount_asign) : 0;
    $totalcosting_amount  = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $costing_amount_asign : 0;


    if (isset($goalteam->goal_completed)) {
      if ($goalteam->goal_completed == 1) {
        $totalDepartmentConvertCustomer =  $goalteam->conversion_actual;
        $totalConvertRatio =  $goalteam->cr_actual;
        $totalDepartmentBusinessValue =  $goalteam->abv_actual;
        $totalDepartmentCollectionValue =  $goalteam->acv_actual;
        $totalmonthcall_outcount =  $goalteam->avg_call_out_actual;
        $totalmonthwalkincount =  $goalteam->no_of_walk_actual;
        $totalmonthFollowupCount =  $goalteam->no_of_followup_actual;
        $working_hoursAmount_total =  $goalteam->working_hours_actual;
        $post_sale_count_total =  $goalteam->no_of_post_sale_actual;
        $OutstandingPayment_count =  $goalteam->no_of_outstanding_actual;
        $std_count_total =  $goalteam->min_no_of_students_actual;
        $totalcosting_amount =  $goalteam->rework_actual;
        $totalreview_count =  $goalteam->no_of_reviews_actual;
        $placement_count_total =  $goalteam->no_of_placements_actual;
        $totalmou_count =  $goalteam->mou_actual;
        $totalcosting_amount =  $goalteam->productions_actual;
        $totalrefferal_count =  $goalteam->reference_sales_actual;
      }
    }



    // Prepare goal details response
    $goalteamDetails = [
      'department_name' => optional($department)->department_name ?? '',
      'department_id'   => optional($department)->sno ?? '',
      'team_id'         => optional($goalteam)->sno ?? '',
      'ten_x'           => json_decode(optional($goalteam)->ten_x ?? '{}', true),

      'conversion_over_all'           => optional($goalteam)->conversion_over_all ?? 0,
      'conversion_check'              => optional($goalteam)->conversion_check ?? 0,
      'conversion_type'               => optional($goalteam)->conversion_type ?? 0,
      'conversion_actual'             => $totalDepartmentConvertCustomer ?? 0,

      'cr_over_all'                   => optional($goalteam)->cr_over_all ?? 0,
      'cr_check'                      => optional($goalteam)->cr_check ?? 0,
      'cr_type'                       => optional($goalteam)->cr_type ?? 0,
      'cr_actual'                     => $totalConvertRatio ?? 'N/A',


      'abv_over_all'                  => optional($goalteam)->abv_over_all ?? 0,
      'abv_check'                     => optional($goalteam)->abv_check ?? 0,
      'abv_type'                      => optional($goalteam)->abv_type ?? 0,
      'abv_actual'                    => $totalDepartmentBusinessValue ?? 0,

      'acv_over_all'                  => optional($goalteam)->acv_over_all ?? 0,
      'acv_check'                     => optional($goalteam)->acv_check ?? 0,
      'acv_type'                      => optional($goalteam)->acv_type ?? 0,
      'acv_actual'                    => $totalDepartmentCollectionValue ?? 0,

      'avg_call_out_over_all'         => optional($goalteam)->avg_call_out_over_all ?? 0,
      'avg_call_out_check'            => optional($goalteam)->avg_call_out_check ?? 0,
      'avg_call_out_type'             => optional($goalteam)->avg_call_out_type ?? 0,
      'avg_call_out_actual'           => $total_outgoing_call_ratio ?? 0,

      'no_of_walk_over_all'           => optional($goalteam)->no_of_walk_over_all ?? 0,
      'no_of_walk_check'              => optional($goalteam)->no_of_walk_check ?? 0,
      'no_of_walk_type'               => optional($goalteam)->no_of_walk_type ?? 0,
      'no_of_walk_actual'             => $totalmonthwalkincount ?? 0,

      'no_of_followup_over_all'       => optional($goalteam)->no_of_followup_over_all ?? 0,
      'no_of_followup_check'          => optional($goalteam)->no_of_followup_check ?? 0,
      'no_of_followup_type'           => optional($goalteam)->no_of_followup_type ?? 0,
      'no_of_followup_actual'         => $totalmonthFollowupCount ?? 0,

      'working_hours_over_all'                  => optional($goalteam)->working_hours_over_all ?? 0,
      'working_hours_check'                     => optional($goalteam)->working_hours_check ?? 0,
      'working_hours_type'                      => optional($goalteam)->working_hours_type ?? 0,
      'working_hours_actual'                    => $working_hoursAmount_total ?? 0,

      'no_of_post_sale_over_all'      => optional($goalteam)->no_of_post_sale_over_all ?? 0,
      'no_of_post_sale_check'         => optional($goalteam)->no_of_post_sale_check ?? 0,
      'no_of_post_sale_type'          => optional($goalteam)->no_of_post_sale_type ?? 0,
      'no_of_post_sale_actual'        => $post_sale_count_total ?? 0,

      'no_of_outstanding_over_all'    => optional($goalteam)->no_of_outstanding_over_all ?? 0,
      'no_of_outstanding_check'       => optional($goalteam)->no_of_outstanding_check ?? 0,
      'no_of_outstanding_type'        => optional($goalteam)->no_of_outstanding_type ?? 0,
      'no_of_outstanding_actual'      => $OutstandingPayment_count ?? 0,

      'min_no_of_students_over_all'   => optional($goalteam)->min_no_of_students_over_all ?? 0,
      'min_no_of_students_check'      => optional($goalteam)->min_no_of_students_check ?? 0,
      'min_no_of_students_type'       => optional($goalteam)->min_no_of_students_type ?? 0,
      'min_no_of_students_actual'     => $std_count_total ?? 0,

      'rework_over_all'   => optional($goalteam)->rework_over_all ?? 0,
      'rework_check'      => optional($goalteam)->rework_check ?? 0,
      'rework_type'       => optional($goalteam)->rework_type ?? 0,
      'rework_actual'     => $totalcosting_amount ?? 0,

      'productions_over_all'          => optional($goalteam)->productions_over_all ?? 0,
      'productions_check'             => optional($goalteam)->productions_check ?? 0,
      'productions_type'              => optional($goalteam)->productions_type ?? 0,
      'productions_actual'            => $totalcosting_amount ?? 0,

      'no_of_reviews_over_all'        => optional($goalteam)->no_of_reviews_over_all ?? 0,
      'no_of_reviews_check'           => optional($goalteam)->no_of_reviews_check ?? 0,
      'no_of_reviews_type'            => optional($goalteam)->no_of_reviews_type ?? 0,
      'no_of_reviews_actual'          => $totalreview_count ?? 0,

      'no_of_placements_over_all'     => optional($goalteam)->no_of_placements_over_all ?? 0,
      'no_of_placements_check'        => optional($goalteam)->no_of_placements_check ?? 0,
      'no_of_placements_type'         => optional($goalteam)->no_of_placements_type ?? 0,
      'no_of_placements_actual'       => $placement_count_total ?? 0,

      'mou_over_all'                  => optional($goalteam)->mou_over_all ?? 0,
      'mou_check'                     => optional($goalteam)->mou_check ?? 0,
      'mou_type'                      => optional($goalteam)->mou_type ?? 0,
      'mou_actual'                    => $totalmou_count ?? 0,

      'reference_sales_over_all'      => optional($goalteam)->reference_sales_over_all ?? 0,
      'reference_sales_check'         => optional($goalteam)->reference_sales_check ?? 0,
      'reference_sales_type'          => optional($goalteam)->reference_sales_type ?? 0,
      'reference_sales_actual'        => $totalrefferal_count ?? 0,

      'status' => optional($goalteam)->status == 1 ? true : false,
      'month'  => $month_id
    ];

    return response()->json([
      'status' => 200,
      'data'   => $goalteamDetails
    ]);
  }

  public function getStaffGoal(Request $request)
  {
    $branchId = $request->user()->branch_id;
    $departmentId = $request->department_id;
    $month_id = $request->month_id; // "March"
    $month = date('n', strtotime($month_id)); // Returns 3
    $year = $request->year;
    $branch_id = $request->user()->branch_id;
    $helper             = new \App\Helpers\Helpers();


    if (!empty($month_id)) {
      if (!is_numeric($month_id)) {
        // Convert month name (e.g., "February") to its numeric value
        $monthNumber = date('m', strtotime($month_id . ' 1'));
        $request->merge(['month_id' => (int)$monthNumber]);
      } else {
        // Ensure month_id is an integer if it's already numeric
        $request->merge(['month_id' => (int)$month_id]);
      }
    }


    //  return $request->all();
    // return $request->month_id;
    // Get staff members with department and role details
    $staff = StaffModel::where('et_staff.branch_id', $branchId)
      ->where('et_staff.department_id', $departmentId)
      ->where('et_staff.status', 0)
      ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
      ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
      ->orderBy('staff_name', 'ASC')
      ->get([
        'et_staff.sno',
        'et_staff.staff_name',
        'et_staff.nick_name',
        'et_staff.gender',
        'et_staff.avaiable_points',
        'et_staff.staff_image',
        'et_staff.basic_salary',
        'et_department.department_name',
        'et_user_role.role_name'
      ]);
    $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $departmentId)->where('et_goal_set_team.branch_id', $branchId)
      ->where('et_goal_set_team.team_goal_month', $request->month_id)
      ->where('et_goal_set_team.team_goal_year', $year)
      ->first();
    // Get goal records for the selected department and month
    $goalsetRecords = GoalSetStaffModel::where('et_goal_set_staff.department_id', $departmentId)->where('et_goal_set_staff.branch_id', $branchId)
      ->where('et_goal_set_staff.goal_month', $request->month_id)
      ->whereMonth('et_goal_set_staff.goal_date', $request->month_id)
      ->whereYear('et_goal_set_staff.goal_date', $year)
      ->get();
    // return $goalsetRecords;
    // Convert goalsetRecords to an associative array for easy lookup
    $goalsetData = [];
    foreach ($goalsetRecords as $goal) {
      $goalsetData[$goal->staff_id] = $goal;
    }

    $helper = new \App\Helpers\Helpers();


    $totalAverageBusinessValue = 0;
    $totalAverageCollectionValue     = 0;
    $totalAverageconvertRatio     = 0;
    $totalconvertRatio     = 0;
    $totalSpamLeadRatio     = 0;
    $totalDeadLeadRatio     = 0;
    $totalAllLead             = 0;
    $totalMonthLead            = 0;
    $totalconvertCustomer            = 0;
    $totalHotLead        = 0;
    $totalSpamLead      = 0;
    $totalDeadLead    = 0;

    $totalAllPayment             = 0;
    $totalAllPaidPayment        = 0;
    $total_basic_pay_pro = 0;


    // Attach goal details to staff members
    $staffDetails = [];
    foreach ($staff as $member) {

      $current_date = date('Y-m-d'); // Define the current date
      $std_count = 0;

      //Sales Team 

      $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.branch_id', $branch_id)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->count();

      $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.branch_id', $branch_id)
        ->whereYear('et_lead.registered_date', $year)
        ->whereMonth('et_lead.registered_date', $month)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->where('et_lead.internal_status', 0)
        ->count();

      $hotLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.branch_id', $branch_id)
        ->whereYear('et_lead.registered_date', $year)
        ->whereMonth('et_lead.registered_date', $month)
        ->whereNotIn('et_lead.status', [2, 6])
        ->where('et_lead.lead_status_id', 3)
        ->where('et_lead.internal_status', 0)
        ->where('et_lead.spam_verified', 0)
        ->where('et_lead.drop_verified', 0)
        ->count();

      $customerConvertCount = DB::table('et_lead')->select('et_lead.sno')
        ->whereYear('et_lead.registered_date', $year)
        ->whereMonth('et_lead.registered_date', $month)
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.branch_id', $branch_id)
        ->where('et_lead.status', 4)->count();

      $customerConvertCount = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->whereIn('et_customer.status',[0,6])
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_lead.created_by', $member->sno)
        ->whereYear('et_customer.created_at', $year)
        ->whereMonth('et_customer.created_at', $month)
        ->count();
        
        
        $customerConvertCount =  DB::table('et_customer')
        ->select('et_customer.sno', 'et_customer.proposal_ids')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_payment', function($join) {
            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                 ->whereRaw('et_payment.transaction_date = (
                     SELECT MIN(ep.transaction_date)
                     FROM et_payment ep
                     WHERE ep.customer_id = et_customer.sno
                 )');
        })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        // ->where('et_customer.status', 0)
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_lead.created_by', $member->sno)
        ->whereYear('et_payment.transaction_date', $year)
        //  ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        // ->orderBy('et_customer.sno', 'asc')
        ->count();

      $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->whereYear('et_lead.registered_date', $year)
        ->whereMonth('et_lead.registered_date', $month)
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.spam_verified', 1)
        ->where('et_lead.branch_id', $branch_id)
        ->where('et_lead.status', 7)->count();

      $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
        ->whereYear('et_lead.registered_date', $year)
        ->whereMonth('et_lead.registered_date', $month)
        ->where('et_lead.created_by', $member->sno)
        ->where('et_lead.drop_verified', 1)
        ->where('et_lead.branch_id', $branch_id)
        ->where('et_lead.status', 5)->count();

      $monthFollowupCount = DB::table('et_appointment')
        ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
        ->whereIn('et_lead.status', [0, 4])
        ->where('et_appointment.created_by', $member->sno)
        ->whereYear('et_appointment.appointment_date', $year)
        ->whereMonth('et_appointment.appointment_date', $month)
        ->count();
      $monthwalkincount = DB::table('et_lead_appointment')
        ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
        ->where('et_lead_appointment.appointment_category', 'walk-in') // Fixed the table reference
        ->where('et_lead_appointment.created_by', $member->sno)
        ->whereYear('et_lead_appointment.appointment_date', $year)
        ->whereMonth('et_lead_appointment.appointment_date', $month)
        ->count();

      $monthcall_out = DB::table('et_call_tracker')
        ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
        ->whereYear('call_start_date', $year)
        ->whereMonth('call_start_date', $month)
        ->where('et_call_tracker.branch_id', $branch_id)
        ->where('et_call_tracker.branch_staff_id', $member->sno)
        ->first();
      $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;


      // Spam Ratio 
      $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
      $spam_lead_ratio = number_format($spam_lead_ratio, 2);

      // Dead ratio
      $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
      $dead_lead_ratio      = number_format($dead_lead_ratio, 2);

      // customer ratio
      $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
      $convertion_rate = number_format($convertion_rate, 2);

      //acr
      $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
      $averager_convertion_rate = number_format($averager_convertion_rate, 2);



      $currentMonthCustomerCount = 0;
      $total_business_amount     = 0;
      $total_payment             = 0;
      $total_paid_payment        = 0;
      $averageBusinessValue      = 0;
      $averageCollectionValue    = 0;
      
        
        $base_amount_paid = 0; // keep track of GST-excluded total
      $gst_percent = 18;

      if ($customerConvertCount > 0) {
        $currentMonthCustomer = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', $member->sno)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();

            
            
            $customerConvertCount =count($currentMonthCustomer);

        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
        $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';

        $totalAllPayment += $total_payment;
        $totalAllPaidPayment += $total_paid_payment;
      }
      
      if ($customerConvertCount > 0) {
        if ($currentMonthCustomer->isNotEmpty()) {
                foreach ($currentMonthCustomer as $customer) {
                    $proposal_ids = DB::table('et_proposal')
                        ->where('et_proposal.customer_id', $customer->sno)
                        ->where('et_proposal.status', 0)
                        ->whereNot('et_proposal.post_sale_check', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->pluck('sno')
                        ->toArray();
                        // return $proposal_ids;
            
                    $proposals = DB::table('et_proposal')
                        ->select('et_proposal.*', 'et_country_currencies.currency_code')
                        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                        ->whereIn('et_proposal.sno', $proposal_ids)
                        ->get();
            
                    foreach ($proposals as $proposal) {
                        // Paid slots for this proposal
                        $paidAmount = DB::table('et_proposal_pay_slot')
                            ->where('proposal_sno', $proposal->sno)
                            ->where('status', 0)
                            ->sum('paidAmount');
            
                        $grantAmount = $proposal->grant_total_amount;
            
                        // First remove GST from paidAmount (base value in proposal's currency)
                        $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
            
                        if ($proposal->currency_id == 70) {
                            // INR: add directly
                            $total_paid_payment += $paidAmount;
                            $total_payment += $grantAmount;
                            $base_amount_paid += $basePaidLocal;
                        } else {
                            // Non-INR: convert both amounts and base value
                            $helper = new \App\Helpers\Helpers();
                            $currency_code = $proposal->currency_code;
                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                        }
                    }
                }
            }
        
        
        // average 
        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
        $totalAllPayment +=$total_payment;
        $totalAllPaidPayment +=$base_amount_paid;
    }

      // Production Goal***********************************************


      

      $refferal_count = DB::table('et_referral_persons')
        ->where('branch_id', $branch_id)
        ->where('referral_id', $member->sno)
        ->where('status', 0)
        ->where('referral_type', 2)
        ->whereYear('created_at', $year)
        ->whereMonth('created_at', $month)
        ->count();

      // Production Goal***********************************************  
      // CRE Goal *****************************************************
      $review_count = 0;

      // CRE Goal *****************************************************
      // PC Goal *****************************************************

      $staff_pc = StaffModel::where('et_staff.branch_id', $branch_id)
        ->where('et_staff.department_id', 2)
        ->where('et_staff.status', 0)
        ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
        ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
        ->orderBy('staff_name', 'ASC')
        ->get([
          'et_staff.sno',
          'et_staff.staff_name',
          'et_staff.nick_name',
          'et_staff.gender',
          'et_staff.staff_image',
          'et_department.department_name',
          'et_user_role.role_name'
        ]);

      $totalcosting_amount = 0;
      $totalrefferal_count = 0;

      foreach ($staff_pc as $staff_pc_list) {

        // Production Goal***********************************************

        $totalcosting_amount += $staffproduction->earned_amount ?? 0;
        $total_basic_pay_pro += $slotType->basic_salary ?? 0;

        $refferal_count = DB::table('et_referral_persons')
          ->where('branch_id', $branch_id)
          ->where('referral_id', $staff_pc_list->sno)
          ->where('status', 0)
          ->where('referral_type', 2)
          ->whereYear('created_at', $year)
          ->whereMonth('created_at', $month)
          ->count();

        $totalrefferal_count += $refferal_count ?? 0;
      }

      if ($departmentId == 5) {
        $review_count = $totalrefferal_count;
      }

      // PC Goal *****************************************************

      // Sales Exc *****************************************************
      $drop_ids = DB::table('et_drop_refund')
        ->where('et_drop_refund.bh_status', 1)
        ->where('et_drop_refund.branch_id', $branch_id);

      $OutstandingPayment_count = 0;

      $post_sale_count = 0;


      $working_hoursAmount = 0;

      // Sales Exc *****************************************************

      $placement_count = 0;

      $mou_count = 0;


      $startDate = Carbon::create($year, $month, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
      $dayCount = $startDate->diffInDays($endDate) + 1;
      $monthcall_out = $dayCount > 0  ? round($monthcall_out /  $dayCount) : 0;
      $monthwalkincount = $dayCount > 0  ? round($monthwalkincount /  $dayCount) : 0;
      $monthFollowupCount = $dayCount > 0  ? round($monthFollowupCount /  $dayCount) : 0;

      $basic_pay = $member->basic_salary > 0 ? ($member->basic_salary * 10) : 0;
      $costing_amount_asign = $goalsetData[$member->sno]->rework ?? 0;
      $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
      $costing_amount = $costing_amount2;




      $productions_asign   = $goalsetData[$member->sno]->productions ?? 0;
      $total_basic_pay_pro = $total_basic_pay_pro * 10;
      $totalcosting_amount = $total_basic_pay_pro > 0  ? ($totalcosting_amount /  $total_basic_pay_pro)  *  $productions_asign : 0;

      if (isset($goalsetData[$member->sno]->goal_completed)) {
        if ($goalsetData[$member->sno]->goal_completed == 1) {
          $customerConvertCount = $goalsetData[$member->sno]->conversion_actual ?? 0;
          $convertion_rate = $goalsetData[$member->sno]->CR_actual ?? 0;
          $averageBusinessValue = $goalsetData[$member->sno]->ABV_actual ?? 0;
          $averageCollectionValue = $goalsetData[$member->sno]->ACV_actual ?? 0;
          $monthcall_out = $goalsetData[$member->sno]->avg_call_out_actual ?? 0;
          $monthwalkincount = $goalsetData[$member->sno]->no_of_walk_actual ?? 0;
          $monthFollowupCount = $goalsetData[$member->sno]->no_of_followup_actual ?? 0;
          $std_count = $goalsetData[$member->sno]->min_no_of_students_actual ?? 0;
          $costing_amount = $goalsetData[$member->sno]->rework_actual ?? 0;
          $review_count = $goalsetData[$member->sno]->no_of_reviews_actual ?? 0;
          $placement_count = $goalsetData[$member->sno]->no_of_placements_actual ?? 0;
          $mou_count = $goalsetData[$member->sno]->mou_actual ?? 0;
          $totalcosting_amount = $goalsetData[$member->sno]->productions_actual ?? 0;
          $working_hoursAmount = $goalsetData[$member->sno]->working_hours_actual ?? 0;
          $post_sale_count = $goalsetData[$member->sno]->no_of_post_sale_actual ?? 0;
          $OutstandingPayment_count = $goalsetData[$member->sno]->no_of_outstanding_actual ?? 0;
          $refferal_count = $goalsetData[$member->sno]->reference_sales_actual ?? 0;
        }
      }

      // $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, $departmentId , $month, $year, $branch_id) ?? 0;



      $currentMonth = $month;
      $currentYear  = $year;

      $startDate = Carbon::create($currentYear, $currentMonth, 1);
      $currentDate = Carbon::now();
      $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

      $dayCounts = 0;
      $dateSrt = $startDate->copy();

      while ($dateSrt->lte($endDate)) {
        if (!$dateSrt->isSunday()) {
          $dayCounts++;
        }
        $dateSrt->addDay();
      }
      $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
        ->where('branch_id', $branchId)
        ->whereIn('attendance', ['P', 'HD'])
        ->whereMonth('date', $month)
        ->whereYear('date', $year)
        ->count();
      //  return $dayCounts;
      $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

      if ($presentDays == 0) {
        $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays > 0 && $presentDays < 50) {
        $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays >= 50 && $presentDays < 75) {
        $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays >= 75 && $presentDays < 100) {
        $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      } elseif ($presentDays == 100) {
        $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
      }



      $goal_progress =  $helper->getStaffGoal_progress_bar($member->sno, $departmentId, $month, $year, $branch_id) ?? 0;
      $ratio = $goal_progress;
      if ($ratio > 100) {
        $color = '#7854c7'; // Purple
      } elseif ($ratio >= 80) {
        $color = '#34C759'; // Green
      } elseif ($ratio >= 40) {
        $color = '#FFCC00'; // Yellow
      } else {
        $color = '#FF3B30'; // Red
      }

      if ($departmentId == 1) {
        // return $actualMonthLeadCount;
        $promisecount = DB::table('et_sales_promise')
          ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
          ->where('et_staff.department_id', 1)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->where('et_sales_promise.status', 0)
          ->where('et_staff.sno', $member->sno)
          ->sum('et_sales_promise.promise_count');

        $successcount = DB::table('et_sales_promise')
          ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
          ->where('et_staff.department_id', 1)
          ->where('et_sales_promise.branch_id', $branch_id)
          ->whereYear('et_sales_promise.promise_date', $year)
          ->whereMonth('et_sales_promise.promise_date', $month)
          ->where('et_sales_promise.status', 1)
          ->where('et_staff.sno', $member->sno)
          ->sum('et_sales_promise.promise_count');

        // Avoid division by zero
        $formattedPromiseSuccess = 0;

        if ($promisecount > 0) {
          $rawScore = ($successcount / $promisecount) * 10;
          $score = min(round($rawScore), 10); // round to whole number and cap at 10
          $formattedPromiseSuccess = str_pad($score, 2, '0', STR_PAD_LEFT); // ensure 2 digits like 02, 10
        } else {
          $formattedPromiseSuccess = '00';
        }

        // Determine badge color
        $trustBadgeColor = 'bg-danger';
        if ($formattedPromiseSuccess >= 5 && $formattedPromiseSuccess <= 8) {
          $trustBadgeColor = 'bg-warning';
        } elseif ($formattedPromiseSuccess >= 9) {
          $trustBadgeColor = 'bg-success';
        }

        $promise = '<div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
                      <div class="fs-8 fw-semibold text-dark">TS</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge ' . $trustBadgeColor . ' fw-semibold fs-8">' . $formattedPromiseSuccess  . '</label>
                      </div>
                    </div>';
      } else {
        $promise = '';
      }



      $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
        . $heart .
        '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    ' . $promise . '
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';




      $staffDetails2 = [
        'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
        'conversion_actual'         => $customerConvertCount ?? 0,
        'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
        'cr_actual'                 => $convertion_rate ?? 0,
        'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
        'abv_actual'                => $averageBusinessValue ?? 0,
        'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
        'acv_actual'                => $averageCollectionValue ?? 0,
        'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
        'avg_call_out_actual'       => $monthcall_out ?? 0,
        'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
        'no_of_walk_actual'         => $monthwalkincount ?? 0,
        'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
        'no_of_followup_actual'     => $monthFollowupCount ?? 0,
        'min_no_of_students'        => $goalsetData[$member->sno]->min_no_of_students ?? 0,
        'min_no_of_students_actual' => $std_count ?? 0,
        'rework'        => $goalsetData[$member->sno]->rework ?? 0,
        'rework_actual' => $costing_amount ?? 0,
        'no_of_reviews'             => $goalsetData[$member->sno]->no_of_reviews ?? 0,
        'no_of_reviews_actual'      => $review_count ?? 0,
        'no_of_placements'          => $goalsetData[$member->sno]->no_of_placements ?? 0,
        'no_of_placements_actual'   => $placement_count ?? 0,
        'mou'                       => $goalsetData[$member->sno]->mou ?? 0,
        'mou_actual'                => $mou_count ?? 0,
        'productions'               => $goalsetData[$member->sno]->productions ?? 0,
        'productions_actual'        => $totalcosting_amount ?? 0,
        'working_hours'                       => $goalsetData[$member->sno]->working_hours ?? 0,
        'working_hours_actual'                => $working_hoursAmount ?? 0,
        'no_of_post_sale'           => $goalsetData[$member->sno]->no_of_post_sale ?? 0,
        'no_of_post_sale_actual'    => $post_sale_count ?? 0,
        'no_of_outstanding'         => $goalsetData[$member->sno]->no_of_outstanding ?? 0,
        'no_of_outstanding_actual'  => $OutstandingPayment_count ?? 0,
        'reference_sales'           => $goalsetData[$member->sno]->reference_sales ?? 0,
        'reference_sales_actual'    => $refferal_count ?? '0',
      ];
        $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
        $goal_achievements = false;
        if(isset($ten_x)){
            foreach ($ten_x as $key => $value) {
                $isChecked = $value === "1";
                if ($isChecked) {
                    $type2 = str_replace("_10x", "", $key);
                    $goal_value = $staffDetails2[$type2] ?? 0;
                    $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                    if($goal_value > 0){
                        if ($actual_value < $goal_value) {
                            $goal_achievements = true; // Not Achieved
                            break; // No need to continue checking if one goal failed
                        }
                    }else{
                        $goal_achievements = true; // Invalid goal
                        break;
                    }
                }
            }
        }
        
        
        if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
            $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
        } else {
            $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
            $staff_image = $helper->name_image($initial, $member->gender);
        }

      
      $staffDetails[] = [
        'sno'                       => $member->sno,
        'staff_name'                => $member->staff_name,
        'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
        'goal_achievements'         => $goal_achievements,
        'nick_name'                 => $member->nick_name,
        'gender'                    => $member->gender,
        'staff_image'               => $staff_image,
        'department_name'           => $member->department_name,
        'role_name'                 => $member->role_name,
        'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
        'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
        'month'                     => $month_id,
        'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,

        'conversion_check'          => $goalsetteam->conversion_check ?? 0,
        'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
        'conversion_actual'         => $customerConvertCount ?? 0,

        'cr_check'                  => $goalsetteam->cr_check ?? 0,
        'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
        'cr_actual'                 => $convertion_rate ?? 0,

        'abv_check'                 => isset($goalsetteam->abv_check) ? $goalsetteam->abv_check : 0,
        'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
        'abv_actual'                => $averageBusinessValue ?? 0,

        'acv_check'                 => isset($goalsetteam->acv_check) ? $goalsetteam->acv_check : 0,
        'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
        'acv_actual'                => $averageCollectionValue ?? 0,

        'avg_call_out_check'        => $goalsetteam->avg_call_out_check ?? 0,
        'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
        'avg_call_out_actual'       => $monthcall_out ?? 0,

        'no_of_walk_check'          => $goalsetteam->no_of_walk_check ?? 0,
        'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
        'no_of_walk_actual'         => $monthwalkincount ?? 0,

        'no_of_followup_check'      => $goalsetteam->no_of_followup_check ?? 0,
        'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
        'no_of_followup_actual'     => $monthFollowupCount ?? 0,

        'min_no_of_students_check'  => $goalsetteam->min_no_of_students_check ?? 0,
        'min_no_of_students'        => $goalsetData[$member->sno]->min_no_of_students ?? 0,
        'min_no_of_students_actual' => $std_count ?? 0,


        'rework_check'  => $goalsetteam->rework_check ?? 0,
        'rework'        => $goalsetData[$member->sno]->rework ?? 0,
        'rework_actual' => $costing_amount ?? 0,

        'no_of_reviews_check'       => $goalsetteam->no_of_reviews_check ?? 0,
        'no_of_reviews'             => $goalsetData[$member->sno]->no_of_reviews ?? 0,
        'no_of_reviews_actual'      => $review_count ?? 0,

        'no_of_placements_check'    => $goalsetteam->no_of_placements_check ?? 0,
        'no_of_placements'          => $goalsetData[$member->sno]->no_of_placements ?? 0,
        'no_of_placements_actual'   => $placement_count ?? 0,

        'mou_check'                 => $goalsetteam->mou_check ?? 0,
        'mou'                       => $goalsetData[$member->sno]->mou ?? 0,
        'mou_actual'                => $mou_count ?? 0,

        'productions_check'         => $goalsetteam->productions_check ?? 0,
        'productions'               => $goalsetData[$member->sno]->productions ?? 0,
        'productions_actual'        => $totalcosting_amount ?? 0,

        'working_hours_check'                 => $goalsetteam->working_hours_check ?? 0,
        'working_hours'                       => $goalsetData[$member->sno]->working_hours ?? 0,
        'working_hours_actual'                => $working_hoursAmount ?? 0,

        'no_of_post_sale_check'     => $goalsetteam->no_of_post_sale_check ?? 0,
        'no_of_post_sale'           => $goalsetData[$member->sno]->no_of_post_sale ?? 0,
        'no_of_post_sale_actual'    => $post_sale_count ?? 0,

        'no_of_outstanding_check'   => $goalsetteam->no_of_outstanding_check ?? 0,
        'no_of_outstanding'         => $goalsetData[$member->sno]->no_of_outstanding ?? 0,
        'no_of_outstanding_actual'  => $OutstandingPayment_count ?? 0,

        'reference_sales'           => $goalsetData[$member->sno]->reference_sales ?? 0,
        'reference_sales_check'     => $goalsetteam->reference_sales_check ?? 0,
        'reference_sales_actual'    => $refferal_count ?? '0',

        'sales_lead_checks'    => $goalsetData[$member->sno]->sales_lead_check ?? 0,


        'score_td'    => $score_td ?? '-',


      ];


    }
    
    return response()->json([
      'status' => 200,
      'data' => $staffDetails
    ]);
  }

  public function saveTeamGoal(Request $request)
  {
    // Validate incoming data
    $validatedData = $request->validate([
      'department_id' => 'required|numeric',
      'month_id'      => 'required',
      'year_id'      => 'required',
      'branch_id'      => 'required',
      'conversion_over_all' => 'nullable|numeric',
      'conversion_check' => 'nullable|numeric',
      'conversion_type' => 'nullable|numeric',
      'cr_over_all'   => 'nullable|numeric',
      'cr_check'      => 'nullable|numeric',
      'cr_type'       => 'nullable|numeric',
      'abv_over_all'  => 'nullable|numeric',
      'abv_check'     => 'nullable|numeric',
      'abv_type'      => 'nullable|numeric',
      'acv_over_all'  => 'nullable|numeric',
      'acv_type'      => 'nullable|numeric',
      'acv_check'     => 'nullable|numeric',
      'avg_call_out_over_all'   => 'nullable|numeric',
      'avg_call_out_check'      => 'nullable|numeric',
      'avg_call_out_type'       => 'nullable|numeric',
      'no_of_walk_over_all'     => 'nullable|numeric',
      'no_of_walk_check'        => 'nullable|numeric',
      'no_of_walk_type'         => 'nullable|numeric',
      'no_of_followup_over_all' => 'nullable|numeric',
      'no_of_followup_check'    => 'nullable|numeric',
      'no_of_followup_type'     => 'nullable|numeric',
      'working_hours_over_all'            => 'nullable|numeric',
      'working_hours_check'               => 'nullable|numeric',
      'working_hours_type'                => 'nullable|numeric',
      'no_of_post_sale_over_all' => 'nullable|numeric',
      'no_of_post_sale_check'    => 'nullable|numeric',
      'no_of_post_sale_type'     => 'nullable|numeric',
      'no_of_outstanding_over_all' => 'nullable|numeric',
      'no_of_outstanding_check'    => 'nullable|numeric',
      'no_of_outstanding_type'     => 'nullable|numeric',
      'min_no_of_students_over_all' => 'nullable|numeric',
      'min_no_of_students_check'    => 'nullable|numeric',
      'min_no_of_students_type'     => 'nullable|numeric',
      'rework_over_all' => 'nullable|numeric',
      'rework_check'    => 'nullable|numeric',
      'rework_type'     => 'nullable|numeric',
      'productions_over_all'  => 'nullable|numeric',
      'productions_check'     => 'nullable|numeric',
      'productions_type'      => 'nullable|numeric',
      'no_of_reviews_over_all' => 'nullable|numeric',
      'no_of_reviews_check'   => 'nullable|numeric',
      'no_of_reviews_type'    => 'nullable|numeric',
      'given_links_over_all'  => 'nullable|numeric',
      'given_links_check'     => 'nullable|numeric',
      'given_links_type'      => 'nullable|numeric',
      'no_of_placements_over_all' => 'nullable|numeric',
      'no_of_placements_check'  => 'nullable|numeric',
      'no_of_placements_type'  => 'nullable|numeric',
      'mou_over_all'          => 'nullable|numeric',
      'mou_check'             => 'nullable|numeric',
      'mou_type'              => 'nullable|numeric',
      'reference_sales_over_all' => 'nullable|numeric',
      'reference_sales_check'    => 'nullable|numeric',
      'reference_sales_type'     => 'nullable|numeric',
    ]);

    $branchId = $validatedData['branch_id'];
    $departmentId = $validatedData['department_id'];
    $month_id = $validatedData['month_id'];
    $year_id = $validatedData['year_id'];
    $createdBy = $request->user()->user_id;
    return $year_id;
    // Convert month_id if it's a string
    if (!is_numeric($month_id)) {
      $month_id = date('m', strtotime($month_id . ' 1'));
    }

    // Update or create the goal record
    $goal = GoalSetTeamModel::updateOrCreate(
      [
        'team_goal_month' => (int)$month_id,
        'team_goal_year'  => (int)$year_id,
        'branch_id'       => $branchId,
        'department_id'   => $departmentId,
      ],
      array_merge($validatedData, [
        'created_by' => $createdBy,
        'updated_by' => $createdBy,
        'status'     => 1 // Mark as 'Goal Set'
      ])
    );

    return response()->json([
      'status'  => 200,
      'message' => 'Team goal successfully updated!',
      'data'    => $goal
    ]);
  }





  public function addOrUpdateStaffGoal(Request $request)
  {
    // Convert month name to numeric format
    $monthName = $request->input('month_id');
    $monthNumber = date('m', strtotime($monthName . ' 1')); // Converts "February" to "02"

    // Replace month_id in the request before validation
    $request->merge(['month_id' => (int)$monthNumber]);
    $validatedData = $request->validate([
      'team_id' => 'required|integer',
      'month_id' => 'required|integer',
      'year' => 'required|integer',
      'department_id' => 'required|integer',
      'staff_goals' => 'required|array',
      'staff_goals.*.staff_id' => 'required|integer',
      'staff_goals.*.conversion' => 'nullable|integer',
      'staff_goals.*.cr' => 'nullable|integer',
      'staff_goals.*.abv' => 'nullable|integer',
      'staff_goals.*.acv' => 'nullable|integer',
      'staff_goals.*.avg_call_out' => 'nullable|integer',
      'staff_goals.*.no_of_walk' => 'nullable|integer',
      'staff_goals.*.no_of_followup' => 'nullable|integer',
      'staff_goals.*.working_hours' => 'nullable|integer',
      'staff_goals.*.no_of_post_sale' => 'nullable|integer',
      'staff_goals.*.no_of_outstanding' => 'nullable|integer',
      'staff_goals.*.rework' => 'nullable|integer',
      'staff_goals.*.min_no_of_students' => 'nullable|integer',
      'staff_goals.*.productions' => 'nullable|integer',
      'staff_goals.*.no_of_reviews' => 'nullable|integer',
      'staff_goals.*.no_of_placements' => 'nullable|integer',
      'staff_goals.*.mou' => 'nullable|integer',
      'staff_goals.*.reference_sales' => 'nullable|integer',
    ]);

    $branchId = $request->user()->branch_id;
    $departmentId = $validatedData['department_id'];
    $month = $validatedData['month_id'];
    $year = $validatedData['year'];
    $team_id = $validatedData['team_id'];
    $createdBy = $request->user()->user_id;
    // return $request->all();
    $branch_check = BranchModel::where('sno', $branchId)->orderBy('sno', 'desc')->first();

    $branch_code = $branch_check->city_short_code;


    foreach ($validatedData['staff_goals'] as $goalData) {
      GoalSetStaffModel::updateOrCreate(
        [
          'goal_month' => $month,
          'goal_date' => "{$year}-{$month}-01", // Proper date format
          'branch_id' => $branchId,
          'department_id' => $departmentId,
          'staff_id' => $goalData['staff_id'],
        ],
        [
          'team_id' => $team_id,
          'conversion' => $goalData['conversion'] ?? 0,
          'CR' => $goalData['cr'] ?? 0,
          'ABV' => $goalData['abv'] ?? 0,
          'ACV' => $goalData['acv'] ?? 0,
          'avg_call_out' => $goalData['avg_call_out'] ?? 0,
          'no_of_walk' => $goalData['no_of_walk'] ?? 0,
          'no_of_followup' => $goalData['no_of_followup'] ?? 0,
          'working_hours' => $goalData['working_hours'] ?? 0,
          'no_of_post_sale' => $goalData['no_of_post_sale'] ?? 0,
          'no_of_outstanding' => $goalData['no_of_outstanding'] ?? 0,
          'rework' => $goalData['rework'] ?? 0,
          'min_no_of_students' => $goalData['min_no_of_students'] ?? 0,
          'productions' => $goalData['productions'] ?? 0,
          'no_of_reviews' => $goalData['no_of_reviews'] ?? 0,
          'no_of_placements' => $goalData['no_of_placements'] ?? 0,
          'mou' => $goalData['mou'] ?? 0,
          'reference_sales' => $goalData['reference_sales'] ?? 0,
          'created_by' => $createdBy,
          'updated_by' => $createdBy,
          'status' => 1, // Default status
        ]
      );
    }


    return response()->json([
      'status' => 200,
      'message' => 'Goals updated successfully'
    ]);
  }
}
