<?php

namespace App\Http\Controllers\team_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use App\Models\CustomerModel;
use App\Models\ManageCoursesModel;
use App\Models\BatchModel;
use App\Models\PaymentModel;
use App\Models\AttendanceModel;
use App\Models\CronjobLogModel;
use App\Models\CronjobMonitorModel;
use Carbon\Carbon;
use App\Models\TrainingModel;
use App\Models\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;

class StaffGoalSet extends Controller
{


    public function index()
    {

        return view('content.team_management.goal_set');
    }
    // Fetch Departments based on Branch
    public function getDepartmentsGoal(Request $request)
    {
        $departments = DepartmentModel::where('status', 0)->get(['sno', 'department_name']);
        return response()->json(['status' => 200, 'data' => $departments]);
    }

    public function getStaffGoal(Request $request)
    {
        $branchId = $request->user()->branch_id;
        $departmentId = $request->department_id;
        $month_id = $request->month_id;
        $month = date('n', strtotime($month_id));
        $year = $request->year;
        $branch_id = $request->user()->branch_id;
        $helper             = new \App\Helpers\Helpers();


        if (!empty($month_id)) {
            if (!is_numeric($month_id)) {
                // Convert month name (e.g., "February") to its numeric value
                $monthNumber = date('m', strtotime($month_id . ' 1'));
                $request->merge(['month_id' => (int)$monthNumber]);
            } else {
                // Ensure month_id is an integer if it's already numeric
                $request->merge(['month_id' => (int)$month_id]);
                $monthNumber = date('m', strtotime($month_id . ' 1'));
            }
        }

        $month = (int)$monthNumber; // 2

        // Get staff members with department and role details
        $staff = StaffModel::where('et_staff.branch_id', $branchId)
            ->where('et_staff.department_id', $departmentId)
            ->where('et_staff.status', 0)
            // ->where('et_staff.sno', 66)
            ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->join('et_user_role', 'et_staff.role_id', '=', 'et_user_role.sno')
            ->orderBy('staff_name', 'ASC')
            ->get([
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.nick_name',
                'et_staff.gender',
                'et_staff.role_id',
                'et_staff.avaiable_points',
                'et_staff.staff_image',
                'et_staff.basic_salary',
                'et_department.department_name',
                'et_user_role.role_name'
            ]);


        $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $departmentId)->where('et_goal_set_team.branch_id', $branchId)
            ->where('et_goal_set_team.team_goal_month', $month)
            ->where('et_goal_set_team.team_goal_year', $year)
            ->first();
        // Get goal records for the selected department and month
        $goalsetRecords = GoalSetStaffModel::where('et_goal_set_staff.department_id', $departmentId)
            ->where('et_goal_set_staff.branch_id', $branchId)
            ->where('et_goal_set_staff.goal_month', $month)
            ->whereMonth('et_goal_set_staff.goal_date', $month)
            ->whereYear('et_goal_set_staff.goal_date', $year)
            ->get();

        if ($goalsetRecords->isEmpty()) {
            return response()->json([
                'status' => 402,
                'data'   => []
            ]);
        }
        // return $goalsetRecords;
        // Convert goalsetRecords to an associative array for easy lookup
        $goalsetData = [];
        foreach ($goalsetRecords as $goal) {
            $goalsetData[$goal->staff_id] = $goal;
        }
        $totalAllPayment             = 0;
        $totalAllPaidPayment         = 0;
        $staffDetails = [];
        // ##############################################################################################
        // ******************************** Pre Sales Department ****************************************
        // ##############################################################################################
        if ($departmentId == 1) {
            // Attach goal details to staff members
            $staffDetails = [];
            $values = [];
            foreach ($staff as $member) {

                $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.branch_id', $branch_id)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();

                $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.branch_id', $branch_id)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();

                $customerConvertCount =  DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.transaction_date = (
                     SELECT MIN(ep.transaction_date)
                     FROM et_payment ep
                     WHERE ep.customer_id = et_customer.sno
                 )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    // ->where('et_customer.status', 0)
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_lead.created_by', $member->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    //  ->whereDay('et_payment.transaction_date', $day) // Use `whereDay` instead of `whereDate`
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    // ->orderBy('et_customer.sno', 'asc')
                    ->count();

                $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.spam_verified', 1)
                    ->where('et_lead.branch_id', $branch_id)
                    ->where('et_lead.status', 7)->count();

                $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.drop_verified', 1)
                    ->where('et_lead.branch_id', $branch_id)
                    ->where('et_lead.status', 5)->count();

                $monthFollowupCGET = DB::table('et_appointment')
                    ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
                    ->whereIn('et_lead.status', [0, 4])
                    ->where('et_appointment.created_by', $member->sno)
                    ->whereYear('et_appointment.appointment_date', $year)
                    ->whereMonth('et_appointment.appointment_date', $month)
                    ->count();

                $monthwalkincount = DB::table('et_lead_appointment')
                    ->join('et_lead', 'et_lead_appointment.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead_appointment.appointment_category', 3) // Fixed the table reference
                    ->where('et_lead_appointment.created_by', $member->sno)
                    ->whereYear('et_lead_appointment.appointment_date', $year)
                    ->whereMonth('et_lead_appointment.appointment_date', $month)
                    ->count();

                $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branch_id)
                    ->where('et_call_tracker.branch_staff_id', $member->sno)
                    ->first();
                $monthcall_outcnt = $monthcall_out->outgoing_call_count ?? 0;
                $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;

                $startDate = Carbon::create($year, $month, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
                $dayCounts3 = $startDate->diffInDays($endDate) + 1;

                $monthcall_out = $dayCounts3 > 0  ? round($monthcall_outcnt / ($dayCounts3)) : 0;
                $monthFollowupCount = $dayCounts3 > 0  ? round($monthFollowupCGET / ($dayCounts3)) : 0;

                // Spam Ratio 
                $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
                $spam_lead_ratio = number_format($spam_lead_ratio, 2);
                // Dead ratio
                $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
                $dead_lead_ratio      = number_format($dead_lead_ratio, 2);
                // customer ratio
                $convertion_rates = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                $convertion_rate = number_format($convertion_rates, 2);
                //acr
                $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                $averager_convertion_rate = number_format($averager_convertion_rate, 2);
                $total_payment             = 0;
                $total_paid_payment        = 0;
                $averageBusinessValue      = 0;
                $averageCollectionValue    = 0;


                $base_amount_paid = 0; // keep track of GST-excluded total
                $gst_percent = 18;

                if ($customerConvertCount > 0) {
                    $currentMonthCustomer = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function ($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.customer_id = et_customer.sno
                     )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.branch_id', $branch_id)
                        ->where('et_lead.created_by', $member->sno)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->get();
                    $customerConvertCount = count($currentMonthCustomer);
                    // average 
                    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                    $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                    $totalAllPayment += $total_payment;
                    $totalAllPaidPayment += $total_paid_payment;
                }
                if ($customerConvertCount > 0) {
                    if ($currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                            $proposal_ids = DB::table('et_proposal')
                                ->where('et_proposal.customer_id', $customer->sno)
                                ->where('et_proposal.status', 0)
                                ->whereNot('et_proposal.post_sale_check', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                ->pluck('sno')
                                ->toArray();
                            // return $proposal_ids;

                            $proposals = DB::table('et_proposal')
                                ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                ->whereIn('et_proposal.sno', $proposal_ids)
                                ->get();

                            foreach ($proposals as $proposal) {
                                // Paid slots for this proposal
                                $paidAmount = DB::table('et_proposal_pay_slot')
                                    ->where('proposal_sno', $proposal->sno)
                                    ->where('status', 0)
                                    ->sum('paidAmount');

                                $grantAmount = $proposal->grant_total_amount;

                                // First remove GST from paidAmount (base value in proposal's currency)
                                $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                                if ($proposal->currency_id == 70) {
                                    // INR: add directly
                                    $total_paid_payment += $paidAmount;
                                    $total_payment += $grantAmount;
                                    $base_amount_paid += $basePaidLocal;
                                } else {
                                    $currency_code = $proposal->currency_code;
                                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                }
                            }
                        }
                    }
                    // average 
                    $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                    $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                    $totalAllPayment += $total_payment;
                    $totalAllPaidPayment += $base_amount_paid;
                }

                if (isset($goalsetData[$member->sno]->goal_completed)) {
                    if ($goalsetData[$member->sno]->goal_completed == 1) {
                        $customerConvertCount = $goalsetData[$member->sno]->conversion_actual ?? 0;
                        $convertion_rate = $goalsetData[$member->sno]->CR_actual ?? 0;
                        $averageBusinessValue = $goalsetData[$member->sno]->ABV_actual ?? 0;
                        $averageCollectionValue = $goalsetData[$member->sno]->ACV_actual ?? 0;
                        $monthcall_out = $goalsetData[$member->sno]->avg_call_out_actual ?? 0;
                        $monthwalkincount = $goalsetData[$member->sno]->no_of_walk_actual ?? 0;
                        $monthFollowupCount = $goalsetData[$member->sno]->no_of_followup_actual ?? 0;
                    }
                }

                $staffDetails2 = [
                    'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
                    'conversion_actual'         => $customerConvertCount ?? 0,
                    'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
                    'cr_actual'                 => $convertion_rate ?? 0,
                    'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
                    'abv_actual'                => $averageBusinessValue ?? 0,
                    'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
                    'acv_actual'                => $averageCollectionValue ?? 0,
                    'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
                    'avg_call_out_actual'       => $monthcall_out ?? 0,
                    'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
                    'no_of_walk_actual'         => $monthwalkincount ?? 0,
                    'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
                    'no_of_followup_actual'     => $monthFollowupCount ?? 0,
                ];
                $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                $goal_achievements = false;
                $total_goal = 0;
                $tot_actual_value = 0;
                $actual_values = 0;

                if (isset($ten_x)) {
                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            $actual_values = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($key == 'rework') {
                                if ($actual_value >= $goal_value) {
                                    $actual_values = $goal_value;
                                }
                                $total_goal  += $goal_value;
                                $tot_actual_value  += $actual_values;
                            } else {
                                if ($actual_value <= $goal_value) {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $goal_value;
                                } else {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $actual_value;
                                }
                            }

                            $values[] = [
                                'set' => $goal_value,
                                'act' =>  $actual_values,
                                '$total_goal'  => $total_goal,
                                '$tot_actual_value'  => $tot_actual_value,
                            ];
                        }
                    }

                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($goal_value > 0) {
                                if ($actual_value < $goal_value) {
                                    $goal_achievements = true; // Not Achieved
                                    break; // No need to continue checking if one goal failed
                                }
                            } else {
                                $goal_achievements = true;
                                break;
                            }
                        }
                    }
                }

                if (isset($goalsetData[$member->sno]->goal_completed) && $goalsetData[$member->sno]->goal_completed == 1) {
                    $goal_progres = $goalsetData[$member->sno]->goalset_percentage ?? 0;
                } else {
                    $goal_progres = $total_goal > 0 ? ($tot_actual_value / $total_goal) * 100 : 0;
                }

                $goal_progress = round($goal_progres);
                $ratio = $goal_progress;
                if ($ratio > 100) {
                    $color = '#7854c7'; // Purple
                } elseif ($ratio >= 80) {
                    $color = '#34C759'; // Green
                } elseif ($ratio >= 40) {
                    $color = '#FFCC00'; // Yellow
                } else {
                    $color = '#FF3B30'; // Red
                }

                $currentMonth = $month;
                $currentYear  = $year;

                $startDate = Carbon::create($currentYear, $currentMonth, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

                $dayCounts = 0;
                $dateSrt = $startDate->copy();

                while ($dateSrt->lte($endDate)) {
                    if (!$dateSrt->isSunday()) {
                        $dayCounts++;
                    }
                    $dateSrt->addDay();
                }
                $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
                    ->where('branch_id', $branchId)
                    ->whereIn('attendance', ['P', 'HD'])
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->count();
                //  return $dayCounts;
                $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;


                if ($presentDays == 0) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays > 0 && $presentDays < 50) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 50 && $presentDays < 75) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 75 && $presentDays < 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays == 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                }



                if ($departmentId == 1) {
                    // return $actualMonthLeadCount;
                    $promisecount = DB::table('et_sales_promise')
                        ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
                        ->where('et_staff.department_id', 1)
                        ->where('et_sales_promise.branch_id', $branch_id)
                        ->whereYear('et_sales_promise.promise_date', $year)
                        ->whereMonth('et_sales_promise.promise_date', $month)
                        ->where('et_sales_promise.status', 0)
                        ->where('et_staff.sno', $member->sno)
                        ->sum('et_sales_promise.promise_count');

                    $successcount = DB::table('et_sales_promise')
                        ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
                        ->where('et_staff.department_id', 1)
                        ->where('et_sales_promise.branch_id', $branch_id)
                        ->whereYear('et_sales_promise.promise_date', $year)
                        ->whereMonth('et_sales_promise.promise_date', $month)
                        ->where('et_sales_promise.status', 1)
                        ->where('et_staff.sno', $member->sno)
                        ->sum('et_sales_promise.promise_count');

                    // Avoid division by zero
                    $formattedPromiseSuccess = 0;

                    if ($promisecount > 0) {
                        $rawScore = ($successcount / $promisecount) * 10;
                        $score = min(round($rawScore), 10); // round to whole number and cap at 10
                        $formattedPromiseSuccess = str_pad($score, 2, '0', STR_PAD_LEFT); // ensure 2 digits like 02, 10
                    } else {
                        $formattedPromiseSuccess = '00';
                    }

                    // Determine badge color
                    $trustBadgeColor = 'bg-danger';
                    if ($formattedPromiseSuccess >= 5 && $formattedPromiseSuccess <= 8) {
                        $trustBadgeColor = 'bg-warning';
                    } elseif ($formattedPromiseSuccess >= 9) {
                        $trustBadgeColor = 'bg-success';
                    }

                    $promise = '<div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
                      <div class="fs-8 fw-semibold text-dark">TS</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge ' . $trustBadgeColor . ' fw-semibold fs-8">' . $formattedPromiseSuccess  . '</label>
                      </div>
                    </div>';
                } else {
                    $promise = '';
                }
                $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
                    . $heart .
                    '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    ' . $promise . '
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';

                //   return $goal_achievements;

                if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
                    $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
                } else {
                    $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
                    $staff_image = $helper->name_image($initial, $member->gender);
                }


                $staffDetails[] = [
                    'monthcall_outdgdfhfdhfhd'                       => $monthcall_outcnt,
                    'dayCounts3'                       => $dayCounts3,
                    'calc'                       => $tot_actual_value . '/' . $total_goal,
                    'calc_cr'                       => $customerConvertCount . '/' . $allLeadCount,
                    'sno'                       => $member->sno,
                    'staff_name'                => $member->staff_name,
                    'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
                    'goal_achievements'         => $goal_achievements,
                    'nick_name'                 => $member->nick_name,
                    'gender'                    => $member->gender,
                    'staff_image'               => $staff_image,
                    'department_name'           => $member->department_name,
                    'role_name'                 => $member->role_name,
                    'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
                    'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
                    'month'                     => $month_id,
                    'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,
                    'sales_lead_checks'    => $goalsetData[$member->sno]->sales_lead_check ?? 0,
                    'score_td'    => $score_td ?? '-',


                    'conversion_check'          => $goalsetteam->conversion_check ?? 0,
                    'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
                    'conversion_actual'         => $customerConvertCount ?? 0,

                    'cr_check'                  => $goalsetteam->cr_check ?? 0,
                    'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
                    'cr_actual'                 => $convertion_rate ?? 0,

                    'abv_check'                 => isset($goalsetteam->abv_check) ? $goalsetteam->abv_check : 0,
                    'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
                    'abv_actual'                => $averageBusinessValue ?? 0,

                    'acv_check'                 => isset($goalsetteam->acv_check) ? $goalsetteam->acv_check : 0,
                    'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
                    'acv_actual'                => $averageCollectionValue ?? 0,

                    'avg_call_out_check'        => $goalsetteam->avg_call_out_check ?? 0,
                    'avg_call_out'              => $goalsetData[$member->sno]->avg_call_out ?? 0,
                    'avg_call_out_actual'       => $monthcall_out ?? 0,

                    'no_of_walk_check'          => $goalsetteam->no_of_walk_check ?? 0,
                    'no_of_walk'                => $goalsetData[$member->sno]->no_of_walk ?? 0,
                    'no_of_walk_actual'         => $monthwalkincount ?? 0,

                    'no_of_followup_check'      => $goalsetteam->no_of_followup_check ?? 0,
                    'no_of_followup'            => $goalsetData[$member->sno]->no_of_followup ?? 0,
                    'no_of_followup_actual'     => $monthFollowupCount ?? 0,
                ];
            }
        }
        // ##############################################################################################
        // ******************************** Post Sale Department ****************************************
        // ##############################################################################################
        if ($departmentId == 15) {
            // return 'Post Sale Department'; 
            $salesStaff = $staff;
            $totalAllPayment             = 0;
            $totalAllPaidPayment        = 0;
            $helper = new \App\Helpers\Helpers();
            foreach ($salesStaff as $member) {
                $allpostSaleData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_proposal.post_sale_date')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_proposal.created_by', $member->sno)
                    ->orderBy('et_proposal.created_at', 'asc') // Order by creation date, ascending
                    ->get();
                $allLeadCount = count($allpostSaleData);
                $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.branch_id', $branch_id)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                $customerConvertData = DB::table('et_customer')
                    ->select('et_customer.sno', 'et_customer.proposal_ids', 'et_customer.cus_name')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_proposal.created_by', $member->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->get();
                $customerConvertCount = count($customerConvertData);
                $spamLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.spam_verified', 1)
                    ->where('et_lead.branch_id', $branch_id)
                    ->where('et_lead.status', 7)->count();
                $deadLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->where('et_lead.created_by', $member->sno)
                    ->where('et_lead.drop_verified', 1)
                    ->where('et_lead.branch_id', $branch_id)
                    ->where('et_lead.status', 5)->count();
                // Spam Ratio 
                $spam_lead_ratio = $monthLeadCount > 0 ? ($spamLeadCount / $monthLeadCount) * 100 : 0;
                $spam_lead_ratio = number_format($spam_lead_ratio > 100 ? 100 : $spam_lead_ratio, 2);

                // Dead ratio
                $dead_lead_ratio      = $monthLeadCount > 0 ? ($deadLeadCount / $monthLeadCount) * 100 : 0;
                $dead_lead_ratio      = number_format($dead_lead_ratio > 100 ? 100 : $dead_lead_ratio, 2);

                // customer ratio
                $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                $convertion_rate = number_format($convertion_rate, 2);

                //acr
                $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                $averager_convertion_rate =  number_format($averager_convertion_rate > 100 ? 100 : $averager_convertion_rate, 2);
                $total_payment             = 0;
                $total_paid_payment        = 0;

                $base_amount_paid = 0; // keep track of GST-excluded total

                $gst_percent = 18;


                if ($customerConvertCount > 0) {
                    $currentMonthCustomer = $customerConvertData;
                    if ($currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                            $proposal_ids = DB::table('et_proposal')
                                ->where('et_proposal.customer_id', $customer->sno)
                                ->where('et_proposal.status', 0)
                                ->where('et_proposal.post_sale_check', 1)
                                ->whereYear('et_proposal.estimate_date', $year)
                                ->whereMonth('et_proposal.estimate_date', $month)
                                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                ->pluck('sno')
                                ->toArray();

                            $proposals = DB::table('et_proposal')
                                ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                ->whereIn('et_proposal.sno', $proposal_ids)
                                ->get();

                            foreach ($proposals as $proposal) {
                                // Paid slots for this proposal
                                $paidAmount = DB::table('et_proposal_pay_slot')
                                    ->where('proposal_sno', $proposal->sno)
                                    ->where('status', 0)
                                    ->sum('paidAmount');

                                $grantAmount = $proposal->grant_total_amount;

                                // First remove GST from paidAmount (base value in proposal's currency)
                                $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));

                                if ($proposal->currency_id == 70) {
                                    // INR: add directly
                                    $total_paid_payment += $paidAmount;
                                    $total_payment += $grantAmount;
                                    $base_amount_paid += $basePaidLocal;
                                } else {
                                    // Non-INR: convert both amounts and base value
                                    $currency_code = $proposal->currency_code;
                                    $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                    $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                    $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                }
                            }
                        }
                    }

                    $totalAllPayment += $total_payment;
                    $totalAllPaidPayment += $base_amount_paid;
                }

                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;


                $startDate = Carbon::create($year, $month, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();
                $dayCount = $startDate->diffInDays($endDate) + 1;

                if (isset($goalsetData[$member->sno]->goal_completed)) {
                    if ($goalsetData[$member->sno]->goal_completed == 1) {
                        $customerConvertCount = $goalsetData[$member->sno]->conversion_actual ?? 0;
                        $convertion_rate = $goalsetData[$member->sno]->CR_actual ?? 0;
                        $averageBusinessValue = $goalsetData[$member->sno]->ABV_actual ?? 0;
                        $averageCollectionValue = $goalsetData[$member->sno]->ACV_actual ?? 0;
                    }
                }

                $staffDetails2 = [
                    'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
                    'conversion_actual'         => $customerConvertCount ?? 0,
                    'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
                    'cr_actual'                 => $convertion_rate ?? 0,
                    'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
                    'abv_actual'                => $averageBusinessValue ?? 0,
                    'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
                    'acv_actual'                => $averageCollectionValue ?? 0,

                ];
                $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                $goal_achievements = false;
                $total_goal = 0;
                $tot_actual_value = 0;
                $actual_values = 0;

                if (isset($ten_x)) {
                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            $actual_values = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($key == 'rework') {
                                if ($actual_value >= $goal_value) {
                                    $actual_values = $goal_value;
                                }
                                $total_goal  += $goal_value;
                                $tot_actual_value  += $actual_values;
                            } else {
                                if ($actual_value <= $goal_value) {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $goal_value;
                                } else {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $actual_value;
                                }
                            }

                            $values[] = [
                                'set' => $goal_value,
                                'act' =>  $actual_values,
                                '$total_goal'  => $total_goal,
                                '$tot_actual_value'  => $tot_actual_value,
                            ];
                        }
                    }

                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($goal_value > 0) {
                                if ($actual_value < $goal_value) {
                                    $goal_achievements = true; // Not Achieved
                                    break; // No need to continue checking if one goal failed
                                }
                            } else {
                                $goal_achievements = true;
                                break;
                            }
                        }
                    }
                }

                $goal_progres = $total_goal > 0 ? ($tot_actual_value / $total_goal) * 100 : 0;
                $goal_progress = round($goal_progres);
                $ratio = $goal_progress;
                if ($ratio > 100) {
                    $color = '#7854c7'; // Purple
                } elseif ($ratio >= 80) {
                    $color = '#34C759'; // Green
                } elseif ($ratio >= 40) {
                    $color = '#FFCC00'; // Yellow
                } else {
                    $color = '#FF3B30'; // Red
                }

                $currentMonth = $month;
                $currentYear  = $year;

                $startDate = Carbon::create($currentYear, $currentMonth, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

                $dayCounts = 0;
                $dateSrt = $startDate->copy();

                while ($dateSrt->lte($endDate)) {
                    if (!$dateSrt->isSunday()) {
                        $dayCounts++;
                    }
                    $dateSrt->addDay();
                }
                $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
                    ->where('branch_id', $branchId)
                    ->whereIn('attendance', ['P', 'HD'])
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->count();
                //  return $dayCounts;
                $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

                if ($presentDays == 0) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays > 0 && $presentDays < 50) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 50 && $presentDays < 75) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 75 && $presentDays < 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays == 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                }



                if ($departmentId == 1) {
                    // return $actualMonthLeadCount;
                    $promisecount = DB::table('et_sales_promise')
                        ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
                        ->where('et_staff.department_id', 1)
                        ->where('et_sales_promise.branch_id', $branch_id)
                        ->whereYear('et_sales_promise.promise_date', $year)
                        ->whereMonth('et_sales_promise.promise_date', $month)
                        ->where('et_sales_promise.status', 0)
                        ->where('et_staff.sno', $member->sno)
                        ->sum('et_sales_promise.promise_count');

                    $successcount = DB::table('et_sales_promise')
                        ->join('et_staff', 'et_staff.sno', '=', 'et_sales_promise.staff_id')
                        ->where('et_staff.department_id', 1)
                        ->where('et_sales_promise.branch_id', $branch_id)
                        ->whereYear('et_sales_promise.promise_date', $year)
                        ->whereMonth('et_sales_promise.promise_date', $month)
                        ->where('et_sales_promise.status', 1)
                        ->where('et_staff.sno', $member->sno)
                        ->sum('et_sales_promise.promise_count');

                    // Avoid division by zero
                    $formattedPromiseSuccess = 0;

                    if ($promisecount > 0) {
                        $rawScore = ($successcount / $promisecount) * 10;
                        $score = min(round($rawScore), 10); // round to whole number and cap at 10
                        $formattedPromiseSuccess = str_pad($score, 2, '0', STR_PAD_LEFT); // ensure 2 digits like 02, 10
                    } else {
                        $formattedPromiseSuccess = '00';
                    }

                    // Determine badge color
                    $trustBadgeColor = 'bg-danger';
                    if ($formattedPromiseSuccess >= 5 && $formattedPromiseSuccess <= 8) {
                        $trustBadgeColor = 'bg-warning';
                    } elseif ($formattedPromiseSuccess >= 9) {
                        $trustBadgeColor = 'bg-success';
                    }

                    $promise = '<div class="mb-0 text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Trust Score">
                      <div class="fs-8 fw-semibold text-dark">TS</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge ' . $trustBadgeColor . ' fw-semibold fs-8">' . $formattedPromiseSuccess  . '</label>
                      </div>
                    </div>';
                } else {
                    $promise = '';
                }
                $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
                    . $heart .
                    '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    ' . $promise . '
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';

                if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
                    $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
                } else {
                    $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
                    $staff_image = $helper->name_image($initial, $member->gender);
                }

                $staffDetails[] = [
                    'sno'                       => $member->sno,
                    'staff_name'                => $member->staff_name,
                    'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
                    'goal_achievements'         => $goal_achievements,
                    'nick_name'                 => $member->nick_name,
                    'gender'                    => $member->gender,
                    'staff_image'               => $staff_image,
                    'department_name'           => $member->department_name,
                    'role_name'                 => $member->role_name,
                    'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
                    'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
                    'month'                     => $month_id,
                    'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,
                    'sales_lead_checks'         => $goalsetData[$member->sno]->sales_lead_check ?? 0,
                    'score_td'                  => $score_td ?? '-',
                    'conversion_check'          => $goalsetteam->conversion_check ?? 0,
                    'conversion'                => $goalsetData[$member->sno]->conversion ?? 0,
                    'conversion_actual'         => $customerConvertCount ?? 0,
                    'cr_check'                  => $goalsetteam->cr_check ?? 0,
                    'cr'                        => $goalsetData[$member->sno]->CR ?? 0,
                    'cr_actual'                 => $convertion_rate ?? 0,
                    'abv_check'                 => isset($goalsetteam->abv_check) ? $goalsetteam->abv_check : 0,
                    'abv'                       => isset($goalsetData[$member->sno]->ABV) ? $goalsetData[$member->sno]->ABV : 0,
                    'abv_actual'                => $averageBusinessValue ?? 0,
                    'acv_check'                 => isset($goalsetteam->acv_check) ? $goalsetteam->acv_check : 0,
                    'acv'                       => isset($goalsetData[$member->sno]->ACV) ? $goalsetData[$member->sno]->ACV : 0,
                    'acv_actual'                => $averageCollectionValue ?? 0,
                ];
            }
        }
        // ##############################################################################################
        // ******************************** Production Department ***************************************
        // ##############################################################################################
        if ($departmentId == 2) {
            $salesStaff = $staff;
            $helper = new \App\Helpers\Helpers();
            foreach ($salesStaff as $member) {


                $working_hour = DB::table('et_task_log')
                    ->where('et_task_log.branch_id', $branch_id)
                    ->whereYear('et_task_log.end_time', $year)
                    ->whereMonth('et_task_log.end_time', $month)
                    ->where('et_task_log.status', 1)
                    ->where('et_task_log.staff_id', $member->sno)
                    ->sum(DB::raw('TIME_TO_SEC(duration)'));

                $working_hoursActual = $working_hour / 3600;

                $rework_count = DB::table('et_daily_tasks')
                    ->whereYear('et_daily_tasks.task_date', $year)
                    ->whereMonth('et_daily_tasks.task_date', $month)
                    ->where('et_daily_tasks.rework_check', 1)
                    ->where('et_daily_tasks.staff_id', $member->sno)
                    ->count();


                if (isset($goalsetData[$member->sno]->goal_completed)) {
                    if ($goalsetData[$member->sno]->goal_completed == 1) {
                        $working_hoursActual = $goalsetData[$member->sno]->working_hours_actual ?? 0;
                        $rework_count = $goalsetData[$member->sno]->rework_actual ?? 0;
                    }
                }

                $staffDetails2 = [
                    'rework'                    => $goalsetData[$member->sno]->rework ?? 0,
                    'rework_actual'             => $rework_count ?? 0,
                    'working_hours'             => $goalsetData[$member->sno]->working_hours ?? 0,
                    'working_hours_actual'      => $working_hoursActual ?? 0,
                ];

                $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                $goal_achievements = false;
                $total_goal = 0;
                $tot_actual_value = 0;
                $actual_values = 0;
                $calvalues = [];

                if (isset($ten_x)) {
                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            $actual_values = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($key == 'rework') {
                                if ($actual_value >= $goal_value) {
                                    $actual_values = $goal_value;
                                }
                                $total_goal  += $goal_value;
                                $tot_actual_value  += $actual_values;
                            } else {
                                if ($actual_value <= $goal_value) {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $goal_value;
                                } else {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $actual_value;
                                }
                            }

                            $calvalues[] = [
                                'set' => $goal_value,
                                'act' =>  $actual_value,
                                'total_goal'  => $total_goal,
                                'tot_actual_value'  => $tot_actual_value,
                            ];
                        }
                    }

                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            if ($key = 'rework_10x') {
                                if ($goal_value > 0) {
                                    if ($actual_value > $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            } else {
                                if ($goal_value > 0) {
                                    if ($actual_value < $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                $goal_progres = $total_goal > 0 ? ($tot_actual_value / $total_goal) * 100 : 0;
                $goal_progress = round($goal_progres);
                $ratio = $goal_progress;
                if ($ratio > 100) {
                    $color = '#7854c7'; // Purple
                } elseif ($ratio >= 80) {
                    $color = '#34C759'; // Green
                } elseif ($ratio >= 40) {
                    $color = '#FFCC00'; // Yellow
                } else {
                    $color = '#FF3B30'; // Red
                }

                $currentMonth = $month;
                $currentYear  = $year;

                $startDate = Carbon::create($currentYear, $currentMonth, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

                $dayCounts = 0;
                $dateSrt = $startDate->copy();

                while ($dateSrt->lte($endDate)) {
                    if (!$dateSrt->isSunday()) {
                        $dayCounts++;
                    }
                    $dateSrt->addDay();
                }
                $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
                    ->where('branch_id', $branchId)
                    ->whereIn('attendance', ['P', 'HD'])
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->count();
                //  return $dayCounts;
                $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

                if ($presentDays == 0) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays > 0 && $presentDays < 50) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 50 && $presentDays < 75) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 75 && $presentDays < 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays == 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                }

                $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
                    . $heart .
                    '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';

                if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
                    $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
                } else {
                    $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
                    $staff_image = $helper->name_image($initial, $member->gender);
                }

                $staffDetails[] = [
                    'calvalues'                 => $calvalues,
                    'calc'                      => $tot_actual_value . '/' . $total_goal,
                    'sno'                       => $member->sno,
                    'staff_name'                => $member->staff_name,
                    'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
                    'goal_achievements'         => $goal_achievements,
                    'nick_name'                 => $member->nick_name,
                    'gender'                    => $member->gender,
                    'staff_image'               => $staff_image,
                    'department_name'           => $member->department_name,
                    'role_name'                 => $member->role_name,
                    'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
                    'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
                    'month'                     => $month_id,
                    'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,
                    'sales_lead_checks'         => $goalsetData[$member->sno]->sales_lead_check ?? 0,
                    'score_td'                  => $score_td ?? '-',



                    'working_hours_check'       => $goalsetteam->working_hours_check ?? 0,
                    'working_hours'             => $goalsetData[$member->sno]->working_hours ?? 0,
                    'working_hours_actual'      => $working_hoursActual ?? 0,

                    'rework_check'              => $goalsetteam->rework_check ?? 0,
                    'rework'                    => $goalsetData[$member->sno]->rework ?? 0,
                    'rework_actual'             => $rework_count ?? 0,
                ];
            }
        }
        // ##############################################################################################
        // ******************************** Journal Department ******************************************
        // ##############################################################################################
        if ($departmentId == 14) {
            $salesStaff = $staff;
            $no_of_papers_countActual = 0;
            $helper = new \App\Helpers\Helpers();
            foreach ($salesStaff as $member) {

                if (in_array($member->role_id, [33, 34])) {
                    $field = $member->role_id == 33 ? 'jc_id' : 'jc_staff';

                    // $pub_count = DB::table('et_customer_services')
                    //     ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                    //     ->whereYear('et_manage_journal.published_at', $year)
                    //     ->whereMonth('et_manage_journal.published_at', $month)
                    //     ->where('et_manage_journal.status', 6)
                    //     ->where("et_customer_services.{$field}", $member->sno)
                    //     ->count();

                    // $acp_count = DB::table('et_customer_services')
                    //     ->join('et_manage_journal', 'et_customer_services.sno', '=', 'et_manage_journal.service_id')
                    //     ->whereYear('et_manage_journal.accepted_at', $year)
                    //     ->whereMonth('et_manage_journal.accepted_at', $month)
                    //     ->where('et_manage_journal.status', 4)
                    //     ->where("et_customer_services.{$field}", $member->sno)
                    //     ->count();

                    // $no_of_papers_countActual += $pub_count + $acp_count;
                    $no_of_papers_countActual += DB::table('et_journal_history')
                        ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.service_id')
                        ->where('et_customer_services.jc_staff', $member->sno)
                        ->whereMonth('et_journal_history.created_at', $month)
                        ->whereYear('et_journal_history.created_at', $year)
                        ->where('et_journal_history.status', 8)
                        ->whereMonth('et_journal_history.published_date', $month)
                        ->count();
                }



                if (isset($goalsetData[$member->sno]->goal_completed)) {
                    if ($goalsetData[$member->sno]->goal_completed == 1) {
                        $no_of_papers_countActual = $goalsetData[$member->sno]->no_of_papers ?? 0;
                    }
                }

                $staffDetails2 = [
                    'no_of_papers'                    => $goalsetData[$member->sno]->no_of_papers ?? 0,
                    'no_of_papers_actual'             => $no_of_papers_countActual ?? 0,
                ];

                $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                $goal_achievements = false;
                $total_goal = 0;
                $tot_actual_value = 0;
                $actual_values = 0;
                $calvalues = [];

                if (isset($ten_x)) {
                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            $actual_values = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($key == 'rework') {
                                if ($actual_value >= $goal_value) {
                                    $actual_values = $goal_value;
                                }
                                $total_goal  += $goal_value;
                                $tot_actual_value  += $actual_values;
                            } else {
                                if ($actual_value <= $goal_value) {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $goal_value;
                                } else {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $actual_value;
                                }
                            }

                            $calvalues[] = [
                                'set' => $goal_value,
                                'act' =>  $actual_value,
                                'total_goal'  => $total_goal,
                                'tot_actual_value'  => $tot_actual_value,
                            ];
                        }
                    }

                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            if ($key = 'rework_10x') {
                                if ($goal_value > 0) {
                                    if ($actual_value > $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            } else {
                                if ($goal_value > 0) {
                                    if ($actual_value < $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                $goal_progres = $total_goal > 0 ? ($tot_actual_value / $total_goal) * 100 : 0;
                $goal_progress = round($goal_progres);
                $ratio = $goal_progress;
                if ($ratio > 100) {
                    $color = '#7854c7'; // Purple
                } elseif ($ratio >= 80) {
                    $color = '#34C759'; // Green
                } elseif ($ratio >= 40) {
                    $color = '#FFCC00'; // Yellow
                } else {
                    $color = '#FF3B30'; // Red
                }

                $currentMonth = $month;
                $currentYear  = $year;

                $startDate = Carbon::create($currentYear, $currentMonth, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

                $dayCounts = 0;
                $dateSrt = $startDate->copy();

                while ($dateSrt->lte($endDate)) {
                    if (!$dateSrt->isSunday()) {
                        $dayCounts++;
                    }
                    $dateSrt->addDay();
                }
                $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
                    ->where('branch_id', $branchId)
                    ->whereIn('attendance', ['P', 'HD'])
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->count();
                //  return $dayCounts;
                $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

                if ($presentDays == 0) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays > 0 && $presentDays < 50) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 50 && $presentDays < 75) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 75 && $presentDays < 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays == 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                }

                $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
                    . $heart .
                    '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';

                if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
                    $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
                } else {
                    $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
                    $staff_image = $helper->name_image($initial, $member->gender);
                }

                $staffDetails[] = [
                    'calvalues'                 => $calvalues,
                    'calc'                      => $tot_actual_value . '/' . $total_goal,
                    'sno'                       => $member->sno,
                    'staff_name'                => $member->staff_name,
                    'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
                    'goal_achievements'         => $goal_achievements,
                    'nick_name'                 => $member->nick_name,
                    'gender'                    => $member->gender,
                    'staff_image'               => $staff_image,
                    'department_name'           => $member->department_name,
                    'role_name'                 => $member->role_name,
                    'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
                    'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
                    'month'                     => $month_id,
                    'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,
                    'sales_lead_checks'         => $goalsetData[$member->sno]->sales_lead_check ?? 0,
                    'score_td'                  => $score_td ?? '-',

                    'no_of_papers_check'       => $goalsetteam->no_of_papers_check ?? 0,
                    'no_of_papers'             => $goalsetData[$member->sno]->no_of_papers ?? 0,
                    'no_of_papers_actual'      => $no_of_papers_countActual ?? 0,
                ];
            }
        }

        // ##############################################################################################
        // ******************************** CRE Department ***************************************
        // ##############################################################################################
        else if ($departmentId == 6) {

            $salesStaff = $staff;
            $helper     = new \App\Helpers\Helpers();
            $branchId   = $branch_id;

            $branch = BranchModel::where('sno', $branchId)
                ->where('status', 0)
                ->latest('sno')
                ->first();

            $gstPercent = $branch ? $branch->gst_percentage : 18;

            /* FINAL TOTALS */
            $collectionHarvestingAmount = 0; // Scheduled
            $collectedHarvestingAmount  = 0; // Paid
            $totalOutstandingAmount     = 0;

            $firstIds = DB::table('et_proposal_pay_slot')
                ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                ->where('et_proposal.status', 0)
                ->where('et_proposal_pay_slot.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->selectRaw('MIN(et_proposal_pay_slot.sno) as first_id')
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->pluck('first_id');

            foreach ($salesStaff as $member) {

                $userId = $member->sno;

                $paidInr = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.cre_id', $userId)
                    ->where('et_proposal.currency_id', 70)
                    ->where('et_proposal_pay_slot.paid_status', 1)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
                    ->sum('et_proposal_pay_slot.paidAmount');

                $paidInr = round($paidInr / (1 + ($gstPercent / 100)), 2);

                $paidNonInrRows = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.cre_id', $userId)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->where('et_proposal_pay_slot.paid_status', 1)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
                    ->get();

                $paidNonInr = 0;
                foreach ($paidNonInrRows as $row) {
                    $paidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
                }

                $paidNonInr = round($paidNonInr / (1 + ($gstPercent / 100)), 2);

                $totalPaid = $paidInr + $paidNonInr;

                $notPaidInr = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.cre_id', $userId)
                    ->where('et_proposal.currency_id', 70)
                    ->where('et_proposal_pay_slot.paid_status', 0)
                    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
                    ->sum('et_proposal_pay_slot.payable_amount');

                $notPaidInr = round($notPaidInr / (1 + ($gstPercent / 100)), 2);

                $notPaidNonInrRows = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.cre_id', $userId)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->where('et_proposal_pay_slot.paid_status', 0)
                    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
                    ->get();

                $notPaidNonInr = 0;
                foreach ($notPaidNonInrRows as $row) {
                    $notPaidNonInr += $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
                }

                $notPaidNonInr = round($notPaidNonInr / (1 + ($gstPercent / 100)), 2);

                $scheduled   = $totalPaid + $notPaidInr + $notPaidNonInr;
                $outstanding = $scheduled - $totalPaid;

                $collectionHarvestingAmount = $scheduled;
                $collectedHarvestingAmount  = $totalPaid;
                $totalOutstandingAmount     = $outstanding;


                $harvesting_percentage_countActual = round(
                    $collectionHarvestingAmount > 0
                        ? ($collectedHarvestingAmount / $collectionHarvestingAmount) * 100
                        : 0,
                    1
                );

                $outstandingPercentage = round(
                    $collectionHarvestingAmount > 0
                        ? ($totalOutstandingAmount / $collectionHarvestingAmount) * 100
                        : 0,
                    1
                );


                if (isset($goalsetData[$member->sno]->goal_completed)) {
                    if ($goalsetData[$member->sno]->goal_completed == 1) {
                        $harvesting_percentage_countActual = $goalsetData[$member->sno]->harvesting_percentage ?? 0;
                    }
                }

                $staffDetails2 = [
                    'harvesting_percentage'                    => $goalsetData[$member->sno]->harvesting_percentage ?? 0,
                    'harvesting_percentage_actual'             => $harvesting_percentage_countActual ?? 0,
                ];

                $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                $goal_achievements = false;
                $total_goal = 0;
                $tot_actual_value = 0;
                $actual_values = 0;
                $calvalues = [];

                if (isset($ten_x)) {
                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            $actual_values = $staffDetails2[$type2 . '_actual'] ?? 0;

                            if ($key == 'rework') {
                                if ($actual_value >= $goal_value) {
                                    $actual_values = $goal_value;
                                }
                                $total_goal  += $goal_value;
                                $tot_actual_value  += $actual_values;
                            } else {
                                if ($actual_value <= $goal_value) {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $goal_value;
                                } else {
                                    $total_goal  += $goal_value;
                                    $tot_actual_value  += $actual_value;
                                }
                            }

                            $calvalues[] = [
                                'set' => $goal_value,
                                'act' =>  $actual_value,
                                'total_goal'  => $total_goal,
                                'tot_actual_value'  => $tot_actual_value,
                            ];
                        }
                    }

                    foreach ($ten_x as $key => $value) {
                        $isChecked = $value === "1";
                        if ($isChecked) {
                            $type2 = str_replace("_10x", "", $key);
                            $goal_value = $staffDetails2[$type2] ?? 0;
                            $actual_value = $staffDetails2[$type2 . '_actual'] ?? 0;
                            if ($key = 'rework_10x') {
                                if ($goal_value > 0) {
                                    if ($actual_value > $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            } else {
                                if ($goal_value > 0) {
                                    if ($actual_value < $goal_value) {
                                        $goal_achievements = true; // Not Achieved
                                        break; // No need to continue checking if one goal failed
                                    }
                                } else {
                                    $goal_achievements = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                $goal_progres = $total_goal > 0 ? ($tot_actual_value / $total_goal) * 100 : 0;
                $goal_progress = round($goal_progres);
                $ratio = $goal_progress;
                if ($ratio > 100) {
                    $color = '#7854c7'; // Purple
                } elseif ($ratio >= 80) {
                    $color = '#34C759'; // Green
                } elseif ($ratio >= 40) {
                    $color = '#FFCC00'; // Yellow
                } else {
                    $color = '#FF3B30'; // Red
                }

                $currentMonth = $month;
                $currentYear  = $year;

                $startDate = Carbon::create($currentYear, $currentMonth, 1);
                $currentDate = Carbon::now();
                $endDate = ($currentDate->year == $currentYear && $currentDate->month == $currentMonth) ? $currentDate : $startDate->copy()->endOfMonth();

                $dayCounts = 0;
                $dateSrt = $startDate->copy();

                while ($dateSrt->lte($endDate)) {
                    if (!$dateSrt->isSunday()) {
                        $dayCounts++;
                    }
                    $dateSrt->addDay();
                }
                $presentDays = StaffAttendanceModel::where('staff_id', $member->sno)
                    ->where('branch_id', $branchId)
                    ->whereIn('attendance', ['P', 'HD'])
                    ->whereMonth('date', $month)
                    ->whereYear('date', $year)
                    ->count();
                //  return $dayCounts;
                $presentDays =  $dayCounts > 0 ? round(($presentDays / $dayCounts) * 100) : 0;

                if ($presentDays == 0) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_0.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays > 0 && $presentDays < 50) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_25.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 50 && $presentDays < 75) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_50.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays >= 75 && $presentDays < 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_75.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                } elseif ($presentDays == 100) {
                    $heart = '<img src="' . asset('assets/phdizone_images/staff_rate/h_100.png') . '" alt="user-avatar" class="image-input-wrapper w-20px h-20px" id="uploadedlogo" />';
                }

                $score_td = '<div class="d-flex align-items-center justify-content-between border rounded border-danger gap-1 px-2 py-1">
                    <div class="symbol symbol-35px cursor-pointer mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Ratio">'
                    . $heart .
                    '<div class="fs-8 fw-semibold text-center text-black">' . $presentDays . '%</div>
                    </div>
                    <div class="cursor-pointer">
                      <div class="progress border rounded h-15px w-60px mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Goalset Ratio">
                       <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: ' . $goal_progress . '%; background: ' . $color . ';"
                         aria-valuenow="' . $goal_progress . '" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <div class="fs-8 fw-semibold text-center text-black">' . $goal_progress . '%</div>
                    </div>
                    <div class="mb-0 text-center">
                      <div class="fs-8 fw-semibold text-dark">Points</div>
                      <div class="fs-8 fw-semibold text-black">
                        <label class="badge bg-danger fw-semibold fs-8">' . sprintf('%02d', $member->avaiable_points ?? 0) . '</label>
                      </div>
                    </div>
                  </div>';

                if ($member->staff_image != '' && file_exists(public_path('staff_images/' . $member->staff_image))) {
                    $staff_image = '<img src="' . asset('staff_images/' . $member->staff_image) . '" alt="Staff" class="w-px-40 h-auto rounded" />';
                } else {
                    $initial = strtoupper(substr($member->staff_name, 0, 1)); // Gets the first letter
                    $staff_image = $helper->name_image($initial, $member->gender);
                }

                $staffDetails[] = [
                    'calvalues'                 => $calvalues,
                    'calc'                      => $tot_actual_value . '/' . $total_goal,
                    'sno'                       => $member->sno,
                    'staff_name'                => $member->staff_name,
                    'ten_x'                     => json_decode(optional($goalsetteam)->ten_x ?? '{}', true),
                    'goal_achievements'         => $goal_achievements,
                    'nick_name'                 => $member->nick_name,
                    'gender'                    => $member->gender,
                    'staff_image'               => $staff_image,
                    'department_name'           => $member->department_name,
                    'role_name'                 => $member->role_name,
                    'team_id'                   => $goalsetData[$member->sno]->team_id ?? 0,
                    'status'                    => isset($goalsetData[$member->sno]) ? ($goalsetData[$member->sno]->status == 1 ? 'Goal Set' : 'Pending') : 'Pending',
                    'month'                     => $month_id,
                    'goal_completed'            => $goalsetData[$member->sno]->goal_completed ?? 0,
                    'sales_lead_checks'         => $goalsetData[$member->sno]->sales_lead_check ?? 0,
                    'score_td'                  => $score_td ?? '-',

                    'harvesting_percentage_check'       => $goalsetteam->harvesting_percentage_check ?? 0,
                    'harvesting_percentage'             => $goalsetData[$member->sno]->harvesting_percentage ?? 0,
                    'harvesting_percentage_actual'      => $harvesting_percentage_countActual ?? 0,
                ];
            }
        }

        return response()->json([
            'status' => 200,
            'data' => $staffDetails
        ]);
    }
}
