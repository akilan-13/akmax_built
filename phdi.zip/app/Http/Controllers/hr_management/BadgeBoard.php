<?php

namespace App\Http\Controllers\hr_management;

use App\Http\Controllers\Controller;
use App\Models\BadgeModel;
use App\Models\ManageExamModel;
use App\Models\StaffBadgeModel;
use Carbon\Carbon;
use DateInterval;
use DatePeriod;
use Google\Service\CloudSearch\Card;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use function PHPSTORM_META\map;

class BadgeBoard extends Controller
{
    public function index(Request $request) {
        $role_id = $request->user()->role_id;
        $user_id = $request->user()->user_id;
        $lists = BadgeModel::where('status', 0)->get();

        // Exam Badges Condition
        $exam_badges = ManageExamModel::where('et_manage_exam.role_id', $role_id)
            ->where('et_manage_exam.badge_check', 1)
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
            ->select('et_exam_badge.*', 'et_manage_exam.sno as exam_sno', 'et_manage_exam.pass_mark', 'et_manage_exam.positive_mark', 'et_manage_exam.negative_mark', 'et_manage_exam.exam_name')
            ->get();

        $examStatus = [];
        foreach($exam_badges as $exam) {
            $attempts = DB::table('et_exam_process')
                ->where('et_exam_process.exam_id', $exam->exam_sno)
                ->where('et_exam_process.staff_id', $user_id)
                ->where('status', '!=', 0)
                ->get();
            
            $label = 'No Attempts';
            foreach($attempts as $attempt) {
                if($attempt->status == 1) {
                    $label = 'Pending';
                    break;
                }
            }

            if($label != 'Pending') {
                foreach($attempts as $attempt) {
                    if($attempt->status == 2) {
                        $answerData = json_decode($attempt->exam_question_answers_datas, true);
                        $totalMarks = 0;
                        $negativeMarks = $exam->negative_mark;
                        $positiveMarks = $exam->positive_mark;

                        foreach($answerData as $answer) {
                            if(isset($answer['correctness'])) {
                                if($answer['correctness'] === 'correct') {
                                    $totalMarks += $positiveMarks;
                                } elseif($answer['correctness'] === 'incorrect') {
                                    $totalMarks -= $negativeMarks;
                                }
                            }
                        }

                        if($totalMarks < 0) {
                            $totalMarks = 0;
                        }

                        if($totalMarks >= $exam->pass_mark) {
                            $label = 'Achieved';
                        } else {
                            $label = 'Not Achieved';
                        }

                        break;
                    }
                }
            }

            $examStatus[$exam->exam_sno] = $label;
        }

        // Master Attendance Conditions
        $masterAttendance = [];
        $today = Carbon::today();
        foreach($lists as $list) {
            if($list->award_type == 1) {
                $startDate = null;
                $endDate = null;

                switch($list->eligibility_period) {
                    case 1:
                        $startDate = Carbon::parse($list->st_date);
                        $endDate = Carbon::parse($list->end_date);
                        break;

                    case 2:
                        $startDate = Carbon::parse('01-' . $list->st_month);
                        $endDate = Carbon::parse('01-' . $list->end_month)->endOfMonth();
                        break;

                    case 3:
                        $startDate = Carbon::create($list->start_year, 1, 1);
                        $endDate = Carbon::create($list->end_year, 12, 31);
                        break;
                    
                    default:
                        continue 2;
                }

                if($today->lte($endDate)) {
                    $attendanceStatus = 'Pending';
                } else {
                    $period = new DatePeriod(
                        $startDate,
                        new DateInterval('P1D'),
                        $endDate->copy()->addDay()
                    );

                    $totalDays = 0;
                    $presentDays = 0;

                    foreach($period as $date) {
                        if(in_array($date->format('N'), [6, 7])) continue;
                        $totalDays++;

                        $attendance = DB::table('et_staff_attendance')
                            ->where('staff_id', $user_id)
                            ->whereDate('date', $date)
                            ->where('attendance', 'P')
                            ->exists();

                        if($attendance) {
                            $presentDays++;
                        }                        
                    }

                    $attendanceStatus = ($totalDays > 0 && $presentDays == $totalDays) ? 'Achieved' : 'Not Achieved';
                }

                $masterAttendance[$list->sno] = $attendanceStatus;
            }
        }

        $pinnedBadges = StaffBadgeModel::where('status', '!=', 2)->where('created_by', $user_id)->first();
        $pinnedBadgeIds = [];
        $normalBadgeIds = [];

        if($pinnedBadges) {
            $pinnedBadgeIds = json_decode($pinnedBadges->exam_badge_ids, true);
            if (!empty($pinnedBadges->normal_badge_ids)) {
                $normalBadgeIds = json_decode($pinnedBadges->normal_badge_ids, true);
            }
        }

        return view('content.hr_management.badge_board', [
            'lists' => $lists,
            'examBadges' => $exam_badges,
            'examStatus' => $examStatus,
            'pinnedExamBadge' => $pinnedBadgeIds,
            'masterAttendance' => $masterAttendance,
            'normalBadgeIds' => $normalBadgeIds
        ]);
    }

    public function toggle_pin(Request $request) {
        $user_id = $request->user()->user_id;
        
        $badge = DB::table('et_staff_badges')
            ->where('staff_id', $user_id)
            ->where('sno', $request->sno)
            ->first();

        if(!$badge) {
            return response([
                'status' => 404,
                'message' => null,
                'error_msg' => "No Badges Found!",
                'data' => null
            ], 404);
        }

        DB::table('et_staff_badges')
            ->where('staff_id', $user_id)
            ->where('sno', $request->sno)
            ->update([
                'pin_status' => $request->pinned ? 1 : 0,
                'updated_by' => $user_id 
            ]);

        return response()->json([
            'status' => 200,
            'message' => $request->pinned ? "Badge Pinned Successfully!" : "Badge Unpinned Successfully!"
        ]);
    }

    // public function badge_board_data(Request $request)
    // {
    //     $user_id = $request->user()->user_id;
    //     $role_id = $request->user()->role_id;

    //     // Sync badges first
    //     $this->sync_badges($user_id);

    //     // Get all exams with badges that match user's role
    //     $all_exam_badges = DB::table('et_manage_exam')
    //         ->select(
    //             'et_manage_exam.sno as exam_id',
    //             'et_manage_exam.exam_name',
    //             'et_manage_exam.badge',
    //             'et_manage_exam.role_id',
    //             'et_exam_badge.badge_name',
    //             'et_exam_badge.badge_image',
    //             'et_exam_badge.badge_desc',
    //             'et_exam_category.category_name',
    //             'et_exam_badge.sno as badge_sno'
    //         )
    //         ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
    //         ->leftJoin('et_exam_category', 'et_exam_badge.exam_cat_id', '=', 'et_exam_category.sno')
    //         ->where('et_manage_exam.badge_check', 1) // Check if exam has badge
    //         ->where('et_manage_exam.badge', '!=', null)
    //         ->where('et_manage_exam.status', 0)
    //         ->get()
    //         ->filter(function ($exam) use ($role_id) {
    //             // Check if user's role_id exists in the role_id array
    //             $roleIds = json_decode($exam->role_id ?? '[]', true) ?? [];
    //             return in_array($role_id, $roleIds);
    //         })
    //         ->values();

    //     // Get badges achieved by staff
    //     $achieved_badges = DB::table('et_exam_staff_badges')
    //         ->select(
    //             'et_exam_staff_badges.sno',
    //             'et_exam_staff_badges.pin_sts',
    //             'et_manage_exam.exam_name',
    //             'et_manage_exam.badge',
    //             'et_exam_badge.badge_name',
    //             'et_exam_badge.badge_image',
    //             'et_exam_badge.badge_desc',
    //             'et_exam_category.category_name',
    //             'et_staff_badges.sno as staff_badge_id',
    //             'et_staff_badges.pin_status',
    //             'et_staff_badges.badge_type',
    //             'et_exam_badge.sno as badge_sno'
    //         )
    //         ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_exam_staff_badges.exam_id')
    //         ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
    //         ->leftJoin('et_exam_category', 'et_exam_badge.exam_cat_id', '=', 'et_exam_category.sno')
    //         ->leftJoin('et_staff_badges', function ($join) use ($user_id) {
    //             $join->on('et_staff_badges.badge_id', '=', 'et_manage_exam.badge')
    //                 ->where('et_staff_badges.staff_id', '=', $user_id)
    //                 ->where('et_staff_badges.badge_type', '=', 0);
    //         })
    //         ->where('et_exam_staff_badges.staff_id', $user_id)
    //         ->where('et_exam_staff_badges.status', 0)
    //         ->get();

    //     // Format achieved badges
    //     $groupedBadges = $achieved_badges
    //         ->groupBy('badge')
    //         ->map(function ($group) {
    //             $first = $group->first();
    //             return [
    //                 'id'         => $first->staff_badge_id,
    //                 'name'       => $first->badge_name ?? 'Unknown Badge',
    //                 'type'       => $first->exam_name ?? 'Unknown Type',
    //                 'badge_type' => $first->badge_type ?? 0,
    //                 'image'      => $first->badge_image
    //                     ? asset("exam/badges/{$first->badge_image}")
    //                     : null,
    //                 'category'   => $first->category_name ?? '',
    //                 'desc'       => $first->badge_desc,
    //                 'status'     => 'Achieved',
    //                 'pinned'     => ($first->pin_status ?? 0) == 1,
    //                 'count'      => str_pad($group->count(), 2, '0', STR_PAD_LEFT),
    //             ];
    //         })
    //         ->values();

    //     // Format missed badges in the same structure as achieved badges
    //     $missedBadges = $all_exam_badges
    //         ->filter(function ($available_badge) use ($achieved_badges) {
    //             // Check if this badge is not in achieved badges
    //             return !$achieved_badges->contains(function ($achieved_badge) use ($available_badge) {
    //                 return $achieved_badge->badge_sno == $available_badge->badge_sno;
    //             });
    //         })
    //         ->groupBy('badge')
    //         ->map(function ($group) {
    //             $first = $group->first();
    //             return [
    //                 'id'         => null, // No staff badge ID for missed badges
    //                 'name'       => $first->badge_name ?? 'Unknown Badge',
    //                 'type'       => $first->exam_name ?? 'Unknown Type',
    //                 'badge_type' => 0, // Default badge type for missed badges
    //                 'image'      => $first->badge_image
    //                     ? asset("exam/badges/{$first->badge_image}")
    //                     : null,
    //                 'category'   => $first->category_name ?? '',
    //                 'desc'       => $first->badge_desc,
    //                 'status'     => 'Not Achieved',
    //                 'pinned'     => false, // Missed badges cannot be pinned
    //                 'count'      => '00', // Default count for missed badges
    //             ];
    //         })
    //         ->values();

    //     return response([
    //         'status' => 200,
    //         'message' => 'Badge Fetched Successfully!',
    //         'error_msg' => null,
    //         'data' => $groupedBadges,
    //         'missed' => $missedBadges
    //     ], 200);
    // }
    
    public function badge_board_data(Request $request)
    {
        $user_id = $request->user()->user_id;
        $role_id = $request->user()->role_id;

        // Sync badges first
        $this->sync_badges($user_id);

        // Get all exams with badges that match user's role
        $all_exam_badges = DB::table('et_manage_exam')
            ->select(
                'et_manage_exam.sno as exam_id',
                'et_manage_exam.exam_name',
                'et_manage_exam.badge',
                'et_manage_exam.role_id',
                'et_exam_badge.badge_name',
                'et_exam_badge.badge_image',
                'et_exam_badge.badge_desc',
                'et_exam_category.category_name',
                'et_exam_badge.sno as badge_sno'
            )
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
            ->leftJoin('et_exam_category', 'et_exam_badge.exam_cat_id', '=', 'et_exam_category.sno')
            ->where('et_manage_exam.badge_check', 1)
            ->whereNotNull('et_manage_exam.badge')
            ->where('et_manage_exam.status', 0)
            ->get()
            ->filter(function ($exam) use ($role_id) {
                $roleIds = json_decode($exam->role_id ?? '[]', true) ?? [];
                return in_array($role_id, $roleIds);
            })
            ->values();

        // Get badges achieved by staff
        $achieved_badges = DB::table('et_exam_staff_badges')
            ->select(
                'et_exam_staff_badges.sno',
                'et_exam_staff_badges.pin_sts',
                'et_manage_exam.exam_name',
                'et_manage_exam.badge',
                'et_exam_badge.badge_name',
                'et_exam_badge.badge_image',
                'et_exam_badge.badge_desc',
                'et_exam_category.category_name',
                'et_staff_badges.sno as staff_badge_id',
                'et_staff_badges.pin_status',
                'et_staff_badges.badge_type',
                'et_exam_badge.sno as badge_sno'
            )
            ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_exam_staff_badges.exam_id')
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
            ->leftJoin('et_exam_category', 'et_exam_badge.exam_cat_id', '=', 'et_exam_category.sno')
            ->leftJoin('et_staff_badges', function ($join) use ($user_id) {
                $join->on('et_staff_badges.badge_id', '=', 'et_manage_exam.badge')
                    ->where('et_staff_badges.staff_id', '=', $user_id)
                    ->where('et_staff_badges.badge_type', '=', 0);
            })
            ->where('et_exam_staff_badges.staff_id', $user_id)
            ->where('et_exam_staff_badges.status', 0)
            ->get();

        // Format achieved badges
        $groupedBadges = $achieved_badges
            ->groupBy('badge')
            ->map(function ($group) {
                $first = $group->first();
                return [
                    'id'         => $first->staff_badge_id,
                    'name'       => $first->badge_name ?? 'Unknown Badge',
                    'type'       => $first->exam_name ?? 'Unknown Type',
                    'badge_type' => $first->badge_type ?? 0,
                    'image'      => $first->badge_image ? asset("exam/badges/{$first->badge_image}") : null,
                    'category'   => $first->category_name ?? '',
                    'desc'       => $first->badge_desc,
                    'status'     => 'Achieved',
                    'pinned'     => ($first->pin_status ?? 0) == 1,
                    'count'      => str_pad($group->count(), 2, '0', STR_PAD_LEFT),
                ];
            })
            ->values();

        // Handle missed or partially achieved badges
        $all_exam_badges_by_sno = $all_exam_badges->groupBy('badge');

        $missedBadgesWithBalance = $all_exam_badges_by_sno->map(function ($group, $badge_sno) use ($achieved_badges) {
            $totalCount = $group->count(); // total exams assigned for this badge
            $achievedCount = $achieved_badges->where('badge_sno', $badge_sno)->count(); // achieved instances
            $remainingCount = $totalCount - $achievedCount;

            if ($remainingCount <= 0) {
                return null; // fully achieved, nothing to show
            }

            $first = $group->first();
            return [
                'id'         => null, // no staff badge ID for missed instances
                'name'       => $first->badge_name ?? 'Unknown Badge',
                'type'       => $first->exam_name ?? 'Unknown Type',
                'badge_type' => 0,
                'image'      => $first->badge_image ? asset("exam/badges/{$first->badge_image}") : null,
                'category'   => $first->category_name ?? '',
                'desc'       => $first->badge_desc,
                'status'     => 'Not Achieved',
                'pinned'     => false,
                'count'      => str_pad($remainingCount, 2, '0', STR_PAD_LEFT),
            ];
        })->filter()->values();

        return response([
            'status' => 200,
            'message' => 'Badge Fetched Successfully!',
            'error_msg' => null,
            'data' => $groupedBadges,          // Achieved badges
            'missed' => $missedBadgesWithBalance, // Remaining / Not Achieved badges
        ], 200);
    }


    public function update_nav_badges(Request $request)
    {
        $user_id = $request->user()->user_id;

        // Sync badges before fetching
        $this->sync_badges($user_id);

        // Fetch badges achieved by staff
        $achieved_badges = DB::table('et_exam_staff_badges')
            ->select(
                'et_exam_staff_badges.sno',
                'et_exam_staff_badges.pin_sts',
                'et_manage_exam.exam_name',
                'et_manage_exam.badge',
                'et_exam_badge.badge_name',
                'et_exam_badge.badge_image',
                'et_exam_badge.badge_desc',
                'et_exam_category.category_name',
                'et_staff_badges.sno as staff_badge_id',
                'et_staff_badges.pin_status',
                'et_staff_badges.badge_type',
                'et_exam_badge.sno as badge_sno'
            )
            ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_exam_staff_badges.exam_id')
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_manage_exam.badge')
            ->leftJoin('et_exam_category', 'et_exam_badge.exam_cat_id', '=', 'et_exam_category.sno')
            ->leftJoin('et_staff_badges', function ($join) use ($user_id) {
                $join->on('et_staff_badges.badge_id', '=', 'et_manage_exam.badge')
                    ->where('et_staff_badges.staff_id', $user_id)
                    ->where('et_staff_badges.badge_type', 0);
            })
            ->where('et_exam_staff_badges.staff_id', $user_id)
            ->where('et_exam_staff_badges.status', 0)
            ->get();

        // Group badges by badge ID and format
        $groupedBadges = $achieved_badges
            ->groupBy('badge')
            ->map(function ($group) {
                $first = $group->first();
                return [
                    'id'         => $first->staff_badge_id,
                    'name'       => $first->badge_name ?? 'Unknown Badge',
                    'type'       => $first->exam_name ?? 'Unknown Type',
                    'badge_type' => $first->badge_type ?? 0,
                    'image'      => $first->badge_image ? asset("exam/badges/{$first->badge_image}") : null,
                    'category'   => $first->category_name ?? '',
                    'desc'       => $first->badge_desc ?? '',
                    'status'     => 'Achieved',
                    'pinned'     => ($first->pin_status ?? 0) == 1,
                    'count'      => str_pad($group->count(), 2, '0', STR_PAD_LEFT),
                ];
            })
            ->values();

        return response([
            'status' => 200,
            'message' => 'Badges Fetched Successfully!',
            'error_msg' => null,
            'data' => $groupedBadges
        ], 200);
    }



    protected function sync_badges($user_id)
    {
        // ! Exam Badges
        $exam_badges = DB::table('et_exam_staff_badges')
            ->select(
                'et_exam_staff_badges.exam_id',
                'et_manage_exam.badge'
            )
            ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_exam_staff_badges.exam_id')
            ->where('et_exam_staff_badges.staff_id', $user_id)
            ->where('et_exam_staff_badges.status', 0)
            ->whereNotNull('et_manage_exam.badge') // Only where badge exists
            ->get();

        foreach ($exam_badges as $exam) {
            $exist = DB::table('et_staff_badges')
                ->where('staff_id', $user_id)
                ->where('badge_id', $exam->badge)
                ->where('badge_type', 0)
                ->first();

            if (!$exist) {
                DB::table('et_staff_badges')->insert([
                    'staff_id' => $user_id,
                    'badge_type' => 0,
                    'badge_id' => $exam->badge,
                    'pin_status' => 1,
                    'created_by' => $user_id,
                    'updated_by' => $user_id,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
            }
        }

        return true;
    }
    public function get_nav_points(Request $request) {
        $user_id = $request->user()->user_id;
    
        // Exam-based points
        $history = DB::table('et_staff_exam_points')
            ->leftJoin('et_exam_badge', 'et_exam_badge.sno', '=', 'et_staff_exam_points.badge_id')
            ->leftJoin('et_manage_exam', 'et_manage_exam.sno', '=', 'et_staff_exam_points.badge_id')
            ->where('et_staff_exam_points.staff_id', $user_id)
            ->where('et_exam_badge.prize_id', 2)
            ->where('et_exam_badge.status', 0)
            ->where('et_staff_exam_points.status', 0)
            ->where('et_manage_exam.status', 0)
            ->select(
                'et_staff_exam_points.points',
                'et_staff_exam_points.created_at',
                DB::raw("'Assessment' as type"),
                'et_manage_exam.exam_name as name'
            )
            ->get();
    
        // Manual staff points
        $history2 = DB::table('et_staff_points')
            ->leftJoin('et_points', 'et_staff_points.points_id', '=', 'et_points.sno')
            ->where('et_staff_points.staff_id', $user_id)
            ->where('et_staff_points.status', 0)
            ->where('et_points.status', 0)
            ->select(
                'et_staff_points.points',
                'et_staff_points.created_at',
                DB::raw("'General' as type"),
                'et_points.points_name as name'
            )
            ->get();
    
        // Merge both collections
        $merged = $history->merge($history2);
    
        // Sort by created_at descending (optional but nice for display)
        $sorted = $merged->sortByDesc('created_at')->values();
    
        // Total points
        $total_points = $merged->sum('points');
        $exam_count = $history->count();
    
        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully!',
            'error_msg' => null,
            'data' => $sorted,
            'total_points' => $total_points,
            'exam_counts' => $exam_count
        ], 200);
    }
}
