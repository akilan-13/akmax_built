<?php
namespace App\Http\Controllers\WebHookHandler;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel; // sub-epr model (set primaryKey sno)
use App\Models\DepartmentModel; 
use App\Models\DivisionModel; 
use App\Models\JobpositionModel; 
use App\Models\StaffModel; 
use App\Models\StaffAttendanceModel; 
use App\Models\User; 
use App\Models\StaffWorkInfoModel; 
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\UserRolePermissionModel;
use App\Events\StaffExistUpdated;


class WebhookReceiverController extends Controller
{

    // public function broadcastMessageOld(Request $request)
    // {
    //     // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
    //     $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

    //     // use updateOrCreate by external uuid (make sure broadcast table has external_uuid column)
    //     $payload = $request->all();
    //     $payload['external_uuid'] = $uuid;

    //     $up = NewsBroadcastModel::updateOrCreate(
    //         ['external_uuid' => $uuid],
    //         array_merge($payload, ['updated_by' => 0])
    //     );

    //     return response()->json(['ok' => true, 'sno' => $up->sno], 200);
    // }

    //  public function broadcastMessage(Request $request)
    // {
    //     try {
    //         //  Step 1: Normalize payload (handles malformed input)
    //         $raw = $request->all();

    //         if (isset($raw[0]) && is_string($raw[0])) {
    //             $payload = json_decode($raw[0], true);

    //             if (json_last_error() !== JSON_ERROR_NONE) {
    //                 return response()->json([
    //                     'ok' => false,
    //                     'message' => 'Invalid JSON payload'
    //                 ], 400);
    //             }
    //         } else {
    //             $payload = $raw;
    //         }

    //         // Step 2: UUID handling (priority order)
    //         $uuid = $request->header('X-IDEMPOTENCY-KEY')
    //             ?? $payload['external_uuid']
    //             ?? $payload['uuid']
    //             ?? (string) \Illuminate\Support\Str::uuid();

    //         //  Step 3: Prepare data safely
    //         $data = [
    //             'external_uuid'     => $uuid,
    //             'template_name'     => $payload['template_name'] ?? '',
    //             'broadcast_message'=> $payload['broadcast_message'] ?? '',
    //             'branch_id'        => $payload['branch_id'] ?? null,
    //             'role_ids'         => $payload['role_ids'] ?? null,
    //             'start_date'       => $payload['start_date'] ?? null,
    //             'end_date'         => $payload['end_date'] ?? null,
    //             'information'      => $payload['information'] ?? null,
    //             'theme_id'         => $payload['theme_id'] ?? null,
    //             'theme_style'      => $payload['theme_style'] ?? null,
    //             'created_by'       => $payload['created_by'] ?? 1, // fallback
    //             'updated_by'       => $payload['updated_by'] ?? 1,
    //             'status'           => 0,
    //             'updated_at'       => now(),
    //         ];

    //         //  Step 4: Insert or Update
    //         DB::table('et_news_broadcast')->updateOrInsert(
    //             ['external_uuid' => $uuid],
    //             $data
    //         );

    //         //  Step 5: Get inserted/updated record ID
    //         $record = DB::table('et_news_broadcast')
    //             ->where('external_uuid', $uuid)
    //             ->first();

    //         return response()->json([
    //             'ok' => true,
    //             'sno' => $record->sno ?? null
    //         ], 200);

    //     } catch (\Exception $e) {
    //         //  Production-safe error handling
    //         \Log::error('Broadcast Webhook Error', [
    //             'error' => $e->getMessage(),
    //             'payload' => $request->all()
    //         ]);

    //         return response()->json([
    //             'ok' => false,
    //             'message' => 'Something went wrong'
    //         ], 500);
    //     }
    // }


    public function broadcastMessage(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                
            $updateBroadcast = NewsBroadcastModel::updateOrCreate(
                ['external_uuid' => $payload['sno']],
                [

                    'template_name' => $payload['template_name'] ?? NULL,
                    'broadcast_message' => $payload['broadcast_message'] ?? NULL,
                    'branch_id' => $payload['branch_id'] ?? NULL,
                    'role_ids' => $payload['role_ids'] ?? NULL,
                    'start_date' => $payload['start_date'] ?? NULL,
                    'end_date' => $payload['end_date'] ?? NULL,
                    'information' => $payload['information'] ?? NULL,
                    'theme_id' => $payload['theme_id'] ?? 0,
                    'theme_style' => $payload['theme_style'] ?? NULL,
                    'created_by' => $request->user()->user_id ?? 0,
                    'updated_by' => $request->user()->user_id ?? 0,
                ]
            );

           

            return response()->json([
                'ok' => true,
                'sno' => $updateBroadcast->sno,
            ], 200);
        }
    
   
        public function existStaffCount()
        {
            $count = StaffModel::where('is_exist_egc', '!=',0)
                ->where('status', 1)
                ->count();

            return response()->json([
                'count' => $count
            ]);
        }

       public function existStaffList()
    {
        $staff = StaffModel::where('et_staff.is_exist_egc','!=',0)
            ->where('et_staff.status', 1)
            ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
            ->select(
                'et_staff.staff_name',
                'et_staff.sno as id',
                'et_staff.staff_image',
                'et_staff.is_exist_egc',
                'et_staff.staff_last_date',
                'et_staff.notice_start_date',
                'et_staff.notice_end_date',
                'et_staff.dep_reason',
                'et_department.department_name',
                'et_job_position.job_position_name'
            )
            ->get();

        return response()->json($staff);
    }
    
    // Deparment Webhook Start
    public function DepartmentList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
       $departmentList=DB::table('et_department')
       ->select('et_department.*')
       ->where('et_department.entity_id',1)
       ->where('et_department.status',0)
       ->get();
       $lastId = DB::table('et_department')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function DepartmentHook(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $department = DepartmentModel::updateOrCreate(
            ['external_uuid' => $uuid],  
            [
                'department_id'    => $payload['department_id'] ?? null,
                'entity_id'        => 1,
                'branch_id'        =>  1,
                'department_name'  => $payload['department_name'],
                'department_desc'  => $payload['department_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );

        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'uuid' => $uuid,
        ], 200);
    }

    public function UpdateDepartmentUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_department_id'];
        if($erpId){
            $department = DepartmentModel::where('sno', $erpId)->first();

            if ($department) {
                $department->external_uuid = $uuid;
                $department->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'department Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'department id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }
    // Deparment Webhook End


    
     // Division Webhook Start
    public function DivisionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $depart_id = $request->department_id;
        // return $depart_id;
       $departmentList=DB::table('et_division')
       ->select('et_division.*');
       if($depart_id){
         $departmentList->where('et_division.department_id',$depart_id);
       }
       
       $departmentList=$departmentList->where('et_division.status',0)
       ->get();
       $lastId = DB::table('et_division')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

     public function DivisionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();

        $department = DivisionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'department_id'    => $payload['erp_department_id'], 
                'entity_id'        => 1,
                'branch_id'        => 1,
                'division_name'  => $payload['division_name'],
                'division_desc'  => $payload['division_desc'] ?? null,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }

     public function UpdateDivisionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_division_id'];
        if($erpId){
            $division = DivisionModel::where('sno', $erpId)->first();

            if ($division) {
                $division->external_uuid = $uuid;
                $division->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Division Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Division id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $division->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Division Webhook End

    // Job Position Webhook Start
    public function JobPostionList(Request $request){

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        
        $division_id = $request->division_id;
        // return $depart_id;
       $departmentList=DB::table('et_job_position')
       ->select('et_job_position.*');
       if($division_id){
         $departmentList->where('et_job_position.division_id',$division_id);
       }
       $departmentList=$departmentList->where('et_job_position.status',0)
       ->get();
       $lastId = DB::table('et_job_position')
        ->orderBy('sno', 'desc')   
        ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1; 
       return response()->json(['status' => 200, 'data' => $departmentList,'nextId' =>$nextId], 200);
    }

    public function JobPositionHook(Request $request)
    {
        // optional: verify signature & timestamp using env('WEBHOOK_SECRET')
        $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();

         $payload = $request->all();
         
         $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

            if (!$category_check) {
    
              $year = substr(date("y"), -2);
              $job_position_id = "JP-0001/" . $year;
            } else {
    
              $data = $category_check->job_position_id;
              $slice = explode("/", $data);
              $result = preg_replace('/[^0-9]/', '', $slice[0]);
    
              $next_number = (int) $result + 1;
              $request = sprintf("JP-%04d", $next_number);
    
              $year = substr(date("y"), -2);
              $job_position_id = $request . '/' . $year;
            }

        $department = JobpositionModel::updateOrCreate(
            ['external_uuid' => $uuid],  // ✅ match by UUID, not ERP id
            [
                'job_position_id'    => $job_position_id, 
                'department_id'    => $payload['erp_department_id'], 
                'division_id'    => $payload['erp_division_id'], 
                'branch_id'        => 1,
                'job_position_name'  => $payload['job_position_name'],
                'job_position_desc'  => $payload['job_position_desc'] ?? null,
                'per_hour_cost'  => $payload['per_hour_cost'] ?? 0,
                'created_by'       => 1,
                'updated_by'       => 1
            ]
        );
    
        return response()->json([
            'ok'  => true,
            'sno' => $department->sno, // auto-increment from your DB
        ], 200);
    }
    public function UpdateJobPositionUUID(Request $request)
    {
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        $erpId = $payload['erp_job_role_id'];
        if($erpId){
            $jobPosition = JobpositionModel::where('sno', $erpId)->first();

            if ($jobPosition) {
                $jobPosition->external_uuid = $uuid;
                $jobPosition->save();
            }else{
                return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position Not Found',
                'uuid' => $uuid,
            ], 200);
            }
        }else{
            return response()->json([
                'ok'  => true,
                'meassage'=>'Job Position id Not Found',
                'uuid' => $uuid,
            ], 200);
        }
        return response()->json([
            'ok'  => true,
            'sno' => $jobPosition->sno,
            'meassage'=>'external uuid updated',
            'uuid' => $uuid,
        ], 200);
    }

    // Job Position Webhook End

    

    // UserRole Webhook Start
    public function userRoleList(Request $request)
    {
        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }

        $departmentList = DB::table('et_user_role')
            ->select('et_user_role.*')
            ->where('et_user_role.entity_id', 1)
            ->where('et_user_role.status', 0)
            ->get();

        $lastId = DB::table('et_user_role')
            ->orderBy('sno', 'desc')
            ->value('sno');

        $nextId = $lastId ? $lastId + 1 : 1;

        return response()->json([
            'status' => 200,
            'data' => $departmentList,
            'nextId' => $nextId
        ], 200);
    }

    public function UpdateUserRoleUUID(Request $request)
    {
        // Get UUID (idempotency key or generate a new UUID if not provided)
        $uuid = $request->header('X-IDEMPOTENCY-KEY') 
            ?? $request->input('uuid') 
            ?? (string) Str::uuid();

        $payload = $request->all();

        // Get the erp_role_id from the payload
        $erpId = $payload['erp_role_id'] ?? null;

        if ($erpId) {
            // Find the user role by erp_role_id
            $userRole = DB::table('et_user_role')->where('sno', $erpId)->first();

            if ($userRole) {
                // Update the external_uuid for the found user role
                DB::table('et_user_role')
                    ->where('sno', $erpId)
                    ->update(['external_uuid' => $uuid]);

                return response()->json([
                    'ok' => true,
                    'sno' => $userRole->sno,
                    'message' => 'External UUID updated successfully',
                    'uuid' => $uuid,
                ], 200);
            } else {
                // If user role is not found
                return response()->json([
                    'ok' => false,
                    'message' => 'User Role not found',
                    'uuid' => $uuid,
                ], 200); // Use 404 for not found error
            }
        } else {
            // If erp_role_id is not provided
            return response()->json([
                'ok' => false,
                'message' => 'User Role ID not provided',
                'uuid' => $uuid,
            ], 200); // Use 400 for bad request error
        }
    }
    // UserRole Webhook End
  
    // Staff Webhook Start 

        public function StaffData(Request $request){

            $auth_key = $request->auth_key;
            $verify_key = 'egcsecret2030datagetapierp';

            if ($auth_key !== $verify_key) {
                return response()->json([
                    'status' => 410,
                    'data' => null,
                    'message' => 'Unauthorized Entry'
                ], 410);
            }

            $staffdata=DB::table('et_staff')
                ->select('et_staff.*','et_department.department_name','et_division.division_name','et_user_role.role_name')
                ->where('et_staff.branch_id',1)
                ->join('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                ->join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
                ->join('et_user_role', 'et_user_role.sno', '=', 'et_staff.role_id')
                ->where('et_staff.status',0)
                ->where('et_staff.sno','>',1)
                ->where('et_staff.department_id','!=',10)
                ->get();
            
            foreach($staffdata as $staff){
                if($staff->staff_image){
                    $staff->staff_image= url('staff_images/' . $staff->staff_image);
                }else{
                    $staff->staff_image='';
                }
                $staff->staff_work_info=[];
                if($staff->exp_type == 2){
                    $WorkDetails = StaffWorkInfoModel::where('staff_id', $staff->sno)->where('status',0)
                            ->get();
                    $staff->staff_work_info = $WorkDetails ?? [];
                }
                
            }
            
            return response()->json(['status' => 200, 'data' => $staffdata], 200);
        }
    
        public function StaffAddHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }

                // Log the decoded payload
                \Log::info('Decoded Payload:', $payload);

                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }

                // Check if mobile number exists
                if (empty($payload['mobile_no'])) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile number is missing'
                    ], 400);
                }

                // Check if mobile number already exists
                $existingStaff = StaffModel::where('mobile_no', $payload['mobile_no'])->first();
                if ($existingStaff) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Mobile Number already exists'
                    ], 200);
                }

                // Handle staff image upload (if any)
                $staff_image_url = $payload['staff_image'] ?? null;
                $staff_image = null;

                if ($staff_image_url) {
                    $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION) ?: 'jpg';
                    $folderPath = public_path("staff_images");

                    // Create directory if it doesn't exist
                    if (!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, 0777, true, true);
                    }

                    // Find the next available image number
                    $existingFiles = File::files($folderPath);
                    $maxNumber = 0;
                    foreach ($existingFiles as $file) {
                        if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                            $num = (int) $matches[1];
                            if ($num > $maxNumber) $maxNumber = $num;
                        }
                    }
                    $nextNumber = $maxNumber + 1;
                    $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
                    $savePath = $folderPath . '/' . $staff_image_name;

                    // Save image
                    try {
                        $imageData = @file_get_contents($staff_image_url);
                        if ($imageData !== false) {
                            file_put_contents($savePath, $imageData);
                            $staff_image = $staff_image_name;
                        }
                    } catch (\Exception $e) {
                        $staff_image = null;
                    }
                }

            // Create or update staff record based on UUID
            $add_staff = StaffModel::updateOrCreate(
                ['external_uuid' => $uuid],
                [
                    'staff_id' => $payload['staff_id'],
                    'branch_id' => 1,
                    'entity_id' => 1,
                    'shift_time_id' => 1,
                    'multi_branch_access' => null,
                    'sub_department_id' => $payload['sub_department_id'] ?? 0,
                    'department_id' => $payload['department_id'] ?? 0,
                    'role_id' => $payload['role_id'],
                    'exp_type' => $payload['exp_type'],
                    'staff_name' => $payload['staff_name'],
                    'mobile_no' => $payload['mobile_no'],
                    'alternative_no' => $payload['alternative_no'] ?? null,
                    'email_id' => $payload['email_id'],
                    'gender' => $payload['gender'],
                    'dob' => $payload['dob'],
                    'date_of_joining' => $payload['date_of_joining'],
                    'contact_person_name' => $payload['contact_person_name'] ?? null,
                    'contact_person_no' => $payload['contact_person_no'] ?? null,
                    'martial_status' => $payload['martial_status'],
                    'address' => $payload['address'] ?? null,
                    'staff_image' => $staff_image ?? null,
                    'attachment' => !empty($payload['attachment'])? json_encode($payload['attachment']): json_encode([]),
                    'nick_name' => $payload['nick_name'] ?? null,
                    'position_role' => $payload['position_role'] ?? null,
                    'description' => $payload['description'] ?? null,
                    'basic_salary' => $payload['basic_salary'] ?? null,
                    'per_hour_cost' => $payload['per_hour_cost'] ?? null,
                    'login_access' => $payload['login_access'] ?? 0,
                    'employee_skill_id' => 1, // Default value for now
                    'user_name' => $payload['user_name'],
                    'password' => $payload['password'],
                    'created_by' => $request->user()->user_id ?? 1,
                    'updated_by' => $request->user()->user_id ?? 1,
                ]
            );

            if ($add_staff) {
                // Create user credentials if not exists
                $existingUser = User::where('user_id', $add_staff->sno)->first();
                if (!$existingUser) {
                    if($payload['login_access'] == 1){
                    User::create([
                        'user_id' => $add_staff->sno,
                        'role_id' => $add_staff->role_id ?? 0,
                        'branch_id' => $add_staff->branch_id,
                        'entity_id' => $add_staff->entity_id,
                        'name' => $add_staff->user_name,
                        'password' => Hash::make($add_staff->password),
                        'email' => $add_staff->email_id,
                        'created_by' => $request->user()->user_id ?? 1,
                        'updated_by' => $request->user()->user_id ?? 1,
                    ]);
                    }
                }

                // Handle work experience (if applicable)
                if ($payload['exp_type'] == 2 && !empty($payload['work_company_name'])) {
                    foreach ($payload['work_company_name'] as $key => $company) {
                        // Avoid duplicate work entries for same staff
                        $existingWork = StaffWorkInfoModel::where('staff_id', $add_staff->sno)
                            ->where('company_name', $company)
                            ->where('position', $payload['work_position'][$key] ?? '')
                            ->first();

                        if (!$existingWork) {
                            StaffWorkInfoModel::create([
                                'staff_id' => $add_staff->sno,
                                'staff_type' => $payload['exp_type'],
                                'position' => $payload['work_position'][$key] ?? null,
                                'year_of_experience' => $payload['work_exp_yrs'][$key] ?? 0,
                                'company_name' => $company,
                                'work_start_date' => isset($payload['work_st_date'][$key]) ? date('Y-m-d', strtotime($payload['work_st_date'][$key])) : null,
                                'work_end_date' => isset($payload['work_end_date'][$key]) ? date('Y-m-d', strtotime($payload['work_end_date'][$key])) : null,
                                'created_by' => $request->user()->user_id ?? 1,
                                'updated_by' => $request->user()->user_id ?? 1,
                            ]);
                        }
                    }
                }
            }

            return response()->json([
                'ok' => true,
                'sno' => $add_staff->sno,
            ], 200);
        }

        public function UpdateStaffUUID(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) Str::uuid();

            $payload = $request->all();

            $erpId = $payload['erp_staff_id'];
            if($erpId){
                $staff = StaffModel::where('sno', $erpId)->first();

                if ($staff) {
                    $staff->external_uuid = $uuid;
                    $staff->save();
                }else{
                    return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff Not Found',
                    'uuid' => $uuid,
                ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }
            return response()->json([
                'ok'  => true,
                'sno' => $staff->sno,
                'meassage'=>'external uuid updated',
                'uuid' => $uuid,
            ], 200);
        }

        public function UpdateExistStaff(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY') 
                ?? $request->input('uuid') 
                ?? (string) Str::uuid();

            $payload = $request->all();
            if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
            }

            if (empty($payload)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Payload is required'
                ], 400);
            }
            try{

            if($payload['staff_id']){
                // $staff = StaffModel::where('sno', $erpId)->first();
                $staff = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();

                if ($staff) {
                    $staff->status = 1;
                    $staff->is_exist_egc = $payload['status'] ?? 1;;
                    $staff->dep_reason = $payload['dep_reason'] ?? null;
                    $staff->notice_start_date = $payload['notice_start_date'] ?? null;
                    $staff->notice_end_date = $payload['notice_end_date'] ?? null;
                    $staff->staff_last_date = $payload['staff_last_date'] ?? null;
                    $staff->save();

                    event(new StaffExistUpdated($staff));

                     return response()->json([
                        'ok'  => true,
                        'sno' => $staff->sno,
                        'meassage'=>'Exit Staff Updated',
                        'uuid' => $uuid,
                    ], 200);
                    

                }else{
                    return response()->json([
                        'ok'  => true,
                        'meassage'=>'Staff Not Found',
                        'uuid' => $uuid,
                    ], 200);
                }
            }else{
                return response()->json([
                    'ok'  => true,
                    'meassage'=>'Staff id Not Found',
                    'uuid' => $uuid,
                ], 200);
            }

            }catch(\Throwable $e){
                    return response()->json([
                        'ok'  => false,
                        'message' => $e->getMessage(),
                    ], 500);
            }
            // $erpId = $payload['erp_staff_id'];
            

            
        }
     


    // Staff Webhook End 

     // Staff Attendance Webhook Start
        public function StaffAddAttendanceHook(Request $request)
        {
            
            // Generate or get UUID
            $uuid = $request->header('X-IDEMPOTENCY-KEY') ?? $request->input('uuid') ?? (string) Str::uuid();
                 // Retrieve the payload and decode it
                $payload = $request->all();
                        // Check if the payload contains a JSON-encoded string (as your logs suggest)
                if (is_array($payload) && count($payload) === 1 && is_string($payload[0])) {
                    $payload = json_decode($payload[0], true);  // Decode JSON string into an associative array
                }


                // Validate payload
                if (empty($payload)) {
                    return response()->json([
                        'ok' => false,
                        'message' => 'Payload is required'
                    ], 400);
                }
                $staffData = StaffModel::where('external_uuid', $payload['staff_id'])
                             ->first();
                
                 $alreadyExists = StaffAttendanceModel::where([
                    ['staff_id', '=', $staffData->sno],
                    ['date', '=', $payload['date']],
                    ['status', '!=', 2], 
                ])->first();
            $year = date("Y");
            $month = date("m");
            if ($alreadyExists) {
                $alreadyExists->attendance = $payload['attendance'];
                $alreadyExists->time_start = $payload['time_start'] ?? null;
                $alreadyExists->time_end = $payload['time_end'] ?? null;
                $alreadyExists->in_time = $payload['in_time'] ?? null;
                $alreadyExists->out_time = $payload['out_time'] ?? null;
                $alreadyExists->reason = $payload['reason'] ?? null;
                $alreadyExists->external_uuid = $uuid ;
                $alreadyExists->update();
                $addStaff=$alreadyExists;
            }else{
                // Generate a new staff attendance ID
                    $category_check = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                    $staff_attendance_id = $this->generateStaffAttendanceId($category_check, $year, $month);

                    // Save new attendance record
                $addStaff= StaffAttendanceModel::updateOrCreate(
                        ['external_uuid' => $uuid],
                        [
                        'staff_attendance_id' => $staff_attendance_id,
                        'branch_id'           => 6,
                        'staff_id'            => $staffData->sno,
                        'date'                => $payload['date'],
                        'attendance'          => $payload['attendance'],
                        'type'                => $payload['type'] ?? null,
                        'time_start'          => $payload['time_start'] ?? null,
                        'time_end'            => $payload['time_end'] ?? null,
                        'in_time'             => $payload['in_time'] ?? null,
                        'out_time'            => $payload['out_time'] ?? null,
                        'reason'              => $payload['reason'] ?? null,
                        'created_by'          => 0,
                        'updated_by'          => 0,
                        ]
                );
            }  

            return response()->json([
                'ok' => true,
                'sno' => $addStaff->sno,
            ], 200);
        }


         public function StaffAddAttendanceHookEssl(Request $request)
        {
            $uuid = $request->header('X-IDEMPOTENCY-KEY')
                ?? $request->input('batch_uuid')
                ?? (string) Str::uuid();
 
           $rawContent = $request->getContent();

                $payload = json_decode($rawContent, true);

                // If double encoded JSON string
                if (is_string($payload)) {
                    $payload = json_decode($payload, true);
                }

                // Final fallback
                if (!$payload || !is_array($payload)) {
                    $payload = $request->all();
                }

            if (empty($payload['records']) || !is_array($payload['records'])) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Attendance records required',
                    "data" => $payload ?? "-"
                ], 400);
            }


 
            DB::beginTransaction();
 
            try {
 
                foreach ($payload['records'] as $record) {
 
                    $staffData = StaffModel::where('external_uuid', $record['staff_id'])->first();
 
                    if (!$staffData) {
                        continue; // skip if staff not found
                    }
 
                    $alreadyExists = StaffAttendanceModel::where([
                        ['staff_id', '=', $staffData->sno],
                        ['date', '=', $record['date']],
                        ['status', '!=', 2],
                    ])->first();
 
                    if ($alreadyExists) {

                        if (in_array($alreadyExists, ['OD', 'PR', 'L','P'])) {
                                $alreadyExists->update([
                                    'in_time'    => $record['in_time'] ?? null,
                                    'out_time'   => $record['out_time'] ?? null,
                                ]);
                        }else{
                            $alreadyExists->update([
                                'attendance' => $record['attendance'],
                                'in_time'    => $record['in_time'] ?? null,
                                'out_time'   => $record['out_time'] ?? null,
                                'reason'     => $record['reason'] ?? null,
                                'external_uuid' => $record['sno'],
                            ]);
                        }
 
                    } else {
 
                        $category_check = StaffAttendanceModel::where('status','!=',2)
                            ->orderBy('sno','desc')
                            ->first();
 
                        $staff_attendance_id = $this->generateStaffAttendanceId(
                            $category_check,
                            date("m"),
                            date("Y")
                        );
 
                        StaffAttendanceModel::create([
                            'staff_attendance_id' => $staff_attendance_id,
                            'branch_id'           => 2,
                            'staff_id'            => $staffData->sno,
                            'date'                => $record['date'],
                            'attendance'          => $record['attendance'],
                            'in_time'             => $record['in_time'] ?? null,
                            'out_time'            => $record['out_time'] ?? null,
                            'reason'              => $record['reason'] ?? null,
                            'external_uuid'       => $record['sno'],
                            'created_by'          => 0,
                            'updated_by'          => 0,
                        ]);
                    }
                }
 
                DB::commit();
 
                return response()->json([
                    'ok' => true,
                    'message' => 'Attendance processed successfully'
                ], 200);
 
            } catch (\Throwable $e) {
 
                DB::rollBack();
 
                return response()->json([
                    'ok' => false,
                    'message' => $e->getMessage()
                ], 500);
            }
        }

        private function generateStaffAttendanceId($category_check, $month, $year)
        {
            if (!$category_check) {
                return 'ATT0001/' . $month . '/' . $year;
            }

            // Extract the current staff attendance ID (e.g., "ATT0001/11/2025")
            $data = $category_check->staff_attendance_id;
            $slice = explode("/", $data);

            // Extract the numeric part of the attendance ID (e.g., 0001 from "ATT0001")
            $resultcus = preg_replace('/[^0-9]/', '', $slice[0]);
            $next_number = (int)$resultcus + 1;

            // Return the formatted ID (e.g., "ATT0002/11/2025")
            return 'ATT' . sprintf("%04d", $next_number) . '/' . $month . '/' . $year;
        }
    // Staff Attendance Webhook End

    // user Credential Check Api
    public function userCrendentialCheck(Request $request)
    {
       
        $validator = Validator::make($request->all(), [
        'name' => 'required|max:255',
        'password' => 'required|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $auth_key = $request->auth_key;
        $verify_key = 'egcsecret2030datagetapierp';

        if ($auth_key !== $verify_key) {
            return response()->json([
                'status' => 410,
                'data' => null,
                'message' => 'Unauthorized Entry'
            ], 410);
        }
        $user = User::select('users.*', 'et_staff.status as staff_status')
        ->where('users.name', $request->name)
        ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
        ->leftJoin('et_branch', 'users.branch_id', '=', 'et_branch.sno')
        // ->where('et_staff.status', 0)
        ->where('et_branch.status', 0)
        ->first();
        
        if (!$user) {
            return response()->json([
                'type' => 'error',
                'message' => 'User not found.'
            ]);
        }

        if ($user->staff_status == 1) {

            return response()->json([
                'type' => 'error',
                'message' => 'This user is inactive. Please contact the administrator.'
            ], 200);

        } elseif ($user->staff_status == 2) {
            return response()->json([
                'type' => 'error',
                'message' => 'This user is deactivated. Please contact the administrator.'
            ], 200);
        }
        if ($user->name !== $request->name) {
            return response()->json([
                'type' => 'error',
                'message' => 'Username is case-sensitive. Please enter the correct case.'
            ], 200);
        }

        // if (!Hash::check($request->password, $user->password)) {
        //     return response()->json([
        //         'type' => 'error',
        //         'message' => 'Invalid credentials'
        //     ], 200);
        // }

        $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();
    
        if (!$permissions) {
            return response()->json([
                'type' => 'error',
                'message' => 'Role Permission Not Set in EAPL ERP'
            ], 200);
        }

        return response()->json([
        'type' => 'Success',
        'message' => 'User Found'
        ], 200);
        
    }

        

    
}