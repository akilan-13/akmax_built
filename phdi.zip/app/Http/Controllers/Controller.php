<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Helpers\Helpers;
use App\Models\GeneralSettingsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    protected static $branch_id;

    public function __construct(Request $request)
    {
      
        $this->shareCommonData();
    }

    protected function shareCommonData()
    {
        $general = GeneralSettingsModel::first();
        $helper = new Helpers();

        $logoUrl = $general ? $helper->Logo_pic($general->logo) : null;
        $favUrl = $general ? $helper->Fav_Icon_pic($general->fav_icon) : null;
        $title   = $general ? $general->title : null;
        // Share data with all views
        view()->share([
            'title' => $title,
            'logoUrl' => $logoUrl,
            'favUrl' => $favUrl,
        ]);
    }
}