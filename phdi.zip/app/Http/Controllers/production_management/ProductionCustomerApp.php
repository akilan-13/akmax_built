<?php

namespace App\Http\Controllers\production_management;

use App\Http\Controllers\Controller;
use App\Models\AppointmentModeModel;
use App\Models\ConnectingWayModel;
use App\Models\CustomerModel;
use App\Models\ManageAppointmentsModel;
use App\Models\StaffModel;
use Illuminate\Http\Request;

class ProductionCustomerApp extends Controller
{
    public function index(Request $request)
    {


        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user = auth()->user();

        // Filter
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $pageConfigs = ['myLayout' => 'default'];

        $fill_chk = $request->fill_chk ?? 0;
        if ($fill_chk == 1) {
            $fill = true;
        } else {
            $fill = false;
        }

        // Data Fetching Variables
        $query = ManageAppointmentsModel::where('et_manage_appointments.status', '!=', 2)
            ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'normal_staff.staff_name as normal_staff_name', 'pc_staff.staff_name as pc_staff_name')
            ->join('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
            ->join('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
            ->join('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
            ->leftJoin('et_staff as normal_staff', 'normal_staff.sno', '=', 'et_manage_appointments.staff_id')
            ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_manage_appointments.pc_id');
        // Returning View


        $customer_type_fill = $request->customer_type_fill ?? '';
        if ($customer_type_fill) {
            $query->where('et_manage_appointments.customer_id', 'LIKE', "%$customer_type_fill%");
        }

        $appointment_type_fill = $request->appointment_type_fill ?? '';
        if ($appointment_type_fill) {
            $query->where('et_manage_appointments.appointment_mode_id',  $appointment_type_fill);
        }

        $connecting_type_fill = $request->connecting_type_fill ?? '';
        if ($connecting_type_fill) {
            $query->where('et_manage_appointments.connecting_way_id', $connecting_type_fill);
        }

        $staff_type_fill = $request->staff_type_fill ?? '';
        if ($staff_type_fill) {
            $query->where('et_manage_appointments.staff_id', $staff_type_fill);
        }
        // return $user->role_id;
        if ($user->role_id == 32) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'view_self_cus')) {
                $query = $query->where('et_manage_appointments.staff_id', $user_id);
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'global_cus')) {
                $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'view_self_cus')) {
                $query = $query->where('et_manage_appointments.pc_id', $user_id);
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'global_cus')) {
                $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }
        }


        $appointments = $query->where('et_manage_appointments.branch_id', $branch_id)
            ->whereNotIn('et_customer.post_sale_check', [1])
            ->orderBy('et_manage_appointments.sno', 'desc')
            ->paginate($perpage);

        $customers = CustomerModel::select('sno', 'cus_name', 'customer_id')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->get();
        $apps = AppointmentModeModel::select('sno', 'appointment_mode_name')->where('status', 0)->get();
        $staffs = StaffModel::select('sno', 'staff_name')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->where('role_id', '=', 15)->get();
        $ways = ConnectingWayModel::select('sno', 'connecting_way_name', 'url_link')->where('status', 0)->get();

        if (auth()->user()->hasPermission('Production Management', 'Pre Sale Appointment', 'Customer  Appointment')) {
            return view('content.production_management.manage_appointment.manage_appointments', compact(
                'customers',
                'appointments',
                'apps',
                'ways',
                'staffs',
                'perpage',
                'pageConfigs',
                'customer_type_fill',
                'appointment_type_fill',
                'connecting_type_fill',
                'staff_type_fill'
            ))->with('filter_on', $fill);
        } else {
            return redirect('/production_management/post_sale_appointments');
        }
    }

    public function post_sale_appointment(Request $request)
    {

        $branch_id = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $user = auth()->user();

        // Filter
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $pageConfigs = ['myLayout' => 'default'];

        $fill_chk = $request->fill_chk ?? 0;
        if ($fill_chk == 1) {
            $fill = true;
        } else {
            $fill = false;
        }

        // Data Fetching Variables
        $query = ManageAppointmentsModel::where('et_manage_appointments.status', '!=', 2)
            ->select('et_manage_appointments.*', 'et_customer.cus_name as name', 'et_customer.customer_id as id', 'et_connecting_way.connecting_way_name as con_name', 'et_appointment_mode.appointment_mode_name', 'normal_staff.staff_name as normal_staff_name', 'pc_staff.staff_name as pc_staff_name')
            ->join('et_customer', 'et_customer.sno', '=', 'et_manage_appointments.customer_id')
            ->join('et_connecting_way', 'et_connecting_way.sno', '=', 'et_manage_appointments.connecting_way_id')
            ->join('et_appointment_mode', 'et_appointment_mode.sno', '=', 'et_manage_appointments.appointment_mode_id')
            ->leftJoin('et_staff as normal_staff', 'normal_staff.sno', '=', 'et_manage_appointments.staff_id')
            ->leftJoin('et_staff as pc_staff', 'pc_staff.sno', '=', 'et_manage_appointments.pc_id');


        $customer_type_fill = $request->customer_type_fill ?? '';
        if ($customer_type_fill) {
            $query->where('et_manage_appointments.customer_id', 'LIKE', "%$customer_type_fill%");
        }

        $appointment_type_fill = $request->appointment_type_fill ?? '';
        if ($appointment_type_fill) {
            $query->where('et_manage_appointments.appointment_mode_id',  $appointment_type_fill);
        }

        $connecting_type_fill = $request->connecting_type_fill ?? '';
        if ($connecting_type_fill) {
            $query->where('et_manage_appointments.connecting_way_id', $connecting_type_fill);
        }

        $staff_type_fill = $request->staff_type_fill ?? '';
        if ($staff_type_fill) {
            $query->where('et_manage_appointments.staff_id', $staff_type_fill);
        }

        if ($user->role_id == 32) {
            if (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'view_self_cus')) {
                $query = $query->where('et_manage_appointments.staff_id', $user_id);
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'global_cus')) {
                $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }
        } else {
            if (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'view_self_cus')) {
                $query = $query->where('et_manage_appointments.pc_id', $user_id);
            } elseif (auth()->user()->hasPermissionradio('Production Management', 'Customer  Appointment', 'global_cus')) {
                $query = $query;
            } else {
                abort(403, 'Unauthorized');
            }
        }


        $appointments = $query->where('et_manage_appointments.branch_id', $branch_id)
            ->where('et_customer.post_sale_check', 1)
            ->orderBy('et_manage_appointments.sno', 'desc')->paginate($perpage);

        $customers = CustomerModel::select('sno', 'cus_name', 'customer_id')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->get();
        $apps = AppointmentModeModel::select('sno', 'appointment_mode_name')->where('status', 0)->get();
        $staffs = StaffModel::select('sno', 'staff_name')->where('status', 0)->where('branch_id', $branch_id)->where('sno', '>', 1)->where('role_id', '=', 15)->get();
        $ways = ConnectingWayModel::select('sno', 'connecting_way_name', 'url_link')->where('status', 0)->get();

        return view('content.production_management.manage_appointment.post_sale_appointment', compact(
            'customers',
            'appointments',
            'apps',
            'ways',
            'staffs',
            'perpage',
            'pageConfigs',
            'customer_type_fill',
            'appointment_type_fill',
            'connecting_type_fill',
            'staff_type_fill'
        ))->with('filter_on', $fill);
    }
}
