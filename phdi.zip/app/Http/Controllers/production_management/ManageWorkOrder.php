<?php

namespace App\Http\Controllers\production_management;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\service_management\ManageService;
use App\Models\DomainModel;
use App\Models\ManageWorkOrderModel;
use App\Models\MilestoneMappingModel;
use App\Models\ProductToolsModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ManageWorkOrder extends Controller
{
  public function index(Request $request)
  {
    $entity_id   = $request->user()->entity_id;
    $user_id   = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;
    $search_fill = $request->search_fill ?? '';
    $filter_on = $request->filter_on ?? '';
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $List = DB::table('et_customer_services')
      ->select(
        'et_customer_services.proposal_id',
        // 'et_customer_services.variant_variable_ids',
        'et_customer_services.product_package',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        // 'et_customer_services.sno as service_sno',
        // 'et_work_order.development_date',
        // 'et_work_order.deliverable_date',
        // 'et_work_order.customer_end_date',
        'et_customer.customer_id AS cus_id'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
    //   ->leftJoin('et_work_order', 'et_work_order.proposal_id', '=', 'et_customer_services.proposal_id')
      ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.branch_id', $branch_id);

    // Apply search filter
    if (!empty($search_fill)) {
      $List->where(function ($query) use ($search_fill) {
        $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
          ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%");
      });
    }

    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
      // User can only view their own data
      $List = $List->where('et_proposal.cre_id', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
      // User can view all data
      $List = $List;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }


    // Group by fields
    $List->groupBy([
      'et_customer_services.proposal_id',
      'et_customer_services.product_package',
      //   'et_customer_services.variant_variable_ids',
      'et_customer_services.branch_id',
      'et_customer_services.work_order_check',
      'et_customer_services.lead_id',
      'et_customer_services.customer_id',
    //   'et_work_order.development_date',
    //   'et_work_order.deliverable_date',
    //   'et_work_order.customer_end_date',
      'et_customer.cus_name',
      'et_customer.cus_mobile',
      'et_customer.cus_email_id',
      'et_customer.country_code',
      //   'et_customer_services.sno',
      'et_customer.customer_id',
    ]);

    // Pagination and ordering
    $ListTable = $List->orderBy('et_customer_services.sno', 'desc')->paginate($perpage);

    // Loop through results and fetch product list
    foreach ($ListTable as $list) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name'
          //   DB::raw("CASE 
          //         WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          //         WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          //         ELSE NULL
          //     END as product_name")
        )
        ->where('et_customer_services.proposal_id', $list->proposal_id)
        // ->leftJoin('et_product', function ($join) {
        //   $join->on('et_product.sno', '=', 'et_customer_services.product_id')
        //     ->where('et_customer_services.product_package', '=', 1);
        // })
        // ->leftJoin('et_package', function ($join) {
        //   $join->on('et_package.sno', '=', 'et_customer_services.package_id')
        //     ->where('et_customer_services.product_package', '=', 2);
        // })
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      // Assign product list to a new property
      $list->product_list = $productList;
    }
    $production_staffs = DB::table('et_staff')->where('et_staff.status', 0)->where('et_staff.sno', '>', 1)
      ->select('et_staff.sno', 'et_staff.branch_id', 'et_staff.role_id', 'et_staff.department_id', 'et_staff.staff_image', 'et_staff.status', 'et_staff.staff_name', 'et_job_position.job_position_name')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.branch_id', $branch_id)
      ->get();
    $tools = ProductToolsModel::where('status', 0)->get();
    $domains = DomainModel::where('status', 0)->get();
    // return $ListTable;
    return view('content.production_management.manage_work_order.list', [
      'ListTable' => $ListTable,
      'perpage' => $perpage,
      'search_fill' => $search_fill,
      'filter_on' => $filter_on,
      'production_staffs' => $production_staffs,
      'tools' => $tools,
      'domains' => $domains
    ]);
  }

//   public function get_manage_service(Request $request)
//   {
//     $branch_id = $request->user()->branch_id;
//     $user_id = $request->user()->user_id;
//     $helper = new \App\Helpers\Helpers();

//     $perPage = $request->get('per_page', 25);
//     $page = $request->get('page', 1);
//     $search = $request->get('search', '');

//     $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';

//     $query = DB::table('et_customer_services')
//       ->select(
//         'et_customer_services.proposal_id',
//         'et_customer_services.product_package',
//         'et_customer_services.branch_id',
//         'et_customer_services.work_order_check',
//         'et_customer_services.created_at',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.country_code',
//         'et_customer.customer_id AS cus_id',
//         'et_proposal.service_title',
//         'et_proposal.proposal_id as proposal_table_id'
//       )
//       ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
//       ->leftJoin('et_payment', 'et_payment.customer_id', '=', 'et_customer_services.customer_id')
//       ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
//       ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
//       ->where('et_customer_services.branch_id', $branch_id)
//       ->where('et_transaction.payment_status', 1)
//       ->groupBy(
//         'et_customer_services.proposal_id',
//         'et_customer_services.product_package',
//         'et_customer_services.branch_id',
//         'et_customer_services.work_order_check',
//         'et_customer_services.lead_id',
//         'et_customer_services.customer_id',
//         'et_customer.cus_name',
//         'et_customer.cus_mobile',
//         'et_customer.cus_email_id',
//         'et_customer.country_code',
//         'et_customer.customer_id',
//         'et_customer_services.created_at',
//         'et_proposal.service_title',
//         'et_proposal.proposal_id'
//       );

//     if (!empty($search)) {
//       $query->where(function ($q) use ($search) {
//         $q->where('et_customer.cus_name', 'like', '%' . $search . '%')
//           ->orWhere('et_customer.cus_mobile', 'like', '%' . $search . '%')
//           ->orWhere('et_customer.cus_email_id', 'like', '%' . $search . '%')
//           ->orWhere('et_customer.customer_id', 'like', '%' . $search . '%');
//       });
//     }

//     if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
//       // User can only view their own data
//       $query = $query->where('et_proposal.cre_id', $user_id);
//       // return "view_self_lead";
//     } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
//       // User can view all data
//       $query = $query;
//       // return "global_lead";
//     } else {
//       // No permission
//       abort(403, 'Unauthorized');
//     }


//     $lists = $query->paginate($perPage);

//     foreach ($lists as $list) {
//       $productList = DB::table('et_customer_services')
//         ->select(
//           'et_customer_services.*',
//           'et_product_category.product_category_name',
//           'et_work_order.development_date',
//           'et_work_order.deliverable_date',
//           'et_work_order.customer_end_date',
//           'et_product.product_name'
//         )
//         ->where('et_customer_services.proposal_id', $list->proposal_id)
//         ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
//         ->leftJoin('et_work_order', 'et_work_order.proposal_id', '=', 'et_customer_services.proposal_id')
//         ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
//         ->orderBy('et_customer_services.sno', 'desc')
//         ->get();

//       foreach ($productList as $product) {
//         $variantVariableIds = json_decode($product->variant_variable_ids, true);
//         $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

//         $variantName = '';
//         $variableName = '';

//         foreach ($variantVariableIds as $data) {
//           $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
//           $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();

//           if ($variant) {
//             $variantName = $variant->product_variant_name ?? '';
//           }

//           if ($variable) {
//             $variableName = $variable->variable_name ?? '';
//           }
//         }

//         $product->variant_name = $variantName;
//         $product->variable_name = $variableName;
//       }

//       $list->product_list = $productList;

//       $list->service_register_date = date(
//         $common_date_format,
//         strtotime($helper->getFirstPaymentDate($list->proposal_id))
//       );
//     }

//     return response([
//       'status' => 200,
//       'message' => 'Service Data Fetched',
//       'error_msg' => null,
//       'data' => [
//         'data' => $lists->items(),
//         'current_page' => $lists->currentPage(),
//         'per_page' => $lists->perPage(),
//         'total' => $lists->total(),
//         'from' => $lists->firstItem(),
//         'to' => $lists->lastItem(),
//         'last_page' => $lists->lastPage(),
//       ]
//     ], 200);
//   }

public function get_manage_service(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $helper = new \App\Helpers\Helpers();
 
    $perPage = $request->get('per_page', 25);
    $page = $request->get('page', 1);
    $search = $request->get('search', '');
 
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
 
 
    $query = DB::table('et_proposal')
      ->select(
        'et_proposal.sno as proposal_id',
        'et_proposal.cre_id',
        DB::raw('MAX(ecs.product_package) AS product_package'),
        DB::raw('MAX(ecs.branch_id) AS branch_id'),
        DB::raw('MAX(ecs.work_order_check) AS work_order_check'),
        DB::raw('MAX(ecs.created_at) AS created_at'),
        DB::raw('MAX(ec.cus_name) AS cus_name'),
        DB::raw('MAX(ec.cus_mobile) AS cus_mobile'),
        DB::raw('MAX(ec.cus_email_id) AS cus_email_id'),
        DB::raw('MAX(ec.country_code) AS country_code'),
        DB::raw('MAX(ec.customer_id) AS cus_id'),
         'et_proposal.service_title',
        'et_proposal.proposal_id as proposal_table_id'
      )
      ->join('et_customer_services AS ecs', 'et_proposal.customer_id', '=', 'ecs.customer_id')
      ->join('et_customer AS ec', 'et_proposal.customer_id', '=', 'ec.sno')
      ->leftJoin('et_payment AS ep', 'ep.customer_id', '=', 'ecs.customer_id')
      ->leftJoin('et_transaction AS et', 'et.payment_id', '=', 'ep.sno')
      ->where('ecs.branch_id', $branch_id)
      ->where('et.payment_status', 1)
      // ->where('ecs.customer_id', 106)
      ->groupBy(
        'et_proposal.sno',
        'et_proposal.cre_id',
        'et_proposal.service_title',
        'et_proposal.proposal_id'
      );
 
 
 
    if (!empty($search)) {
      $query->where(function ($q) use ($search) {
        $q->where('ec.cus_name', 'like', '%' . $search . '%')
          ->orWhere('ec.cus_mobile', 'like', '%' . $search . '%')
          ->orWhere('ec.cus_email_id', 'like', '%' . $search . '%')
             ->orWhere('et_proposal.service_title', 'like', '%' . $search . '%')
            ->orWhere('et_proposal.proposal_id', 'like', '%' . $search . '%')
          ->orWhere('ec.customer_id', 'like', '%' . $search . '%');
      });
    }
 
    if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
      // User can only view their own data
      $query = $query->where('et_proposal.cre_id', $user_id);
      // return "view_self_lead";
    } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
      // User can view all data
      $query = $query;
      // return "global_lead";
    } else {
      // No permission
      abort(403, 'Unauthorized');
    }
 
    // return $query->get();
 
 
    // $query = DB::table('et_customer_services')
    //   ->select(
    //     'et_customer_services.proposal_id',
    //     'et_customer_services.product_package',
    //     'et_customer_services.branch_id',
    //     'et_customer_services.work_order_check',
    //     'et_customer_services.created_at',
    //     'et_customer.cus_name',
    //     'et_customer.cus_mobile',
    //     'et_customer.cus_email_id',
    //     'et_customer.country_code',
    //     'et_customer.customer_id AS cus_id'
    //   )
    //   ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
    //   ->leftJoin('et_payment', 'et_payment.customer_id', '=', 'et_customer_services.customer_id')
    //   ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //   ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
    //   ->where('et_customer_services.branch_id', $branch_id)
    //   ->where('et_transaction.payment_status', 1)
    //   ->groupBy(
    //     'et_customer_services.proposal_id',
    //     'et_customer_services.product_package',
    //     'et_customer_services.branch_id',
    //     'et_customer_services.work_order_check',
    //     'et_customer_services.lead_id',
    //     'et_customer_services.customer_id',
    //     'et_customer.cus_name',
    //     'et_customer.cus_mobile',
    //     'et_customer.cus_email_id',
    //     'et_customer.country_code',
    //     'et_customer.customer_id',
    //     'et_customer_services.created_at'
    //   );
 
    // if (!empty($search)) {
    //   $query->where(function ($q) use ($search) {
    //     $q->where('et_customer.cus_name', 'like', '%' . $search . '%')
    //       ->orWhere('et_customer.cus_mobile', 'like', '%' . $search . '%')
    //       ->orWhere('et_customer.cus_email_id', 'like', '%' . $search . '%')
    //       ->orWhere('et_customer.customer_id', 'like', '%' . $search . '%');
    //   });
    // }
 
    // if (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'view_self_cus')) {
    //   // User can only view their own data
    //   $query = $query->where('et_proposal.cre_id', $user_id);
    //   // return "view_self_lead";
    // } elseif (auth()->user()->hasPermissionradio('Customer Management', 'Manage Customer', 'global_cus')) {
    //   // User can view all data
    //   $query = $query;
    //   // return "global_lead";
    // } else {
    //   // No permission
    //   abort(403, 'Unauthorized');
    // }
 
 
    $lists = $query->paginate($perPage);
 
    foreach ($lists as $list) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
        //   'et_work_order.development_date',
        //   'et_work_order.deliverable_date',
        //   'et_work_order.customer_end_date',
          'et_product.product_name'
        )
        ->where('et_customer_services.proposal_id', $list->proposal_id)
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        // ->leftJoin('et_work_order', 'et_work_order.proposal_id', '=', 'et_customer_services.proposal_id')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();
 
      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];
 
        $variantName = '';
        $variableName = '';
 
        foreach ($variantVariableIds as $data) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();
 
          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }
 
          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }
 
        $product->variant_name = $variantName;
        $product->variable_name = $variableName;
      }
 
      $list->product_list = $productList;
 
      $list->service_register_date = date(
        $common_date_format,
        strtotime($helper->getFirstPaymentDate($list->proposal_id))
      );
    }
 
    return response([
      'status' => 200,
      'message' => 'Service Data Fetched',
      'error_msg' => null,
      'data' => [
        'data' => $lists->items(),
        'current_page' => $lists->currentPage(),
        'per_page' => $lists->perPage(),
        'total' => $lists->total(),
        'from' => $lists->firstItem(),
        'to' => $lists->lastItem(),
        'last_page' => $lists->lastPage(),
      ]
    ], 200);
  }
  
  public function get_first_call($id)
  {
    $data = DB::table('et_customer_services')
      ->select(
        'et_customer_services.proposal_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.proposal_id', $id)
      ->orderBy('et_customer_services.sno', 'desc')
      ->first();

    $helper = new \App\Helpers\Helpers();
    $domain_names = $helper->get_domain_by_proposalId($id);

    $data->domain_names = $domain_names;

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name'
        )
        ->where('et_customer_services.proposal_id', $data->proposal_id)
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

        $variantName = '';
        $variableName  = '';

        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }

          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }

        $product->variant_name = $variantName;
        $product->variable_name = $variableName;

        $year = date('Y', strtotime($product->created_at));
        $id = str_pad($product->sno, 5, '0', STR_PAD_LEFT);
        $product->service_id = "SR-{$id}/{$year}";
      }

      $data->product_list = $productList;
    } else {
      $data = null;
    }

    return response([
      'status' => 200,
      'message' => 'Product fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

  public function get_workorder_checklist()
  {
    $data = DB::table('et_work_order_checklist')->where('status', 0)->orderBy('work_order_checklist', 'ASC')->get();

    return response([
      'status' => 200,
      'message' => 'Workorder Checklist Fetched',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function submit_first_call(Request $request)
  {
    try {
      $user_id = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $proposalId = $request->proposal_id;
      $billableDetails = $request->billable_details;
      $checklists = $request->checklist_items;
      $nextPayDates = $request->next_pay_date;
      $paySlotIds = $request->pay_slot_ids;
      $desc = $request->description;

      DB::beginTransaction();

      $data = DB::table('et_customer_services')
        ->where('proposal_id', $proposalId)
        ->get();

      foreach ($data as $d) {
        $new = new ManageWorkOrderModel();
        $new->branch_id = $branch_id;
        $new->service_id = $d->sno;
        $new->created_by = $user_id;
        $new->updated_by = $user_id;
        $new->proposal_id = $proposalId;
        $new->billable_details = $billableDetails;
        $new->checklist = json_encode($checklists, true);
        $new->work_order_desc = $desc;
        $new->save();

        if (!$new) {
          throw new Exception('Failed to create work order');
        }
      }

      $updated = DB::table('et_customer_services')
        ->where('proposal_id', $proposalId)
        ->update([
          'work_order_check' => 2,
          'updated_by' => $user_id
        ]);

      if ($updated === 0) {
        throw new Exception('Failed to update customer service');
      }

      if (!empty($paySlotIds) && !empty($nextPayDates)) {
        foreach ($paySlotIds as $index => $slotId) {
          if (!isset($nextPayDates[$index])) {
            continue;
          }

          $date = $nextPayDates[$index];

          try {
            DB::table('et_proposal_pay_slot')
              ->where('sno', $slotId)
              ->update([
                'nextPayDate' => Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d'),
                'initialPayDate' => Carbon::createFromFormat('d-M-Y', $date)->format('Y-m-d'),
                'updated_by' => $user_id
              ]);
          } catch (\Exception $e) {
            throw new Exception('Invalid date format for payment slot: ' . $date);
          }
        }
      }

      DB::commit();

      return response([
        'status' => 200,
        'message' => 'First Call Confirmed!',
        'error_msg' => null,
        'data' => $proposalId
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack();
      return response([
        'status' => 500,
        'message' => 'Failed to confirm first call',
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }

  public function get_allocate_pc(Request $request)
  {

    $branch_id = $request->user()->branch_id;

    $data = DB::table('et_staff')->where('et_staff.status', 0)
      ->where('et_staff.sno', '>', 1)
      ->where('et_staff.role_id', 15)
      ->select('et_staff.sno', 'et_staff.staff_name', 'et_job_position.job_position_name')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->where('et_staff.branch_id', $branch_id)
      ->get();

    return response([
      'status' => 200,
      'message' => 'PC Fetched',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function allocate_project_coordinator($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $id = $decryptedValue;

    $data = DB::table('et_customer_services')
      ->select(
        'et_customer_services.proposal_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.proposal_id', $id)
      ->orderBy('et_customer_services.sno', 'desc')
      ->first();

    $domain_names = $helper->get_domain_by_proposalId($id);

    $data->domain_names = json_decode($domain_names, true);

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name'
        )
        ->where('et_customer_services.proposal_id', $data->proposal_id)
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

        $variantName = '';
        $variableName  = '';

        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }

          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }

        $product->variant_name = $variantName;
        $product->variable_name = $variableName;

        $year = date('Y', strtotime($product->created_at));
        $id = str_pad($product->sno, 5, '0', STR_PAD_LEFT);
        $product->service_id = "SR-{$id}/{$year}";
      }

      $data->product_list = $productList;
    } else {
      $data = null;
    }


    return view('content.production_management.manage_work_order.allocate_pc', [
      'data' => $data,
      'id' => $decryptedValue
    ]);
  }

  public function get_service_data_dropdown($id)
  {
    $data = DB::table('et_customer_services')
      ->select(
        'et_customer_services.*',
        'et_product_category.product_category_name',
        DB::raw("CASE 
          WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          ELSE NULL
        END as product_name")
      )
      ->where('et_customer_services.proposal_id', $id)
      ->leftJoin('et_product', function ($join) {
        $join->on('et_product.sno', '=', 'et_customer_services.product_id')
          ->where('et_customer_services.product_package', '=', 1);
      })
      ->leftJoin('et_package', function ($join) {
        $join->on('et_package.sno', '=', 'et_customer_services.package_id')
          ->where('et_customer_services.product_package', '=', 2);
      })
      ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->orderBy('et_customer_services.sno', 'desc')
      ->get();

    foreach ($data as $product) {
      $variantVariableIds = json_decode($product->variant_variable_ids, true);
      $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

      $variantName = '';
      $variableName  = '';

      foreach ($variantVariableIds as $v) {
        $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
        $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

        if ($variant) {
          $variantName = $variant->product_variant_name ?? '';
        }

        if ($variable) {
          $variableName = $variable->variable_name ?? '';
        }
      }

      $product->variant_name = $variantName;
      $product->variable_name = $variableName;
    }

    return response([
      'status' => 200,
      'message' => 'Product Fetched Successfully',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function get_journal_indexings()
  {
    $data = DB::table('et_journal_index')
      ->where('status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function schedule_dates($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $id = $decryptedValue;

    $data = DB::table('et_customer_services')
      ->select(
        'et_customer_services.proposal_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer.cus_name',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.proposal_id', $id)
      ->orderBy('et_customer_services.sno', 'desc')
      ->first();

    $domain_names = $helper->get_domain_by_proposalId($id);

    $data->domain_names = json_decode($domain_names, true);

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name'
        )
        ->where('et_customer_services.proposal_id', $data->proposal_id)
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

        $variantName = '';
        $variableName  = '';

        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }

          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }

        $product->variant_name = $variantName;
        $product->variable_name = $variableName;

        $year = date('Y', strtotime($product->created_at));
        $id = str_pad($product->sno, 5, '0', STR_PAD_LEFT);
        $product->service_id = "SR-{$id}/{$year}";
      }

      $data->product_list = $productList;
    } else {
      $data = null;
    }


    return view('content.production_management.manage_work_order.schedule_date', [
      'data' => $data,
      'id' => $decryptedValue
    ]);
  }

  public function milestone_mapping($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $id = $decryptedValue;

    $data = DB::table('et_customer_services')
      ->select(
        'et_customer_services.proposal_id',
        'et_customer_services.branch_id',
        'et_customer_services.work_order_check',
        'et_customer.cus_name',
        'et_customer.sno as cus_sno',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer.country_code',
        'et_customer.customer_id'
      )
      ->leftJoin('et_customer', 'et_customer_services.customer_id', '=', 'et_customer.sno')
      ->where('et_customer_services.proposal_id', $id)
      ->orderBy('et_customer_services.sno', 'desc')
      ->first();

    $domain_names = $helper->get_domain_by_proposalId($id);

    $data->domain_names = json_decode($domain_names, true);

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name'
        )
        ->where('et_customer_services.proposal_id', $data->proposal_id)
        ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

        $variantName = '';
        $variableName  = '';

        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }

          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }

        $product->variant_name = $variantName;
        $product->variable_name = $variableName;

        $year = date('Y', strtotime($product->created_at));
        $id = str_pad($product->sno, 5, '0', STR_PAD_LEFT);
        $product->service_id = "SR-{$id}/{$year}";
      }

      $data->product_list = $productList;
    } else {
      $data = null;
    }


    return view('content.production_management.manage_work_order.milestone_mapping', [
      'data' => $data,
      'id' => $decryptedValue
    ]);
  }

  public function add_assign_staff(Request $request)
  {
    try {
      $sno = $request->proposal_id;
      $user_id = $request->user()->user_id;
      $pc_add = $request->project_coordinator_id;
      $journal_check = $request->journal_check;
      $journal_services = $request->journal_services;

      // Validation
      if (!$pc_add) {
        return response([
          'status' => 400,
          'message' => 'Project Coordinator is required',
          'error_msg' => 'Please select a Project Coordinator',
          'data' => []
        ], 400);
      }

      if (!$sno) {
        return response([
          'status' => 400,
          'message' => 'Proposal ID is required',
          'error_msg' => 'Invalid proposal ID',
          'data' => []
        ], 400);
      }

      // Check if services exist for this proposal
      $services = DB::table('et_customer_services')
        ->where('proposal_id', $sno)
        ->get();

      if ($services->isEmpty()) {
        return response([
          'status' => 404,
          'message' => 'No services found for this proposal',
          'error_msg' => 'Invalid proposal ID',
          'data' => []
        ], 404);
      }

      DB::beginTransaction();

      // Update work_order_check for all services
      DB::table('et_customer_services')
        ->where('proposal_id', $sno)
        ->update([
          'work_order_check' => 1,
          'pc_id' => $pc_add,
          'updated_by' => $user_id
        ]);

      if ($journal_check == 1 && !empty($journal_services)) {
        foreach ($journal_services as $journal_service) {
          $service_id = $journal_service['service_id'] ?? null;
          $journal_indexes = $journal_service['journal_indexes'] ?? [];

          if ($service_id && !empty($journal_indexes)) {
            // Update journal_check for the specific service
            DB::table('et_customer_services')
              ->where('sno', $service_id)
              ->where('proposal_id', $sno)
              ->update([
                'journal_check' => 1,
                'updated_by' => $user_id,
                'journal_index' => json_encode($journal_indexes),
              ]);
          }
        }
      }

      // Get PC name
      $pc = DB::table('et_staff')
        ->where('status', 0)
        ->where('sno', $pc_add)
        ->select('staff_name')
        ->first();

      $pc_name = $pc ? $pc->staff_name : 'Staff';

      DB::commit();

      return response([
        'status' => 200,
        'message' => 'Staff assigned successfully!',
        'error_msg' => null,
        'data' => [
          'staff_name' => $pc_name,
          'proposal_id' => $sno
        ]
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack(); // Added rollback in catch block

      return response([
        'status' => 500,
        'message' => 'Failed to assign staff',
        'error_msg' => $e->getMessage(),
        'data' => []
      ], 500);
    }
  }

  public function get_pay_slot($id = '')
  {
    $data = DB::table('et_proposal_pay_slot')
      ->select(
        'et_proposal_pay_slot.*',
        'et_payment_slot.payment_slot_name'
      )
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->where('et_proposal_pay_slot.proposal_sno', $id)
      ->get();
    $maxPayDate = DB::table('et_general_settings')->select('min_payment_days')->where('sno', 1)->first();
    if ($data) {
      return response([
        'status' => 200,
        'message' => 'Data Fetched Successfully !',
        'error_msg' => null,
        'data' => $data,
        'maxPayDate' => $maxPayDate
      ], 200);
    } else {
      return response([
        'status' => 402,
        'message' => 'No Such Records!',
        'error_msg' => null,
        'data' => null
      ], 402);
    }
  }
  public function assign_dates($id)
  {
    $data = DB::table('et_customer_services')
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->select(
        'et_customer.cus_name',
        'et_customer.customer_id',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer_services.proposal_id',
      )
      ->where('et_customer_services.proposal_id', $id)
      ->first();

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->select(
          'et_customer_services.*',
          'et_product_category.product_category_name',
          'et_product.product_name',
          //   DB::raw("CASE 
          //         WHEN et_customer_services.product_package = 1 THEN et_product.product_name
          //         WHEN et_customer_services.product_package = 2 THEN et_package.package_name
          //         ELSE NULL
          //     END as product_name")
        )
        ->where('et_customer_services.proposal_id', $data->proposal_id)
        ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();
      $helper = new Helpers();
      foreach ($productList as $list) {
        $variant_variable_data = json_decode($list->variant_variable_ids ?? '[]', true);
        if (!empty($variant_variable_data) && is_array($variant_variable_data)) {
          foreach ($variant_variable_data as $cart_item) {
            $list->variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
            $list->variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';

            break;
          }
        }
      }
      $data->product_list = $productList;
    } else {
      $data = null;
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }

  public function saveDateTool($id, Request $request)
  {

    $user_id = $request->user()->user_id;
    $dateData = $request->date_data;

    if (!$dateData || !is_array($dateData)) {
      return response([
        'status' => 400,
        'message' => 'Invalid date data',
        'error_msg' => 'date_data must be an array',
        'data' => null
      ], 400);
    }

    foreach ($dateData as $row) {
      DB::table('et_work_order')
        ->where('proposal_id', $id)
        ->where('service_id', $row['service_id'])
        ->update([
          'development_date' => date('Y-m-d', strtotime($row['development_date'])),
          'deliverable_date' => date('Y-m-d', strtotime($row['deliverable_date'])),
          'customer_end_date' => date('Y-m-d', strtotime($row['customer_end_date'])),
          'updated_by' => $user_id
        ]);
    }

    DB::table('et_customer_services')
      ->where('proposal_id', $id)
      ->update([
        'work_order_check' => 3,
        'updated_by' => $user_id
      ]);

    return response([
      'status' => 200,
      'message' => 'Date Saved Successfully!',
      'error_msg' => null,
      'data' => $id
    ], 200);
  }

 public function milestone_mapping_data_fetch($id)
  {
    $data = DB::table('et_customer_services')
      ->where('et_customer_services.proposal_id', $id)
      ->where('et_customer_services.task_status', 0)
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_customer_services.proposal_id')
      ->select(
        'et_customer.cus_name',
        'et_customer.customer_id as cus_id',
        'et_customer.sno as customer_id',
        'et_customer.cus_mobile',
        'et_customer.cus_email_id',
        'et_customer_services.proposal_id',
        'et_customer_services.variant_variable_ids',
        'et_proposal_pay_slot.total_amount'
      )
      ->first();
 
    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
 
  public function get_milestone_data($id)
  {
    // Get total services for this proposal
    $totalServices = DB::table('et_customer_services')
      ->where('proposal_id', $id)
      ->where('task_status', 0)
      ->count();
 
    // Get total milestones for this proposal
    $totalMilestones = DB::table('et_proposal_pay_slot')
      ->where('proposal_sno', $id)
      ->count();
 
    // Calculate expected percentage per milestone
    $expectedPerMilestone = ($totalServices * 100) / $totalMilestones;
 
    // Get ALL milestones
    $allMilestones = DB::table('et_proposal_pay_slot')
      ->where('et_proposal_pay_slot.proposal_sno', $id)
      ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
      ->select(
        'et_payment_slot.payment_slot_name',
        'et_proposal_pay_slot.sno'
      )
      ->get();
 
    // Check which milestones are completed (reached expected percentage)
    $completedMilestoneIds = [];
    foreach ($allMilestones as $milestone) {
      $currentTotal = DB::table('et_milestone_mapping')
        ->where('proposal_id', $id)
        ->where('milestone_id', $milestone->sno)
        ->sum('total_percentage');
 
      // Mark as completed if it's >= expected percentage
      if ($currentTotal >= $expectedPerMilestone) {
        $completedMilestoneIds[] = $milestone->sno;
      }
    }
 
    // Filter out completed milestones
    $availableMilestones = $allMilestones->filter(function ($milestone) use ($completedMilestoneIds) {
      return !in_array($milestone->sno, $completedMilestoneIds);
    })->values();
 
    // Add expected percentage to each milestone
    $availableMilestones = $availableMilestones->map(function ($item) use ($expectedPerMilestone) {
      $item->expected_percentage = $expectedPerMilestone;
      return $item;
    });
 
    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $availableMilestones,
      'total_services' => $totalServices,
      'total_milestones' => $totalMilestones,
      'expected_per_milestone' => $expectedPerMilestone
    ], 200);
  }
 
  public function get_milestone_service_data($id)
  {
    $services = DB::table('et_customer_services')
      ->where('et_customer_services.proposal_id', $id)
      ->where('et_customer_services.task_status', 0)
      ->leftJoin('et_product', 'et_customer_services.product_id', '=', 'et_product.sno')
      ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
      ->select(
        'et_product_category.product_category_name',
        'et_product.product_name',
        'et_customer_services.sno',
        'et_customer_services.created_at'
      )
      ->get();
 
    foreach ($services as $service) {
      $year = date('Y', strtotime($service->created_at));
      $id = str_pad($service->sno, 5, '0', STR_PAD_LEFT);
      $service->service_id = "SR-{$id}/{$year}";
    }
 
    return response([
      'status' => 200,
      'message' => 'Service Fetched Successfully!',
      'error_msg' => null,
      'data' => $services
    ], 200);
  }
 
//   public function get_milestone_product($sno)
//   {
//     $services = DB::table('et_customer_services')
//       ->where('et_customer_services.sno', $sno)
//       ->where('et_customer_services.task_status', 0)
//       ->select(
//         'et_customer_services.product_id',
//         'et_customer_services.variant_variable_ids',
//         'et_customer_services.customer_id',
//         'et_customer_services.proposal_id'
//       )
//       ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
//       ->first();
 
//     // Check if service exists
//     if (!$services) {
//       return response([
//         'status' => 404,
//         'message' => 'Service not found',
//         'data' => []
//       ], 404);
//     }
 
//     $variant_variables = json_decode($services->variant_variable_ids, true);
 
//     if (is_array($variant_variables) && count($variant_variables) > 0) {
//       $first = $variant_variables[0];
//       $services->variant_id  = $first['variant_id'] ?? null;
//       $services->variable_id = $first['variable_id'] ?? null;
//     } else {
//       $services->variant_id  = null;
//       $services->variable_id = null;
//     }
 
//     // Get all available tasks for this product
//     $allTasks = DB::table('et_product_task_mapping')
//       ->leftJoin('et_product_task', 'et_product_task.map_id', '=', 'et_product_task_mapping.sno')
//       ->where('et_product_task_mapping.product_id', $services->product_id)
//       ->where('et_product_task_mapping.variant_id', $services->variant_id)
//       ->where('et_product_task_mapping.variable_id', $services->variable_id)
//       ->select(
//         'et_product_task.task_name',
//         'et_product_task.sno'
//       )
//       ->get();
 
//     // Get already mapped tasks for this customer and proposal
//     $mappedTasks = DB::table('et_milestone_mapping')
//       ->where('customer_id', $services->customer_id)
//       ->where('proposal_id', $services->proposal_id)
//       ->where('service_id', $sno)
//       ->select('task_ids')
//       ->get();
 
//     $excludedTaskIds = [];
 
//     // Extract all task IDs that are already mapped
//     foreach ($mappedTasks as $mappedTask) {
//       $taskIds = json_decode($mappedTask->task_ids, true);
//       if (is_array($taskIds)) {
//         $excludedTaskIds = array_merge($excludedTaskIds, $taskIds);
//       }
//     }
 
//     // Remove duplicates
//     $excludedTaskIds = array_unique($excludedTaskIds);
 
//     // Filter out already mapped tasks
//     $availableTasks = $allTasks->filter(function ($task) use ($excludedTaskIds) {
//       return !in_array($task->sno, $excludedTaskIds);
//     })->values();
 
//     $taskCount = $availableTasks->count();
 
//     return response([
//       'status'  => 200,
//       'message' => 'Milestone Product Data Fetched Successfully!',
//       'data'    => $availableTasks,
//       'task_count' => $taskCount,
//       'excluded_tasks_count' => count($excludedTaskIds) // For debugging
//     ], 200);
//   }
 
 public function get_milestone_product($sno)
  {
    $services = DB::table('et_customer_services')
      ->where('et_customer_services.sno', $sno)
      ->where('et_customer_services.task_status', 0)
      ->select(
        'et_customer_services.product_id',
        'et_customer_services.variant_variable_ids',
        'et_customer_services.customer_id',
        'et_customer_services.proposal_id'
      )
      ->leftJoin('et_product', 'et_product.sno', '=', 'et_customer_services.product_id')
      ->first();
 
    if (!$services) {
      return response([
        'status' => 404,
        'message' => 'Service not found',
        'data' => []
      ], 404);
    }
 
    $variant_variables = json_decode($services->variant_variable_ids, true);
 
    if (is_array($variant_variables) && count($variant_variables) > 0) {
      $first = $variant_variables[0];
      $services->variant_id  = $first['variant_id'] ?? null;
      $services->variable_id = $first['variable_id'] ?? null;
    } else {
      $services->variant_id  = null;
      $services->variable_id = null;
    }
 
    // Get all available tasks for this product
    $allTasks = DB::table('et_product_task_mapping')
      ->leftJoin('et_product_task', 'et_product_task.map_id', '=', 'et_product_task_mapping.sno')
      ->where('et_product_task_mapping.product_id', $services->product_id)
      ->where('et_product_task_mapping.variant_id', $services->variant_id)
      ->where('et_product_task_mapping.variable_id', $services->variable_id)
      ->select(
        'et_product_task.task_name',
        'et_product_task.sno'
      )
      ->get();
 
    // Get already mapped tasks for THIS SPECIFIC SERVICE ONLY
    // This prevents duplicate tasks within the same service
    $mappedTasks = DB::table('et_milestone_mapping')
      ->where('customer_id', $services->customer_id)
      ->where('proposal_id', $services->proposal_id)
      ->where('service_id', $sno) // Keep this filter - only check tasks mapped to THIS service
      ->select('task_ids')
      ->get();
 
    $excludedTaskIds = [];
 
    // Extract task IDs already mapped to THIS service
    foreach ($mappedTasks as $mappedTask) {
      $taskIds = json_decode($mappedTask->task_ids, true);
      if (is_array($taskIds)) {
        $excludedTaskIds = array_merge($excludedTaskIds, $taskIds);
      }
    }
 
    // Remove duplicates
    $excludedTaskIds = array_unique($excludedTaskIds);
 
    // Filter out tasks already mapped to THIS service
    $availableTasks = $allTasks->filter(function ($task) use ($excludedTaskIds) {
      return !in_array($task->sno, $excludedTaskIds);
    })->values();
 
    $taskCount = $availableTasks->count();
 
    return response([
      'status'  => 200,
      'message' => 'Milestone Product Data Fetched Successfully!',
      'data'    => $availableTasks,
      'task_count' => $taskCount,
      'excluded_tasks_count' => count($excludedTaskIds),
      'service_info' => [
        'product_id' => $services->product_id,
        'service_id' => $sno
      ]
    ], 200);
  }
 
  public function add_multiple_milestone_mapping(Request $request)
  {
    try {
      $user_id = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $customer_id = $request->customer_id;
      $proposal_id = $request->proposal_id;
      $milestone_id = $request->milestone_id;
      $services = $request->services;
 
      // Validation
      $validator = Validator::make($request->all(), [
        'customer_id' => 'required|integer',
        'proposal_id' => 'required|integer',
        'milestone_id' => 'required|integer',
        'services' => 'required|array|min:1',
        'services.*.service_id' => 'required|integer',
        'services.*.tasks' => 'required|array|min:1',
        'services.*.tasks.*' => 'required|integer',
        'services.*.pages' => 'array',
        'services.*.percentages' => 'array'
      ]);
 
      if ($validator->fails()) {
        return response([
          'status' => 422,
          'message' => "Validation Failed",
          'error_msg' => $validator->errors()->first(),
          'data' => null
        ], 422);
      }
 
      DB::beginTransaction();
 
      $createdMilestones = [];
 
      foreach ($services as $serviceData) {
        $service_id = $serviceData['service_id'];
        $tasks = $serviceData['tasks'];
        $pages = $serviceData['pages'] ?? [];
        $percentages = $serviceData['percentages'] ?? [];
 
        // Calculate totals for this service
        $total_pages = 0;
        $total_percentage = 0;
 
        foreach ($tasks as $index => $task_id) {
          if (!empty($pages[$index]) && is_numeric($pages[$index])) {
            $total_pages += (float) $pages[$index];
          }
          if (!empty($percentages[$index]) && is_numeric($percentages[$index])) {
            $total_percentage += (float) $percentages[$index];
          }
        }
 
        // Check if this service is already mapped to this milestone
        $existingMilestone = MilestoneMappingModel::where([
          'branch_id' => $branch_id,
          'customer_id' => $customer_id,
          'proposal_id' => $proposal_id,
          'milestone_id' => $milestone_id,
          'service_id' => $service_id
        ])->first();
 
        if ($existingMilestone) {
          // Get existing task IDs
          $existingTaskIds = json_decode($existingMilestone->task_ids, true) ?? [];
 
          // Check for duplicate tasks
          $duplicateTasks = array_intersect($tasks, $existingTaskIds);
          if (!empty($duplicateTasks)) {
            DB::rollBack();
            return response([
              'status' => 422,
              'message' => "Validation Failed",
              'error_msg' => 'Some tasks are already mapped to this milestone-service combination',
              'data' => null
            ], 422);
          }
 
          // Merge task IDs
          $allTaskIds = array_unique(array_merge($existingTaskIds, $tasks));
 
          // Update the existing record
          $existingMilestone->update([
            'task_ids' => json_encode(array_values($allTaskIds)),
            'total_pages' => $existingMilestone->total_pages + $total_pages,
            'total_percentage' => $existingMilestone->total_percentage + $total_percentage,
            'updated_by' => $user_id
          ]);
 
          $milestone = $existingMilestone->fresh();
        } else {
          // Create new milestone-service mapping
          $milestone = MilestoneMappingModel::create([
            'branch_id' => $branch_id,
            'customer_id' => $customer_id,
            'proposal_id' => $proposal_id,
            'milestone_id' => $milestone_id,
            'service_id' => $service_id,
            'task_ids' => json_encode($tasks),
            'total_pages' => $total_pages,
            'total_percentage' => $total_percentage,
            'created_by' => $user_id,
            'updated_by' => $user_id
          ]);
        }
 
        // Add to history for NEW tasks only
        foreach ($tasks as $index => $task_id) {
          $existingHistory = DB::table('et_milestone_history')
            ->where('milestone_id', $milestone->sno)
            ->where('task_id', $task_id)
            ->first();
 
          if (!$existingHistory) {
            $page_or_per = 0;
            if (!empty($pages[$index]) && is_numeric($pages[$index])) {
              $page_or_per = (float) $pages[$index];
            } elseif (!empty($percentages[$index]) && is_numeric($percentages[$index])) {
              $page_or_per = (float) $percentages[$index];
            }
 
            DB::table('et_milestone_history')->insert([
              'milestone_id' => $milestone->sno,
              'task_id' => $task_id,
              'page_or_per' => $page_or_per,
              'balance' => $page_or_per,
              'created_by' => $user_id,
              'updated_by' => $user_id
            ]);
          }
        }
 
        $createdMilestones[] = $milestone;
      }
 
      // Calculate milestone completion
      $totalServicesCount = DB::table('et_customer_services')
        ->where('proposal_id', $proposal_id)
        ->where('task_status', 0)
        ->count();
 
      $totalMilestonesCount = DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $proposal_id)
        ->count();
 
      $expectedPerMilestone = ($totalServicesCount * 100) / $totalMilestonesCount;
 
      $currentMilestoneTotal = DB::table('et_milestone_mapping')
        ->where('proposal_id', $proposal_id)
        ->where('milestone_id', $milestone_id)
        ->sum('total_percentage');
 
      $isCompleted = abs($currentMilestoneTotal - $expectedPerMilestone) < 0.01 ||
        $currentMilestoneTotal >= $expectedPerMilestone;
 
      // if ($isCompleted) {
      //   DB::table('et_milestone_mapping')
      //     ->where('proposal_id', $proposal_id)
      //     ->where('milestone_id', $milestone_id)
      //     ->update(['is_completed' => 1]);
      // }
 
      DB::commit();
 
      return response([
        'status' => 200,
        'message' => 'Milestones mapped successfully for ' . count($createdMilestones) . ' service(s)',
        'error_msg' => null,
        'data' => $createdMilestones,
        'milestone_stats' => [
          'current_total' => $currentMilestoneTotal,
          'expected_total' => $expectedPerMilestone,
          'remaining' => $expectedPerMilestone - $currentMilestoneTotal,
          'is_completed' => $isCompleted
        ]
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack();
      return response([
        'status' => 500,
        'message' => "Failed to map milestones",
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }
  public function getTaskCategory($id)
  {
    $data = DB::table('et_product_task')
      ->where('status', 0)
      ->where('sno', $id)
      ->select('category_check')
      ->first();
 
    return response([
      'status'  => 200,
      'message' => 'Milestone Product Data Fetched Successfully!',
      'data'    => $data
    ], 200);
  }
 
  public function add_milestone_mapping(Request $request)
  {
    try {
      $user_id = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $customer_id = $request->customer_id;
      $proposal_id = $request->proposal_id;
      $milestone_id = $request->milestone_id;
      $service_id = $request->service_id;
      $tasks = $request->tasks;
      $pages = $request->pages ?? [];
      $percentages = 100;
      $input_total_percentage = $request->total_percentage ?? 0;
 
      // Validation
      $validator = Validator::make($request->all(), [
        'customer_id' => 'required|integer',
        'proposal_id' => 'required|integer',
        'milestone_id' => 'required|integer',
        'service_id' => 'required|integer',
        'tasks' => 'required|array',
        'tasks.*' => 'required|integer'
      ]);
 
      if ($validator->fails()) {
        return response([
          'status' => 422,
          'message' => "Validation Failed",
          'error_msg' => $validator->errors()->first(),
          'data' => null
        ], 422);
      }
 
      DB::beginTransaction();
 
      // Calculate totals for this submission
      $total_pages = 0;
      $total_percentage = 0;
      $hasPercentageTasks = false;
 
      foreach ($tasks as $index => $task_id) {
        if (!empty($pages[$index]) && is_numeric($pages[$index])) {
          $total_pages += (float) $pages[$index];
        }
        if (!empty($percentages[$index]) && is_numeric($percentages[$index])) {
          $hasPercentageTasks = true;
          $total_percentage += (float) $percentages[$index];
        }
      }
 
      // Step 1: Validate service must be 100% if percentage tasks
    //   if ($hasPercentageTasks && $total_percentage != 100) {
    //     DB::rollBack();
    //     return response([
    //       'status' => 422,
    //       'message' => "Validation Failed",
    //       'error_msg' => 'Total percentage must be exactly 100% for this service. Current total: ' . $total_percentage . '%',
    //       'data' => null
    //     ], 422);
    //   }
 
      // Step 2: Get total services and milestones for the proposal
      $totalServices = DB::table('et_customer_services')
        ->where('proposal_id', $proposal_id)
        ->where('task_status', 0)
        ->count();
 
      $totalMilestones = DB::table('et_proposal_pay_slot')
        ->where('proposal_sno', $proposal_id)
        ->count();
 
      $expectedPerMilestone = ($totalServices * 100) / $totalMilestones;
 
      // Step 3: Check if milestone is already completed
      $milestoneCompletionCheck = DB::table('et_milestone_mapping')
        ->where('proposal_id', $proposal_id)
        ->where('milestone_id', $milestone_id)
        ->first();
 
    //   if ($milestoneCompletionCheck && $milestoneCompletionCheck->is_completed == 1) {
    //     DB::rollBack();
    //     return response([
    //       'status' => 422,
    //       'message' => "Validation Failed",
    //       'error_msg' => 'This milestone has already reached its maximum allocation and is marked as completed.',
    //       'data' => null
    //     ], 422);
    //   }
 
      // Step 4: Get current total percentage for this milestone across all services
      $milestoneTotalPercentage = DB::table('et_milestone_mapping')
        ->where('proposal_id', $proposal_id)
        ->where('milestone_id', $milestone_id)
        ->sum('total_percentage');
 
      $newMilestoneTotal = $milestoneTotalPercentage + $total_percentage;
 
      // Step 5: Validate milestone total doesn't exceed expected
      if ($newMilestoneTotal > $expectedPerMilestone) {
        DB::rollBack();
        return response([
          'status' => 422,
          'message' => "Validation Failed",
          'error_msg' => 'Milestone cannot exceed ' . $expectedPerMilestone . '% total. ' .
            'Current: ' . $milestoneTotalPercentage . '%, ' .
            'Adding: ' . $total_percentage . '%, ' .
            'Would be: ' . $newMilestoneTotal . '%',
          'data' => null
        ], 422);
      }
 
      // Check if this milestone+service combination already exists
      $existingMilestone = MilestoneMappingModel::where([
        'branch_id' => $branch_id,
        'customer_id' => $customer_id,
        'proposal_id' => $proposal_id,
        'milestone_id' => $milestone_id,
        'service_id' => $service_id
      ])->first();
 
      if ($existingMilestone) {
        // Get existing task IDs
        $existingTaskIds = json_decode($existingMilestone->task_ids, true) ?? [];
 
        // Check for duplicate tasks
        $duplicateTasks = array_intersect($tasks, $existingTaskIds);
        if (!empty($duplicateTasks)) {
          DB::rollBack();
          return response([
            'status' => 422,
            'message' => "Validation Failed",
            'error_msg' => 'Some tasks are already mapped to this milestone-service combination',
            'data' => null
          ], 422);
        }
 
        // Merge task IDs
        $allTaskIds = array_unique(array_merge($existingTaskIds, $tasks));
 
        // Get existing totals
        $existingTotalPercentage = $existingMilestone->total_percentage;
 
        // Check if service would exceed 100%
        $serviceTotalPercentage = $existingTotalPercentage + $total_percentage;
        if ($serviceTotalPercentage > 100) {
          DB::rollBack();
          return response([
            'status' => 422,
            'message' => "Validation Failed",
            'error_msg' => 'Service cannot exceed 100% total. Current: ' . $existingTotalPercentage . '%, Adding: ' . $total_percentage . '%',
            'data' => null
          ], 422);
        }
 
        // Update the milestone-service mapping
        $existingMilestone->update([
          'task_ids' => json_encode(array_values($allTaskIds)),
          'total_pages' => $existingMilestone->total_pages + $total_pages,
          'total_percentage' => 100,
          'bh_verification' => 1,
          'updated_by' => $user_id
        ]);
 
        $milestone = $existingMilestone->fresh();
        $message = 'Milestone Updated Successfully!';
 
        // Check if service is now 100% complete
        if ($serviceTotalPercentage == 100) {
          $message = 'Service is now 100% complete for this milestone!';
        }
      } else {
        // Create new milestone-service mapping
        $milestone = MilestoneMappingModel::create([
          'branch_id' => $branch_id,
          'customer_id' => $customer_id,
          'proposal_id' => $proposal_id,
          'milestone_id' => $milestone_id,
          'service_id' => $service_id,
          'task_ids' => json_encode($tasks),
          'total_pages' => $total_pages,
          'total_percentage' => 100,
          'bh_verification' => 1,
          'created_by' => $user_id,
          'updated_by' => $user_id
        ]);
 
        $message = "Milestone Mapped Successfully!";
 
        if ($hasPercentageTasks && $total_percentage == 100) {
          $message = "Service is 100% complete for this milestone!";
        }
      }
 
      // --- Insert into milestone history for NEW tasks only ---
      foreach ($tasks as $index => $task_id) {
        // Check if this task already exists in history for this milestone-service
        $existingHistory = DB::table('et_milestone_history')
          ->where('milestone_id', $milestone->sno)
          ->where('task_id', $task_id)
          ->first();
 
        if (!$existingHistory) {
          // Determine page or percentage value for this task
          $page_or_per = 0;
          if (!empty($pages[$index]) && is_numeric($pages[$index])) {
            $page_or_per = (float) $pages[$index];
          } elseif (!empty($percentages[$index]) && is_numeric($percentages[$index])) {
            $page_or_per = (float) $percentages[$index];
          }
 
          DB::table('et_milestone_history')->insert([
            'milestone_id' => $milestone->sno,
            'task_id' => $task_id,
            'page_or_per' => $page_or_per,
            'balance' => $page_or_per,
            'created_by' => $user_id,
            'updated_by' => $user_id
          ]);
        }
      }
 
      // Step 6: Check if milestone has reached its expected total
      $currentMilestoneTotal = DB::table('et_milestone_mapping')
        ->where('proposal_id', $proposal_id)
        ->where('milestone_id', $milestone_id)
        ->sum('total_percentage');
 
      // Calculate if milestone is completed (allow small floating point differences)
    //   $isCompleted = abs($currentMilestoneTotal - $expectedPerMilestone) < 0.01 || $currentMilestoneTotal >= $expectedPerMilestone;
 
    //   if ($isCompleted) {
    //     // Mark ALL records for this milestone as completed
    //     DB::table('et_milestone_mapping')
    //       ->where('proposal_id', $proposal_id)
    //       ->where('milestone_id', $milestone_id)
    //       ->update(['is_completed' => 1]);
 
    //     $message .= ' Milestone has reached its expected total and is now completed!';
    //   }
 
      DB::commit();
 
      return response([
        'status' => 200,
        'message' => $message,
        'error_msg' => null,
        'data' => $milestone,
        'milestone_stats' => [
          'current_total' => $currentMilestoneTotal,
          'expected_total' => $expectedPerMilestone,
          'remaining' => $expectedPerMilestone - $currentMilestoneTotal,
        //   'is_completed' => $isCompleted
        ]
      ], 200);
    } catch (\Exception $e) {
      DB::rollBack();
      return response([
        'status' => 500,
        'message' => "Failed to map milestone",
        'error_msg' => $e->getMessage(),
        'data' => null
      ], 500);
    }
  }
 
  public function get_milestone_current_usage($milestone_id)
  {
    $proposal_id = request('proposal_id');
 
    if (!$proposal_id) {
      return response([
        'status' => 400,
        'message' => 'Proposal ID is required',
        'data' => null
      ], 400);
    }
 
    $currentTotal = DB::table('et_milestone_mapping')
      ->where('proposal_id', $proposal_id)
      ->where('milestone_id', $milestone_id)
      ->sum('total_percentage');
 
    // Get services already mapped to this milestone
    $mappedServices = DB::table('et_milestone_mapping')
      ->where('proposal_id', $proposal_id)
      ->where('milestone_id', $milestone_id)
      ->pluck('service_id')
      ->toArray();
 
    // Check if milestone is completed
    $isCompleted = DB::table('et_milestone_mapping')
      ->where('proposal_id', $proposal_id)
      ->where('milestone_id', $milestone_id)
      ->where('is_completed', 1)
      ->exists();
 
    // Get total services and expected percentage
    $totalServices = DB::table('et_customer_services')
      ->where('proposal_id', $proposal_id)
      ->where('task_status', 0)
      ->count();
 
    $totalMilestones = DB::table('et_proposal_pay_slot')
      ->where('proposal_sno', $proposal_id)
      ->count();
 
    $expectedPerMilestone = ($totalServices * 100) / $totalMilestones;
 
    return response([
      'status' => 200,
      'message' => 'Milestone usage fetched',
      'data' => [
        'current_total' => $currentTotal,
        'mapped_services' => $mappedServices,
        'services_count' => count($mappedServices),
        'expected_percentage' => $expectedPerMilestone,
        'remaining' => $expectedPerMilestone - $currentTotal,
        'is_completed' => $isCompleted,
        'can_add_more' => !$isCompleted && ($currentTotal < $expectedPerMilestone)
      ]
    ], 200);
  }



  public function view($id)
  {
    $data = DB::table('et_customer_services')
      ->where('proposal_id', $id)
      ->select(
        'et_customer_services.pc_id',
        'et_customer_services.customer_id',
        'et_customer.cus_name',
        'et_customer.customer_id',
        'et_customer.cus_email_id',
        'et_customer.cus_mobile',
        'et_staff.staff_name',
        'et_staff.staff_image',
        'et_job_position.job_position_name'
      )
      ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_customer_services.customer_id')
      ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_customer_services.pc_id')
      ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'et_staff.position_role')
      ->first();

    if ($data) {
      $productList = DB::table('et_customer_services')
        ->where('et_customer_services.proposal_id', $id)
        ->leftJoin('et_product', function ($join) {
          $join->on('et_product.sno', '=', 'et_customer_services.product_id')
            ->where('et_customer_services.product_package', '=', 1);
        })
        ->leftJoin('et_package', function ($join) {
          $join->on('et_package.sno', '=', 'et_customer_services.package_id')
            ->where('et_customer_services.product_package', '=', 2);
        })
        ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
        ->select(
          'et_customer_services.product_package',
          'et_customer_services.journal_check',
          'et_customer_services.variant_variable_ids',
          'et_customer_services.created_at',
          'et_customer_services.sno',
          DB::raw("CASE 
            WHEN et_customer_services.product_package = 1 THEN et_product.product_name
            WHEN et_customer_services.product_package = 2 THEN et_package.package_name
            ELSE NULL
          END as product_name")
        )
        ->orderBy('et_customer_services.sno', 'desc')
        ->get();

      foreach ($productList as $product) {
        $variantVariableIds = json_decode($product->variant_variable_ids, true);
        $variantVariableIds = is_array($variantVariableIds) ? $variantVariableIds : [];

        $variantName = '';
        $variableName  = '';

        foreach ($variantVariableIds as $v) {
          $variant = DB::table('et_manage_product_variant')->where('sno', $v['variant_id'])->first();
          $variable = DB::table('et_manage_product_variable')->where('sno', $v['variable_id'])->first();

          if ($variant) {
            $variantName = $variant->product_variant_name ?? '';
          }

          if ($variable) {
            $variableName = $variable->variable_name ?? '';
          }
        }

        $product->variant_name = $variantName;
        $product->variable_name = $variableName;

        $year = date('Y', strtotime($product->created_at));
        $id = str_pad($product->sno, 5, '0', STR_PAD_LEFT);
        $product->service_id = "SR-{$id}/{$year}";
      }

      $data->product_list = $productList;

      $workData = ManageWorkOrderModel::where('proposal_id', $id)->first();

      $workChecklist = json_decode($workData->checklist ?? '[]', true);
      $workChecklistData = is_array($workChecklist) ? $workChecklist : [];

      $checkListName = [];

      if (!empty($workChecklistData)) {
        // Fetch all checklist items in one query
        $chkl_datas = DB::table('et_work_order_checklist')
          ->whereIn('sno', $workChecklistData)
          ->get();

        foreach ($chkl_datas as $chkl_data) {
          $checkListName[] = $chkl_data->work_order_checklist;
        }
      }

      $data->checklists = $checkListName;
      $data->desc = $workData->work_order_desc;

      $paySlots = DB::table('et_proposal_pay_slot')
        ->select(
          'et_proposal_pay_slot.initialPayDate',
          'et_proposal_pay_slot.nextPayDate',
          'et_proposal_pay_slot.payable_amount',
          'et_payment_slot.payment_slot_name'
        )
        ->leftJoin('et_payment_slot', 'et_proposal_pay_slot.slot_id', '=', 'et_payment_slot.sno')
        ->where('et_proposal_pay_slot.proposal_sno', $id)
        ->get();

      $data->pay_slots = $paySlots;
    } else {
      $data = null;
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => $data
    ], 200);
  }
}
