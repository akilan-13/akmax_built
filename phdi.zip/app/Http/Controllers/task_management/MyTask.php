<?php

namespace App\Http\Controllers\task_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\UserRoleModel;
class MyTask extends Controller
{
    public function index(Request $request)
    {
        $roleId = $request->user()->role_id;

        // 🔹 Fetch only favorite tasks for the current user's role
        $tasks = DB::table('et_task_master')
            ->where('role_id', $roleId)
            ->where('favorite', 1) // ✅ Only favorites
            ->get();

        // 🔹 Fetch the related role details
        $roledetails = UserRoleModel::where('sno', $roleId)->first();

        return view('content.task_management.my_task.daily_task', compact('tasks', 'roledetails'));
    }
}

