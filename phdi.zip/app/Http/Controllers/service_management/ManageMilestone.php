<?php

namespace App\Http\Controllers\service_management;

use App\Http\Controllers\Controller;
use App\Models\MilestoneMappingModel;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ManageMilestone extends Controller
{
    // public function index(Request $request) {
    //     $lists = DB::table('et_milestone_mapping')
    //         ->where('et_milestone_mapping.status', '!=', 2)
    //          ->where('et_milestone_mapping.bh_verfication', 1)
    //         ->select(
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
    //             'et_customer.cus_mobile',
    //             'et_customer.cus_email_id',
    //             'et_customer_services.variant_variable_ids',
    //             'et_customer_services.created_at',
    //             'et_customer_services.sno', // This is the service ID
    //             DB::raw("CASE 
    //                 WHEN et_customer_services.product_package = 1 THEN et_product.product_name
    //                 WHEN et_customer_services.product_package = 2 THEN et_package.package_name
    //                 ELSE NULL
    //             END as product_name"),
    //             DB::raw('COUNT(DISTINCT et_milestone_mapping.sno) AS milestone_count'),
    //             DB::raw('SUM(CASE WHEN et_milestone_mapping.milestone_status = 1 THEN 1 ELSE 0 END) AS total_unlock_count')
    //         )
    //         ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_milestone_mapping.customer_id')
    //         ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_milestone_mapping.service_id')
    //         ->leftJoin('et_product', function ($join) {
    //             $join->on('et_product.sno', '=', 'et_customer_services.product_id')
    //                 ->where('et_customer_services.product_package', '=', 1);
    //         })
    //         ->leftJoin('et_package', function ($join) {
    //             $join->on('et_package.sno', '=', 'et_customer_services.package_id')
    //                 ->where('et_customer_services.product_package', '=', 2);
    //         })
    //         ->groupBy([
    //             'et_customer_services.sno',
    //             'et_customer.cus_name',
    //             'et_customer.customer_id',
    //             'et_customer.cus_mobile',
    //             'et_customer.cus_email_id',
    //             'et_customer_services.variant_variable_ids',
    //             'et_customer_services.created_at',
    //             'et_customer_services.product_package',
    //             'et_product.product_name',
    //             'et_package.package_name'
    //         ])
    //         ->orderBy('et_milestone_mapping.sno', 'desc')
    //         ->get();

    //     // Now get task counts for each service
    //     $serviceIds = $lists->pluck('sno')->toArray();
        
    //     $taskCounts = DB::table('et_milestone_mapping')
    //         ->whereIn('service_id', $serviceIds)
    //         ->where('status', '!=', 2)
    //         ->select('service_id', 'task_ids')
    //         ->get()
    //         ->groupBy('service_id');

    //     // Get all unique task IDs from all services
    //     $allTaskIds = [];
    //     foreach ($taskCounts as $serviceTasks) {
    //         foreach($serviceTasks as $milestone) {
    //             $taskIds = json_decode($milestone->task_ids, true);
    //             if(is_array($taskIds)) {
    //                 $allTaskIds = array_merge($allTaskIds, $taskIds);
    //             }
    //         }
    //     }
    //     $allTaskIds = array_unique($allTaskIds);

    //     // Get task names for all task IDs
    //     $taskNames = [];
    //     if (!empty($allTaskIds)) {
    //         $tasks = DB::table('et_product_task')
    //             ->whereIn('sno', $allTaskIds)
    //             ->select('sno', 'task_name') // Fixed: changed 'task_names' to 'task_name'
    //             ->get();

    //         $taskNames = $tasks->pluck('task_name', 'sno')->toArray(); // Fixed: added quotes around 'sno'
    //     }

    //     // Get milestone data for all services at once (better performance)
    //     $milestoneData = DB::table('et_milestone_mapping')
    //         ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
    //         ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
    //         ->select(
    //             'et_milestone_mapping.service_id',
    //             'et_milestone_mapping.sno',
    //             'et_milestone_mapping.milestone_status',
    //             'et_milestone_mapping.task_ids',
    //             'et_payment_slot.payment_slot_name',
    //             'et_proposal_pay_slot.payable_amount',
    //             'et_proposal_pay_slot.paidAmount'
    //         )
    //         ->whereIn('et_milestone_mapping.service_id', $serviceIds)
    //         ->where('et_milestone_mapping.status', '!=', 2)
    //         ->get()
    //         ->groupBy('service_id');

    //     foreach ($lists as $list) {
    //         $variantVariableIds = json_decode($list->variant_variable_ids, true);

    //         $variantName = '';
    //         $variableName = '';

    //         if (is_array($variantVariableIds)) {
    //             foreach ($variantVariableIds as $data) {
    //                 $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
    //                 $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();

    //                 if($variant) {
    //                     $variantName = $variant->product_variant_name ?? '';
    //                 }

    //                 if($variable) {
    //                     $variableName = $variable->variable_name ?? '';
    //                 }
    //             }
    //         }

    //         $year = date('Y', strtotime($list->created_at));
    //         $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
    //         $list->formatted_service_id = "SR-{$id}/{$year}";

    //         $list->variant_name = $variantName;
    //         $list->variable_name = $variableName;

    //         // Calculate total tasks for this service
    //         $allTaskIdsForService = [];
    //         if (isset($taskCounts[$list->sno])) {
    //             foreach ($taskCounts[$list->sno] as $milestone) {
    //                 $taskIds = json_decode($milestone->task_ids, true);
    //                 if (is_array($taskIds)) {
    //                     $allTaskIdsForService = array_merge($allTaskIdsForService, $taskIds);
    //                 }
    //             }
    //             $allTaskIdsForService = array_unique($allTaskIdsForService);
    //         }
            
    //         $list->total_task_count = count($allTaskIdsForService);

    //         // Process milestone data with task names for each milestone separately
    //         $milestoneDataWithTasks = [];
    //         if (isset($milestoneData[$list->sno])) {
    //             foreach ($milestoneData[$list->sno] as $milestone) {
    //                 $milestoneTaskNames = [];
    //                 $taskIds = json_decode($milestone->task_ids, true);
                    
    //                 if (is_array($taskIds)) {
    //                     foreach ($taskIds as $taskId) {
    //                         if (isset($taskNames[$taskId])) {
    //                             $milestoneTaskNames[] = $taskNames[$taskId];
    //                         }
    //                     }
    //                 }
                    
    //                 // Create a new object with all milestone data plus task names
    //                 $milestoneWithTasks = (object)[
    //                     'payment_slot_name' => $milestone->payment_slot_name,
    //                     'payable_amount' => $milestone->payable_amount,
    //                     'paidAmount' => $milestone->paidAmount,
    //                     'task_ids' => $milestone->task_ids,
    //                     'sno' => $milestone->sno,
    //                     'status' => $milestone->milestone_status,
    //                     'task_names' => $milestoneTaskNames,
    //                     'task_count' => count($milestoneTaskNames)
    //                 ];
                    
    //                 $milestoneDataWithTasks[] = $milestoneWithTasks;
    //             }
    //         }
            
    //         $list->milestone_data = $milestoneDataWithTasks;
    //     }

    //     return view('content.service_management.manage_milestone.list', [
    //         'lists' => $lists
    //     ]);
    // }

    public function index(Request $request) {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $search_fill = $request->search_fill ?? '';

        $milestoneQuery = DB::table('et_milestone_mapping')
            ->where('et_milestone_mapping.status', '!=', 2)
            ->where('et_milestone_mapping.bh_verfication', 1)
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer_services.variant_variable_ids',
                'et_customer_services.created_at',
                'et_customer_services.sno', // This is the service ID
                DB::raw("CASE
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name"),
                DB::raw('COUNT(DISTINCT et_milestone_mapping.sno) AS milestone_count'),
                DB::raw('SUM(CASE WHEN et_milestone_mapping.milestone_status = 1 THEN 1 ELSE 0 END) AS total_unlock_count')
            )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_milestone_mapping.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_milestone_mapping.service_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->groupBy([
                'et_customer_services.sno',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer_services.variant_variable_ids',
                'et_customer_services.created_at',
                'et_customer_services.product_package',
                'et_product.product_name',
                'et_package.package_name'
            ]);

        if (!empty($search_fill)) {
            $milestoneQuery->where(function ($query) use ($search_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_package.package_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_customer.cus_email_id', 'LIKE', "%{$search_fill}%");
            });
        }

        $lists = $milestoneQuery->orderBy('et_milestone_mapping.sno', 'desc')
            ->paginate($perpage);

        // Now get task counts for each service
        $serviceIds = $lists->pluck('sno')->toArray();

        $taskCounts = DB::table('et_milestone_mapping')
            ->whereIn('service_id', $serviceIds)
            ->where('status', '!=', 2)
            ->select('service_id', 'task_ids')
            ->get()
            ->groupBy('service_id');

        // Get all unique task IDs from all services
        $allTaskIds = [];
        foreach ($taskCounts as $serviceTasks) {
            foreach($serviceTasks as $milestone) {
                $taskIds = json_decode($milestone->task_ids, true);
                if(is_array($taskIds)) {
                    $allTaskIds = array_merge($allTaskIds, $taskIds);
                }
            }
        }
        $allTaskIds = array_unique($allTaskIds);

        // Get task names for all task IDs
        $taskNames = [];
        if (!empty($allTaskIds)) {
            $tasks = DB::table('et_product_task')
                ->whereIn('sno', $allTaskIds)
                ->select('sno', 'task_name') // Fixed: changed 'task_names' to 'task_name'
                ->get();

            $taskNames = $tasks->pluck('task_name', 'sno')->toArray(); // Fixed: added quotes around 'sno'
        }

        // Get milestone data for all services at once (better performance)
        $milestoneData = DB::table('et_milestone_mapping')
            ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.sno', '=', 'et_milestone_mapping.milestone_id')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->select(
                'et_milestone_mapping.service_id',
                'et_milestone_mapping.sno',
                'et_milestone_mapping.milestone_status',
                'et_milestone_mapping.task_ids',
                'et_payment_slot.payment_slot_name',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount'
            )
            ->whereIn('et_milestone_mapping.service_id', $serviceIds)
             ->where('et_milestone_mapping.bh_verfication', 1)
            ->where('et_milestone_mapping.status', '!=', 2)
            ->get()
            ->groupBy('service_id');

        foreach ($lists as $list) {
            $variantVariableIds = json_decode($list->variant_variable_ids, true);

            $variantName = '';
            $variableName = '';

            if (is_array($variantVariableIds)) {
                foreach ($variantVariableIds as $data) {
                    $variant = DB::table('et_manage_product_variant')->where('sno', $data['variant_id'])->first();
                    $variable = DB::table('et_manage_product_variable')->where('sno', $data['variable_id'])->first();

                    if($variant) {
                        $variantName = $variant->product_variant_name ?? '';
                    }

                    if($variable) {
                        $variableName = $variable->variable_name ?? '';
                    }
                }
            }

            $year = date('Y', strtotime($list->created_at));
            $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
            $list->formatted_service_id = "SR-{$id}/{$year}";

            $list->variant_name = $variantName;
            $list->variable_name = $variableName;

            // Calculate total tasks for this service
            $allTaskIdsForService = [];
            if (isset($taskCounts[$list->sno])) {
                foreach ($taskCounts[$list->sno] as $milestone) {
                    $taskIds = json_decode($milestone->task_ids, true);
                    if (is_array($taskIds)) {
                        $allTaskIdsForService = array_merge($allTaskIdsForService, $taskIds);
                    }
                }
                $allTaskIdsForService = array_unique($allTaskIdsForService);
            }

            $list->total_task_count = count($allTaskIdsForService);

            // Process milestone data with task names for each milestone separately
            $milestoneDataWithTasks = [];
            if (isset($milestoneData[$list->sno])) {
                foreach ($milestoneData[$list->sno] as $milestone) {
                    $milestoneTaskNames = [];
                    $taskIds = json_decode($milestone->task_ids, true);

                    if (is_array($taskIds)) {
                        foreach ($taskIds as $taskId) {
                            if (isset($taskNames[$taskId])) {
                                $milestoneTaskNames[] = $taskNames[$taskId];
                            }
                        }
                    }

                    // Create a new object with all milestone data plus task names
                    $milestoneWithTasks = (object)[
                        'payment_slot_name' => $milestone->payment_slot_name,
                        'payable_amount' => $milestone->payable_amount,
                        'paidAmount' => $milestone->paidAmount,
                        'task_ids' => $milestone->task_ids,
                        'sno' => $milestone->sno,
                        'status' => $milestone->milestone_status,
                        'task_names' => $milestoneTaskNames,
                        'task_count' => count($milestoneTaskNames)
                    ];

                    $milestoneDataWithTasks[] = $milestoneWithTasks;
                }
            }

            $list->milestone_data = $milestoneDataWithTasks;
        }

        return view('content.service_management.manage_milestone.list', [
            'lists' => $lists,
            'search_fill' => $search_fill,
            'perpage' => $perpage
        ]);
    }


    public function get_manage_milestone($id) {
        $data = DB::table('et_milestone_mapping')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_milestone_mapping.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.proposal_id', '=', 'et_milestone_mapping.proposal_id')
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->where('et_milestone_mapping.sno', $id)
            ->select(
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_milestone_mapping.milestone_id',
                'et_milestone_mapping.task_id',
                'et_milestone_mapping.milestone_task_id',
                'et_milestone_mapping.unlock_task_ids',
                DB::raw("CASE 
                    WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                    WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                    ELSE NULL
                END as product_name")
            )
            ->first();

        if (!$data) {
            return response([
                'status' => 404,
                'message' => 'Record not found',
                'error_msg' => null,
                'data' => null
            ], 404);
        }

        $milestoneIds   = json_decode($data->milestone_id, true) ?? [];
        $taskIds        = json_decode($data->task_id, true) ?? [];
        $milestonMapIds = json_decode($data->milestone_task_id, true) ?? [];
        $unlockedTaskIds = json_decode($data->unlock_task_ids, true) ?? [];

        $milestones = DB::table('et_proposal_pay_slot')
            ->leftJoin('et_payment_slot', 'et_payment_slot.sno', '=', 'et_proposal_pay_slot.slot_id')
            ->whereIn('et_proposal_pay_slot.sno', $milestoneIds)
            ->pluck('et_payment_slot.payment_slot_name', 'et_proposal_pay_slot.sno')
            ->toArray();

        $tasks = DB::table('et_product_task')
            ->whereIn('sno', $taskIds)
            ->pluck('task_name', 'sno')
            ->toArray();

        $milestoneData = [];
        foreach ($milestoneIds as $mid) {
            $taskNames = [];
            $taskList  = $milestonMapIds[$mid] ?? [];

            foreach ($taskList as $tid) {
                if (isset($tasks[$tid])) {
                    $taskNames[] = $tasks[$tid];
                }
            }

            $unlockedCount = count(array_intersect($taskList, $unlockedTaskIds));
            $totalCount    = count($taskList);

            if ($totalCount === 0) {
                $status = 'No Tasks';
            } elseif ($unlockedCount === $totalCount) {
                $status = 'Unlocked';
            } elseif ($unlockedCount > 0) {
                $status = 'Partially Unlocked';
            } else {
                $status = 'Locked';
            }

            $milestoneData[] = [
                'milestone_id'   => $mid,
                'milestone_name' => $milestones[$mid] ?? 'Unknown Milestone',
                'tasks'          => $taskNames,
                'task_ids'       => $taskList,
                'status'         => $status
            ];
        }

        $response = [
            'customer_name' => $data->cus_name,
            'customer_id'   => $data->customer_id,
            'product_name'  => $data->product_name,
            'milestones'    => $milestoneData,
        ];

        return response([
            'status' => 200,
            'message' => 'Milestone data fetched successfully!',
            'error_msg' => null,
            'data' => $response
        ], 200);
    }

    public function unlockMilestone(Request $request)
    {
        try {
            $user_id = $request->user_id;
            $sno = $request->sno;
            $reason = $request->reason;

            DB::table('et_milestone_mapping')
                ->where('status', 0)
                ->where('sno', $sno)
                ->update([
                    'milestone_status' => 1,
                    'reason' => $reason
                ]);

            return response([
                'status' => 200,
                'message' => 'Milestone Unlocked',
                'error_msg' => 'Unlock Failed',
                'data' => null
            ], 200);

        } catch (Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Unlock failed!',
                'error_msg' => $e->getMessage()
            ], 500);
        }
    }

    public function unlock(Request $request)
    {
        try {
            $user_id = $request->user_id;
            $sno = $request->sno;

            DB::table('et_milestone_mapping')
                ->where('status', 0)
                ->where('sno', $sno)
                ->update([
                    'milestone_status' => 1
                ]);

            return response([
                'status' => 200,
                'message' => 'Milestone Unlocked',
                'error_msg' => 'Unlock Failed',
                'data' => null
            ], 200);

        } catch (Exception $e) {
            return response([
                'status' => 500,
                'message' => 'Unlock failed!',
                'error_msg' => $e->getMessage()
            ], 500);
        }
    }

}
