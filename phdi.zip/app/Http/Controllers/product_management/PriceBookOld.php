<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use App\Models\PriceBookModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PriceBook extends Controller
{
    public function index(Request $request)
    {
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_fill = $request->search_fill ?? '';

        $latestSnoSubquery = PriceBookModel::select(DB::raw('MAX(sno) as latest_sno'))
            ->where('status', '!=', 2)
            ->groupBy('product_id');

        $query = PriceBookModel::select(
            'et_price_book.*',
            'et_product.product_name',
            'et_product_category.product_category_name',
            'et_product.base_price as base_price',
            'et_product.min_amount as min_amount',
            'et_product.max_amount as max_amount'
        )
            ->joinSub($latestSnoSubquery, 'latest_price_book', function ($join) {
                $join->on('et_price_book.sno', '=', 'latest_price_book.latest_sno');
            })
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')
            ->leftJoin('et_product_category', 'et_product_category.sno', '=', 'et_product.product_category_id')
            ->where('et_price_book.status', '!=', 2);

        if (!empty($search_fill)) {
            $query->where(function ($list) use ($search_fill) {
                $list->where('et_product.product_name', 'LIKE', "%{$search_fill}%");
            });
        }

        $ListTable = $query->orderBy('et_price_book.sno', 'desc')
            ->paginate($perpage);

        return view('content.product_management.manage_price_book.price_book', [
            'ListTable' => $ListTable,
            'perpage' => $perpage,
            'search_fill' => $search_fill,
        ]);
    }

    public function currency_accordion (Request $request) {

        $branch_id = $request->user()->branch_id;
        $branch = DB::table('et_general_settings')
            ->select('et_general_settings.branch_product_currency')
            ->first();

        $currency_codes = json_decode($branch->branch_product_currency, true);

        $data = DB::table('et_country_currencies')
            ->whereIn('sno', $currency_codes)
            ->get();

        if($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

    }

    public function product_data_fetch() {
        $data = DB::table('et_product')
            ->select(
                'et_product.sno',
                'et_product.product_name'
            )
            ->leftJoin('et_price_book', 'et_price_book.product_id', '=', 'et_product.sno')
            ->whereNull('et_price_book.product_id')
            ->where('et_product.status', 0)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function product_variant_data_fetch($id) {
        $data = DB::table('et_manage_product_variable')
            ->select(
                'et_manage_product_variable.*',
                'et_product.base_price',
                'et_product.min_amount',
                'et_product.max_amount'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_manage_product_variable.product_id')
            ->where('et_manage_product_variable.status', 0)
            ->where('et_product.sno', $id)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }

    public function store(Request $request)
    {
        $productId = $request->input('product_id');
        $branchId = $request->user()->branch_id;
        $user_id = $request->user()->user_id;
        $allData = $request->input('data');

        if (empty($productId) || empty($allData)) {
            return response()->json([
                'status' => 400,
                'message' => 'Missing required data',
            ]);
        }

        foreach ($allData as $currencyId => $values) {
            $basePrice = $values['base_price'] ?? 0;
            $minAmount = $values['min_amount'] ?? 0;
            $maxAmount = $values['max_amount'] ?? 0;

            $variantDetails = [];

            if (isset($values['variants']) && is_array($values['variants'])) {
                foreach ($values['variants'] as $variantId => $amount) {
                    $variantDetails[] = [
                        'variant_id' => $variantId,
                        'amount' => $amount,
                    ];
                }
            }

            $create = new PriceBookModel();
            $create->branch_id = $branchId;
            $create->product_id = $productId;
            $create->currency_id = $currencyId;
            $create->base_price = $basePrice;
            $create->min_amount = $minAmount;
            $create->max_amount = $maxAmount;
            $create->varient_details = json_encode($variantDetails);
            $create->created_by = $user_id;
            $create->updated_by = $user_id;
            $create->save();
        }

        if($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Price Book Added Successfully!'
            ]);

            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Price Book Adding Failed!'
            ]);

            return redirect()->back();
        }
    }

    public function Edit($id)
    {
        $dataList = PriceBookModel::where('et_price_book.product_id', $id)
            ->select(
                'et_price_book.*',
                'et_product.product_name',
                'et_country_currencies.currency_symbol',
                'et_country_currencies.currency_name',
                'et_product.base_price as product_base',
                'et_product.min_amount as product_min',
                'et_product.max_amount as product_max'
        )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_price_book.currency_id')
            ->get();

        if ($dataList->isEmpty()) {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

        $responseData = $dataList->map(function ($data) {
            $variantDetails = json_decode($data->varient_details, true) ?? [];
            $variantIds = array_column($variantDetails, 'variant_id');

            $variants = DB::table('et_manage_product_variable')
                ->where('product_id', $data->product_id)
                ->whereIn('sno', $variantIds)
                ->get()
                ->keyBy('sno');

            $variantsWithNames = array_map(function ($item) use ($variants) {
                $variant = $variants->get($item['variant_id']);
                return [
                    'variant_id' => $item['variant_id'],
                    'variant_name' => $variant->variable_name ?? 'Unknown',
                    'amount' => $item['amount'],
                    'variable_amount' => $variant->variable_amount ?? 0,
                ];
            }, $variantDetails);

            $arrayData = $data->toArray();
            $arrayData['variants'] = $variantsWithNames;

            return $arrayData;
        });

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully !',
            'error_msg' => null,
            'data' => $responseData
        ], 200);
    }

    public function Update(Request $request)
    {
        $user_id = $request->user()->user_id;
        $allData = $request->input('data');

        foreach ($allData as $currencyData) {
            $sno = $currencyData['sno'] ?? null;
            if (!$sno) {
                continue; 
            }

            $basePrice = $currencyData['base_price'] ?? 0;
            $minAmount = $currencyData['min_amount'] ?? 0;
            $maxAmount = $currencyData['max_amount'] ?? 0;

            $variantDetails = [];
            if (isset($currencyData['variants']) && is_array($currencyData['variants'])) {
                foreach ($currencyData['variants'] as $variantId => $amount) {
                    $variantDetails[] = [
                        'variant_id' => $variantId,
                        'amount' => $amount,
                    ];
                }
            }

            $priceBook = PriceBookModel::where('sno', $sno)->where('status', '!=', 2)->first();
            if (!$priceBook) {
                // Optionally skip or handle missing record
                continue;
            }

            $priceBook->base_price = $basePrice;
            $priceBook->min_amount = $minAmount;
            $priceBook->max_amount = $maxAmount;
            $priceBook->varient_details = json_encode($variantDetails);
            $priceBook->updated_by = $user_id;
            $priceBook->save();
        }

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Price Book Updated Successfully!',
        ]);

        return redirect()->back();
    }

    public function View($id)
    {
        $dataList = PriceBookModel::where('et_price_book.product_id', $id)
            ->select(
                'et_price_book.*',
                'et_product.product_name',
                'et_country_currencies.currency_symbol',
                'et_country_currencies.currency_name',
                'et_product.base_price as product_base',
                'et_product.min_amount as product_min',
                'et_product.max_amount as product_max'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_price_book.product_id')
            ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_price_book.currency_id')
            ->get();

        if ($dataList->isEmpty()) {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }

        $responseData = $dataList->map(function ($data) {
            $variantDetails = json_decode($data->varient_details, true) ?? [];
            $variantIds = array_column($variantDetails, 'variant_id');

            $variants = DB::table('et_manage_product_variable')
                ->where('product_id', $data->product_id)
                ->whereIn('sno', $variantIds)
                ->get()
                ->keyBy('sno');

            $variantsWithNames = array_map(function ($item) use ($variants) {
                $variant = $variants->get($item['variant_id']);
                return [
                    'variant_id' => $item['variant_id'],
                    'variant_name' => $variant->variable_name ?? 'Unknown',
                    'amount' => $item['amount'],
                    'variable_amount' => $variant->variable_amount ?? 0,
                ];
            }, $variantDetails);

            $arrayData = $data->toArray();
            $arrayData['variants'] = $variantsWithNames;

            return $arrayData;
        });

        return response([
            'status' => 200,
            'message' => 'Data Fetched Successfully !',
            'error_msg' => null,
            'data' => $responseData
        ], 200);
    }
}
