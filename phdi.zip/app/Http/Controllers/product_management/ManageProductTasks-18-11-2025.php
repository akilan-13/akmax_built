<?php

namespace App\Http\Controllers\product_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductModel;
use App\Models\ProductTaskModel;
use App\Models\TaskChecklistModel;
use App\Models\ProductTaskMappingModel;
use Illuminate\Support\Facades\DB;

class ManageProductTasks extends Controller
{
    public function index(Request $request)
    {
        $entity_id   = $request->user()->entity_id;
        $user_id   = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;

        $search_fill = $request->search_fill ?? '';
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;

        $Product = ProductTaskMappingModel::where('et_product_task_mapping.status', '!=', 2)
            ->select(
                'et_product.product_name',

                'et_product_task_mapping.product_id',
                'et_product_task_mapping.variant_id',
                'et_product_category.product_category_name',
                'et_product_task_mapping.sno',
                'et_product_task_mapping.variable_id',
                'et_manage_product_variant.product_variant_name',
                'et_manage_product_variable.variable_name',
                DB::raw('(SELECT COUNT(sno) FROM et_product_task WHERE et_product_task.map_id = et_product_task_mapping.sno AND et_product_task.status=0) as task_count')
            )
            ->where('et_product_task_mapping.branch_id', $branch_id)
            ->leftJoin('et_product', 'et_product_task_mapping.product_id', 'et_product.sno')
            ->leftJoin('et_manage_product_variant', 'et_product_task_mapping.variant_id', 'et_manage_product_variant.sno')
            ->leftJoin('et_manage_product_variable', 'et_product_task_mapping.variable_id', 'et_manage_product_variable.sno')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno');
        if ($search_fill  != '') {
            $Product->where(function ($query) use ($search_fill) {
                $query->where('et_product.product_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_product_variant.product_variant_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_product_category.product_category_name', 'LIKE', "%{$search_fill}%")
                    ->orWhere('et_manage_product_variable.variable_name', 'LIKE', "%{$search_fill}%");
            });
        }
        $Product = $Product->orderBy('et_product_task_mapping.sno', 'desc')->paginate($perpage);
        // return $Product;

        // $product_task_list = DB::table('et_product_task_mapping')->where('status',0)->pluck('product_id');
        // ->whereNotIn('sno',$product_task_list)
        $product_list = DB::table('et_product')->where('status', 0)->get();

        return view('content.product_management.manage_product_task.manage_product_task', [
            'ListTable' => $Product,
            'perpage' => $perpage,
            'Product_list' => $product_list,
            'search_fill' => $search_fill,
        ]);
    }
    public function get_product_variant_data_task(Request $request)
    {
        $id = $request->id;
        $data = DB::table('et_manage_product_variant')
            ->select(
                'et_manage_product_variant.*',
                'et_product.product_category_id',
                'et_product_category.product_category_name'
            )
            ->leftJoin('et_product', 'et_product.sno', '=', 'et_manage_product_variant.product_id')
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_manage_product_variant.status', 0)
            ->where('et_product.sno', $id)
            ->get();
        $data_category = DB::table('et_product')
            ->select(
                'et_product.product_category_id',
                'et_product_category.product_category_name'
            )
            ->leftJoin('et_product_category', 'et_product.product_category_id', 'et_product_category.sno')
            ->where('et_product.sno', $id)
            ->first();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data,
                'data_category' => $data_category,
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }
    public function get_product_variable_data_task(Request $request)
    {
        $id = $request->id;
        $data = DB::table('et_manage_product_variable')
            ->select(
                'et_manage_product_variable.*'
            )
            ->where('et_manage_product_variable.status', 0)
            ->where('et_manage_product_variable.product_variant_id', $id)
            ->get();

        if ($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 402,
                'message' => 'Data Fetching Failed!',
                'error_msg' => null,
                'data' => null
            ], 402);
        }
    }
    public function Product_by_category(Request $request)
    {
        $id = $request->input('category_id');
        $data = ProductModel::where('status', 0)->where('product_category_id', $id)->get();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $data
        ], 200);
    }
    public function Add_product_task_mapping(Request $request)
    {
        DB::beginTransaction();

        // return $request;
        try {

            $user_id      = $request->user()->user_id;
            $branch_id    = $request->user()->branch_id;
            $task_names   = $request->task_name ?? [];
            $product_id   = $request->product_id;
            $variant_id   = $request->variant_id ?? 0;
            $variable_id  = $request->variable_id ?? 0;
            $product_cat_id = $request->cat_id_hide;

            // --------------------------
            // CREATE MAIN MAPPING RECORD
            // --------------------------
            $mapping = new ProductTaskMappingModel();
            $mapping->product_id  = $product_id;
            $mapping->variant_id  = $variant_id;
            $mapping->variable_id = $variable_id;
            $mapping->branch_id   = $branch_id;
            $mapping->created_by  = $user_id;
            $mapping->updated_by  = $user_id;
            $mapping->save();


            // --------------------------
            // FIRST PASS: PERCENTAGE LOGIC
            // --------------------------
            $totalFixedPercentage = 0;
            $flexibleTasks = [];

            foreach ($task_names as $i => $task_name) {

                $isFlexible = ($request->input("task_flex_$i") == 1);
                $taskPer    = floatval($request->input("task_pecentage_hidden_$i") ?? 0);

                if ($isFlexible) {
                    $flexibleTasks[] = $i;
                } else {
                    $totalFixedPercentage += $taskPer;
                }
            }

            // Validate total
            if ($totalFixedPercentage > 100) {
                DB::rollBack();
                return back()->with('toastr', [
                    'type'    => 'error',
                    'message' => 'Total fixed task percentage exceeds 100%.'
                ]);
            }

            // Distribute remaining % to flexible tasks
            $flexibleCount = count($flexibleTasks);
            $remainingPercentage   = 100 - $totalFixedPercentage;
            $eachFlexiblePercentage = $flexibleCount > 0
                ? ($remainingPercentage / $flexibleCount)
                : 0;


            // --------------------------
            // SECOND PASS: SAVE RECORDS
            // --------------------------
            foreach ($task_names as $i => $task_name) {

                // ----- EMP SKILL TYPE -----
                $skill = DB::table('et_employee_skill')->where('default_share', 0)->first();
                $skill_id = $skill ? $skill->sno : 0;
                // return $request->input("code_or_write_$i");
                // If UI category override exists
                if ($request->has("code_or_write_$i")) {
                    $category_id = $request->input("code_or_write_$i");
                    // return 'if';
                } else {
                    if ($product_cat_id == 1) {
                        $prd_cat = 0;
                    } else {
                        $prd_cat = 1;
                    }
                    $category_id = $prd_cat;
                    // return 'elsr';
                }
                // return $product_cat_id;


                // Product category (1 = write, 2 = code)
                $productCategory = intval($product_cat_id);

                // For each task:
                if ($request->has("code_or_write_$i")) {
                    // Checkbox sends 0 or 1 always as STRING → cast to int
                    $category_id = intval($request->input("code_or_write_$i"));
                    $category_id = ($category_id == 1) ? 0 : 1;
                } else {

                    // If no checkbox sent → AUTO DEFAULT based on product category
                    // WRITE PRODUCT (1) → default WRITE TYPE (0)
                    // CODE PRODUCT  (2) → default CODE TYPE  (1)

                    $category_id = ($productCategory == 1) ? 0 : 1;
                }


                $cat = 0;
                $taskData = [];

                $isCodingTask = $request->input('code_or_write_' . $i, 0) == 1;

                if ($isCodingTask) {
                    $cat = 1;
                    // Process as coding task
                    $taskData = [
                        'type' => 'code',
                        1 => ['percent' => 100, 'hours' => $request->input("junior_hours_$i")],
                        2 => ['percent' => 100, 'hours' => $request->input("mid_hours_$i")],
                        3 => ['percent' => 100, 'hours' => $request->input("senior_hours_$i")]
                    ];
                } else {
                    $cat = 0;
                    // Process as writing task
                    $taskData = [
                        'type' => 'write',
                        1 => ['pages' => 1, 'words' => $request->input("jr_word_count_$i"),  'hours' => $request->input("jr_hours_$i")],
                        2 => ['pages' => 1, 'words' => $request->input("mid_word_count_$i"), 'hours' => $request->input("midl_hours_$i")],
                        3 => ['pages' => 1, 'words' => $request->input("sr_word_count_$i"),  'hours' => $request->input("sr_hours_$i")]
                    ];
                }



                // Percentage check (fixed / flexible)
                $isFlexible = ($request->input("task_flex_$i") == 1);
                $taskPer = $isFlexible ? $eachFlexiblePercentage :
                    floatval($request->input("task_pecentage_hidden_$i"));

                // Current skill hours
                $skill_hours = in_array($skill_id, [1, 2, 3]) ? ($emp_skill[$skill_id]['hours'] ?? 0) : 0;


                // ----- SAVE TASK -----
                $task = new ProductTaskModel();
                $task->map_id          = $mapping->sno;
                $task->product_id      = $product_id;
                $task->task_name       = $task_name;
                $task->task_percentage = $taskPer;
                $task->emp_skill_id    = $skill_id;
                $task->emp_skill       = json_encode($taskData);
                $task->flexible_check  = $isFlexible ? 1 : 0;
                $task->category_check  = $cat;
                $task->hours_id        = $skill_hours;
                $task->branch_id       = $branch_id;
                $task->created_by      = $user_id;
                $task->updated_by      = $user_id;
                $task->save();


                // ----- SAVE CHECKLIST ITEMS -----
                $task_checklist = $request->task_checklist[$i] ?? [];

                foreach ($task_checklist as $item) {
                    TaskChecklistModel::create([
                        'map_id'          => $mapping->sno,
                        'product_id'      => $product_id,
                        'product_task_id' => $task->sno,
                        'task_checklist'  => $item,
                        'created_by'      => $user_id,
                        'updated_by'      => $user_id,
                    ]);
                }
            }


            DB::commit();
            // return $request;

            return back()->with('toastr', [
                'type'    => 'success',
                'message' => 'Product Task added Successfully!'
            ]);
        } catch (\Exception $e) {

            DB::rollBack();
            // \Log::error("Add_product_task_mapping ERROR: " . $e->getMessage());

            return back()->with('toastr', [
                'type'    => 'error',
                'message' => 'Failed to add product tasks. Please try again.'
            ]);
        }
    }

    public function Edit(Request $request)
    {
        $entity_id = $request->user()->entity_id;
        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;
        $id = $request->id;

        // Fetch the product task mapping with related data
        $Product = ProductTaskMappingModel::where('et_product_task_mapping.status', '!=', 2)
            ->select(
                'et_product_task_mapping.sno',
                'et_product_task_mapping.product_id',
                'et_product_task_mapping.variant_id',
                'et_product.product_name',
                'et_product.product_category_id',
                'et_product_category.product_category_name',
                'et_product_task_mapping.variable_id'
            )
            ->leftJoin('et_product', 'et_product_task_mapping.product_id', '=', 'et_product.sno')
            ->leftJoin('et_manage_product_variant', 'et_product_task_mapping.variant_id', '=', 'et_manage_product_variant.sno')
            ->leftJoin('et_manage_product_variable', 'et_product_task_mapping.variable_id', '=', 'et_manage_product_variable.sno') // fixed join key here
            ->leftJoin('et_product_category', 'et_product.product_category_id', '=', 'et_product_category.sno')
            ->where('et_product_task_mapping.sno', $id)
            ->first();

        $product_task_list = collect();
        $check_list = collect();

        if ($Product) {
            // Get product tasks associated with the product mapping
            $product_task_list = ProductTaskModel::where('status', 0)
                ->where('map_id', $Product->sno)
                ->get();

            // For each product task, get the checklist and store by task ID
            $check_list = [];
            foreach ($product_task_list as $pt) {
                $check_list = TaskChecklistModel::where('status', 0)
                    ->where('product_task_id', $pt->sno)
                    ->where('map_id', $Product->sno)
                    ->get();
                $pt->check_list = $check_list;
            }
        }

        $product_list = DB::table('et_product')->where('status', 0)->get();

        return view('content.product_management.manage_product_task.edit', [
            'edit' => $Product,
            'Product_list' => $product_list,
            'product_task_list' => $product_task_list,
        ]);
    }
    public function Update_product_task_mapping(Request $request)
    {
        DB::beginTransaction();

        try {
            $user_id   = $request->user()->user_id;
            $branch_id = $request->user()->branch_id;
            $edit_map_id  = $request->edit_map_id;

            $task_names  = $request->task_name ?? [];
            $product_id  = $request->edit_product_id;
            $variant_id  = $request->edit_variant_id ?? 0;
            $variable_id = $request->edit_variable_id ?? 0;

            // Save main mapping
            $mapping = ProductTaskMappingModel::where('sno', $edit_map_id)->first();
            if (!$mapping) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Mapping not found.'
                ]);
                return redirect()->back();
            }

            $mapping->product_id  = $product_id;
            $mapping->variant_id  = $variant_id;
            $mapping->variable_id = $variable_id;
            $mapping->branch_id   = $branch_id;
            $mapping->updated_by  = $user_id;
            $mapping->save();

            $update_ids = $request->edit_task_ids ?? [];

            $OldIds = ProductTaskModel::where('map_id', $mapping->sno)
                ->where('status', '!=', 2)
                ->get();

            $existingIds = $OldIds->pluck('sno')->toArray();

            $ToDeleteDiff = array_diff($existingIds, $update_ids);
            $ToDelete = array_values($ToDeleteDiff);

            if (!empty($ToDelete)) {
                $deleteTask = DB::table('et_product_task')->whereIn('sno', $ToDelete)
                    ->update(['status' => 2]);
            }

            $totalFixedPercentage = 0;
            $flexibleTasksIndices = [];

            foreach ($task_names as $i => $task_name) {
                $isFlexible = $request->input("edit_task_flex_$i") == 1;
                $taskPer = floatval($request->input("edit_task_pecentage_hidden_$i") ?? 0);

                if ($isFlexible) {
                    $flexibleTasksIndices[] = $i;
                } else {
                    $totalFixedPercentage += $taskPer;
                }
            }

            $remainingPercentage = 100 - $totalFixedPercentage;
            $flexibleCount = count($flexibleTasksIndices);

            if ($remainingPercentage < 0) {
                DB::rollBack();
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Total fixed task percentage exceeds 100%.'
                ]);
                return redirect()->back();
            }

            $eachFlexiblePercentage = $flexibleCount > 0 ? $remainingPercentage / $flexibleCount : 0;

            foreach ($task_names as $i => $task_name) {
                $emp_skill = [];
                $isCodingTask = $request->input("edit_code_or_write_$i") == 1;

                if ($isCodingTask) {
                    // Coding task - use code allocation fields
                    $emp_skill = [
                        'type' => 'code',
                        1 => [
                            'percent' => 100,
                            'hours'   => $request->input("junior_hours_$i"),
                        ],
                        2 => [
                            'percent' => 100,
                            'hours'   => $request->input("mid_hours_$i"),
                        ],
                        3 => [
                            'percent' => 100,
                            'hours'   => $request->input("senior_hours_$i"),
                        ],
                    ];
                } else {
                    // Writing task - use write allocation fields
                    $emp_skill = [
                        'type' => 'write',
                        1 => [
                            'pages' => 1,
                            'words' => $request->input("jr_word_count_$i"),
                            'hours' => $request->input("jr_hours_$i"),
                        ],
                        2 => [
                            'pages' => 1,
                            'words' => $request->input("mid_word_count_$i"),
                            'hours' => $request->input("midl_hours_$i"),
                        ],
                        3 => [
                            'pages' => 1,
                            'words' => $request->input("sr_word_count_$i"),
                            'hours' => $request->input("sr_hours_$i"),
                        ],
                    ];
                }

                $isFlexible = $request->input("edit_task_flex_$i") == 1;
                $taskPer = $isFlexible ? $eachFlexiblePercentage : floatval($request->input("edit_task_pecentage_hidden_$i"));
                $task_sno = $request->input("edit_task_id_$i");

                if ($task_sno > 0) {
                    // Update task
                    $task = ProductTaskModel::where('sno', $task_sno)->first();
                    $task->map_id         = $mapping->sno;
                    $task->product_id     = $product_id;
                    $task->task_name      = $task_name;
                    $task->task_percentage = $taskPer;
                    $task->flexible_check = $isFlexible ? 1 : 0;
                    $task->category_check = $isCodingTask ? 1 : 0;
                    $task->emp_skill      = json_encode($emp_skill);
                    $task->branch_id      = $branch_id;
                    $task->updated_by     = $user_id;
                    $task->save();
                } else {
                    // Create new task
                    $task = new ProductTaskModel();
                    $task->map_id         = $mapping->sno;
                    $task->product_id     = $product_id;
                    $task->task_name      = $task_name;
                    $task->task_percentage = $taskPer;
                    $task->flexible_check = $isFlexible ? 1 : 0;
                    $task->category_check = $isCodingTask ? 1 : 0;
                    $task->emp_skill      = json_encode($emp_skill);
                    $task->branch_id      = $branch_id;
                    $task->created_by     = $user_id;
                    $task->updated_by     = $user_id;
                    $task->save();
                }

                // Handle checklist items
                $task_checklist = $request->task_checklist[$i] ?? [];
                $edit_check_ids = $request->edit_check_id[$i] ?? [];

                $update_idsChecklist = $edit_check_ids;

                $OldIdsChecklist = TaskChecklistModel::where('map_id', $mapping->sno)
                    ->where('product_task_id', $task->sno)
                    ->where('status', '!=', 2)
                    ->get();

                $existingIdsChecklist = $OldIdsChecklist->pluck('sno')->toArray();

                $ToDeleteChecklistDiff = array_diff($existingIdsChecklist, $update_idsChecklist);
                $ToDeleteChecklist = array_values($ToDeleteChecklistDiff);

                if (!empty($ToDeleteChecklist)) {
                    $deleteTask = DB::table('et_task_checklist')->whereIn('sno', $ToDeleteChecklist)
                        ->update(['status' => 2]);
                }

                foreach ($task_checklist as $index => $tcl) {
                    $check_sno = $edit_check_ids[$index] ?? 0;

                    if ($check_sno > 0) {
                        // Update checklist
                        $checklist = TaskChecklistModel::where('sno', $check_sno)->first();
                        if ($checklist) {
                            $checklist->map_id          = $mapping->sno;
                            $checklist->product_id      = $product_id;
                            $checklist->product_task_id = $task->sno;
                            $checklist->task_checklist  = $tcl;
                            $checklist->updated_by      = $user_id;
                            $checklist->save();
                        }
                    } else {
                        // Create new checklist
                        $checklist = new TaskChecklistModel();
                        $checklist->map_id          = $mapping->sno;
                        $checklist->product_id      = $product_id;
                        $checklist->product_task_id = $task->sno;
                        $checklist->task_checklist  = $tcl;
                        $checklist->created_by      = $user_id;
                        $checklist->updated_by      = $user_id;
                        $checklist->save();
                    }
                }
            }

            DB::commit();

            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Product Task Updated Successfully!'
            ]);

            return redirect()->back();
        } catch (\Exception $e) {
            DB::rollBack();

            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Failed to update product tasks. Please try again.'
            ]);

            return redirect()->back();
        }
    }
}
