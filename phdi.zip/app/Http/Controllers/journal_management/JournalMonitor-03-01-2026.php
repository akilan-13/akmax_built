<?php

namespace App\Http\Controllers\journal_management;

use App\Http\Controllers\Controller;
use App\Models\DomainModel;
use App\Models\JournalMonitorModel;
use Illuminate\Support\Facades\DB;
use App\Models\ManageJournalModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use PhpParser\JsonDecoder;

class JournalMonitor extends Controller
{
    public function indexs(Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $journals = DB::table('et_journal_monitor')
            ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')
            // Conditionally join et_product if product_package = 1
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_product_category if product_package = 1
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_package if product_package = 2
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_journal_monitor.*',
                'et_customer.cus_name',
                'et_journal_history.paper_name',
                'et_journal_booklet.journal_name',
                'et_customer.customer_id',
                'et_journal_booklet.domain_id',
                'et_customer_services.product_package',
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name"),
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                        ELSE NULL
                    END as category_name")
            )
            ->where('et_journal_monitor.branch_id', $branch_id)
            ->get();

        foreach ($journals as $journal) {
            $domainIds = json_decode($journal->domain_id, true);
            if (is_array($domainIds)) {
                $domains = DomainModel::whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
                $journal->domain_names = $domains;
            } else {
                $journal->domain_names = [];
            }
        }

        return view('content.journal_management.journal_monitor.list', compact('journals'));
    }

    public function index(Request $request)
    {

        $branch_id = $request->user()->branch_id;

        $lists = DB::table('et_manage_journal')
            ->where('et_manage_journal.status', '!=', 2)
            ->where('et_manage_journal.branch_id', $branch_id)
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_journal.customer_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_manage_journal.booklet_id')
            ->select(
                'et_manage_journal.sno',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'et_journal_booklet.journal_name',
                'et_journal_booklet.domain_id',
                'et_manage_journal.paper_name',
                'et_manage_journal.journal_id',
                'et_manage_journal.publish_author',
                'et_manage_journal.publish_url',
                'et_manage_journal.publish_date',
                'et_manage_journal.status'
            )
            ->get();

        foreach ($lists as $journal) {
            if ($journal->domain_id) {
                $domain_ids = json_decode($journal->domain_id, true);

                if (is_array($domain_ids) && !empty($domain_ids)) {
                    $domain_names = DB::table('et_domain')
                        ->whereIn('et_domain.sno', $domain_ids)
                        ->where('et_domain.status', 0)
                        ->pluck('domain_name')
                        ->toArray();

                    $journal->domain_names = $domain_names;
                } else {
                    $journal->domain_names = [];
                }
            } else {
                $journal->domain_names = [];
            }
        }

        return view('content.journal_management.journal_monitor.list', [
            'lists' => $lists
        ]);
    }

    public function dataFetchForm($id){

        $data = DB::table('et_journal_monitor')
            ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')
            // Conditionally join et_product if product_package = 1
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_product_category if product_package = 1
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditionally join et_package if product_package = 2
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.package_id')
                    ->where('et_customer_services.product_package', '=', 2);
            })
            ->select(
                'et_journal_monitor.*',
                'et_customer.cus_name',
                'et_journal_history.paper_name',
                'et_journal_booklet.journal_name',
                'et_customer.customer_id',
                'et_journal_booklet.domain_id',
                'et_customer_services.product_package',
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                        WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                        ELSE NULL
                    END as service_name"),
                DB::raw("CASE 
                        WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                        ELSE NULL
                    END as category_name")
            )
            ->where('et_journal_monitor.sno', $id)
            ->first();

        $domainIds = json_decode($data->domain_id, true);

        if (is_array($domainIds)) {
            $domains = DomainModel::whereIn('sno', $domainIds)->pluck('domain_name')->toArray();
            $data->domain_names = $domains;
        } else {
            $data->domain_names = [];
        }

            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully !',
                'error_msg' => 'Error Fetching Data !',
                'data' => $data
            ], 200);
    }

    public function storeRejectionForm(Request $request){

        $user_id = $request->user()->user_id;

        $validator = Validator::make($request->all(), [
            'rejected_reason' => 'required'
        ]);

        if($validator->fails()){
            return response([
                'status' => 404,
                'message' => 'Incorrect Input Field Format !',
                'error_msg' => null,
                'data' => null
            ], 404);
        }

        $sno = $request->cancel_id;
        $reject_manage_journal = $request->reject_manage_journal;
        
        $Create = JournalMonitorModel::where('sno', $sno)->first();
        $Create->rejected_reason = $request->rejected_reason;
        $Create->status = 2;
        $Create->created_by = $user_id;
        $Create->updated_by = $user_id;
        $Create->update();
        
        $Add = ManageJournalModel::where('sno', $reject_manage_journal)->first();

        if ($Add) {
            $Add->rejected_count++;
            $Add->update();
        } else {
            return response([
                'status' => 404,
                'message' => 'Journal not found',
                'error_msg' => 'No journal matches the provided ID',
                'data' => null
            ], 404);
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Journal Rejected Successfully'
        ]);
    }

    public function reviewedFiles(Request $request)
    {
        $request->validate([
            'file_upload.*' => 'required|file|max:10240' // max 10MB
        ]);

        $uploaded = [];

        foreach ($request->file('file_upload') as $file) {

            $timestamp = now()->format('Ymd_His'); // e.g., 20250618_142530
            $extension = $file->getClientOriginalExtension();

            // Create a unique filename using timestamp and a unique ID
            $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

            // Move the file
            $file->move(public_path('reviewed_journals'), $fileName);

            $uploaded[] = $fileName;
        }

        return response()->json([
            'success' => true,
            'files' => $uploaded
        ]);
    }

    public function addReviewForm(Request $request){
        $validator = Validator::make($request->all(), [
            'reviewer_comment' => 'required'
        ]);

        if($validator->fails()){
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 401);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->review_id;
        $review_customer_id = $request->review_customer_id;

        $review = JournalMonitorModel::where('sno', $sno)->first();
        $review->reviewer_comment = $request->reviewer_comment;
        $review->status = 1;
        $review->created_by = $user_id;
        $review->updated_by = $user_id;
        $review->update();

        if($request->filled('uploaded_files')){
            $files = json_decode($request->uploaded_files, true);
        }

        if($request->filled('uploaded_files')){
            $files = json_decode($request->uploaded_files, true);
            $review->reviewed_document = json_encode($files);
            $review->update();
        }

        $Add = ManageJournalModel::where('sno', $review_customer_id)->first();
        if ($Add) {
            $Add->review_count++;
            $Add->updated_by = $user_id;
            $Add->update();
        } else {

            return response([
                'status' => 404,
                'message' => 'Journal not found',
                'error_msg' => 'No journal matches the provided ID',
                'data' => null
            ], 404);
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Journal Reviewed Successfully'
        ]);
    }

    public function storeResubmittedForm(Request $request)
    {

        $user_id = $request->user()->user_id;

        $sno = $request->resubmitted_id;
        $resubmitted_journal_id = $request->resubmitted_journal_id;

        $Create = JournalMonitorModel::where('sno', $sno)->first();
        $Create->status = 3;
        $Create->created_by = $user_id;
        $Create->updated_by = $user_id;
        $Create->update();

        $Add = ManageJournalModel::where('sno', $resubmitted_journal_id)->first();
        if ($Add) {
            $Add->resubmitted_count++;
            $Add->updated_by = $user_id;
            $Add->update();
        } else {

            return response([
                'status' => 404,
                'message' => 'Journal not found',
                'error_msg' => 'No journal matches the provided ID',
                'data' => null
            ], 404);
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Journal Resubmitted Successfully'
        ]);
    }

    public function storeAcceptedForm(Request $request)
    {

        $user_id = $request->user()->user_id;

        $sno = $request->accepted_id;
        $accepted_journal_id = $request->accepted_journal_id;

        $Create = JournalMonitorModel::where('sno', $sno)->first();
        $Create->status = 4;
        $Create->created_by = $user_id;
        $Create->updated_by = $user_id;
        $Create->update();

        $Add = ManageJournalModel::where('sno', $accepted_journal_id)->first();
        if ($Add) {
            $Add->accepted_count++;
            $Add->updated_by = $user_id;
            $Add->update();
        } else {

            return response([
                'status' => 404,
                'message' => 'Journal not found',
                'error_msg' => 'No journal matches the provided ID',
                'data' => null
            ], 404);
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Journal Accepted Successfully'
        ]);
    }

    public function publishedFiles(Request $request)
    {
        $request->validate([
            'publish_uploaded_files.*' => 'required|file|max:10240' // max 10MB
        ]);

        $uploadedFiles = [];

        foreach ($request->file('publish_uploaded_files') as $file) {

            $timestamp = now()->format('Ymd_His'); // e.g., 20250618_142530
            $extension = $file->getClientOriginalExtension();

            // Create a unique filename using timestamp and a unique ID
            $fileName = $timestamp . '_' . uniqid() . '.' . $extension;

            // Move the file
            $file->move(public_path('published_journals'), $fileName);

            $uploadedFiles[] = $fileName;
        }

        return response()->json([
            'success' => true,
            'files' => $uploadedFiles
        ]);
    }

    public function addPublishedForm(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'publish_paper' => 'required'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 401);
        }

        $user_id = $request->user()->user_id;
        $sno = $request->published_id;
        $published_journal_id = $request->published_journal_id;

        $review = JournalMonitorModel::where('sno', $sno)->first();

        if (!$review) {
            return response([
                'status' => 404,
                'message' => 'Journal Monitor record not found',
                'error_msg' => 'No record matches the provided published_id',
                'data' => null
            ], 404);
        }

        $review->published_date = $request->publish_date;
        $review->paper_name = $request->publish_paper;
        $review->author_name = $request->publish_author;
        $review->published_url = $request->publish_url;
        $review->published_desc = $request->publish_desc;
        $review->status = 5;
        $review->created_by = $user_id;
        $review->updated_by = $user_id;
        $review->update();

        if ($request->filled('publish_uploaded_files')) {
            $files = json_decode($request->publish_uploaded_files, true);
        }

        if ($request->filled('publish_uploaded_files')) {
            $files = json_decode($request->publish_uploaded_files, true);
            $review->published_document = json_encode($files);
            $review->save();
        }

        $Add = ManageJournalModel::where('sno', $published_journal_id)->first();
        if ($Add) {
            $Add->published_count++;
            $Add->updated_by = $user_id;
            $Add->update();

            DB::table('et_customer_services')
                ->where('sno', $Add->customer_services_id)
                ->update(['published_status' => 1]);
        } else {

            return response([
                'status' => 404,
                'message' => 'Journal not found',
                'error_msg' => 'No journal matches the provided ID',
                'data' => null
            ], 404);
        }

        return redirect()->back()->with('toastr', [
            'type' => 'success',
            'message' => 'Journal Published Successfully'
        ]);
    }

    public function viewJournal($id)
    {
        // First, get the monitor with all necessary joins
        $monitor = JournalMonitorModel::select(
            'et_journal_monitor.*',
            'et_customer.cus_name',
            'et_customer.customer_id',
            'et_journal_booklet.journal_name',
            'et_journal_booklet.domain_id',
            'et_journal_history.paper_name',
            'et_journal_history.description',
            'et_journal_history.documents',
            'et_customer_services.product_package',
            'et_customer_services.sno as customer_sno',
            DB::raw("et_journal_monitor.status as journal_monitor_status"),
            DB::raw("et_journal_monitor.paper_name as journal_monitor_paper"),
            DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product.product_name
                WHEN et_customer_services.product_package = 2 THEN et_package.package_name
                ELSE NULL
            END as service_name"),
            DB::raw("CASE 
                WHEN et_customer_services.product_package = 1 THEN et_product_category.product_category_name
                ELSE NULL
            END as category_name")
        )
            ->leftJoin('et_journal_history', 'et_journal_history.sno', '=', 'et_journal_monitor.journal_history_id')
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_journal_history.customer_id')
            ->leftJoin('et_customer_services', 'et_customer_services.sno', '=', 'et_journal_history.customer_services_id')
            ->leftJoin('et_journal_booklet', 'et_journal_booklet.sno', '=', 'et_journal_history.journal_booklet_id')

            // Conditional join for product
            ->leftJoin('et_product', function ($join) {
                $join->on('et_product.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 1);
            })
            ->leftJoin('et_product_category', function ($join) {
                $join->on('et_product_category.sno', '=', 'et_product.product_category_id')
                    ->where('et_customer_services.product_package', '=', 1);
            })

            // Conditional join for package
            ->leftJoin('et_package', function ($join) {
                $join->on('et_package.sno', '=', 'et_customer_services.product_package')
                    ->where('et_customer_services.product_package', '=', 2);
            })

            // Only fetch if the manage_journal entry matches
            ->where('et_journal_monitor.sno', $id)
            ->first();

        // If no record found, return 404
        if (!$monitor) {
            return response()->json([
                'status' => false,
                'message' => 'Journal not found',
                'data' => null
            ], 404);
        }

        // Decode domain_id and fetch associated domain names
        $domainIds = json_decode($monitor->domain_id, true);

        if (is_array($domainIds)) {
            $domains = DomainModel::whereIn('sno', $domainIds)->pluck('domain_name');
        } else {
            $domains = collect();
        }

        // Attach domain names to the monitor object
        $monitor->domain_names = $domains;

        // Decode Published Document
        $uploadedFiles = [];
        if (!empty($monitor->published_document)) {
            $uploadedFiles = json_decode($monitor->published_document, true);
            if (!is_array($uploadedFiles)) {
                $uploadedFiles = [];
            }
        }

        // Decode Reviewed Document
        $reviewedFiles = [];
        if (!empty($monitor->reviewed_document)) {
            $reviewedFiles = json_decode($monitor->reviewed_document, true);
            if (!is_array($reviewedFiles)) {
                $reviewedFiles = [];
            }
        }

        // Decode Submitted Document
        $submittedFiles = [];
        if(!empty($monitor->documents)){
            $submittedFiles = json_decode($monitor->documents, true);
            if(!is_array($submittedFiles)) {
                $submittedFiles = [];
            }
        }

        $responseData = $monitor->toArray();
        $responseData['uploaded_files'] = $uploadedFiles;
        $responseData['reviewed_files'] = $reviewedFiles;
        $responseData['submitted_files'] = $submittedFiles;

        // Return successful response
        return response()->json([
            'status' => 200,
            'message' => 'Data fetched successfully!',
            'data' => $responseData
        ], 200);
    }
}