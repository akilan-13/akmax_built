<?php

namespace App\Http\Controllers\whatsapp_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\WhatsappContactModel;
use App\Models\WhatsappMessageModel;
use App\Events\NewMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http; // Import Http facade
use Carbon\Carbon;

class WhatsappConfig extends Controller
{
    public function WhatsappWebhook(Request $request)
    {
        $accessToken = 'EAAFb1ehfWDIBO3IxRjM766z6Hyx00dC8MzmepCI5QZC30BjNU4z72nwDmegzVtxZBQKv1o0iyD7HduA4PUtPiA1iZBJvFAcntx2wSiJFU69VKWZBevCW3B0Dbai0RZB4gKFM6ZBycwnD5VUCKL3jTea95GTLBGgGTYm07ihWVngg750IBWeZB7nubdG6Lov4bbdnwZDZD';
        $verfiy_token='2027d0dfea8175ec07b42b2245da10f7';
        // Handle verification challenge
        if ($request->method() === 'GET') {
            $mode = $request->query('hub_mode');
            $token = $request->query('hub_verify_token');
            $challenge = $request->query('hub_challenge');
    
            if ($mode === 'subscribe' && $token === $verfiy_token) {
                return response($challenge, 200);
            }
            return response()->json(['error' => 'Verification failed'], 403);
        }
         Log::info('Incoming WhatsApp Webhook Data:', ['data' => $request->all()]);

            $entry = $request->json('entry');
            if (empty($entry)) {
                return response()->json(['message' => 'Invalid data format'], 400);
            }
        
            $changes = $entry[0]['changes'][0]['value'] ?? null;
            if (!$changes) {
                return response()->json(['message' => 'No changes found'], 400);
            }
        
            // Handle message statuses
            if (isset($changes['statuses'])) {
                foreach ($changes['statuses'] as $status) {
                    $messageId = $status['id'] ?? null;
                    $statusType = $status['status'] ?? null;
        
                    if ($messageId && $statusType) {
                        WhatsappMessageModel::where('wama_id', $messageId)->update(['message_status' => $statusType]);
                        Log::info("Message status updated: ID {$messageId} -> {$statusType}");
                    }
                }
                return response()->json(['success' => true]);
            }
        
            $messageData = $changes['messages'][0] ?? null;
            $contactData = $changes['contacts'][0] ?? null;
        
            if (!$messageData || !$contactData) {
                return response()->json(['message' => 'No message received'], 400);
            }
        
            $phone = $contactData['wa_id'];
            $messageType = $messageData['type'] ?? 'text';
            $messageId = $messageData['id'] ?? null;
            $messageStatus = $messageData['status'] ?? 'sent';
            $messageTimestamp = $messageData['timestamp'] ?? null;
            $messageText = $messageType === 'text' ? $messageData['text']['body'] : null;
        
            if (!$messageTimestamp || !$messageId) {
                return response()->json(['message' => 'Missing timestamp or ID'], 400);
            }
        
            $messageDateTime = Carbon::createFromTimestamp($messageTimestamp)->toDateTimeString();
        
            // Check for duplicate message using wama_id
            $existing = WhatsappMessageModel::where('wama_id', $messageId)->where('type', $messageType)->first();
            if ($existing) {
                Log::info("Duplicate message skipped for wama_id: {$messageId}");
                return response()->json(['message' => 'Duplicate message skipped'], 200);
            }
        
            // Contact handling
            $contact = WhatsappContactModel::firstOrCreate(
                ['phone' => $phone],
                ['msg_count' => 0]
            );
            $contact->increment('msg_count');
        
            // REACTION TYPE HANDLING
            if ($messageType === 'reaction') {
                $reactionMessageId = $messageData['reaction']['message_id'] ?? null;
                $reactionEmoji = $messageData['reaction']['emoji'] ?? null;
        
                if ($reactionMessageId && $reactionEmoji) {
                    $originalMessage = WhatsappMessageModel::where('wama_id', $reactionMessageId)->first();
        
                    if ($originalMessage) {
                        $originalMessage->update([
                            'reaction_emoji' => $reactionEmoji,
                            'reaction_status' => 1,
                        ]);
                        Log::info("Updated reaction for message ID {$reactionMessageId}: {$reactionEmoji}");
                    } else {
                        // Save reaction as a new entry (only if not already saved)
                        WhatsappMessageModel::create([
                            'contact_id' => $contact->sno,
                            'message' => $reactionEmoji,
                            'type' => 'reaction',
                            'from' => 0,
                            'wama_id' => $messageId,
                            'message_date_time' => $messageDateTime,
                            'message_status' => 'sent',
                            'reaction_emoji' => $reactionEmoji,
                        ]);
                        Log::info("New reaction saved for unknown original message: {$reactionEmoji}");
                    }
                }
        
                return response()->json(['success' => true]);
            }
        
            // Prepare data for saving the message
            $messageDataToSave = [
                'contact_id' => $contact->sno,
                'message' => $messageText,
                'type' => $messageType,
                'from' => 0,
                'wama_id' => $messageId,
                'message_date_time' => $messageDateTime,
                'message_status' => $messageStatus,
            ];
        
            // Handle media messages
            if (in_array($messageType, ['image', 'video', 'document', 'audio', 'sticker'])) {
                $mediaId = $messageData[$messageType]['id'] ?? null;
        
                if ($mediaId) {
                    $mediaUrlResponse = Http::withHeaders([
                        'Authorization' => "Bearer $accessToken"
                    ])->get("https://graph.facebook.com/v19.0/{$mediaId}");
        
                    $mediaUrl = $mediaUrlResponse->json()['url'] ?? null;
        
                    if ($mediaUrl) {
                        $mediaContentResponse = Http::withHeaders([
                            'Authorization' => "Bearer $accessToken"
                        ])->get($mediaUrl);
        
                        if ($mediaContentResponse->successful()) {
                            $mimeType = $mediaContentResponse->header('Content-Type');
                            $extension = $this->getMediaExtension($mimeType);
                            $mediaFolder = $this->getMediaFolder($messageType);
                            $filePath = public_path("whatsapp/{$mediaFolder}");
        
                            if (!file_exists($filePath)) {
                                mkdir($filePath, 0777, true);
                            }
        
                            $fileName = uniqid() . '.' . $extension;
                            file_put_contents("$filePath/$fileName", $mediaContentResponse->body());
        
                            $messageDataToSave['media_url'] = "whatsapp/{$mediaFolder}/{$fileName}";
                            $messageDataToSave['media_type'] = $messageType;
                            $messageDataToSave['mime_type'] = $mimeType;
        
                            if ($messageType === 'document') {
                                $messageDataToSave['media_caption'] = $messageData[$messageType]['filename'] ?? null;
                                $messageDataToSave['message'] = $messageData[$messageType]['caption'] ?? null;
                            } else {
                                $messageDataToSave['media_caption'] = $messageData[$messageType]['caption'] ?? null;
                            }
                        }
                    }
                }
            }
        
            // Save message and dispatch event
            $message = WhatsappMessageModel::create($messageDataToSave);
            // event(new NewMessage($message, $entry));

        return response()->json(['success' => true]);
        
  
    }
    
    private function getMediaExtension($mimeType)
    {
        $mimeMap = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'video/mp4' => 'mp4',
            'video/avi' => 'avi',
            'video/3gpp' => '3gp',
            'audio/mpeg' => 'mp3',
            'audio/ogg' => 'ogg',
            'audio/wav' => 'wav',
            'audio/webm' => 'webm',
            'application/pdf' => 'pdf',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'application/zip' => 'zip',
            'application/x-rar-compressed' => 'rar',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
        ];

        return $mimeMap[$mimeType] ?? 'bin'; // Default to 'bin' if no match
    }

    
    /**
     * Get media folder based on type.
     */
    private function getMediaFolder($messageType)
    {
        return match ($messageType) {
            'image' => 'images',
            'video' => 'videos',
            'document' => 'documents',
            'audio' => 'audios',
            'sticker' => 'stickers',
            default => 'other',
        };
    }
}