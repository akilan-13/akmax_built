<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Http\Controllers\settings\Holiday;
use App\Models\AdditionalChargesModel;
use App\Models\BranchModel;
use App\Models\HolidayModel;
use App\Models\StaffAttendanceModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BranchHoliday extends Controller
{
    public function index()
    {
        $lists = HolidayModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();
        
        foreach($lists as $list) {
            $branch_names = [];
            $branch_ids = json_decode($list->branch_id, true);
            foreach($branch_ids as $branch_id) {
                $branchDetails = DB::table('et_branch')
                    ->select('sno', 'branch_name', 'franchise_name', 'branch_type')
                    ->where('sno', $branch_id)
                    ->first();

                $branch_names[] = ($branchDetails->branch_type == 2) ? $branchDetails->franchise_name : $branchDetails->branch_name;
                $branch_name = implode(', ', $branch_names);
            }

            $list->branch_name = $branch_name;
            
        }

        return view('content.branch_management.branch_holiday', compact('lists'));
    }

    public function create(Request $request)
    {
        $user_id = $request->user()->user_id;
        $branch_ids = $request->input('branch_id');

        foreach($branch_ids as $branch_id) {
            $branch = BranchModel::where('sno', $branch_id)->firstOrFail();
            $branchCode = $branch->city_short_code;

            $staffs = StaffModel::where('branch_id', $branch_id)
                ->where('status', 0)
                ->pluck('sno');

            foreach ($staffs as $staffSno) {
                $latestAttendance = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $year = date("Y");
                if (!$latestAttendance) {
                    $staffAttendanceId = $year . '/' . $branchCode . '/' . "SAT0001";
                } else {
                    $data = $latestAttendance->staff_attendance_id;
                    $slice = explode("/", $data);
                    $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                    $nextNumber = (int)$resultcus + 1;
                    $staffAttendanceId = sprintf("%s/%s/SAT%04d", $year, $branchCode, $nextNumber);
                }

                StaffAttendanceModel::create([
                    'staff_attendance_id' => $staffAttendanceId,
                    'branch_id' => $branch_id,
                    'staff_id' => $staffSno,
                    'date' => date('Y-m-d', strtotime($request->holiday_date)),
                    'attendance' => 'HD',
                    'created_by' => auth()->user()->user_id,
                ]);
            }
        }
        
        $create = new HolidayModel();
        $create->branch_id = json_encode($branch_ids ?? [], true);
        $create->hol_date = date('Y-m-d', strtotime($request->holiday_date));
        $create->hol_reason = $request->holiday_reason;
        $create->created_by = $user_id;
        $create->updated_by = $user_id;
        $create->save();

        if ($create) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Branch holiday created successfully !',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Branch holiday creation failed !',
            ]);
        }
        return redirect()->back();
    }

    public function Edit($id) {
        $data = HolidayModel::where('sno', $id)->where('status', '!=', 2)->first();

        if($data) {
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully',
                'error_msg' => null,
                'data' => $data
            ], 200);
        }
    }

    public function Update(Request $request)
    {
        $user_id = $request->user()->user_id;
        $sno = $request->edit_id;
        $branch_ids = $request->input('branch_id_edit');

        $oldHoliday = HolidayModel::where('sno', $sno)->where('status', '!=', 2)->firstOrFail();
        $oldDate = $oldHoliday->hol_date;
        $oldBranchIds = json_decode($oldHoliday->branch_id, true);
        $newDate = date('Y-m-d', strtotime($request->holiday_date_edit));

        foreach($oldBranchIds as $branch_id) {
            $staffs = StaffModel::where('branch_id', $branch_id)
                ->where('status', 0)
                ->pluck('sno');

            StaffAttendanceModel::whereIn('staff_id', $staffs)
                ->where('date', $oldDate)
                ->where('attendance', 'HD')
                ->delete();
        }

        foreach($branch_ids as $branch_id) {
            $branch = BranchModel::where('sno', $branch_id)->firstOrFail();
            $branchCode = $branch->city_short_code;

            $staffs = StaffModel::where('branch_id', $branch_id)
                ->where('status', 0)
                ->pluck('sno');
            
            foreach($staffs as $staffSno) {

                $latestAttendance = StaffAttendanceModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $year = date("Y");
                if (!$latestAttendance) {
                    $staffAttendanceId = $year . '/' . $branchCode . '/' . "SAT0001";
                } else {
                    $data = $latestAttendance->staff_attendance_id;
                    $slice = explode("/", $data);
                    $resultcus = preg_replace('/[^0-9]/', '', $slice[2]);
                    $nextNumber = (int)$resultcus + 1;
                    $staffAttendanceId = sprintf("%s/%s/SAT%04d", $year, $branchCode, $nextNumber);
                }

                StaffAttendanceModel::create([
                    'staff_attendance_id' => $staffAttendanceId,
                    'branch_id' => $branch_id,
                    'staff_id' => $staffSno,
                    'date' => $newDate,
                    'attendance' => 'HD',
                    'created_by' => $user_id,
                ]);
            }
        }

        $oldHoliday->branch_id = json_encode($branch_ids ?? [], true);
        $oldHoliday->hol_date = $newDate;
        $oldHoliday->hol_reason = $request->holiday_reason_edit;
        $oldHoliday->created_by = $user_id;
        $oldHoliday->updated_by = $user_id;
        $oldHoliday->save();

        if ($oldHoliday) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Branch holiday updated successfully!',
            ]);
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Branch holiday update failed!',
            ]);
        }

        return redirect()->back();
    }

}
