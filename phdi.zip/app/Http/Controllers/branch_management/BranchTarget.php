<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManageTargetModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\DB;
use App\Models\CustomerModel;
use Carbon\Carbon;
class BranchTarget extends Controller
{


  public function index()
    {
        return view('content.branch_management.branch_target');
    }

       public function getTargets(Request $request)
    {
        // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    
        // Fetch target record for given branch and date
        $targets = ManageTargetModel::where('branch_target.branch_id', $request->branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->first();
    
        return response()->json(['status' => 200, 'data' => $targets]);
    }
    
   public function getTargetsMetrics(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
    
        // Fetch all targets for the month
        $targets = ManageTargetModel::join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*', 'et_branch.branch_name', 'et_branch.franchise_name', 'et_branch.branch_type')
                    ->orderBy('et_branch.sno','asc')
                    ->get();
                    
                    // return $targets;
    
        $results = [];
         $user_id = auth()->user()->user_id;
        $helper = new \App\Helpers\Helpers();
        $branchControlList = $helper->get_branch_control_list($user_id); 
        $branches = collect($branchControlList['branches'] ?? [])->pluck('sno');
        $franchises = collect($branchControlList['franchises'] ?? [])->pluck('sno');
        
        $allowedBranchIds = $branches->merge($franchises)->toArray();
        // return $branchControlList;
        foreach ($targets as $target) {
            $branchId = $target->branch_id;
            
                if (!in_array($branchId, $allowedBranchIds)) {
                    continue; // filter out unauthorized branches
                }
            
           $lastLogin = DB::table('personal_access_tokens as pat')
            ->join('users as user', 'pat.tokenable_id', '=', 'user.id') // table alias must match
            ->where('user.branch_id', $branchId)
            ->where('pat.tokenable_type', 'App\\Models\\User') // ensure it's filtering correct model
            ->orderByRaw('COALESCE(pat.last_used_at, pat.created_at) DESC')
            ->limit(1)
            ->value(DB::raw('COALESCE(pat.last_used_at, pat.created_at)'));
            
            if ($lastLogin) {
                $lastLoginCarbon = Carbon::parse($lastLogin);
                
                $lastLoginFormatted = $lastLoginCarbon->format('d-M-Y h:i A');
                $lastLoginDiff = $lastLoginCarbon->diffForHumans(null, true); // more accurate format
            } else {
                $lastLoginFormatted = 'N/A';
                $lastLoginDiff = 'N/A';
            }
             $totalLeads = DB::table('et_lead')
                ->where('branch_id', $branchId)
                ->where('status', 0)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
            // Actual payments (old)
            $totalPaidAmountOld = 0;
    
            // Actual payments (new)
            $totalPaidAmountNew = DB::table('et_payment')
                ->where('et_payment.branch_id', $branchId)
                ->where('et_payment.status', 1)
                ->where('et_payment.paid_amount', '>', 0)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->sum('et_payment.paid_amount');
                
             $transaction = DB::table('et_transaction')
                     ->where('et_transaction.branch_id', $branchId)
                      ->whereYear('et_transaction.transaction_date', $year)
                     ->whereMonth('et_transaction.transaction_date', $month)
                     ->sum('et_transaction.credit');
                     
                     $totalSum = DB::table('et_transaction')
    ->leftJoin('et_payment', function($join) {
        $join->on('et_transaction.payment_id', '=', 'et_payment.sno');
    })
    ->where('et_transaction.branch_id', $branchId)
    ->whereYear('et_transaction.transaction_date', $year)
    ->whereMonth('et_transaction.transaction_date', $month)
    ->selectRaw('
        SUM(
            CASE 
                WHEN et_transaction.customer_type = 2 THEN et_transaction.credit
                WHEN et_transaction.customer_type = 0 THEN et_payment.paid_amount
                ELSE 0
            END
        ) as total_sum
    ')
    ->value('total_sum');
                    
                // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
                $targetActual = $totalSum;
    
            // Post-sale & pre-sale actuals
            $postSaleActual = CustomerModel::whereIn('et_customer.status', [0, 6])
                ->join('et_proposal', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->where('et_customer.post_sale_check', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereYear('et_proposal.post_sale_date', $year)
                ->whereMonth('et_proposal.post_sale_date', $month)
                ->count();
    
            $preSaleActual = CustomerModel::whereIn('status', [0, 6])
                ->where('post_sale_check', 0)
                ->where('branch_id', $branchId)
                ->whereYear('created_at', $year)
                ->whereMonth('created_at', $month)
                ->count();
                
               
    
            $results[] = [
                'branch_name' => $target->branch_type == 1 ? $target->branch_name : $target->franchise_name,
                 'branch_type' => $target->branch_type,
                  'branch_id' => $target->branch_id,
                'date' => $target->date,
                'target'             => '₹' . number_format($target->monthly_target),
                'post_sale_target' => $target->post_sale,
                'pre_sale_target' => $target->no_of_registrations,
                 'target_actual'      => '₹' . number_format($targetActual),
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                 'lead_total'         => $totalLeads,
                 'last_login' => $lastLogin ? date('d-M-Y h:i A', strtotime($lastLogin)) : 'N/A',
                 'last_login_ago' => $lastLoginDiff,
                 
            ];
        }
    
        return response()->json([
            'status' => 200,
            'data' => $results
        ]);
    }



    public function updateTargets(Request $request)
{
    $request->validate([
        'branch_id' => 'required|integer',
        'no_of_registrations' => 'required|integer|min:0',
        'post_sale' => 'required|integer|min:0',
        'monthly_target' => 'required|integer|min:0',
    ]);

    // Convert month name to numeric month (e.g., "May" → 05)
        $monthNumber = date('m', strtotime("1 " . $request->month));
    
        // Format date string as 'YYYY-MM-01'
        $targetDate = $request->year . '-' . $monthNumber . '-01';
    $userId = auth()->user()->user_id ?? 0; // Get current logged-in user

    // Check if record already exists
    $existing = ManageTargetModel::where('branch_id', $request->branch_id)
                ->where('date', $targetDate)
                ->first();

    if ($existing) {
        // Update path
        $existing->no_of_registrations = $request->no_of_registrations;
        $existing->post_sale = $request->post_sale;
        $existing->monthly_target = $request->monthly_target;
        $existing->updated_by = $userId;
        $existing->save();
    } else {
        // Insert path
        ManageTargetModel::create([
            'branch_id' => $request->branch_id,
            'date' => $targetDate,
            'no_of_registrations' => $request->no_of_registrations,
             'post_sale' => $request->post_sale,
            'monthly_target' => $request->monthly_target,
            'created_by' => $userId,
            'updated_by' => $userId,
        ]);
    }

    return response()->json([
        'status' => 200,
        'message' => 'Target saved successfully.'
    ]);
}



}
