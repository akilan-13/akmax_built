<?php

namespace App\Http\Controllers\branch_management;

use App\Http\Controllers\Controller;
use App\Models\MarketingModel;
use App\Models\BranchModel;
use App\Models\MarketingZoneModel;
use App\Models\MarketingAreaModel;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\MarketingCampaignExport;

class BranchCampaign extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $cus_fill = $request->cus_fill ?? '';

    
    $marketing = MarketingModel::select(
      'et_marketing.sno',
      'et_marketing.campaign_name',
      'et_marketing.category_id',
      'et_marketing.type_id',
      'et_marketing.vendor_id',
      'et_marketing.total_amount',
      'et_marketing.zone_id',
      'et_marketing.payment',
      'et_marketing.count',
      'et_marketing.gst',
      'et_marketing.start_date',
      'et_marketing.branch_id',
      'et_branch.branch_name',
      'et_branch.franchise_name',
      'et_marketing.end_date',
      'et_marketing.status',
      'et_marketing.zone_schedule',
      'et_marketing_category.marketing_category_name',
      'et_marketing_type.marketing_type_name',
      // 'et_marketing_area.zone_area_name',
      'et_marketing_zone.zone_name',
      'et_vendor.marketing_vendor_name'
    )

      ->join('et_marketing_category', 'et_marketing_category.sno', '=', 'et_marketing.category_id')
      ->join('et_marketing_type', 'et_marketing_type.sno', '=', 'et_marketing.type_id')
      ->leftJoin('et_marketing_zone', 'et_marketing_zone.sno', '=', 'et_marketing.zone_id')
      ->leftJoin('et_branch', 'et_branch.sno', '=', 'et_marketing.branch_id')
      // ->leftJoin('et_marketing_area', 'et_marketing_area.zone_name', '=', 'et_marketing_zone.sno')
      ->leftJoin('et_vendor', 'et_vendor.sno', '=', 'et_marketing.vendor_id')
      ->groupBy(
        'et_marketing.sno',
        'et_marketing.campaign_name',
        'et_marketing.category_id',
        'et_marketing.type_id',
        'et_marketing.vendor_id',
        'et_marketing.zone_id',
        'et_marketing.payment',
        'et_marketing.count',
        'et_marketing.status',
        'et_marketing.total_amount',
        'et_marketing.gst',
        'et_marketing.start_date',
        'et_marketing.end_date',
        'et_marketing.zone_schedule',
        // 'et_marketing_area.zone_area_name',
        'et_marketing_category.marketing_category_name',
        'et_marketing_type.marketing_type_name',
        'et_marketing_zone.zone_name', // Include this line for grouping as well
        'et_vendor.marketing_vendor_name',
        'et_marketing.branch_id',
        'et_branch.branch_name',
        'et_branch.franchise_name'
      )
      ->where('et_marketing.status', '!=', 2)
      // ->where('et_marketing.branch_id', self::$branch_id)
      ->orderBy('sno', 'desc');

      
      if ($cus_fill) {
        $branch_manage->where(function ($customer) use ($cus_fill) {
          $customer->where('et_marketing.campaign_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('et_marketing.start_date', 'LIKE', "%{$cus_fill}%")
            ->orWhere('et_marketing.end_date', 'LIKE', "%{$cus_fill}%")
            ->orWhere('et_marketing_category.marketing_category_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('et_marketing_type.marketing_type_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere('et_marketing_zone.zone_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere( 'et_vendor.marketing_vendor_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere( 'et_branch.branch_name', 'LIKE', "%{$cus_fill}%")
            ->orWhere( 'et_branch.franchise_name', 'LIKE', "%{$cus_fill}%");
        });
      }
      
      $marketing= $marketing->paginate($perpage);
      
      $pageConfigs = ['myLayout' => 'default'];
      

    // return $marketing;
    // dd($marketing);

    $branch = BranchModel::select('*')->where('status', '!=', 2)->get();
    return view('content.branch_management.manage_campaign.list',[
      'marketing'   => $marketing,
      'branch'      => $branch,
      'pageConfigs' => $pageConfigs,
      'perpage'     => $perpage,
      'cus_fill'    => $cus_fill,
    ]);
  }
  
  public function verify_activity($id = '')
  {
      // Decrypt the ID
      $helper = new \App\Helpers\Helpers();
      $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
      if ($decryptedValue === false) {
          return redirect()->back()->with('error', 'Invalid Entry');
      }
  
      // Fetch the marketing activity
      $verify_activity = MarketingModel::select(
          'et_marketing.sno as mark_sno',
          'et_marketing.campaign_name',
          'et_marketing.start_date',
          'et_marketing.end_date',
          'et_marketing.zone_schedule',
          'et_marketing.description',
          'et_marketing.payment',
          'et_marketing.count',
          'et_marketing.checklist',
          'et_marketing.category_id as cat_id',
          'et_marketing.type_id as type_id',
          'et_marketing.vendor_id as vendor_id',
          'et_marketing.zone_id as zone_id',
          'et_marketing_category.sno as mar_cat_sno',
          'et_marketing_category.marketing_category_name',
          'et_marketing_type.sno as mar_type_sno',
          'et_marketing_type.marketing_type_name',
          'et_vendor.sno as mar_vendor_sno',
          'et_vendor.marketing_vendor_name',
          'et_vendor.vendor_contact_person_name',
          'et_vendor.vendor_contact_person_mobile',
          'et_vendor.marketing_vendor_address',
          'et_marketing_zone.sno as mar_zone_sno',
          'et_marketing_zone.zone_name',
          'camp_type.sno as mar_checklist_sno',  // Changed alias for camp_type
          'camp_type.camp_checklist'
      )
      ->join('et_marketing_category', 'et_marketing.category_id', '=', 'et_marketing_category.sno')
      ->join('et_marketing_type', 'et_marketing.type_id', '=', 'et_marketing_type.sno')
      ->leftJoin('et_vendor', 'et_marketing.vendor_id', '=', 'et_vendor.sno')
      ->leftJoin('et_marketing_zone', 'et_marketing.zone_id', '=', 'et_marketing_zone.sno')
      ->leftJoin('et_campaign_checklist AS camp_type', 'et_marketing.type_id', '=', 'camp_type.camp_type_id')
      ->leftJoin('et_campaign_checklist AS camp_category', 'et_marketing.category_id', '=', 'camp_category.camp_category_id') // Changed alias for camp_category
      ->where('et_marketing.sno', '=', $decryptedValue)
      ->where('et_marketing.status', '!=', 2)
      ->groupBy(
          'mark_sno',
          'et_marketing.campaign_name',
          'et_marketing.start_date',
          'et_marketing.end_date',
          'et_marketing.zone_schedule',
          'et_marketing.description',
          'et_marketing.count',
          'et_marketing.checklist',
          'et_marketing.payment',
          'cat_id',
          'type_id',
          'vendor_id',
          'zone_id',
          'mar_cat_sno',
          'et_marketing_category.marketing_category_name',
          'mar_type_sno',
          'et_marketing_type.marketing_type_name',
          'mar_vendor_sno',
          'et_vendor.marketing_vendor_name',
          'et_vendor.vendor_contact_person_name',
          'et_vendor.vendor_contact_person_mobile',
          'et_vendor.marketing_vendor_address',
          'mar_zone_sno',
          'et_marketing_zone.zone_name',
          'mar_checklist_sno',
          'camp_type.camp_checklist'
      )
      ->orderBy('et_marketing.sno', 'desc')
      ->first();
  
      // Decode the JSON fields (if needed)
      $zone_schedule = json_decode($verify_activity->zone_schedule, true); // Decode zone_schedule as array
      $checklist = json_decode($verify_activity->camp_checklist, true); // Decode checklist as array
      // return $verify_activity;
      // Return the data to the view
      return view('content.branch_management.manage_campaign.verify_activity', [
          'verify_activity' => $verify_activity,
          'zone_schedule' => $zone_schedule,
          'checklist' => $checklist,
      ]);
  }
  
  
  public function verify_activity_edit($id = '')
  {

    // return $id;
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $verify_activity_edit = MarketingModel::select(
      'et_marketing.sno as mark_sno',
      'et_marketing.campaign_name',
      'et_marketing.start_date',
      'et_marketing.end_date',
      'et_marketing.zone_schedule',
      'et_marketing.description',
      'et_marketing.payment',
      'et_marketing.count',
      'et_marketing.total_amount',
      'et_marketing.checklist',
      'et_marketing.category_id as cat_id',
      'et_marketing.type_id as type_id',
      'et_marketing.vendor_id as vendor_id',
      'et_marketing.zone_id as zone_id',
      'et_marketing_category.sno as mar_cat_sno',
      'et_marketing_category.marketing_category_name',
      'et_marketing_type.sno as mar_type_sno',
      'et_marketing_type.marketing_type_name',
      'et_vendor.sno as mar_vendor_sno',
      'et_vendor.marketing_vendor_name',
      'et_vendor.vendor_contact_person_name',
      'et_vendor.vendor_contact_person_mobile',
      'et_vendor.marketing_vendor_address',
      'et_marketing_zone.sno as mar_zone_sno',
      'et_marketing_zone.zone_name',
      'camp_type.sno as mar_checklist_sno',  // Changed alias for camp_type
      'camp_type.camp_checklist'
    )
      ->join('et_marketing_category', 'et_marketing.category_id', '=', 'et_marketing_category.sno')
      ->join('et_marketing_type', 'et_marketing.type_id', '=', 'et_marketing_type.sno')
      ->leftJoin('et_vendor', 'et_marketing.vendor_id', '=', 'et_vendor.sno')
      ->leftJoin('et_marketing_zone', 'et_marketing.zone_id', '=', 'et_marketing_zone.sno')
      ->leftJoin('et_campaign_checklist AS camp_type', 'et_marketing.type_id', '=', 'camp_type.camp_type_id')
      ->leftJoin('et_campaign_checklist AS camp_category', 'et_marketing.category_id', '=', 'camp_category.camp_category_id') // Changed alias for camp_category
      ->where('et_marketing.sno', '=', $decryptedValue)
      ->where('et_marketing.status', '!=', 2)
      // ->where('et_marketing.branch_id', $branch_id)
      // ->where('et_marketing.branch_id', self::$branch_id)
      ->groupBy(
        'mark_sno',
        'et_marketing.campaign_name',
        'et_marketing.start_date',
        'et_marketing.end_date',
        'et_marketing.zone_schedule',
        'et_marketing.description',
        'et_marketing.count',
        'et_marketing.total_amount',
        'et_marketing.checklist',
        'et_marketing.payment',
        'cat_id',
        'type_id',
        'vendor_id',
        'zone_id',
        'mar_cat_sno',
        'et_marketing_category.marketing_category_name',
        'mar_type_sno',
        'et_marketing_type.marketing_type_name',
        'mar_vendor_sno',
        'et_vendor.marketing_vendor_name',
        'et_vendor.vendor_contact_person_name',
        'et_vendor.vendor_contact_person_mobile',
        'et_vendor.marketing_vendor_address',
        'mar_zone_sno',
        'et_marketing_zone.zone_name',
        'mar_checklist_sno',
        'camp_type.camp_checklist'
      )
      ->orderBy('et_marketing.sno', 'desc')
      ->first();
    // return  $verify_activity_edit;


    return view('content.branch_management.manage_campaign.verify_activity_edit', [
      'verify_activity_edit' => $verify_activity_edit
    ]);
  }

  public function view_activity($id = '')
  {
    // return $id;
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $view = MarketingModel::select(
      'et_marketing.sno as mark_sno',
      'et_marketing.campaign_name',
      'et_marketing.start_date',
      'et_marketing.end_date',
      'et_marketing.zone_schedule',
      'et_marketing.description',
      'et_marketing.payment',
      'et_marketing.count',
      'et_marketing.total_amount',
      'et_marketing.checklist',
      'et_marketing.category_id as cat_id',
      'et_marketing.type_id as type_id',
      'et_marketing.vendor_id as vendor_id',
      'et_marketing.zone_id as zone_id',
      'et_marketing_category.sno as mar_cat_sno',
      'et_marketing_category.marketing_category_name',
      'et_marketing_type.sno as mar_type_sno',
      'et_marketing_type.marketing_type_name',
      'et_vendor.sno as mar_vendor_sno',
      'et_vendor.marketing_vendor_name',
      'et_vendor.vendor_contact_person_name',
      'et_vendor.vendor_contact_person_mobile',
      'et_vendor.marketing_vendor_address',
      'et_marketing_zone.sno as mar_zone_sno',
      'et_marketing_zone.zone_name',
      'camp_type.sno as mar_checklist_sno',  // Changed alias for camp_type
      'camp_type.camp_checklist'
    )
      ->join('et_marketing_category', 'et_marketing.category_id', '=', 'et_marketing_category.sno')
      ->join('et_marketing_type', 'et_marketing.type_id', '=', 'et_marketing_type.sno')
      ->leftJoin('et_vendor', 'et_marketing.vendor_id', '=', 'et_vendor.sno')
      ->leftJoin('et_marketing_zone', 'et_marketing.zone_id', '=', 'et_marketing_zone.sno')
      ->leftJoin('et_campaign_checklist AS camp_type', 'et_marketing.type_id', '=', 'camp_type.camp_type_id')
      ->leftJoin('et_campaign_checklist AS camp_category', 'et_marketing.category_id', '=', 'camp_category.camp_category_id') // Changed alias for camp_category
      ->where('et_marketing.sno', '=', $decryptedValue)
      ->where('et_marketing.status', '!=', 2)
      // ->where('et_marketing.branch_id', $branch_id)
      // ->where('et_marketing.branch_id', self::$branch_id)
      ->groupBy(
        'mark_sno',
        'et_marketing.campaign_name',
        'et_marketing.start_date',
        'et_marketing.end_date',
        'et_marketing.zone_schedule',
        'et_marketing.description',
        'et_marketing.count',
        'et_marketing.total_amount',
        'et_marketing.checklist',
        'et_marketing.payment',
        'cat_id',
        'type_id',
        'vendor_id',
        'zone_id',
        'mar_cat_sno',
        'et_marketing_category.marketing_category_name',
        'mar_type_sno',
        'et_marketing_type.marketing_type_name',
        'mar_vendor_sno',
        'et_vendor.marketing_vendor_name',
        'et_vendor.vendor_contact_person_name',
        'et_vendor.vendor_contact_person_mobile',
        'et_vendor.marketing_vendor_address',
        'mar_zone_sno',
        'et_marketing_zone.zone_name',
        'mar_checklist_sno',
        'camp_type.camp_checklist'
      )
      ->orderBy('et_marketing.sno', 'desc')
      ->first();
    return view('content.branch_management.manage_campaign.view_activity', [
      'view' => $view,
    ]);
  }

  // public function update_branch_franchise()
  // {
  //   return view('content.branch_management.manage_branch.edit');
  // }

  public function Add(Request $request)
  {
      // Validate the request data
      $validator = Validator::make($request->all(), [
          'campaign_name' => 'required|max:255',
      ]);
  
      if ($validator->fails()) {
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Incorrect format input fields'
          ]);
          return redirect()->back();
      }
  
      // Extract request data
      $campaign_name = $request->campaign_name;
      $mar_cat_select = $request->mar_cat_select;
      $branch_select = $request->branch_select;
      $type_select = $request->type_select;
      $vendor_select = $request->vendor_select;
      $count = $request->count;
      $gst = $request->gst;
      $schedule = $request->schedule;
  
      // Handle schedule dates if they exist
      if (!empty($schedule)) {
          list($startDate, $endDate) = explode(' to ', $schedule);
      } else {
          $startDate = '';
          $endDate = '';
      }
  
      // Clean up dates
      $startDate = trim($startDate);
      $endDate = trim($endDate);
      
      // Other data
      $zone_select = $request->zone_select; 
      $description = $request->description;
  
      // Retrieve area IDs, names, and dates
      $zone_area_id = $request->zone_area_id ?? [];
      $zone_area_name = $request->zone_area_name;
      $zone_area_date = $request->zone_area_date ?? [];
  
      // Initialize an empty array to hold the final result
      $result = [];
  
      // Iterate over each zone_area_id and map it to a corresponding zone_schedule entry
      foreach ($zone_area_id as $index => $areaId) {
          // Ensure that both name and date are present, even if the date is null
          $result[] = [
              'id' => $areaId,          // Area ID
              'area' => $zone_area_name[$index], // Area name
              'date' => isset($zone_area_date[$index]) ? $zone_area_date[$index] : null,  // Use null if no date is provided
          ];
      }
  
      // Encode the result to JSON
      $zone_schedule = json_encode($result);
      // For debugging purposes, you can return the result to check
      // return $zone_schedule;
  
      // Save to the database
      $add = new MarketingModel();
      $add->campaign_name = $campaign_name;
      $add->marketing_id = 'MC-0001'; // Replace with your actual ID generation logic
      $add->category_id = $mar_cat_select;
      $add->branch_id = $branch_select;
      $add->type_id = $type_select;
      $add->vendor_id = $vendor_select;
      $add->count = $count;
      $add->gst = $gst;
      $add->start_date = !empty($startDate) ? date('Y-m-d', strtotime($startDate)) : null;
      $add->end_date = !empty($endDate) ? date('Y-m-d', strtotime($endDate)) : null;
      $add->payment = $request->payment;
      $add->zone_id = $zone_select;
      $add->description = $description;
      $add->zone_schedule = $zone_schedule;
      $add->zone_area_name = json_encode($zone_area_name);
      $add->zone_area_date = json_encode($zone_area_date);
      $add->created_by = $request->user()->user_id;
      $add->updated_by = $request->user()->user_id;
      // return $add;
      $add->save();
  
      // Flash success or error message
      if ($add) {
          session()->flash('toastr', [
              'type' => 'success',
              'message' => 'Manage Campaign added Successfully!'
          ]);
      } else {
          session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Could not add the Manage Campaign!'
          ]);
      }
  
      return redirect()->back();
  }
  
  

  // public function Update(Request $request)
  // {
  //   return $request;
  //   $validator = Validator::make($request->all(), [
  //     'campaign_name' => 'required|max:255'
  //   ]);

  //   if ($validator->fails()) {
  //     // If validation fails, return error response
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'Incorrect format input fields'
  //     ]);
  //     return redirect()->back();
  //   }
  //   // return $request;

  //   // If validation passes
  //   $campaign_name = $request->campaign_name;
  //   $mar_cat_select = $request->mar_cat_select;
  //   $type_select = $request->type_select;
  //   $vendor_select = $request->vendor_select;
  //   $count = $request->count;
  //   $gst = $request->gst;
  //   $schedule = $request->schedule;
  //   // dd($schedule);
  //   // Assuming $schedule is the input string
  //   if (!empty($schedule)) {
  //     list($startDate, $endDate) = explode(' to ', $schedule);
  //   } else {
  //     $startDate = null;
  //     $endDate = null;
  //   }

  //   // Trim any whitespace (optional but good practice)
  //   $startDate = trim($startDate);
  //   $endDate = trim($endDate);
  //   // dd($startDate, 'to', $endDate);

  //   $schedule = DateTime::createFromFormat('d-M-Y', $request->schedule);
  //   $payment = $request->payment;
  //   $zone_select = $request->zone_select;
  //   $description = $request->description;

  //   $zone_area_id = $request->zone_area_id;
  //   $zone_area_name = $request->zone_area_name;
  //   $zone_area_date = $request->zone_area_date;


  //   // Iterate over each option and map it to the corresponding date
  //   // Get the options and course data from the request
  //   $areaIds = $request->input('zone_area_id', []);
  //   $areaNames = $request->input('zone_area_name', []);
  //   $dateDates = $request->input('zone_area_date', []);

  //   // Initialize an empty array to hold the result
  //   $result = [];

  //   // Iterate over each area name and map it to the corresponding ID and date
  //   foreach ($areaNames as $index => $value) {
  //     // Ensure that the index exists in the IDs and date arrays
  //     if (isset($areaIds[$index]) && isset($dateDates[$index])) {
  //       // Create the formatted entry
  //       $result[] = [
  //         'id' => $areaIds[$index],   // Include the area ID
  //         //'area' => $value,           // Area name
  //         'date' => $dateDates[$index] // Corresponding date
  //       ];
  //     }
  //   }

  //   // Output the result (for debugging)
  //   // dd($result);
  //   $zone_schedule = json_encode($result);

  //   // return $zone_schedule;

  //   $branch_id = $request->user()->branch_id;
  //   $user_id = $request->user()->user_id;

  //   // Check if the category already exists
  //   $chk = MarketingModel::where('campaign_name', ucwords($campaign_name))
  //     ->where('branch_id', $request->user()->branch_id)
  //     ->first();


  //   if ($chk) {
  //     // dd($chk);
  //     // If category already exists, return error response
  //     session()->flash('toastr', [
  //       'type' => 'error',
  //       'message' => 'campaign name has already been created!'
  //     ]);
  //   } else {
  //     // Generate a unique category ID
  //     $add = MarketingModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

  //     if (!$add) {
  //       $year = substr(date('y'), -2);
  //       $marketing_id = 'MC-0001/' . $year;
  //     } else {
  //       $data = $add->marketing_id;
  //       $slice = explode('/', $data);
  //       $result = preg_replace('/[^0-9]/', '', $slice[0]);
  //       $next_number = (int)$result + 1;
  //       $requestId = sprintf('MC-%04d', $next_number);
  //       $year = substr(date('y'), -2);
  //       $marketing_id = $requestId . '/' . $year;
  //     }

  //     // Add the category to the database
  //     $add = new MarketingModel();
  //     $add->campaign_name = $campaign_name;
  //     $add->marketing_id = $marketing_id;
  //     $add->category_id = $mar_cat_select;
  //     $add->type_id = $type_select;
  //     $add->vendor_id = $vendor_select;
  //     $add->count = $request->count;
  //     $add->gst = $request->gst;
  //     //$add->schedule = $schedule->format('Y-m-d');
  //     //  $add->start_date = $startDate ?: '0000-00-00';
  //     $add->start_date = !empty($startDate) ? date('Y-m-d', strtotime($startDate)) : null;

  //     // dd('date', $add->start_date);
  //     $add->end_date = !empty($endDate) ? date('Y-m-d', strtotime($endDate)) : null;

  //     // dd($add->end_date);
  //     $add->payment = $payment;
  //     $add->zone_id = $zone_select;
  //     $add->description = $description;
  //     $add->zone_schedule = $zone_schedule;
  //     $add->zone_area_name = json_encode($zone_area_name);
  //     $add->zone_area_date = json_encode($zone_area_date);

  //     $add->branch_id = $branch_id;
  //     $add->created_by = $user_id;
  //     $add->updated_by = $user_id;
  //     // dd($add);

  //     $add->save();

  //     if ($add) {
  //       session()->flash('toastr', [
  //         'type' => 'success',
  //         'message' => ' Manage Campaign added Successfully!'
  //       ]);
  //     } else {
  //       session()->flash('toastr', [
  //         'type' => 'error',
  //         'message' => 'Could not add the  Manage Campaign !'
  //       ]);
  //     }
  //   }

  //   return redirect()->back();
  // }


  public function zoneget(Request $request)
  {
    // return $request;

    $zone_id = $request->zone_id;
    $branch_id = $request->branch_id;

    $MarType = MarketingAreaModel::where('status', 0)->where('zone_name', $zone_id)
      ->where('zone_branch_id', $branch_id)
      ->orderBy('sno', 'desc')
      ->get();
    // Prepare and return the response
    // return $MarType;
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $MarType
    ], 200);
  }

  public function Edit(Request $request)
  {
    // dd($request);
    $sno = $request->id;
    // return $sno;

    $edit = MarketingModel::select(
      'et_marketing.sno',
      'et_marketing.campaign_name',
      'et_marketing.category_id',
      'et_marketing.type_id',
      'et_marketing.vendor_id',
      'et_marketing.zone_id',
      'et_marketing.branch_id',
      'et_marketing.payment',
      'et_marketing.count',
      'et_marketing.gst',
      'et_marketing.start_date',
      'et_marketing.end_date',
      'et_marketing.zone_schedule',
      'et_marketing.description',
      'et_marketing_category.marketing_category_name',
      'et_marketing_type.marketing_type_name',
      'et_marketing_zone.zone_name',
      'et_vendor.marketing_vendor_name'
    )

      ->join('et_marketing_category', 'et_marketing_category.sno', '=', 'et_marketing.category_id')
      ->join('et_marketing_type', 'et_marketing_type.sno', '=', 'et_marketing.type_id')
      ->leftJoin('et_marketing_zone', 'et_marketing_zone.sno', '=', 'et_marketing.zone_id')
      ->leftJoin('et_vendor', 'et_vendor.sno', '=', 'et_marketing.vendor_id')
      ->groupBy(
        'et_marketing.sno',
        'et_marketing.campaign_name',
        'et_marketing.category_id',
        'et_marketing.type_id',
        'et_marketing.vendor_id',
        'et_marketing.zone_id',
        'et_marketing.payment',
        'et_marketing.branch_id',
        'et_marketing.count',
        'et_marketing.gst',
        'et_marketing.start_date',
        'et_marketing.end_date',
        'et_marketing.zone_schedule',
        'et_marketing.description',
        'et_marketing_category.marketing_category_name',
        'et_marketing_type.marketing_type_name',
        'et_marketing_zone.zone_name', // Include this line for grouping as well
        'et_vendor.marketing_vendor_name'
      )
      ->where('et_marketing.status', '!=', 2)
      ->where('et_marketing.sno', '=', $sno)
      ->orderBy('sno', 'desc')
      ->first();

    // dd($edit);

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $edit
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'camp_name' => 'required|max:255'
    ]);
    // dd($validator);

    if ($validator->fails()) {
      // If validation fails, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    }
    // return $request;

    // If validation passes
    $sno = $request->sno_edit;
    $campaign_name = $request->camp_name;
    $mar_cat_select = $request->cat_id_edit;
    $type_select = $request->type_id_edit;
    $vendor_select = $request->vendor_id_edit;
    $gst_edit = $request->gst_edit;
    $schedule_date_edit = $request->schedule_date_edit;
    if (!empty($schedule_date_edit)) {
      list($startDate, $endDate) = explode(' to ', $schedule_date_edit);
    } else {
      $startDate = null;
      $endDate = null;
    }
    $startDate = trim($startDate);
    $endDate = trim($endDate);
    // dd($startDate, 'to', $endDate);
    $count = $request->cound_edit;


    // $schedule = DateTime::createFromFormat('d-M-Y', $request->schedule_date_edit);
    //dd('date', $schedule_date_edit);
    $payment = $request->Payment_edit;
    $zone_select = $request->zone_id_edit;
    $description = $request->description_edit;
    $zone_area_id_ = $request->zone_area_id_;
    $zone_area_name = $request->zone_area_name;
    $zone_area_date = $request->zone_area_date;
    // Iterate over each option and map it to the corresponding date
    // Get the options and course data from the request
    $areaIds = $request->input('zone_area_id_', []);
    $areaNames = $request->input('zone_area_name', []);
    $dateDates = $request->input('zone_area_date', []);

    // Initialize an empty array to hold the final result
    $result = [];
  
    // Iterate over each zone_area_id and map it to a corresponding zone_schedule entry
    foreach ($areaIds as $index => $areaId) {
        // Ensure that both name and date are present, even if the date is null
        $result[] = [
            'id' => $areaId,          // Area ID
            'area' => $areaNames[$index], // Area name
            'date' => isset($dateDates[$index]) ? $dateDates[$index] : null,  // Use null if no date is provided
        ];
    }

    // Encode the result to JSON
    $zone_schedule = json_encode($result);
    // return $zone_schedule;

    $branch_id = $request->branch_select_edit;
    $user_id = $request->user()->user_id;

    // Check if the category already exists
    $chk = MarketingModel::where('campaign_name', ucwords($campaign_name))
      // ->where('branch_id', $request->user()->branch_id)
      ->where('status', '!=', 2)
      ->first();


    if ($chk) {
      // dd($chk);
      // If category already exists, return error response
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'campaign name has already been created!'
      ]);
    }


    // Add the category to the database

    $upd_CourseModel =  MarketingModel::find($sno);
    $upd_CourseModel->campaign_name = ucfirst($campaign_name);
    $upd_CourseModel->category_id = $mar_cat_select;
    $upd_CourseModel->type_id = $type_select;
    $upd_CourseModel->vendor_id = $vendor_select;
    $upd_CourseModel->count = $count;
    $upd_CourseModel->gst = $gst_edit;
    $upd_CourseModel->start_date = !empty($startDate) ? $startDate : null;
    $upd_CourseModel->end_date = !empty($endDate) ? $endDate : null;
    // dd('end', $upd_CourseModel->end_date);
    $upd_CourseModel->payment = $payment;
    $upd_CourseModel->zone_id = $zone_select;
    $upd_CourseModel->description = $description;
    $upd_CourseModel->zone_schedule = $zone_schedule;


    $upd_CourseModel->zone_area_name = json_encode($zone_area_name);
    $upd_CourseModel->zone_area_date = json_encode($zone_area_date);

    $upd_CourseModel->branch_id = $branch_id;
    $upd_CourseModel->created_by = $user_id;
    $upd_CourseModel->updated_by = $user_id;
    // return $upd_CourseModel;

    $upd_CourseModel->update();

    if ($upd_CourseModel) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => ' Manage Campaign updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the  Manage Campaign !'
      ]);
    }


    return redirect()->back();
  }

//   public function marketing_verifiy_activity_Update(Request $request)
//   {
//       // Get the data from the request
//       $sno = $request->marketing_sno_edit;
//       $area_name = $request->input('area_name', []); // Dynamic list of areas
//       // return $request;
//       $result = [];

//       // Loop through each area
//       foreach ($request->input('area_name', []) as $area) {
//           // Sanitize area name to create dynamic keys
//           $sanitized_area = str_replace(' ', '_', $area);
//       // return $sanitized_area;
//           // Fetch dynamic activity data for the area
//           $activities = $request->input("activity_{$sanitized_area}", []);
//           // return $activities;
//           $activity_checks = $request->input("activity_{$area}", []); // activity checkboxes (checked)
//           // return $activity_checks;
//           $amounts = $request->input("checklist_amount_{$sanitized_area}", []);
//           $reasons = $request->input("checklist_reason_{$sanitized_area}", []);
      
//           // Loop through each activity for the area
//           foreach ($activities as $index => $activityData) {
//               // Check if the current activity is checked
//               $checked = isset($activity_checks[$index]['checked']) && $activity_checks[$index]['checked'] == '1' ? 1 : 0;
      
//               // Only process if checked
//               if ($checked) {
//                   // Get the activity name, amount, and reason
//                   $activity_name = $activityData['activity'] ?? null;
//                   $amount = isset($amounts[$index]) ? $amounts[$index] : null;
//                   $reason = isset($reasons[$index]) ? $reasons[$index] : null;
      
//                   // Add to the result array if amount is provided
//                   if (!empty($amount)) {
//                       $result[] = [
//                           'area' => $area,
//                           'checklist' => $activity_name,
//                           'checked' => 1,
//                           'amount' => $amount,
//                           'reason' => $reason
//                       ];
//                   }
//               }
//           }
//       }

//       $totalAmount = 0;
//       foreach ($result as $entry) {
//           $totalAmount += (float)$entry['amount']; // Ensure the amount is treated as a float
//       }
      
//       // Return the result
//       // return $totalAmount;     

//     $user_id = auth()->user()->user_id;
//     $branch_id = $request->user()->branch_id;
//     $upd_CourseModel =  MarketingModel::find($sno);
//     // dd($upd_CourseModel);

//     $upd_CourseModel->checklist = json_encode($result);
//     // dd($upd_CourseModel->checklist);
//     $upd_CourseModel->updated_by = $user_id;
//     $upd_CourseModel->total_amount = $totalAmount;
//     // dd($upd_CourseModel);

//     $upd_CourseModel->update();
//     // dd($upd_CourseModel);
//     return $upd_CourseModel;
//     if ($upd_CourseModel) {
//       session()->flash('toastr', [
//         'type' => 'success',
//         'message' => ' Verifiy Activity added Successfully!'
//       ]);
//     } else {
//       session()->flash('toastr', [
//         'type' => 'error',
//         'message' => 'Could not add the  Manage Campaign !'
//       ]);
//     }


//     // return redirect('/marketing');

//     // return view('content.marketing_management.manage_marketing.list');
//   }

    public function marketing_verifiy_activity_Update(Request $request)
    {
        $sno = $request->marketing_sno_edit;
        $result = [];
    
        foreach ($request->input('area_name', []) as $area) {
            $sanitized_area = str_replace(' ', '_', $area);
    
            // Use sanitized key for all dynamic fields
            $activities = $request->input("activity_{$sanitized_area}", []);
            $amounts = $request->input("checklist_amount_{$sanitized_area}", []);
            $reasons = $request->input("checklist_reason_{$sanitized_area}", []);
    
            foreach ($activities as $index => $activityData) {
                // Get checkbox state properly
                $checked = isset($activityData['checked']) && $activityData['checked'] == '1';
    
                if ($checked) {
                    $activity_name = $activityData['activity'] ?? null;
                    $amount = $amounts[$index] ?? null;
                    $reason = $reasons[$index] ?? null;
    
                    if (!empty($amount)) {
                        $result[] = [
                            'area' => $area,
                            'checklist' => $activity_name,
                            'checked' => 1,
                            'amount' => $amount,
                            'reason' => $reason
                        ];
                    }
                }
            }
        }
    
        $totalAmount = array_sum(array_column($result, 'amount'));
    
        $user_id = auth()->user()->user_id;
        $branch_id = $request->user()->branch_id;
    
        $upd_CourseModel = MarketingModel::find($sno);
        if (!$upd_CourseModel) {
            return response()->json(['message' => 'Marketing record not found'], 404);
        }
    
        $upd_CourseModel->checklist = json_encode($result);
        $upd_CourseModel->total_amount = $totalAmount;
        $upd_CourseModel->updated_by = $user_id;
        $upd_CourseModel->save();
    
        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Verify Activity added Successfully!'
        ]);
    
        return redirect('/branch_campaign');
    }


  //delete function
  public function Delete($id)
  {
    // dd($id);
    $upd_hrdirectoryModel =  MarketingModel::where('sno', $id)->first();
    $upd_hrdirectoryModel->status  = 2;
    $upd_hrdirectoryModel->Update();
    if ($upd_hrdirectoryModel) {
      return response([
        'status'    => 200,
        'message'   => 'Marketing Campaign Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Marketing Campaign!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  // Status change 
  public function Status($id, Request $request)
  {
    // return $id;
    $upd_CourseTypeModel =  MarketingModel::where('sno', $id)->first();
    $helper = new \App\Helpers\Helpers();

    $upd_CourseTypeModel->status = $request->status;
    // return  $upd_CourseTypeModel;
    if ($request->status == 1) {
      $upd_CourseTypeModel->status = 1;
    } elseif($request->status == 3){
      $upd_CourseTypeModel->status = 3;
    }elseif($request->status == 4){
      $upd_CourseTypeModel->status = 4;
    }elseif($request->status == 5){
      $upd_CourseTypeModel->status = 5;
    }

      // return $upd_CourseTypeModel;
      $upd_CourseTypeModel->update();

      return response([
        'status'    => 200,
        'message'   => 'Successfully Status Updated!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
  }
  
}