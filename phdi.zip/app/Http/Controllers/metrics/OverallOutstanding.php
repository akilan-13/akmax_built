<?php

namespace App\Http\Controllers\metrics;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BranchModel;
use App\Models\PaymentModel;
use App\Models\CustomerModel;
use App\Models\DropRefundModel;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Collection;
class OverallOutstanding extends Controller
{
  public function index()
  {
    return view('content.metrics.overall_outstanding');
  }

    // public function overallOutstanding(Request $request)
    // {
    //     $branch_id = $request->user()->branch_id;
    //     $firstIds = DB::table('et_proposal_pay_slot')
    //         ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    //         ->where('et_proposal.status', 0)
    //         ->where('et_proposal_pay_slot.status', 0)
    //         ->whereNotIn('et_proposal.proposal_status', [0, 2])
    //         ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
    //         ->groupBy('et_proposal_pay_slot.proposal_sno')
    //         ->orderBy('first_id', 'asc')
    //         ->pluck('first_id');

    //     // Get customers with slot info (flat structure)
    //     $customers = DB::table('et_customer')
    //         ->where('et_customer.branch_id', $branch_id)
    //         ->where('et_customer.status', 0)
    //         ->leftJoin('et_proposal_pay_slot', 'et_proposal_pay_slot.lead_id', '=', 'et_customer.lead_id')
    //         ->leftJoin('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->leftJoin('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
    //         ->leftJoin('et_country_currencies', 'et_country_currencies.sno', '=', 'et_proposal.currency_id')
    //         ->select(
    //             'et_customer.*',
    //             'et_proposal_pay_slot.payable_amount',
    //             'et_proposal_pay_slot.total_amount',
    //             'et_proposal_pay_slot.balance_amount',
    //             'et_proposal_pay_slot.paid_status',
    //             'et_proposal_pay_slot.initialPayDate',
    //             'et_proposal_pay_slot.nextPayDate',
    //             'et_proposal.currency_id',
    //             'et_proposal.post_sale_check',
    //             'et_country_currencies.currency_code'
    //         )
    //         ->whereNotIn('et_proposal.proposal_status', [0, 2])
    //          ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
    //         ->where('et_lead.created_by', '>', 1)
    //         ->get();

    //     $branch = BranchModel::where('sno', $branch_id)
    //         ->where('status', 0)
    //         ->select('min_prd_cost', 'gst_percentage')
    //         ->first();

    //     $branchCost = $branch->min_prd_cost ?? 0;
    //     $gstPer = $branch->gst_percentage ?? 0;

    //     $overallStandings = [];
    //     $grandTotal = 0.0;

    //     // Group slots by customer
    //     $grouped = $customers->groupBy('lead_id');

    //     foreach ($grouped as $lead_id => $slots) {
    //         $customerCumulative = 0.0;
    //         $reachedThreshold = false;
    //         $customerName = $slots->first()->cus_name;
    //         $customerId = $slots->first()->customer_id;

    //         foreach ($slots as $slot) {
    //             $status = (int) $slot->paid_status;
    //             $isInr = (int) $slot->currency_id === 70;
    //             $slotAmount = (float) $slot->payable_amount;
    //             $basePaidAmount = (float) $slot->payable_amount;
    //             $currencyCode = $slot->currency_code;

    //             $gstAmount = 0.0;
    //             $paidAmount = 0.0;
    //             $amount = 0.0;

    //             if ($isInr) {
    //                 // For INR: apply GST normally
    //                 $gstAmount = $basePaidAmount * ($gstPer / 100);
    //                 $paidAmount = $basePaidAmount + $gstAmount;
    //                 $amount = $slotAmount;
    //             } else {
    //                 // For other currencies: reverse GST, convert to INR, then reapply GST
    //                 $baseAmount = $basePaidAmount / (1 + ($gstPer / 100));

    //                 // Convert to INR using helper
    //                 $helper = new \App\Helpers\Helpers();
    //                 $convertedAmount = $helper->ConvertedAmountInr($currencyCode, $baseAmount);

    //                 // Reapply GST on converted amount
    //                 $gstAmount = $convertedAmount * ($gstPer / 100);
    //                 $paidAmount = $convertedAmount + $gstAmount;

    //                 $amount = 0.0;
    //             }



    //             if ($status === 2 || $amount < 0 || $paidAmount < 0) {
    //                 continue;
    //             }

    //             if ($status === 1) {
    //                 $customerCumulative += $paidAmount;

    //                 if (!$reachedThreshold && $customerCumulative <= $branchCost) {
    //                     continue;
    //                 }

    //                 if (!$reachedThreshold && $customerCumulative > $branchCost) {
    //                     $reachedThreshold = true;
    //                 }
    //             }

    //             if ($status === 0) {
    //                 if (is_null($slot->nextPayDate)) {
    //                     continue;
    //                 }
    //                 $month = \Carbon\Carbon::parse($slot->nextPayDate)->format('Y-m');
    //                 $amountToShow = $amount;
    //                 $bg = '#ffcccc';
    //             } else {
    //                 if (is_null($slot->initialPayDate)) {
    //                     continue;
    //                 }
    //                 $month = \Carbon\Carbon::parse($slot->initialPayDate)->format('Y-m');
    //                 $amountToShow = $paidAmount;
    //                 $bg = '#ccffcc';
    //             }

    //             if (!isset($overallStandings[$month])) {
    //                 $overallStandings[$month] = ['month_total' => 0.0, 'rows' => []];
    //             }

    //             if ($amountToShow <= 0) {
    //                 continue;
    //             }

    //             if ($status === 0) {
    //                 $grandTotal += $amountToShow;
    //             }

    //             $overallStandings[$month]['month_total'] += $amountToShow;

    //             $overallStandings[$month]['rows'][] = [
    //                 'name'       => $customerName,
    //                 'customerId' => $customerId,
    //                 'amount'     => $amountToShow,
    //                 'bg'         => $bg,
    //                 'status'     => $status,
    //                 'cumulative' => $customerCumulative,
    //                 'reachedThreshold' => $reachedThreshold,
    //                 'post_sale_check' => $slot->post_sale_check
    //             ];
    //         }
    //     }

    //     return response()->json([
    //         'status' => 200,
    //         'data' => $overallStandings,
    //         'grand_total_outstanding' => $grandTotal,
    //         'branch_cost' => $branchCost
    //     ]);
    // }
    
    public function overallOutstanding(Request $request)
    {

        $helper = new \App\Helpers\Helpers();
        $branch_id = $request->user()->branch_id;

        $firstIds = DB::table('et_proposal_pay_slot')
            ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
            ->where('et_proposal.status', 0)
            ->where('et_proposal_pay_slot.status', 0)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
            ->groupBy('et_proposal_pay_slot.proposal_sno')
            ->orderBy('first_id', 'asc')
            ->pluck('first_id');
            $drop_ids = DB::table('et_customer')
              ->where('et_customer.drop_refund_id', '!=' ,0)
              ->where('et_customer.drop_verified' ,1)
              ->pluck('et_customer.sno');

        $HistoryPayment = DB::table('et_proposal_pay_slot')
            ->leftJoin('et_payment', 'et_proposal_pay_slot.sno', '=', 'et_payment.pay_slot_id')
            ->leftJoin('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_lead.created_by', '>', 1)
            ->whereNotIn('et_customer.sno', $drop_ids)
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereNotIn('et_proposal.proposal_status', [0, 2])
            ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
            ->select(
                'et_payment.payment_id',
                'et_proposal_pay_slot.nextPayDate',
                'et_proposal_pay_slot.initialPayDate',
                'et_proposal_pay_slot.paid_status AS payment_status',
                'et_proposal_pay_slot.payable_amount AS payment_amount',
                'et_proposal_pay_slot.paidAmount AS payment_paid_amt',
                'et_proposal_pay_slot.gst_amount AS payment_gst_amount',
                'et_proposal_pay_slot.balance_amount',
                'et_proposal.post_sale_check',
                'et_customer.sno as customer_sno',
                'et_customer.customer_id',
                'et_customer.cus_name',
                'et_customer.cus_pic',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_proposal.service_title',
                'et_proposal.gst_perc',
                'et_proposal.currency_id',
                'et_country_currencies.currency_code',
                'et_country_currencies.currency_symbol',
                'et_proposal.sno as proposal_id',
                'et_transaction.total_amount_inr',
                'et_proposal_pay_slot.propo_pay_slot_id',
                DB::raw('MAX(et_proposal_pay_slot.total_amount) as overall_amount'),
                DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS overall_gst_fees'),
                DB::raw('MAX(et_proposal_pay_slot.paidAmount) AS tot_pay_amt'),
                DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_pay_gst_amt'),
                DB::raw('MAX(et_proposal_pay_slot.balance_amount) AS tot_bal_amt'),
                DB::raw('MAX(et_proposal_pay_slot.gst_amount) AS tot_bal_gst_amt'),
                DB::raw("'0' AS is_previous")
            )
            ->groupBy(
                'et_payment.payment_id',
                'et_customer.sno',
                'et_customer.customer_id',
                'et_proposal_pay_slot.initialPayDate',
                'et_customer.cus_name',
                'et_customer.cus_pic',
                'et_customer.cus_mobile',
                'et_customer.cus_email_id',
                'et_customer.cus_gender',
                'et_proposal.service_title',
                'et_proposal.sno',
                'et_proposal.post_sale_check',
                'et_proposal_pay_slot.propo_pay_slot_id',
                'et_proposal_pay_slot.nextPayDate',
                'et_proposal_pay_slot.paid_status',
                'et_proposal_pay_slot.payable_amount',
                'et_proposal_pay_slot.paidAmount',
                'et_proposal.gst_perc',
                'et_proposal_pay_slot.gst_amount',
                'et_proposal_pay_slot.balance_amount',
                'et_proposal.currency_id',
                'et_country_currencies.currency_code',
                'et_transaction.total_amount_inr',
                'et_country_currencies.currency_symbol'
            );

        if (!empty($customer_fill)) {
            $HistoryPayment->where(function ($query) use ($customer_fill) {
                $query->where('et_customer.cus_name', 'LIKE', "%{$customer_fill}%")
                    ->orWhere('et_customer.cus_mobile', 'LIKE', "%{$customer_fill}%")
                    ->orWhere('et_customer.customer_id', 'LIKE', "%{$customer_fill}%");
            });
        }

        if (!empty($balance_payment)) {
            $HistoryPayment ->where('et_proposal_pay_slot.paid_status', 0)->where('et_proposal_pay_slot.payable_amount', '>', 0);
        }

        $HistoryPayment = $HistoryPayment->get();
        $branchCost = $branch->min_prd_cost ?? 0;
        $netAmountInr = 0;
        $grandTotal = 0.0;
        $customerCumulative = 0.0;
        $reachedThreshold = false;

        foreach ($HistoryPayment as $pay) {
            $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc / 100 : 0;

            if ($pay->payment_status == 0) {
                if ($pay->currency_id != 70) {
                    $convertedPaidAmountInr = $helper->ConvertedAmountInr($pay->currency_code, $pay->payment_amount);
                    $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                } else {
                    $convertedPaidAmountInr = $pay->payment_amount;
                    $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                }
            } else {
                if ($pay->currency_id != 70) {
                    if ($pay->total_amount_inr) {
                        $convertedPaidAmountInr = $pay->total_amount_inr;
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                        $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                    } else {
                        $convertedPaidAmountInr = $helper->ConvertedAmountInr($pay->currency_code, $pay->payment_paid_amt);
                        $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                        $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                    }
                } else {
                    $convertedPaidAmountInr = $pay->payment_paid_amt;
                    $netAmountInr = $convertedPaidAmountInr / (1 + $gstRate);
                    $gstAmountInr = $convertedPaidAmountInr - $netAmountInr;
                }
            }

            $pay->amountToShow = $convertedPaidAmountInr;
            $pay->gstAmount = $gstAmountInr;
            $pay->base_amount = $netAmountInr;

            $status = $pay->payment_status;

            if ($status === 2 || $netAmountInr < 0) {
                continue;
            }

            if ($status === 1) {
                $customerCumulative += $netAmountInr;

                if (!$reachedThreshold && $customerCumulative <= $branchCost) {
                    continue;
                }

                if (!$reachedThreshold && $customerCumulative > $branchCost) {
                    $reachedThreshold = true;
                }
            }

            if ($status === 0) {
                if (is_null($pay->nextPayDate)) {
                    continue;
                }
                $month = \Carbon\Carbon::parse($pay->nextPayDate)->format('Y-m');
                $amountToShow = $netAmountInr;
                $bg = '#ffcccc';
            } else {
                if (is_null($pay->initialPayDate)) {
                    continue;
                }
                $month = \Carbon\Carbon::parse($pay->initialPayDate)->format('Y-m');
                $amountToShow = $netAmountInr;
                $bg = '#ccffcc';
            }

            if (!isset($overallStandings[$month])) {
                $overallStandings[$month] = ['month_total' => 0.0, 'rows' => []];
            }

            if ($amountToShow <= 0) {
                continue;
            }

            if ($status === 0) {
                $grandTotal += $amountToShow;
            }

            $overallStandings[$month]['month_total'] += $amountToShow;

            $overallStandings[$month]['rows'][] = [
                'name'       => $pay->cus_name,
                'customerId' => $pay->customer_id,
                'amount'     => $amountToShow,
                'bg'         => $bg,
                'status'     => $status,
                'cumulative' => $customerCumulative,
                'reachedThreshold' => $reachedThreshold,
                'post_sale_check' => $pay->post_sale_check
            ];
        }

        return response()->json([
            'status' => 200,
            'data' => $overallStandings,
            'grand_total_outstanding' => $grandTotal,
            'branch_cost' => $branchCost
        ]);
    }
}
