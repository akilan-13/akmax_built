<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;
class ManageMetrics extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;
            
        return view('content.metrics.manage_metrics');
    }
     public function incentive(Request $request)
    {
        $branch_id = $request->user()->branch_id;
            
        return view('content.metrics.manage_incentive');
    }
   public function fetchIncentive(Request $request)
   {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id')??$request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('et_staff.staff_name')
        ->where('et_staff.branch_id', $branchId)
        ->where('et_staff.role_id', $role_id)
        ->where('et_staff.status', 0)
        ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
        return response()->json([
            'status' => false,
            'message' => 'Staff not found'
        ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
        'status' => true,
        'staff_names' => $staffNames,
        'types' => $types
    ]);
}

 public function getMetrics(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
        $branch_id = $request->user()->branch_id;
         $helper = new \App\Helpers\Helpers();
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                     $firstIds = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal_pay_slot.status', 0)
                        ->where('et_proposal_pay_slot.branch_id', $branch_id)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                        ->groupBy('et_proposal_pay_slot.proposal_sno')
                        ->orderBy('first_id', 'asc')
                        ->pluck('first_id');
    
        // Old payments
        // $totalPaidAmountOld = DB::table('et_old_payments')
        //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
        //     ->where('et_old_customer.branch_id', $branch_id)
        //     ->where('et_old_payments.status', '!=', 2)
        //     ->whereIn('et_old_customer.status', [1, 4])
        //     ->where('et_old_payments.amount', '>', 0)
        //     ->whereYear('et_old_payments.created_at', $year)
        //     ->whereMonth('et_old_payments.created_at', $month)
        //     ->sum('et_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->sum('et_payment.paid_amount');
            
             $branch = BranchModel::where('sno', $branch_id)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

         $gstPercentage = $branch ? $branch->gst_percentage  : 18;
            
        $transactionTotalNet = 0; // final net after GST

        // 1. INR transactions
        $transactionInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>',1)
            ->where('et_lead.status', '!=',2)
            ->where('et_customer.status',0)
            ->where('et_transaction.payment_status',1)
            ->where('et_payment.currency','INR')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount','et_proposal.gst_perc')
            ->get();
        
        foreach($transactionInr as $row){
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch ? $branch->gst_percentage/100 : 0.18);
            $net = $row->paidAmount / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
        
        // 2. Non-INR with already converted INR total
        $transactionNonInrConvert = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>',1)
            ->where('et_lead.status', '!=',2)
            ->where('et_customer.status',0)
            ->where('et_transaction.payment_status',1)
            ->whereNot('et_payment.currency','INR')
            ->where('et_transaction.total_amount_inr','>',0)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_transaction.total_amount_inr','et_proposal.gst_perc')
            ->get();
        
        foreach($transactionNonInrConvert as $row){
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch ? $branch->gst_percentage/100 : 0.18);
            $net = $row->total_amount_inr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
        
        // 3. Non-INR need conversion
        $transactionNonInr = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_lead.created_by', '>',1)
            ->where('et_lead.status', '!=',2)
            ->where('et_customer.status',0)
            ->where('et_transaction.payment_status',1)
            ->whereNot('et_payment.currency','INR')
            ->where(function($q){
                $q->where('et_transaction.total_amount_inr','<',0)
                  ->orWhereNull('et_transaction.total_amount_inr');
            })
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->select('et_payment.paid_amount as paidAmount','et_proposal.gst_perc','et_country_currencies.currency_code')
            ->get();
        
        foreach($transactionNonInr as $row){
            $convertedInr = $helper->ConvertedAmountInr($row->currency_code, $row->paidAmount);
            $gstRate = $row->gst_perc > 0 ? $row->gst_perc/100 : ($branch ? $branch->gst_percentage/100 : 0.18);
            $net = $convertedInr / (1 + $gstRate);
            $transactionTotalNet += $net;
        }
        
        // Final net collection (matches verified_collection_net style)
        $targetActual = $transactionTotalNet;

        
         // Post-sale & pre-sale actuals (count only)
             $postSaleActualold = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
             ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->whereNotIn('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereYear('et_proposal.post_sale_date', $year)
            ->whereMonth('et_proposal.post_sale_date', $month)
            ->distinct('et_proposal.sno')
            ->count('et_proposal.sno');
            
            $customerConvertDataPost = DB::table('et_customer')
            ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_payment', function($join) {
                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                     ->whereRaw('et_payment.transaction_date = (
                         SELECT MIN(ep.transaction_date)
                         FROM et_payment ep
                         WHERE ep.proposal_id = et_proposal.sno
                     )');
            })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_lead.created_by', '>',1)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->orderBy('et_customer.sno', 'asc')
            ->get();
            
             $postSaleActual =count($customerConvertDataPost);
        // return $postSaleActual;
        // $preSaleActual = CustomerModel::whereIn('status', [0,6]) 
        //     ->where('post_sale_check', 0)
        //     ->where('branch_id', $branch_id)
        //     ->whereYear('created_at', $year)
        //     ->whereMonth('created_at', $month)
        //     ->count();
            
          $preSaleActualData = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->join('et_payment', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1) // Ensure payment status is 1
            ->groupBy('et_customer.sno')  // Group by customer id (et_customer.sno)
            ->orderBy('et_customer.sno', 'asc')  // Order by customer id ascending
            ->get();
            
            $customerConvertData = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by','>',1)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();
            
            $preSaleActual =count($customerConvertData);
            
         $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();       // Carbon with time
         $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->endOfDay(); // Carbon with time
        // Initialize Carbon dates
        $start = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);
            
            
        
         //  harvestingscheduleamount
       $expectedNewByDate = DB::table('et_proposal_pay_slot')
        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
         ->where('et_lead.created_by', '>',1)
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_proposal_pay_slot.paid_status', 1)
        ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
        ->where('et_customer.status', 0)
        ->where('et_proposal_pay_slot.paidAmount', '>', 0)
        ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
        ->select(
            DB::raw("DATE(et_proposal_pay_slot.nextPayDate) as date"),
            "et_payment.paid_amount as paidAmount",
            "et_country_currencies.currency_code as currency_code"
        )
        ->get()
        ->groupBy('date')
        ->map(function ($rows) use ($gstPercentage, $helper) {
            $sum = 0;
            foreach ($rows as $row) {
                // remove GST
                $baseAmount = $row->paidAmount / (1 + ($gstPercentage / 100));
    
                // convert currency
                if ($row->currency_code != "INR") {
                    $converted = $helper->ConvertedAmountInr($row->currency_code, $baseAmount);
                } else {
                    $converted = $baseAmount;
                }
    
                $sum += $converted;
            }
            return $sum;
        })
        ->toArray();


            //   $totalPaidAmountoldNewByDate = DB::table('et_old_payments')
            //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
            //     ->selectRaw('DATE(et_old_payments.created_at) as date, SUM(et_old_payments.paidAmount) as total_expected')
            //     ->where('et_old_customer.branch_id', $branch_id)
            //     ->whereIn('et_old_customer.status', [1, 4])
            //     ->where('et_old_payments.amount', '>', 0)
            //     ->whereBetween('et_old_payments.created_at', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_old_payments.created_at)'))
            //     ->pluck('total_expected', 'date')
            //     ->toArray();
            
            // $harvestingsNotPaidByDate = DB::table('et_proposal_pay_slot')
            //         // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            //         ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            //         ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            //      ->selectRaw("
            //             DATE(et_proposal_pay_slot.nextPayDate) as date, 
            //             SUM(et_proposal_pay_slot.payable_amount) / (1 + (? / 100)) as total_expected
            //         ", [$gstPercentage])
            //     ->where('et_customer.branch_id', $branch_id)
            //     ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
            //     ->where('et_customer.status', 0)
            //     ->where('et_proposal.status', 0)
            //      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
            //     ->whereNotIn('et_proposal.proposal_status', [0,2])
            //     ->where('et_proposal_pay_slot.payable_amount','>', 0) 
            //     ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_proposal_pay_slot.nextPayDate)'))
            //     ->pluck('total_expected', 'date')
            //     ->toArray();
                
            $harvestingsNotPaidByDate = DB::table('et_proposal_pay_slot')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                 ->where('et_lead.created_by', '>',1)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.paid_status', 0) // unpaid
                ->where('et_customer.status', 0)
                ->where('et_proposal.status', 0)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
                ->whereNotIn('et_proposal.proposal_status', [0, 2])
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
                ->select(
                    DB::raw("DATE(et_proposal_pay_slot.nextPayDate) as date"),
                    "et_proposal_pay_slot.payable_amount",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->groupBy('date')
                ->map(function ($rows) use ($gstPercentage, $helper) {
                    $sum = 0;
                    foreach ($rows as $row) {
                        // remove GST
                        $baseAmount = $row->payable_amount / (1 + ($gstPercentage / 100));
            
                        // convert currency
                        if ($row->currency_code != "INR") {
                            $converted = $helper->ConvertedAmountInr($row->currency_code, $baseAmount);
                        } else {
                            $converted = $baseAmount;
                        }
            
                        $sum += $converted;
                    }
                    return $sum;
                })
                ->toArray();

              
            
                    
             $harvestings = collect($expectedNewByDate)
                    // ->mergeRecursive($totalPaidAmountoldNewByDate)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    });
                
                $harvestingscheduleamount = collect($harvestingsNotPaidByDate)
                    ->mergeRecursive($harvestings)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    })
                    ->toArray();
            
            // here we found harvesting Paid amount
            // $paidAmountNewByDate = DB::table('et_proposal_pay_slot')
            //         ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            //         ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            //      ->selectRaw("
            //         DATE(et_proposal_pay_slot.initialPayDate) as date, 
            //         SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_paid
            //     ", [$gstPercentage])
            //     ->where('et_customer.branch_id', $branch_id)
            //     ->where('et_proposal_pay_slot.paid_status', 1)
            //     ->where('et_customer.status', 0)
            //      ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
            //     ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            //     ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
            //     ->pluck('total_paid', 'date')
            //     ->toArray();
            
           $paidAmountNewByDate = DB::table('et_proposal_pay_slot')
    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
    ->where('et_lead.created_by', '>', 1)
    ->where('et_customer.branch_id', $branch_id)
    ->where('et_proposal_pay_slot.paid_status', 1)
    ->where('et_customer.status', 0)
    ->whereNotIn('et_proposal_pay_slot.sno', $firstIds)
    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
    ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
    ->select(
        DB::raw("DATE(et_proposal_pay_slot.initialPayDate) as date"),
        "et_payment.paid_amount as paidAmount",
        "et_transaction.total_amount_inr",
        "et_proposal.gst_perc"
    )
    ->get()
    ->groupBy('date')
    ->map(function ($rows) use ($branch) {
        $sum = 0;
        foreach ($rows as $row) {
            // ✅ Prefer INR amount from transaction if available
            $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                ? $row->total_amount_inr
                : $row->paidAmount;

            // ✅ Use proposal-specific GST, fallback to branch GST
            $gstRate = $row->gst_perc > 0
                ? $row->gst_perc / 100
                : ($branch ? $branch->gst_percentage / 100 : 0.18);

            // ✅ Net without GST
            $netAmount = $amountInr / (1 + $gstRate);

            $sum += $netAmount;
        }
        return $sum;
    })
    ->toArray();


                
                $harvestingPaidAmountIn = $paidAmountNewByDate ;
              
    //   $monthlyTargetActualsByDate = DB::table('et_proposal_pay_slot')
    //         ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    //         ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    //         ->selectRaw("
    //             DATE(et_payment.transaction_date) as date, 
    //             SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as credit
    //         ", [$gstPercentage])
    //         ->where('et_proposal_pay_slot.branch_id', $branch_id)
    //         ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
    //         ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
    //         ->pluck('credit', 'date')
    //         ->toArray();
    
    
     $monthlyTargetActualsByDate = DB::table('et_proposal_pay_slot')
    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
    ->where('et_lead.created_by', '>', 1)
    ->where('et_lead.status', '!=', 2)
    ->where('et_customer.status', 0)
    ->where('et_proposal_pay_slot.paid_status', 1)
    ->where('et_transaction.payment_status', 1) // only verified
    ->where('et_proposal_pay_slot.branch_id', $branch_id)
    ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
    ->select(
        DB::raw("DATE(et_payment.transaction_date) as date"),
        "et_payment.paid_amount as paidAmount",
        "et_country_currencies.currency_code",
        "et_transaction.total_amount_inr",
        "et_proposal.gst_perc"
    )
    ->get()
    ->groupBy('date')
    ->map(function ($rows) use ($branch) {
        $sum = 0;
        foreach ($rows as $row) {
            // ✅ Prefer total_amount_inr if it exists and > 0
            $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                ? $row->total_amount_inr
                : $row->paidAmount; // fallback raw paid amount

            // ✅ GST rate per proposal (fallback to branch default)
            $gstRate = $row->gst_perc > 0
                ? $row->gst_perc / 100
                : ($branch ? $branch->gst_percentage / 100 : 0.18);

            // ✅ Net without GST
            $netAmount = $amountInr / (1 + $gstRate);

            $sum += $netAmount;
        }
        return $sum;
    })
    ->toArray();


            
           
             
        // Fetch pre-sale actuals per day
       
            
     $preSaleActualsByDate = DB::table('et_customer')
        ->selectRaw('DATE(et_payment.transaction_date) as date, COUNT(DISTINCT et_customer.sno) as count')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
       ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by','>', 1)
        ->where('et_customer.post_sale_check', 0)
        ->where('et_customer.branch_id', $branch_id)
        ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
        ->orderBy(DB::raw('DATE(et_payment.transaction_date)'), 'asc')
        ->pluck('count', 'date')
        ->toArray();


            
            // $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            // ->where('post_sale_check', 0)
            // ->where('branch_id', $branch_id)
            // ->whereYear('created_at', $year)
            // ->whereMonth('created_at', $month)
            // ->count();
            
             $preSaleActualData = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
             ->where('et_lead.created_by','>', 1)
            ->where('et_transaction.payment_status', 1) // Ensure payment status is 1
            ->groupBy('et_customer.sno')  // Group by customer id (et_customer.sno)
            ->orderBy('et_customer.sno', 'asc')  // Order by customer id ascending
            ->get();
            
            $customerConvertData = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by','>',1)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();
            
            $preSaleActual =count($customerConvertData);
            
           // Fetch post-sale actuals per day
       
            
            $postSaleActualsByDate = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->selectRaw('DATE(et_payment.transaction_date) as date, COUNT(DISTINCT et_proposal.sno) as count')
                ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.proposal_id = et_proposal.sno
                             )');
                    })
                ->where('et_customer.status', 0)
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_lead.created_by','>', 1)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->whereNotIn('et_proposal.proposal_status', [0,2])
                ->where('et_proposal.branch_id', $branch_id)
                ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
                ->pluck('count', 'date')
                ->toArray();
                
            // return $postSaleActualsByDate;
            
          // Fetch pre-sale customer IDs
        $preSaleCustomerIds = CustomerModel::where('et_customer.status', 0)
            ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.customer_id = et_customer.sno
                         )');
                })
             ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->pluck('et_customer.sno')
            ->toArray();
            
       
        
        // Fetch post-sale customer IDs
        $postSaleCustomerIds = CustomerModel::where('et_customer.status', 0)
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->whereNotIn('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereBetween('et_proposal.post_sale_date', [$startDate, $endDate])
            ->pluck('et_proposal.sno')
            ->toArray();
            
       // Daily paid amounts for post-sale
        // $dailyPaidAmountsPost =DB::table('et_proposal_pay_slot')
        //   ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        //     ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        //     ->where('et_proposal_pay_slot.paid_status', 1)
        //     ->whereIn('et_customer.sno', $postSaleCustomerIds)
        //     ->where('et_customer.post_sale_check', 1)
        //     ->where('et_customer.branch_id', $branch_id)
        //     ->where('et_proposal_pay_slot.payable_amount', '>', 0)
        //     ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
        //     ->selectRaw("
        //         DATE(et_proposal_pay_slot.initialPayDate) as date, 
        //         SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
        //     ", [$gstPercentage])
        //     ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
        //     ->pluck('total_amount', 'date')
        //     ->toArray();
        
        $dailyPaidAmountsPost = DB::table('et_proposal_pay_slot')
        ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
        ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
        ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->where('et_lead.created_by', '>',1)
        ->where('et_proposal_pay_slot.paid_status', 1)
        ->whereIn('et_customer.sno', $postSaleCustomerIds)
        ->where('et_customer.post_sale_check', 1)
        ->where('et_customer.branch_id', $branch_id)
        ->where('et_proposal_pay_slot.payable_amount', '>', 0)
        ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
        ->select(
            DB::raw("DATE(et_proposal_pay_slot.initialPayDate) as date"),
            "et_payment.paid_amount as paidAmount",
            "et_country_currencies.currency_code as currency_code"
        )
        ->get()
        ->groupBy('date')
        ->map(function ($rows) use ($gstPercentage, $helper) {
            $sum = 0;
            foreach ($rows as $row) {
                // remove GST
                $baseAmount = $row->paidAmount / (1 + ($gstPercentage / 100));
    
                // convert to INR
                if ($row->currency_code != "INR") {
                    $converted = $helper->ConvertedAmountInr($row->currency_code, $baseAmount);
                } else {
                    $converted = $baseAmount;
                }
    
                $sum += $converted;
            }
            return $sum;
        })
        ->toArray();

        
        // Daily paid amounts for pre-sale
        // $dailyPaidAmountsPre = DB::table('et_proposal_pay_slot')
        //   ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        //     ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
        //     ->where('et_proposal_pay_slot.paid_status', 1)
        //     ->whereIn('et_customer.sno', $preSaleCustomerIds)
        //     ->where('et_customer.post_sale_check', 0)
        //     ->where('et_customer.branch_id', $branch_id)
        //     ->where('et_proposal_pay_slot.payable_amount', '>', 0)
        //     ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
        //     ->selectRaw("
        //         DATE(et_proposal_pay_slot.initialPayDate) as date, 
        //         SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
        //     ", [$gstPercentage])
        //     ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
        //     ->pluck('total_amount', 'date')
        //     ->toArray();
            
            
            $dailyPaidAmountsPre = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereIn('et_customer.sno', $preSaleCustomerIds)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            ->select(
                DB::raw("DATE(et_proposal_pay_slot.initialPayDate) as date"),
                "et_payment.paid_amount as paidAmount",
                "et_country_currencies.currency_code as currency_code"
            )
            ->get()
            ->groupBy('date')
            ->map(function ($rows) use ($gstPercentage, $helper) {
                $sum = 0;
                foreach ($rows as $row) {
                    // remove GST
                    $baseAmount = $row->paidAmount / (1 + ($gstPercentage / 100));
        
                    // convert to INR
                    if ($row->currency_code != "INR") {
                        $converted = $helper->ConvertedAmountInr($row->currency_code, $baseAmount);
                    } else {
                        $converted = $baseAmount;
                    }
        
                    $sum += $converted;
                }
                return $sum;
            })
            ->toArray();

            
            
             // STEP 1: Get all pre-sale + post-sale payment invoice_ids to exclude
            $excludedInvoiceIds =  DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>',1)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->whereIn('et_customer.sno', array_merge($preSaleCustomerIds, $postSaleCustomerIds))
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
                ->pluck('et_proposal_pay_slot.invoice_id') 
                ->filter() // remove nulls
                ->unique() // ensure uniqueness
                ->toArray();
     
        //   $dailyPaidAmountOther = DB::table('et_payment')
        //     ->where('et_payment.branch_id', $branch_id)
        //     ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
        //     ->when(!empty($excludedInvoiceIds), function ($query) use ($excludedInvoiceIds) {
        //         $query->where(function ($subQuery) use ($excludedInvoiceIds) {
        //             $subQuery->whereNotIn('et_payment.invoice_id', $excludedInvoiceIds)
        //                      ->orWhereNull('et_payment.invoice_id'); // include NULLs
        //         });
        //     })
        //     ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
        //     ->selectRaw("
        //         DATE(et_payment.transaction_date) as date, 
        //         SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
        //     ", [$gstPercentage])
        //     ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
        //     ->pluck('total_amount', 'date')
        //     ->toArray();
        
        
        $dailyPaidAmountOther = DB::table('et_payment')
            ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
             ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_payment.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->when(!empty($excludedInvoiceIds), function ($query) use ($excludedInvoiceIds) {
                $query->where(function ($subQuery) use ($excludedInvoiceIds) {
                    $subQuery->whereNotIn('et_payment.invoice_id', $excludedInvoiceIds)
                             ->orWhereNull('et_payment.invoice_id'); // include NULLs
                });
            })
            ->select(
                DB::raw("DATE(et_payment.transaction_date) as date"),
                "et_payment.paid_amount as paidAmount",
                "et_country_currencies.currency_code as currency_code"
            )
            ->get()
            ->groupBy('date')
            ->map(function ($rows) use ($gstPercentage, $helper) {
                $sum = 0;
                foreach ($rows as $row) {
                    // remove GST
                    $baseAmount = $row->paidAmount / (1 + ($gstPercentage / 100));
        
                    // convert to INR
                    if ($row->currency_code != "INR") {
                        $converted = $helper->ConvertedAmountInr($row->currency_code, $baseAmount);
                    } else {
                        $converted = $baseAmount;
                    }
        
                    $sum += $converted;
                }
                return $sum;
            })
            ->toArray();

                    
            
        // Pre-sale cumulative per day
        $preSaleActualPerDay = [];
        $current = $start->copy();
        $cumulativePreSale = 0;
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $preSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePreSale += $dailyValue;
                $preSaleActualPerDay[$dateStr] = $cumulativePreSale;
            } else {
                $preSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        // Post-sale cumulative per day
        $postSaleActualPerDay = [];
        $current = $start->copy(); // reset date pointer
        $cumulativePostSale = 0;
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $postSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePostSale += $dailyValue;
                $postSaleActualPerDay[$dateStr] = $cumulativePostSale;
            } else {
                $postSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }

        
        $monthlyTargetActualPerDay = [];
        $cumulativeTarget = 0;
        $current = $start->copy();
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyTarget = $monthlyTargetActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativeTarget += $dailyTarget;
                $monthlyTargetActualPerDay[$dateStr] = $cumulativeTarget;
            } else {
                $monthlyTargetActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        
            $dailyPaidAmountPerDay = [];
            $cumulativePaid = 0;
            $current = \Carbon\Carbon::parse($startDate)->copy();
            $end = \Carbon\Carbon::parse($endDate);
            $today = now()->format('Y-m-d');
            
            while ($current->lte($end)) {
                $dateStr = $current->format('Y-m-d');
            
                $paidNew = $paidAmountNewByDate[$dateStr] ?? 0;
                $paidOld = $paidAmountOldByDate[$dateStr] ?? 0;
            
                $dailyTotalPaid = $paidNew + $paidOld;
            
                if ($dateStr <= $today) {
                    $cumulativePaid += $dailyTotalPaid;
                    $dailyPaidAmountPerDay[$dateStr] = $cumulativePaid;
                } else {
                    $dailyPaidAmountPerDay[$dateStr] = 0;
                }
            
                $current->addDay();
            }
                    
            $preSaleTarget      = $targets->no_of_registrations ?? 0;
            $postSaleTarget     = $targets->post_sale ?? 0;
            $monthlyTarget      = $targets->monthly_target ?? 0;
            $harvestingschedule = $harvestingscheduleamount;
            
            // $harvestingsExpectedByDate = $this->distributeIndividuallyPerDay($harvestingsExpectedByDate, $startDate, $endDate);
            $monthlyTargetExpectedByDate = $this->distributePerDay($monthlyTarget, $startDate, $endDate);
            $preSaleExpectedByDate = $this->distributePerDay($preSaleTarget, $startDate, $endDate);
            $postSaleExpectedByDate = $this->distributePerDay($postSaleTarget, $startDate, $endDate);
            
            $dates = array_keys($preSaleExpectedByDate);
       
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                
            ],
            'distribution' => [
                'dates' => $dates,
                'harvestings_expected' => $harvestingschedule,
                'monthly_target_expected' => $monthlyTargetExpectedByDate,
                'pre_sale_expected' => $preSaleExpectedByDate,
                'post_sale_expected' => $postSaleExpectedByDate,
                // 'harvestings_actual_per_day' => $dailyPaidAmountPerDay,
                'harvestings_actual_per_day' => $harvestingPaidAmountIn,
                'monthly_target_actual_per_day' => $monthlyTargetActualPerDay,
                'pre_sale_actual_per_day' => $preSaleActualPerDay,
                'post_sale_actual_per_day' => $postSaleActualPerDay,
                'dailyPaidAmountsPre' => $dailyPaidAmountsPre,
                'dailyPaidAmountsPost' => $dailyPaidAmountsPost,
                'dailyPaidAmountsOther' => $dailyPaidAmountOther,
                // 'preSaleInvoiceIds' => $preSaleInvoiceDateMap,
            ],
        ]);
    }
   
    public function getMetricsold(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
        $branch_id = $request->user()->branch_id;
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                     $firstIds = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->join('et_lead', 'et_proposal.lead_id', '=', 'et_lead.sno')
                        ->where('et_proposal.status', 0)
                        ->where('et_lead.created_by','>',1)
                        ->where('et_proposal_pay_slot.status', 0)
                        ->where('et_proposal_pay_slot.branch_id', $branch_id)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                        ->groupBy('et_proposal_pay_slot.proposal_sno')
                        ->orderBy('first_id', 'asc')
                        ->pluck('first_id');
    
        // Old payments
        // $totalPaidAmountOld = DB::table('et_old_payments')
        //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
        //     ->where('et_old_customer.branch_id', $branch_id)
        //     ->where('et_old_payments.status', '!=', 2)
        //     ->whereIn('et_old_customer.status', [1, 4])
        //     ->where('et_old_payments.amount', '>', 0)
        //     ->whereYear('et_old_payments.created_at', $year)
        //     ->whereMonth('et_old_payments.created_at', $month)
        //     ->sum('et_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->sum('et_payment.paid_amount as paidAmount');
            
        // $transaction = DB::table('et_transaction')
        //      ->where('et_transaction.branch_id', $branch_id)
        //       ->whereYear('et_transaction.transaction_date', $year)
        //     ->whereMonth('et_transaction.transaction_date', $month)
        //      ->sum('et_transaction.credit');
            
        $transaction = DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
              ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
              ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.status', '!=',2)
             ->where('et_proposal_pay_slot.paid_status', 1)
             ->where('et_proposal_pay_slot.branch_id', $branch_id)
             ->whereYear('et_payment.transaction_date', $year)
             ->whereMonth('et_payment.transaction_date', $month)
             ->sum('et_payment.paid_amount as paidAmount');
             
             $branch = BranchModel::where('sno', $branch_id)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

      $gstPercentage = $branch ? $branch->gst_percentage  : 18;
             
        // $gst_percent = 18;
         
        $base_amount_paid = $transaction / (1 + ($gstPercentage / 100));
    
    // return $transaction;
            
        // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
        $targetActual = $base_amount_paid;
        
         // Post-sale & pre-sale actuals (count only)
             $postSaleActualold = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
             ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->whereNotIn('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereYear('et_proposal.created_at', $year)
            ->whereMonth('et_proposal.created_at', $month)
            ->distinct('et_proposal.sno')
            ->count('et_proposal.sno');
            
             $customerConvertDataPost = DB::table('et_customer')
                ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->join('et_payment', function($join) {
                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                         ->whereRaw('et_payment.transaction_date = (
                             SELECT MIN(ep.transaction_date)
                             FROM et_payment ep
                             WHERE ep.proposal_id = et_proposal.sno
                         )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_lead.created_by', '>',1)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->orderBy('et_customer.sno', 'asc')
                ->get();
            
             $postSaleActual =count($customerConvertDataPost);
    
        $preSaleActual = CustomerModel::whereIn('status', [0,6]) 
            ->where('post_sale_check', 0)
            ->where('branch_id', $branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
            
         $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();       // Carbon with time
         $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->endOfDay(); // Carbon with time
        // Initialize Carbon dates
        $start = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);
        
        
         //  harvestingscheduleamount
       
            $expectedNewByDate =DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>',1)
                    ->selectRaw("
                        DATE(et_proposal_pay_slot.nextPayDate) as date, 
                        SUM(et_payment.paid_amount) / (1 + (? / 100)) as total_expected
                    ", [$gstPercentage])
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_proposal_pay_slot.paid_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_proposal_pay_slot.paidAmount', '>', 0)
                    ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
                    ->groupBy(DB::raw('DATE(et_proposal_pay_slot.nextPayDate)'))
                    ->pluck('total_expected', 'date')
                    ->toArray();
            //   $totalPaidAmountoldNewByDate = DB::table('et_old_payments')
            //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
            //     ->selectRaw('DATE(et_old_payments.created_at) as date, SUM(et_old_payments.paidAmount) as total_expected')
            //     ->where('et_old_customer.branch_id', $branch_id)
            //     ->whereIn('et_old_customer.status', [1, 4])
            //     ->where('et_old_payments.amount', '>', 0)
            //     ->whereBetween('et_old_payments.created_at', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_old_payments.created_at)'))
            //     ->pluck('total_expected', 'date')
            //     ->toArray();
            
            $harvestingsNotPaidByDate = DB::table('et_proposal_pay_slot')
                    // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>',1)
                 ->selectRaw("
                        DATE(et_proposal_pay_slot.nextPayDate) as date, 
                        SUM(et_proposal_pay_slot.payable_amount) / (1 + (? / 100)) as total_expected
                    ", [$gstPercentage])
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
                ->where('et_customer.status', 0)
                ->where('et_proposal.status', 0)
                 ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
                ->whereNotIn('et_proposal.proposal_status', [0,2])
                ->where('et_proposal_pay_slot.payable_amount','>', 0) 
                ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal_pay_slot.nextPayDate)'))
                ->pluck('total_expected', 'date')
                ->toArray();
                
              
            
                    
             $harvestings = collect($expectedNewByDate)
                    // ->mergeRecursive($totalPaidAmountoldNewByDate)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    });
                
                $harvestingscheduleamount = collect($harvestingsNotPaidByDate)
                    ->mergeRecursive($harvestings)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    })
                    ->toArray();
            
            // here we found harvesting Paid amount
            $paidAmountNewByDate = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>',1)
                 ->selectRaw("
                    DATE(et_proposal_pay_slot.initialPayDate) as date, 
                    SUM(et_payment.paid_amount) / (1 + (? / 100)) as total_paid
                ", [$gstPercentage])
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->where('et_customer.status', 0)
                 ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
                ->pluck('total_paid', 'date')
                ->toArray();
            
            // $paidAmountOldByDate = DB::table('et_old_payments')
            //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
            //     ->selectRaw('DATE(et_old_payments.created_at) as date, SUM(et_old_payments.paidAmount) as total_paid')
            //     ->where('et_old_customer.branch_id', $branch_id)
            //     ->where('et_old_payments.status', '!=', 2)
            //     ->whereIn('et_old_customer.status', [1, 4])
            //     ->where('et_old_payments.amount', '>', 0)
            //     ->whereBetween('et_old_payments.created_at', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_old_payments.created_at)'))
            //     ->pluck('total_paid', 'date')
            //     ->toArray();
                
                $harvestingPaidAmountIn = $paidAmountNewByDate ;
              
      $monthlyTargetActualsByDate = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
             ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
              ->where('et_lead.status', '!=',2)
             ->where('et_customer.status',0)
             ->where('et_proposal_pay_slot.paid_status', 1)
            ->selectRaw("
                DATE(et_payment.transaction_date) as date, 
                SUM(et_payment.paid_amount) / (1 + (? / 100)) as credit
            ", [$gstPercentage])
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
            ->pluck('credit', 'date')
            ->toArray();
            
           
             
        // Fetch pre-sale actuals per day
        $preSaleActualsByDate = CustomerModel::selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->whereIn('status', [0, 6])
            ->where('post_sale_check', 0)
            ->where('branch_id', $branch_id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy(DB::raw('DATE(created_at)'))
            ->pluck('count', 'date')
            ->toArray();
            
            $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            ->where('post_sale_check', 0)
            ->where('branch_id', $branch_id)
            ->whereYear('created_at', $year)
            ->whereMonth('created_at', $month)
            ->count();
            
           // Fetch post-sale actuals per day
       
            
            $postSaleActualsByDate = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->selectRaw('DATE(et_proposal.created_at) as date, COUNT(DISTINCT et_proposal.sno) as count')
                ->whereIn('et_customer.status', [0, 6])
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                 ->where('et_lead.created_by', '>',1)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_proposal.proposal_status', [0,2])
                ->where('et_proposal.branch_id', $branch_id)
                ->whereBetween('et_proposal.created_at', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal.created_at)'))
                ->pluck('count', 'date')
                ->toArray();
            
          // Fetch pre-sale customer IDs
        $preSaleCustomerIds = CustomerModel::whereIn('status', [0, 6])
            ->where('post_sale_check', 0)
            ->where('branch_id', $branch_id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->pluck('sno')
            ->toArray();
            
       
        
        // Fetch post-sale customer IDs
        $postSaleCustomerIds = CustomerModel::whereIn('et_customer.status', [0, 6])
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.created_by', '>',1)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereBetween('et_proposal.created_at', [$startDate, $endDate])
            ->pluck('et_proposal.sno')
            ->toArray();
            
       // Daily paid amounts for post-sale
        $dailyPaidAmountsPost =DB::table('et_proposal_pay_slot')
          ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereIn('et_customer.sno', $postSaleCustomerIds)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            ->selectRaw("
                DATE(et_proposal_pay_slot.initialPayDate) as date, 
                SUM(et_payment.paid_amount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
            ->pluck('total_amount', 'date')
            ->toArray();
        
        // Daily paid amounts for pre-sale
        $dailyPaidAmountsPre = DB::table('et_proposal_pay_slot')
          ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereIn('et_customer.sno', $preSaleCustomerIds)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            ->selectRaw("
                DATE(et_proposal_pay_slot.initialPayDate) as date, 
                SUM(et_payment.paid_amount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
            ->pluck('total_amount', 'date')
            ->toArray();
            
            
            
             // STEP 1: Get all pre-sale + post-sale payment invoice_ids to exclude
            $excludedInvoiceIds =  DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->whereIn('et_customer.sno', array_merge($preSaleCustomerIds, $postSaleCustomerIds))
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
                ->pluck('et_proposal_pay_slot.invoice_id') 
                ->filter() // remove nulls
                ->unique() // ensure uniqueness
                ->toArray();
     
           $dailyPaidAmountOther = DB::table('et_payment')
            ->where('et_payment.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->when(!empty($excludedInvoiceIds), function ($query) use ($excludedInvoiceIds) {
                $query->where(function ($subQuery) use ($excludedInvoiceIds) {
                    $subQuery->whereNotIn('et_payment.invoice_id', $excludedInvoiceIds)
                             ->orWhereNull('et_payment.invoice_id'); // include NULLs
                });
            })
            ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->selectRaw("
                DATE(et_payment.transaction_date) as date, 
                SUM(et_payment.paid_amount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
            ->pluck('total_amount', 'date')
            ->toArray();
                    
            
        // Pre-sale cumulative per day
        $preSaleActualPerDay = [];
        $current = $start->copy();
        $cumulativePreSale = 0;
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $preSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePreSale += $dailyValue;
                $preSaleActualPerDay[$dateStr] = $cumulativePreSale;
            } else {
                $preSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        // Post-sale cumulative per day
        $postSaleActualPerDay = [];
        $current = $start->copy(); // reset date pointer
        $cumulativePostSale = 0;
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $postSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePostSale += $dailyValue;
                $postSaleActualPerDay[$dateStr] = $cumulativePostSale;
            } else {
                $postSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }

        
        $monthlyTargetActualPerDay = [];
        $cumulativeTarget = 0;
        $current = $start->copy();
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyTarget = $monthlyTargetActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativeTarget += $dailyTarget;
                $monthlyTargetActualPerDay[$dateStr] = $cumulativeTarget;
            } else {
                $monthlyTargetActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        
            $dailyPaidAmountPerDay = [];
            $cumulativePaid = 0;
            $current = \Carbon\Carbon::parse($startDate)->copy();
            $end = \Carbon\Carbon::parse($endDate);
            $today = now()->format('Y-m-d');
            
            while ($current->lte($end)) {
                $dateStr = $current->format('Y-m-d');
            
                $paidNew = $paidAmountNewByDate[$dateStr] ?? 0;
                $paidOld = $paidAmountOldByDate[$dateStr] ?? 0;
            
                $dailyTotalPaid = $paidNew + $paidOld;
            
                if ($dateStr <= $today) {
                    $cumulativePaid += $dailyTotalPaid;
                    $dailyPaidAmountPerDay[$dateStr] = $cumulativePaid;
                } else {
                    $dailyPaidAmountPerDay[$dateStr] = 0;
                }
            
                $current->addDay();
            }
                    
            $preSaleTarget      = $targets->no_of_registrations ?? 0;
            $postSaleTarget     = $targets->post_sale ?? 0;
            $monthlyTarget      = $targets->monthly_target ?? 0;
            $harvestingschedule = $harvestingscheduleamount;
            
            // $harvestingsExpectedByDate = $this->distributeIndividuallyPerDay($harvestingsExpectedByDate, $startDate, $endDate);
            $monthlyTargetExpectedByDate = $this->distributePerDay($monthlyTarget, $startDate, $endDate);
            $preSaleExpectedByDate = $this->distributePerDay($preSaleTarget, $startDate, $endDate);
            $postSaleExpectedByDate = $this->distributePerDay($postSaleTarget, $startDate, $endDate);
            
            $dates = array_keys($preSaleExpectedByDate);
       
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                
            ],
            'distribution' => [
                'dates' => $dates,
                'harvestings_expected' => $harvestingschedule,
                'monthly_target_expected' => $monthlyTargetExpectedByDate,
                'pre_sale_expected' => $preSaleExpectedByDate,
                'post_sale_expected' => $postSaleExpectedByDate,
                // 'harvestings_actual_per_day' => $dailyPaidAmountPerDay,
                'harvestings_actual_per_day' => $harvestingPaidAmountIn,
                'monthly_target_actual_per_day' => $monthlyTargetActualPerDay,
                'pre_sale_actual_per_day' => $preSaleActualPerDay,
                'post_sale_actual_per_day' => $postSaleActualPerDay,
                'dailyPaidAmountsPre' => $dailyPaidAmountsPre,
                'dailyPaidAmountsPost' => $dailyPaidAmountsPost,
                'dailyPaidAmountsOther' => $dailyPaidAmountOther,
                // 'preSaleInvoiceIds' => $preSaleInvoiceDateMap,
            ],
        ]);
    }
    
    private function distributePerDay($total, $startDate)
    {
        $days = [];
    
        $start = \Carbon\Carbon::parse($startDate)->startOfDay();
        $end = $start->copy()->endOfMonth();
        $diffDays = $start->diffInDays($end) + 1;
    
        if ($diffDays <= 0) return [];
    
        $step = $total / $diffDays;
        $sum = 0;
        $currentDate = $start->copy();
    
        for ($i = 0; $i < $diffDays; $i++) {
            $sum += $step;
            $rounded = round($sum);
    
            // Ensure last day hits exact total (e.g., 100)
            if ($i == $diffDays - 1) {
                $rounded = $total;
            }
    
            $days[$currentDate->format('Y-m-d')] = $rounded;
            $currentDate->addDay();
        }
    
        return $days;
    }
    
    private function distributeIndividuallyPerDay($total, $startDate, $endDate)
    {
    $days = [];

    $start = \Carbon\Carbon::parse($startDate)->startOfDay();
    $end = \Carbon\Carbon::parse($endDate)->endOfDay();
    $diffDays = $start->diffInDays($end) + 1;

    if ($diffDays <= 0) return [];

    $step = $total / $diffDays;
    $currentDate = $start->copy();
    $sum = 0;

    for ($i = 0; $i < $diffDays; $i++) {
        $remainingDays = $diffDays - $i;
        $value = round(($total - $sum) / $remainingDays); // distribute remainder properly
        $days[$currentDate->format('Y-m-d')] = $value;
        $sum += $value;
        $currentDate->addDay();
    }

    return $days;
}

    public function getConvertion(Request $request)
    {
    $branch_id = $request->user()->branch_id;
    $date = $request->date; // format: Y-m-d

    $startOfMonth = Carbon::parse($date)->startOfMonth()->format('Y-m-d');
    $endOfMonth = Carbon::parse($date)->endOfMonth()->format('Y-m-d');

    // Total converted customers from start of month to selected date
    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_customer.branch_id', $branch_id)
        ->whereRaw('DATE(et_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $date])
        ->select(
            'et_customer.created_at as customer_created_at',
            'et_lead.created_at as lead_created_at'
        )
        ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');

        if ($customerDate === $date && $leadDate === $date) {
            $convertedToday++;
        } elseif (
            $customerDate >= $startOfMonth && $customerDate <= $date &&
            $leadDate >= $startOfMonth && $leadDate <= $date
        ) {
            $convertedMonth++;
        } elseif (
            $customerDate >= $startOfMonth && $customerDate <= $date &&
            ($leadDate < $startOfMonth || $leadDate > $date)
        ) {
            $convertedOldMonth++;
        }
    }

    // Unclassified = total - (today + month + old)
    $convertedUnclassified = $allConverted->count() - ($convertedToday + $convertedMonth + $convertedOldMonth);

    return response()->json([
        'status' => 200,
        'data' => [
            'converted_today' => $convertedToday,
            'converted_month' => $convertedMonth,
            'converted_old_month' => $convertedOldMonth,
            'converted_unclassified' => $convertedUnclassified,
            'converted_total' => $allConverted->count(),
            'converted_total_list' => $allConverted,
        ]
    ]);
}

    
    public function getIncentiveMetrics(Request $request)
    {
        $branchId = $request->branch_id ?? $request->user()->branch_id;
        $departmentId = $request->department_id;
        $role_id = $request->role_id;
        $helper = new \App\Helpers\Helpers();
        $year = $request->year;
    
        if (!empty($request->month)) {
            $request->month = is_numeric($request->month)
                ? (int) $request->month
                : (int) date('m', strtotime($request->month . ' 1'));
        }
        
        $month = $request->month;
        
        // Get the first and last date of the requested month
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    
        // Generate all dates in the month
        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }
    
        // Directly use startDate and endDate for formatting
        $startOfMonth = $startDate->format('Y-m-d');
        $endOfMonth = $endDate->format('Y-m-d');
        
        $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
        $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;
        
        $current = Carbon::create($year, $month, 1);
        // 20 years ago from now
        $startDateold = $current->copy()->subYears(20)->startOfMonth();
        $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
        
          $startDateChck = Carbon::create($year, $month, 1);
            $currentDateChck = Carbon::now();
            $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month) 
                        ? $currentDateChck 
                        : $startDateChck->copy()->endOfMonth();
        
        $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;
        // $sundayCount = 0;
        // for ($date = $startDateChck->copy(); $date <= $endDateChck; $date->addDay()) {
        // // Check if the current day is a Sunday and has already passed (i.e., not today)
        //     if ($date->dayOfWeek === Carbon::SUNDAY && $date->isPast()) {
        //         $sundayCount++;
        //     }
        // }
            
        //     // If today is Sunday and hasn't finished yet, don't count it
        //     if ($currentDateChck->dayOfWeek === Carbon::SUNDAY && $currentDateChck->hour < 23) {
        //         $sundayCount--;
        //     }
         
        //     // Subtract the Sundays from the total day count
        //     $dayCountMonth = $dayCountMonth - $sundayCount;
        
        // $month=7;
        
        $staffList = StaffModel::join('et_sub_department', 'et_sub_department.sno', '=', 'et_staff.sub_department_id')
              ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
              ->join('et_branch', 'et_branch.sno', '=', 'et_staff.branch_id')
            ->where('et_staff.branch_id', $branchId)
            ->where('et_staff.role_id', $role_id)
            ->where('et_staff.status', 0)
            // ->where('et_staff.sno', 57)
            ->select(
                'et_staff.sno as staff_id',
                'et_staff.staff_name',
                'et_staff.role_id',
                'et_staff.department_id',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.branch_id',
                'et_branch.branch_name',
                'et_branch.franchise_name',
                'et_staff.avaiable_points',
                 'et_staff.per_hour_cost',
                'et_staff.basic_salary',
                'et_sub_department.sub_department_id',
                'et_sub_department.sub_department_name',
                'et_department.department_name'
            )
            ->get();
            $departmentIds = $staffList->pluck('department_id')->unique()->toArray();
            //  return  $departmentIds;
            $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $departmentIds)->where('et_goal_set_team.branch_id', $branchId)
          ->where('et_goal_set_team.team_goal_month', $request->month)
          ->where('et_goal_set_team.team_goal_year', $year)
          ->first();
        
            // Get goal records for the selected department and month
            $goalsetRecords = GoalSetStaffModel::where('et_goal_set_staff.department_id', $departmentIds)->where('et_goal_set_staff.branch_id', $branchId)
              ->where('et_goal_set_staff.goal_month', $request->month)
              ->whereMonth('et_goal_set_staff.goal_date', $request->month)
              ->whereYear('et_goal_set_staff.goal_date', $year)
              ->get();
            //   return  $goalsetRecords;
              
            $goalsetData = [];
            foreach ($goalsetRecords as $goal) {
              $goalsetData[$goal->staff_id] = $goal;
            }
    
             
        $result = [];
    
        foreach ($staffList as $staff) {
             
            $isProduction = $staff->role_id == 22;
            $isSalesEx = $staff->role_id == 11;
            $isPostSalesEx = $staff->role_id == 35;
            $isTeamLead = $staff->role_id == 12;
            $isCollection = $staff->role_id == 14;
            $isCRE = $staff->role_id == 16;
            $isJournalCordinator = $staff->role_id == 34;
            $isPC = $staff->role_id == 15;
            $isContentWriter = $staff->role_id == 36;
            $isDeveloper = $staff->role_id == 32;
            $current_date = date('Y-m-d'); // Define the current date
            
            $incentive = IncentiveModel::where('role_id', $staff->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
            // return $staff->role_id;
                 
            // if (!$incentive) {
            //     continue; // Skip if no incentive record for ro
            // }
           
           
            if ($isTeamLead) {
                // Step 1: Get all active executives under same branch and department
                $executives = StaffModel::where('branch_id', $staff->branch_id)
                    ->where('department_id', $staff->department_id)
                    ->where('role_id', 11)
                    ->where('status', 0)
                    ->get();
            
                // Step 2: Filter executive IDs who have goals (conversion > 0)
                $executiveIds = $executives->pluck('sno')->toArray();
            
                $executiveGoalSet = $goalsetRecords
                    ->whereIn('staff_id', $executiveIds)
                    ->where('conversion', '>', 0)
                    ->pluck('staff_id')
                    ->unique()
                    ->toArray();
                $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
                if (!$incentive) {
                    continue; // Skip if no incentive record for role
                }
            
                // Step 3: Re-filter only executives who have goal set
                $filteredExecutives = $executives->whereIn('sno', $executiveGoalSet);
            
                // Step 4: Calculate incentives only for valid executives
                $allExecutiveIncentives = [];
                foreach ($filteredExecutives as $executive) {
                    $allExecutiveIncentives['staff_' . $executive->sno] = $this->calculateIncentivesForStaff(
                        $executive,
                        $branchId,
                        $month,
                        $year,
                        $goalsetData
                    );
                }
        
                // Step 5: Run final status check
                $finalStatus = $this->getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives);
                $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->whereMonth('branch_target.date', $month)
                    ->whereYear('branch_target.date', $request->year)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                    
                $preSaleActual = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->whereYear('et_payment.transaction_date', $request->year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_lead.created_by','>', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->count();
                    $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;
                    $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                //   return $allExecutiveIncentives;
                    // Now prepare result for Team Lead
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
                
                        'incentives' => [
                            'tenx_award' => [
                                'target' => 'All Executives Achieved 10x',
                                'actual' => $individual10x ? 'Achieved' : 'Not Achieved',
                                'status' => $individual10x,
                                'reward' => $individual10x ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                            'eci' => [
                                'target' => 'All Executives Achieved ECI',
                                'actual' => $finalStatus['eci'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['eci'],
                                'reward' => $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                            'bi' => [
                                'target' => 'All Executives Achieved BI',
                                'actual' => $finalStatus['bi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['bi'],
                                'reward' => $finalStatus['bi'] ? ($biReward ?? 0) : 0,
                            ],
                            'si' => [
                                'target' => 'All Executives Achieved SI',
                                'actual' => $finalStatus['si'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['si'],
                                'reward' => $finalStatus['si'] ? 3000 : 0,
                            ],
                            'pi' => [
                                'target' => 'All Executives Achieved PI',
                                'actual' => $finalStatus['pi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['pi'],
                                'reward' => $finalStatus['pi'] ? ($piReward ?? 0) : 0,
                            ],
                            'sp' => [
                                'target' => 'All Executives Achieved SP',
                                'actual' => $finalStatus['sp'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['sp'],
                                'reward' => $finalStatus['sp'] ? ($spotTotalReward ?? 0) : 0,
                            ],
                            'li' => [
                                'target' => 'All Incentives Achieved by Team',
                                'actual' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? 'Achieved'
                                    : 'Not Achieved',
                                'status' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']),
                                'reward' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ],
                    ];
            }
            
            if ($isSalesEx) {
                 
                  
                  //Sales Team 
                  //   return 'hi';
                  $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
            
                  $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                    //this month count 
                    
                  $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->count();
                    
                    $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                     ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_payment.transaction_date', $prevYear)
                    ->whereMonth('et_payment.transaction_date', $prevMonth)
                    ->where('et_transaction.payment_status', 1)
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();    
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
                    // $dropoutCustomers = DB::table('et_training')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 2)
                    //     ->pluck('customer_id')
                    //     ->toArray();

                       // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->select('et_payment.customer_id')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->groupBy('et_payment.customer_id')
                        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
                        ->pluck('et_payment.customer_id')
                        ->toArray();
                    // return $fullPaidCustomerIds;
                    // 2. Customers who made a second payment this month
                    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();
                        //  return $secondPaymentCustomersmulti;
                    
                  
                    $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));

                    // second condition  
                    // $secondPaymentCustomers = DB::table('et_payment')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 1)
                    //     ->whereMonth('nextPayDate', $month)
                    //     ->whereYear('nextPayDate', $year)
                    //     ->pluck('customer_id')
                    //     ->unique()
                    //     ->values() // this reindexes!
                    //     ->toArray();
                        // return $secondPaymentCustomers;
                    // third condition  
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                
                    //  $drop_ids = DB::table('et_drop_refund')
                    //       ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                    //       ->where('et_drop_refund.bh_status', 1)
                    //       ->pluck('et_training.customer_id');
                          
                    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIds = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIds,
                            array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
                        ));
                        // return count($badCustomerIds);
                        $second_pay_check = $incentive ? $incentive->second_payment_check : 0;
                        if($second_pay_check == 1){
                            $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                        }else{
                            $customerConvertCount = max(0,$customerConvertCountthismonth);
                        }
                      
                    // return $customerConvertCount;
                  $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
            
            
                  // customer ratio
                  $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                  $convertion_rate = number_format($convertion_rate, 2);
            
                  //acr
                  $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                  $averager_convertion_rate = number_format($averager_convertion_rate, 2);
            
                    
               
                    $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                    
                    $si_slabs = ($incentive && $incentive->si_incentive_json)
                                ? json_decode($incentive->si_incentive_json, true)
                                : [];
                    $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            
                  $currentMonthCustomerCount = 0;
                  $total_business_amount     = 0;
                  $total_payment             = 0;
                  $total_paid_payment        = 0;
                  $averageBusinessValue      = 0;
                  $averageCollectionValue    = 0;
                  $crashCount = 0;
                  $professionCount = 0;
                  $tesboCount = 0;
                  $courseTypeTotal = 0;
                  $eciCustomerConvertCount = 0;
                  $eciActualPercentage = 0;
                  $eciTargetPercentage = $incentive->eci_count ?? 0;
                  $eciStatus = false;
                  
               
                
                   $targetConversion = $goalsetData[$staff->staff_id]->conversion ?? 0;
                    $targetABV             = $goalsetData[$staff->staff_id]->ABV ?? 0;
                    $targetACV             = $goalsetData[$staff->staff_id]->ACV ?? 0;
                    $crashTarget =0;
                    $professionTarget =0;
                    $tesboTarget =0;
                    $crashPercent =0;
                    $professionPercent=0;
                    $tesboPercent=0;
                    $piPercentage = 0;
                    $originalAmount = 0;
                    $piReward = 0;
                    $slabPercentageSI = 0; 
                    $siPercentage=0;
                    $originalAmountSI = 0;
                    $matchedSlab = null;
                    $slabPercentage = 0;  
                    $piReward  =0;
                    $siCollectionValue=0;
                    $matchedSlabSI = null;
                    $siReward = 0;
                    $slabMin = 0;
                    $slabMax = null;
                    $matchedSlabPI = null;
                    $piRewardPercent = 0;
                     $piRewardAmount = 0;
                 
                 
                    if ($customerConvertCount > 0) {
                   
                      
                      $currentMonthCustomer = DB::table('et_customer')->select(
                                'et_customer.sno',
                                'et_customer.proposal_ids',
                                'et_payment.transaction_date',
                                'et_customer.cus_mobile',
                                'et_proposal.sno as proposal_id',
                                'et_proposal.service_title',
                                'et_proposal.currency_id',
                                'et_proposal.grant_total_amount',
                                'et_country_currencies.currency_symbol',
                                'et_country_currencies.currency_code',
                                'et_transaction.total_amount_inr',
                                'et_payment.paid_amount',
                                )
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                     ->whereRaw('et_payment.transaction_date = (
                                         SELECT MIN(ep.transaction_date)
                                         FROM et_payment ep
                                         WHERE ep.customer_id = et_customer.sno
                                     )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->orderBy('et_customer.sno', 'asc')
                            ->get();
                      
                      
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                     $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                 ->whereRaw('et_payment.sno = (
                                     SELECT ep.sno
                                     FROM et_payment ep
                                     WHERE ep.customer_id = et_customer.sno
                                     ORDER BY ep.transaction_date ASC, ep.sno ASC
                                     LIMIT 1
                                 )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_lead.created_by', $staff->staff_id)
                         ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereDay('et_payment.transaction_date', '<=', 15)
                        ->count();
                        
                        // return $customerConvertCount;
                        // spot incentive 
                        if($incentive){
                            $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $customerConvertCountthismonth) * 100 : 0;
                            $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $customerConvertCountthismonth) * 100 : 0;
                            $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $customerConvertCountthismonth) * 100 : 0;
                            $crashTarget = $incentive->si_crash_course ?? 0;
                            $professionTarget = $incentive->si_profession_course ?? 0;
                            $tesboTarget = $incentive->si_tesbo_course ?? 0;
                            
                        }else{
                            $crashPercent =  0;
                            $professionPercent =  0;
                            $tesboPercent =  0;
                            $crashTarget =  0;
                            $professionTarget = 0;
                            $tesboTarget =  0;
                        }
                        
                        
                        
                        
                        //  return $piReward;
                        //    return $currentMonthCustomer;
                      
                        $base_amount_paid=0;
                         $gst_percent = 18;
                        if ($currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {

                                    $grantAmount = $customer->grant_total_amount;
                        
                                    // First remove GST from paidAmount (base value in proposal's currency)
                                    $basePaidLocal = $customer->paid_amount / (1 + ($gst_percent / 100));
                        
                                    if ($customer->currency_id == 70) {
                                        // INR: add directly
                                        $total_paid_payment += $customer->paid_amount;
                                        $total_payment += $grantAmount;
                                        $base_amount_paid += $basePaidLocal;
                                    } else {
                                        if($customer->total_amount_inr > 0){
                                            $currency_code = $customer->currency_code;
                                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                            $total_paid_payment += $customer->total_amount_inr;
                                            $base_amount_paid += $customer->total_amount_inr / (1 + ($gst_percent / 100));

                                        }else{
                                            $currency_code = $customer->currency_code;
                                            $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $customer->paid_amount);
                                            $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                            $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                        }
                                        
                                    }
                                
                            }
                        }
                
                        // return $total_paid_payment;
                        // average 
                        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        $siCollectionValue = $averageCollectionValue;
                        
                       
                        foreach ($si_slabs as $slab) {
                            $min = $slab['min'];
                            $max = $slab['max'];

                            if (
                                $siCollectionValue >= $min &&
                                ($max === null || $siCollectionValue <= $max)
                            ) {
                                $matchedSlabSI = $min . ' - ' . ($max ?? 'Above');
                                $siReward = $slab['reward'];
                                $slabMin = $min;
                                $slabMax = $max;
                                break;
                            }
                        }

                        $siStatus = $siReward > 0;

                        // $proposalIds = DB::table('et_customer')
                        //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        //         ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        //         ->join('et_payment', function($join) {
                        //             $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                        //                 ->whereRaw('et_payment.transaction_date = (
                        //                     SELECT MIN(ep.transaction_date)
                        //                     FROM et_payment ep
                        //                     WHERE ep.proposal_id = et_proposal.sno
                        //                 )');
                        //         })
                        //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        //         ->where('et_customer.status', 0)
                        //         ->where('et_proposal.post_sale_check', 0)
                        //         ->where('et_customer.branch_id', $branchId)
                        //         ->where('et_proposal.created_by', $staff->staff_id)
                        //         ->whereYear('et_payment.transaction_date', $year)
                        //         ->whereMonth('et_payment.transaction_date', $month)
                        //         ->where('et_transaction.payment_status', 1)
                        //         ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        //         ->where('et_proposal.status',0)
                        //         ->orderBy('et_proposal.sno', 'asc')
                        //         ->pluck('et_proposal.sno');
                            
                        //     $productProfit = DB::table('et_proposal_product_cart')
                        //         ->whereIn('proposal_sno', $proposalIds)
                        //         ->selectRaw('SUM(GREATEST(product_amount - original_amount,0)) as profit')
                        //         ->value('profit') ?? 0;

                        //     $packageProfit = DB::table('et_proposal_package_cart')
                        //         ->whereIn('proposal_sno', $proposalIds)
                        //         ->selectRaw('SUM(GREATEST(cust_product_amount - original_product_amount,0)) as profit')
                        //         ->value('profit') ?? 0;

                        //     $totalProfit = $productProfit + $packageProfit;

                        //     return $totalProfit ;

                        //     $totalPaymentIds = DB::table('et_payment')
                        //     ->whereIn('proposal_id', $proposalIds)
                        //     ->pluck('sno');

                           

                        //     $gst_percent = 18;

                        //     $totalCollectionWithGST = DB::table('et_transaction')
                        //         ->whereIn('payment_id', $totalPaymentIds)
                        //         ->where('payment_status', 1)
                        //         ->sum('total_amount_inr');

                        //     // Remove GST to get NET collection
                        //     $totalCollection = $totalCollectionWithGST / (1 + ($gst_percent / 100));

                          
                        //     $profitPercentage = 0;
                        //     if ($totalCollection > 0) {
                        //         $profitPercentage = ($totalProfit / $totalCollection) * 100;
                        //     }
                          

                        //     foreach ($pi_slabs as $slab) {

                        //         $min = (float)$slab['min'];
                        //         $max = (float)$slab['max'];

                        //         if ($profitPercentage >= $min && $profitPercentage <= $max) {
                        //             $matchedSlabPI = $min . '% - ' . $max . '%';
                        //             $piRewardPercent = (float)$slab['percentage'];
                        //             break;
                        //         }
                        //     }

                           

                        //     if ($piRewardPercent > 0) {
                        //         $piRewardAmount = ($totalProfit * $piRewardPercent) / 100;
                        //     }

                        // Step 1: Get proposal IDs for the month and staff
                        $proposalIds = DB::table('et_customer')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                    ->whereRaw('et_payment.transaction_date = (
                                        SELECT MIN(ep.transaction_date)
                                        FROM et_payment ep
                                        WHERE ep.proposal_id = et_proposal.sno
                                    )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_proposal.post_sale_check', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_proposal.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                            ->where('et_proposal.status',0)
                            ->pluck('et_proposal.sno');

                        // Step 2: Get all payment IDs for these proposals
                        $totalPaymentIds = DB::table('et_payment')
                            ->whereIn('proposal_id', $proposalIds)
                            ->pluck('sno');


                        $proposalData = DB::table('et_proposal')
                            ->leftJoin('et_proposal_product_cart as ppc', 'ppc.proposal_sno', '=', 'et_proposal.sno')
                            ->leftJoin('et_proposal_package_cart as pkg', 'pkg.proposal_sno', '=', 'et_proposal.sno')
                            ->whereIn('et_proposal.sno', $proposalIds)
                            ->groupBy('et_proposal.sno')
                            ->select(
                                'et_proposal.sno as proposal_id',
                                DB::raw('SUM(ppc.original_amount) as product_original'),
                                DB::raw('SUM(pkg.original_product_amount) as package_original'),
                                DB::raw('SUM(ppc.product_amount) as product_custom'),
                                DB::raw('SUM(pkg.cust_product_amount) as package_custom')
                            )
                            ->get();

                            $collections = DB::table('et_transaction')
                            ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->whereIn('et_payment.proposal_id', $proposalIds)
                            ->where('et_transaction.payment_status', 1)
                            ->groupBy('et_payment.proposal_id')
                            ->select(
                                'et_payment.proposal_id',
                                DB::raw('SUM(et_transaction.total_amount_inr) as total_inr')
                            )
                            ->pluck('total_inr', 'proposal_id');

                        $gst_percent = 18;

                        $totalProfitNet = 0;
                        $totalCollectionNet = 0;

                        foreach ($proposalData as $row) {

                            $proposalId = $row->proposal_id;

                            $original = ($row->product_original ?? 0) + ($row->package_original ?? 0);
                            $custom   = ($row->product_custom ?? 0) + ($row->package_custom ?? 0);

                            // ✅ Only eligible proposals
                            if ($custom > $original) {

                                $collectionINR = $collections[$proposalId] ?? 0;

                                if ($collectionINR > 0 && $custom > 0) {

                                    // ✅ Conversion ratio from proposal currency → INR
                                    $conversionRate = $collectionINR / $custom;

                                    // ✅ Profit in INR
                                    $profitINR = ($custom - $original) * $conversionRate;

                                    // ✅ Remove GST
                                    $profitNet = $profitINR / (1 + ($gst_percent / 100));
                                    $collectionNet = $collectionINR / (1 + ($gst_percent / 100));

                                    $totalProfitNet += $profitNet;
                                    $totalCollectionNet += $collectionNet;
                                }
                            }
                        }

                       
                        $profitPercentage = 0;

                        if ($totalCollectionNet > 0) {
                            $profitPercentage = ($totalProfitNet / $totalCollectionNet) * 100;
                        }

                        $piRewardPercent = 0;
                        $matchedSlabPI = '';

                        foreach ($pi_slabs as $slab) {
                            $min = (float)$slab['min'];
                            $max = (float)$slab['max'];

                            if ($profitPercentage >= $min && $profitPercentage <= $max) {
                                $matchedSlabPI = $min . '% - ' . $max . '%';
                                $piRewardPercent = (float)$slab['percentage'];
                                break;
                            }
                        }

                        $piRewardAmount = ($totalProfitNet * $piRewardPercent) / 100;
                        // $gst_percent = 18;
             
                        // $base_amount_paid = $total_paid_payment / (1 + ($gst_percent / 100));
                        
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        // $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $totalAllPayment +=$total_payment;
                        // $totalAllPaidPayment +=$base_amount_paid;
                         // ECI Logic
                     
                        $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                        $eciActualPercentage = number_format($eciActualPercentage, 2);
                        $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
            
                        // average 
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                        // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                
                        // $totalAllPayment += $total_payment;
                        // $totalAllPaidPayment += $total_paid_payment;
                    }
                  
                    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                

                    foreach ($allConverted as $row) {
                      
                      $mobile = $row->lead_mobile;
                        // Get the latest call
                         $lastCall = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->first();
                    
                            
                        $totalCallCount = DB::table('et_call_tracker')->select('sno')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->count();
                        // Attach values to row
                        $row->call_created_at = $lastCall->call_start_date ?? null;
                        $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                        $row->call_count = $totalCallCount;
                    }
        
                    
                        
                        // return $allConverted;
                        
                    $convertedToday = 0;
                    $convertedMonth = 0;
                    $convertedOldMonth = 0;
                $customerDetails=[];
                    foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                            // include call count
                        // if ($customerDate ===  $leadDate && $call_count ===  1) {
                        //     $convertedToday++;
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     $leadDate >= $startOfMonth && $leadDate <= $dates &&
                        //     $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //         $callDate = Carbon::parse($call->call_start_date);
                        //         return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        //     })
                            
                        // ) {
                        //     $convertedMonth++;
                        //     $customerMobiles[] = $mobile; 
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     ($leadDate < $startOfMonth || $leadDate > $dates)
                        // ) {
                        //     $convertedOldMonth++;
                        // }
                        $customerData = [
                            'customerDate' => $customerDate,
                            'leadDate'     => $leadDate,
                            'mobile'       => $mobile
                        ];
                        if ($customerDate ===  $leadDate) {
                            $convertedToday++;
                            //   $customerDetails[] = $customerData; 
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates
                        ) {
                            $convertedMonth++;
                           
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                    // return $customerDetails;
                    // return $convertedToday;
                    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                    // Old month = always 0
                    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                  
                    // 10x award calculation       
                    $actualConversion      = $customerConvertCount;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;
                   
                    //   $tenxStatus = (
                    //         $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    //         $actualConversion >= $targetConversion &&
                    //         $actualABV >= $targetABV &&
                    //         $actualACV >= $targetACV
                    //     );
                     $tenxStatus = (
                        $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                        $actualConversion >= $targetConversion 
                    );
                   // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                    
                    $biReward = $biAchievedCount * $biPerConversion;
                    $biStatus = $biAchievedCount > 0;
                    
                     //   for promance incentive
                  $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                  $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;
                  
                  $actualOutgoingCallCount=0;
                  $actualMissedCallRate=0;
                  $actualMissedCount=0;
                  
                //   $actualCallCount = DB::table('et_call_tracker')
                //     ->selectRaw('
                //         COUNT(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count, 
                //         COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count, 
                //         COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) AS missedcall_count,
                //         COUNT(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count,
                //         COUNT(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count
                //     ')
                //     ->whereYear('call_start_date', $year)
                //     ->whereMonth('call_start_date', $month)
                //     ->where('et_call_tracker.branch_id', $branchId)
                //     ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                //     ->first();

                $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  
                   $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                   $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                  
                  $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                  $actualOutgoingPerDay=round($actualOutgoingPerDay);
                  
                  // Missed call ratio
                    $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count + $actualCallCount->rejected_call_count;
                    $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                    $actualMissedCallRate=round($actualMissedCallRate,1);
                    
                    
                  
                  $performIncentStatus = (
                        $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                        $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                    );
                  
                  
                  
                  
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $customerConvertCountthismonth . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" 
                                                      >
                                                    ' . $actualConversion . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            'eci' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $eciStatus,
                                'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($targetConversion . ' - ' . $actualConversion . ' = (' . $biAchievedCount . ')') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($biAchievedCount . ' × ' . $biPerConversion) . 
                                            '</span>',
                                'status' => $tenxStatus && $biStatus,
                                'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                            ],
                        
                            'si' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                             ($matchedSlabSI ? $matchedSlabSI : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                              '₹' . number_format($siCollectionValue) . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openSIDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $siStatus,
                                'reward' => ($tenxStatus && $siStatus) ? $siReward : 0,
                            ],
                        
                           'pi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlabPI ? $matchedSlabPI : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piRewardPercent, 1) . '% — ₹' . number_format($piRewardAmount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPIActualCalculationModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $piRewardAmount > 0,
                                'reward' => ($tenxStatus && $piRewardAmount > 0)
                                    ? (($piRewardAmount >= 0 ? '+' : '-') . round(abs($piRewardAmount)))
                                    : 0,
                            ],
                        
                           'sp' => [
                                'target' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . '</span>
                                            </td>
                                        </tr>
                                    </table>
                                ',
                            
                                'actual' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openManageCallModal(' . $staff->staff_id . ')" >Details</span>
                                            </td>
                                        </tr>
                                        
                                    </table>
                                ',
                                'status' => $tenxStatus && $spotTotalReward > 0,
                                'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
                            ],
                            'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Missed Call Rate">' . $targetMissedCallRate . '%</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Outgoing Call Count Per day">' . $targetOutgoingCallCount . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info"  data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Missed Call Rate"
                                                      >
                                                    ' . $actualMissedCallRate . '%
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Outgoing Call Count Per day"
                                                      >
                                                    ' . $actualOutgoingPerDay . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformCallModal(' . $staff->staff_id . ')" >Details</span>
                                             ',
                                
                                'status' => $tenxStatus && $performIncentStatus,
                                'reward' => ($tenxStatus && $performIncentStatus) ? ($incentive->$performIncentStatus ?? 0) : 0,
                            ],
        
                        
                           'li' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) 
                                                ? 'Achieved' 
                                                : 'Not Achieved') . 
                                            '</span>',
                                'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
                                'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward)
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ]
        
                    ];
            
            } 
                
            if ($isPostSalesEx) {
                 
                  
                  //Sales Team 
                  //   return 'hi';
                  $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
            
                  $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                    //this month count 

                    $customerConvertCountthismonth = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->staff_id)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                         ->count();
                    
                    $prevMonthConvertedCustomers = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->staff_id)
                        ->whereYear('et_payment.transaction_date', $prevYear)
                        ->whereMonth('et_payment.transaction_date', $prevMonth)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->pluck('et_customer.sno')
                        ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
                    // $dropoutCustomers = DB::table('et_training')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 2)
                    //     ->pluck('customer_id')
                    //     ->toArray();
                       // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->select('et_payment.customer_id')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->groupBy('et_payment.customer_id')
                        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
                        ->pluck('et_payment.customer_id')
                        ->toArray();
                    // return $fullPaidCustomerIds;
                    // 2. Customers who made a second payment this month
                    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();
                        //  return $secondPaymentCustomersmulti;
                    
                  
                    $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));

                    // second condition  
                    // $secondPaymentCustomers = DB::table('et_payment')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 1)
                    //     ->whereMonth('nextPayDate', $month)
                    //     ->whereYear('nextPayDate', $year)
                    //     ->pluck('customer_id')
                    //     ->unique()
                    //     ->values() // this reindexes!
                    //     ->toArray();
                        // return $secondPaymentCustomers;
                    // third condition  
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                
                    //  $drop_ids = DB::table('et_drop_refund')
                    //       ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                    //       ->where('et_drop_refund.bh_status', 1)
                    //       ->pluck('et_training.customer_id');
                          
                    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIds = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIds,
                            array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
                        ));
                        $second_pay_check = $incentive ? $incentive->second_payment_check : 0;
                        if($second_pay_check == 1){
                            $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                        }else{
                            $customerConvertCount = max(0,$customerConvertCountthismonth);
                        }
                      
                    // return $customerConvertCount;
                  $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
            
            
                  // customer ratio
                  $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                  $convertion_rate = number_format($convertion_rate, 2);
            
                  //acr
                  $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                  $averager_convertion_rate = number_format($averager_convertion_rate, 2);
            
                    
               
                    $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                    
                    $si_slabs = ($incentive && $incentive->si_slab_json) ? json_decode($incentive->si_slab_json, true) : [];
                    $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            
                  $currentMonthCustomerCount = 0;
                  $total_business_amount     = 0;
                  $total_payment             = 0;
                  $total_paid_payment        = 0;
                  $averageBusinessValue      = 0;
                  $averageCollectionValue    = 0;
                  $crashCount = 0;
                  $professionCount = 0;
                  $tesboCount = 0;
                  $courseTypeTotal = 0;
                  $eciCustomerConvertCount = 0;
                  $eciActualPercentage = 0;
                  $eciTargetPercentage = $incentive->eci_count ?? 0;
                  $eciStatus = false;
                  
               
                
                   $targetConversion = $goalsetData[$staff->staff_id]->conversion ?? 0;
                    $targetABV             = $goalsetData[$staff->staff_id]->ABV ?? 0;
                    $targetACV             = $goalsetData[$staff->staff_id]->ACV ?? 0;
                    $crashTarget =0;
                    $professionTarget =0;
                    $tesboTarget =0;
                    $crashPercent =0;
                    $professionPercent=0;
                    $tesboPercent=0;
                    $piPercentage = 0;
                    $originalAmount = 0;
                    $piReward = 0;
                    $matchedSlabSI = null;
                    $slabPercentageSI = 0; 
                    $siPercentage=0;
                    $originalAmountSI = 0;
                    $siReward = 0;
                    $matchedSlab = null;
                    $slabPercentage = 0; 
                   // Total Professional and Crash courses
                
                    
                    // Prepare tree output
                    $crash_coures_total = 0;
                    $professinal_coures_total = 0;
                    $teshobo_coures_total = 0;
                    $siStatus = false;
                    // foreach ($groupedData as $row) {
                    //     if ($row->course_type_id == 3) {
                    //         $professinal_coures_total = (int) $row->total_trainings;
                    //     } elseif ($row->course_type_id == 4) {
                    //         $crash_coures_total = (int) $row->total_trainings;
                    //     }
                    // }
                 
                     // return $crash_coures_total;
                     $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
                 
                    if ($customerConvertCount > 0) {
                   
                      
                      $currentMonthCustomer = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                     ->whereRaw('et_payment.transaction_date = (
                                         SELECT MIN(ep.transaction_date)
                                         FROM et_payment ep
                                         WHERE ep.customer_id = et_customer.sno
                                     )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->orderBy('et_customer.sno', 'asc')
                            ->get();
                      

                            $eciCustomerConvertCount = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.post_sale_check', 1)
                                ->where('et_proposal.post_sale_check', 1)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_proposal.created_by', $staff->staff_id)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                                ->where('et_proposal.status',0)
                                ->orderBy('et_proposal.sno', 'asc')
                                ->whereDay('et_payment.transaction_date', '<=', 15)
                                ->count();
                     
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                    //  $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    //     ->join('et_payment', function($join) {
                    //         $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    //              ->whereRaw('et_payment.sno = (
                    //                  SELECT ep.sno
                    //                  FROM et_payment ep
                    //                  WHERE ep.customer_id = et_customer.sno
                    //                  ORDER BY ep.transaction_date ASC, ep.sno ASC
                    //                  LIMIT 1
                    //              )');
                    //     })
                    //     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    //     ->where('et_customer.branch_id', $branchId)
                    //     ->whereIn('et_customer.status', [0, 6])
                    //     ->where('et_lead.created_by', $staff->staff_id)
                    //      ->whereYear('et_payment.transaction_date', $year)
                    //     ->whereMonth('et_payment.transaction_date', $month)
                    //     ->where('et_transaction.payment_status', 1)
                    //     ->whereDay('et_payment.transaction_date', '<=', 15)
                    //     ->count();
                        
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            // foreach ($currentMonthCustomer as $customer) {
                        
                            //     // First: check if this customer has TESBO training
                            //     $hasTesbo = DB::table('et_training')
                            //         ->where('customer_id', $customer->sno)
                            //         ->where('branch_id', $branchId)
                            //         ->whereMonth('created_at', $month)
                            //         ->whereYear('created_at', $year)
                            //         ->where('tesbo_check', 2)
                            //         ->where('post_sale_check', '!=', 1)
                            //         ->exists();
                        
                            //     if ($hasTesbo) {
                            //         $tesboCount++;
                            //         continue; // skip crash/professional check if TESBO already counted
                            //     }
                        
                            //     // Then: check if customer has valid Professional or Crash training (not tesbo)
                            //     $nonTesboTrainings = DB::table('et_training')
                            //         ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                            //         ->where('et_training.customer_id', $customer->sno)
                            //         ->where('et_training.branch_id', $branchId)
                            //         ->whereMonth('et_training.created_at', $month)
                            //         ->whereYear('et_training.created_at', $year)
                            //         ->where('et_training.post_sale_check', '!=', 1)
                            //         ->where('et_training.tesbo_check', '!=', 2)
                            //         ->whereIn('et_course.course_type_id', [3, 4])
                            //         ->select('et_course.course_type_id')
                            //         ->get();
                        
                            //     $hasCrash = false;
                            //     $hasProfession = false;
                        
                            //     foreach ($nonTesboTrainings as $training) {
                            //         if ($training->course_type_id == 3) {
                            //             $hasProfession = true;
                            //         } elseif ($training->course_type_id == 4) {
                            //             $hasCrash = true;
                            //         }
                            //     }
                        
                            //     if ($hasCrash) $crashCount++;
                            //     if ($hasProfession) $professionCount++;
                            // }
                        
                            // $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                            $courseTypeTotal = 0;
                        }
                        // return $customerConvertCount;
                        // spot incentive 
                        if($incentive){
                            $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $customerConvertCountthismonth) * 100 : 0;
                            $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $customerConvertCountthismonth) * 100 : 0;
                            $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $customerConvertCountthismonth) * 100 : 0;
                            $crashTarget = $incentive->si_crash_course ?? 0;
                            $professionTarget = $incentive->si_profession_course ?? 0;
                            $tesboTarget = $incentive->si_tesbo_course ?? 0;
                            
                        }else{
                            $crashPercent =  0;
                            $professionPercent =  0;
                            $tesboPercent =  0;
                            $crashTarget =  0;
                            $professionTarget = 0;
                            $tesboTarget =  0;
                        }
                        
                        
                        // $crashPercent = $crashCount;
                        // $professionPercent = $professionCount;
                        // $tesboPercent = $tesboCount;
                        
                       
                        
                        // only condition: Crash must be ≤ targe
                           
                          
                          if ( $customerConvertCountthismonth  >= 20){
                              $siStatus = true;
                            // return $customerConvertCountthismonth;
                            if ($incentive->si_crash_course > 0) {
                                
                                // $siStatus = $siStatus && ($crashPercent >= $crashTarget);
                                $siStatus = $siStatus && (($crashPercent >= $crashTarget) || ($crashPercent <= $crashTarget) );
                            }
                            
                            if ($incentive->si_profession_course > 0) {
                                
                                $siStatus = $siStatus && ($professionPercent >= $professionTarget);
                            }
                            
                            if ($incentive->si_tesbo_course > 0) {
                                // return $siStatus;
                                $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
                            }
                          }else{
                              $siStatus = false;
                          }
                        //  return $currentMonthCustomer;
                        // return 'not coming good';
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                              
                                 $trainings = DB::table('et_proposal as t1')
                                        ->join(DB::raw('(
                                            SELECT MIN(sno) as min_sno
                                            FROM et_proposal
                                            WHERE post_sale_check = 0
                                            GROUP BY customer_id
                                        ) as t2'), 't1.sno', '=', 't2.min_sno')
                                        ->where('t1.customer_id', $customer->sno)
                                        ->select('t1.sno', 't1.customer_id',    't1.total_amount')
                                        ->get();
                            
                                    foreach ($trainings as $training) {
                                         // Determine course_id based on tesbo_check
                                        $course_id = null;
                                
                                        if (!$course_id) continue; // Skip if no course_id
                                
                                        $course = ManageCoursesModel::where('sno', $course_id)
                                            ->whereIn('course_type_id', [2, 3])
                                            ->first();
                                
                                        if (!$course) continue;
                                    $basePrice = $course->course_min_price;
                                    $soldPrice = $training->overall_fees;
                                    $profitAmount = $soldPrice - $basePrice;
                                    
                                    // if ($profitAmount > 0) {
                                        
                                       $originalAmount += $profitAmount; 
        
                                       $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                                      // return $pi_slabs;
                                        // Match against PI slabs
                                        foreach ($pi_slabs as $slab) {
                                            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                                $slabPercentage = $slab['percentage'];
                                                $rewardFromThis = ($originalAmount * $slabPercentage) / 100;
                        
                                                $piRewards = $rewardFromThis > 0 ? $rewardFromThis : 0;
                                                $piPercentage = $profitPercent;
                                                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                                break; // first matching slab
                                            }
                                        }
                                    // }
                                }
                            }
                        }
                         $piReward0 = $slabPercentage >0 ? ($originalAmount * $slabPercentage) / 100 : 0;
                         $piReward  = $piReward0 > 0 ?$piReward0 :0;
                        //  return $piReward;
                         //   return $rewardFromThisd;
                        // if ($currentMonthCustomer->isNotEmpty()) {
                        //   foreach ($currentMonthCustomer as $customer) {
                
                        //     // $payment = DB::table('et_proposal')->select('et_proposal.sno', 'et_proposal.customer_id')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     // //   ->where('et_training.tesbo_check', 0)
                        //     //   ->sum('et_proposal.total_amount');
                
                        //     // $total_payment += $payment;
                        //     $proposal_ids=json_decode($customer->proposal_ids);
                        //     $total_payment_grant = DB::table('et_proposal')
                        //     ->whereIn('sno', $proposal_ids)
                        //     ->where('status', 0) 
                        //     ->sum('grant_total_amount');
                       
                        //         $total_payment += $total_payment_grant;
                
                
                            
                            
                            
                        //     $total_paid_payment_slot = DB::table('et_proposal_pay_slot')
                        //                   ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
                        //                   ->where('status', 0)
                        //                   ->sum('paidAmount');
                
                        //     // $paid_payment = DB::table('et_proposal')->select( 'et_proposal.sno', 'et_proposal.customer_id')
                        //     // ->join('et_proposal_pay_slot','et_proposal.sno','=','et_proposal_pay_slot.proposal_sno')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     //   ->sum('et_proposal_pay_slot.paidAmount');
                
                        //     $total_paid_payment += $total_paid_payment_slot;
                            
                             
                            
                        //   }
                                
                        // }
                        $base_amount_paid=0;
                         $gst_percent = 18;
                        if ($currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                                $proposal_ids = DB::table('et_proposal')
                                    ->where('et_proposal.customer_id', $customer->sno)
                                    ->where('et_proposal.status', 0)
                                    ->whereNot('et_proposal.post_sale_check', 1)
                                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                    ->pluck('sno')
                                    ->toArray();
                                    // return $proposal_ids;
                        
                                $proposals = DB::table('et_proposal')
                                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                    ->whereIn('et_proposal.sno', $proposal_ids)
                                    ->get();
                        
                                foreach ($proposals as $proposal) {
                                    // Paid slots for this proposal
                                    $paidAmount = DB::table('et_proposal_pay_slot')
                                        ->where('proposal_sno', $proposal->sno)
                                        ->where('status', 0)
                                        ->sum('paidAmount');
                        
                                    $grantAmount = $proposal->grant_total_amount;
                        
                                    // First remove GST from paidAmount (base value in proposal's currency)
                                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                        
                                    if ($proposal->currency_id == 70) {
                                        // INR: add directly
                                        $total_paid_payment += $paidAmount;
                                        $total_payment += $grantAmount;
                                        $base_amount_paid += $basePaidLocal;
                                    } else {
                                        // Non-INR: convert both amounts and base value
                                        $currency_code = $proposal->currency_code;
                                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                    }
                                }
                            }
                        }
                
                
                        // average 
                        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $gst_percent = 18;
             
                        // $base_amount_paid = $total_paid_payment / (1 + ($gst_percent / 100));
                        
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        // $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $totalAllPayment +=$total_payment;
                        // $totalAllPaidPayment +=$base_amount_paid;
                         // ECI Logic
                     
                        $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                        // $eciActualPercentage = $customerConvertCountthismonth > 0 ? ($eciCustomerConvertCount / $customerConvertCountthismonth) * 100 : 0;
                        $eciActualPercentage = number_format($eciActualPercentage, 2);
                        $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
            
                        // average 
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                        // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                
                        // $totalAllPayment += $total_payment;
                        // $totalAllPaidPayment += $total_paid_payment;
                    }
                  
                    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                

                    foreach ($allConverted as $row) {
                      
                      $mobile = $row->lead_mobile;
                        // Get the latest call
                         $lastCall = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->first();
                    
                            
                        $totalCallCount = DB::table('et_call_tracker')->select('sno')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->count();
                        // Attach values to row
                        $row->call_created_at = $lastCall->call_start_date ?? null;
                        $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                        $row->call_count = $totalCallCount;
                    }
        
                    
                        
                        // return $allConverted;
                        
                    $convertedToday = 0;
                    $convertedMonth = 0;
                    $convertedOldMonth = 0;
                $customerDetails=[];
                    foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                            // include call count
                        // if ($customerDate ===  $leadDate && $call_count ===  1) {
                        //     $convertedToday++;
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     $leadDate >= $startOfMonth && $leadDate <= $dates &&
                        //     $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //         $callDate = Carbon::parse($call->call_start_date);
                        //         return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        //     })
                            
                        // ) {
                        //     $convertedMonth++;
                        //     $customerMobiles[] = $mobile; 
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     ($leadDate < $startOfMonth || $leadDate > $dates)
                        // ) {
                        //     $convertedOldMonth++;
                        // }
                        $customerData = [
                            'customerDate' => $customerDate,
                            'leadDate'     => $leadDate,
                            'mobile'       => $mobile
                        ];
                        if ($customerDate ===  $leadDate) {
                            $convertedToday++;
                            //   $customerDetails[] = $customerData; 
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates
                        ) {
                            $convertedMonth++;
                           
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                    // return $customerDetails;
                    // return $convertedToday;
                    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                    // Old month = always 0
                    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                  
                    // 10x award calculation       
                    $actualConversion      = $customerConvertCount;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;
                   
                    //   $tenxStatus = (
                    //         $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    //         $actualConversion >= $targetConversion &&
                    //         $actualABV >= $targetABV &&
                    //         $actualACV >= $targetACV
                    //     );
                     $tenxStatus = (
                        $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                        $actualConversion >= $targetConversion 
                    );
                   // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                    
                    $biReward = $biAchievedCount * $biPerConversion;
                    $biStatus = $biAchievedCount > 0;
                    
                     //   for promance incentive
                  $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                  $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;
                  
                  $actualOutgoingCallCount=0;
                  $actualMissedCallRate=0;
                  $actualMissedCount=0;
                  
                  $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                // $actualCallCount = DB::table('et_call_tracker')
                //     ->selectRaw('
                //         COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                //         COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                //         COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                //         COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                //         COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                //     ')
                //     ->where('branch_id', $branchId)
                //     ->where('branch_staff_id', $staff->staff_id)
                //     ->where('call_start_date', '>=', "$year-$month-01")
                //     ->where('call_start_date', '<', Carbon::create($year, $month)->addMonth()->format('Y-m-d'))
                //     ->first();

                //   return $actualCallCount;
                   $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                   $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                  
                  $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                  $actualOutgoingPerDay=round($actualOutgoingPerDay);
                  
                  // Missed call ratio
                    $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count ;
                    $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                    $actualMissedCallRate=round($actualMissedCallRate,1);
                    
                    
                  
                  $performIncentStatus = (
                        $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                        $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                    );

                    // return $performIncentStatus;
                  
                  
                  
                  
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $customerConvertCountthismonth . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" 
                                                      >
                                                    ' . $actualConversion . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            'eci' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $eciStatus,
                                'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($targetConversion . ' - ' . $actualConversion . ' = (' . $biAchievedCount . ')') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($biAchievedCount . ' × ' . $biPerConversion) . 
                                            '</span>',
                                'status' => $tenxStatus && $biStatus,
                                'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                            ],
                        
                           'pi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $piReward > 0,
                                'reward' => ($tenxStatus && $piReward > 0)
                                    ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                    : 0,
                            ],
                        
                            'si' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlabSI ? $matchedSlabSI . ' = ' . round($slabPercentageSI, 2) . '%' : 'No Matching Slab')  . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                             round($siPercentage, 2) . '% — ₹' . number_format($originalAmountSI) . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $siStatus,
                                'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                            ],
                        
                            'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Missed Call Rate">' . $targetMissedCallRate . '%</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Outgoing Call Count Per day">' . $targetOutgoingCallCount . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info"  data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Missed Call Rate"
                                                      >
                                                    ' . $actualMissedCallRate . '%
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Outgoing Call Count Per day"
                                                      >
                                                    ' . $actualOutgoingPerDay . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformCallModal(' . $staff->staff_id . ')" >Details</span>
                                             ',
                                
                                'status' => $tenxStatus && $performIncentStatus,
                                'reward' => ($tenxStatus && $performIncentStatus) ? ($incentive->$performIncentStatus ?? 0) : 0,
                            ],
        
                        
                           'li' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) 
                                                ? 'Achieved' 
                                                : 'Not Achieved') . 
                                            '</span>',
                                'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
                                'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward)
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ]
        
                    ];
            
            } 
           
           
            
            if ($isCollection) {
                
                 $refferal_count = DB::table('et_referral_persons')
                      ->where('branch_id', $branchId)
                      ->where('referral_id', $staff->staff_id)
                      ->where('status', 0)
                      ->where('referral_type', 2)
                      ->whereYear('created_at', $year)
                      ->whereMonth('created_at', $month)
                      ->count();
                $dropoutCustomers = DB::table('et_training')
                        ->where('status', 2)
                        ->pluck('customer_id')
                        ->toArray();
                       
                $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_customer.sno', $dropoutCustomers) 
                    ->whereBetween('et_customer.created_at', [$startDateold, $endDateold])
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
               
            
                // here $secondPaymentCustomers  we need colclude the dat get $hacAmount
                  $hacAmount = DB::table('et_payment')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
                        ->where('et_payment.status', 1) // paid amoun
                        ->whereYear('et_payment.initialPayDate', $year)
                        ->whereMonth('et_payment.initialPayDate', $month)
                        ->where('et_payment.branch_id', $branchId)
                        ->sum('et_payment.paidAmount');
                        // return $hacAmount;
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    //  return $ten_x;
                    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
                    $isoutstandingRequired        = $ten_x['no_of_outstanding_10x'] == "1";
                    $isPostsaleRequired        = $ten_x['no_of_post_sale_10x'] == "1";
                   
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isHacCostingRequired) {
                        $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                        $actaulTenx  = $hacAmount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isoutstandingRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } 
                    
                        $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulREI  = $refferal_count ?? 0;
                        $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                        
                         $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                         
                        $EIaward = 0;
                        $EIStatus = false;
                        $targetEI = 0;
                        $actaulEI = 0;
                        
                        if ($isHacCostingRequired) {
                            $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                            $actaulTenx  = $hacAmount ?? 0;
                            $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
                        
                            // Only if HAC 10X achieved, calculate EI
                            if ($tenxStatus && $incentive->excess_incentive > 0) {
                                $excessAmount = $actaulTenx - $targetTenx;
                        
                                if ($excessAmount > 0) {
                                    $targetEI = $incentive->excess_incentive . '%'; // just for display
                                    $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
                                    $EIaward = $actaulEI;
                                    $EIStatus = true;
                                }
                            }
                        }
                        $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulTenx . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCollectionModal(' . $staff->staff_id . ')" >Details</span>', 
                                             
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => ($tenxStatus && $incentive->tenx_warrior) ?  : 0,
                            ],
                        
                            
                            'EI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetEI . '</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . number_format($actaulEI, 2) . '</span>',
                                'status' => $EIStatus,
                                'reward' => number_format($EIaward, 2),
                            ],
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isCRE) {
                $helper = new \App\Helpers\Helpers();
                
                 $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                
                $targetTenx = $goalsetData[$staff->staff_id]->harvesting_percentage ?? 85;
                if($incentive){
                    $eci_target = $incentive->eci_count ?? 0;
                    $bi_target_percent = $incentive->bi_amount ?? 0;
                    $bi_target = $targetTenx ?? 0;
                    $spot_cre_incentive_target = $incentive->spot_incentive_percent ?? 0;
                    $spot_cre_incentive_reward = $incentive->spot_incentive_month ?? 0;
                    $ri_reward = $incentive->ri_amount ?? 0;
                }else{
                    $eci_target = 70;
                     $bi_target = $targetTenx ;
                     $bi_target_percent = 2;
                     $spot_cre_incentive_target = 80;
                     $spot_cre_incentive_reward = 2000;
                     $ri_reward = 750;
                }
                
               
                $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
                $tenxStatus = false;
                $actaulTenx = 0;
                $gstPercentage=18;
                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
                
               $tragetHarvesting = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper) {
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($branch ? $gstPercentage / 100 : 0.18);
            
                    // Calculate the converted amount based on the payment status and currency
                    if ($row->payment_status == 1) {
                        if ($row->currency_code != "INR") {
                            $converted = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                ? $row->total_amount_inr
                                : $row->paid_amount;
                        } else {
                            $converted = $row->paid_amount;
                        }
                        $netAmount = $converted / (1 + $gstRate);
                    } else if ($row->currency_code != "INR") {
                        $converted = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
                        $netAmount = $converted / (1 + $gstRate);
                    } else {
                        $converted = $row->payable_amount;
                        $netAmount = $converted / (1 + $gstRate);
                    }
            
                    return $netAmount;
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 1 decimal place
                    return $carry + $item;
                }, 0);
            
     
                $tragetHarvesting = round($tragetHarvesting);
            
            
                $collectionHarvesting = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper) {
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;
            
                    // ✅ Use proposal-specific GST, fallback to branch GST
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);
            
                    // ✅ Net without GST
                    $netAmount = $amountInr / (1 + $gstRate);
            
                    // Round the net amount to two decimal places
                    return round($netAmount, 2);
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 2 decimal places
                    return round($carry + $item, 2);
                }, 0);

                $collectionHarvesting = round($collectionHarvesting, 1);
                
                
                
                 $collectionEci = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                $collectionEci = round($collectionEci, 1);
                
                 $collectionSpot = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                    $collectionSpot = round($collectionSpot, 1);
                
                    $monthlyTargets = [];
            

                    // ! 10x Award
                    $monthlyCollectionsINR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $monthlyCollectionsOther = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $convertedCollections = [];
                    foreach ($monthlyCollectionsOther as $staffId => $target1) {
                        $convertedAmount = $helper->ConvertedAmountInr($target1->currency_code, $target1->monthly_collection);
                        if (!isset($convertedCollections[$staffId])) {
                            $convertedCollections[$staffId] = 0;
                        }
                        $convertedCollections[$staffId] += $convertedAmount;
                    }

                    $monthlyCollections = [];
                    foreach ($monthlyCollectionsINR as $staffId => $inrCollection) {
                        $monthlyCollections[$staffId] = [
                            'total_collection_inr' => $inrCollection->monthly_collection,
                        ];
                    }

                    // Add converted non-INR amounts to the collection array
                    foreach ($convertedCollections as $staffId => $convertedAmount) {
                        if (isset($monthlyCollections[$staffId])) {
                            $monthlyCollections[$staffId]['total_collection_inr'] += $convertedAmount;
                        } else {
                            $monthlyCollections[$staffId] = [
                                'total_collection_inr' => $convertedAmount,
                            ];
                        }
                    }

                    // ! Early Cash Incentive
                    $cre_eci_inr = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $cre_eci_other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $convertedCollectionsBy15th = [];
                    foreach ($cre_eci_other as $staffId => $target2) {
                        $convertedAmount = $helper->ConvertedAmountInr($target2->currency_code, $target2->collection_by_15th);

                        if (!isset($convertedCollectionsBy15th[$staffId])) {
                            $convertedCollectionsBy15th[$staffId] = 0;
                        }

                        $convertedCollectionsBy15th[$staffId] += $convertedAmount;
                    }

                $collectionsBy15th = [];
                foreach ($cre_eci_inr as $staffId => $inrCollection) {
                    $collectionsBy15th[$staffId] = [
                        'total_collection_eci' => $inrCollection->collection_by_15th,
                    ];
                }

                // Add converted foreign currency collections
                foreach ($convertedCollectionsBy15th as $staffId => $convertedAmount) {
                    if (isset($collectionsBy15th[$staffId])) {
                        $collectionsBy15th[$staffId]['total_collection_eci'] += $convertedAmount;
                    } else {
                        $collectionsBy15th[$staffId] = [
                            'total_collection_eci' => $convertedAmount,
                        ];
                    }
                }

                // ! Spot Incentive
                $cre_spot_INR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $cre_spot_Other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                // Convert foreign currency collections to INR
                $convertedCollectionsSpotOther = [];
                foreach ($cre_spot_Other as $staffId => $collection) {
                    $convertedAmount = $helper->ConvertedAmountInr($collection->currency_code ?? 'default_currency_code', $collection->monthly_collection_before_next_paydate);

                    if (!isset($convertedCollectionsSpotOther[$staffId])) {
                        $convertedCollectionsSpotOther[$staffId] = 0;
                    }

                    $convertedCollectionsSpotOther[$staffId] += $convertedAmount;
                }

                // Prepare INR collections
                $collectionsSpotINR = [];
                foreach ($cre_spot_INR as $staffId => $collection) {
                    $collectionsSpotINR[$staffId] = [
                        'total_collection_spot' => $collection->monthly_collection_before_next_paydate,
                    ];
                }

                // Combine converted foreign collections into INR collections
                foreach ($convertedCollectionsSpotOther as $staffId => $convertedAmount) {
                    if (isset($collectionsSpotINR[$staffId])) {
                        $collectionsSpotINR[$staffId]['total_collection_spot'] += $convertedAmount;
                    } else {
                        $collectionsSpotINR[$staffId] = [
                            'total_collection_spot' => $convertedAmount,
                        ];
                    }
                }


                // Referal Incentive
                $cre_ref_count =  DB::table('et_proposal')
                ->select(
                    'et_proposal.service_title',
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.country_code',
                    'et_customer.cus_mobile',
                    'et_payment.transaction_date as created_date',
                    'et_payment.transaction_date as created_at',
                    'et_transaction.payment_id',
                    'et_transaction.sno as transaction_id',
                    'et_payment.paid_amount'
                )
                ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->where('et_proposal.branch_id', $branchId)
                ->where('et_proposal.referral_id', $staff->staff_id)
                ->where('et_proposal.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->where('et_payment.status', 0)
                ->orderBy('et_proposal.sno', 'asc')
                ->count();

                // return $cre_spot;

               
                $collection = 0;

                // ! Total Target
                
                // if($incentive){
                //     $targetTenx= $incentive ? $incentive 85;
                // }else{
                //     $targetTenx = 85;
                // }
                

                // ! 10X Calculation
                $collection = $collectionHarvesting ?? 0;
                $collectionPercentage = $tragetHarvesting > 0 ? ($collection / $tragetHarvesting) * 100 : 0;
                $collectionPercentage=round($collectionPercentage);
                $tenxStatus = $collectionPercentage >= $targetTenx;
                
               
                // ! Early Cash Incentive
                $eci_collection = $collectionEci ?? 0;
                $eci_percentage = $tragetHarvesting > 0 ? ($eci_collection / $tragetHarvesting) * 100 : 0;
                $eci_achieved = ($eci_target && $eci_percentage >= $eci_target) ? $eci_target : 0;

                //    return $collectionSpot;
                //  ! Spot Incentive
                $spot_collection = $collectionSpot ??  0;
                $spot_percentage = $collection > 0 ? ($spot_collection / $collection) * 100 : 0;
                $spot_achieved = $spot_percentage >= ($spot_cre_incentive_target ?? 0);
                
                $bi_value =0;
                $bonusAmount =0;
                $excessValue =0;
                if ($collectionPercentage > $bi_target) {
                    $excessPercentage = $collectionPercentage - $bi_target;
                   
                    $excessValue = ($excessPercentage / 100) * $tragetHarvesting;
                    $bi_value =($bi_target_percent / 100);
                    
                    $bonusAmount = round($excessValue * $bi_value); 
                }
                // ! Bonus Incentive
                
               
                $bi_achieved = (($bi_target) && $collectionPercentage > $bi_target) ? true : false;
                $bi_reward = $bi_achieved ? $bonusAmount : 0;

                // ! Referal Incentive
                $ri_amount = ($cre_ref_count ?? 0) * $ri_reward;
                $ri_achieved = $ri_amount > 0;

                // ! Luxury Incentive
                $luxuryData = $incentive && isset($incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                $early_cash_incentive = $luxuryData['early_cash_incentive'] ?? 0;
                $tenx_award_luxury = $luxuryData['tenx_award'] ?? 0;
                $bonus_incentive = $luxuryData['bonus_incentive'] ?? 0;
                $spot_incentive = $luxuryData['spot_incentive'] ?? 0;
                $referral_incentive = $luxuryData['referral_incentive'] ?? 0;
                $reward = $luxuryData['reward'] ?? '0';
                // $tenxStatus=false;
                $tenx_luxury_achieved = $tenx_award_luxury ? ($tenxStatus ? true : false) : true ;
                $bi_luxury_achieved = $bonus_incentive ? ($bi_achieved ? true : false) : true ;
                $spi_luxury_achieved = $spot_incentive ? ($spot_achieved ? true : false) : true ;
                $ri_luxury_achieved = $referral_incentive ? ($ri_achieved ? true : false) : true ;
                // $luxury_achieved = ($tenxStatus && $early_cash_incentive && $eci_achieved && $bonus_incentive && $bi_achieved && $spot_incentive && $spot_achieved&& $referral_incentive && $ri_achieved);
                $luxury_achieved = ($tenx_luxury_achieved && $bi_luxury_achieved && $spi_luxury_achieved && $ri_luxury_achieved);

                $result[] = [
                    'staff_id' => $staff->staff_id,
                    'staff_name' => $staff->staff_name,
                    'staff_image' => $staff->staff_image,
                    'role_id' => $staff->role_id,
                    'nick_name' => $staff->nick_name,
                    'sub_department_name' => $staff->sub_department_name,
                    'department_name' => $staff->department_name,

                    'incentives' => [
                        'tenx_award' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '%</span> <span class="fw-bold fs-2 ms-2 badge bg-label-secondary">' . number_format($tragetHarvesting) . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $collectionPercentage . '%
                                             </span>
                                             <span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . number_format($collection) . '
                                             </span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCreActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                             

                            'status' => $tenxStatus,
                            'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                        ],

                        'eci' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($eci_target ?? 0) . '%' . '</span>',
                            'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eci_percentage) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                            'status' => $tenxStatus && $eci_achieved,
                            'reward' => ($tenxStatus && $eci_achieved) ? $incentive->eci_reward : 0 ,
                        ],


                        'bi' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">Greater Than ' . ($bi_target ? $bi_target : 0) . '%' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . ($bi_achieved ? (round($excessValue) . ' * '. $bi_target_percent .'% = ' . number_format($bi_reward, 0)) : '0') . '
                                             </span> <span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCrebonusDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $bi_achieved,
                            'reward' => ($tenxStatus && $bi_achieved) ? $bi_reward : 0 ,
                        ],

                        'sp' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $spot_cre_incentive_target . '%' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . number_format($spot_percentage, 0) . '%' . '
                                             </span><span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreSpotDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $spot_achieved,
                            'reward' => ($tenxStatus && $spot_achieved) ? ($spot_cre_incentive_reward ?? 0) : 0 ,
                        ],

                        'ri' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'.$ri_reward.' Per Successful Referral">' .$ri_reward. '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $cre_ref_count . ' * '.$ri_reward.' =' . $ri_amount  . '
                                             </span> <span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreRefrlDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $ri_achieved,
                            'reward' => ($tenxStatus && $ri_achieved) ? $ri_amount : 0 ,
                        ],

                        'li' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 'All Incentives Achieved' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . ($luxury_achieved ? 'All Incentives Achieved' : 'Not Achieved') . '
                                             </span>',

                            'status' => $luxury_achieved,
                            'reward' => $luxury_achieved ? $reward : 0,
                        ],


                    ]

                ];
            }
            
            if ($isJournalCordinator) {
                
                

                    $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
                    $lastTwoMonths = [
                        $currentMonthJournal->copy()->subMonth(1),
                        $currentMonthJournal->copy()->subMonth(2),
                    ];

                    $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->staff_id)
                        ->where('status_10x', 1)
                        ->where(function ($query) use ($lastTwoMonths) {
                            foreach ($lastTwoMonths as $date) {
                                $query->orWhere(function ($q) use ($date) {
                                    $q->whereMonth('goal_date', $date->month)
                                    ->whereYear('goal_date', $date->year);
                                });
                            }
                        })
                        ->get();
                    $isConsistent = $goalsetteamLast->count() == 2;
                    // return  $isConsistent;
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                    $publish_target= $goalsetData[$staff->staff_id]->no_of_papers ?? 8;
                    if( $incentive ){
                        $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
                        $tenx_amount = $incentive->tenx_award ?? 1000;
                        $exiTarget = $publish_target ?? 8;
                        $exiAcheiveAmount = $incentive->extra_acheive_award ?? 1000;
                        $doubleXITarget = $publish_target ? $publish_target*2 : 16;
                        $doubleXIAmount= $incentive->doublex_award ?? 5000;
                        $perform_attend_percent= $incentive->perform_incent_attend ?? 100;
                        $performance_incentive_reward = $incentive->performance_incentive_reward ?? 1000;
                    }else{
                        $check_accepted_paper=1;
                        $tenx_amount =  1000;
                        $exiTarget = 8;
                        $exiAcheiveAmount =  1000;
                        $doubleXITarget =  16;
                        $doubleXIAmount=  5000;
                        $perform_attend_percent=  100;
                        $performance_incentive_reward =  1000;
                    }
                    $publicationCurrentMonthCount = 0;
                    
                    $tenxStatus = false;
                    $exiStatus = false;
                    $doubleXIncent = false;
                    $permformJCIncent = false;
                    $priviousGoalsetAwared = $isConsistent ? true:false;


                    //  $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                    //     ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                    //     ->leftJoin('et_journal_history as jh', function ($join) {
                    //         $join->on('mj.sno', '=', 'jh.journal_id')
                    //             ->where('jh.status', 5);
                    //     });

                    // if ($check_accepted_paper == 1) {
                    //     $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5,8,7]);
                    // } else {
                    //     $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
                    // }

                    // $publicationCurrentMonthCount = $publicationCurrentMonthCount
                    //     ->where('cs.jc_staff', $staff->staff_id)
                    //     ->where(function ($query) use ($year, $month) {

                    //         $query->where(function ($q) use ($year, $month) {
                    //             $q->where('mj.status', 8)
                    //             ->whereYear('mj.publish_date', $year)
                    //             ->whereMonth('mj.publish_date', $month);
                    //         })

                    //         ->orWhere(function ($q) use ($year, $month) {
                    //             $q->where('mj.status', 5)
                    //             ->whereYear('jh.accepted_date', $year)
                    //             ->whereMonth('jh.accepted_date', $month);
                    //         });

                    //     })
                    //     ->count();

                        $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                            ->leftJoin('et_journal_history as jh', function ($join) {
                                $join->on('mj.sno', '=', 'jh.journal_id')
                                    ->where('jh.status', 5);
                            });

                        if ($check_accepted_paper == 1) {
                            //  Added 7 here
                            $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5, 7, 8]);
                        } else {
                            $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
                        }

                        $publicationCurrentMonthCount = $publicationCurrentMonthCount
                            ->where('cs.jc_staff', $staff->staff_id)
                            ->where(function ($query) use ($year, $month) {

                                $query->where(function ($q) use ($year, $month) {
                                    $q->where('mj.status', 8)
                                    ->whereYear('mj.publish_date', $year)
                                    ->whereMonth('mj.publish_date', $month);
                                })

                                ->orWhere(function ($q) use ($year, $month) {
                                    $q->whereIn('mj.status', [5, 7]) //  include 7 here also
                                    ->whereYear('jh.accepted_date', $year)
                                    ->whereMonth('jh.accepted_date', $month);
                                });

                            })
                            ->count();

                        $publicationCurrentMonthData = DB::table('et_manage_journal as mj')
                            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                            ->leftJoin('et_journal_history as jh', function ($join) {
                                $join->on('mj.sno', '=', 'jh.journal_id')
                                    ->where('jh.status', 5);
                            });

                        if ($check_accepted_paper == 1) {
                            $publicationCurrentMonthData = $publicationCurrentMonthData->whereIn('mj.status', [5, 7, 8]);
                        } else {
                            $publicationCurrentMonthData = $publicationCurrentMonthData->where('mj.status', 8);
                        }

                        $publicationCurrentMonthData = $publicationCurrentMonthData
                            ->where('cs.jc_staff', $staff->staff_id)
                            ->where(function ($query) use ($year, $month) {

                                $query->where(function ($q) use ($year, $month) {
                                    $q->where('mj.status', 8)
                                    ->whereYear('mj.publish_date', $year)
                                    ->whereMonth('mj.publish_date', $month);
                                })

                                ->orWhere(function ($q) use ($year, $month) {
                                    $q->whereIn('mj.status', [5, 7])
                                    ->whereYear('jh.accepted_date', $year)
                                    ->whereMonth('jh.accepted_date', $month);
                                });

                            })
                             ->orderByRaw("
                                CASE 
                                    WHEN mj.status IN (5, 7) THEN jh.accepted_date
                                    ELSE mj.publish_date
                                END ASC
                            ")
                            ->limit($exiTarget)
                            ->pluck('mj.sno');
                        
                    

                
                        $publicationAfter15thCount = DB::table('et_manage_journal as mj')
                            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                            ->leftJoin('et_journal_history as jh', function ($join) {
                                $join->on('mj.sno', '=', 'jh.journal_id')
                                    ->where('jh.status', 5);
                            });
                             if ($check_accepted_paper == 1) {
                                $publicationAfter15thCount = $publicationAfter15thCount->whereIn('mj.status', [5, 7, 8]);
                            } else {
                                $publicationAfter15thCount = $publicationAfter15thCount->where('mj.status', 8);
                            }

                            $publicationAfter15thCount = $publicationAfter15thCount
                                ->where('cs.jc_staff', $staff->staff_id)
                                ->whereNotIn('mj.sno',$publicationCurrentMonthData)
                                ->where(function ($query) use ($year, $month) {

                                    $query->where(function ($q) use ($year, $month) {
                                        $q->where('mj.status', 8)
                                        ->whereYear('mj.publish_date', $year)
                                        ->whereMonth('mj.publish_date', $month)
                                        ->whereDay('mj.publish_date', '<=', 15);
                                    })

                                    ->orWhere(function ($q) use ($year, $month) {
                                         $q->whereIn('mj.status', [5, 7])
                                        ->whereYear('jh.accepted_date', $year)
                                        ->whereMonth('jh.accepted_date', $month)
                                        ->whereDay('jh.accepted_date', '<=', 15);
                                    });

                                })
                                ->count();
                        
                       
                        // return $publicationAfter15thCount;
                      

                    
                    $tenxStatus = ($publicationCurrentMonthCount >=$publish_target);
                    $exiStatus = ($publicationCurrentMonthCount >=$exiTarget);
                    $exiAmountAward = $publicationAfter15thCount > 0 ? $publicationAfter15thCount *$exiAcheiveAmount : 0;
                    $doubleXIncent = ($publicationCurrentMonthCount >=$doubleXITarget);

                     $startDate = Carbon::create($year, $month, 1);
                    $currentDate = Carbon::now();
                    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

                    $dayCounts = 0;
                    $dateSrt = $startDate->copy();
                    while ($dateSrt->lte($endDate)) {
                        if (!$dateSrt->isSunday()) {
                            $dayCounts++;
                        }
                        $dateSrt->addDay();
                    }
                    
                 
                    $presentDays = DB::table('et_staff_attendance')
                        ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                        ->where('et_staff_attendance.staff_id', $staff->staff_id) 
                        // ->where('et_staff_attendance.staff_id', 62) 
                        ->whereYear('et_staff_attendance.date', $year)
                        ->whereMonth('et_staff_attendance.date', $month)
                        ->count();
                    
                    $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
                  
                  $permformJCIncent = (
                        $attendance_percent > 0 && 
                        $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
                    );
                  

                
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Publish Paper Target Count">' . $publish_target . '</span> ',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Paper Count">
                                                    ' . $publicationCurrentMonthCount . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualJournalDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
                            ],
                        
                            'exi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary"> Greater Than ' . $exiTarget  .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $publicationAfter15thCount . '*'.$exiAcheiveAmount. '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualExtraJournalDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $exiStatus,
                                'reward' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
                            ],
                        
                            'doublex' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($doubleXITarget) . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($publicationCurrentMonthCount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable ms-1" style="cursor:pointer" onclick="openActualDoubleXJournalDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $doubleXIncent,
                                'reward' => ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0,
                            ],
                        
                           'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($perform_attend_percent) . 
                                            ' %</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Percentage">' . 
                                            $attendance_percent . ' %' . 
                                            '</span><span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformAttendanceModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $permformJCIncent,
                                'reward' => ($tenxStatus && $permformJCIncent)
                                    ? ($performance_incentive_reward)
                                    : 0,
                            ],
                        ]
        
                    ];
            
            } 
            
            if ($isProduction) {
                
             
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
            
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
                    $isStudentMinRequired        = $ten_x['min_no_of_students_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isStudentMinRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                   //   return $pdiStatus;
                    $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'PDI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . 
                                            '</span>',
                            
                                'status' =>  $pdiStatus,
                                'reward' => $tenxStatus && $pdiReward
                                    ? (($pdiReward >= 0 ? '+' : '-') . round(abs($pdiReward)))
                                    : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isPC) {
                
                $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
            
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    // return $ten_x;
                    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    }  elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                    
                    $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                    $actaulREI  = $refferal_count ?? 0;
                    $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                    
                    $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                   //   return $pdiStatus;
                    $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            if ($isContentWriter || $isDeveloper) {
                
                

                    $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
                    $lastTwoMonths = [
                        $currentMonthJournal->copy()->subMonth(1),
                        $currentMonthJournal->copy()->subMonth(2),
                    ];

                    $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->staff_id)
                        ->where('status_10x', 1)
                        ->where(function ($query) use ($lastTwoMonths) {
                            foreach ($lastTwoMonths as $date) {
                                $query->orWhere(function ($q) use ($date) {
                                    $q->whereMonth('goal_date', $date->month)
                                    ->whereYear('goal_date', $date->year);
                                });
                            }
                        })
                        ->get();
                    $isConsistent = $goalsetteamLast->count() == 2;
                    // return  $isConsistent;
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                    $publish_target= $goalsetData[$staff->staff_id]->working_hours ?? 180;
                    $publish_target_percent= $goalsetData[$staff->staff_id]->rework ?? 95;
                    if( $incentive ){
                        $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
                        $tenx_amount = $incentive->tenx_award ?? 1000;
                        $exiTarget = $publish_target ?? 180;
                        $exiAcheiveAmount = $incentive->extra_acheive_award ?? 1000;
                        $doubleXITarget = $incentive->publish_target ? $incentive->publish_target*2 : 16;
                        $doubleXIAmount= $incentive->doublex_award ?? 5000;
                        $perform_attend_percent= $incentive->perform_incent_attend ?? 100;
                        $performance_incentive_reward = $incentive->performance_incentive_reward ?? 1000;
                    }else{
                        $check_accepted_paper=1;
                        $tenx_amount =  1000;
                        $exiTarget = 180;
                        $exiAcheiveAmount =  1000;
                        $doubleXITarget =  16;
                        $doubleXIAmount=  5000;
                        $perform_attend_percent=  80;
                        $performance_incentive_reward =  1000;
                    }
                    $publicationCurrentMonthCount = 0;
                    
                    $tenxStatus = false;
                    $exiStatus = false;
                    $doubleXIncent = false;
                    $permformJCIncent = false;
                    $priviousGoalsetAwared = $isConsistent ? true:false;


                     $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                        ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno');
                        if( $check_accepted_paper==1){
                          $publicationCurrentMonthCount=$publicationCurrentMonthCount->whereIn('mj.status',[5,8]);
                        }else{
                        $publicationCurrentMonthCount=$publicationCurrentMonthCount->where('mj.status', 8);
                        }
                        
                        $publicationCurrentMonthCount=$publicationCurrentMonthCount->where('cs.jc_staff', $staff->staff_id) 
                        // ->where('cs.jc_staff', 62) 
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month)
                        ->count();
                  

                    // $CurrentWorkingHoursInsec = DB::table('et_daily_tasks')
                    //     ->join('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
                    //     ->whereYear('et_daily_tasks.task_date', $year)
                    //     ->whereMonth('et_daily_tasks.task_date', $month)
                    //     ->where('et_daily_tasks.staff_id', $staff->staff_id)
                    //     ->selectRaw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as total_seconds')
                    //     ->value('total_seconds');

                    $CurrentWorkingHoursInsec = DB::table('et_daily_tasks')
                    ->join('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
                    ->whereYear('et_daily_tasks.task_date', $year)
                    ->whereMonth('et_daily_tasks.task_date', $month)
                    ->where('et_daily_tasks.staff_id', $staff->staff_id)
                    ->selectRaw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as total_seconds')
                    ->value('total_seconds');

                    // $CurrentWorkingHours = round($CurrentWorkingHoursInsec / 3600, 1);

                    $SavingTimeInSec = DB::table(DB::raw("
                    (
                        SELECT 
                            dt.sno,
                            dt.task_hours,
                            (dt.task_hours * 3600) - 
                            COALESCE(SUM(TIME_TO_SEC(tl.duration)),0) as saving_seconds
                        FROM et_daily_tasks dt
                        LEFT JOIN et_task_log tl 
                            ON dt.sno = tl.task_id
                        WHERE YEAR(dt.task_date) = $year
                            AND MONTH(dt.task_date) = $month
                            AND dt.staff_id = {$staff->staff_id}
                            AND dt.status >= 4
                        GROUP BY dt.sno, dt.task_hours
                    ) as task_saving
                "))
                ->sum('saving_seconds');

                        $savingFlag = 'neutral';

                        if ($SavingTimeInSec > 0) {
                            $savingFlag = 'positive';
                        } elseif ($SavingTimeInSec < 0) {
                            $savingFlag = 'negative';
                        }

                        $savingBadgeClass = 'bg-label-secondary';

                        if ($savingFlag == 'positive') {
                            $savingBadgeClass = 'bg-label-success';  // green
                        } elseif ($savingFlag == 'negative') {
                            $savingBadgeClass = 'bg-label-danger';   // red
                        }

                        $AdjustedWorkingSeconds = $CurrentWorkingHoursInsec + $SavingTimeInSec;

                        $AdjustedWorkingHours = round($AdjustedWorkingSeconds / 3600, 1);
                        $SavingTimeInHours = round($SavingTimeInSec / 3600, 1);
                        $CurrentWorkingHours = round($CurrentWorkingHoursInsec / 3600, 1);

                        $AdjustedWorkingPercentage = 0;
                        if ($publish_target > 0) {
                            $AdjustedWorkingPercentage = round(($AdjustedWorkingHours / $publish_target * 100), 2);
                        }
                        // task_hours = 5 hrs
                        // actual_duration = 4 hrs
                        // saving = +1 hr → ADD to total

                        // task_hours = 5 hrs
                        // actual_duration = 6 hrs
                        // saving = -1 hr → SUBTRACT from total
                        

                    $publicationCurrentMonthData = DB::table('et_manage_journal as mj')
                        ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno');
                        if( $check_accepted_paper==1){
                          $publicationCurrentMonthData=$publicationCurrentMonthData->whereIn('mj.status',[5,8]);
                        }else{
                        $publicationCurrentMonthData=$publicationCurrentMonthData->where('mj.status', 8);
                        }
                        
                        $publicationCurrentMonthData=$publicationCurrentMonthData->where('cs.jc_staff', $staff->staff_id)  
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month)
                        ->orderBy('mj.publish_date','asc')
                        ->limit($exiTarget)
                        ->pluck('mj.sno');

                    $publicationAfter15thCount = DB::table('et_manage_journal as mj')
                        ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno');
                        if( $check_accepted_paper==1){
                          $publicationAfter15thCount=$publicationAfter15thCount->whereIn('mj.status',[5,8]);
                        }else{
                        $publicationAfter15thCount=$publicationAfter15thCount->where('mj.status', 8);
                        }
                        
                        $publicationAfter15thCount=$publicationAfter15thCount->where('cs.jc_staff', $staff->staff_id)  
                        // ->where('cs.jc_staff', 62)   // staff id
                        ->whereYear('mj.publish_date', $year)
                        ->whereMonth('mj.publish_date', $month)
                        ->whereNotIn('mj.sno',$publicationCurrentMonthData)
                        ->whereDay('mj.publish_date', '>', 15)
                        ->count();

                    
                    $tenxStatus = ($CurrentWorkingHours >=$publish_target);
                    $exiStatus = ($CurrentWorkingHours >=$exiTarget);
                    $exiAmountAward = $publicationAfter15thCount > 0 ? $publicationAfter15thCount *$exiAcheiveAmount : 0;
                   

                     $startDate = Carbon::create($year, $month, 1);
                    $currentDate = Carbon::now();
                    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

                    $dayCounts = 0;
                    $dateSrt = $startDate->copy();
                    while ($dateSrt->lte($endDate)) {
                        if (!$dateSrt->isSunday()) {
                            $dayCounts++;
                        }
                        $dateSrt->addDay();
                    }
                    
                 
                    $presentDays = DB::table('et_staff_attendance')
                        ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                        ->where('et_staff_attendance.staff_id', $staff->staff_id) 
                        // ->where('et_staff_attendance.staff_id', 62) 
                        ->whereYear('et_staff_attendance.date', $year)
                        ->whereMonth('et_staff_attendance.date', $month)
                        ->count();
                    
                    $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
                  
                  $permformJCIncent = (
                        $attendance_percent > 0 && 
                        $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
                    );
                  

                
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Target Working Hours">' . $publish_target . ' hrs</span> <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Target Working Percentage">' . $publish_target_percent . '%</span> ',
                                
                                'actual' => '
                                            <span class="fw-bold fs-2 badge bg-label-secondary me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Working Hours">' . $CurrentWorkingHours . ' hrs</span>
                                            <span class="fw-bold fs-2 badge me-1 ' . $savingBadgeClass . '" 
                                                data-bs-toggle="tooltip" 
                                                data-bs-placement="bottom" 
                                                title="Saving Hours (Task Hours - Actual Worked)">
                                                ' . $SavingTimeInHours . ' hrs
                                            </span>
                                            <span class="fw-bold fs-2 badge bg-label-info" 
                                                      data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Working Hours in the month">
                                                    ' . $AdjustedWorkingHours . ' hrs
                                            </span> 
                                            <span class="fw-bold fs-2 badge bg-label-info" 
                                                      data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Working Percentage in the month">
                                                    ' . $AdjustedWorkingPercentage . '%
                                            </span> 
                                            <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualProductionDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary"> Greater Than ' . $exiTarget  .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $publicationAfter15thCount . '*'.$exiAcheiveAmount. '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualExtraJournalDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $exiStatus,
                                'reward' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
                            ],
                        
                           'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($perform_attend_percent) . 
                                            ' %</span> ',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Percentage">' . 
                                            $attendance_percent . ' %' . 
                                            '',
                                'status' => $tenxStatus && $permformJCIncent,
                                'reward' => ($tenxStatus && $permformJCIncent)
                                    ? ($performance_incentive_reward)
                                    : 0,
                            ],
                        ]
        
                    ];
            
            }
        }
            return response()->json([
                'status' => 200,
                'data' => $result
            ]);
    }
    private function getTeamIncentiveStatus(array $executiveIds, array $allExecutiveIncentives): array
    {
        $finalStatus = [
            'tenx_award' => true,
            'eci' => true,
            'bi' => true,
            'si' => true,
            'pi' => true,
            'sp' => true,
        ];
    
        foreach ($executiveIds as $execId) {
            $key = 'staff_' . $execId;
    
            if (!isset($allExecutiveIncentives[$key])) {
                // If data missing, fail all
                foreach ($finalStatus as $type => $_) {
                    $finalStatus[$type] = false;
                }
                continue;
            }
    
            $incentiveSet = $allExecutiveIncentives[$key]['incentives'] ?? [];
    
            foreach ($finalStatus as $type => $_) {
                // If not true, then mark team as not fully achieved
                if (!isset($incentiveSet[$type]['status']) || $incentiveSet[$type]['status'] !== true) {
                    $finalStatus[$type] = false;
                }
            }
        }
    
        return $finalStatus;
    }

    private function calculateIncentivesForStaff($staff, $branchId , $month, $year, $goalsetData)
    {
        $finalStatus = [
            'tenx_award' => true,
            'eci' => true,
            'bi' => true,
            'si' => true,
            'pi' => true,
            'sp' => true,
        ];
      
          // Get the first and last date of the requested month
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    
        // Generate all dates in the month
        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }
    
        // Directly use startDate and endDate for formatting
        $startOfMonth = $startDate->format('Y-m-d');
        $endOfMonth = $endDate->format('Y-m-d');
        // $finalStatus  = [];
        
        // foreach ($staff as $staff) {
        
               $current_date = date('Y-m-d'); // Define the current date
              //Sales Team 
              
              $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.branch_id', $branchId)
                ->whereNotIn('et_lead.status', [2, 6])
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.drop_verified', 0)
                ->where('et_lead.internal_status', 0)
                ->count();
        
              $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.branch_id', $branchId)
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->whereNotIn('et_lead.status', [2, 6])
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.drop_verified', 0)
                ->where('et_lead.internal_status', 0)
                ->count();
                
            //   $customerConvertCount = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
            //   ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            //     ->whereIn('et_customer.status',[0,6])
            //     ->where('et_customer.branch_id', $branchId)
            //     ->where('et_lead.created_by', $staff->sno)
            //     ->whereYear('et_customer.created_at', $year)
            //     ->whereMonth('et_customer.created_at', $month)
            //     ->count();
                
                $customerConvertCount = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->count();
                
              $monthcall_out = DB::table('et_call_tracker')
                ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                ->whereYear('call_start_date', $year)
                ->whereMonth('call_start_date', $month)
                ->where('et_call_tracker.branch_id', $branchId)
                ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                ->first();
                
              $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
        
        
              // customer ratio
              $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
              $convertion_rate = number_format($convertion_rate, 2);
        
              //acr
              $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
              $averager_convertion_rate = number_format($averager_convertion_rate, 2);
        
                $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
                if (!$incentive) {
                    return []; // or return null or false based on your method return type
                }
        
                $luxury = json_decode($incentive->luxury_incentive, true);
                $pi_slabs = json_decode($incentive->pi_slab_json, true);
        
              $currentMonthCustomerCount = 0;
              $total_business_amount     = 0;
              $total_payment             = 0;
              $total_paid_payment        = 0;
              $averageBusinessValue      = 0;
              $averageCollectionValue    = 0;
              $crashCount = 0;
              $professionCount = 0;
              $tesboCount = 0;
              $courseTypeTotal = 0;
              $eciCustomerConvertCount = 0;
              $eciActualPercentage = 0;
              $eciTargetPercentage = $incentive->eci_count ?? 0;
              $eciStatus = false;
            
               $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
                $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
                $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;
                $crashTarget =0;
                $professionTarget =0;
                $tesboTarget =0;
                $crashPercent =0;
                $professionPercent=0;
                $tesboPercent=0;
                $piPercentage = 0;
                $originalAmount = 0;
                $piReward = 0;
                $matchedSlab = null;
                $slabPercentage = 0; 
                
               // Total Professional and Crash courses
                // $groupedData = DB::table('et_training')
                //     ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                //     ->select(
                //         'et_course.course_type_id',
                //         DB::raw('COUNT(DISTINCT et_training.payment_id) AS total_trainings')
                //     )
                //     ->where('et_training.branch_id', $branchId)
                //     ->whereMonth('et_training.created_at', $month)
                //     ->whereYear('et_training.created_at', $year)
                //     ->whereIn('et_course.course_type_id', [3, 4])
                //     ->where('et_training.tesbo_check', '!=', 2)
                //     ->where('et_training.post_sale_check', '!=', 1)
                //     ->groupBy('et_course.course_type_id')
                //     ->get();
                $groupedData=[];
                // Get valid TESBO count separately
                // $teshobo_coures_total = DB::table('et_training')
                //     ->where('branch_id', $branchId)
                //     ->whereMonth('created_at', $month)
                //     ->whereYear('created_at', $year)
                //     ->where('tesbo_check', 2)
                //     ->where('post_sale_check', '!=', 1)
                //     ->distinct('payment_id')
                //     ->count('payment_id');
                $teshobo_coures_total=0;
                
                // Prepare tree output
                $crash_coures_total = 0;
                $professinal_coures_total = 0;
                
                foreach ($groupedData as $row) {
                    if ($row->course_type_id == 3) {
                        $professinal_coures_total = (int) $row->total_trainings;
                    } elseif ($row->course_type_id == 4) {
                        $crash_coures_total = (int) $row->total_trainings;
                    }
                }
                
                 $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
             
               if ($customerConvertCount > 0) {
                // $currentMonthCustomer = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                // ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                //   ->where('et_customer.branch_id', $branchId)
                //   ->whereIn('et_customer.status',[0,6])
                //   ->where('et_lead.created_by', $staff->sno)
                //   ->whereYear('et_customer.created_at', $year)
                //   ->whereMonth('et_customer.created_at', $month)
                //   ->get();
                  
                  
                //     // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                // // ECI early conversion before 15th
                // $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                //     ->where('et_customer.branch_id', $branchId)
                //     ->whereIn('et_customer.status', [0, 6])
                //     ->where('et_lead.created_by', $staff->sno)
                //     ->whereYear('et_customer.created_at', $year)
                //     ->whereMonth('et_customer.created_at', $month)
                //     ->whereDay('et_customer.created_at', '<=', 15)
                //     ->count();
                    
                    $currentMonthCustomer = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                     ->whereRaw('et_payment.transaction_date = (
                                         SELECT MIN(ep.transaction_date)
                                         FROM et_payment ep
                                         WHERE ep.customer_id = et_customer.sno
                                     )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->orderBy('et_customer.sno', 'asc')
                            ->get();
                      
                      
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                     $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                 ->whereRaw('et_payment.sno = (
                                     SELECT ep.sno
                                     FROM et_payment ep
                                     WHERE ep.customer_id = et_customer.sno
                                     ORDER BY ep.transaction_date ASC, ep.sno ASC
                                     LIMIT 1
                                 )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_lead.created_by', $staff->staff_id)
                         ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereDay('et_payment.transaction_date', '<=', 15)
                        ->count();
                    
                    //   return $currentMonthCustomer;
                    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                        // foreach ($currentMonthCustomer as $customer) {
                    
                        //     // First: check if this customer has TESBO training
                        //     $hasTesbo = DB::table('et_training')
                        //         ->where('customer_id', $customer->sno)
                        //         ->where('branch_id', $branchId)
                        //         ->whereMonth('created_at', $month)
                        //         ->whereYear('created_at', $year)
                        //         ->where('tesbo_check', 2)
                        //         ->where('post_sale_check', '!=', 1)
                        //         ->exists();
                    
                        //     if ($hasTesbo) {
                        //         $tesboCount++;
                        //         continue; // skip crash/professional check if TESBO already counted
                        //     }
                    
                        //     // Then: check if customer has valid Professional or Crash training (not tesbo)
                        //     $nonTesboTrainings = DB::table('et_training')
                        //         ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                        //         ->where('et_training.customer_id', $customer->sno)
                        //         ->where('et_training.branch_id', $branchId)
                        //         ->whereMonth('et_training.created_at', $month)
                        //         ->whereYear('et_training.created_at', $year)
                        //         ->where('et_training.post_sale_check', '!=', 1)
                        //         ->where('et_training.tesbo_check', '!=', 2)
                        //         ->whereIn('et_course.course_type_id', [3, 4])
                        //         ->select('et_course.course_type_id')
                        //         ->get();
                    
                        //     $hasCrash = false;
                        //     $hasProfession = false;
                    
                        //     foreach ($nonTesboTrainings as $training) {
                        //         if ($training->course_type_id == 3) {
                        //             $hasProfession = true;
                        //         } elseif ($training->course_type_id == 4) {
                        //             $hasCrash = true;
                        //         }
                        //     }
                    
                        //     if ($hasCrash) $crashCount++;
                        //     if ($hasProfession) $professionCount++;
                        // }
                    
                        // $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                        $courseTypeTotal = 0;
                    }
                    // return $crashCount;
                    // spot incentive 
                    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalcours) * 100 : 0;
                    $professionPercent = $incentive->si_profession_course > 0 ? ($totalcours / $professinal_coures_total) * 100 : 0;
                    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalcours) * 100 : 0;
                    
                    $crashTarget = $incentive->si_crash_course ?? 0;
                    $professionTarget = $incentive->si_profession_course ?? 0;
                    $tesboTarget = $incentive->si_tesbo_course ?? 0;
                    
                    // only condition: Crash must be ≤ target
                    $siStatus = $crashPercent <= $crashTarget;
                    
                  
                    
                    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                              
                                 $trainings = DB::table('et_proposal as t1')
                                        ->join(DB::raw('(
                                            SELECT MIN(sno) as min_sno
                                            FROM et_proposal
                                            WHERE post_sale_check = 0
                                            GROUP BY customer_id
                                        ) as t2'), 't1.sno', '=', 't2.min_sno')
                                        ->where('t1.customer_id', $customer->sno)
                                        ->select('t1.sno', 't1.customer_id',    't1.total_amount')
                                        ->get();
                            
                                    foreach ($trainings as $training) {
                                         // Determine course_id based on tesbo_check
                                        $course_id = null;
                                
                                        if (!$course_id) continue; // Skip if no course_id
                                
                                        $course = ManageCoursesModel::where('sno', $course_id)
                                            ->whereIn('course_type_id', [2, 3])
                                            ->first();
                                
                                        if (!$course) continue;
                                    $basePrice = $course->course_min_price;
                                    $soldPrice = $training->overall_fees;
                                    $profitAmount = $soldPrice - $basePrice;
                                    
                                    // if ($profitAmount > 0) {
                                        
                                       $originalAmount += $profitAmount; 
        
                                       $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                                      // return $pi_slabs;
                                        // Match against PI slabs
                                        foreach ($pi_slabs as $slab) {
                                            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                                $slabPercentage = $slab['percentage'];
                                                $rewardFromThis = ($originalAmount * $slabPercentage) / 100;
                        
                                                $piRewards = $rewardFromThis > 0 ? $rewardFromThis : 0;
                                                $piPercentage = $profitPercent;
                                                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                                break; // first matching slab
                                            }
                                        }
                                    // }
                                }
                            }
                        
                        
                    }
               $base_amount_paid=0;
                $gst_percent = 18;
                if ($currentMonthCustomer->isNotEmpty()) {
                  foreach ($currentMonthCustomer as $customer) {
                                $proposal_ids = DB::table('et_proposal')
                                    ->where('et_proposal.customer_id', $customer->sno)
                                    ->where('et_proposal.status', 0)
                                    ->whereNot('et_proposal.post_sale_check', 1)
                                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                    ->pluck('sno')
                                    ->toArray();
                                    // return $proposal_ids;
                        
                                $proposals = DB::table('et_proposal')
                                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                    ->whereIn('et_proposal.sno', $proposal_ids)
                                    ->get();
                        
                                foreach ($proposals as $proposal) {
                                    // Paid slots for this proposal
                                    $paidAmount = DB::table('et_proposal_pay_slot')
                                        ->where('proposal_sno', $proposal->sno)
                                        ->where('status', 0)
                                        ->sum('paidAmount');
                        
                                    $grantAmount = $proposal->grant_total_amount;
                        
                                    // First remove GST from paidAmount (base value in proposal's currency)
                                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                        
                                    if ($proposal->currency_id == 70) {
                                        // INR: add directly
                                        $total_paid_payment += $paidAmount;
                                        $total_payment += $grantAmount;
                                        $base_amount_paid += $basePaidLocal;
                                    } else {
                                        // Non-INR: convert both amounts and base value
                                        $currency_code = $proposal->currency_code;
                                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                    }
                                }
                            }
                }
                 // ECI Logic
                $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                $eciActualPercentage = number_format($eciActualPercentage, 2);
                $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
    
                // average 
                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
        
                // $totalAllPayment += $total_payment;
                // $totalAllPaidPayment += $total_paid_payment;
              }
              
               $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                

                    
            
                $convertedToday = 0;
                $convertedMonth = 0;
                $convertedOldMonth = 0;
            
                foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                            // include call count
                        // if ($customerDate ===  $leadDate && $call_count ===  1) {
                        //     $convertedToday++;
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     $leadDate >= $startOfMonth && $leadDate <= $dates &&
                        //     $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //         $callDate = Carbon::parse($call->call_start_date);
                        //         return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        //     })
                            
                        // ) {
                        //     $convertedMonth++;
                        //     $customerMobiles[] = $mobile; 
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     ($leadDate < $startOfMonth || $leadDate > $dates)
                        // ) {
                        //     $convertedOldMonth++;
                        // }
                        $customerData = [
                            'customerDate' => $customerDate,
                            'leadDate'     => $leadDate,
                            'mobile'       => $mobile
                        ];
                        if ($customerDate ===  $leadDate) {
                            $convertedToday++;
                            //   $customerDetails[] = $customerData; 
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates
                        ) {
                            $convertedMonth++;
                           
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                
                $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                // Old month = always 0
                $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
              
                // 10x award calculation       
                $actualConversion      = $customerConvertCount;
                $actualABV             = $averageBusinessValue ?? 0;
                $actualACV             = $averageCollectionValue ?? 0;
               
               
                 $tenxStatus = (
                    $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    $actualConversion >= $targetConversion 
                );
               // bi award calculation  
                $biPerConversion = $incentive->bi_amount ?? 0;
                $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                
                $biReward = $biAchievedCount * $biPerConversion;
                $biStatus = $biAchievedCount > 0;
                
                
                return [
        
                    'incentives' => [
                       'tenx_award' => [
                            'target' => "{$targetConversion}, {$targetABV}, {$targetACV}",
                            'actual' => " {$actualConversion}, " . round($actualABV) . ", " . round($actualACV) .
                                ' <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                    <i class="mdi mdi-help-circle text-dark"></i>
                                </label>',
                            'status' => $tenxStatus,
                            'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                        ],
                    
                        'eci' => [
                            'target' => $eciTargetPercentage . '%',
                            'actual' => round($eciActualPercentage, 1) . '%'. ' <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                            'status' => $eciStatus,
                            'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                        ],
                    
                        'bi' => [
                            'target' => "{$targetConversion} - {$actualConversion} = ({$biAchievedCount})",
                            'actual' => "{$biAchievedCount} × {$biPerConversion}",
                            'status' =>  $biStatus,
                            'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                        ],
                    
                        'si' => [
                            'target' => "{$crashTarget}:{$professionTarget}:{$tesboTarget}",
                            'actual' => round($crashPercent) . '%'. ':' . round($professionPercent) . '%'. ':' . round($tesboPercent). '%',
                            'status' => $tenxStatus && $siStatus,
                            'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                        ],
                    
                        'pi' => [
                            'target' => $matchedSlab . round($slabPercentage, 2) . '%' ?? 'No Matching Slab',
                            'actual' => round($piPercentage, 2) . '%' . '₹'. $originalAmount,
                            'status' => $piReward > 0,
                            'reward' => ($tenxStatus && $piReward > 0)
                                ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                : 0,
                        ],
                    
                        'sp' => [
                            'target' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . '</td></tr>
                                    
                                </table>
                            ',
                            'actual' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</td></tr>
                                    
                                </table>
                            ',
                            'status' => $tenxStatus && $spotTotalReward > 0,
                            'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
                        ],
    
                    
                        'li' => [
                            'target' => 'All Incentives Achieved',
                            'actual' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
                                ? 'Achieved'
                                : 'Not Achieved',
                            'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus),
                            'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
                                ? ($luxury['reward'] ?? 0)
                                : 0,
                                ]
                     ]
                ];
                
    }
    
    
    //  public function getConvertedCustomers(Request $request)
    // {
    //     $staffId   = $request->query('staff_id');
    //     $monthRaw  = $request->query('month');
    //     $year      = $request->query('year');
    //     $branchId  = $request->query('branch_id');
    
    //     if (!$staffId || !$monthRaw || !$year || !$branchId) {
    //         return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    //     }
    
    //     // Convert month name or number into intege
    //     $month = is_numeric($monthRaw)
    //         ? (int)$monthRaw
    //         : (int)date('m', strtotime($monthRaw . ' 1'));
    
    //     // Previous month and year
    //     $currentMonthStart = Carbon::createFromDate($year, $month, 1);
    //     $prevMonthStart = $currentMonthStart->copy()->subMonth();
    //     $prevMonth = $prevMonthStart->month;
    //     $prevYear  = $prevMonthStart->year;
   
    //     // 1. Get all converted customers this month (for detailed listing)
    //      $customerConvertThisMonth = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.cus_mobile', 'et_payment.transaction_date as created_date','et_transaction.payment_id','et_transaction.sno as transaction_id','et_payment.paid_amount')->whereIn('et_customer.status',[0,6])
    //               ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //                 ->whereIn('et_customer.status',[0,6])
    //                 ->join('et_payment', function($join) {
    //                     $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                          ->whereRaw('et_payment.sno = (
    //                              SELECT ep.sno
    //                              FROM et_payment ep
    //                              WHERE ep.customer_id = et_customer.sno
    //                              ORDER BY ep.transaction_date ASC, ep.sno ASC
    //                              LIMIT 1
    //                          )');
    //                 })
    //                 ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //                 ->where('et_customer.branch_id', $branchId)
    //                 ->where('et_lead.created_by', $staffId)
    //                 ->whereYear('et_payment.transaction_date', $year)
    //                 ->whereMonth('et_payment.transaction_date', $month)
    //                 ->where('et_transaction.payment_status', 1)
    //                 ->orderBy('et_customer.sno', 'asc')
    //                 ->get();
    //     // return $customerConvertThisMonth;
    //     // return $customerConvertThisMonth;
    //     // 1a. For current month low MBC checks only take records from 1st to 25th
    //     // (Assuming your DB supports the DAY() function; adjust if needed)
    //      $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
    //           ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //             ->whereIn('et_customer.status',[0,6])
    //             ->join('et_payment', function($join) {
    //                 $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                      ->whereRaw('et_payment.sno = (
    //                          SELECT ep.sno
    //                          FROM et_payment ep
    //                          WHERE ep.customer_id = et_customer.sno
    //                          ORDER BY ep.transaction_date ASC, ep.sno ASC
    //                          LIMIT 1
    //                      )');
    //             })
    //             ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_customer.branch_id', $branchId)
    //             ->where('et_lead.created_by', $staffId)
    //             ->whereYear('et_payment.transaction_date', $year)
    //             ->whereMonth('et_payment.transaction_date', $month)
    //             ->where('et_transaction.payment_status', 1)
    //              ->pluck('et_customer.sno')
    //             ->toArray();
                
    //              $customer_first_pay_slot_id = CustomerModel::whereIn('et_customer.status',[0,6])
    //               ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //                 ->whereIn('et_customer.status',[0,6])
    //                 ->join('et_payment', function($join) {
    //                     $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                          ->whereRaw('et_payment.sno = (
    //                              SELECT ep.sno
    //                              FROM et_payment ep
    //                              WHERE ep.customer_id = et_customer.sno
    //                              ORDER BY ep.transaction_date ASC, ep.sno ASC
    //                              LIMIT 1
    //                          )');
    //                 })
    //                 ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //                 ->where('et_customer.branch_id', $branchId)
    //                 ->where('et_lead.created_by', $staffId)
    //                 ->whereYear('et_payment.transaction_date', $year)
    //                 ->whereMonth('et_payment.transaction_date', $month)
    //                 ->where('et_transaction.payment_status', 1)
    //                  ->pluck('et_payment.pay_slot_id')
    //                 ->toArray();
                
    //              $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
    //             ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //             ->where('et_staff.branch_id', $branchId)
    //             ->where('et_staff.sno', $staffId)
    //             ->first();
      
    //     // 2. Get previous month converted customers (with staff details)
    //     $prevMonthCustomerIdscus = CustomerModel::whereIn('et_customer.status',[0,6])
    //     ->select(
    //                 'et_customer.sno',
    //                 'et_customer.cus_name',
    //                 'et_payment.transaction_date as created_at',
    //                 'et_customer.cus_mobile',
    //                 'et_staff.staff_name',
    //                 'et_staff.staff_image',
    //                 'et_proposal.proposal_id',
    //                 'et_department.department_name'
    //             )
    //       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
           
    //         ->whereIn('et_customer.status',[0,6])
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                  ->whereRaw('et_payment.transaction_date = (
    //                      SELECT MIN(ep.transaction_date)
    //                      FROM et_payment ep
    //                      WHERE ep.customer_id = et_customer.sno
    //                  )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
    //         ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
    //         ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //         ->where('et_customer.branch_id', $branchId)
    //         ->where('et_lead.created_by', $staffId)
    //         ->whereYear('et_payment.transaction_date', $prevYear)
    //         ->whereMonth('et_payment.transaction_date', $prevMonth)
    //         ->where('et_transaction.payment_status', 1)
    //         ->get();
    
    //     // 3. Get previous month converted customer IDs (for further checks)
       
            
    //          $prevMonthCustomerIds = CustomerModel::whereIn('et_customer.status',[0,6])
    //       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->whereIn('et_customer.status',[0,6])
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                  ->whereRaw('et_payment.transaction_date = (
    //                      SELECT MIN(ep.transaction_date)
    //                      FROM et_payment ep
    //                      WHERE ep.customer_id = et_customer.sno
    //                  )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_customer.branch_id', $branchId)
    //         ->where('et_lead.created_by', $staffId)
    //         ->whereYear('et_payment.transaction_date', $prevYear)
    //         ->whereMonth('et_payment.transaction_date', $prevMonth)
    //         ->where('et_transaction.payment_status', 1)
    //          ->pluck('et_customer.sno')
    //         ->toArray();
    
    //     // 4. First Condition: Dropout for previous month
    //     // $dropoutCustomers = DB::table('et_training')
    //     //     ->whereIn('customer_id', $prevMonthCustomerIds)
    //     //     ->where('status', 2)
    //     //     ->pluck('customer_id')
    //     //     ->toArray();
    //   // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
    //     $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
    //           ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    //             ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    //         ->select('et_payment.customer_id')
    //         ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
    //         ->where('et_proposal_pay_slot.paid_status', 1)
    //         ->groupBy('et_payment.customer_id')
    //         ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(et_proposal_pay_slot.total_amount)')
    //         ->pluck('et_payment.customer_id')
    //         ->toArray();
    //     // return $fullPaidCustomerIds;
    //     // 2. Customers who made a second payment this month
    //     $secondPaymentCustomersmulti =DB::table('et_proposal_pay_slot')
    //           ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
    //             ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    //         ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
    //         ->where('et_proposal_pay_slot.paid_status', 1)
    //         ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
    //         ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
    //         ->pluck('et_payment.customer_id')
    //         ->unique()
    //         ->toArray();
    //         //  return $secondPaymentCustomersmulti;
      
      
    //   $secondPaymentCustomers =   array_values(array_unique(array_merge(
    //             $secondPaymentCustomersmulti,
    //             $fullPaidCustomerIds
    //         )));
    //     // return $secondPaymentCustomers;

    //     // return or use $secondPaymentCustomers

       
    //     // 6. Third Condition: Low MBC (min amount not paid) for previous month
    //     $branch = BranchModel::where('sno', $branchId)->first();
    //     // $dropRefundedIds = DB::table('et_drop_refund')
    //     //     ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
    //     //     ->pluck('et_training.customer_id')
    //     //     ->toArray();
    
    //     $lowMbcCustomerIds = DB::table('et_proposal')
    //         ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
    //         ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    //         ->whereIn('et_proposal.customer_id', $prevMonthCustomerIds)
    //         ->where('et_proposal.branch_id', $branchId)
    //         // ->whereNotIn('et_proposal.customer_id', $dropRefundedIds)
    //         ->where('et_proposal.post_sale_check', 0)
    //         ->whereNotIn('et_proposal.status',[0,2])
    //         // ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
    //         // ->whereRaw('DAY(et_customer.created_at) <= 25')
    //         ->groupBy('et_proposal.customer_id')
    //         ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost ?? 0])
    //         ->pluck('et_proposal.customer_id')
    //         ->toArray();
           
    
    //     // 7. Combine all failed (bad) customers for previous month
    //     $badCustomerIdsPrev = array_unique(array_merge(
    //         // $dropoutCustomers,
    //         array_diff($prevMonthCustomerIds, $secondPaymentCustomers),
    //         $lowMbcCustomerIds
    //     ));
    
    //     // Now, for current month details: Using low MBC check for 1st to 25th only.
    //     // a. Dropout in current month (based on current-customer IDs filtered above)
    //     // $dropoutCustomersCurrent = DB::table('et_proposal')
    //     //     ->whereIn('customer_id', $prevMonthCustomerIdsCurrent)
    //     //     ->where('status', 2)
    //     //     ->pluck('customer_id')
    //     //     ->toArray();
    
    //     // b. Low MBC in current month (add the day limitation in the customer join above)
    //     $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
    //         // ->join('et_payment', 'et_payment.payment_id', '=', 'et_training.payment_id')
    //         ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
    //         ->whereIn('et_proposal.customer_id', $prevMonthCustomerIdsCurrent)
    //         // ->where('et_payment.branch_id', $branchId)
    //         // ->whereNotIn('et_training.customer_id', $dropoutCustomersCurrent)
    //         ->whereNotIn('et_proposal.status',[0,2])
    //         ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
    //         ->whereRaw('DAY(et_proposal.created_at) <= 25')
    //         ->groupBy('et_proposal.customer_id')
    //         ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost])
    //         ->pluck('et_proposal.customer_id')
    //         ->toArray();
    //         // return $lowMbcCustomerIdsCurrent;
    //     $lowMbcCustomerIdspay = DB::table('et_payment')
    //         ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
    //         ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
    //         ->whereIn('et_payment.customer_id', $prevMonthCustomerIdsCurrent)
    //         ->whereIn('et_payment.pay_slot_id', $customer_first_pay_slot_id)
    //         ->where('et_proposal.branch_id', $branchId)
    //         // ->whereNotIn('et_training.customer_id', $dropRefundedIds)
    //         ->where('et_customer.status', 0)
    //         ->select(
    //             'et_payment.customer_id',
    //             DB::raw('SUM(DISTINCT et_payment.paid_amount) as total_paid_amount'),
    //             DB::raw('MAX(et_country_currencies.currency_symbol) as currencySymbol'),
    //             DB::raw('MAX(et_proposal.currency_id) as currencyId'),
    //             DB::raw('MAX(et_payment.pay_slot_id) as slotId'),
    //             DB::raw('MAX(et_proposal.proposal_id) as proposalId')
    //         )
    //         ->groupBy('et_payment.customer_id')
    //         ->get()
    //         ->keyBy('customer_id'); // ← keep this as Collection, NOT array
       
  
    //     // Combine current month bad customer IDs (only dropout and low MBC are considered)
    //     $badCustomerIdsCurrent = array_unique(array_merge(
    //         // $dropoutCustomersCurrent,
    //         $lowMbcCustomerIdsCurrent
    //     ));
    //     $dropoutCustomers=[];
    
    //     // 8. Build the final list for previous month with status & reason
    //     $finalDataPrev = $prevMonthCustomerIdscus->map(function ($cus) use ($dropoutCustomers, $secondPaymentCustomers, $lowMbcCustomerIds) {
    //         $reason = null;
    //         // Default: converted (green tick)
    //         $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
    //                             <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
    //                             <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
    //                                 c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
    //                                 c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
    //                         </svg>
    //                     </a>';
    
    //         if (in_array($cus->sno, $dropoutCustomers)) {
    //             $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                             <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                             <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                 c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                 c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                 c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                         </svg>
    //                       </a>';
    //             $reason = 'Dropout in previous month';
    //         } elseif (!in_array($cus->sno, $secondPaymentCustomers)) {
    //             $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                             <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                             <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                 c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                 c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                 c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                         </svg>
    //                       </a>';
    //             $reason = 'No second payment in current month';
    //         } elseif (in_array($cus->sno, $lowMbcCustomerIds)) {
    //             $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                             <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                             <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                 c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                 c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                 c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                         </svg>
    //                       </a>';
    //             $reason = 'Paid below low MBC';
    //         }
    //         $country_code_prev =$cus->country_code ==0 ? '91' :  $cus->country_code;
    //          $cusMobile_prev = $country_code_prev . ''. $cus->cus_mobile;
    //          $proposal_id_prev=$cus->proposal_id ?? '-';
    //         return [
    //             'customer_name' => $cus->cus_name,
    //             'mobile'        => $cusMobile_prev,
    //             'month'         => Carbon::parse($cus->created_at)->format('F Y'),
    //             'status'        => $status,
    //             'reason'        => $reason ?? 'Successfully Paid MPC And Second Payment',
    //             'staff_name'    => $cus->staff_name,
    //             'staff_image'   => $cus->staff_image,
    //             'department_name'=> $cus->department_name,
    //             'proposalId'=>$proposal_id_prev ,
    //         ];
    //     })->values();
    // $dropoutCustomersCurrent=[];
    //     // 9. Build the final list for current month details with status & reason
    //     $finalDataCurrent = $customerConvertThisMonth->map(function ($cus) use ($dropoutCustomersCurrent, $lowMbcCustomerIdsCurrent,$lowMbcCustomerIdspay) {
    //         $reason = null;
    //         // Default status: converted
    //         $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
    //                             <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
    //                             <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
    //                                 c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
    //                                 c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
    //                         </svg>
    //                     </a>';
    //           $amount = $lowMbcCustomerIdspay->get($cus->sno)?->total_paid_amount ?? 0;
    //           $proposal_id = $lowMbcCustomerIdspay->get($cus->sno)?->proposalId ?? '-';
    //           $currencySymbol = $lowMbcCustomerIdspay->get($cus->sno)?->currencySymbol ?? '₹';
    //           $currencyId = $lowMbcCustomerIdspay->get($cus->sno)?->currencyId ?? 70;
    //           $country_code =$cus->country_code ==0 ? '91' :  $cus->country_code;
    //           $cusMobile = $country_code . ''. $cus->cus_mobile;
    
    //         if (in_array($cus->sno, $dropoutCustomersCurrent)) {
    //             $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                             <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                             <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                 c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                 c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                 c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                         </svg>
    //                       </a>';
    //             $reason = 'Dropout in current month';
    //         } elseif (in_array($cus->sno, $lowMbcCustomerIdsCurrent)) {
    //             $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                             <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                             <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                 c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                 c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                 c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                         </svg>
    //                       </a>';
    //             $reason = 'Paid below low MBC (1st-25th day)';
    //         }
    
    //         return [
    //             'customer_name' => $cus->cus_name,
    //             'mobile'        => $cusMobile,
    //             'month'         => Carbon::parse($cus->created_at)->format('F Y'),
    //             'amount'        => $amount,
    //             'proposalId'        => $proposal_id,
    //             'currencySymbol'        => $currencySymbol,
    //             'currencyId'        => $currencyId,
    //             'status'        => $status,
    //             'reason'        => $reason ?? 'Successfully Paid MPC Value'
    //         ];
    //     })->values();
    
    //     // 10. Build summary counts for display
    //     $prevMonthSummary = [
    //         'second_payment_total' => count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($dropoutCustomers) - count($lowMbcCustomerIds),
    //         'lmbc_total'           => count($lowMbcCustomerIds),
    //         'drop_count_total'     => count($dropoutCustomers),
    //         'converted_total'      => count($prevMonthCustomerIds)
    //     ];
      
       
    //     $minuscustold =  count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($lowMbcCustomerIds) - count($dropoutCustomers);
    //      $minus_value =  $minuscustold + count($lowMbcCustomerIdsCurrent) + count($dropoutCustomersCurrent) + count($dropoutCustomers);
    //     $finalCustomer = count($prevMonthCustomerIdsCurrent) - $minus_value;
    //     $currentMonthSummary = [
    //          'minus_value'             => $minus_value,
    //          'final_value'             => $finalCustomer > 0 ? $finalCustomer :0,
    //         'lmbc_total_current'   => count($lowMbcCustomerIdsCurrent),
    //         'drop_count_current'   => count($dropoutCustomersCurrent),
    //         'converted_total_current' => count($prevMonthCustomerIdsCurrent)
    //     ];
    
    //     return response()->json([
    //         'staff_data'       => $StaffData,
    //         'data_prev'       => $finalDataPrev,
    //         'data_current'    => $finalDataCurrent,
    //         'summary_prev'    => $prevMonthSummary,
    //         'summary_current' => $currentMonthSummary,
    //     ]);
    // }

    public function getConvertedCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }


        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name','et_staff.role_id')->where('et_staff.status',0)
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_staff.branch_id', $branchId)
                ->where('et_staff.sno', $staffId)
                ->first();
    
        // Convert month name or number into intege
        $month = is_numeric($monthRaw)
            ? (int)$monthRaw
            : (int)date('m', strtotime($monthRaw . ' 1'));
    
        // Previous month and year
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $prevMonthStart = $currentMonthStart->copy()->subMonth();
        $prevMonth = $prevMonthStart->month;
        $prevYear  = $prevMonthStart->year;

        $incentive = IncentiveModel::where('role_id', $StaffData->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();

        if( $StaffData->role_id == 35){
                

                $customerConvertThisMonth = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.cus_name', 'et_customer.country_code',  'et_customer.cus_mobile', 'et_payment.transaction_date as created_date','et_payment.transaction_date as created_at','et_transaction.payment_id','et_transaction.sno as transaction_id','et_payment.paid_amount')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->get();
                    $proposalIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal_pay_slot.branch_id', $branchId)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->havingRaw('COUNT(et_proposal_pay_slot.proposal_sno) = 1')
                    ->pluck('et_proposal_pay_slot.proposal_sno');

                    //  $proposalPaidIds = DB::table('et_proposal_pay_slot')
                    //     ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    //     ->where('et_proposal.status', 0)
                    //     ->where('et_proposal_pay_slot.status', 0)
                    //     ->where('et_proposal_pay_slot.branch_id', $branchId)
                    //     ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    //     ->groupBy('et_proposal_pay_slot.proposal_sno')
                    //     ->havingRaw('COUNT(et_proposal_pay_slot.proposal_sno) > 1')
                    //     ->havingRaw('SUM(CASE WHEN et_proposal_pay_slot.paid_status = 1 THEN 1 ELSE 0 END) > 0')
                    //     ->pluck('et_proposal_pay_slot.proposal_sno');

                        $proposalPaidIds = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal_pay_slot.status', 0)
                        ->where('et_proposal_pay_slot.branch_id', $branchId)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->groupBy('et_proposal_pay_slot.proposal_sno')
                         ->havingRaw('COUNT(et_proposal_pay_slot.proposal_sno) = SUM(CASE WHEN et_proposal_pay_slot.paid_status = 1 THEN 1 ELSE 0 END)')
                        ->pluck('et_proposal_pay_slot.proposal_sno');

            //             ->havingRaw('COUNT(et_proposal_pay_slot.proposal_sno) = 
            //  SUM(CASE WHEN et_proposal_pay_slot.paid_status = 1 THEN 1 ELSE 0 END)')
                
            // return $customerConvertThisMonth;
            // return $customerConvertThisMonth;
            // 1a. For current month low MBC checks only take records from 1st to 25th
            // (Assuming your DB supports the DAY() function; adjust if needed)
            $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_customer.branch_id', $branchId)
                ->where('et_proposal.created_by', $staffId)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->where('et_proposal.status',0)
                ->orderBy('et_proposal.sno', 'asc')
                 ->pluck('et_customer.sno')
                ->toArray();

                
                
                 $customer_first_pay_slot_id = CustomerModel::whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function ($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', $staffId)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                     ->pluck('et_payment.pay_slot_id')
                    ->toArray();
                
                 
      
                // 2. Get previous month converted customers (with staff details)
                $prevMonthCustomerIdscus = CustomerModel::whereIn('et_customer.status',[0,6])
                ->select(
                        'et_customer.sno',
                        'et_customer.cus_name',
                        'et_payment.transaction_date as created_at',
                        'et_customer.cus_mobile',
                        'et_staff.staff_name',
                        'et_staff.staff_image',
                        'et_proposal.proposal_id',
                        'et_department.department_name'
                    )
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                            ->whereRaw('et_payment.transaction_date = (
                                SELECT MIN(ep.transaction_date)
                                FROM et_payment ep
                                WHERE ep.proposal_id = et_proposal.sno
                            )');
                    })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_customer.status', 0)
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_customer.branch_id', $branchId)
                ->where('et_proposal.created_by', $staffId)
                ->whereNotIn('et_proposal.sno', $proposalIds)
                ->whereNotIn('et_proposal.sno', $proposalPaidIds)
                ->whereYear('et_payment.transaction_date', $prevYear)
                ->whereMonth('et_payment.transaction_date', $prevMonth)
                ->where('et_transaction.payment_status', 1)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->where('et_proposal.status',0)
                ->orderBy('et_proposal.sno', 'asc')
                ->get();
    
                // 3. Get previous month converted customer IDs (for further checks)
       
            
                $prevMonthCustomerIds = CustomerModel::whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                     ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                   ->where('et_customer.status', 0)
                    ->where('et_customer.post_sale_check', 1)
                    ->where('et_proposal.post_sale_check', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_proposal.created_by', $staffId)
                    ->whereNotIn('et_proposal.sno', $proposalIds)
                    ->whereNotIn('et_proposal.sno', $proposalPaidIds)
                    ->whereYear('et_payment.transaction_date', $prevYear)
                    ->whereMonth('et_payment.transaction_date', $prevMonth)
                    ->where('et_transaction.payment_status', 1)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->where('et_proposal.status',0)
                    ->orderBy('et_proposal.sno', 'asc')
                    ->pluck('et_customer.sno')
                    ->toArray();
    
                // 4. First Condition: Dropout for previous month
                // $dropoutCustomers = DB::table('et_training')
                //     ->whereIn('customer_id', $prevMonthCustomerIds)
                //     ->where('status', 2)
                //     ->pluck('customer_id')
                //     ->toArray();
                // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->select('et_payment.customer_id')
                ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->groupBy('et_payment.customer_id')
                ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(et_proposal_pay_slot.total_amount)')
                ->pluck('et_payment.customer_id')
                ->toArray();
                // return $fullPaidCustomerIds;
                // 2. Customers who made a second payment this month
                $secondPaymentCustomersmulti =DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
                    ->where('et_proposal_pay_slot.paid_status', 1)
                    ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                    ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                    ->pluck('et_payment.customer_id')
                    ->unique()
                    ->toArray();
                //  return $secondPaymentCustomersmulti;
        
        
                $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));
            // return $secondPaymentCustomers;

            // return or use $secondPaymentCustomers

        
            // 6. Third Condition: Low MBC (min amount not paid) for previous month
            $branch = BranchModel::where('sno', $branchId)->first();
            // $dropRefundedIds = DB::table('et_drop_refund')
            //     ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
            //     ->pluck('et_training.customer_id')
            //     ->toArray();
        
            $lowMbcCustomerIds = DB::table('et_proposal')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->whereIn('et_proposal.customer_id', $prevMonthCustomerIds)
                ->where('et_proposal.branch_id', $branchId)
                // ->whereNotIn('et_proposal.customer_id', $dropRefundedIds)
                ->where('et_proposal.post_sale_check', 0)
                ->whereNotIn('et_proposal.status',[0,2])
                // ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
                // ->whereRaw('DAY(et_customer.created_at) <= 25')
                ->groupBy('et_proposal.customer_id')
                ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost ?? 0])
                ->pluck('et_proposal.customer_id')
                ->toArray();
            
        
            // 7. Combine all failed (bad) customers for previous month
            $badCustomerIdsPrev = array_unique(array_merge(
                // $dropoutCustomers,
                array_diff($prevMonthCustomerIds, $secondPaymentCustomers),
                $lowMbcCustomerIds
            ));
        
            // Now, for current month details: Using low MBC check for 1st to 25th only.
            // a. Dropout in current month (based on current-customer IDs filtered above)
            // $dropoutCustomersCurrent = DB::table('et_proposal')
            //     ->whereIn('customer_id', $prevMonthCustomerIdsCurrent)
            //     ->where('status', 2)
            //     ->pluck('customer_id')
            //     ->toArray();
        
            // b. Low MBC in current month (add the day limitation in the customer join above)
            $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
                // ->join('et_payment', 'et_payment.payment_id', '=', 'et_training.payment_id')
                ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->whereIn('et_proposal.customer_id', $prevMonthCustomerIdsCurrent)
                // ->where('et_payment.branch_id', $branchId)
                // ->whereNotIn('et_training.customer_id', $dropoutCustomersCurrent)
                ->whereNotIn('et_proposal.status',[0,2])
                ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
                ->whereRaw('DAY(et_proposal.created_at) <= 25')
                ->groupBy('et_proposal.customer_id')
                ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost])
                ->pluck('et_proposal.customer_id')
                ->toArray();
                // return $lowMbcCustomerIdsCurrent;
            $lowMbcCustomerIdspay = DB::table('et_payment')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->whereIn('et_payment.customer_id', $prevMonthCustomerIdsCurrent)
                ->whereIn('et_payment.pay_slot_id', $customer_first_pay_slot_id)
                ->where('et_proposal.branch_id', $branchId)
                // ->whereNotIn('et_training.customer_id', $dropRefundedIds)
                ->where('et_customer.status', 0)
                ->select(
                    'et_payment.customer_id',
                    DB::raw('SUM(DISTINCT et_payment.paid_amount) as total_paid_amount'),
                    DB::raw('MAX(et_country_currencies.currency_symbol) as currencySymbol'),
                    DB::raw('MAX(et_proposal.currency_id) as currencyId'),
                    DB::raw('MAX(et_payment.pay_slot_id) as slotId'),
                    DB::raw('MAX(et_proposal.proposal_id) as proposalId')
                )
                ->groupBy('et_payment.customer_id')
                ->get()
                ->keyBy('customer_id'); // ← keep this as Collection, NOT array
        
    
            // Combine current month bad customer IDs (only dropout and low MBC are considered)
            $badCustomerIdsCurrent = array_unique(array_merge(
                // $dropoutCustomersCurrent,
                $lowMbcCustomerIdsCurrent
            ));
            $dropoutCustomers=[];
        
            // 8. Build the final list for previous month with status & reason
            $finalDataPrev = $prevMonthCustomerIdscus->map(function ($cus) use ($dropoutCustomers, $secondPaymentCustomers, $lowMbcCustomerIds) {
                $reason = null;
                // Default: converted (green tick)
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                    <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                    <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                        c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                        c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                </svg>
                            </a>';
        
                if (in_array($cus->sno, $dropoutCustomers)) {
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                    $reason = 'Dropout in previous month';
                } elseif (!in_array($cus->sno, $secondPaymentCustomers)) {
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                    $reason = 'No second payment in current month';
                } elseif (in_array($cus->sno, $lowMbcCustomerIds)) {
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                    $reason = 'Paid below low MBC';
                }
                $country_code_prev =$cus->country_code ==0 ? '91' :  $cus->country_code;
                $cusMobile_prev = $country_code_prev . ''. $cus->cus_mobile;
                $proposal_id_prev=$cus->proposal_id ?? '-';
                return [
                    'customer_name' => $cus->cus_name,
                    'mobile'        => $cusMobile_prev,
                    'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                    'status'        => $status,
                    'reason'        => $reason ?? 'Successfully Paid MPC And Second Payment',
                    'staff_name'    => $cus->staff_name,
                    'staff_image'   => $cus->staff_image,
                    'department_name'=> $cus->department_name,
                    'proposalId'=>$proposal_id_prev ,
                ];
            })->values();
            $dropoutCustomersCurrent=[];
            // 9. Build the final list for current month details with status & reason
            $finalDataCurrent = $customerConvertThisMonth->map(function ($cus) use ($dropoutCustomersCurrent, $lowMbcCustomerIdsCurrent,$lowMbcCustomerIdspay) {
                $reason = null;
                // Default status: converted
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                    <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                    <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                        c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                        c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                </svg>
                            </a>';
                $amount = $lowMbcCustomerIdspay->get($cus->sno)?->total_paid_amount ?? 0;
                $proposal_id = $lowMbcCustomerIdspay->get($cus->sno)?->proposalId ?? '-';
                $currencySymbol = $lowMbcCustomerIdspay->get($cus->sno)?->currencySymbol ?? '₹';
                $currencyId = $lowMbcCustomerIdspay->get($cus->sno)?->currencyId ?? 70;
                $country_code =$cus->country_code ==0 ? '91' :  $cus->country_code;
                $cusMobile = $country_code . ''. $cus->cus_mobile;
        
                if (in_array($cus->sno, $dropoutCustomersCurrent)) {
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                    $reason = 'Dropout in current month';
                } elseif (in_array($cus->sno, $lowMbcCustomerIdsCurrent)) {
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                    $reason = 'Paid below low MBC (1st-25th day)';
                }
        
                return [
                    'customer_name' => $cus->cus_name,
                    'mobile'        => $cusMobile,
                    'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                    'amount'        => $amount,
                    'proposalId'        => $proposal_id,
                    'currencySymbol'        => $currencySymbol,
                    'currencyId'        => $currencyId,
                    'status'        => $status,
                    'reason'        => $reason ?? 'Successfully Paid MPC Value'
                ];
            })->values();

            // return count($secondPaymentCustomers);
            // 10. Build summary counts for display
            $prevMonthSummary = [
                'second_payment_total' => count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($dropoutCustomers) - count($lowMbcCustomerIds),
                'lmbc_total'           => count($lowMbcCustomerIds),
                'drop_count_total'     => count($dropoutCustomers),
                'converted_total'      => count($prevMonthCustomerIds)
            ];
        
        
            $minuscustold =  count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($lowMbcCustomerIds) - count($dropoutCustomers);
            $minus_value =  $minuscustold + count($lowMbcCustomerIdsCurrent) + count($dropoutCustomersCurrent) + count($dropoutCustomers);
            $finalCustomer = count($prevMonthCustomerIdsCurrent) - $minus_value;
            $currentMonthSummary = [
                'minus_value'             => $minus_value,
                'final_value'             => $finalCustomer > 0 ? $finalCustomer :0,
                'lmbc_total_current'   => count($lowMbcCustomerIdsCurrent),
                'drop_count_current'   => count($dropoutCustomersCurrent),
                'converted_total_current' => count($prevMonthCustomerIdsCurrent)
            ];

                    
        }else{
            // 1. Get all converted customers this month (for detailed listing)
            $customerConvertThisMonth = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.cus_mobile', 'et_payment.transaction_date as created_date','et_transaction.payment_id','et_transaction.sno as transaction_id','et_payment.paid_amount')->whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->whereIn('et_customer.status',[0,6])
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.sno = (
                                    SELECT ep.sno
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                    ORDER BY ep.transaction_date ASC, ep.sno ASC
                                    LIMIT 1
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->orderBy('et_customer.sno', 'asc')
                        ->get();


                         $proposalIds = DB::table('et_proposal_pay_slot')
                            ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                            ->where('et_proposal.status', 0)
                            ->where('et_proposal_pay_slot.status', 0)
                            ->where('et_proposal_pay_slot.branch_id', $branchId)
                            ->whereNotIn('et_proposal.proposal_status', [0, 2])
                            ->groupBy('et_proposal_pay_slot.proposal_sno')
                            ->havingRaw('COUNT(et_proposal_pay_slot.proposal_sno) = 1')
                            ->pluck('et_proposal_pay_slot.proposal_sno');
            // return $customerConvertThisMonth;
            // return $customerConvertThisMonth;
            // 1a. For current month low MBC checks only take records from 1st to 25th
            // (Assuming your DB supports the DAY() function; adjust if needed)
            $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status',[0,6])
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staffId)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->pluck('et_customer.sno')
                    ->toArray();
                    
                    $customer_first_pay_slot_id = CustomerModel::whereIn('et_customer.status',[0,6])
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->whereIn('et_customer.status',[0,6])
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.sno = (
                                    SELECT ep.sno
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                    ORDER BY ep.transaction_date ASC, ep.sno ASC
                                    LIMIT 1
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->pluck('et_payment.pay_slot_id')
                        ->toArray();
                    
                    
        
            // 2. Get previous month converted customers (with staff details)
            $prevMonthCustomerIdscus = CustomerModel::whereIn('et_customer.status',[0,6])
            ->select(
                        'et_customer.sno',
                        'et_customer.cus_name',
                        'et_payment.transaction_date as created_at',
                        'et_customer.cus_mobile',
                        'et_staff.staff_name',
                        'et_staff.staff_image',
                        'et_proposal.proposal_id',
                        'et_department.department_name'
                    )
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            
                ->whereIn('et_customer.status',[0,6])
                ->join('et_payment', function($join) {
                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereRaw('et_payment.transaction_date = (
                            SELECT MIN(ep.transaction_date)
                            FROM et_payment ep
                            WHERE ep.customer_id = et_customer.sno
                        )');
                })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', $staffId)
                   ->whereNotIn('et_proposal.sno', $proposalIds)
                ->whereYear('et_payment.transaction_date', $prevYear)
                ->whereMonth('et_payment.transaction_date', $prevMonth)
                ->where('et_transaction.payment_status', 1)
                ->get();
        
            // 3. Get previous month converted customer IDs (for further checks)
        
                
                $prevMonthCustomerIds = CustomerModel::whereIn('et_customer.status',[0,6])
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->whereIn('et_customer.status',[0,6])
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $prevYear)
                        ->whereMonth('et_payment.transaction_date', $prevMonth)
                        ->where('et_transaction.payment_status', 1)
                        ->pluck('et_customer.sno')
                        ->toArray();
        
                // 4. First Condition: Dropout for previous month
                // $dropoutCustomers = DB::table('et_training')
                //     ->whereIn('customer_id', $prevMonthCustomerIds)
                //     ->where('status', 2)
                //     ->pluck('customer_id')
                //     ->toArray();
            // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
            $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->select('et_payment.customer_id')
                ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->groupBy('et_payment.customer_id')
                ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(et_proposal_pay_slot.total_amount)')
                ->pluck('et_payment.customer_id')
                ->toArray();
            // return $fullPaidCustomerIds;
            // 2. Customers who made a second payment this month
            $secondPaymentCustomersmulti =DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->pluck('et_payment.customer_id')
                ->unique()
                ->toArray();
                //  return $secondPaymentCustomersmulti;
        
        
            $secondPaymentCustomers =   array_values(array_unique(array_merge(
                        $secondPaymentCustomersmulti,
                        $fullPaidCustomerIds
                    )));
                // return $secondPaymentCustomers;

                // return or use $secondPaymentCustomers

            
                // 6. Third Condition: Low MBC (min amount not paid) for previous month
                $branch = BranchModel::where('sno', $branchId)->first();
                // $dropRefundedIds = DB::table('et_drop_refund')
                //     ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                //     ->pluck('et_training.customer_id')
                //     ->toArray();
            
                $lowMbcCustomerIds = DB::table('et_proposal')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->whereIn('et_proposal.customer_id', $prevMonthCustomerIds)
                    ->where('et_proposal.branch_id', $branchId)
                    // ->whereNotIn('et_proposal.customer_id', $dropRefundedIds)
                    ->where('et_proposal.post_sale_check', 0)
                    ->whereNotIn('et_proposal.status',[0,2])
                    // ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
                    // ->whereRaw('DAY(et_customer.created_at) <= 25')
                    ->groupBy('et_proposal.customer_id')
                    ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost ?? 0])
                    ->pluck('et_proposal.customer_id')
                    ->toArray();
                
            
                // 7. Combine all failed (bad) customers for previous month
                $badCustomerIdsPrev = array_unique(array_merge(
                    // $dropoutCustomers,
                    array_diff($prevMonthCustomerIds, $secondPaymentCustomers),
                    $lowMbcCustomerIds
                ));
            
                // Now, for current month details: Using low MBC check for 1st to 25th only.
                // a. Dropout in current month (based on current-customer IDs filtered above)
                // $dropoutCustomersCurrent = DB::table('et_proposal')
                //     ->whereIn('customer_id', $prevMonthCustomerIdsCurrent)
                //     ->where('status', 2)
                //     ->pluck('customer_id')
                //     ->toArray();
            
                // b. Low MBC in current month (add the day limitation in the customer join above)
                $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
                    // ->join('et_payment', 'et_payment.payment_id', '=', 'et_training.payment_id')
                    ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->whereIn('et_proposal.customer_id', $prevMonthCustomerIdsCurrent)
                    // ->where('et_payment.branch_id', $branchId)
                    // ->whereNotIn('et_training.customer_id', $dropoutCustomersCurrent)
                    ->whereNotIn('et_proposal.status',[0,2])
                    ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
                    ->whereRaw('DAY(et_proposal.created_at) <= 25')
                    ->groupBy('et_proposal.customer_id')
                    ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost])
                    ->pluck('et_proposal.customer_id')
                    ->toArray();
                    // return $lowMbcCustomerIdsCurrent;
                $lowMbcCustomerIdspay = DB::table('et_payment')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereIn('et_payment.customer_id', $prevMonthCustomerIdsCurrent)
                    ->whereIn('et_payment.pay_slot_id', $customer_first_pay_slot_id)
                    ->where('et_proposal.branch_id', $branchId)
                    // ->whereNotIn('et_training.customer_id', $dropRefundedIds)
                    ->where('et_customer.status', 0)
                    ->select(
                        'et_payment.customer_id',
                        DB::raw('SUM(DISTINCT et_payment.paid_amount) as total_paid_amount'),
                        DB::raw('MAX(et_country_currencies.currency_symbol) as currencySymbol'),
                        DB::raw('MAX(et_proposal.currency_id) as currencyId'),
                        DB::raw('MAX(et_payment.pay_slot_id) as slotId'),
                        DB::raw('MAX(et_proposal.proposal_id) as proposalId')
                    )
                    ->groupBy('et_payment.customer_id')
                    ->get()
                    ->keyBy('customer_id'); // ← keep this as Collection, NOT array
            
        
                // Combine current month bad customer IDs (only dropout and low MBC are considered)
                $badCustomerIdsCurrent = array_unique(array_merge(
                    // $dropoutCustomersCurrent,
                    $lowMbcCustomerIdsCurrent
                ));
                $dropoutCustomers=[];
            
                // 8. Build the final list for previous month with status & reason
                $finalDataPrev = $prevMonthCustomerIdscus->map(function ($cus) use ($dropoutCustomers, $secondPaymentCustomers, $lowMbcCustomerIds) {
                    $reason = null;
                    // Default: converted (green tick)
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                        <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                        <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                            c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                            c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                    </svg>
                                </a>';
            
                    if (in_array($cus->sno, $dropoutCustomers)) {
                        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                    </svg>
                                </a>';
                        $reason = 'Dropout in previous month';
                    } elseif (!in_array($cus->sno, $secondPaymentCustomers)) {
                        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                    </svg>
                                </a>';
                        $reason = 'No second payment in current month';
                    } elseif (in_array($cus->sno, $lowMbcCustomerIds)) {
                        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                    </svg>
                                </a>';
                        $reason = 'Paid below low MBC';
                    }
                    $country_code_prev =$cus->country_code ==0 ? '91' :  $cus->country_code;
                    $cusMobile_prev = $country_code_prev . ''. $cus->cus_mobile;
                    $proposal_id_prev=$cus->proposal_id ?? '-';
                    return [
                        'customer_name' => $cus->cus_name,
                        'mobile'        => $cusMobile_prev,
                        'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                        'status'        => $status,
                        'reason'        => $reason ?? 'Successfully Paid MPC And Second Payment',
                        'staff_name'    => $cus->staff_name,
                        'staff_image'   => $cus->staff_image,
                        'department_name'=> $cus->department_name,
                        'proposalId'=>$proposal_id_prev ,
                    ];
                })->values();
                $dropoutCustomersCurrent=[];
                // 9. Build the final list for current month details with status & reason
                $finalDataCurrent = $customerConvertThisMonth->map(function ($cus) use ($dropoutCustomersCurrent, $lowMbcCustomerIdsCurrent,$lowMbcCustomerIdspay) {
                    $reason = null;
                    // Default status: converted
                    $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                        <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                        <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                            c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                            c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                    </svg>
                                </a>';
                    $amount = $lowMbcCustomerIdspay->get($cus->sno)?->total_paid_amount ?? 0;
                    $proposal_id = $lowMbcCustomerIdspay->get($cus->sno)?->proposalId ?? '-';
                    $currencySymbol = $lowMbcCustomerIdspay->get($cus->sno)?->currencySymbol ?? '₹';
                    $currencyId = $lowMbcCustomerIdspay->get($cus->sno)?->currencyId ?? 70;
                    $country_code =$cus->country_code ==0 ? '91' :  $cus->country_code;
                    $cusMobile = $country_code . ''. $cus->cus_mobile;
            
                    if (in_array($cus->sno, $dropoutCustomersCurrent)) {
                        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                    </svg>
                                </a>';
                        $reason = 'Dropout in current month';
                    } elseif (in_array($cus->sno, $lowMbcCustomerIdsCurrent)) {
                        $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                    </svg>
                                </a>';
                        $reason = 'Paid below low MBC (1st-25th day)';
                    }
            
                    return [
                        'customer_name' => $cus->cus_name,
                        'mobile'        => $cusMobile,
                        'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                        'amount'        => $amount,
                        'proposalId'        => $proposal_id,
                        'currencySymbol'        => $currencySymbol,
                        'currencyId'        => $currencyId,
                        'status'        => $status,
                        'reason'        => $reason ?? 'Successfully Paid MPC Value'
                    ];
                })->values();
            
                // 10. Build summary counts for display
                $prevMonthSummary = [
                    'second_payment_total' => count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($dropoutCustomers) - count($lowMbcCustomerIds),
                    'lmbc_total'           => count($lowMbcCustomerIds),
                    'drop_count_total'     => count($dropoutCustomers),
                    'converted_total'      => count($prevMonthCustomerIds)
                ];
            
            
                $minuscustold =  count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($lowMbcCustomerIds) - count($dropoutCustomers);
                $minus_value =  $minuscustold + count($lowMbcCustomerIdsCurrent) + count($dropoutCustomersCurrent) + count($dropoutCustomers);
                $finalCustomer = count($prevMonthCustomerIdsCurrent) - $minus_value;
                $currentMonthSummary = [
                    'minus_value'             => $minus_value,
                    'final_value'             => $finalCustomer > 0 ? $finalCustomer :0,
                    'lmbc_total_current'   => count($lowMbcCustomerIdsCurrent),
                    'drop_count_current'   => count($dropoutCustomersCurrent),
                    'converted_total_current' => count($prevMonthCustomerIdsCurrent)
                ];

        }
    
        return response()->json([
            'staff_data'       => $StaffData,
            'data_prev'       => $finalDataPrev,
            'data_current'    => $finalDataCurrent,
            'summary_prev'    => $prevMonthSummary,
            'summary_current' => $currentMonthSummary,
            'second_payment_check' => $incentive ? $incentive->second_payment_check : 0,
        ]);
    }
    public function getcalculationCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));

        $prevDate = Carbon::createFromDate($year, $month, 1)->subMonth();
        $prevMonth = $prevDate->month;
        $prevYear  = $prevDate->year;

        $pi_slabs = [
            ['min' => 0, 'max' => 10, 'percentage' => 5],
            ['min' => 10, 'max' => 20, 'percentage' => 10],
            ['min' => 20, 'max' => 1000, 'percentage' => 15],
        ];

        $data = [];

        $prevMonthCustomerIdscus = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month)
            ->get();
        $globalIndex = 1; 
    
        foreach ($prevMonthCustomerIdscus as  $customer) {
        
        
            $trainings = DB::table('et_training as t1')
                    ->join(DB::raw('(
                        SELECT MIN(sno) as min_sno
                        FROM et_training
                        WHERE post_sale_check = 0
                        GROUP BY customer_id
                    ) as t2'), 't1.sno', '=', 't2.min_sno')
                    ->where('t1.customer_id', $customer->sno)
                    ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
                    ->get();
            
        
            foreach ($trainings as $training) {
                // Determine course_id based on tesbo_check
                $course_id = null;
        
                if ($training->tesbo_check > 0) {
                    $payment = PaymentModel::where('payment_id',$training->payment_id)->first();
                    if ($payment && $payment->course_id) {
                        $course_id = $payment->course_id;
                    }
                } else {
                    $course_id = $training->course_id;
                }
        
                if (!$course_id) continue; // Skip if no course_id
        
                $course = ManageCoursesModel::where('sno', $course_id)
                    ->whereIn('course_type_id', [2, 3])
                    ->first();
        
                if (!$course) continue;
            
                $basePrice = $course->course_min_price;
                $soldPrice = $training->overall_fees;
                $profitAmount = $soldPrice - $basePrice;
            
                // Calculate confirmed amount only if there's profit
                $confirmAmount = 0;
                if ($profitAmount > 0) {
                    $profitPercent = ($profitAmount / $basePrice) * 100;
                    foreach ($pi_slabs as $slab) {
                        if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                            $confirmAmount = ($profitAmount * $slab['percentage']) / 100;
                            break;
                        }
                    }
                }
            
                $data[] = [
                    'sno'                 => $globalIndex++,
                    'customer_name'       => $customer->cus_name,
                    'mobile'              => $customer->cus_mobile,
                    'month'               => Carbon::parse($customer->created_at)->format('F Y'),
                    'course_name'         => $course->course_name,
                    'original_amount'     => number_format($basePrice, 2),
                    'confirm_amount'      => number_format($soldPrice, 2),
                    'profit_loss_amount'  => ($profitAmount >= 0 ? '+' : '-') . number_format(abs($profitAmount), 2),
                    'staff_name'          => $customer->staff_name,
                    'staff_image'         => $customer->staff_image,
                    'department_name'     => $customer->department_name,
                ];
            }
        }

        return response()->json(['data' => $data]);
    }
    public function geteciCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
        
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
    
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name','et_staff.role_id')->where('et_staff.status',0)
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_staff.branch_id', $branchId)
                ->where('et_staff.sno', $staffId)
                ->first();
        if( $StaffData->role_id == 35){
                

                $customers = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.cus_name', 'et_customer.country_code',  'et_customer.cus_mobile', 'et_payment.transaction_date as created_date','et_payment.transaction_date as created_at','et_transaction.payment_id','et_transaction.sno as transaction_id','et_payment.paid_amount')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->get();
            $data = [];
            foreach ($customers as $index => $cus) {
                // Fetch course
                $course = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $cus->sno)
                    ->select('et_proposal.service_title')
                    ->first();

                $data[] = [
                    'sno'         => $index + 1,
                    'name'        => $cus->cus_name,
                    'mobile'        => $cus->cus_mobile,
                    'course'      => $course->service_title ?? '--',
                    'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                    'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
                                ? 'Converted'
                                : 'Eligible', // you can change this dynamically
                    'staff_name'      => $StaffData->staff_name,
                    'staff_image'     => $StaffData->staff_image,
                    'department_name' => $StaffData->department_name,
                ];
            }

                    
        }else{
            $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_payment.transaction_date as created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.sno = (
                                    SELECT ep.sno
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                    ORDER BY ep.transaction_date ASC, ep.sno ASC
                                    LIMIT 1
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->whereIn('et_customer.status', [0, 6])
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', $staffId)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->get();

            $data = [];
            foreach ($customers as $index => $cus) {
                // Fetch course
                $course = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $cus->sno)
                    ->select('et_proposal.service_title')
                    ->first();

                $data[] = [
                    'sno'         => $index + 1,
                    'name'        => $cus->cus_name,
                    'mobile'        => $cus->cus_mobile,
                    'course'      => $course->service_title ?? '--',
                    'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                    'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
                                ? 'Converted'
                                : 'Eligible', // you can change this dynamically
                    'staff_name'      => $cus->staff_name,
                    'staff_image'     => $cus->staff_image,
                    'department_name' => $cus->department_name,
                ];
            }
        }  

        return response()->json(['data' => $data,'staff'=>$StaffData]);
    }

    public function getCallCustomers(Request $request)
    {
                $staffId   = $request->query('staff_id');
                $monthRaw  = $request->query('month');
                $year      = $request->query('year');
                $branchId  = $request->query('branch_id');

                if (!$staffId || !$monthRaw || !$year || !$branchId) {
                    return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
                }

                $month = is_numeric($monthRaw)
                    ? (int) $monthRaw
                    : (int) date('m', strtotime($monthRaw . ' 1'));

                $now = Carbon::createFromDate($year, $month, 1);
                $startOfMonth = $now->copy()->startOfMonth();
                $middleOfMonth = $now->copy()->startOfMonth()->addDays(14);
                $endOfMonth = $now->copy()->endOfMonth(); // 🔧 FIXED
                // $incentive = IncentiveModel::where('role_id', 11)
                //                 ->where('branch_id', $branchId)
                //                 ->where('status', 0)
                //                 ->first();
            
                    $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_staff.role_id','et_department.department_name')->where('et_staff.status',0)
                        ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                        ->where('et_staff.branch_id', $branchId)
                        ->where('et_staff.sno', $staffId)
                        ->first();
                        
                    $incentive = IncentiveModel::where('role_id', $StaffData->role_id)
                            ->where('branch_id', $branchId)
                            ->whereMonth('incentive_month', $month)
                            ->whereYear('incentive_month', $year)
                            ->where('status', 0)
                            ->first();       
                $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                    ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staffId)
                    // ->where('et_lead.sno', 9436)
                    ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                    ->whereRaw('et_payment.sno = (
                                        SELECT ep.sno
                                        FROM et_payment ep
                                        WHERE ep.customer_id = et_customer.sno
                                        ORDER BY ep.transaction_date ASC, ep.sno ASC
                                        LIMIT 1
                                    )');
                            })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_transaction.payment_status', 1)
                    ->whereBetween(DB::raw('DATE(et_payment.transaction_date)'), [$startOfMonth, $endOfMonth])
                    ->select(
                        'et_customer.sno',
                        'et_lead.lead_mobile',
                        'et_payment.transaction_date as customer_created_at',
                        'et_lead.registered_date as lead_created_at',
                        'et_customer.cus_name',
                        'et_customer.cus_mobile',
                        'et_payment.transaction_date as created_at',
                        'et_staff.staff_name',
                        'et_staff.staff_image',
                        'et_department.department_name'
                    )
                    ->get();

                $convertedToday = 0;
                $convertedMonth = 0;
                $convertedOldMonth = 0;
                $data = [];

                foreach ($allConverted as $index => $row) {
                    $mobile = $row->lead_mobile;

                    // Get the latest call
                    $lastCall = DB::table('et_call_tracker')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staffId)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->orderByDesc('call_start_date')
                        ->first();

                    $totalCallCount = DB::table('et_call_tracker')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staffId)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->count();
                    $totalCalldata = DB::table('et_call_tracker')
                        ->where('branch_id', $branchId)
                        ->where('branch_staff_id', $staffId)
                        ->where('customer_phone_no', 'like', "%{$mobile}")
                        ->select(
                            'et_call_tracker.call_start_date'
                        )
                        ->get();
                    
                    //   return  $totalCalldata;
                    // Date parsing
                    $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                    $leadDate     = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                    $callDate     = $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null;

                    $convertedOnDay = $customerDate === $leadDate;
                    //  && $totalCallCount === 1;



                    $convertedInMonth = !$convertedOnDay && // only if not already on-day
                        $customerDate >= $startOfMonth->format('Y-m-d') &&
                        $customerDate <= $endOfMonth->format('Y-m-d') &&
                        $leadDate >= $startOfMonth->format('Y-m-d') &&
                        $leadDate <= $endOfMonth->format('Y-m-d');
                        //  &&
                        // $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //     $callDate = Carbon::parse($call->call_start_date);
                        //     return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        // });
                    // return $convertedInMonth;
                    $convertedOld = !$convertedOnDay && !$convertedInMonth && // only if not on-day or in-month
                        $customerDate >= $startOfMonth->format('Y-m-d') &&
                        $customerDate <= $endOfMonth->format('Y-m-d') &&
                        ($leadDate < $startOfMonth->format('Y-m-d') && $leadDate > $endOfMonth->format('Y-m-d'));
                        
                    $otherstaffConvert = !$convertedOnDay && !$convertedInMonth && !$convertedOld && $totalCallCount === 0;
                        

                                    
                    $statusTick = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                            <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                            <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                        </svg>
                                    </a>';
                    $statusWrong = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                            <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                            <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                        </svg>
                                    </a>';
                                    
                    $spotIncentiveDayAmount = $convertedOnDay ? ($incentive->spot_incentive_day ?? 0) : 0;
                    $spotIncentiveMonthAmount = $convertedInMonth ? ($incentive->spot_incentive_month ?? 0) : 0;
                    
                    $totalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                    
                    $data[] = [
                        'sno' => $index + 1,
                        'name' => $row->cus_name,
                        'mobile' => $row->cus_mobile,
                        'totalCallCount' => $totalCallCount,
                        'created_at' => Carbon::parse($row->customer_created_at)->format('d-M-Y'),
                        'lead_created_at' => Carbon::parse($row->lead_created_at)->format('d-M-Y'),
                        'call_start_date' => $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null,
                        'on_day' => $convertedOnDay ? $statusTick : $statusWrong,
                        'on_month' => $convertedInMonth ? $statusTick : $statusWrong,
                        'old_month' => $convertedOld ? $statusTick : $statusWrong,
                        'otherstaff' => $otherstaffConvert,
                        'Rewards' => $spotIncentiveDayAmount + $spotIncentiveMonthAmount,
                        'staff_name' => $row->staff_name,
                        'staff_image' => $row->staff_image,
                        'department_name' => $row->department_name
                    ];
            }

    return response()->json([
        'data' => $data,
        'StaffData' => $StaffData,
        'summary' => [
            'on_day' => $convertedToday,
            'on_month' => $convertedMonth,
            'old_month' => $convertedOldMonth
        ]
    ]);
}

    public function getCollectionCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }
    
        $month = is_numeric($monthRaw)
            ? (int)$monthRaw
            : (int)date('m', strtotime($monthRaw . ' 1'));
    
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $nextMonthStart = $currentMonthStart->copy()->addMonth();
        
          $current = Carbon::create($year, $month, 1);
        // 20 years ago from now
        $startDateold = $current->copy()->subYears(20)->startOfMonth();
        $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
        $staff = StaffModel::where('sno', $staffId)->first();

      
        $currentMonthStart = Carbon::create($year, $month, 1)->startOfMonth();
        $currentMonthEnd = Carbon::create($year, $month, 1)->endOfMonth();
         $dropoutCustomers = DB::table('et_training')
                        ->where('status', 2)
                        ->pluck('customer_id')
                        ->toArray();
                       
         $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_customer.sno', $dropoutCustomers) 
                    ->whereBetween('et_customer.created_at', [$startDateold, $endDateold])
                    ->pluck('et_customer.sno')
                    ->toArray();
    
        // ✅ 2. Get old month collection (scheduled earlier, paid now)
        $oldMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->where('et_payment.nextPayDate', '<', $currentMonthStart)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
      
        // ✅ 3. Get current month collection (scheduled and paid now)
        $currentMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->whereMonth('et_payment.nextPayDate', $month)
            ->whereYear('et_payment.nextPayDate', $year)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
           
    
        // ✅ 4. Get future month collection (scheduled later, paid now)
        $futureMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->where('et_payment.nextPayDate', '>', $nextMonthStart)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
    
        // ✅ 5. Calculate totals
        $oldAmountTotal = $oldMonthCollection->sum('paidAmount');
        $currentAmountTotal = $currentMonthCollection->sum('paidAmount');
        $futureAmountTotal = $futureMonthCollection->sum('paidAmount');
    
        // Optional: You can calculate percentage based on targets if available
    
        $totalCollection = $oldAmountTotal + $currentAmountTotal + $futureAmountTotal;

        return response()->json([
            'staff' => $staff,
        
            'old_amount' => [
                'collection' => $oldAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($oldAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $oldMonthCollection,
            ],
        
            'current_amount' => [
                'collection' => $currentAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($currentAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $currentMonthCollection,
            ],
        
            'future_amount' => [
                'collection' => $futureAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($futureAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $futureMonthCollection,
            ],
        ]);
    }
    
    public function getSICustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }
    
        $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $nextMonthStart = $currentMonthStart->copy()->addMonth();
        $helper = new \App\Helpers\Helpers();

        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_staff.role_id','et_department.department_name')->where('et_staff.status',0)
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_staff.branch_id', $branchId)
            ->where('et_staff.sno', $staffId)
            ->first();
        
        $incentive = IncentiveModel::where('role_id', $StaffData->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
        $si_slabs = ($incentive && $incentive->si_slab_json) ? json_decode($incentive->si_slab_json, true) : [];

        if( $StaffData->role_id == 35){
                

                $customers = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.cus_name', 'et_customer.country_code',  'et_customer.cus_mobile', 'et_payment.transaction_date as created_date','et_payment.transaction_date as created_at','et_transaction.payment_id','et_transaction.sno as transaction_id','et_payment.paid_amount')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staffId)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->get();
            $data = [];
            foreach ($customers as $index => $cus) {
                // Fetch course
                $course = DB::table('et_proposal')
                    ->where('et_proposal.customer_id', $cus->sno)
                    ->select('et_proposal.service_title')
                    ->first();

                $data[] = [
                    'sno'         => $index + 1,
                    'name'        => $cus->cus_name,
                    'mobile'        => $cus->cus_mobile,
                    'course'      => $course->service_title ?? '--',
                    'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                    'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
                                ? 'Converted'
                                : 'Eligible', // you can change this dynamically
                    'staff_name'      => $StaffData->staff_name,
                    'staff_image'     => $StaffData->staff_image,
                    'department_name' => $StaffData->department_name,
                ];
            }

                    
        }else{
            $customers = CustomerModel::select(
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_payment.transaction_date as created_at',
                    'et_customer.cus_mobile',
                    'et_proposal.sno as proposal_id',
                    'et_proposal.service_title',
                    'et_proposal.currency_id',
                    'et_proposal.grant_total_amount',
                    'et_country_currencies.currency_symbol',
                    'et_country_currencies.currency_code',
                    'et_transaction.total_amount_inr',
                    'et_payment.paid_amount',
                    )
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                ->whereRaw('et_payment.sno = (
                                    SELECT ep.sno
                                    FROM et_payment ep
                                    WHERE ep.customer_id = et_customer.sno
                                    ORDER BY ep.transaction_date ASC, ep.sno ASC
                                    LIMIT 1
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->join('et_proposal', 'et_payment.proposal_id', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->whereIn('et_customer.status', [0, 6])
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', $staffId)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->get();

            $data = [];
            $base_amount_paid=0;
            $total_payment=0;
            $siReward=0;
            $siCollectionValue=0;
            $total_collection_net_inr =0;
            $total_collection_inr =0;
            $gst_percent = 18;
            $customerConvertCount = count($customers);
            foreach ($customers as $index => $cus) {

                $displayAmount = 0;
                $displayCurrency = '₹';
                $collectionInr = 0;
             
                    // Paid slots for this proposal
                    $paidAmount = DB::table('et_proposal_pay_slot')
                        ->where('proposal_sno', $cus->proposal_id)
                        ->where('status', 0)
                        ->sum('paidAmount');

                    $grantAmount = $cus->grant_total_amount;
                    
        
                    if ($cus->currency_id == 70) {
                        $collectionInr = $cus->paid_amount;
                    } else {
                        if ($cus->total_amount_inr > 0) {
                            $collectionInr = $cus->total_amount_inr;

                        } else {
                            $collectionInr = $helper->ConvertedAmountInr($currency_code, $paidAmount);
                        }
                    }

                $basePaidLocal = $collectionInr / (1 + ($gst_percent / 100));
                
                $total_payment += $collectionInr;
                $base_amount_paid += $basePaidLocal;

                $total_collection_inr += $collectionInr;
                $total_collection_net_inr += $basePaidLocal;
                $data[] = [
                    'sno'         => $index + 1,
                    'name'        => $cus->cus_name,
                    'mobile'        => $cus->cus_mobile,
                    'service_title'      => $cus->service_title ?? '--',
                    'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                    'status'      =>'Eligible', 
                    'collection' => round($cus->paid_amount),
                    'collection_base_amount' => round($basePaidLocal),
                    'currency_symbol'   => $cus->currency_symbol,   
                    'currency_id'   => $cus->currency_id,   
                    'collection_inr' => round($cus->total_amount_inr),         
                    'staff_name'      => $StaffData->staff_name,
                    'staff_image'     => $StaffData->staff_image,
                    'department_name' => $StaffData->department_name,
                ];
            }
        }  
       
        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
        $siCollectionValue = $averageCollectionValue;

         $matchedSlabSI = 'Below 25K';

        foreach ($si_slabs as $slab) {
            $min = $slab['min'];
            $max = $slab['max'];

            if (
                $siCollectionValue >= $min &&
                ($max === null || $siCollectionValue <= $max)
            ) {
                $matchedSlabSI = $min . ' - ' . ($max ?? 'Above');
                $siReward = $slab['reward'];
                $slabMin = $min;
                $slabMax = $max;
                break;
            }
        }
      

       
        return response()->json([
            'staff' => $StaffData,
            'collection_total_avg' => round($siCollectionValue),
            'collection_total_inr' => round($total_collection_inr),
            'collection_total_net_inr' => round($total_collection_net_inr),
            'total_customer' => $customerConvertCount ?? 0,
            'slab' => $matchedSlabSI,
            'siReward' => $siReward,
            'data' => $data
        ]);
    }

       public function MyIncentive(Request $request)
    {
        $branch_id = $request->user()->branch_id;
            
        return view('content.metrics.manage_my_incentive');
    }
    
   public function getMyIncentiveMetrics(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branchId = $request->branch_id ?? $request->user()->branch_id;
        $departmentId = $request->department_id;
        // $role_id = 11;
        $user_id = $request->user()->user_id;
        
        // $user_id = 120;
        $year = $request->year;
    
        if (!empty($request->month)) {
            $request->month = is_numeric($request->month)
                ? (int) $request->month
                : (int) date('m', strtotime($request->month . ' 1'));
        }
        
        $month = $request->month;
        
        // Get the first and last date of the requested month
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    
        // Generate all dates in the month
        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }
    
        // Directly use startDate and endDate for formatting
        $startOfMonth = $startDate->format('Y-m-d');
        $endOfMonth = $endDate->format('Y-m-d');
        
        $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
        $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;
        
        $current = Carbon::create($year, $month, 1);
        // 20 years ago from now
        $startDateold = $current->copy()->subYears(20)->startOfMonth();
        $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
        
        $staffList = StaffModel::join('et_division', 'et_division.sno', '=', 'et_staff.sub_department_id')
              ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
              ->join('et_branch', 'et_branch.sno', '=', 'et_staff.branch_id')
            ->where('et_staff.branch_id', $branchId)
            // ->where('et_staff.role_id', $role_id)
            ->where('et_staff.sno', $user_id)
            ->where('et_staff.status', 0)
            ->select(
                'et_staff.sno as staff_id',
                'et_staff.staff_name',
                'et_staff.role_id',
                'et_staff.department_id',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.branch_id',
                'et_branch.branch_name',
                'et_branch.franchise_name',
                'et_branch.cert_auth_sign',
                'et_staff.avaiable_points',
                 'et_staff.per_hour_cost',
                'et_staff.basic_salary',
                // 'et_division.division_id',
                'et_division.division_name as sub_department_name',
                'et_department.department_name'
            )
            ->first();
            // return $staffList;
            $role_id  = $staffList->role_id;
            // return  $staffList;
            //  return  $departmentIds;
            $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $staffList->department_id)->where('et_goal_set_team.branch_id', $branchId)
          ->where('et_goal_set_team.team_goal_month', $request->month)
          ->where('et_goal_set_team.team_goal_year', $year)
          ->first();
        //   return  $staffList;
            // Get goal records for the selected department and month
            $goalsetRecords = GoalSetStaffModel::where('et_goal_set_staff.department_id', $staffList->department_id)->where('et_goal_set_staff.branch_id', $branchId)
              ->where('et_goal_set_staff.goal_month', $request->month)
              ->whereMonth('et_goal_set_staff.goal_date', $request->month)
              ->whereYear('et_goal_set_staff.goal_date', $year)
              ->get();
            //   return  $goalsetRecords;
              
            $goalsetData = [];
            foreach ($goalsetRecords as $goal) {
              $goalsetData[$goal->staff_id] = $goal;
            }
    
            //   return  $staffList;
        $result = [];
    
      
            $staff = $staffList;
            $isProduction = $staff->role_id == 22;
            $isSalesEx = $staff->role_id == 11;
            $isPostSalesEx = $staff->role_id == 35;
            $isTeamLead = $staff->role_id == 12;
            $isCollection = $staff->role_id == 14;
            $isCRE = $staff->role_id == 16;
            $isJournalCordinator = $staff->role_id == 34;
            $isPC = $staff->role_id == 15;
            $current_date = date('Y-m-d'); // Define the current date
            
            $incentive = IncentiveModel::where('role_id', $staff->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
            $startDateChck = Carbon::create($year, $month, 1);
            $currentDateChck = Carbon::now();
            $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month) 
                        ? $currentDateChck 
                        : $startDateChck->copy()->endOfMonth();
            $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;
                 
            // if (!$incentive) {
            //     continue; // Skip if no incentive record for ro
            // }
           
           
            if ($isTeamLead) {
                // Step 1: Get all active executives under same branch and department
                $executives = StaffModel::where('branch_id', $staff->branch_id)
                    ->where('department_id', $staff->department_id)
                    ->where('role_id', 11)
                    ->where('status', 0)
                    ->get();
            
                // Step 2: Filter executive IDs who have goals (conversion > 0)
                $executiveIds = $executives->pluck('sno')->toArray();
            
                $executiveGoalSet = $goalsetRecords
                    ->whereIn('staff_id', $executiveIds)
                    ->where('conversion', '>', 0)
                    ->pluck('staff_id')
                    ->unique()
                    ->toArray();
                $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
                // if (!$incentive) {
                //     continue; // Skip if no incentive record for role
                // }
            
                // Step 3: Re-filter only executives who have goal set
                $filteredExecutives = $executives->whereIn('sno', $executiveGoalSet);
            
                // Step 4: Calculate incentives only for valid executives
                $allExecutiveIncentives = [];
                foreach ($filteredExecutives as $executive) {
                    $allExecutiveIncentives['staff_' . $executive->sno] = $this->calculateIncentivesForStaff(
                        $executive,
                        $branchId,
                        $month,
                        $year,
                        $goalsetData
                    );
                }
        
                // Step 5: Run final status check
                $finalStatus = $this->getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives);
                $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->whereMonth('branch_target.date', $month)
                    ->whereYear('branch_target.date', $request->year)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                    
                $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
                    ->where('branch_id', $branchId)
                    ->whereYear('created_at', $request->year)
                    ->whereMonth('created_at', $month)
                    ->count();
                    $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;
                    
                //   return $allExecutiveIncentives;
                    // Now prepare result for Team Lead
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'branch_name' => $staff->branch_name,
                        'bh_signature' => $staff->cert_auth_sign,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
                
                        'incentives' => [
                            'tenx_award' => [
                                'target' => 'All Executives Achieved 10x',
                                'actual' => $individual10x ? 'Achieved' : 'Not Achieved',
                                'status' => $individual10x,
                                'reward' => $individual10x ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                            'eci' => [
                                'target' => 'All Executives Achieved ECI',
                                'actual' => $finalStatus['eci'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['eci'],
                                'reward' => $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                            'bi' => [
                                'target' => 'All Executives Achieved BI',
                                'actual' => $finalStatus['bi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['bi'],
                                'reward' => $finalStatus['bi'] ? ($biReward ?? 0) : 0,
                            ],
                            'si' => [
                                'target' => 'All Executives Achieved SI',
                                'actual' => $finalStatus['si'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['si'],
                                'reward' => $finalStatus['si'] ? 3000 : 0,
                            ],
                            'pi' => [
                                'target' => 'All Executives Achieved PI',
                                'actual' => $finalStatus['pi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['pi'],
                                'reward' => $finalStatus['pi'] ? ($piReward ?? 0) : 0,
                            ],
                            'sp' => [
                                'target' => 'All Executives Achieved SP',
                                'actual' => $finalStatus['sp'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['sp'],
                                'reward' => $finalStatus['sp'] ? ($spotTotalReward ?? 0) : 0,
                            ],
                            'li' => [
                                'target' => 'All Incentives Achieved by Team',
                                'actual' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? 'Achieved'
                                    : 'Not Achieved',
                                'status' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']),
                                'reward' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ],
                    ];
            }
            
            if ($isSalesEx) {
                 
                  
                  //Sales Team 
                  //   return 'hi';
                  $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
            
                  $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                    //this month count 
                    
                  $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_transaction.payment_status', 1)
                    ->orderBy('et_customer.sno', 'asc')
                    ->count();
                    
                    $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                     ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                             ->whereRaw('et_payment.transaction_date = (
                                 SELECT MIN(ep.transaction_date)
                                 FROM et_payment ep
                                 WHERE ep.customer_id = et_customer.sno
                             )');
                    })
                    ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_payment.transaction_date', $prevYear)
                    ->whereMonth('et_payment.transaction_date', $prevMonth)
                    ->where('et_transaction.payment_status', 1)
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();    
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
                    // $dropoutCustomers = DB::table('et_training')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 2)
                    //     ->pluck('customer_id')
                    //     ->toArray();
                       // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->select('et_payment.customer_id')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->groupBy('et_payment.customer_id')
                        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
                        ->pluck('et_payment.customer_id')
                        ->toArray();
                    // return $fullPaidCustomerIds;
                    // 2. Customers who made a second payment this month
                    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();
                        //  return $secondPaymentCustomersmulti;
                    
                  
                    $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));

                    // second condition  
                    // $secondPaymentCustomers = DB::table('et_payment')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 1)
                    //     ->whereMonth('nextPayDate', $month)
                    //     ->whereYear('nextPayDate', $year)
                    //     ->pluck('customer_id')
                    //     ->unique()
                    //     ->values() // this reindexes!
                    //     ->toArray();
                        // return $secondPaymentCustomers;
                    // third condition  
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                
                    //  $drop_ids = DB::table('et_drop_refund')
                    //       ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                    //       ->where('et_drop_refund.bh_status', 1)
                    //       ->pluck('et_training.customer_id');
                          
                    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIds = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIds,
                            array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
                        ));
                        // return count($badCustomerIds);
                         $second_pay_check = $incentive ? $incentive->second_payment_check : 0;
                        if($second_pay_check == 1){
                            $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                        }else{
                            $customerConvertCount = max(0,$customerConvertCountthismonth);
                        }
                      
                    // return $customerConvertCount;
                  $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
            
            
                  // customer ratio
                  $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                  $convertion_rate = number_format($convertion_rate, 2);
            
                  //acr
                  $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                  $averager_convertion_rate = number_format($averager_convertion_rate, 2);
            
                    
               
                    $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                    
                    $si_slabs = ($incentive && $incentive->si_slab_json) ? json_decode($incentive->si_slab_json, true) : [];
                    $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            
                  $currentMonthCustomerCount = 0;
                  $total_business_amount     = 0;
                  $total_payment             = 0;
                  $total_paid_payment        = 0;
                  $averageBusinessValue      = 0;
                  $averageCollectionValue    = 0;
                  $crashCount = 0;
                  $professionCount = 0;
                  $tesboCount = 0;
                  $courseTypeTotal = 0;
                  $eciCustomerConvertCount = 0;
                  $eciActualPercentage = 0;
                  $eciTargetPercentage = $incentive->eci_count ?? 0;
                  $eciStatus = false;
                  
               
                
                   $targetConversion = $goalsetData[$staff->staff_id]->conversion ?? 0;
                    $targetABV             = $goalsetData[$staff->staff_id]->ABV ?? 0;
                    $targetACV             = $goalsetData[$staff->staff_id]->ACV ?? 0;
                    $crashTarget =0;
                    $professionTarget =0;
                    $tesboTarget =0;
                    $crashPercent =0;
                    $professionPercent=0;
                    $tesboPercent=0;
                    $piPercentage = 0;
                    $originalAmount = 0;
                    $piReward = 0;
                    $matchedSlabSI = null;
                    $slabPercentageSI = 0; 
                    $siPercentage=0;
                    $originalAmountSI = 0;
                    $siReward = 0;
                    $matchedSlab = null;
                    $slabPercentage = 0; 
                   // Total Professional and Crash courses
                
                    
                    // Prepare tree output
                    $crash_coures_total = 0;
                    $professinal_coures_total = 0;
                    $teshobo_coures_total = 0;
                    $siStatus = false;
                    // foreach ($groupedData as $row) {
                    //     if ($row->course_type_id == 3) {
                    //         $professinal_coures_total = (int) $row->total_trainings;
                    //     } elseif ($row->course_type_id == 4) {
                    //         $crash_coures_total = (int) $row->total_trainings;
                    //     }
                    // }
                    
                     // return $crash_coures_total;
                     $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
                 
                    if ($customerConvertCount > 0) {
                   
                      
                      $currentMonthCustomer = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                     ->whereRaw('et_payment.transaction_date = (
                                         SELECT MIN(ep.transaction_date)
                                         FROM et_payment ep
                                         WHERE ep.customer_id = et_customer.sno
                                     )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->orderBy('et_customer.sno', 'asc')
                            ->get();
                      
                      
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                     $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                 ->whereRaw('et_payment.sno = (
                                     SELECT ep.sno
                                     FROM et_payment ep
                                     WHERE ep.customer_id = et_customer.sno
                                     ORDER BY ep.transaction_date ASC, ep.sno ASC
                                     LIMIT 1
                                 )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_lead.created_by', $staff->staff_id)
                         ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereDay('et_payment.transaction_date', '<=', 15)
                        ->count();
                        
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            // foreach ($currentMonthCustomer as $customer) {
                        
                            //     // First: check if this customer has TESBO training
                            //     $hasTesbo = DB::table('et_training')
                            //         ->where('customer_id', $customer->sno)
                            //         ->where('branch_id', $branchId)
                            //         ->whereMonth('created_at', $month)
                            //         ->whereYear('created_at', $year)
                            //         ->where('tesbo_check', 2)
                            //         ->where('post_sale_check', '!=', 1)
                            //         ->exists();
                        
                            //     if ($hasTesbo) {
                            //         $tesboCount++;
                            //         continue; // skip crash/professional check if TESBO already counted
                            //     }
                        
                            //     // Then: check if customer has valid Professional or Crash training (not tesbo)
                            //     $nonTesboTrainings = DB::table('et_training')
                            //         ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                            //         ->where('et_training.customer_id', $customer->sno)
                            //         ->where('et_training.branch_id', $branchId)
                            //         ->whereMonth('et_training.created_at', $month)
                            //         ->whereYear('et_training.created_at', $year)
                            //         ->where('et_training.post_sale_check', '!=', 1)
                            //         ->where('et_training.tesbo_check', '!=', 2)
                            //         ->whereIn('et_course.course_type_id', [3, 4])
                            //         ->select('et_course.course_type_id')
                            //         ->get();
                        
                            //     $hasCrash = false;
                            //     $hasProfession = false;
                        
                            //     foreach ($nonTesboTrainings as $training) {
                            //         if ($training->course_type_id == 3) {
                            //             $hasProfession = true;
                            //         } elseif ($training->course_type_id == 4) {
                            //             $hasCrash = true;
                            //         }
                            //     }
                        
                            //     if ($hasCrash) $crashCount++;
                            //     if ($hasProfession) $professionCount++;
                            // }
                        
                            // $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                            $courseTypeTotal = 0;
                        }
                        // return $customerConvertCount;
                        // spot incentive 
                        if($incentive){
                            $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $customerConvertCountthismonth) * 100 : 0;
                            $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $customerConvertCountthismonth) * 100 : 0;
                            $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $customerConvertCountthismonth) * 100 : 0;
                            $crashTarget = $incentive->si_crash_course ?? 0;
                            $professionTarget = $incentive->si_profession_course ?? 0;
                            $tesboTarget = $incentive->si_tesbo_course ?? 0;
                            
                        }else{
                            $crashPercent =  0;
                            $professionPercent =  0;
                            $tesboPercent =  0;
                            $crashTarget =  0;
                            $professionTarget = 0;
                            $tesboTarget =  0;
                        }
                        
                        
                        // $crashPercent = $crashCount;
                        // $professionPercent = $professionCount;
                        // $tesboPercent = $tesboCount;
                        
                       
                        
                        // only condition: Crash must be ≤ targe
                           
                          
                          if ( $customerConvertCountthismonth  >= 20){
                              $siStatus = true;
                            // return $customerConvertCountthismonth;
                            if ($incentive->si_crash_course > 0) {
                                
                                // $siStatus = $siStatus && ($crashPercent >= $crashTarget);
                                $siStatus = $siStatus && (($crashPercent >= $crashTarget) || ($crashPercent <= $crashTarget) );
                            }
                            
                            if ($incentive->si_profession_course > 0) {
                                
                                $siStatus = $siStatus && ($professionPercent >= $professionTarget);
                            }
                            
                            if ($incentive->si_tesbo_course > 0) {
                                // return $siStatus;
                                $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
                            }
                          }else{
                              $siStatus = false;
                          }
                        //  return $currentMonthCustomer;
                        // return 'not coming good';
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                              
                                 $trainings = DB::table('et_proposal as t1')
                                        ->join(DB::raw('(
                                            SELECT MIN(sno) as min_sno
                                            FROM et_proposal
                                            WHERE post_sale_check = 0
                                            GROUP BY customer_id
                                        ) as t2'), 't1.sno', '=', 't2.min_sno')
                                        ->where('t1.customer_id', $customer->sno)
                                        ->select('t1.sno', 't1.customer_id',    't1.total_amount')
                                        ->get();
                            
                                    foreach ($trainings as $training) {
                                         // Determine course_id based on tesbo_check
                                        $course_id = null;
                                
                                        if (!$course_id) continue; // Skip if no course_id
                                
                                        $course = ManageCoursesModel::where('sno', $course_id)
                                            ->whereIn('course_type_id', [2, 3])
                                            ->first();
                                
                                        if (!$course) continue;
                                    $basePrice = $course->course_min_price;
                                    $soldPrice = $training->overall_fees;
                                    $profitAmount = $soldPrice - $basePrice;
                                    
                                    // if ($profitAmount > 0) {
                                        
                                       $originalAmount += $profitAmount; 
        
                                       $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                                      // return $pi_slabs;
                                        // Match against PI slabs
                                        foreach ($pi_slabs as $slab) {
                                            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                                $slabPercentage = $slab['percentage'];
                                                $rewardFromThis = ($originalAmount * $slabPercentage) / 100;
                        
                                                $piRewards = $rewardFromThis > 0 ? $rewardFromThis : 0;
                                                $piPercentage = $profitPercent;
                                                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                                break; // first matching slab
                                            }
                                        }
                                    // }
                                }
                            }
                        }
                         $piReward0 = $slabPercentage >0 ? ($originalAmount * $slabPercentage) / 100 : 0;
                         $piReward  = $piReward0 > 0 ?$piReward0 :0;
                        //  return $piReward;
                         //   return $rewardFromThisd;
                        // if ($currentMonthCustomer->isNotEmpty()) {
                        //   foreach ($currentMonthCustomer as $customer) {
                
                        //     // $payment = DB::table('et_proposal')->select('et_proposal.sno', 'et_proposal.customer_id')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     // //   ->where('et_training.tesbo_check', 0)
                        //     //   ->sum('et_proposal.total_amount');
                
                        //     // $total_payment += $payment;
                        //     $proposal_ids=json_decode($customer->proposal_ids);
                        //     $total_payment_grant = DB::table('et_proposal')
                        //     ->whereIn('sno', $proposal_ids)
                        //     ->where('status', 0) 
                        //     ->sum('grant_total_amount');
                       
                        //         $total_payment += $total_payment_grant;
                
                
                            
                            
                            
                        //     $total_paid_payment_slot = DB::table('et_proposal_pay_slot')
                        //                   ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
                        //                   ->where('status', 0)
                        //                   ->sum('paidAmount');
                
                        //     // $paid_payment = DB::table('et_proposal')->select( 'et_proposal.sno', 'et_proposal.customer_id')
                        //     // ->join('et_proposal_pay_slot','et_proposal.sno','=','et_proposal_pay_slot.proposal_sno')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     //   ->sum('et_proposal_pay_slot.paidAmount');
                
                        //     $total_paid_payment += $total_paid_payment_slot;
                            
                             
                            
                        //   }
                                
                        // }
                        $base_amount_paid=0;
                         $gst_percent = 18;
                        if ($currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                                $proposal_ids = DB::table('et_proposal')
                                    ->where('et_proposal.customer_id', $customer->sno)
                                    ->where('et_proposal.status', 0)
                                    ->whereNot('et_proposal.post_sale_check', 1)
                                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                    ->pluck('sno')
                                    ->toArray();
                                    // return $proposal_ids;
                        
                                $proposals = DB::table('et_proposal')
                                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                    ->whereIn('et_proposal.sno', $proposal_ids)
                                    ->get();
                        
                                foreach ($proposals as $proposal) {
                                    // Paid slots for this proposal
                                    $paidAmount = DB::table('et_proposal_pay_slot')
                                        ->where('proposal_sno', $proposal->sno)
                                        ->where('status', 0)
                                        ->sum('paidAmount');
                        
                                    $grantAmount = $proposal->grant_total_amount;
                        
                                    // First remove GST from paidAmount (base value in proposal's currency)
                                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                        
                                    if ($proposal->currency_id == 70) {
                                        // INR: add directly
                                        $total_paid_payment += $paidAmount;
                                        $total_payment += $grantAmount;
                                        $base_amount_paid += $basePaidLocal;
                                    } else {
                                        // Non-INR: convert both amounts and base value
                                        $currency_code = $proposal->currency_code;
                                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                    }
                                }
                            }
                        }
                
                
                        // average 
                        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $gst_percent = 18;
             
                        // $base_amount_paid = $total_paid_payment / (1 + ($gst_percent / 100));
                        
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        // $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $totalAllPayment +=$total_payment;
                        // $totalAllPaidPayment +=$base_amount_paid;
                         // ECI Logic
                     
                        $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                        $eciActualPercentage = number_format($eciActualPercentage, 2);
                        $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
            
                        // average 
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                        // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                
                        // $totalAllPayment += $total_payment;
                        // $totalAllPaidPayment += $total_paid_payment;
                    }
                  
                    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                

                    foreach ($allConverted as $row) {
                      
                      $mobile = $row->lead_mobile;
                        // Get the latest call
                         $lastCall = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->first();
                    
                            
                        $totalCallCount = DB::table('et_call_tracker')->select('sno')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->count();
                        // Attach values to row
                        $row->call_created_at = $lastCall->call_start_date ?? null;
                        $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                        $row->call_count = $totalCallCount;
                    }
        
                    
                        
                        // return $allConverted;
                        
                    $convertedToday = 0;
                    $convertedMonth = 0;
                    $convertedOldMonth = 0;
                $customerDetails=[];
                    foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                            // include call count
                        // if ($customerDate ===  $leadDate && $call_count ===  1) {
                        //     $convertedToday++;
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     $leadDate >= $startOfMonth && $leadDate <= $dates &&
                        //     $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //         $callDate = Carbon::parse($call->call_start_date);
                        //         return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        //     })
                            
                        // ) {
                        //     $convertedMonth++;
                        //     $customerMobiles[] = $mobile; 
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     ($leadDate < $startOfMonth || $leadDate > $dates)
                        // ) {
                        //     $convertedOldMonth++;
                        // }
                        $customerData = [
                            'customerDate' => $customerDate,
                            'leadDate'     => $leadDate,
                            'mobile'       => $mobile
                        ];
                        if ($customerDate ===  $leadDate) {
                            $convertedToday++;
                            //   $customerDetails[] = $customerData; 
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates
                        ) {
                            $convertedMonth++;
                           
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                    // return $customerDetails;
                    // return $convertedToday;
                    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                    // Old month = always 0
                    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                  
                    // 10x award calculation       
                    $actualConversion      = $customerConvertCount;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;
                   
                    //   $tenxStatus = (
                    //         $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    //         $actualConversion >= $targetConversion &&
                    //         $actualABV >= $targetABV &&
                    //         $actualACV >= $targetACV
                    //     );
                     $tenxStatus = (
                        $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                        $actualConversion >= $targetConversion 
                    );
                   // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                    
                    $biReward = $biAchievedCount * $biPerConversion;
                    $biStatus = $biAchievedCount > 0;
                    
                     //   for promance incentive
                  $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                  $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;
                  
                  $actualOutgoingCallCount=0;
                  $actualMissedCallRate=0;
                  $actualMissedCount=0;
                  
                //   $actualCallCount = DB::table('et_call_tracker')
                //     ->selectRaw('
                //         COUNT(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count, 
                //         COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count, 
                //         COUNT(CASE WHEN call_status = 2 THEN 1 ELSE NULL END) AS missedcall_count,
                //         COUNT(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count,
                //         COUNT(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count
                //     ')
                //     ->whereYear('call_start_date', $year)
                //     ->whereMonth('call_start_date', $month)
                //     ->where('et_call_tracker.branch_id', $branchId)
                //     ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                //     ->first();

                $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  
                   $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                   $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                  
                  $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                  $actualOutgoingPerDay=round($actualOutgoingPerDay);
                  
                  // Missed call ratio
                    $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count + $actualCallCount->rejected_call_count;
                    $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                    $actualMissedCallRate=round($actualMissedCallRate,1);
                    
                    
                  
                  $performIncentStatus = (
                        $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                        $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                    );
                  
                  
                  
                  
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $customerConvertCountthismonth . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" 
                                                      >
                                                    ' . $actualConversion . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            'eci' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $eciStatus,
                                'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($targetConversion . ' - ' . $actualConversion . ' = (' . $biAchievedCount . ')') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($biAchievedCount . ' × ' . $biPerConversion) . 
                                            '</span>',
                                'status' => $tenxStatus && $biStatus,
                                'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                            ],
                        
                            'si' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlabSI ? $matchedSlabSI . ' = ' . round($slabPercentageSI, 2) . '%' : 'No Matching Slab')  . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                             round($siPercentage, 2) . '% — ₹' . number_format($originalAmountSI) . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $siStatus,
                                'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                            ],
                        
                           'pi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $piReward > 0,
                                'reward' => ($tenxStatus && $piReward > 0)
                                    ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                    : 0,
                            ],
                        
                           'sp' => [
                                'target' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . '</span>
                                            </td>
                                        </tr>
                                        
                                    </table>
                                ',
                            
                                'actual' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openManageCallModal(' . $staff->staff_id . ')" >Details</span>
                                            </td>
                                        </tr>
                                        
                                    </table>
                                ',
                                'status' => $tenxStatus && $spotTotalReward > 0,
                                'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
                            ],
                            'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Missed Call Rate">' . $targetMissedCallRate . '%</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Outgoing Call Count Per day">' . $targetOutgoingCallCount . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info"  data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Missed Call Rate"
                                                      >
                                                    ' . $actualMissedCallRate . '%
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Outgoing Call Count Per day"
                                                      >
                                                    ' . $actualOutgoingPerDay . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformCallModal(' . $staff->staff_id . ')" >Details</span>
                                             ',
                                
                                'status' => $tenxStatus && $performIncentStatus,
                                'reward' => ($tenxStatus && $performIncentStatus) ? ($incentive->$performIncentStatus ?? 0) : 0,
                            ],
        
                        
                           'li' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) 
                                                ? 'Achieved' 
                                                : 'Not Achieved') . 
                                            '</span>',
                                'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
                                'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward)
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ]
        
                    ];
            
            }
           
            
            if ($isPostSalesEx) {
                 
                  
                  //Sales Team 
                  //   return 'hi';
                  $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
            
                  $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                    //this month count 

                    $customerConvertCountthismonth = DB::table('et_customer')
                        ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->staff_id)
                        ->whereYear('et_payment.transaction_date', $year)
                        ->whereMonth('et_payment.transaction_date', $month)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                         ->count();
                    
                    $prevMonthConvertedCustomers = DB::table('et_customer')
                        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                        ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_customer.status', 0)
                        ->where('et_customer.post_sale_check', 1)
                        ->where('et_proposal.post_sale_check', 1)
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_proposal.created_by', $staff->staff_id)
                        ->whereYear('et_payment.transaction_date', $prevYear)
                        ->whereMonth('et_payment.transaction_date', $prevMonth)
                        ->where('et_transaction.payment_status', 1)
                        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                        ->where('et_proposal.status',0)
                        ->orderBy('et_proposal.sno', 'asc')
                        ->pluck('et_customer.sno')
                        ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
                    // $dropoutCustomers = DB::table('et_training')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 2)
                    //     ->pluck('customer_id')
                    //     ->toArray();
                       // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->select('et_payment.customer_id')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->groupBy('et_payment.customer_id')
                        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
                        ->pluck('et_payment.customer_id')
                        ->toArray();
                    // return $fullPaidCustomerIds;
                    // 2. Customers who made a second payment this month
                    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();
                        //  return $secondPaymentCustomersmulti;
                    
                  
                    $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));

                    // second condition  
                    // $secondPaymentCustomers = DB::table('et_payment')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 1)
                    //     ->whereMonth('nextPayDate', $month)
                    //     ->whereYear('nextPayDate', $year)
                    //     ->pluck('customer_id')
                    //     ->unique()
                    //     ->values() // this reindexes!
                    //     ->toArray();
                        // return $secondPaymentCustomers;
                    // third condition  
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                
                    //  $drop_ids = DB::table('et_drop_refund')
                    //       ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                    //       ->where('et_drop_refund.bh_status', 1)
                    //       ->pluck('et_training.customer_id');
                          
                    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIds = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIds,
                            array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
                        ));
                       
                         $second_pay_check = $incentive ? $incentive->second_payment_check : 0;
                        if($second_pay_check == 1){
                            $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                        }else{
                            $customerConvertCount = max(0,$customerConvertCountthismonth);
                        }
                      
                    // return $customerConvertCount;
                  $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
            
            
                  // customer ratio
                  $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                  $convertion_rate = number_format($convertion_rate, 2);
            
                  //acr
                  $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                  $averager_convertion_rate = number_format($averager_convertion_rate, 2);
            
                    
               
                    $luxury = ($incentive && $incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                    
                    $si_slabs = ($incentive && $incentive->si_slab_json) ? json_decode($incentive->si_slab_json, true) : [];
                    $pi_slabs = ($incentive && $incentive->pi_slab_json) ? json_decode($incentive->pi_slab_json, true) : [];

            
                  $currentMonthCustomerCount = 0;
                  $total_business_amount     = 0;
                  $total_payment             = 0;
                  $total_paid_payment        = 0;
                  $averageBusinessValue      = 0;
                  $averageCollectionValue    = 0;
                  $crashCount = 0;
                  $professionCount = 0;
                  $tesboCount = 0;
                  $courseTypeTotal = 0;
                  $eciCustomerConvertCount = 0;
                  $eciActualPercentage = 0;
                  $eciTargetPercentage = $incentive->eci_count ?? 0;
                  $eciStatus = false;
                  
               
                
                   $targetConversion = $goalsetData[$staff->staff_id]->conversion ?? 0;
                    $targetABV             = $goalsetData[$staff->staff_id]->ABV ?? 0;
                    $targetACV             = $goalsetData[$staff->staff_id]->ACV ?? 0;
                    $crashTarget =0;
                    $professionTarget =0;
                    $tesboTarget =0;
                    $crashPercent =0;
                    $professionPercent=0;
                    $tesboPercent=0;
                    $piPercentage = 0;
                    $originalAmount = 0;
                    $piReward = 0;
                    $matchedSlabSI = null;
                    $slabPercentageSI = 0; 
                    $siPercentage=0;
                    $originalAmountSI = 0;
                    $siReward = 0;
                    $matchedSlab = null;
                    $slabPercentage = 0; 
                   // Total Professional and Crash courses
                
                    
                    // Prepare tree output
                    $crash_coures_total = 0;
                    $professinal_coures_total = 0;
                    $teshobo_coures_total = 0;
                    $siStatus = false;
                    // foreach ($groupedData as $row) {
                    //     if ($row->course_type_id == 3) {
                    //         $professinal_coures_total = (int) $row->total_trainings;
                    //     } elseif ($row->course_type_id == 4) {
                    //         $crash_coures_total = (int) $row->total_trainings;
                    //     }
                    // }
                 
                     // return $crash_coures_total;
                     $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
                 
                    if ($customerConvertCount > 0) {
                   
                      
                      $currentMonthCustomer = DB::table('et_customer')
                            ->select('et_customer.sno', 'et_customer.proposal_ids')
                            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                            ->join('et_payment', function($join) {
                                $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                     ->whereRaw('et_payment.transaction_date = (
                                         SELECT MIN(ep.transaction_date)
                                         FROM et_payment ep
                                         WHERE ep.customer_id = et_customer.sno
                                     )');
                            })
                            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                            ->where('et_customer.status', 0)
                            ->where('et_customer.branch_id', $branchId)
                            ->where('et_lead.created_by', $staff->staff_id)
                            ->whereYear('et_payment.transaction_date', $year)
                            ->whereMonth('et_payment.transaction_date', $month)
                            ->where('et_transaction.payment_status', 1)
                            ->orderBy('et_customer.sno', 'asc')
                            ->get();
                      

                            $eciCustomerConvertCount = DB::table('et_customer')
                                ->select('et_customer.sno', 'et_customer.proposal_ids','et_customer.cus_name')
                                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                                ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                                ->join('et_payment', function($join) {
                                    $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                        ->whereRaw('et_payment.transaction_date = (
                                            SELECT MIN(ep.transaction_date)
                                            FROM et_payment ep
                                            WHERE ep.proposal_id = et_proposal.sno
                                        )');
                                })
                                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                                ->where('et_customer.status', 0)
                                ->where('et_customer.post_sale_check', 1)
                                ->where('et_proposal.post_sale_check', 1)
                                ->where('et_customer.branch_id', $branchId)
                                ->where('et_proposal.created_by', $staff->staff_id)
                                ->whereYear('et_payment.transaction_date', $year)
                                ->whereMonth('et_payment.transaction_date', $month)
                                ->where('et_transaction.payment_status', 1)
                                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                                ->where('et_proposal.status',0)
                                ->orderBy('et_proposal.sno', 'asc')
                                ->whereDay('et_payment.transaction_date', '<=', 15)
                                ->count();
                     
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                    //  $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    //     ->join('et_payment', function($join) {
                    //         $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                    //              ->whereRaw('et_payment.sno = (
                    //                  SELECT ep.sno
                    //                  FROM et_payment ep
                    //                  WHERE ep.customer_id = et_customer.sno
                    //                  ORDER BY ep.transaction_date ASC, ep.sno ASC
                    //                  LIMIT 1
                    //              )');
                    //     })
                    //     ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                    //     ->where('et_customer.branch_id', $branchId)
                    //     ->whereIn('et_customer.status', [0, 6])
                    //     ->where('et_lead.created_by', $staff->staff_id)
                    //      ->whereYear('et_payment.transaction_date', $year)
                    //     ->whereMonth('et_payment.transaction_date', $month)
                    //     ->where('et_transaction.payment_status', 1)
                    //     ->whereDay('et_payment.transaction_date', '<=', 15)
                    //     ->count();
                        
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            // foreach ($currentMonthCustomer as $customer) {
                        
                            //     // First: check if this customer has TESBO training
                            //     $hasTesbo = DB::table('et_training')
                            //         ->where('customer_id', $customer->sno)
                            //         ->where('branch_id', $branchId)
                            //         ->whereMonth('created_at', $month)
                            //         ->whereYear('created_at', $year)
                            //         ->where('tesbo_check', 2)
                            //         ->where('post_sale_check', '!=', 1)
                            //         ->exists();
                        
                            //     if ($hasTesbo) {
                            //         $tesboCount++;
                            //         continue; // skip crash/professional check if TESBO already counted
                            //     }
                        
                            //     // Then: check if customer has valid Professional or Crash training (not tesbo)
                            //     $nonTesboTrainings = DB::table('et_training')
                            //         ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                            //         ->where('et_training.customer_id', $customer->sno)
                            //         ->where('et_training.branch_id', $branchId)
                            //         ->whereMonth('et_training.created_at', $month)
                            //         ->whereYear('et_training.created_at', $year)
                            //         ->where('et_training.post_sale_check', '!=', 1)
                            //         ->where('et_training.tesbo_check', '!=', 2)
                            //         ->whereIn('et_course.course_type_id', [3, 4])
                            //         ->select('et_course.course_type_id')
                            //         ->get();
                        
                            //     $hasCrash = false;
                            //     $hasProfession = false;
                        
                            //     foreach ($nonTesboTrainings as $training) {
                            //         if ($training->course_type_id == 3) {
                            //             $hasProfession = true;
                            //         } elseif ($training->course_type_id == 4) {
                            //             $hasCrash = true;
                            //         }
                            //     }
                        
                            //     if ($hasCrash) $crashCount++;
                            //     if ($hasProfession) $professionCount++;
                            // }
                        
                            // $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                            $courseTypeTotal = 0;
                        }
                        // return $customerConvertCount;
                        // spot incentive 
                        if($incentive){
                            $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $customerConvertCountthismonth) * 100 : 0;
                            $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $customerConvertCountthismonth) * 100 : 0;
                            $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $customerConvertCountthismonth) * 100 : 0;
                            $crashTarget = $incentive->si_crash_course ?? 0;
                            $professionTarget = $incentive->si_profession_course ?? 0;
                            $tesboTarget = $incentive->si_tesbo_course ?? 0;
                            
                        }else{
                            $crashPercent =  0;
                            $professionPercent =  0;
                            $tesboPercent =  0;
                            $crashTarget =  0;
                            $professionTarget = 0;
                            $tesboTarget =  0;
                        }
                        
                        
                        // $crashPercent = $crashCount;
                        // $professionPercent = $professionCount;
                        // $tesboPercent = $tesboCount;
                        
                       
                        
                        // only condition: Crash must be ≤ targe
                           
                          
                          if ( $customerConvertCountthismonth  >= 20){
                              $siStatus = true;
                            // return $customerConvertCountthismonth;
                            if ($incentive->si_crash_course > 0) {
                                
                                // $siStatus = $siStatus && ($crashPercent >= $crashTarget);
                                $siStatus = $siStatus && (($crashPercent >= $crashTarget) || ($crashPercent <= $crashTarget) );
                            }
                            
                            if ($incentive->si_profession_course > 0) {
                                
                                $siStatus = $siStatus && ($professionPercent >= $professionTarget);
                            }
                            
                            if ($incentive->si_tesbo_course > 0) {
                                // return $siStatus;
                                $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
                            }
                          }else{
                              $siStatus = false;
                          }
                        //  return $currentMonthCustomer;
                        // return 'not coming good';
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                              
                                 $trainings = DB::table('et_proposal as t1')
                                        ->join(DB::raw('(
                                            SELECT MIN(sno) as min_sno
                                            FROM et_proposal
                                            WHERE post_sale_check = 0
                                            GROUP BY customer_id
                                        ) as t2'), 't1.sno', '=', 't2.min_sno')
                                        ->where('t1.customer_id', $customer->sno)
                                        ->select('t1.sno', 't1.customer_id',    't1.total_amount')
                                        ->get();
                            
                                    foreach ($trainings as $training) {
                                         // Determine course_id based on tesbo_check
                                        $course_id = null;
                                
                                        if (!$course_id) continue; // Skip if no course_id
                                
                                        $course = ManageCoursesModel::where('sno', $course_id)
                                            ->whereIn('course_type_id', [2, 3])
                                            ->first();
                                
                                        if (!$course) continue;
                                    $basePrice = $course->course_min_price;
                                    $soldPrice = $training->overall_fees;
                                    $profitAmount = $soldPrice - $basePrice;
                                    
                                    // if ($profitAmount > 0) {
                                        
                                       $originalAmount += $profitAmount; 
        
                                       $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                                      // return $pi_slabs;
                                        // Match against PI slabs
                                        foreach ($pi_slabs as $slab) {
                                            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                                $slabPercentage = $slab['percentage'];
                                                $rewardFromThis = ($originalAmount * $slabPercentage) / 100;
                        
                                                $piRewards = $rewardFromThis > 0 ? $rewardFromThis : 0;
                                                $piPercentage = $profitPercent;
                                                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                                break; // first matching slab
                                            }
                                        }
                                    // }
                                }
                            }
                        }
                         $piReward0 = $slabPercentage >0 ? ($originalAmount * $slabPercentage) / 100 : 0;
                         $piReward  = $piReward0 > 0 ?$piReward0 :0;
                        //  return $piReward;
                         //   return $rewardFromThisd;
                        // if ($currentMonthCustomer->isNotEmpty()) {
                        //   foreach ($currentMonthCustomer as $customer) {
                
                        //     // $payment = DB::table('et_proposal')->select('et_proposal.sno', 'et_proposal.customer_id')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     // //   ->where('et_training.tesbo_check', 0)
                        //     //   ->sum('et_proposal.total_amount');
                
                        //     // $total_payment += $payment;
                        //     $proposal_ids=json_decode($customer->proposal_ids);
                        //     $total_payment_grant = DB::table('et_proposal')
                        //     ->whereIn('sno', $proposal_ids)
                        //     ->where('status', 0) 
                        //     ->sum('grant_total_amount');
                       
                        //         $total_payment += $total_payment_grant;
                
                
                            
                            
                            
                        //     $total_paid_payment_slot = DB::table('et_proposal_pay_slot')
                        //                   ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
                        //                   ->where('status', 0)
                        //                   ->sum('paidAmount');
                
                        //     // $paid_payment = DB::table('et_proposal')->select( 'et_proposal.sno', 'et_proposal.customer_id')
                        //     // ->join('et_proposal_pay_slot','et_proposal.sno','=','et_proposal_pay_slot.proposal_sno')
                        //     //   ->where('et_proposal.customer_id', $customer->sno)
                        //     //   ->sum('et_proposal_pay_slot.paidAmount');
                
                        //     $total_paid_payment += $total_paid_payment_slot;
                            
                             
                            
                        //   }
                                
                        // }
                        $base_amount_paid=0;
                         $gst_percent = 18;
                        if ($currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                                $proposal_ids = DB::table('et_proposal')
                                    ->where('et_proposal.customer_id', $customer->sno)
                                    ->where('et_proposal.status', 0)
                                    ->whereNot('et_proposal.post_sale_check', 1)
                                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                                    ->pluck('sno')
                                    ->toArray();
                                    // return $proposal_ids;
                        
                                $proposals = DB::table('et_proposal')
                                    ->select('et_proposal.*', 'et_country_currencies.currency_code')
                                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                                    ->whereIn('et_proposal.sno', $proposal_ids)
                                    ->get();
                        
                                foreach ($proposals as $proposal) {
                                    // Paid slots for this proposal
                                    $paidAmount = DB::table('et_proposal_pay_slot')
                                        ->where('proposal_sno', $proposal->sno)
                                        ->where('status', 0)
                                        ->sum('paidAmount');
                        
                                    $grantAmount = $proposal->grant_total_amount;
                        
                                    // First remove GST from paidAmount (base value in proposal's currency)
                                    $basePaidLocal = $paidAmount / (1 + ($gst_percent / 100));
                        
                                    if ($proposal->currency_id == 70) {
                                        // INR: add directly
                                        $total_paid_payment += $paidAmount;
                                        $total_payment += $grantAmount;
                                        $base_amount_paid += $basePaidLocal;
                                    } else {
                                        // Non-INR: convert both amounts and base value
                                        $currency_code = $proposal->currency_code;
                                        $total_paid_payment += $helper->ConvertedAmountInr($currency_code, $paidAmount);
                                        $total_payment += $helper->ConvertedAmountInr($currency_code, $grantAmount);
                                        $base_amount_paid += $helper->ConvertedAmountInr($currency_code, $basePaidLocal);
                                    }
                                }
                            }
                        }
                
                
                        // average 
                        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $gst_percent = 18;
             
                        // $base_amount_paid = $total_paid_payment / (1 + ($gst_percent / 100));
                        
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        // $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $totalAllPayment +=$total_payment;
                        // $totalAllPaidPayment +=$base_amount_paid;
                         // ECI Logic
                     
                        $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                        // $eciActualPercentage = $customerConvertCountthismonth > 0 ? ($eciCustomerConvertCount / $customerConvertCountthismonth) * 100 : 0;
                        $eciActualPercentage = number_format($eciActualPercentage, 2);
                        $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
            
                        // average 
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                        // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                
                        // $totalAllPayment += $total_payment;
                        // $totalAllPaidPayment += $total_paid_payment;
                    }
                  
                    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->join('et_payment', function($join) {
                                    $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                                        ->whereRaw('et_payment.sno = (
                                            SELECT ep.sno
                                            FROM et_payment ep
                                            WHERE ep.customer_id = et_customer.sno
                                            ORDER BY ep.transaction_date ASC, ep.sno ASC
                                            LIMIT 1
                                        )');
                                })
                        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                        ->where('et_transaction.payment_status', 1)
                        ->whereRaw('DATE(et_payment.transaction_date) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_payment.transaction_date as customer_created_at',
                            'et_lead.registered_date as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                

                    foreach ($allConverted as $row) {
                      
                      $mobile = $row->lead_mobile;
                        // Get the latest call
                         $lastCall = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->first();
                    
                            
                        $totalCallCount = DB::table('et_call_tracker')->select('sno')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->count();
                        // Attach values to row
                        $row->call_created_at = $lastCall->call_start_date ?? null;
                        $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                        $row->call_count = $totalCallCount;
                    }
        
                    
                        
                        // return $allConverted;
                        
                    $convertedToday = 0;
                    $convertedMonth = 0;
                    $convertedOldMonth = 0;
                $customerDetails=[];
                    foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                            // include call count
                        // if ($customerDate ===  $leadDate && $call_count ===  1) {
                        //     $convertedToday++;
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     $leadDate >= $startOfMonth && $leadDate <= $dates &&
                        //     $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                        //         $callDate = Carbon::parse($call->call_start_date);
                        //         return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                        //     })
                            
                        // ) {
                        //     $convertedMonth++;
                        //     $customerMobiles[] = $mobile; 
                        // } elseif (
                        //     $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        //     ($leadDate < $startOfMonth || $leadDate > $dates)
                        // ) {
                        //     $convertedOldMonth++;
                        // }
                        $customerData = [
                            'customerDate' => $customerDate,
                            'leadDate'     => $leadDate,
                            'mobile'       => $mobile
                        ];
                        if ($customerDate ===  $leadDate) {
                            $convertedToday++;
                            //   $customerDetails[] = $customerData; 
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates
                        ) {
                            $convertedMonth++;
                           
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                    // return $customerDetails;
                    // return $convertedToday;
                    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                    // Old month = always 0
                    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                  
                    // 10x award calculation       
                    $actualConversion      = $customerConvertCount;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;
                   
                    //   $tenxStatus = (
                    //         $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    //         $actualConversion >= $targetConversion &&
                    //         $actualABV >= $targetABV &&
                    //         $actualACV >= $targetACV
                    //     );
                     $tenxStatus = (
                        $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                        $actualConversion >= $targetConversion 
                    );
                   // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                    
                    $biReward = $biAchievedCount * $biPerConversion;
                    $biStatus = $biAchievedCount > 0;
                    
                     //   for promance incentive
                  $targetMissedCallRate = $incentive->performance_incentive_missed_call ?? 0;
                  $targetOutgoingCallCount = $incentive->performance_incentive_outgoing_call_count ?? 0;
                  
                  $actualOutgoingCallCount=0;
                  $actualMissedCallRate=0;
                  $actualMissedCount=0;
                  
                  $actualCallCount = DB::table('et_call_tracker')
                    ->selectRaw('
                        COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                        COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                        COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                        COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                        COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                    ')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                // $actualCallCount = DB::table('et_call_tracker')
                //     ->selectRaw('
                //         COUNT(CASE WHEN call_status = 1 THEN 1 END) AS incoming_call_count,
                //         COUNT(CASE WHEN call_status = 0 THEN 1 END) AS outgoing_call_count,
                //         COUNT(CASE WHEN call_status = 2 THEN 1 END) AS missedcall_count,
                //         COUNT(CASE WHEN call_status = 3 THEN 1 END) AS rejected_call_count,
                //         COUNT(CASE WHEN call_status = 4 THEN 1 END) AS dialedcall_count
                //     ')
                //     ->where('branch_id', $branchId)
                //     ->where('branch_staff_id', $staff->staff_id)
                //     ->where('call_start_date', '>=', "$year-$month-01")
                //     ->where('call_start_date', '<', Carbon::create($year, $month)->addMonth()->format('Y-m-d'))
                //     ->first();

                //   return $actualCallCount;
                   $actualOutgoingCallCount = $actualCallCount->outgoing_call_count ?? 0;
                   $actualMissedCount = $actualCallCount->missedcall_count ?? 0;
                  
                  $actualOutgoingPerDay= $dayCountMonth > 0 ? round($actualOutgoingCallCount / $dayCountMonth) : 0;
                  $actualOutgoingPerDay=round($actualOutgoingPerDay);
                  
                  // Missed call ratio
                    $total_calls = $actualCallCount->incoming_call_count + $actualCallCount->missedcall_count ;
                    $actualMissedCallRate = $total_calls > 0 ? ($actualMissedCount / $total_calls) * 100 : 0;
                    $actualMissedCallRate=round($actualMissedCallRate,1);
                    
                    
                  
                  $performIncentStatus = (
                        $targetMissedCallRate > 0 && $targetOutgoingCallCount > 0 && 
                        $actualOutgoingPerDay >= $targetOutgoingCallCount &&   $targetMissedCallRate >= $actualMissedCallRate
                    );

                    // return $performIncentStatus;
                  
                  
                  
                  
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $customerConvertCountthismonth . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" 
                                                      >
                                                    ' . $actualConversion . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            'eci' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $eciStatus,
                                'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($targetConversion . ' - ' . $actualConversion . ' = (' . $biAchievedCount . ')') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($biAchievedCount . ' × ' . $biPerConversion) . 
                                            '</span>',
                                'status' => $tenxStatus && $biStatus,
                                'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                            ],
                        
                           'pi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $piReward > 0,
                                'reward' => ($tenxStatus && $piReward > 0)
                                    ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                    : 0,
                            ],
                        
                            'si' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlabSI ? $matchedSlabSI . ' = ' . round($slabPercentageSI, 2) . '%' : 'No Matching Slab')  . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                             round($siPercentage, 2) . '% — ₹' . number_format($originalAmountSI) . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $siStatus,
                                'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                            ],
                        
                            'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Missed Call Rate">' . $targetMissedCallRate . '%</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Outgoing Call Count Per day">' . $targetOutgoingCallCount . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info"  data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Missed Call Rate"
                                                      >
                                                    ' . $actualMissedCallRate . '%
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Actual Outgoing Call Count Per day"
                                                      >
                                                    ' . $actualOutgoingPerDay . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformCallModal(' . $staff->staff_id . ')" >Details</span>
                                             ',
                                
                                'status' => $tenxStatus && $performIncentStatus,
                                'reward' => ($tenxStatus && $performIncentStatus) ? ($incentive->$performIncentStatus ?? 0) : 0,
                            ],
        
                        
                           'li' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) 
                                                ? 'Achieved' 
                                                : 'Not Achieved') . 
                                            '</span>',
                                'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
                                'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward)
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ]
        
                    ];
            
            } 
           
           
            
            if ($isCollection) {
                return "CRE";
                 $refferal_count = DB::table('et_referral_persons')
                      ->where('branch_id', $branchId)
                      ->where('referral_id', $staff->staff_id)
                      ->where('status', 0)
                      ->where('referral_type', 2)
                      ->whereYear('created_at', $year)
                      ->whereMonth('created_at', $month)
                      ->count();
                $dropoutCustomers = DB::table('et_training')
                        ->where('status', 2)
                        ->pluck('customer_id')
                        ->toArray();
                       
                $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_customer.sno', $dropoutCustomers) 
                    ->whereBetween('et_customer.created_at', [$startDateold, $endDateold])
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
               
            
                // here $secondPaymentCustomers  we need colclude the dat get $hacAmount
                  $hacAmount = DB::table('et_payment')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
                        ->where('et_payment.status', 1) // paid amoun
                        ->whereYear('et_payment.initialPayDate', $year)
                        ->whereMonth('et_payment.initialPayDate', $month)
                        ->where('et_payment.branch_id', $branchId)
                        ->sum('et_payment.paidAmount');
                        // return $hacAmount;
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    //  return $ten_x;
                    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
                    $isoutstandingRequired        = $ten_x['no_of_outstanding_10x'] == "1";
                    $isPostsaleRequired        = $ten_x['no_of_post_sale_10x'] == "1";
                   
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isHacCostingRequired) {
                        $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                        $actaulTenx  = $hacAmount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isoutstandingRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } 
                    
                        $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulREI  = $refferal_count ?? 0;
                        $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                        
                         $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                         
                        $EIaward = 0;
                        $EIStatus = false;
                        $targetEI = 0;
                        $actaulEI = 0;
                        
                        if ($isHacCostingRequired) {
                            $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                            $actaulTenx  = $hacAmount ?? 0;
                            $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
                        
                            // Only if HAC 10X achieved, calculate EI
                            if ($tenxStatus && $incentive->excess_incentive > 0) {
                                $excessAmount = $actaulTenx - $targetTenx;
                        
                                if ($excessAmount > 0) {
                                    $targetEI = $incentive->excess_incentive . '%'; // just for display
                                    $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
                                    $EIaward = $actaulEI;
                                    $EIStatus = true;
                                }
                            }
                        }
                        $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulTenx . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCollectionModal(' . $staff->staff_id . ')" >Details</span>', 
                                             
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => ($tenxStatus && $incentive->tenx_warrior) ?  : 0,
                            ],
                        
                            
                            'EI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetEI . '</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . number_format($actaulEI, 2) . '</span>',
                                'status' => $EIStatus,
                                'reward' => number_format($EIaward, 2),
                            ],
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isCRE) {
                return "CRE";
                $helper = new \App\Helpers\Helpers();
                
                 $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                
                $targetTenx = $goalsetData[$staff->staff_id]->harvesting_percentage ?? 85;
                if($incentive){
                    $eci_target = $incentive->eci_count ?? 0;
                    $bi_target_percent = $incentive->bi_amount ?? 0;
                    $bi_target = $targetTenx ?? 0;
                    $spot_cre_incentive_target = $incentive->spot_incentive_percent ?? 0;
                    $spot_cre_incentive_reward = $incentive->spot_incentive_month ?? 0;
                    $ri_reward = $incentive->ri_amount ?? 0;
                }else{
                    $eci_target = 70;
                     $bi_target = $targetTenx ;
                     $bi_target_percent = 2;
                     $spot_cre_incentive_target = 80;
                     $spot_cre_incentive_reward = 2000;
                     $ri_reward = 750;
                }
                
               
                $cutoffDate = Carbon::create($year, $month, 15)->format('Y-m-d');
                $tenxStatus = false;
                $actaulTenx = 0;
                $gstPercentage=18;
                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
                
               $tragetHarvesting = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper) {
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($branch ? $gstPercentage / 100 : 0.18);
            
                    // Calculate the converted amount based on the payment status and currency
                    if ($row->payment_status == 1) {
                        if ($row->currency_code != "INR") {
                            $converted = ($row->total_amount_inr && $row->total_amount_inr > 0)
                                ? $row->total_amount_inr
                                : $row->paid_amount;
                        } else {
                            $converted = $row->paid_amount;
                        }
                        $netAmount = $converted / (1 + $gstRate);
                    } else if ($row->currency_code != "INR") {
                        $converted = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);
                        $netAmount = $converted / (1 + $gstRate);
                    } else {
                        $converted = $row->payable_amount;
                        $netAmount = $converted / (1 + $gstRate);
                    }
            
                    return $netAmount;
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 1 decimal place
                    return $carry + $item;
                }, 0);
            
     
                $tragetHarvesting = round($tragetHarvesting);
            
            
                $collectionHarvesting = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1)
                ->where('et_proposal.cre_id', $staff->staff_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code"
                )
                ->get()
                ->map(function ($row) use ($gstPercentage, $helper) {
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;
            
                    // ✅ Use proposal-specific GST, fallback to branch GST
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);
            
                    // ✅ Net without GST
                    $netAmount = $amountInr / (1 + $gstRate);
            
                    // Round the net amount to two decimal places
                    return round($netAmount, 2);
                })
                ->reduce(function ($carry, $item) {
                    // Sum the values and round to 2 decimal places
                    return round($carry + $item, 2);
                }, 0);

                $collectionHarvesting = round($collectionHarvesting, 1);
                
                
                
                 $collectionEci = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                    ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                $collectionEci = round($collectionEci, 1);
                
                 $collectionSpot = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->where('et_lead.created_by', '>', 1)
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                    ->where('et_customer.status', 0)
                    ->where('et_transaction.payment_status', 1)
                    ->where('et_proposal.cre_id', $staff->staff_id)
                    ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->select(
                        "et_proposal_pay_slot.payable_amount as payable_amount",
                        "et_transaction.payment_status",
                        "et_transaction.total_amount_inr",
                        "et_payment.paid_amount",
                        "et_proposal.gst_perc",
                        "et_country_currencies.currency_code as currency_code"
                    )
                    ->get()
                    ->map(function ($row) use ($gstPercentage, $helper) {
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;
                
                        // ✅ Use proposal-specific GST, fallback to branch GST
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);
                
                        // ✅ Net without GST
                        $netAmount = $amountInr / (1 + $gstRate);
                
                        // Round the net amount to two decimal places
                        return round($netAmount, 2);
                    })
                    ->reduce(function ($carry, $item) {
                        // Sum the values and round to 2 decimal places
                        return round($carry + $item, 2);
                    }, 0);

                    $collectionSpot = round($collectionSpot, 1);
                
                    $monthlyTargets = [];
            

                    // ! 10x Award
                    $monthlyCollectionsINR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $monthlyCollectionsOther = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $convertedCollections = [];
                    foreach ($monthlyCollectionsOther as $staffId => $target1) {
                        $convertedAmount = $helper->ConvertedAmountInr($target1->currency_code, $target1->monthly_collection);
                        if (!isset($convertedCollections[$staffId])) {
                            $convertedCollections[$staffId] = 0;
                        }
                        $convertedCollections[$staffId] += $convertedAmount;
                    }

                    $monthlyCollections = [];
                    foreach ($monthlyCollectionsINR as $staffId => $inrCollection) {
                        $monthlyCollections[$staffId] = [
                            'total_collection_inr' => $inrCollection->monthly_collection,
                        ];
                    }

                    // Add converted non-INR amounts to the collection array
                    foreach ($convertedCollections as $staffId => $convertedAmount) {
                        if (isset($monthlyCollections[$staffId])) {
                            $monthlyCollections[$staffId]['total_collection_inr'] += $convertedAmount;
                        } else {
                            $monthlyCollections[$staffId] = [
                                'total_collection_inr' => $convertedAmount,
                            ];
                        }
                    }

                    // ! Early Cash Incentive
                    $cre_eci_inr = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $cre_eci_other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                    ->whereDate('et_payment.transaction_date', '<=', $cutoffDate)
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', '!=', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->groupBy('et_proposal.cre_id', 'et_country_currencies.currency_code')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        'et_country_currencies.currency_code',
                        DB::raw('SUM(et_payment.paid_amount) as collection_by_15th')
                    )
                    ->get()
                    ->keyBy('staff_id');

                    $convertedCollectionsBy15th = [];
                    foreach ($cre_eci_other as $staffId => $target2) {
                        $convertedAmount = $helper->ConvertedAmountInr($target2->currency_code, $target2->collection_by_15th);

                        if (!isset($convertedCollectionsBy15th[$staffId])) {
                            $convertedCollectionsBy15th[$staffId] = 0;
                        }

                        $convertedCollectionsBy15th[$staffId] += $convertedAmount;
                    }

                $collectionsBy15th = [];
                foreach ($cre_eci_inr as $staffId => $inrCollection) {
                    $collectionsBy15th[$staffId] = [
                        'total_collection_eci' => $inrCollection->collection_by_15th,
                    ];
                }

                // Add converted foreign currency collections
                foreach ($convertedCollectionsBy15th as $staffId => $convertedAmount) {
                    if (isset($collectionsBy15th[$staffId])) {
                        $collectionsBy15th[$staffId]['total_collection_eci'] += $convertedAmount;
                    } else {
                        $collectionsBy15th[$staffId] = [
                            'total_collection_eci' => $convertedAmount,
                        ];
                    }
                }

                // ! Spot Incentive
                $cre_spot_INR = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                $cre_spot_Other = DB::table('et_payment')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_payment.proposal_id')
                    ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->whereYear('et_payment.transaction_date', $year)
                    ->whereMonth('et_payment.transaction_date', $month)
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal.currency_id', 70)
                    ->whereNotIn('et_proposal.proposal_status', [0, 2])
                    ->whereColumn('et_payment.transaction_date', '<', 'et_proposal_pay_slot.nextPayDate')
                    ->groupBy('et_proposal.cre_id')
                    ->select(
                        'et_proposal.cre_id as staff_id',
                        DB::raw('SUM(et_payment.paid_amount) as monthly_collection_before_next_paydate')
                    )
                    ->get()
                    ->keyBy('staff_id');

                // Convert foreign currency collections to INR
                $convertedCollectionsSpotOther = [];
                foreach ($cre_spot_Other as $staffId => $collection) {
                    $convertedAmount = $helper->ConvertedAmountInr($collection->currency_code ?? 'default_currency_code', $collection->monthly_collection_before_next_paydate);

                    if (!isset($convertedCollectionsSpotOther[$staffId])) {
                        $convertedCollectionsSpotOther[$staffId] = 0;
                    }

                    $convertedCollectionsSpotOther[$staffId] += $convertedAmount;
                }

                // Prepare INR collections
                $collectionsSpotINR = [];
                foreach ($cre_spot_INR as $staffId => $collection) {
                    $collectionsSpotINR[$staffId] = [
                        'total_collection_spot' => $collection->monthly_collection_before_next_paydate,
                    ];
                }

                // Combine converted foreign collections into INR collections
                foreach ($convertedCollectionsSpotOther as $staffId => $convertedAmount) {
                    if (isset($collectionsSpotINR[$staffId])) {
                        $collectionsSpotINR[$staffId]['total_collection_spot'] += $convertedAmount;
                    } else {
                        $collectionsSpotINR[$staffId] = [
                            'total_collection_spot' => $convertedAmount,
                        ];
                    }
                }


                // Referal Incentive
                $cre_ref_count =  DB::table('et_proposal')
                ->select(
                    'et_proposal.service_title',
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.country_code',
                    'et_customer.cus_mobile',
                    'et_payment.transaction_date as created_date',
                    'et_payment.transaction_date as created_at',
                    'et_transaction.payment_id',
                    'et_transaction.sno as transaction_id',
                    'et_payment.paid_amount'
                )
                ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->where('et_proposal.branch_id', $branchId)
                ->where('et_proposal.referral_id', $staff->staff_id)
                ->where('et_proposal.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->where('et_payment.status', 0)
                ->orderBy('et_proposal.sno', 'asc')
                ->count();

                // return $cre_spot;

               
                $collection = 0;

                // ! Total Target
                
                // if($incentive){
                //     $targetTenx= $incentive ? $incentive 85;
                // }else{
                //     $targetTenx = 85;
                // }
                

                // ! 10X Calculation
                $collection = $collectionHarvesting ?? 0;
                $collectionPercentage = $tragetHarvesting > 0 ? ($collection / $tragetHarvesting) * 100 : 0;
                $collectionPercentage=round($collectionPercentage);
                $tenxStatus = $collectionPercentage >= $targetTenx;
                
               
                // ! Early Cash Incentive
                $eci_collection = $collectionEci ?? 0;
                $eci_percentage = $tragetHarvesting > 0 ? ($eci_collection / $tragetHarvesting) * 100 : 0;
                $eci_achieved = ($eci_target && $eci_percentage >= $eci_target) ? $eci_target : 0;

                //    return $collectionSpot;
                //  ! Spot Incentive
                $spot_collection = $collectionSpot ??  0;
                $spot_percentage = $collection > 0 ? ($spot_collection / $collection) * 100 : 0;
                $spot_achieved = $spot_percentage >= ($spot_cre_incentive_target ?? 0);
                
                $bi_value =0;
                $bonusAmount =0;
                $excessValue =0;
                if ($collectionPercentage > $bi_target) {
                    $excessPercentage = $collectionPercentage - $bi_target;
                   
                    $excessValue = ($excessPercentage / 100) * $tragetHarvesting;
                    $bi_value =($bi_target_percent / 100);
                    
                    $bonusAmount = round($excessValue * $bi_value); 
                }
                // ! Bonus Incentive
                
               
                $bi_achieved = (($bi_target) && $collectionPercentage > $bi_target) ? true : false;
                $bi_reward = $bi_achieved ? $bonusAmount : 0;

                // ! Referal Incentive
                $ri_amount = ($cre_ref_count ?? 0) * $ri_reward;
                $ri_achieved = $ri_amount > 0;

                // ! Luxury Incentive
                $luxuryData = $incentive && isset($incentive->luxury_incentive) ? json_decode($incentive->luxury_incentive, true) : [];
                $early_cash_incentive = $luxuryData['early_cash_incentive'] ?? 0;
                $tenx_award_luxury = $luxuryData['tenx_award'] ?? 0;
                $bonus_incentive = $luxuryData['bonus_incentive'] ?? 0;
                $spot_incentive = $luxuryData['spot_incentive'] ?? 0;
                $referral_incentive = $luxuryData['referral_incentive'] ?? 0;
                $reward = $luxuryData['reward'] ?? '0';
                // $tenxStatus=false;
                $tenx_luxury_achieved = $tenx_award_luxury ? ($tenxStatus ? true : false) : true ;
                $bi_luxury_achieved = $bonus_incentive ? ($bi_achieved ? true : false) : true ;
                $spi_luxury_achieved = $spot_incentive ? ($spot_achieved ? true : false) : true ;
                $ri_luxury_achieved = $referral_incentive ? ($ri_achieved ? true : false) : true ;
                // $luxury_achieved = ($tenxStatus && $early_cash_incentive && $eci_achieved && $bonus_incentive && $bi_achieved && $spot_incentive && $spot_achieved&& $referral_incentive && $ri_achieved);
                $luxury_achieved = ($tenx_luxury_achieved && $bi_luxury_achieved && $spi_luxury_achieved && $ri_luxury_achieved);

                $result[] = [
                    'staff_id' => $staff->staff_id,
                    'staff_name' => $staff->staff_name,
                    'staff_image' => $staff->staff_image,
                    'role_id' => $staff->role_id,
                    'nick_name' => $staff->nick_name,
                    'sub_department_name' => $staff->sub_department_name,
                    'department_name' => $staff->department_name,

                    'incentives' => [
                        'tenx_award' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '%</span> <span class="fw-bold fs-2 ms-2 badge bg-label-secondary">' . number_format($tragetHarvesting) . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $collectionPercentage . '%
                                             </span>
                                             <span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . number_format($collection) . '
                                             </span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCreActualDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                             

                            'status' => $tenxStatus,
                            'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                        ],

                        'eci' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . ($eci_target ?? 0) . '%' . '</span>',
                            'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eci_percentage) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                            'status' => $tenxStatus && $eci_achieved,
                            'reward' => ($tenxStatus && $eci_achieved) ? $incentive->eci_reward : 0 ,
                        ],


                        'bi' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">Greater Than ' . ($bi_target ? $bi_target : 0) . '%' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . ($bi_achieved ? (round($excessValue) . ' * '. $bi_target_percent .'% = ' . number_format($bi_reward, 0)) : '0') . '
                                             </span> <span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCrebonusDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $bi_achieved,
                            'reward' => ($tenxStatus && $bi_achieved) ? $bi_reward : 0 ,
                        ],

                        'sp' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $spot_cre_incentive_target . '%' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . number_format($spot_percentage, 0) . '%' . '
                                             </span><span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreSpotDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $spot_achieved,
                            'reward' => ($tenxStatus && $spot_achieved) ? ($spot_cre_incentive_reward ?? 0) : 0 ,
                        ],

                        'ri' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'.$ri_reward.' Per Successful Referral">' .$ri_reward. '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $cre_ref_count . ' * '.$ri_reward.' =' . $ri_amount  . '
                                             </span> <span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCreRefrlDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                            'status' => $tenxStatus && $ri_achieved,
                            'reward' => ($tenxStatus && $ri_achieved) ? $ri_amount : 0 ,
                        ],

                        'li' => [
                            'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 'All Incentives Achieved' . '</span>',

                            'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . ($luxury_achieved ? 'All Incentives Achieved' : 'Not Achieved') . '
                                             </span>',

                            'status' => $luxury_achieved,
                            'reward' => $luxury_achieved ? $reward : 0,
                        ],


                    ]

                ];
            }
            
            if ($isJournalCordinator) {
                
                    return "journal";

                    $currentMonthJournal = Carbon::createFromDate($year, $month, 1);
                    $lastTwoMonths = [
                        $currentMonthJournal->copy()->subMonth(1),
                        $currentMonthJournal->copy()->subMonth(2),
                    ];

                    $goalsetteamLast = GoalSetStaffModel::where('staff_id', $staff->staff_id)
                        ->where('status_10x', 1)
                        ->where(function ($query) use ($lastTwoMonths) {
                            foreach ($lastTwoMonths as $date) {
                                $query->orWhere(function ($q) use ($date) {
                                    $q->whereMonth('goal_date', $date->month)
                                    ->whereYear('goal_date', $date->year);
                                });
                            }
                        })
                        ->get();
                    $isConsistent = $goalsetteamLast->count() == 2;
                    // return  $isConsistent;
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                    $publish_target= $goalsetData[$staff->staff_id]->no_of_papers ?? 8;
                    if( $incentive ){
                        $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
                        $tenx_amount = $incentive->tenx_award ?? 1000;
                        $exiTarget = $publish_target ?? 8;
                        $exiAcheiveAmount = $incentive->extra_acheive_award ?? 1000;
                        $doubleXITarget = $publish_target ? $publish_target*2 : 16;
                        $doubleXIAmount= $incentive->doublex_award ?? 5000;
                        $perform_attend_percent= $incentive->perform_incent_attend ?? 100;
                        $performance_incentive_reward = $incentive->performance_incentive_reward ?? 1000;
                    }else{
                        $check_accepted_paper=1;
                        $tenx_amount =  1000;
                        $exiTarget = 8;
                        $exiAcheiveAmount =  1000;
                        $doubleXITarget =  16;
                        $doubleXIAmount=  5000;
                        $perform_attend_percent=  100;
                        $performance_incentive_reward =  1000;
                    }
                    $publicationCurrentMonthCount = 0;
                    
                    $tenxStatus = false;
                    $exiStatus = false;
                    $doubleXIncent = false;
                    $permformJCIncent = false;
                    $priviousGoalsetAwared = $isConsistent ? true:false;


                     $publicationCurrentMonthCount = DB::table('et_manage_journal as mj')
                        ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                        ->leftJoin('et_journal_history as jh', function ($join) {
                            $join->on('mj.sno', '=', 'jh.journal_id')
                                ->where('jh.status', 5);
                        });

                    if ($check_accepted_paper == 1) {
                        $publicationCurrentMonthCount = $publicationCurrentMonthCount->whereIn('mj.status', [5, 7, 8]);
                    } else {
                        $publicationCurrentMonthCount = $publicationCurrentMonthCount->where('mj.status', 8);
                    }

                    $publicationCurrentMonthCount = $publicationCurrentMonthCount
                        ->where('cs.jc_staff', $staff->staff_id)
                        ->where(function ($query) use ($year, $month) {

                            $query->where(function ($q) use ($year, $month) {
                                $q->where('mj.status', 8)
                                ->whereYear('mj.publish_date', $year)
                                ->whereMonth('mj.publish_date', $month);
                            })

                            ->orWhere(function ($q) use ($year, $month) {
                                $q->whereIn('mj.status', [5, 7])
                                ->whereYear('jh.accepted_date', $year)
                                ->whereMonth('jh.accepted_date', $month);
                            });

                        })
                        ->count();

                        $publicationCurrentMonthData = DB::table('et_manage_journal as mj')
                            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                            ->leftJoin('et_journal_history as jh', function ($join) {
                                $join->on('mj.sno', '=', 'jh.journal_id')
                                    ->where('jh.status', 5);
                            });

                        if ($check_accepted_paper == 1) {
                            $publicationCurrentMonthData = $publicationCurrentMonthData->whereIn('mj.status', [5, 7, 8]);
                        } else {
                            $publicationCurrentMonthData = $publicationCurrentMonthData->where('mj.status', 8);
                        }

                        $publicationCurrentMonthData = $publicationCurrentMonthData
                            ->where('cs.jc_staff', $staff->staff_id)
                            ->where(function ($query) use ($year, $month) {

                                $query->where(function ($q) use ($year, $month) {
                                    $q->where('mj.status', 8)
                                    ->whereYear('mj.publish_date', $year)
                                    ->whereMonth('mj.publish_date', $month);
                                })

                                ->orWhere(function ($q) use ($year, $month) {
                                    $q->whereIn('mj.status', [5, 7])
                                    ->whereYear('jh.accepted_date', $year)
                                    ->whereMonth('jh.accepted_date', $month);
                                });

                            })
                             ->orderByRaw("
                                    CASE 
                                        WHEN mj.status IN (5, 7) THEN jh.accepted_date
                                        ELSE mj.publish_date
                                    END ASC
                                ")
                            ->limit($exiTarget)
                            ->pluck('mj.sno');
                        
                    

                
                        $publicationAfter15thCount = DB::table('et_manage_journal as mj')
                            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                            ->leftJoin('et_journal_history as jh', function ($join) {
                                $join->on('mj.sno', '=', 'jh.journal_id')
                                    ->where('jh.status', 5);
                            });
                             if ($check_accepted_paper == 1) {
                                $publicationAfter15thCount = $publicationAfter15thCount->whereIn('mj.status', [5, 7, 8]);
                            } else {
                                $publicationAfter15thCount = $publicationAfter15thCount->where('mj.status', 8);
                            }

                            $publicationAfter15thCount = $publicationAfter15thCount
                                ->where('cs.jc_staff', $staff->staff_id)
                                ->whereNotIn('mj.sno',$publicationCurrentMonthData)
                                ->where(function ($query) use ($year, $month) {

                                    $query->where(function ($q) use ($year, $month) {
                                        $q->where('mj.status', 8)
                                        ->whereYear('mj.publish_date', $year)
                                        ->whereMonth('mj.publish_date', $month)
                                        ->whereDay('mj.publish_date', '<=', 15);
                                    })

                                    ->orWhere(function ($q) use ($year, $month) {
                                         $q->whereIn('mj.status', [5, 7])
                                        ->whereYear('jh.accepted_date', $year)
                                        ->whereMonth('jh.accepted_date', $month)
                                        ->whereDay('jh.accepted_date', '<=', 15);
                                    });

                                })
                                ->count();
                        
                       
                        // return $publicationAfter15thCount;
                      

                    
                    $tenxStatus = ($publicationCurrentMonthCount >=$publish_target);
                    $exiStatus = ($publicationCurrentMonthCount >=$exiTarget);
                    $exiAmountAward = $publicationAfter15thCount > 0 ? $publicationAfter15thCount *$exiAcheiveAmount : 0;
                    $doubleXIncent = ($publicationCurrentMonthCount >=$doubleXITarget);

                     $startDate = Carbon::create($year, $month, 1);
                    $currentDate = Carbon::now();
                    $endDate = ($currentDate->year == $year && $currentDate->month == $month) ? $currentDate : $startDate->copy()->endOfMonth();

                    $dayCounts = 0;
                    $dateSrt = $startDate->copy();
                    while ($dateSrt->lte($endDate)) {
                        if (!$dateSrt->isSunday()) {
                            $dayCounts++;
                        }
                        $dateSrt->addDay();
                    }
                    
                 
                    $presentDays = DB::table('et_staff_attendance')
                        ->whereIn('et_staff_attendance.attendance', ['P','HD','PR','OD'])
                        ->where('et_staff_attendance.staff_id', $staff->staff_id) 
                        // ->where('et_staff_attendance.staff_id', 62) 
                        ->whereYear('et_staff_attendance.date', $year)
                        ->whereMonth('et_staff_attendance.date', $month)
                        ->count();
                    
                    $attendance_percent= $dayCounts >0 ? round(($presentDays / $dayCounts) * 100, 1) :0;
                  
                  $permformJCIncent = (
                        $attendance_percent > 0 && 
                        $attendance_percent >= $perform_attend_percent && $priviousGoalsetAwared
                    );
                  

                
                    
                     $terms = DB::table('et_terms_conditions')->where('branch_id', $staff->branch_id)->where('status',0)->orderBy('sno', 'desc')->first();
                    
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                         'branch_name' => $staff->branch_name,
                        'bh_signature' => $terms->signature ?? '1755151615_2.png',
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Publish Paper Target Count">' . $publish_target . '</span> ',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Paper Count">
                                                    ' . $publicationCurrentMonthCount . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualJournalDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($tenx_amount ?? 0) : 0,
                            ],
                        
                            'exi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary"> Greater Than ' . $exiTarget  .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $publicationAfter15thCount . '*'.$exiAcheiveAmount. '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualExtraJournalDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $exiStatus,
                                'reward' => ($tenxStatus && $exiStatus) ? ($exiAmountAward ?? 0) : 0,
                            ],
                        
                            'doublex' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($doubleXITarget) . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($publicationCurrentMonthCount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable ms-1" style="cursor:pointer" onclick="openActualDoubleXJournalDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $doubleXIncent,
                                'reward' => ($tenxStatus && $doubleXIncent) ? $doubleXIAmount : 0,
                            ],
                        
                           'perform_incent' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($perform_attend_percent) . 
                                            ' %</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Attendance Percentage">' . 
                                            $attendance_percent . ' %' . 
                                            '</span><span class="fw-bold ms-1 fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openPerformAttendanceModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $permformJCIncent,
                                'reward' => ($tenxStatus && $permformJCIncent)
                                    ? ($performance_incentive_reward)
                                    : 0,
                            ],
                        ]
        
                    ];
            
            } 
            
            if ($isProduction) {
                
                return "CRE";
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->where('et_training.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('et_training.branch_id', $branchId)
                    ->where('et_training.staff_id', $slotType->staff_id)
                     ->where('et_training.status', '!=', 2)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
                $current_date = date('Y-m-d');
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    // ->whereDate('start_date', '<=', $current_date)
                    // ->whereDate('end_date', '>=', $current_date)
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
                    $isStudentMinRequired        = $ten_x['min_no_of_students_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isStudentMinRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                   //   return $pdiStatus;
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'PDI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . 
                                            '</span>',
                            
                                'status' =>  $pdiStatus,
                                'reward' => $tenxStatus && $pdiReward
                                    ? (($pdiReward >= 0 ? '+' : '-') . round(abs($pdiReward)))
                                    : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isPC) {
                return "CRE";
                $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
            
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    // return $ten_x;
                    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    }  elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                    
                    $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                    $actaulREI  = $refferal_count ?? 0;
                    $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                    
                    $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                   //   return $pdiStatus;
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
        
            return response()->json([
                'status' => 200,
                'data' => $result
            ]);
    }

  // cre details
    public function getCreCustomers(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();
        
        $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_payment.transaction_date as created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

                $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staffId)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                $gstPercentage=18;

                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staffId)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
            // return $tragetHarvestingIds;
            $balance_amount =0;
            $harvesting_amount =0;
            $collection_amount =0;
        $collectionHarvesting = DB::table('et_proposal_pay_slot')
            ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
            ->where('et_customer.status', 0)
            // ->where('et_transaction.payment_status', 1)
            ->where('et_proposal.cre_id', $staffId)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->select(
                "et_proposal_pay_slot.payable_amount as payable_amount",
                "et_transaction.payment_status",
                "et_transaction.total_amount_inr",
                "et_payment.paid_amount",
                "et_proposal.gst_perc",
                "et_country_currencies.currency_code as currency_code",
                "et_country_currencies.currency_symbol",
                'et_customer.sno',
                'et_customer.cus_name',
                'et_payment.transaction_date as created_at',
                'et_proposal_pay_slot.nextPayDate as miletone_date',
                'et_customer.cus_mobile',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get()
            // return $collectionHarvesting;
            ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount,&$collection_amount) {

               
                if($row->payment_status == 0){
                    
                    $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $balance_amount +=$netAmount;

                }else{
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $collection_amount +=$netAmount;
                }
                $harvesting_amount +=$netAmount;
                return $row;
            });
            // return $collectionHarvesting;
            // $collectionHarvesting = round($collectionHarvesting, 1);
            $harvestingPercentage =$harvesting_amount > 0 ? ($collection_amount/$harvesting_amount)*100 : 0;
        $data = [];
        foreach ($collectionHarvesting as $index => $cus) {
            // Fetch course
            $course = DB::table('et_proposal')
                ->where('et_proposal.customer_id', $cus->sno)
                ->select('et_proposal.service_title')
                ->first();

            $data[] = [
                'sno'         => $index + 1,
                'name'        => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'course'      => $course->service_title ?? '--',
                'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
                            ? 'Converted'
                            : 'Eligible', // you can change this dynamically
                'staff_name'      => $cus->staff_name,
                'staff_image'     => $cus->staff_image,
                'department_name' => $cus->department_name,
                'net_amount' => number_format(round($cus->net_amount)),
                'paid_amount' => round($cus->paid_amount),
                'total_amount_inr' => round($cus->total_amount_inr),
                'payable_amount' => round($cus->payable_amount),
                'payment_status' => round($cus->payment_status),
                'gst_perc' => $cus->gst_perc,
                'currency_code' => $cus->currency_code,
                'currency_symbol' => $cus->currency_symbol,
                'miletone_date' => Carbon::parse($cus->miletone_date)->format('d-M-Y'),
            ];
        }

        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            'harvestingPercentage'=>round($harvestingPercentage),
            'balance_amount'=>number_format(round($balance_amount)),
            'harvesting_amount'=>number_format(round($harvesting_amount)),
            'collection_amount'=>number_format(round($collection_amount)),
            ]);
    }


    //  journal Executive Details
    public function getJournalLists(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name','et_staff.role_id')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();
        $incentive = IncentiveModel::where('role_id', $StaffData->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();

            if( $incentive ){
                $check_accepted_paper=$incentive->check_accepted_paper ?? 0;
                $exiTarget=5;
            }else{
                $check_accepted_paper=1;
                $exiTarget=5;
            }

        // $publishedList = DB::table('et_manage_journal as mj')
        //     ->select('mj.*','prpsl.service_title')
        //     ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
        //     ->join('et_proposal as prpsl', 'cs.proposal_id', '=', 'prpsl.sno')
        //     ->whereIn('mj.status', [5,8])
        //     ->where('cs.jc_staff', $staffId) 
        //     // ->where('cs.jc_staff', 62) 
        //     ->whereYear('mj.publish_date', $year)
        //     ->whereMonth('mj.publish_date', $month)
        //     ->get();

         $publishedList = DB::table('et_manage_journal as mj')
          ->select('mj.*','prpsl.service_title','jh.accepted_date')
            ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
            ->join('et_proposal as prpsl', 'cs.proposal_id', '=', 'prpsl.sno')
            ->leftJoin('et_journal_history as jh', function ($join) {
                $join->on('mj.sno', '=', 'jh.journal_id')
                    ->where('jh.status', 5);
            });

        if ($check_accepted_paper == 1) {
            $publishedList = $publishedList->whereIn('mj.status', [5, 7, 8]);
        } else {
            $publishedList = $publishedList->where('mj.status', 8);
        }

        $publishedList = $publishedList
            ->where('cs.jc_staff', $staffId)
            ->where(function ($query) use ($year, $month) {

                $query->where(function ($q) use ($year, $month) {
                    $q->where('mj.status', 8)
                    ->whereYear('mj.publish_date', $year)
                    ->whereMonth('mj.publish_date', $month);
                })

                ->orWhere(function ($q) use ($year, $month) {
                     $q->whereIn('mj.status', [5, 7])
                    ->whereYear('jh.accepted_date', $year)
                    ->whereMonth('jh.accepted_date', $month);
                });

            })
             ->orderByRaw("
                    CASE 
                        WHEN mj.status IN (5, 7) THEN jh.accepted_date
                        ELSE mj.publish_date
                    END ASC
                ")
             ->get();

            
                $first12PaperIds = DB::table('et_manage_journal as mj')
                    ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
                    ->leftJoin('et_journal_history as jh', function ($join) {
                        $join->on('mj.sno', '=', 'jh.journal_id')
                            ->where('jh.status', 5);
                    });

                if ($check_accepted_paper == 1) {
                    $first12PaperIds = $first12PaperIds->whereIn('mj.status', [5, 7, 8]);
                } else {
                    $first12PaperIds = $first12PaperIds->where('mj.status', 8);
                }

        $first12PaperIds = $first12PaperIds
            ->where('cs.jc_staff', $staffId)
            ->where(function ($query) use ($year, $month) {

                $query->where(function ($q) use ($year, $month) {
                    $q->where('mj.status', 8)
                    ->whereYear('mj.publish_date', $year)
                    ->whereMonth('mj.publish_date', $month);
                })

                ->orWhere(function ($q) use ($year, $month) {
                     $q->whereIn('mj.status', [5, 7])
                    ->whereYear('jh.accepted_date', $year)
                    ->whereMonth('jh.accepted_date', $month);
                });

            })
             ->orderByRaw("
                    CASE 
                        WHEN mj.status IN (5, 7) THEN jh.accepted_date
                        ELSE mj.publish_date
                    END ASC
                ")
            ->limit($exiTarget)
            ->pluck('mj.sno')
            ->toArray();

        //    $first12PaperIds = DB::table('et_manage_journal as mj')
        //         ->join('et_customer_services as cs', 'mj.service_id', '=', 'cs.sno')
        //         ->whereIn('mj.status',[5,8])
        //         ->where('cs.jc_staff', $staffId)
        //         ->whereYear('mj.publish_date', $year)
        //         ->whereMonth('mj.publish_date', $month)
        //         ->orderBy('mj.publish_date', 'asc')
        //         ->limit(12)
        //         ->pluck('mj.sno')
        //         ->toArray();
     
        $data = [];
        foreach ($publishedList as $index => $cus) {
            
                $publishDate = Carbon::parse($cus->publish_date);
                $acceptDate =$cus->accepted_date ? Carbon::parse($cus->accepted_date) : null;
               
                $checkDate = $cus->status == 8 
                ? (  $publishDate ??  $acceptDate)
                : $acceptDate;

                $status = 'Not Eligible';

                if (!in_array($cus->sno, $first12PaperIds)) {

                    if ($checkDate && $checkDate->day <= 15) {
                        $status = 'Eligible';
                    }

                }


            $data[] = [
                'sno'         => $index + 1,
                'paper_name'        => $cus->paper_name,
                'journal_id'        => $cus->journal_id,
                'service_title'      => $cus->service_title ?? '--',
                'publish_date'     => $publishDate->format('d-M-Y'),
                'accept_date' => $acceptDate ? $acceptDate->format('d-M-Y') : '--',
                'paper_status'     => $cus->status,
                'status'           => $status,
                'staff_name'      => $StaffData->staff_name,
                'staff_image'     => $StaffData->staff_image,
                'department_name' => $StaffData->department_name,
            ];
        }

        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            ]);
    }
    
       public function getPerformanceCallCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));

        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(14);
        $endOfMonth = $now->copy()->endOfMonth(); // 🔧 FIXED
        $incentive = IncentiveModel::where('role_id', 11)
                        ->where('branch_id', $branchId)
                        ->where('status', 0)
                        ->first();
            $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_staff.branch_id', $branchId)
            ->where('et_staff.sno', $staffId)
            ->first();
        $startDate = Carbon::createFromDate($year, $month, 1);
        $endDate   = $startDate->copy()->endOfMonth();

        $days = [];
        $workingDays = 0;
        $startDateChck = Carbon::create($year, $month, 1);
            $currentDateChck = Carbon::now();
            $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month)
                        ? $currentDateChck
                        : $startDateChck->copy()->endOfMonth();
       
        $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;
        

        for ($date = $startDate->copy(); $date <= $endDate; $date->addDay()) {

            // // ❌ Skip Sundays
            // if ($date->isSunday()) {
            //     continue;
            // }

            $workingDays++;

            $counts = DB::table('et_call_tracker')
                ->selectRaw('
                    COUNT(CASE WHEN call_status = 0 THEN 1 END) as outgoing,
                    COUNT(CASE WHEN call_status = 1 THEN 1 END) as incoming,
                    COUNT(CASE WHEN call_status = 2 THEN 1 END) as missed
                ')
                ->whereDate('call_start_date', $date->format('Y-m-d'))
                ->where('branch_id', $branchId)
                ->where('branch_staff_id', $staffId)
                ->first();

            $days[] = [
                'date'     => $date->format('d-M-Y'),
                'day'      => $date->format('l'),
                'outgoing' => $counts->outgoing ?? 0,
                'incoming' => $counts->incoming ?? 0,
                'missed'   => $counts->missed ?? 0,
            ];
        }

        $totalOutgoing = collect($days)->sum('outgoing');
        $totalMissed   = collect($days)->sum('missed');
        $totalIncoming = collect($days)->sum('incoming');

        $actualOutgoingPerDay = $dayCountMonth > 0
            ? round($totalOutgoing / $dayCountMonth)
            : 0;

        // Missed call rate formula (same as your incentive logic)
        $totalCallsForRate = $totalIncoming + $totalMissed;
        $actualMissedCallRate = $totalCallsForRate > 0
            ? round(($totalMissed / $totalCallsForRate) * 100, 1)
            : 0;  

        $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            // ->where('et_lead.sno', 9436)
            ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_transaction.payment_status', 1)
            ->whereBetween(DB::raw('DATE(et_payment.transaction_date)'), [$startOfMonth, $endOfMonth])
            ->select(
                'et_customer.sno',
                'et_lead.lead_mobile',
                'et_payment.transaction_date as customer_created_at',
                'et_lead.registered_date as lead_created_at',
                'et_customer.cus_name',
                'et_customer.cus_mobile',
                'et_payment.transaction_date as created_at',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get();

        $convertedToday = 0;
        $convertedMonth = 0;
        $convertedOldMonth = 0;
        $data = [];

        foreach ($allConverted as $index => $row) {
            $mobile = $row->lead_mobile;

            // Get the latest call
            $lastCall = DB::table('et_call_tracker')
                ->where('branch_id', $branchId)
                ->where('branch_staff_id', $staffId)
                ->where('customer_phone_no', 'like', "%{$mobile}")
                ->orderByDesc('call_start_date')
                ->first();

            $totalCallCount = DB::table('et_call_tracker')
                ->where('branch_id', $branchId)
                ->where('branch_staff_id', $staffId)
                ->where('customer_phone_no', 'like', "%{$mobile}")
                ->count();
            $totalCalldata = DB::table('et_call_tracker')
                ->where('branch_id', $branchId)
                ->where('branch_staff_id', $staffId)
                ->where('customer_phone_no', 'like', "%{$mobile}")
                ->select(
                    'et_call_tracker.call_start_date'
                )
                ->get();
            
            //   return  $totalCalldata;
            // Date parsing
            $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
            $leadDate     = Carbon::parse($row->lead_created_at)->format('Y-m-d');
            $callDate     = $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null;

            $convertedOnDay = $customerDate === $leadDate;
            //  && $totalCallCount === 1;



            $convertedInMonth = !$convertedOnDay && // only if not already on-day
                $customerDate >= $startOfMonth->format('Y-m-d') &&
                $customerDate <= $endOfMonth->format('Y-m-d') &&
                $leadDate >= $startOfMonth->format('Y-m-d') &&
                $leadDate <= $endOfMonth->format('Y-m-d');
                //  &&
                // $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                //     $callDate = Carbon::parse($call->call_start_date);
                //     return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                // });
            // return $convertedInMonth;
            $convertedOld = !$convertedOnDay && !$convertedInMonth && // only if not on-day or in-month
                $customerDate >= $startOfMonth->format('Y-m-d') &&
                $customerDate <= $endOfMonth->format('Y-m-d') &&
                ($leadDate < $startOfMonth->format('Y-m-d') && $leadDate > $endOfMonth->format('Y-m-d'));
                
            $otherstaffConvert = !$convertedOnDay && !$convertedInMonth && !$convertedOld && $totalCallCount === 0;
                

                            
            $statusTick = '<a href="javascript:;" class="btn btn-icon btn-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                    <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                    <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                        c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                        c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                </svg>
                            </a>';
            $statusWrong = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                    <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                    <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                </svg>
                            </a>';
                            
            $spotIncentiveDayAmount = $convertedOnDay ? ($incentive->spot_incentive_day ?? 0) : 0;
            $spotIncentiveMonthAmount = $convertedInMonth ? ($incentive->spot_incentive_month ?? 0) : 0;
            
            $totalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
            
            $data[] = [
                'sno' => $index + 1,
                'name' => $row->cus_name,
                'mobile' => $row->cus_mobile,
                'totalCallCount' => $totalCallCount,
                'created_at' => Carbon::parse($row->customer_created_at)->format('d-M-Y'),
                'lead_created_at' => Carbon::parse($row->lead_created_at)->format('d-M-Y'),
                'call_start_date' => $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null,
                'on_day' => $convertedOnDay ? $statusTick : $statusWrong,
                'on_month' => $convertedInMonth ? $statusTick : $statusWrong,
                'old_month' => $convertedOld ? $statusTick : $statusWrong,
                'otherstaff' => $otherstaffConvert,
                'Rewards' => $spotIncentiveDayAmount + $spotIncentiveMonthAmount,
                'staff_name' => $row->staff_name,
                'staff_image' => $row->staff_image,
                'department_name' => $row->department_name
            ];
        }

        return response()->json([
            'data' => $data,
            'days' => $days,
            'StaffData' => $StaffData,
            'summary' => [
                'working_days' => $dayCountMonth,
                'total_outgoing' => $totalOutgoing,
                'total_missed' => $totalMissed,
                'total_incoming' => $totalIncoming,
                'actual_outgoing_per_day' => $actualOutgoingPerDay,
                'actual_missed_call_rate' => $actualMissedCallRate,
            ]
        ]);
    }

    //    public function getPerformanceAttendance(Request $request)
    // {
    //     $staffId   = $request->query('staff_id');
    //     $monthRaw  = $request->query('month');
    //     $year      = $request->query('year');
    //     $branchId  = $request->query('branch_id');

    //     if (!$staffId || !$monthRaw || !$year || !$branchId) {
    //         return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    //     }

    //     $month = is_numeric($monthRaw)
    //         ? (int) $monthRaw
    //         : (int) date('m', strtotime($monthRaw . ' 1'));

    //     $now = Carbon::createFromDate($year, $month, 1);
    //     $startOfMonth = $now->copy()->startOfMonth();
    //     $middleOfMonth = $now->copy()->startOfMonth()->addDays(14);
    //     $endOfMonth = $now->copy()->endOfMonth(); // 🔧 FIXED
    //     $incentive = IncentiveModel::where('role_id', 11)
    //                     ->where('branch_id', $branchId)
    //                     ->where('status', 0)
    //                     ->first();
    //         $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
    //         ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //         ->where('et_staff.branch_id', $branchId)
    //         ->where('et_staff.sno', $staffId)
    //         ->first();
    //     $startDate = Carbon::createFromDate($year, $month, 1);
    //     $endDate   = $startDate->copy()->endOfMonth();

    //     $days = [];
    //     $workingDays = 0;
    //     $startDateChck = Carbon::create($year, $month, 1);
    //         $currentDateChck = Carbon::now();
    //         $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month)
    //                     ? $currentDateChck
    //                     : $startDateChck->copy()->endOfMonth();
       
    //     $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;
        

    //     for ($date = $startDate->copy(); $date <= $endDate; $date->addDay()) {

    //         // // ❌ Skip Sundays
    //         // if ($date->isSunday()) {
    //         //     continue;
    //         // }

    //         $workingDays++;

    //         $counts = DB::table('et_staff_attendance')
    //             ->whereDate('date', $date->format('Y-m-d'))
    //             ->where('branch_id', $branchId)
    //             ->where('staff_id', $staffId)
    //             ->first();

    //         $days[] = [
    //             'date'     => $date->format('d-M-Y'),
    //             'day'      => $date->format('l'),
    //             'attendance' => $counts->attendance ?? '-',
    //         ];
    //     }

    //     $totalPresent = collect($days)->sum('P,OD,PR');
       

    //     $actualAttendancePercentage = $dayCountMonth > 0
    //         ? round(($totalPresent / $dayCountMonth)*100)
    //         : 0;

    //     // Missed call rate formula (same as your incentive logic)
    //     $totalCallsForRate = $totalIncoming + $totalMissed;
    //     $actualMissedCallRate = $dayCountMonth > 0
    //         ? round(($totalPresent / $dayCountMonth) * 100, 1)
    //         : 0;  

    //     $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
    //         ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
    //         ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
    //         ->whereIn('et_customer.status', [0, 6])
    //         ->where('et_customer.branch_id', $branchId)
    //         ->where('et_lead.created_by', $staffId)
    //         // ->where('et_lead.sno', 9436)
    //         ->join('et_payment', function($join) {
    //                     $join->on('et_payment.customer_id', '=', 'et_customer.sno')
    //                         ->whereRaw('et_payment.sno = (
    //                             SELECT ep.sno
    //                             FROM et_payment ep
    //                             WHERE ep.customer_id = et_customer.sno
    //                             ORDER BY ep.transaction_date ASC, ep.sno ASC
    //                             LIMIT 1
    //                         )');
    //                 })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_transaction.payment_status', 1)
    //         ->whereBetween(DB::raw('DATE(et_payment.transaction_date)'), [$startOfMonth, $endOfMonth])
    //         ->select(
    //             'et_customer.sno',
    //             'et_lead.lead_mobile',
    //             'et_payment.transaction_date as customer_created_at',
    //             'et_lead.registered_date as lead_created_at',
    //             'et_customer.cus_name',
    //             'et_customer.cus_mobile',
    //             'et_payment.transaction_date as created_at',
    //             'et_staff.staff_name',
    //             'et_staff.staff_image',
    //             'et_department.department_name'
    //         )
    //         ->get();

    //     $convertedToday = 0;
    //     $convertedMonth = 0;
    //     $convertedOldMonth = 0;
    //     $data = [];

    //     foreach ($allConverted as $index => $row) {
    //         $mobile = $row->lead_mobile;

    //         // Get the latest call
    //         $lastCall = DB::table('et_call_tracker')
    //             ->where('branch_id', $branchId)
    //             ->where('branch_staff_id', $staffId)
    //             ->where('customer_phone_no', 'like', "%{$mobile}")
    //             ->orderByDesc('call_start_date')
    //             ->first();

    //         $totalCallCount = DB::table('et_call_tracker')
    //             ->where('branch_id', $branchId)
    //             ->where('branch_staff_id', $staffId)
    //             ->where('customer_phone_no', 'like', "%{$mobile}")
    //             ->count();
    //         $totalCalldata = DB::table('et_call_tracker')
    //             ->where('branch_id', $branchId)
    //             ->where('branch_staff_id', $staffId)
    //             ->where('customer_phone_no', 'like', "%{$mobile}")
    //             ->select(
    //                 'et_call_tracker.call_start_date'
    //             )
    //             ->get();
            
    //         //   return  $totalCalldata;
    //         // Date parsing
    //         $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
    //         $leadDate     = Carbon::parse($row->lead_created_at)->format('Y-m-d');
    //         $callDate     = $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null;

    //         $convertedOnDay = $customerDate === $leadDate;
    //         //  && $totalCallCount === 1;



    //         $convertedInMonth = !$convertedOnDay && // only if not already on-day
    //             $customerDate >= $startOfMonth->format('Y-m-d') &&
    //             $customerDate <= $endOfMonth->format('Y-m-d') &&
    //             $leadDate >= $startOfMonth->format('Y-m-d') &&
    //             $leadDate <= $endOfMonth->format('Y-m-d');
    //             //  &&
    //             // $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
    //             //     $callDate = Carbon::parse($call->call_start_date);
    //             //     return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
    //             // });
    //         // return $convertedInMonth;
    //         $convertedOld = !$convertedOnDay && !$convertedInMonth && // only if not on-day or in-month
    //             $customerDate >= $startOfMonth->format('Y-m-d') &&
    //             $customerDate <= $endOfMonth->format('Y-m-d') &&
    //             ($leadDate < $startOfMonth->format('Y-m-d') && $leadDate > $endOfMonth->format('Y-m-d'));
                
    //         $otherstaffConvert = !$convertedOnDay && !$convertedInMonth && !$convertedOld && $totalCallCount === 0;
                

                            
    //         $statusTick = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
    //                                 <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
    //                                 <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
    //                                     c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
    //                                     c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
    //                             </svg>
    //                         </a>';
    //         $statusWrong = '<a href="javascript:;" class="btn btn-icon btn-sm">
    //                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
    //                                 <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
    //                                 <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
    //                                     c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
    //                                     c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
    //                                     c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
    //                             </svg>
    //                         </a>';
                            
    //         $spotIncentiveDayAmount = $convertedOnDay ? ($incentive->spot_incentive_day ?? 0) : 0;
    //         $spotIncentiveMonthAmount = $convertedInMonth ? ($incentive->spot_incentive_month ?? 0) : 0;
            
    //         $totalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
            
    //         $data[] = [
    //             'sno' => $index + 1,
    //             'name' => $row->cus_name,
    //             'mobile' => $row->cus_mobile,
    //             'totalCallCount' => $totalCallCount,
    //             'created_at' => Carbon::parse($row->customer_created_at)->format('d-M-Y'),
    //             'lead_created_at' => Carbon::parse($row->lead_created_at)->format('d-M-Y'),
    //             'call_start_date' => $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null,
    //             'on_day' => $convertedOnDay ? $statusTick : $statusWrong,
    //             'on_month' => $convertedInMonth ? $statusTick : $statusWrong,
    //             'old_month' => $convertedOld ? $statusTick : $statusWrong,
    //             'otherstaff' => $otherstaffConvert,
    //             'Rewards' => $spotIncentiveDayAmount + $spotIncentiveMonthAmount,
    //             'staff_name' => $row->staff_name,
    //             'staff_image' => $row->staff_image,
    //             'department_name' => $row->department_name
    //         ];
    //     }

    //     return response()->json([
    //         'data' => $data,
    //         'days' => $days,
    //         'StaffData' => $StaffData,
    //         'summary' => [
    //             'working_days' => $dayCountMonth,
    //             'total_outgoing' => $totalOutgoing,
    //             'total_missed' => $totalMissed,
    //             'total_incoming' => $totalIncoming,
    //             'actual_outgoing_per_day' => $actualOutgoingPerDay,
    //             'actual_missed_call_rate' => $actualMissedCallRate,
    //         ]
    //     ]);
    // }

    public function getPerformanceAttendance(Request $request)
{
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
        return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
        ? (int) $monthRaw
        : (int) date('m', strtotime($monthRaw . ' 1'));

    $startDate = Carbon::createFromDate($year, $month, 1);
    $endDate   = $startDate->copy()->endOfMonth();

    $startDateChck = Carbon::create($year, $month, 1);
    $currentDateChck = Carbon::now();

    $endDateChck = ($currentDateChck->year == $year && $currentDateChck->month == $month)
        ? $currentDateChck
        : $startDateChck->copy()->endOfMonth();

    $dayCountMonth = $startDateChck->diffInDays($endDateChck) + 1;

    $StaffData = StaffModel::select(
            'et_staff.staff_name',
            'et_staff.staff_image',
            'et_department.department_name'
        )
        ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
        ->where('et_staff.status',0)
        ->where('et_staff.branch_id', $branchId)
        ->where('et_staff.sno', $staffId)
        ->first();

    $days = [];
    $workingDays = 0;
    $presentCount = 0;

    for ($date = $startDate->copy(); $date <= $endDate; $date->addDay()) {

        $attendance = DB::table('et_staff_attendance')
            ->whereDate('date', $date->format('Y-m-d'))
            ->where('branch_id', $branchId)
            ->where('staff_id', $staffId)
            ->value('attendance');

        $isSunday = $date->isSunday();

        if ($isSunday) {

            $days[] = [
                'date' => $date->format('d-M-Y'),
                'day' => $date->format('l'),
                'attendance' => 'Weekend'
            ];

            continue;
        }

        if ($attendance == 'HD') {

            $days[] = [
                'date' => $date->format('d-M-Y'),
                'day' => $date->format('l'),
                'attendance' => 'Holiday'
            ];

            continue;
        }

        // Count working day
        $workingDays++;

        if (in_array($attendance, ['P','PR','OD'])) {
            $presentCount++;
        }

        $days[] = [
            'date' => $date->format('d-M-Y'),
            'day' => $date->format('l'),
            'attendance' => $attendance ?? '-'
        ];
    }

    // Present count (P,PR,OD)
    $presentCount = collect($days)->filter(function ($item) {
        return in_array($item['attendance'], ['P','PR','OD']);
    })->count();

    $actualAttendancePercentage = $workingDays > 0
        ? round(($presentCount / $workingDays) * 100,1)
        : 0;

    return response()->json([
        'days' => $days,
        'StaffData' => $StaffData,
        'summary' => [
            'working_days' => $workingDays,
            'present_days' => $presentCount,
            'attendance_percentage' => $actualAttendancePercentage
        ]
    ]);
}


    public function getCreEciCustomers(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();
        
        $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_payment.transaction_date as created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

                $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staffId)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                $gstPercentage=18;

                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staffId)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
            // return $tragetHarvestingIds;
            $balance_amount =0;
            $harvesting_amount =0;
            $harvesting_amount_eci =0;
            $collection_amount_eci =0;
            $collection_amount =0;
             $collectionHarvesting = DB::table('et_proposal_pay_slot')
            ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
            ->where('et_customer.status', 0)
            // ->where('et_transaction.payment_status', 1)
            ->where('et_proposal.cre_id', $staffId)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->select(
                "et_proposal_pay_slot.payable_amount as payable_amount",
                "et_transaction.payment_status",
                "et_transaction.total_amount_inr",
                "et_payment.paid_amount",
                "et_proposal.gst_perc",
                "et_country_currencies.currency_code as currency_code",
                "et_country_currencies.currency_symbol",
                'et_customer.sno',
                'et_customer.cus_name',
                'et_payment.transaction_date as created_at',
                'et_proposal_pay_slot.nextPayDate as miletone_date',
                'et_customer.cus_mobile',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get()
            // return $collectionHarvesting;
            ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount,&$collection_amount) {

               
                if($row->payment_status == 0){
                    
                    $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $balance_amount +=$netAmount;

                }else{
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $collection_amount +=$netAmount;
                }
                $harvesting_amount +=$netAmount;
                return $row;
            });
            $collectionHarvestingPaid = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->where('et_proposal.cre_id', $staffId)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->select(
                "et_proposal_pay_slot.payable_amount as payable_amount",
                "et_transaction.payment_status",
                "et_transaction.total_amount_inr",
                "et_payment.paid_amount",
                "et_proposal.gst_perc",
                "et_country_currencies.currency_code as currency_code",
                "et_country_currencies.currency_symbol",
                'et_customer.sno',
                'et_customer.cus_name',
                'et_payment.transaction_date as created_at',
                'et_proposal_pay_slot.nextPayDate as miletone_date',
                'et_customer.cus_mobile',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get()
            // return $collectionHarvesting;
            ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount_eci,&$collection_amount_eci) {

               
                if($row->payment_status == 0){
                    
                    $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $balance_amount +=$netAmount;

                }else{
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $collection_amount_eci +=$netAmount;
                }
                $harvesting_amount_eci +=$netAmount;
                return $row;
            });
            // return $collectionHarvesting;
            // $collectionHarvesting = round($collectionHarvesting, 1);
           
        $data = [];
        $totalEligibleAmount = 0;
        foreach ($collectionHarvestingPaid as $index => $cus) {

          $isEligible = Carbon::parse($cus->created_at)
                    ->between($startOfMonth, $middleOfMonth);

            if ($isEligible) {
                $totalEligibleAmount += $cus->net_amount;
            }
            // Fetch course
            $course = DB::table('et_proposal')
                ->where('et_proposal.customer_id', $cus->sno)
                ->select('et_proposal.service_title')
                ->first();

            $data[] = [
                'sno'         => $index + 1,
                'name'        => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'course'      => $course->service_title ?? '--',
                'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                'status'      => $isEligible ? 'Eligible' : 'Not Eligible',
                'staff_name'      => $cus->staff_name,
                'staff_image'     => $cus->staff_image,
                'department_name' => $cus->department_name,
                'net_amount' => number_format(round($cus->net_amount)),
                'paid_amount' => round($cus->paid_amount),
                'total_amount_inr' => round($cus->total_amount_inr),
                'payable_amount' => round($cus->payable_amount),
                'payment_status' => round($cus->payment_status),
                'gst_perc' => $cus->gst_perc,
                'currency_code' => $cus->currency_code,
                'currency_symbol' => $cus->currency_symbol,
                'miletone_date' => Carbon::parse($cus->miletone_date)->format('d-M-Y'),
            ];
        }
         $eciPercentage =$harvesting_amount > 0 ? ($totalEligibleAmount/$harvesting_amount)*100 : 0;

        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            'eciPercentage'=>round($eciPercentage),
            'balance_amount'=>number_format(round($balance_amount)),
            'harvesting_amount'=>number_format(round($harvesting_amount)),
            'collection_amount'=>number_format(round($collection_amount)),
            'totalEligibleAmount'=>number_format(round($totalEligibleAmount)),
            ]);
    }

    public function getCreSpotCustomers(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();
        
        $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_payment.transaction_date as created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

                $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staffId)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                $gstPercentage=18;

                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staffId)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
            // return $tragetHarvestingIds;
            $balance_amount =0;
            $harvesting_amount =0;
            $collection_amount =0;
            
            $collectionHarvesting = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
            ->where('et_customer.status', 0)
            ->where('et_transaction.payment_status', 1)
            ->where('et_proposal.cre_id', $staffId)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->select(
                "et_proposal_pay_slot.payable_amount as payable_amount",
                "et_transaction.payment_status",
                "et_transaction.total_amount_inr",
                "et_payment.paid_amount",
                "et_proposal.gst_perc",
                "et_country_currencies.currency_code as currency_code",
                "et_country_currencies.currency_symbol",
                'et_customer.sno',
                'et_customer.cus_name',
                'et_payment.transaction_date as created_at',
                'et_proposal_pay_slot.nextPayDate as miletone_date',
                'et_customer.cus_mobile',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get()
            // return $collectionHarvesting;
            ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount,&$collection_amount) {

               
                if($row->payment_status == 0){
                    
                    $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $balance_amount +=$netAmount;

                }else{
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $collection_amount +=$netAmount;
                }
                $harvesting_amount +=$netAmount;
                return $row;
            });
            // return $collectionHarvesting;
            // $collectionHarvesting = round($collectionHarvesting, 1);
           
        $data = [];
        $totalEligibleAmount = 0;
        foreach ($collectionHarvesting as $index => $cus) {

          $isEligible = Carbon::parse($cus->created_at)
            ->lte(Carbon::parse($cus->miletone_date));

            if ($isEligible) {
                $totalEligibleAmount += $cus->net_amount;
            }
            // Fetch course
            $course = DB::table('et_proposal')
                ->where('et_proposal.customer_id', $cus->sno)
                ->select('et_proposal.service_title')
                ->first();

            $data[] = [
                'sno'         => $index + 1,
                'name'        => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'course'      => $course->service_title ?? '--',
                'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                'status'      => $isEligible ? 'Eligible' : 'Not Eligible',
                'staff_name'      => $cus->staff_name,
                'staff_image'     => $cus->staff_image,
                'department_name' => $cus->department_name,
                'net_amount' => number_format(round($cus->net_amount)),
                'paid_amount' => round($cus->paid_amount),
                'total_amount_inr' => round($cus->total_amount_inr),
                'payable_amount' => round($cus->payable_amount),
                'payment_status' => round($cus->payment_status),
                'gst_perc' => $cus->gst_perc,
                'currency_code' => $cus->currency_code,
                'currency_symbol' => $cus->currency_symbol,
                'miletone_date' => Carbon::parse($cus->miletone_date)->format('d-M-Y'),
            ];
        }
         $eciPercentage =$collection_amount > 0 ? ($totalEligibleAmount/$collection_amount)*100 : 0;
        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            'spotPercentage'=>round($eciPercentage),
            'balance_amount'=>number_format(round($balance_amount)),
            'harvesting_amount'=>number_format(round($harvesting_amount)),
            'collection_amount'=>number_format(round($collection_amount)),
            'totalEligibleAmount'=>number_format(round($totalEligibleAmount)),
            ]);
    }


    public function getCreBonusCustomers(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.role_id','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();

        $incentive = IncentiveModel::where('role_id', $StaffData->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
        
        $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_payment.transaction_date as created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->join('et_payment', function($join) {
                        $join->on('et_payment.customer_id', '=', 'et_customer.sno')
                            ->whereRaw('et_payment.sno = (
                                SELECT ep.sno
                                FROM et_payment ep
                                WHERE ep.customer_id = et_customer.sno
                                ORDER BY ep.transaction_date ASC, ep.sno ASC
                                LIMIT 1
                            )');
                    })
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1)
            ->get();

                $firstPayIds = DB::table('et_proposal_pay_slot')
                    ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                    ->where('et_proposal.status', 0)
                    ->where('et_proposal_pay_slot.status', 0)
                    ->where('et_proposal.cre_id', $staffId)
                    ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                    ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                    ->groupBy('et_proposal_pay_slot.proposal_sno')
                    ->orderBy('first_id', 'asc')
                    ->pluck('first_id');

                $gstPercentage=18;

                $tragetHarvestingIds = DB::table('et_proposal_pay_slot')
                ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereNotIn('et_proposal_pay_slot.sno', $firstPayIds)
                ->where('et_customer.status', 0)
                ->where('et_proposal.cre_id', $staffId)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as pay_slot_id'))
                ->groupBy('et_proposal_pay_slot.proposal_sno')
                ->orderBy('pay_slot_id', 'asc')
                ->pluck('pay_slot_id');
            // return $tragetHarvestingIds;
            $balance_amount =0;
            $harvesting_amount =0;
           $collection_amount_paid =0;
           $harvesting_amount_paid =0;
            $collection_amount =0;
             $collectionHarvesting = DB::table('et_proposal_pay_slot')
            ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->leftJoin('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
            ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_lead.created_by', '>', 1)
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
            ->where('et_customer.status', 0)
            // ->where('et_transaction.payment_status', 1)
            ->where('et_proposal.cre_id', $staffId)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->select(
                "et_proposal_pay_slot.payable_amount as payable_amount",
                "et_transaction.payment_status",
                "et_transaction.total_amount_inr",
                "et_payment.paid_amount",
                "et_proposal.gst_perc",
                "et_country_currencies.currency_code as currency_code",
                "et_country_currencies.currency_symbol",
                'et_customer.sno',
                'et_customer.cus_name',
                'et_payment.transaction_date as created_at',
                'et_proposal_pay_slot.nextPayDate as miletone_date',
                'et_customer.cus_mobile',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_department.department_name'
            )
            ->get()
            // return $collectionHarvesting;
            ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount,&$collection_amount) {

               
                if($row->payment_status == 0){
                    
                    $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $balance_amount +=$netAmount;

                }else{
                    // ✅ Prefer INR amount from transaction if available
                    $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                        ? $row->total_amount_inr
                        : $row->paid_amount;

                    // ✅ Proposal GST → Branch GST → Default 18%
                    $gstRate = $row->gst_perc > 0
                        ? $row->gst_perc / 100
                        : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                    // ✅ Net amount (without GST)
                    $netAmount = round($amountInr / (1 + $gstRate), 2);

                    // ✅ Attach net_amount to each row
                    $row->net_amount = $netAmount;
                    $collection_amount +=$netAmount;
                }
                $harvesting_amount +=$netAmount;
                return $row;
            });
            
            $collectionHarvestingPaid = DB::table('et_proposal_pay_slot')
                ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_transaction', 'et_payment.sno', '=', 'et_transaction.payment_id')
                ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                ->join('et_country_currencies', 'et_proposal.currency_id', '=', 'et_country_currencies.sno')
                ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                ->join('et_staff', 'et_staff.sno', '=', 'et_proposal.cre_id')
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_lead.created_by', '>', 1)
                ->where('et_customer.branch_id', $branchId)
                ->whereIn('et_proposal_pay_slot.sno', $tragetHarvestingIds)
                ->where('et_customer.status', 0)
                ->where('et_transaction.payment_status', 1)
                ->where('et_proposal.cre_id', $staffId)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
                ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
                ->select(
                    "et_proposal_pay_slot.payable_amount as payable_amount",
                    "et_transaction.payment_status",
                    "et_transaction.total_amount_inr",
                    "et_payment.paid_amount",
                    "et_proposal.gst_perc",
                    "et_country_currencies.currency_code as currency_code",
                    "et_country_currencies.currency_symbol",
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_payment.transaction_date as created_at',
                    'et_proposal_pay_slot.nextPayDate as miletone_date',
                    'et_customer.cus_mobile',
                    'et_staff.staff_name',
                    'et_staff.staff_image',
                    'et_department.department_name'
                )
                ->get()
                // return $collectionHarvesting;
                ->map(function ($row) use ($gstPercentage,$helper,&$balance_amount,&$harvesting_amount_paid,&$collection_amount_paid) {

                
                    if($row->payment_status == 0){
                        
                        $amountInr = $helper->ConvertedAmountInr($row->currency_code, $row->payable_amount);

                        // ✅ Proposal GST → Branch GST → Default 18%
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                        // ✅ Net amount (without GST)
                        $netAmount = round($amountInr / (1 + $gstRate), 2);

                        // ✅ Attach net_amount to each row
                        $row->net_amount = $netAmount;
                        $balance_amount +=$netAmount;

                    }else{
                        // ✅ Prefer INR amount from transaction if available
                        $amountInr = ($row->total_amount_inr && $row->total_amount_inr > 0)
                            ? $row->total_amount_inr
                            : $row->paid_amount;

                        // ✅ Proposal GST → Branch GST → Default 18%
                        $gstRate = $row->gst_perc > 0
                            ? $row->gst_perc / 100
                            : ($gstPercentage ? $gstPercentage / 100 : 0.18);

                        // ✅ Net amount (without GST)
                        $netAmount = round($amountInr / (1 + $gstRate), 2);

                        // ✅ Attach net_amount to each row
                        $row->net_amount = $netAmount;
                        $collection_amount_paid +=$netAmount;
                    }
                    $harvesting_amount_paid +=$netAmount;
                    return $row;
                });
            // return $collectionHarvesting;
            // $collectionHarvesting = round($collectionHarvesting, 1);
            $collectionPercentage = round($harvesting_amount) > 0
                ? round((round($collection_amount) / round($harvesting_amount)) * 100, 2)
                : 0;
           
        $data = [];
        $totalEligibleAmount = 0;
        $bi_value = 0;
     
        $goalsetData = GoalSetStaffModel::where('staff_id', $staffId)
            ->whereMonth('goal_date', $month)
            ->whereYear('goal_date', $year)
            ->first();

        $targetTenx = $goalsetData->harvesting_percentage ?? 85;

        if ($incentive) {
            $bi_target_percent = $incentive->bi_amount ?? 2;
        } else {
            $bi_target_percent = 2;
        }

        $excessPercentage = 0;
        $excessValue = 0;
        $bonusAmount = 0;

        if ($collectionPercentage > $targetTenx) {

            $excessPercentage = round($collectionPercentage - $targetTenx);

            $excessValue = round(($excessPercentage / 100) * round($harvesting_amount));

            $bonusAmount = round(($bi_target_percent / 100) * round($excessValue));
        }

        $bi_achieved = $collectionPercentage > $targetTenx;
        $bi_reward   = $bi_achieved ? $bonusAmount : 0;
        foreach ($collectionHarvestingPaid as $index => $cus) {
            // Fetch course
            $course = DB::table('et_proposal')
                ->where('et_proposal.customer_id', $cus->sno)
                ->select('et_proposal.service_title')
                ->first();

            $data[] = [
                'sno'         => $index + 1,
                'name'        => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'course'      => $course->service_title ?? '--',
                'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
                'status' => $bi_achieved ? 'Eligible' : 'Not Eligible',
                'staff_name'      => $cus->staff_name,
                'staff_image'     => $cus->staff_image,
                'department_name' => $cus->department_name,
                'net_amount' => number_format(round($cus->net_amount)),
                'paid_amount' => round($cus->paid_amount),
                'total_amount_inr' => round($cus->total_amount_inr),
                'payable_amount' => round($cus->payable_amount),
                'payment_status' => round($cus->payment_status),
                'gst_perc' => $cus->gst_perc,
                'currency_code' => $cus->currency_code,
                'currency_symbol' => $cus->currency_symbol,
                'miletone_date' => Carbon::parse($cus->miletone_date)->format('d-M-Y'),
            ];
        }
        

        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            // Performance
            'collectionPercentage' => round($collectionPercentage),
            'targetPercentage' => $targetTenx,
            'bi_percent' => $bi_target_percent,
            // Bonus Breakdown
            'excessPercentage' => $excessPercentage,
            'excessValue' => number_format($excessValue),
            'bonusAmount' => number_format($bonusAmount),
            'bi_achieved' => $bi_achieved,
            'bi_reward' => number_format($bi_reward),
            'balance_amount'=>number_format(round($balance_amount)),
            'harvesting_amount'=>number_format(round($harvesting_amount)),
            'collection_amount'=>number_format(round($collection_amount)),
            'totalEligibleAmount'=>number_format(round($totalEligibleAmount)),
            ]);
    }


    public function getCreReferralCustomers(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
            $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                    ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                    ->where('et_staff.branch_id', $branchId)
                    ->where('et_staff.sno', $staffId)
                    ->first();
        
      

            $customerConvertThisMonth = DB::table('et_proposal')
                ->select(
                    'et_proposal.service_title',
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.country_code',
                    'et_customer.cus_mobile',
                    'et_payment.transaction_date as created_date',
                    'et_payment.transaction_date as created_at',
                    'et_transaction.payment_id',
                    'et_transaction.sno as transaction_id',
                    'et_payment.paid_amount'
                )
                ->join('et_customer', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->where('et_proposal.branch_id', $branchId)
                ->where('et_proposal.referral_id', $staffId)
                ->where('et_proposal.status', 0)
                ->whereNotIn('et_proposal.proposal_status', [0,1,2])
                ->join('et_payment', function($join) {
                            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                                ->whereRaw('et_payment.transaction_date = (
                                    SELECT MIN(ep.transaction_date)
                                    FROM et_payment ep
                                    WHERE ep.proposal_id = et_proposal.sno
                                )');
                        })
                ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
                ->where('et_customer.status', 0)
                ->whereYear('et_payment.transaction_date', $year)
                ->whereMonth('et_payment.transaction_date', $month)
                ->where('et_transaction.payment_status', 1)
                ->where('et_payment.status', 0)
                ->orderBy('et_proposal.sno', 'asc')
                ->get();
                
           
            // return $customerConvertThisMonth;
            // $collectionHarvesting = round($collectionHarvesting, 1);
           
        $data = [];
        $totalEligibleAmount = 0;
        foreach ($customerConvertThisMonth as $index => $cus) {

            $data[] = [
                'sno'         => $index + 1,
                'name'        => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'course'      => $cus->service_title ?? '--',
                'created_at'  => Carbon::parse($cus->created_date)->format('d-M-Y'),
                'staff_name'      => $StaffData->staff_name,
                'staff_image'     => $StaffData->staff_image,
                'department_name' => $StaffData->department_name,
            ];
        }
        return response()->json([
            'data' => $data,
            'staff'=>$StaffData,
            ]);
    }
    public function getProductionDetails(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');

        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }

        $month = is_numeric($monthRaw)
            ? (int) $monthRaw
            : (int) date('m', strtotime($monthRaw . ' 1'));
            
        // Define the 1st to 15th range of the selected month/year
        $now = Carbon::createFromDate($year, $month, 1);
        $startOfMonth = $now->copy()->startOfMonth();
        $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
        
        $StaffData = StaffModel::select('et_staff.staff_name','et_staff.staff_image','et_department.department_name')->where('et_staff.status',0)
                ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
                ->where('et_staff.branch_id', $branchId)
                ->where('et_staff.sno', $staffId)
                ->first();
        
       $CurrentWorkingHoursInsec = DB::table('et_daily_tasks')
            ->join('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.staff_id', $staffId)
            ->selectRaw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as total_seconds')
            ->value('total_seconds');

        // Saving Per Task (Subquery Safe)
        $SavingTimeInSec = DB::table(DB::raw("
            (
                SELECT 
                    dt.sno,
                    dt.task_hours,
                    (dt.task_hours * 3600) - 
                    COALESCE(SUM(TIME_TO_SEC(tl.duration)),0) as saving_seconds
                FROM et_daily_tasks dt
                LEFT JOIN et_task_log tl 
                    ON dt.sno = tl.task_id
                WHERE YEAR(dt.task_date) = $year
                    AND MONTH(dt.task_date) = $month
                    AND dt.staff_id = {$staffId}
                    AND dt.status >= 4
                GROUP BY dt.sno, dt.task_hours
            ) as task_saving
        "))
        ->sum('saving_seconds');

        $AdjustedWorkingSeconds = $CurrentWorkingHoursInsec + $SavingTimeInSec;

        // Task-wise
        $tasks = DB::table('et_daily_tasks')
            ->leftJoin('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
            ->leftJoin('et_task', 'et_daily_tasks.task_id', '=', 'et_task.sno')
            ->leftJoin('et_product_task', 'et_product_task.sno', '=', 'et_task.task_name')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.staff_id', $staffId)
            ->select(
                'et_daily_tasks.sno',
                'et_daily_tasks.task_date',
                'et_product_task.task_name',
                'et_daily_tasks.task_hours',
                'et_daily_tasks.status',
                DB::raw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as actual_seconds')
            )
            ->groupBy('et_daily_tasks.sno',
            'et_product_task.task_name',
             'et_daily_tasks.task_hours',
             'et_daily_tasks.task_date',
              'et_daily_tasks.status')
            ->get();
        return response()->json([
            'summary' => [
                'worked_hours'   => round($CurrentWorkingHoursInsec / 3600, 2),
                'saving_hours'   => round($SavingTimeInSec / 3600, 2),
                'adjusted_hours' => round($AdjustedWorkingSeconds / 3600, 2),
            ],
            'data' => $tasks,
            'staff'=>$StaffData,
            ]);
    }

    public function productionDetails($staffId)
    {
        $year = now()->year;
        $month = now()->month;

        // Current Working Seconds
        $CurrentWorkingHoursInsec = DB::table('et_daily_tasks')
            ->join('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.staff_id', $staffId)
            ->selectRaw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as total_seconds')
            ->value('total_seconds');

        // Saving Per Task (Subquery Safe)
        $SavingTimeInSec = DB::table(DB::raw("
            (
                SELECT 
                    dt.sno,
                    dt.task_hours,
                    (dt.task_hours * 3600) - 
                    COALESCE(SUM(TIME_TO_SEC(tl.duration)),0) as saving_seconds
                FROM et_daily_tasks dt
                LEFT JOIN et_task_log tl 
                    ON dt.sno = tl.task_id
                WHERE YEAR(dt.task_date) = $year
                    AND MONTH(dt.task_date) = $month
                    AND dt.staff_id = {$staffId}
                    AND dt.status >= 4
                GROUP BY dt.sno, dt.task_hours
            ) as task_saving
        "))
        ->sum('saving_seconds');

        $AdjustedWorkingSeconds = $CurrentWorkingHoursInsec + $SavingTimeInSec;

        // Task-wise
        $tasks = DB::table('et_daily_tasks')
            ->leftJoin('et_task_log', 'et_daily_tasks.sno', '=', 'et_task_log.task_id')
            ->whereYear('et_daily_tasks.task_date', $year)
            ->whereMonth('et_daily_tasks.task_date', $month)
            ->where('et_daily_tasks.staff_id', $staffId)
            ->select(
                'et_daily_tasks.sno',
                'et_daily_tasks.task_hours',
                'et_daily_tasks.status',
                DB::raw('COALESCE(SUM(TIME_TO_SEC(et_task_log.duration)),0) as actual_seconds')
            )
            ->groupBy('et_daily_tasks.sno', 'et_daily_tasks.task_hours', 'et_daily_tasks.status')
            ->get();

        return response()->json([
            'summary' => [
                'worked_hours'   => round($CurrentWorkingHoursInsec / 3600, 2),
                'saving_hours'   => round($SavingTimeInSec / 3600, 2),
                'adjusted_hours' => round($AdjustedWorkingSeconds / 3600, 2),
            ],
            'tasks' => $tasks
        ]);
    }




    // public function getPIDetails(Request $request) {
    //     $staffId  = $request->query('staff_id');
    //     $monthRaw = $request->query('month');
    //     $year     = $request->query('year');
    //     $branchId = $request->query('branch_id');

    //     if (!$staffId || !$monthRaw || !$year || !$branchId) {
    //         return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    //     }

    //     $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    //     $gst_percent = 18;

    //     // Get staff & role info
    //     $staff = \App\Models\StaffModel::select('et_staff.staff_name','et_staff.role_id','et_staff.staff_image','et_department.department_name')
    //         ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //         ->where('et_staff.sno', $staffId)
    //         ->where('et_staff.branch_id', $branchId)
    //         ->where('et_staff.status', 0)
    //         ->first();

    //     if (!$staff) {
    //         return '<div class="alert alert-danger">Staff not found.</div>';
    //     }

    //     // Load PI slabs for role/branch/month
    //     $incentive = \App\Models\IncentiveModel::where('role_id', $staff->role_id)
    //         ->where('branch_id', $branchId)
    //         ->whereMonth('incentive_month', $month)
    //         ->whereYear('incentive_month', $year)
    //         ->where('status', 0)
    //         ->first();

    //     $pi_slabs = $incentive && $incentive->pi_slab_json ? json_decode($incentive->pi_slab_json, true) : [];

    //     // Step 1: Get eligible proposals
    //     $proposalIds = DB::table('et_customer')
    //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
    //                 ->whereRaw('et_payment.transaction_date = (
    //                     SELECT MIN(ep.transaction_date)
    //                     FROM et_payment ep
    //                     WHERE ep.proposal_id = et_proposal.sno
    //                 )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_customer.status', 0)
    //         ->where('et_proposal.post_sale_check', 0)
    //         ->where('et_proposal.created_by', $staffId)
    //         ->whereYear('et_payment.transaction_date', $year)
    //         ->whereMonth('et_payment.transaction_date', $month)
    //         ->where('et_transaction.payment_status', 1)
    //         ->whereNotIn('et_proposal.proposal_status', [0,1,2])
    //         ->where('et_proposal.status',0)
    //         ->pluck('et_proposal.sno');

    //     if ($proposalIds->isEmpty()) {
    //         return '<div class="alert alert-info">No profitable incentive proposals found.</div>';
    //     }

    //     // Step 2: Gather proposal-level details
    //     $proposalDetails = collect();
    //     foreach ($proposalIds as $proposalId) {
    //         $proposal = DB::table('et_proposal')->where('sno', $proposalId)->first();

    //         // Products
    //         $products = DB::table('et_proposal_product_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
    //             ->where('et_proposal_product_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name', 'et_proposal_product_cart.original_amount', 'et_proposal_product_cart.product_amount')
    //             ->get();

    //         // Packages
    //         $packages = DB::table('et_proposal_package_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_package_cart.product_id')
    //             ->where('et_proposal_package_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name as package_name', 'et_proposal_package_cart.original_product_amount', 'et_proposal_package_cart.cust_product_amount')
    //             ->get();

    //         // Sum original & custom
    //         $totalOriginal = $products->sum('original_amount') + $packages->sum('original_product_amount');
    //         $totalCustom   = $products->sum('product_amount') + $packages->sum('cust_product_amount');

    //         // ✅ Only eligible for PI
    //         if ($totalCustom <= $totalOriginal) {
    //             continue;
    //         }

    //         // Collection INR
    //         $collectionINR = DB::table('et_transaction')
    //             ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_payment.proposal_id', $proposalId)
    //             ->where('et_transaction.payment_status', 1)
    //             ->sum('et_transaction.total_amount_inr');

    //         if ($collectionINR <= 0) continue;

    //         $conversionRate = $totalCustom > 0 ? $collectionINR / $totalCustom : 1;

    //         $profitINR = ($totalCustom - $totalOriginal) * $conversionRate;
    //         $profitNet = $profitINR / (1 + ($gst_percent / 100));
    //         $collectionNet = $collectionINR / (1 + ($gst_percent / 100));
    //         $profitPercentage = $collectionNet > 0 ? ($profitNet / $collectionNet) * 100 : 0;

    //         $proposalDetails->push([
    //             'proposal_id' => $proposal->sno,
    //             'proposal_title' => $proposal->service_title ?? '-',
    //             'products' => $products,
    //             'packages' => $packages,
    //             'total_original' => $totalOriginal,
    //             'total_custom' => $totalCustom,
    //             'profit_net' => $profitNet,
    //             'profit_percentage' => $profitPercentage
    //         ]);
    //     }

    //     if ($proposalDetails->isEmpty()) {
    //         return '<div class="alert alert-info">No profitable incentive proposals after eligibility check.</div>';
    //     }

    //     // Step 3: Build table
    //     $html = '<div class="table-responsive"><table class="table table-bordered table-striped table-hover">';
    //     $html .= '<thead class="table-primary">
    //                 <tr>
    //                     <th>Proposal ID</th>
    //                     <th>Title</th>
    //                     <th>Products (O / C)</th>
    //                     <th>Packages (O / C)</th>
    //                     <th>Total Original</th>
    //                     <th>Total Custom</th>
    //                     <th>Profit %</th>
    //                     <th>Profit ₹</th>
    //                 </tr>
    //             </thead><tbody>';

    //     foreach ($proposalDetails as $detail) {
    //         $productList = '';
    //         foreach ($detail['products'] as $p) {
    //             $productList .= $p->product_name . ' (' . number_format($p->original_amount) . ' / ' . number_format($p->product_amount) . ')<br>';
    //         }

    //         $packageList = '';
    //         foreach ($detail['packages'] as $pkg) {
    //             $packageList .= $pkg->package_name . ' (' . number_format($pkg->original_product_amount) . ' / ' . number_format($pkg->cust_product_amount) . ')<br>';
    //         }

    //         // Color-coded profit
    //         $profitPercent = round($detail['profit_percentage'], 2);
    //         if ($profitPercent >= 30) $profitColor = 'bg-success text-white';
    //         elseif ($profitPercent >= 15) $profitColor = 'bg-warning text-dark';
    //         else $profitColor = 'bg-danger text-white';

    //         $html .= '<tr>
    //             <td>' . $detail['proposal_id'] . '</td>
    //             <td>' . $detail['proposal_title'] . '</td>
    //             <td>' . $productList . '</td>
    //             <td>' . $packageList . '</td>
    //             <td>' . number_format($detail['total_original']) . '</td>
    //             <td>' . number_format($detail['total_custom']) . '</td>
    //             <td><span class="badge ' . $profitColor . '">' . $profitPercent . '%</span></td>
    //             <td>₹' . number_format($detail['profit_net']) . '</td>
    //         </tr>';
    //     }

    //     $html .= '</tbody></table></div>';

    //     // Step 4: Overall totals
    //     $overallCollectionNet = $proposalDetails->sum(function($d) use ($gst_percent) {
    //         return DB::table('et_transaction')
    //             ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_payment.proposal_id', $d['proposal_id'])
    //             ->where('et_transaction.payment_status', 1)
    //             ->sum('et_transaction.total_amount_inr') / (1 + ($gst_percent / 100));
    //     });

    //     $overallProfitNet = $proposalDetails->sum('profit_net');
    //     $overallProfitPercentage = $overallCollectionNet > 0 ? ($overallProfitNet / $overallCollectionNet) * 100 : 0;

    //     // Matched slab
    //     $matchedSlabPI = 'No Matching Slab';
    //     $piRewardPercent = 0;
    //     foreach ($pi_slabs as $slab) {
    //         if ($overallProfitPercentage >= $slab['min'] && $overallProfitPercentage <= $slab['max']) {
    //             $matchedSlabPI = $slab['min'] . '% - ' . $slab['max'] . '%';
    //             $piRewardPercent = $slab['percentage'];
    //             break;
    //         }
    //     }

    //     $piRewardAmount = ($overallProfitNet * $piRewardPercent) / 100;

    //     // Step 5: Footer cards
    //     $html .= '<div class="row g-3 mt-4">';
    //     $cards = [
    //         ['title'=>'Total Proposals','value'=>$proposalDetails->count(),'border'=>'border-primary'],
    //         ['title'=>'Net Collection (₹)','value'=>number_format($overallCollectionNet),'border'=>'border-success'],
    //         ['title'=>'Net Profit (₹)','value'=>number_format($overallProfitNet),'border'=>'border-warning'],
    //         ['title'=>'Matched PI Slab','value'=>$matchedSlabPI . '<br><span class="text-success fw-bold">Reward: ₹' . number_format($piRewardAmount) . '</span>','border'=>'border-info']
    //     ];

    //     foreach ($cards as $card) {
    //         $html .= '<div class="col-md-3">
    //                     <div class="card text-center shadow-sm ' . $card['border'] . '">
    //                         <div class="card-body">
    //                             <h6 class="card-title text-uppercase">' . $card['title'] . '</h6>
    //                             <h2 class="card-text fw-bold">' . $card['value'] . '</h2>
    //                         </div>
    //                     </div>
    //                 </div>';
    //     }

    //     $html .= '</div>';

    //     return $html;
    // }
    // accordiaon view
    // public function getPIDetails(Request $request) {
    //     $staffId  = $request->query('staff_id');
    //     $monthRaw = $request->query('month');
    //     $year     = $request->query('year');
    //     $branchId = $request->query('branch_id');

    //     if (!$staffId || !$monthRaw || !$year || !$branchId) {
    //         return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    //     }

    //     $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    //     $gst_percent = 18;

    //     // Get staff & role info
    //     $staff = \App\Models\StaffModel::select('et_staff.staff_name','et_staff.role_id','et_staff.staff_image','et_department.department_name')
    //         ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //         ->where('et_staff.sno', $staffId)
    //         ->where('et_staff.branch_id', $branchId)
    //         ->where('et_staff.status', 0)
    //         ->first();

    //     if (!$staff) return '<div class="alert alert-danger">Staff not found.</div>';

    //     // Load PI slabs
    //     $incentive = \App\Models\IncentiveModel::where('role_id', $staff->role_id)
    //         ->where('branch_id', $branchId)
    //         ->whereMonth('incentive_month', $month)
    //         ->whereYear('incentive_month', $year)
    //         ->where('status', 0)
    //         ->first();

    //     $pi_slabs = $incentive && $incentive->pi_slab_json ? json_decode($incentive->pi_slab_json, true) : [];

    //     // Step 1: Eligible proposals
    //     $proposalIds = DB::table('et_customer')
    //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
    //                 ->whereRaw('et_payment.transaction_date = (
    //                     SELECT MIN(ep.transaction_date)
    //                     FROM et_payment ep
    //                     WHERE ep.proposal_id = et_proposal.sno
    //                 )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_customer.status', 0)
    //         ->where('et_proposal.post_sale_check', 0)
    //         ->where('et_proposal.created_by', $staffId)
    //         ->whereYear('et_payment.transaction_date', $year)
    //         ->whereMonth('et_payment.transaction_date', $month)
    //         ->where('et_transaction.payment_status', 1)
    //         ->whereNotIn('et_proposal.proposal_status', [0,1,2])
    //         ->where('et_proposal.status',0)
    //         ->pluck('et_proposal.sno');

    //     if ($proposalIds->isEmpty()) return '<div class="alert alert-info">No profitable incentive proposals found.</div>';

    //     $proposalDetails = collect();
    //     foreach ($proposalIds as $proposalId) {
    //         $proposal = DB::table('et_proposal')->where('sno', $proposalId)->first();

    //         // Products
    //         $products = DB::table('et_proposal_product_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
    //             ->where('et_proposal_product_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name', 'et_proposal_product_cart.original_amount', 'et_proposal_product_cart.product_amount')
    //             ->get();

    //         // Packages
    //         $packages = DB::table('et_proposal_package_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_package_cart.product_id')
    //             ->where('et_proposal_package_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name as package_name', 'et_proposal_package_cart.original_product_amount', 'et_proposal_package_cart.cust_product_amount')
    //             ->get();

    //         $totalOriginal = $products->sum('original_amount') + $packages->sum('original_product_amount');
    //         $totalCustom   = $products->sum('product_amount') + $packages->sum('cust_product_amount');

    //         if ($totalCustom <= $totalOriginal) continue;

    //         $collectionINR = DB::table('et_transaction')
    //             ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_payment.proposal_id', $proposalId)
    //             ->where('et_transaction.payment_status', 1)
    //             ->sum('et_transaction.total_amount_inr');

    //         if ($collectionINR <= 0) continue;

    //         $conversionRate = $totalCustom > 0 ? $collectionINR / $totalCustom : 1;
    //         $profitINR = ($totalCustom - $totalOriginal) * $conversionRate;
    //         $profitNet = $profitINR / (1 + ($gst_percent / 100));
    //         $collectionNet = $collectionINR / (1 + ($gst_percent / 100));
    //         $profitPercentage = $collectionNet > 0 ? ($profitNet / $collectionNet) * 100 : 0;

    //         $proposalDetails->push([
    //             'proposal_id' => $proposal->sno,
    //             'proposal_title' => $proposal->service_title ?? '-',
    //             'products' => $products,
    //             'packages' => $packages,
    //             'total_original' => $totalOriginal,
    //             'total_custom' => $totalCustom,
    //             'profit_net' => $profitNet,
    //             'profit_percentage' => $profitPercentage
    //         ]);
    //     }

    //     if ($proposalDetails->isEmpty()) return '<div class="alert alert-info">No eligible PI proposals after check.</div>';

    //     // Step 2: Accordion table
    //     $html = '<div class="accordion" id="piAccordion">';
    //     foreach ($proposalDetails as $idx => $detail) {
    //         $profitPercent = round($detail['profit_percentage'], 2);
    //         $profitColor = $profitPercent >= 30 ? 'bg-success text-white' : ($profitPercent >= 15 ? 'bg-warning text-dark' : 'bg-danger text-white');

    //         $html .= '<div class="accordion-item">
    //             <h2 class="accordion-header" id="heading'.$idx.'">
    //                 <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse'.$idx.'" aria-expanded="false">
    //                     Proposal ID: '.$detail['proposal_id'].' - '.$detail['proposal_title'].' | Profit: <span class="badge '.$profitColor.'">'.$profitPercent.'%</span> | ₹'.number_format($detail['profit_net']).'
    //                 </button>
    //             </h2>
    //             <div id="collapse'.$idx.'" class="accordion-collapse collapse" data-bs-parent="#piAccordion">
    //                 <div class="accordion-body">
    //                     <strong>Products (Original / Custom)</strong><br>';
    //         foreach ($detail['products'] as $p) {
    //             $html .= $p->product_name.' ('.number_format($p->original_amount).' / '.number_format($p->product_amount).')<br>';
    //         }
    //         $html .= '<br><strong>Packages (Original / Custom)</strong><br>';
    //         foreach ($detail['packages'] as $pkg) {
    //             $html .= $pkg->package_name.' ('.number_format($pkg->original_product_amount).' / '.number_format($pkg->cust_product_amount).')<br>';
    //         }
    //         $html .= '</div></div></div>';
    //     }
    //     $html .= '</div>';

    //     // Step 3: Overall summary card
    //     $overallCollectionNet = $proposalDetails->sum('profit_net') + $proposalDetails->sum(function($d) use ($gst_percent) {
    //         return DB::table('et_transaction')
    //             ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_payment.proposal_id', $d['proposal_id'])
    //             ->where('et_transaction.payment_status', 1)
    //             ->sum('et_transaction.total_amount_inr') / (1 + ($gst_percent / 100));
    //     });
    //     $overallProfitNet = $proposalDetails->sum('profit_net');
    //     $overallProfitPercentage = $overallCollectionNet > 0 ? ($overallProfitNet / $overallCollectionNet) * 100 : 0;

    //     // Matched slab
    //     $matchedSlabPI = 'No Matching Slab';
    //     $piRewardPercent = 0;
    //     foreach ($pi_slabs as $slab) {
    //         if ($overallProfitPercentage >= $slab['min'] && $overallProfitPercentage <= $slab['max']) {
    //             $matchedSlabPI = $slab['min'].'% - '.$slab['max'].'%';
    //             $piRewardPercent = $slab['percentage'];
    //             break;
    //         }
    //     }
    //     $piRewardAmount = ($overallProfitNet * $piRewardPercent) / 100;

    //     $html .= '<div class="row g-3 mt-4">';
    //     $cards = [
    //         ['title'=>'Total Proposals','value'=>$proposalDetails->count(),'border'=>'border-primary'],
    //         ['title'=>'Net Collection (₹)','value'=>number_format($overallCollectionNet),'border'=>'border-success'],
    //         ['title'=>'Net Profit (₹)','value'=>number_format($overallProfitNet),'border'=>'border-warning'],
    //         ['title'=>'Matched PI Slab','value'=>$matchedSlabPI.'<br><span class="text-success fw-bold">Reward: ₹'.number_format($piRewardAmount).'</span>','border'=>'border-info']
    //     ];
    //     foreach ($cards as $card) {
    //         $html .= '<div class="col-md-3">
    //                     <div class="card text-center shadow-sm '.$card['border'].'">
    //                         <div class="card-body">
    //                             <h6 class="card-title text-uppercase">'.$card['title'].'</h6>
    //                             <h2 class="card-text fw-bold">'.$card['value'].'</h2>
    //                         </div>
    //                     </div>
    //                 </div>';
    //     }
    //     $html .= '</div>';

    //     return $html;
    // }

    // public function getPIDetails(Request $request) {
    //     $staffId  = $request->query('staff_id');
    //     $monthRaw = $request->query('month');
    //     $year     = $request->query('year');
    //     $branchId = $request->query('branch_id');

    //     if (!$staffId || !$monthRaw || !$year || !$branchId) {
    //         return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    //     }

    //     $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    //     $gst_percent = 18;

    //     // Staff info
    //     $staff = \App\Models\StaffModel::select('et_staff.staff_name','et_staff.role_id','et_staff.staff_image','et_department.department_name')
    //         ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
    //         ->where('et_staff.sno', $staffId)
    //         ->where('et_staff.branch_id', $branchId)
    //         ->where('et_staff.status', 0)
    //         ->first();
    //     if (!$staff) return '<div class="alert alert-danger">Staff not found.</div>';

    //     // PI slabs
    //     $incentive = \App\Models\IncentiveModel::where('role_id', $staff->role_id)
    //         ->where('branch_id', $branchId)
    //         ->whereMonth('incentive_month', $month)
    //         ->whereYear('incentive_month', $year)
    //         ->where('status', 0)
    //         ->first();
    //     $pi_slabs = $incentive && $incentive->pi_slab_json ? json_decode($incentive->pi_slab_json, true) : [];

    //     // Eligible proposals
    //     $proposalIds = DB::table('et_customer')
    //         ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
    //         ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
    //         ->join('et_payment', function($join) {
    //             $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
    //                 ->whereRaw('et_payment.transaction_date = (
    //                     SELECT MIN(ep.transaction_date)
    //                     FROM et_payment ep
    //                     WHERE ep.proposal_id = et_proposal.sno
    //                 )');
    //         })
    //         ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //         ->where('et_customer.status', 0)
    //         ->where('et_proposal.post_sale_check', 0)
    //         ->where('et_proposal.created_by', $staffId)
    //         ->whereYear('et_payment.transaction_date', $year)
    //         ->whereMonth('et_payment.transaction_date', $month)
    //         ->where('et_transaction.payment_status', 1)
    //         ->whereNotIn('et_proposal.proposal_status', [0,1,2])
    //         ->where('et_proposal.status',0)
    //         ->pluck('et_proposal.sno');

    //     if ($proposalIds->isEmpty()) return '<div class="alert alert-info">No profitable incentive proposals found.</div>';

    //     $proposalDetails = collect();
    //     foreach ($proposalIds as $proposalId) {
    //         $proposal = DB::table('et_proposal')->where('sno', $proposalId)->first();

    //         $products = DB::table('et_proposal_product_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
    //             ->where('et_proposal_product_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name', 'et_proposal_product_cart.original_amount', 'et_proposal_product_cart.product_amount')
    //             ->get();

    //         $packages = DB::table('et_proposal_package_cart')
    //             ->join('et_product', 'et_product.sno', '=', 'et_proposal_package_cart.product_id')
    //             ->where('et_proposal_package_cart.proposal_sno', $proposalId)
    //             ->select('et_product.product_name as package_name', 'et_proposal_package_cart.original_product_amount', 'et_proposal_package_cart.cust_product_amount')
    //             ->get();

    //         $totalOriginal = $products->sum('original_amount') + $packages->sum('original_product_amount');
    //         $totalCustom   = $products->sum('product_amount') + $packages->sum('cust_product_amount');

    //         if ($totalCustom <= $totalOriginal) continue;

    //         $collectionINR = DB::table('et_transaction')
    //             ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
    //             ->where('et_payment.proposal_id', $proposalId)
    //             ->where('et_transaction.payment_status', 1)
    //             ->sum('et_transaction.total_amount_inr');

    //         if ($collectionINR <= 0) continue;

    //         $conversionRate = $totalCustom > 0 ? $collectionINR / $totalCustom : 1;
    //         $profitINR = ($totalCustom - $totalOriginal) * $conversionRate;
    //         $profitNet = $profitINR / (1 + ($gst_percent / 100));
    //         $collectionNet = $collectionINR / (1 + ($gst_percent / 100));
    //         $profitPercentage = $collectionNet > 0 ? ($profitNet / $collectionNet) * 100 : 0;

    //         $proposalDetails->push([
    //             'proposal_id' => $proposal->sno,
    //             'proposal_code' => $proposal->proposal_id,
    //             'product_package' => $proposal->product_package,
    //             'proposal_title' => $proposal->service_title ?? '-',
    //             'products' => $products,
    //             'packages' => $packages,
    //             'total_original' => $totalOriginal,
    //             'total_custom' => $totalCustom,
    //             'profit_net' => $profitNet,
    //             'profit_percentage' => $profitPercentage
    //         ]);
    //     }

    //     if ($proposalDetails->isEmpty()) return '<div class="alert alert-info">No eligible PI proposals after check.</div>';

    //     // Accordion with Chart.js
    //     $html = '<div class="accordion" id="piAccordion">';
    //     foreach ($proposalDetails as $idx => $detail) {
    //         $profitPercent = round($detail['profit_percentage'], 2);
    //         $profitColor = $profitPercent >= 30 ? 'bg-success text-white' : ($profitPercent >= 15 ? 'bg-warning text-dark' : 'bg-danger text-white');

    //         // Prepare chart data JSON
    //         $chartData = [
    //             'labels' => ['Original','Custom','Profit'],
    //             'data' => [
    //                 $detail['total_original'],
    //                 $detail['total_custom'],
    //                 $detail['profit_net']
    //             ]
    //         ];

    //         $html .= '<div class="accordion-item">
    //             <h2 class="accordion-header" id="heading'.$idx.'">
    //                 <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse'.$idx.'" aria-expanded="false">
    //                     '.$detail['proposal_code'].' - '.$detail['proposal_title'].' | Profit: <span class="badge '.$profitColor.'">'.$profitPercent.'%</span> | ₹'.number_format($detail['profit_net']).'
    //                 </button>
    //             </h2>
    //             <div id="collapse'.$idx.'" class="accordion-collapse collapse" data-bs-parent="#piAccordion">
    //                 <div class="accordion-body">';
            
    //             if($detail['product_package'] == 1){
    //                 $html .= '<strong>Products (Original / Custom)</strong><br>';
    //                 foreach ($detail['products'] as $p) {
    //                     $html .= $p->product_name.' ('.number_format($p->original_amount).' / '.number_format($p->product_amount).')<br>';
    //                 }
    //             }
    //             if($detail['product_package'] == 2){
    //                 $html .= '<br><strong>Packages (Original / Custom)</strong><br>';
    //                 foreach ($detail['packages'] as $pkg) {
    //                     $html .= $pkg->package_name.' ('.number_format($pkg->original_product_amount).' / '.number_format($pkg->cust_product_amount).')<br>';
    //                 }
    //             }

    //         // Add chart canvas
    //         $html .= '<canvas id="chart'.$idx.'" height="100"></canvas>
    //             <script>
    //                 var ctx = document.getElementById("chart'.$idx.'").getContext("2d");
    //                 new Chart(ctx, {
    //                     type: "bar",
    //                     data: {
    //                         labels: '.json_encode($chartData['labels']).',
    //                         datasets: [{
    //                             label: "Amount (₹)",
    //                             data: '.json_encode($chartData['data']).',
    //                             backgroundColor: ["#6c757d","#0d6efd","#198754"]
    //                         }]
    //                     },
    //                     options: {
    //                         responsive:true,
    //                         plugins: { legend:{ display:false }, title:{ display:true, text:"Proposal Amount Comparison" } },
    //                         scales: { y:{ beginAtZero:true } }
    //                     }
    //                 });
    //             </script>
    //         </div></div></div>';
    //     }
    //     $html .= '</div>';

    //     // Overall summary card
    //     $overallCollectionNet = $proposalDetails->sum(function($d) use ($gst_percent){
    //         return $d['profit_net'] + 0;
    //     });
    //     $overallProfitNet = $proposalDetails->sum('profit_net');
    //     $overallProfitPercentage = $overallCollectionNet > 0 ? ($overallProfitNet / $overallCollectionNet) * 100 : 0;

    //     $matchedSlabPI = 'No Matching Slab';
    //     $piRewardPercent = 0;
    //     foreach ($pi_slabs as $slab) {
    //         $min = (float)$slab['min']; $max = (float)$slab['max'];
    //         if ($overallProfitPercentage >= $min && $overallProfitPercentage <= $max) {
    //             $matchedSlabPI = $min.'% - '.$max.'%';
    //             $piRewardPercent = (float)$slab['percentage'];
    //             break;
    //         }
    //     }
    //     $piRewardAmount = ($overallProfitNet * $piRewardPercent) / 100;

    //     $html .= '<div class="row g-3 mt-4">
    //         <div class="col-md-3"><div class="card text-center shadow-sm border-primary"><div class="card-body">
    //             <h6 class="card-title text-uppercase">Total Proposals</h6>
    //             <h2 class="card-text fw-bold">'.$proposalDetails->count().'</h2>
    //         </div></div></div>
    //         <div class="col-md-3"><div class="card text-center shadow-sm border-success"><div class="card-body">
    //             <h6 class="card-title text-uppercase">Net Collection (₹)</h6>
    //             <h2 class="card-text fw-bold">'.number_format($overallCollectionNet).'</h2>
    //         </div></div></div>
    //         <div class="col-md-3"><div class="card text-center shadow-sm border-warning"><div class="card-body">
    //             <h6 class="card-title text-uppercase">Net Profit (₹)</h6>
    //             <h2 class="card-text fw-bold">'.number_format($overallProfitNet).'</h2>
    //         </div></div></div>
    //         <div class="col-md-3"><div class="card text-center shadow-sm border-info"><div class="card-body">
    //             <h6 class="card-title text-uppercase">Matched PI Slab</h6>
    //             <p class="mb-1 fw-bold">'.$matchedSlabPI.'</p>
    //             <h5 class="card-text text-success">Reward: ₹'.number_format($piRewardAmount).'</h5>
    //         </div></div></div>
    //     </div>';

    //     return $html;
    // }

    public function getPIDetails(Request $request) {
    $staffId  = $request->query('staff_id');
    $monthRaw = $request->query('month');
    $year     = $request->query('year');
    $branchId = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
        return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    $gst_percent = 18;

    // Staff info
    $staff = \App\Models\StaffModel::select('et_staff.staff_name','et_staff.role_id','et_staff.staff_image','et_department.department_name')
        ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
        ->where('et_staff.sno', $staffId)
        ->where('et_staff.branch_id', $branchId)
        ->where('et_staff.status', 0)
        ->first();
    if (!$staff) return response()->json(['data'=>[], 'error'=>'Staff not found'], 404);

    // PI slabs
    $incentive = \App\Models\IncentiveModel::where('role_id', $staff->role_id)
        ->where('branch_id', $branchId)
        ->whereMonth('incentive_month', $month)
        ->whereYear('incentive_month', $year)
        ->where('status', 0)
        ->first();
    $pi_slabs = $incentive && $incentive->pi_slab_json ? json_decode($incentive->pi_slab_json, true) : [];

    // Eligible proposals
    $proposalIds = DB::table('et_customer')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
        ->join('et_payment', function($join) {
            $join->on('et_payment.proposal_id', '=', 'et_proposal.sno')
                 ->whereRaw('et_payment.transaction_date = (SELECT MIN(ep.transaction_date) FROM et_payment ep WHERE ep.proposal_id = et_proposal.sno)');
        })
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.status', 0)
        ->where('et_proposal.post_sale_check', 0)
        ->where('et_proposal.created_by', $staffId)
        ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->whereNotIn('et_proposal.proposal_status', [0,1,2])
        ->where('et_proposal.status',0)
        ->pluck('et_proposal.sno');

    if ($proposalIds->isEmpty()) {
        return response()->json(['data' => [], 'error' => 'No eligible proposals'], 200);
    }

    $proposalDetails = collect();
    foreach ($proposalIds as $proposalId) {
        $proposal = DB::table('et_proposal')->where('sno', $proposalId)->first();

        $products = DB::table('et_proposal_product_cart')
            ->join('et_product', 'et_product.sno', '=', 'et_proposal_product_cart.product_id')
            ->where('et_proposal_product_cart.proposal_sno', $proposalId)
            ->select('et_product.product_name', 'et_proposal_product_cart.original_amount', 'et_proposal_product_cart.product_amount')
            ->get();

        $packages = DB::table('et_proposal_package_cart')
            ->join('et_product', 'et_product.sno', '=', 'et_proposal_package_cart.product_id')
            ->where('et_proposal_package_cart.proposal_sno', $proposalId)
            ->select('et_product.product_name as package_name', 'et_proposal_package_cart.original_product_amount', 'et_proposal_package_cart.cust_product_amount')
            ->get();

        $totalOriginal = $products->sum('original_amount') + $packages->sum('original_product_amount');
        $totalCustom   = $products->sum('product_amount') + $packages->sum('cust_product_amount');

        if ($totalCustom <= $totalOriginal) continue;

        $collectionINR = DB::table('et_transaction')
            ->join('et_payment', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_payment.proposal_id', $proposalId)
            ->where('et_transaction.payment_status', 1)
            ->sum('et_transaction.total_amount_inr');

        if ($collectionINR <= 0) continue;

        $conversionRate = $totalCustom > 0 ? $collectionINR / $totalCustom : 1;
        $profitINR = ($totalCustom - $totalOriginal) * $conversionRate;
        $profitNet = $profitINR / (1 + ($gst_percent / 100));
        $collectionNet = $collectionINR / (1 + ($gst_percent / 100));
        $profitPercentage = $collectionNet > 0 ? ($profitNet / $collectionNet) * 100 : 0;

        // Determine matched slab for this proposal
        $matchedSlab = 'No Matching Slab';
        $piRewardPercent = 0;
        foreach ($pi_slabs as $slab) {
            if ($profitPercentage >= $slab['min'] && $profitPercentage <= $slab['max']) {
                $matchedSlab = $slab['min'].'% - '.$slab['max'].'%';
                $piRewardPercent = (float)$slab['percentage'];
                break;
            }
        }
        $piRewardAmount = ($profitNet * $piRewardPercent)/100;

        $proposalDetails->push([
            'proposal_id' => $proposal->sno,
            'proposal_code' => $proposal->proposal_id,
            'proposal_title' => $proposal->service_title ?? '-',
            'product_package' => $proposal->product_package,
            'products' => $products,
            'packages' => $packages,
            'total_original' => $totalOriginal,
            'total_custom' => $totalCustom,
            'collection_inr' => $collectionINR,
            'profit_net' => $profitNet,
            'profit_percentage' => $profitPercentage,
            'matched_slab' => $matchedSlab,
            'pi_reward_percent' => $piRewardPercent,
            'pi_reward_amount' => $piRewardAmount
        ]);
    }

    // Overall calculation
    $overallCollectionNet = $proposalDetails->sum('collection_inr') / (1 + ($gst_percent/100));
    $overallProfitNet = $proposalDetails->sum('profit_net');
    $overallProfitPercentage = $overallCollectionNet > 0 ? ($overallProfitNet / $overallCollectionNet)*100 : 0;

    $overallMatchedSlab = 'No Matching Slab';
    $overallPiPercent = 0;
    foreach ($pi_slabs as $slab) {
        if ($overallProfitPercentage >= $slab['min'] && $overallProfitPercentage <= $slab['max']) {
            $overallMatchedSlab = $slab['min'].'% - '.$slab['max'].'%';
            $overallPiPercent = (float)$slab['percentage'];
            break;
        }
    }
    $overallPiAmount = ($overallProfitNet * $overallPiPercent)/100;

    return response()->json([
        'staff' => $staff,
        'proposals' => $proposalDetails,
        'overall' => [
            'total_proposals' => $proposalDetails->count(),
            'collection_net' => $overallCollectionNet,
            'profit_net' => $overallProfitNet,
            'profit_percentage' => $overallProfitPercentage,
            'matched_slab' => $overallMatchedSlab,
            'pi_percent' => $overallPiPercent,
            'pi_amount' => $overallPiAmount
        ]
    ]);
}
}