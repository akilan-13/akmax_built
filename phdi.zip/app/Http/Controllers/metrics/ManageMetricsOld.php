<?php

namespace App\Http\Controllers\metrics;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessGoalSetModel;
use App\Models\ManageTargetModel;
use App\Models\PaymentModel;
use App\Models\TrainingModel;
use App\Models\TransactionModel;
use App\Models\StaffModel;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\CustomerModel;
use App\Models\IncentiveModel;
use App\Models\OldCustomerModel;
use App\Models\BranchModel;
use App\Models\BatchModel;
use App\Models\AttendanceModel;
use Carbon\Carbon;
use App\Models\ManageCoursesModel;
use Illuminate\Support\Collection;
class ManageMetrics extends Controller
{
    public function index(Request $request)
    {
        $branch_id = $request->user()->branch_id;

        
            
        return view('content.metrics.manage_metrics');
    }
     public function incentive(Request $request)
    {
        $branch_id = $request->user()->branch_id;
            
        return view('content.metrics.manage_incentive');
    }
   public function fetchIncentive(Request $request)
   {
    // Use input() to safely fetch values (or use $request->get() / query() for GET)
    $role_id   = $request->input('role_id');
    $month     = $request->input('month'); // you named it monthRaw, but using as month
    $year      = $request->input('year');
    $branchId  = $request->input('branch_id')??$request->user()->branch_id;

    // Fetch staff list
    $staff = StaffModel::select('et_staff.staff_name')
        ->where('et_staff.branch_id', $branchId)
        ->where('et_staff.role_id', $role_id)
        ->where('et_staff.status', 0)
        ->get();

    // Check if staff exists
    if ($staff->isEmpty()) {
        return response()->json([
            'status' => false,
            'message' => 'Staff not found'
        ]);
    }

    // Get unique staff names
    $staffNames = $staff->pluck('staff_name')->unique()->values();

    // Define incentive types
    $types = ['ECI', 'PI', 'BI', '10X', 'SI', 'LI'];

    // Return response
    return response()->json([
        'status' => true,
        'staff_names' => $staffNames,
        'types' => $types
    ]);
}
   
    public function getMetrics(Request $request)
    {
        $monthNumber = date('m', strtotime("1 " . $request->month));
        $targetDate = $request->year . '-' . $monthNumber . '-01';
        $year = $request->year;
        $month = $monthNumber;
        $branch_id = $request->user()->branch_id;
        // Fetch target
        $targets = ManageTargetModel::where('branch_target.branch_id', $branch_id)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->where('branch_target.date', $targetDate)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                     $firstIds = DB::table('et_proposal_pay_slot')
                        ->join('et_proposal', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                        ->where('et_proposal.status', 0)
                        ->where('et_proposal_pay_slot.status', 0)
                        ->where('et_proposal_pay_slot.branch_id', $branch_id)
                        ->whereNotIn('et_proposal.proposal_status', [0, 2])
                        ->select(DB::raw('MIN(et_proposal_pay_slot.sno) as first_id'))
                        ->groupBy('et_proposal_pay_slot.proposal_sno')
                        ->orderBy('first_id', 'asc')
                        ->pluck('first_id');
    
        // Old payments
        // $totalPaidAmountOld = DB::table('et_old_payments')
        //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
        //     ->where('et_old_customer.branch_id', $branch_id)
        //     ->where('et_old_payments.status', '!=', 2)
        //     ->whereIn('et_old_customer.status', [1, 4])
        //     ->where('et_old_payments.amount', '>', 0)
        //     ->whereYear('et_old_payments.created_at', $year)
        //     ->whereMonth('et_old_payments.created_at', $month)
        //     ->sum('et_old_payments.paidAmount');
    
        // New payments
        $totalPaidAmountNew = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->where('et_customer.status', 0)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereYear('et_proposal_pay_slot.initialPayDate', $year)
            ->whereMonth('et_proposal_pay_slot.initialPayDate', $month)
            ->sum('et_proposal_pay_slot.paidAmount');
            
        // $transaction = DB::table('et_transaction')
        //      ->where('et_transaction.branch_id', $branch_id)
        //       ->whereYear('et_transaction.transaction_date', $year)
        //     ->whereMonth('et_transaction.transaction_date', $month)
        //      ->sum('et_transaction.credit');
            
        $transaction = DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
              ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
              ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
             ->where('et_lead.status', '!=',2)
             ->where('et_proposal_pay_slot.paid_status', 1)
             ->where('et_proposal_pay_slot.branch_id', $branch_id)
             ->whereYear('et_payment.transaction_date', $year)
             ->whereMonth('et_payment.transaction_date', $month)
             ->sum('et_proposal_pay_slot.paidAmount');
             
             $branch = BranchModel::where('sno', $branch_id)
              ->where('status', 0)
              ->orderBy('sno', 'desc')
              ->first();

      $gstPercentage = $branch ? $branch->gst_percentage  : 18;
             
        // $gst_percent = 18;
         
        $base_amount_paid = $transaction / (1 + ($gstPercentage / 100));
    
    // return $transaction;
            
        // $targetActual = $totalPaidAmountOld + $totalPaidAmountNew;
        $targetActual = $base_amount_paid;
        
         // Post-sale & pre-sale actuals (count only)
             $postSaleActual = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->whereNotIn('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereYear('et_proposal.created_at', $year)
            ->whereMonth('et_proposal.created_at', $month)
            ->distinct('et_proposal.sno')
            ->count('et_proposal.sno');
    
        // $preSaleActual = CustomerModel::whereIn('status', [0,6]) 
        //     ->where('post_sale_check', 0)
        //     ->where('branch_id', $branch_id)
        //     ->whereYear('created_at', $year)
        //     ->whereMonth('created_at', $month)
        //     ->count();
            
          $preSaleActualData = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
            ->where('et_transaction.payment_status', 1) // Ensure payment status is 1
            ->groupBy('et_customer.sno')  // Group by customer id (et_customer.sno)
            ->orderBy('et_customer.sno', 'asc')  // Order by customer id ascending
            ->get();
            
            $preSaleActual =count($preSaleActualData);
            
         $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();       // Carbon with time
         $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth()->endOfDay(); // Carbon with time
        // Initialize Carbon dates
        $start = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);
        
        
         //  harvestingscheduleamount
       
            $expectedNewByDate =DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                    ->selectRaw("
                        DATE(et_proposal_pay_slot.nextPayDate) as date, 
                        SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_expected
                    ", [$gstPercentage])
                    ->where('et_customer.branch_id', $branch_id)
                    ->where('et_proposal_pay_slot.paid_status', 1)
                    ->where('et_customer.status', 0)
                    ->where('et_proposal_pay_slot.paidAmount', '>', 0)
                    ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
                    ->groupBy(DB::raw('DATE(et_proposal_pay_slot.nextPayDate)'))
                    ->pluck('total_expected', 'date')
                    ->toArray();
            //   $totalPaidAmountoldNewByDate = DB::table('et_old_payments')
            //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
            //     ->selectRaw('DATE(et_old_payments.created_at) as date, SUM(et_old_payments.paidAmount) as total_expected')
            //     ->where('et_old_customer.branch_id', $branch_id)
            //     ->whereIn('et_old_customer.status', [1, 4])
            //     ->where('et_old_payments.amount', '>', 0)
            //     ->whereBetween('et_old_payments.created_at', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_old_payments.created_at)'))
            //     ->pluck('total_expected', 'date')
            //     ->toArray();
            
            $harvestingsNotPaidByDate = DB::table('et_proposal_pay_slot')
                    // ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_proposal', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
                    ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                 ->selectRaw("
                        DATE(et_proposal_pay_slot.nextPayDate) as date, 
                        SUM(et_proposal_pay_slot.payable_amount) / (1 + (? / 100)) as total_expected
                    ", [$gstPercentage])
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.paid_status', 0) // paid amount
                ->where('et_customer.status', 0)
                ->where('et_proposal.status', 0)
                 ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
                ->whereNotIn('et_proposal.proposal_status', [0,2])
                ->where('et_proposal_pay_slot.payable_amount','>', 0) 
                ->whereBetween('et_proposal_pay_slot.nextPayDate', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal_pay_slot.nextPayDate)'))
                ->pluck('total_expected', 'date')
                ->toArray();
                
              
            
                    
             $harvestings = collect($expectedNewByDate)
                    // ->mergeRecursive($totalPaidAmountoldNewByDate)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    });
                
                $harvestingscheduleamount = collect($harvestingsNotPaidByDate)
                    ->mergeRecursive($harvestings)
                    ->map(function ($val) {
                        return is_array($val) ? array_sum($val) : $val;
                    })
                    ->toArray();
            
            // here we found harvesting Paid amount
            $paidAmountNewByDate = DB::table('et_proposal_pay_slot')
                    ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                    ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                 ->selectRaw("
                    DATE(et_proposal_pay_slot.initialPayDate) as date, 
                    SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_paid
                ", [$gstPercentage])
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->where('et_customer.status', 0)
                 ->whereNotIn('et_proposal_pay_slot.sno',$firstIds)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
                ->pluck('total_paid', 'date')
                ->toArray();
            
            // $paidAmountOldByDate = DB::table('et_old_payments')
            //     ->join('et_old_customer', 'et_old_payments.customer_id', '=', 'et_old_customer.sno')
            //     ->selectRaw('DATE(et_old_payments.created_at) as date, SUM(et_old_payments.paidAmount) as total_paid')
            //     ->where('et_old_customer.branch_id', $branch_id)
            //     ->where('et_old_payments.status', '!=', 2)
            //     ->whereIn('et_old_customer.status', [1, 4])
            //     ->where('et_old_payments.amount', '>', 0)
            //     ->whereBetween('et_old_payments.created_at', [$startDate, $endDate])
            //     ->groupBy(DB::raw('DATE(et_old_payments.created_at)'))
            //     ->pluck('total_paid', 'date')
            //     ->toArray();
                
                $harvestingPaidAmountIn = $paidAmountNewByDate ;
              
      $monthlyTargetActualsByDate = DB::table('et_proposal_pay_slot')
            ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->selectRaw("
                DATE(et_payment.transaction_date) as date, 
                SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as credit
            ", [$gstPercentage])
            ->where('et_proposal_pay_slot.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
            ->pluck('credit', 'date')
            ->toArray();
            
           
             
        // Fetch pre-sale actuals per day
        // $preSaleActualsByDate = CustomerModel::selectRaw('DATE(created_at) as date, COUNT(*) as count')
        //     ->whereIn('status', [0, 6])
        //     ->where('post_sale_check', 0)
        //     ->where('branch_id', $branch_id)
        //     ->whereBetween('created_at', [$startDate, $endDate])
        //     ->groupBy(DB::raw('DATE(created_at)'))
        //     ->pluck('count', 'date')
        //     ->toArray();
            
     $preSaleActualsByDate = DB::table('et_customer')
        ->selectRaw('DATE(et_payment.transaction_date) as date, COUNT(DISTINCT et_customer.sno) as count')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_payment', 'et_payment.customer_id', '=', 'et_customer.sno')
        ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
        ->where('et_customer.status', 0)
        ->where('et_lead.created_by','>', 1)
        ->where('et_customer.post_sale_check', 0)
        ->where('et_customer.branch_id', $branch_id)
        ->whereYear('et_payment.transaction_date', $year)
        ->whereMonth('et_payment.transaction_date', $month)
        ->where('et_transaction.payment_status', 1)
        ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
        ->orderBy(DB::raw('DATE(et_payment.transaction_date)'), 'asc')
        ->pluck('count', 'date')
        ->toArray();


            
            // $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
            // ->where('post_sale_check', 0)
            // ->where('branch_id', $branch_id)
            // ->whereYear('created_at', $year)
            // ->whereMonth('created_at', $month)
            // ->count();
            
             $preSaleActualData = DB::table('et_customer')
            ->select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_payment', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->join('et_transaction', 'et_transaction.payment_id', '=', 'et_payment.sno')
            ->where('et_customer.status', 0)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->whereYear('et_payment.transaction_date', $year)
            ->whereMonth('et_payment.transaction_date', $month)
             ->where('et_lead.created_by','>', 1)
            ->where('et_transaction.payment_status', 1) // Ensure payment status is 1
            ->groupBy('et_customer.sno')  // Group by customer id (et_customer.sno)
            ->orderBy('et_customer.sno', 'asc')  // Order by customer id ascending
            ->get();
            
            $preSaleActual =count($preSaleActualData);
            
           // Fetch post-sale actuals per day
       
            
            $postSaleActualsByDate = CustomerModel::join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
                ->selectRaw('DATE(et_proposal.created_at) as date, COUNT(DISTINCT et_proposal.sno) as count')
                ->whereIn('et_customer.status', [0, 6])
                ->where('et_customer.post_sale_check', 1)
                ->where('et_proposal.post_sale_check', 1)
                ->where('et_proposal.proposal_status', [0,2])
                ->where('et_proposal.branch_id', $branch_id)
                ->whereBetween('et_proposal.created_at', [$startDate, $endDate])
                ->groupBy(DB::raw('DATE(et_proposal.created_at)'))
                ->pluck('count', 'date')
                ->toArray();
            
          // Fetch pre-sale customer IDs
        $preSaleCustomerIds = CustomerModel::whereIn('status', [0, 6])
            ->where('post_sale_check', 0)
            ->where('branch_id', $branch_id)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->pluck('sno')
            ->toArray();
            
       
        
        // Fetch post-sale customer IDs
        $postSaleCustomerIds = CustomerModel::whereIn('et_customer.status', [0, 6])
            ->join('et_proposal', 'et_customer.sno', '=', 'et_proposal.customer_id')
            ->where('et_customer.post_sale_check', 1)
            ->where('et_proposal.post_sale_check', 1)
            ->where('et_proposal.proposal_status', [0,2])
            ->where('et_proposal.branch_id', $branch_id)
            ->whereBetween('et_proposal.created_at', [$startDate, $endDate])
            ->pluck('et_proposal.sno')
            ->toArray();
            
       // Daily paid amounts for post-sale
        $dailyPaidAmountsPost =DB::table('et_proposal_pay_slot')
          ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereIn('et_customer.sno', $postSaleCustomerIds)
            ->where('et_customer.post_sale_check', 1)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            ->selectRaw("
                DATE(et_proposal_pay_slot.initialPayDate) as date, 
                SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
            ->pluck('total_amount', 'date')
            ->toArray();
        
        // Daily paid amounts for pre-sale
        $dailyPaidAmountsPre = DB::table('et_proposal_pay_slot')
          ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereIn('et_customer.sno', $preSaleCustomerIds)
            ->where('et_customer.post_sale_check', 0)
            ->where('et_customer.branch_id', $branch_id)
            ->where('et_proposal_pay_slot.payable_amount', '>', 0)
            ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
            ->selectRaw("
                DATE(et_proposal_pay_slot.initialPayDate) as date, 
                SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_proposal_pay_slot.initialPayDate)'))
            ->pluck('total_amount', 'date')
            ->toArray();
            
            
            
             // STEP 1: Get all pre-sale + post-sale payment invoice_ids to exclude
            $excludedInvoiceIds =  DB::table('et_proposal_pay_slot')
              ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                ->where('et_proposal_pay_slot.paid_status', 1)
                ->whereIn('et_customer.sno', array_merge($preSaleCustomerIds, $postSaleCustomerIds))
                ->where('et_customer.branch_id', $branch_id)
                ->where('et_proposal_pay_slot.payable_amount', '>', 0)
                ->whereBetween('et_proposal_pay_slot.initialPayDate', [$startDate, $endDate])
                ->pluck('et_proposal_pay_slot.invoice_id') 
                ->filter() // remove nulls
                ->unique() // ensure uniqueness
                ->toArray();
     
           $dailyPaidAmountOther = DB::table('et_payment')
            ->where('et_payment.branch_id', $branch_id)
            ->whereBetween('et_payment.transaction_date', [$startDate, $endDate])
            ->when(!empty($excludedInvoiceIds), function ($query) use ($excludedInvoiceIds) {
                $query->where(function ($subQuery) use ($excludedInvoiceIds) {
                    $subQuery->whereNotIn('et_payment.invoice_id', $excludedInvoiceIds)
                             ->orWhereNull('et_payment.invoice_id'); // include NULLs
                });
            })
            ->join('et_proposal_pay_slot', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
            ->selectRaw("
                DATE(et_payment.transaction_date) as date, 
                SUM(et_proposal_pay_slot.paidAmount) / (1 + (? / 100)) as total_amount
            ", [$gstPercentage])
            ->groupBy(DB::raw('DATE(et_payment.transaction_date)'))
            ->pluck('total_amount', 'date')
            ->toArray();
                    
            
        // Pre-sale cumulative per day
        $preSaleActualPerDay = [];
        $current = $start->copy();
        $cumulativePreSale = 0;
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $preSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePreSale += $dailyValue;
                $preSaleActualPerDay[$dateStr] = $cumulativePreSale;
            } else {
                $preSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        // Post-sale cumulative per day
        $postSaleActualPerDay = [];
        $current = $start->copy(); // reset date pointer
        $cumulativePostSale = 0;
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyValue = $postSaleActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativePostSale += $dailyValue;
                $postSaleActualPerDay[$dateStr] = $cumulativePostSale;
            } else {
                $postSaleActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }

        
        $monthlyTargetActualPerDay = [];
        $cumulativeTarget = 0;
        $current = $start->copy();
        $today = now()->format('Y-m-d');
        
        while ($current->lte($end)) {
            $dateStr = $current->format('Y-m-d');
            $dailyTarget = $monthlyTargetActualsByDate[$dateStr] ?? 0;
        
            if ($dateStr <= $today) {
                $cumulativeTarget += $dailyTarget;
                $monthlyTargetActualPerDay[$dateStr] = $cumulativeTarget;
            } else {
                $monthlyTargetActualPerDay[$dateStr] = 0;
            }
        
            $current->addDay();
        }
        
        
            $dailyPaidAmountPerDay = [];
            $cumulativePaid = 0;
            $current = \Carbon\Carbon::parse($startDate)->copy();
            $end = \Carbon\Carbon::parse($endDate);
            $today = now()->format('Y-m-d');
            
            while ($current->lte($end)) {
                $dateStr = $current->format('Y-m-d');
            
                $paidNew = $paidAmountNewByDate[$dateStr] ?? 0;
                $paidOld = $paidAmountOldByDate[$dateStr] ?? 0;
            
                $dailyTotalPaid = $paidNew + $paidOld;
            
                if ($dateStr <= $today) {
                    $cumulativePaid += $dailyTotalPaid;
                    $dailyPaidAmountPerDay[$dateStr] = $cumulativePaid;
                } else {
                    $dailyPaidAmountPerDay[$dateStr] = 0;
                }
            
                $current->addDay();
            }
                    
            $preSaleTarget      = $targets->no_of_registrations ?? 0;
            $postSaleTarget     = $targets->post_sale ?? 0;
            $monthlyTarget      = $targets->monthly_target ?? 0;
            $harvestingschedule = $harvestingscheduleamount;
            
            // $harvestingsExpectedByDate = $this->distributeIndividuallyPerDay($harvestingsExpectedByDate, $startDate, $endDate);
            $monthlyTargetExpectedByDate = $this->distributePerDay($monthlyTarget, $startDate, $endDate);
            $preSaleExpectedByDate = $this->distributePerDay($preSaleTarget, $startDate, $endDate);
            $postSaleExpectedByDate = $this->distributePerDay($postSaleTarget, $startDate, $endDate);
            
            $dates = array_keys($preSaleExpectedByDate);
       
        return response()->json([
            'status' => 200,
            'data' => $targets,
            'actuals' => [
                'target_actual' => $targetActual,
                'post_sale_actual' => $postSaleActual,
                'pre_sale_actual' => $preSaleActual,
                
            ],
            'distribution' => [
                'dates' => $dates,
                'harvestings_expected' => $harvestingschedule,
                'monthly_target_expected' => $monthlyTargetExpectedByDate,
                'pre_sale_expected' => $preSaleExpectedByDate,
                'post_sale_expected' => $postSaleExpectedByDate,
                // 'harvestings_actual_per_day' => $dailyPaidAmountPerDay,
                'harvestings_actual_per_day' => $harvestingPaidAmountIn,
                'monthly_target_actual_per_day' => $monthlyTargetActualPerDay,
                'pre_sale_actual_per_day' => $preSaleActualPerDay,
                'post_sale_actual_per_day' => $postSaleActualPerDay,
                'dailyPaidAmountsPre' => $dailyPaidAmountsPre,
                'dailyPaidAmountsPost' => $dailyPaidAmountsPost,
                'dailyPaidAmountsOther' => $dailyPaidAmountOther,
                // 'preSaleInvoiceIds' => $preSaleInvoiceDateMap,
            ],
        ]);
    }
    
    private function distributePerDay($total, $startDate)
    {
        $days = [];
    
        $start = \Carbon\Carbon::parse($startDate)->startOfDay();
        $end = $start->copy()->endOfMonth();
        $diffDays = $start->diffInDays($end) + 1;
    
        if ($diffDays <= 0) return [];
    
        $step = $total / $diffDays;
        $sum = 0;
        $currentDate = $start->copy();
    
        for ($i = 0; $i < $diffDays; $i++) {
            $sum += $step;
            $rounded = round($sum);
    
            // Ensure last day hits exact total (e.g., 100)
            if ($i == $diffDays - 1) {
                $rounded = $total;
            }
    
            $days[$currentDate->format('Y-m-d')] = $rounded;
            $currentDate->addDay();
        }
    
        return $days;
    }
    
    private function distributeIndividuallyPerDay($total, $startDate, $endDate)
    {
    $days = [];

    $start = \Carbon\Carbon::parse($startDate)->startOfDay();
    $end = \Carbon\Carbon::parse($endDate)->endOfDay();
    $diffDays = $start->diffInDays($end) + 1;

    if ($diffDays <= 0) return [];

    $step = $total / $diffDays;
    $currentDate = $start->copy();
    $sum = 0;

    for ($i = 0; $i < $diffDays; $i++) {
        $remainingDays = $diffDays - $i;
        $value = round(($total - $sum) / $remainingDays); // distribute remainder properly
        $days[$currentDate->format('Y-m-d')] = $value;
        $sum += $value;
        $currentDate->addDay();
    }

    return $days;
}

    public function getConvertion(Request $request)
    {
    $branch_id = $request->user()->branch_id;
    $date = $request->date; // format: Y-m-d

    $startOfMonth = Carbon::parse($date)->startOfMonth()->format('Y-m-d');
    $endOfMonth = Carbon::parse($date)->endOfMonth()->format('Y-m-d');

    // Total converted customers from start of month to selected date
    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_customer.branch_id', $branch_id)
        ->whereRaw('DATE(et_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $date])
        ->select(
            'et_customer.created_at as customer_created_at',
            'et_lead.created_at as lead_created_at'
        )
        ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    foreach ($allConverted as $row) {
        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');

        if ($customerDate === $date && $leadDate === $date) {
            $convertedToday++;
        } elseif (
            $customerDate >= $startOfMonth && $customerDate <= $date &&
            $leadDate >= $startOfMonth && $leadDate <= $date
        ) {
            $convertedMonth++;
        } elseif (
            $customerDate >= $startOfMonth && $customerDate <= $date &&
            ($leadDate < $startOfMonth || $leadDate > $date)
        ) {
            $convertedOldMonth++;
        }
    }

    // Unclassified = total - (today + month + old)
    $convertedUnclassified = $allConverted->count() - ($convertedToday + $convertedMonth + $convertedOldMonth);

    return response()->json([
        'status' => 200,
        'data' => [
            'converted_today' => $convertedToday,
            'converted_month' => $convertedMonth,
            'converted_old_month' => $convertedOldMonth,
            'converted_unclassified' => $convertedUnclassified,
            'converted_total' => $allConverted->count(),
            'converted_total_list' => $allConverted,
        ]
    ]);
}

    
    public function getIncentiveMetrics(Request $request)
    {
        $branchId = $request->branch_id ?? $request->user()->branch_id;
        $departmentId = $request->department_id;
        $role_id = $request->role_id;
     
        $year = $request->year;
    
        if (!empty($request->month)) {
            $request->month = is_numeric($request->month)
                ? (int) $request->month
                : (int) date('m', strtotime($request->month . ' 1'));
        }
        
        $month = $request->month;
        
        // Get the first and last date of the requested month
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    
        // Generate all dates in the month
        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }
    
        // Directly use startDate and endDate for formatting
        $startOfMonth = $startDate->format('Y-m-d');
        $endOfMonth = $endDate->format('Y-m-d');
        
        $prevMonth = Carbon::createFromDate($year, $month, 1)->subMonth()->month;
        $prevYear  = Carbon::createFromDate($year, $month, 1)->subMonth()->year;
        
        $current = Carbon::create($year, $month, 1);
        // 20 years ago from now
        $startDateold = $current->copy()->subYears(20)->startOfMonth();
        $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
        
        // $month=7;
        
        $staffList = StaffModel::join('et_sub_department', 'et_sub_department.sno', '=', 'et_staff.sub_department_id')
              ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->where('et_staff.branch_id', $branchId)
            ->where('et_staff.role_id', $role_id)
            ->where('et_staff.status', 0)
            ->select(
                'et_staff.sno as staff_id',
                'et_staff.staff_name',
                'et_staff.role_id',
                'et_staff.department_id',
                'et_staff.staff_image',
                'et_staff.nick_name',
                'et_staff.branch_id',
                'et_staff.avaiable_points',
                 'et_staff.per_hour_cost',
                'et_staff.basic_salary',
                'et_sub_department.sub_department_id',
                'et_sub_department.sub_department_name',
                'et_department.department_name'
            )
            ->get();
            $departmentIds = $staffList->pluck('department_id')->unique()->toArray();
            //  return  $departmentIds;
            $goalsetteam = GoalSetTeamModel::where('et_goal_set_team.department_id', $departmentIds)->where('et_goal_set_team.branch_id', $branchId)
          ->where('et_goal_set_team.team_goal_month', $request->month)
          ->where('et_goal_set_team.team_goal_year', $year)
          ->first();
        
            // Get goal records for the selected department and month
            $goalsetRecords = GoalSetStaffModel::where('et_goal_set_staff.department_id', $departmentIds)->where('et_goal_set_staff.branch_id', $branchId)
              ->where('et_goal_set_staff.goal_month', $request->month)
              ->whereMonth('et_goal_set_staff.goal_date', $request->month)
              ->whereYear('et_goal_set_staff.goal_date', $year)
              ->get();
            //   return  $goalsetRecords;
              
            $goalsetData = [];
            foreach ($goalsetRecords as $goal) {
              $goalsetData[$goal->staff_id] = $goal;
            }
    
             
        $result = [];
    
        foreach ($staffList as $staff) {
             
            $isProduction = $staff->role_id == 22;
            $isSalesEx = $staff->role_id == 11;
            $isTeamLead = $staff->role_id == 12;
            $isCollection = $staff->role_id == 14;
            $isCRE = $staff->role_id == 16;
            $isPC = $staff->role_id == 15;
            $current_date = date('Y-m-d'); // Define the current date
            
            $incentive = IncentiveModel::where('role_id', $staff->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
            // return $staff->role_id;
                 
            // if (!$incentive) {
            //     continue; // Skip if no incentive record for ro
            // }
           
           
            if ($isTeamLead) {
                // Step 1: Get all active executives under same branch and department
                $executives = StaffModel::where('branch_id', $staff->branch_id)
                    ->where('department_id', $staff->department_id)
                    ->where('role_id', 11)
                    ->where('status', 0)
                    ->get();
            
                // Step 2: Filter executive IDs who have goals (conversion > 0)
                $executiveIds = $executives->pluck('sno')->toArray();
            
                $executiveGoalSet = $goalsetRecords
                    ->whereIn('staff_id', $executiveIds)
                    ->where('conversion', '>', 0)
                    ->pluck('staff_id')
                    ->unique()
                    ->toArray();
                $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
                if (!$incentive) {
                    continue; // Skip if no incentive record for role
                }
            
                // Step 3: Re-filter only executives who have goal set
                $filteredExecutives = $executives->whereIn('sno', $executiveGoalSet);
            
                // Step 4: Calculate incentives only for valid executives
                $allExecutiveIncentives = [];
                foreach ($filteredExecutives as $executive) {
                    $allExecutiveIncentives['staff_' . $executive->sno] = $this->calculateIncentivesForStaff(
                        $executive,
                        $branchId,
                        $month,
                        $year,
                        $goalsetData
                    );
                }
        
                // Step 5: Run final status check
                $finalStatus = $this->getTeamIncentiveStatus($executiveGoalSet, $allExecutiveIncentives);
                $targets = ManageTargetModel::where('branch_target.branch_id', $branchId)
                    ->join('et_branch', 'branch_target.branch_id', '=', 'et_branch.sno')
                    ->whereMonth('branch_target.date', $month)
                    ->whereYear('branch_target.date', $request->year)
                    ->select('branch_target.*') // Ensure you're returning only target column
                    ->first();
                    
                    
                $preSaleActual = CustomerModel::whereIn('status', [0, 6]) 
                    ->where('branch_id', $branchId)
                    ->whereYear('created_at', $request->year)
                    ->whereMonth('created_at', $month)
                    ->count();
                    $individual10x = $targets && $targets->no_of_registrations <= $preSaleActual;
                    
                //   return $allExecutiveIncentives;
                    // Now prepare result for Team Lead
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
                
                        'incentives' => [
                            'tenx_award' => [
                                'target' => 'All Executives Achieved 10x',
                                'actual' => $individual10x ? 'Achieved' : 'Not Achieved',
                                'status' => $individual10x,
                                'reward' => $individual10x ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                            'eci' => [
                                'target' => 'All Executives Achieved ECI',
                                'actual' => $finalStatus['eci'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['eci'],
                                'reward' => $finalStatus['eci'] ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                            'bi' => [
                                'target' => 'All Executives Achieved BI',
                                'actual' => $finalStatus['bi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['bi'],
                                'reward' => $finalStatus['bi'] ? ($biReward ?? 0) : 0,
                            ],
                            'si' => [
                                'target' => 'All Executives Achieved SI',
                                'actual' => $finalStatus['si'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['si'],
                                'reward' => $finalStatus['si'] ? 3000 : 0,
                            ],
                            'pi' => [
                                'target' => 'All Executives Achieved PI',
                                'actual' => $finalStatus['pi'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['pi'],
                                'reward' => $finalStatus['pi'] ? ($piReward ?? 0) : 0,
                            ],
                            'sp' => [
                                'target' => 'All Executives Achieved SP',
                                'actual' => $finalStatus['sp'] ? 'Achieved' : 'Not Achieved',
                                'status' => $finalStatus['sp'],
                                'reward' => $finalStatus['sp'] ? ($spotTotalReward ?? 0) : 0,
                            ],
                            'li' => [
                                'target' => 'All Incentives Achieved by Team',
                                'actual' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? 'Achieved'
                                    : 'Not Achieved',
                                'status' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp']),
                                'reward' => ($finalStatus['tenx_award'] && $finalStatus['eci'] && $finalStatus['bi'] && $finalStatus['si'] && $finalStatus['sp'])
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ],
                    ];
            }
            
            if ($isSalesEx) {
                 
                  
                  //Sales Team 
                  //   return 'hi';
                  $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
            
                  $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->where('et_lead.branch_id', $branchId)
                    ->whereYear('et_lead.registered_date', $year)
                    ->whereMonth('et_lead.registered_date', $month)
                    ->whereNotIn('et_lead.status', [2, 6])
                    ->where('et_lead.spam_verified', 0)
                    ->where('et_lead.drop_verified', 0)
                    ->where('et_lead.internal_status', 0)
                    ->count();
                    //this month count 
                  $customerConvertCountthismonth = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                  ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status',[0,6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_customer.created_at', $year)
                    ->whereMonth('et_customer.created_at', $month)
                    ->count();
                    
                    $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->staff_id)
                    ->whereYear('et_customer.created_at', $prevYear)
                    ->whereMonth('et_customer.created_at', $prevMonth)
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
                    // $dropoutCustomers = DB::table('et_training')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 2)
                    //     ->pluck('customer_id')
                    //     ->toArray();
                       // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
                    $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->select('et_payment.customer_id')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->groupBy('et_payment.customer_id')
                        ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(total_amount)')
                        ->pluck('et_payment.customer_id')
                        ->toArray();
                    // return $fullPaidCustomerIds;
                    // 2. Customers who made a second payment this month
                    $secondPaymentCustomersmulti = DB::table('et_proposal_pay_slot')
                       ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers)
                        ->where('et_proposal_pay_slot.paid_status', 1)
                        ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
                        ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
                        ->pluck('et_payment.customer_id')
                        ->unique()
                        ->values() // this reindexes!
                        ->toArray();
                        //  return $secondPaymentCustomersmulti;
                    
                  
                    $secondPaymentCustomers =   array_values(array_unique(array_merge(
                            $secondPaymentCustomersmulti,
                            $fullPaidCustomerIds
                        )));
                    // second condition  
                    // $secondPaymentCustomers = DB::table('et_payment')
                    //     ->whereIn('customer_id', $prevMonthConvertedCustomers)
                    //     ->where('status', 1)
                    //     ->whereMonth('nextPayDate', $month)
                    //     ->whereYear('nextPayDate', $year)
                    //     ->pluck('customer_id')
                    //     ->unique()
                    //     ->values() // this reindexes!
                    //     ->toArray();
                        // return $secondPaymentCustomers;
                    // third condition  
                    $branch = BranchModel::where('sno', $branchId)
                      ->where('status', 0)
                      ->orderBy('sno', 'desc')
                      ->first();
                
                    //  $drop_ids = DB::table('et_drop_refund')
                    //       ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
                    //       ->where('et_drop_refund.bh_status', 1)
                    //       ->pluck('et_training.customer_id');
                          
                    $PaidUnderPayment = DB::table('et_proposal')
                          ->whereIn('et_proposal.customer_id', $prevMonthConvertedCustomers)
                          ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
                          ->join('et_proposal_pay_slot', 'et_proposal.sno', '=', 'et_proposal_pay_slot.proposal_sno')
                          ->leftJoin('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                          ->join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                          ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
                          ->select(
                              'et_customer.customer_id',
                              'et_payment.proposal_id',
                              'et_customer.sno as customer_sno',
                              'et_customer.cus_name',
                              'et_customer.cus_gender',
                              'et_customer.cus_pic',
                              'et_customer.cus_mobile',
                              'et_customer.cus_email_id',
                              'et_staff.staff_name',
                              'et_proposal_pay_slot.initialPayDate',
                              'et_proposal_pay_slot.paidAmount as total_paid_amount',
                             'et_proposal_pay_slot.balance_amount as total_balance_fee',
                             'et_proposal_pay_slot.total_amount as total_amount',
                              DB::raw('SUM(et_proposal_pay_slot.gst_amount) as total_gst_amount'),
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate'
                          )
                          ->where('et_payment.branch_id', $branchId)
                        //   ->whereNotIn('et_customer.sno', $drop_ids)
                          ->whereNotIn('et_proposal.status', [0,2])
                          ->where('et_proposal_pay_slot.balance_amount', '!=',0)
                          ->groupBy(
                              'et_customer.customer_id',
                              'et_customer.sno',
                               'et_payment.proposal_id',
                              'et_customer.cus_name',
                              'et_customer.cus_mobile',
                              'et_customer.cus_pic',
                              'et_customer.cus_gender',
                              'et_customer.cus_email_id',
                               'et_staff.staff_name',
                               'et_proposal_pay_slot.paidAmount',
                             'et_proposal_pay_slot.balance_amount',
                             'et_proposal_pay_slot.total_amount',
                              'et_payment.payment_mode',
                              'et_proposal_pay_slot.nextPayDate',
                              'et_proposal_pay_slot.initialPayDate'
                          )
                        //   ->orderByDesc('et_payment.sno')
                        ->orderBy('et_proposal_pay_slot.nextPayDate', 'asc')
                          ->get()
                          ->unique('customer_id'); // Keep only unique customer records;
                      //   return $PaidUnderPayment;
                      // Filter the results for customers with unpaid or insufficient amounts (below min_required)
                      $lowPaymentResult = $PaidUnderPayment->filter(function ($payment) use ($branch) {
                          return $payment->total_paid_amount < $branch->min_prd_cost;
                      });
                   
                    
                      // Group by customer_id
                      $finalResult = $lowPaymentResult->groupBy('customer_id')->map(function ($payments) use ($branch) {
                          // Filter payments where paidAmount is greater than 0
                          $filteredPayments = $payments->filter(function ($payment) {
                              return $payment->total_paid_amount > 0;
                          });
                    
                          // If no valid payments exist after filtering, exclude this customer
                          if ($filteredPayments->isEmpty()) {
                              return null;
                          }
                    
                          $payment = $payments->first();
                          // Return structured data for each customer
                          return [
                              'customer_name' => $payment->cus_name,
                              'customer_sno' => $payment->customer_sno,
                              'total_paid' => $payment->total_paid_amount,
                              'min_required' => $branch->min_prd_cost,
                              'status' => 'Pending',
                              'payments' => $filteredPayments->sortBy('nextPayDate')->map(function ($payment) {
                                  return [
                                      'course_name' => $payment->course_name,
                                      'cus_gender' => $payment->cus_gender,
                                      'cus_pic' => $payment->cus_pic,
                                      'staff_name' => $payment->staff_name,
                                      'batch_id' => $payment->batch_id,
                                      'training_id' => $payment->training_id,
                                      'payment_id' => $payment->payment_id,
                                      'cus_name' => $payment->cus_name,
                                      'cus_mobile' => $payment->cus_mobile,
                                      'amount' => $payment->total_amount,
                                      'paidAmount' => $payment->total_paid_amount,
                                      'balanceFee' => $payment->total_balance_fee,
                                      'gst_amount' => $payment->total_gst_amount,
                                      'nextPayDate' => $payment->nextPayDate,
                                      'initialPayDate' => $payment->initialPayDate,
                                      'payment_mode_label' => $payment->payment_mode_label,
                                  ];
                              })->values(), // Reset array keys
                          ];
                        })->filter();
                  
                        // Paginate the results
                        //   $paginatedResult = $finalResult->slice(($page - 1) * $perPage, $perPage);
                    
                        // Calculate the total number of pages
                        $totalItems = $finalResult->count();
                        
                        $lowMbcCustomerIds = $finalResult->pluck('customer_sno')->toArray();
                        // return $lowMbcCustomerIds;
                        $badCustomerIds = array_unique(array_merge(
                            // $dropoutCustomers,
                            $lowMbcCustomerIds,
                            array_diff($prevMonthConvertedCustomers, $secondPaymentCustomers)
                        ));
                        // return count($badCustomerIds);
                        $customerConvertCount = max(0, $customerConvertCountthismonth - count($badCustomerIds));
                    // return $customerConvertCount;
                  $monthcall_out = DB::table('et_call_tracker')
                    ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                    ->whereYear('call_start_date', $year)
                    ->whereMonth('call_start_date', $month)
                    ->where('et_call_tracker.branch_id', $branchId)
                    ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                    ->first();
                  $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
            
            
                  // customer ratio
                  $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
                  $convertion_rate = number_format($convertion_rate, 2);
            
                  //acr
                  $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
                  $averager_convertion_rate = number_format($averager_convertion_rate, 2);
            
                    
               
                    $luxury = json_decode($incentive->luxury_incentive, true);
                    $pi_slabs = json_decode($incentive->pi_slab_json, true);
            
                  $currentMonthCustomerCount = 0;
                  $total_business_amount     = 0;
                  $total_payment             = 0;
                  $total_paid_payment        = 0;
                  $averageBusinessValue      = 0;
                  $averageCollectionValue    = 0;
                  $crashCount = 0;
                  $professionCount = 0;
                  $tesboCount = 0;
                  $courseTypeTotal = 0;
                  $eciCustomerConvertCount = 0;
                  $eciActualPercentage = 0;
                  $eciTargetPercentage = $incentive->eci_count ?? 0;
                  $eciStatus = false;
                
                   $targetConversion = $goalsetData[$staff->staff_id]->conversion ?? 0;
                    $targetABV             = $goalsetData[$staff->staff_id]->ABV ?? 0;
                    $targetACV             = $goalsetData[$staff->staff_id]->ACV ?? 0;
                    $crashTarget =0;
                    $professionTarget =0;
                    $tesboTarget =0;
                    $crashPercent =0;
                    $professionPercent=0;
                    $tesboPercent=0;
                    $piPercentage = 0;
                    $originalAmount = 0;
                    $piReward = 0;
                    $matchedSlab = null;
                    $slabPercentage = 0; 
                   // Total Professional and Crash courses
                    // $groupedData = DB::table('et_training')
                    //     ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                    //     ->select(
                    //         'et_course.course_type_id',
                    //         DB::raw('COUNT(DISTINCT et_training.payment_id) AS total_trainings')
                    //     )
                    //     ->where('et_training.branch_id', $branchId)
                    //     ->whereMonth('et_training.created_at', $month)
                    //     ->whereYear('et_training.created_at', $year)
                    //     ->whereIn('et_course.course_type_id', [3, 4])
                    //     ->where('et_training.tesbo_check', '!=', 2)
                    //     ->where('et_training.status', 0)
                    //     ->where('et_training.post_sale_check', '!=', 1)
                    //     ->groupBy('et_course.course_type_id')
                    //     ->get();
                    
                    // // Get valid TESBO count separately
                    // $teshobo_coures_total = DB::table('et_training')
                    //     ->where('branch_id', $branchId)
                    //     ->whereMonth('created_at', $month)
                    //     ->whereYear('created_at', $year)
                    //     ->where('tesbo_check', 2)
                    //     ->where('et_training.status', 0)
                    //     ->where('post_sale_check', '!=', 1)
                    //     ->distinct('payment_id')
                    //     ->count('payment_id');
                    
                    // Prepare tree output
                    $crash_coures_total = 0;
                    $professinal_coures_total = 0;
                    $teshobo_coures_total = 0;
                    
                    // foreach ($groupedData as $row) {
                    //     if ($row->course_type_id == 3) {
                    //         $professinal_coures_total = (int) $row->total_trainings;
                    //     } elseif ($row->course_type_id == 4) {
                    //         $crash_coures_total = (int) $row->total_trainings;
                    //     }
                    // }
                    
                     // return $crash_coures_total;
                     $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
                 
                    if ($customerConvertCount > 0) {
                    $currentMonthCustomer = CustomerModel::select('et_customer.sno','et_customer.proposal_ids')
                    ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                      ->where('et_customer.branch_id', $branchId)
                      ->whereIn('et_customer.status',[0,6])
                      ->where('et_lead.created_by', $staff->staff_id)
                      ->whereYear('et_customer.created_at', $year)
                      ->whereMonth('et_customer.created_at', $month)
                      ->get();
                      
                      
                        // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                     // ECI early conversion before 15th
                     $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                        ->where('et_customer.branch_id', $branchId)
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->whereYear('et_customer.created_at', $year)
                        ->whereMonth('et_customer.created_at', $month)
                        ->whereDay('et_customer.created_at', '<=', 15)
                        ->count();
                        //   return $currentMonthCustomer;
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            // foreach ($currentMonthCustomer as $customer) {
                        
                            //     // First: check if this customer has TESBO training
                            //     $hasTesbo = DB::table('et_training')
                            //         ->where('customer_id', $customer->sno)
                            //         ->where('branch_id', $branchId)
                            //         ->whereMonth('created_at', $month)
                            //         ->whereYear('created_at', $year)
                            //         ->where('tesbo_check', 2)
                            //         ->where('post_sale_check', '!=', 1)
                            //         ->exists();
                        
                            //     if ($hasTesbo) {
                            //         $tesboCount++;
                            //         continue; // skip crash/professional check if TESBO already counted
                            //     }
                        
                            //     // Then: check if customer has valid Professional or Crash training (not tesbo)
                            //     $nonTesboTrainings = DB::table('et_training')
                            //         ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                            //         ->where('et_training.customer_id', $customer->sno)
                            //         ->where('et_training.branch_id', $branchId)
                            //         ->whereMonth('et_training.created_at', $month)
                            //         ->whereYear('et_training.created_at', $year)
                            //         ->where('et_training.post_sale_check', '!=', 1)
                            //         ->where('et_training.tesbo_check', '!=', 2)
                            //         ->whereIn('et_course.course_type_id', [3, 4])
                            //         ->select('et_course.course_type_id')
                            //         ->get();
                        
                            //     $hasCrash = false;
                            //     $hasProfession = false;
                        
                            //     foreach ($nonTesboTrainings as $training) {
                            //         if ($training->course_type_id == 3) {
                            //             $hasProfession = true;
                            //         } elseif ($training->course_type_id == 4) {
                            //             $hasCrash = true;
                            //         }
                            //     }
                        
                            //     if ($hasCrash) $crashCount++;
                            //     if ($hasProfession) $professionCount++;
                            // }
                        
                            // $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                            $courseTypeTotal = 0;
                        }
                        // return $customerConvertCount;
                        // spot incentive 
                        $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $customerConvertCountthismonth) * 100 : 0;
                        $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $customerConvertCountthismonth) * 100 : 0;
                        $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $customerConvertCountthismonth) * 100 : 0;
                        
                        // $crashPercent = $crashCount;
                        // $professionPercent = $professionCount;
                        // $tesboPercent = $tesboCount;
                        
                        $crashTarget = $incentive->si_crash_course ?? 0;
                        $professionTarget = $incentive->si_profession_course ?? 0;
                        $tesboTarget = $incentive->si_tesbo_course ?? 0;
                        
                        // only condition: Crash must be ≤ targe
                           
                          
                          if ( $customerConvertCountthismonth  >= 20){
                              $siStatus = true;
                            // return $customerConvertCountthismonth;
                            if ($incentive->si_crash_course > 0) {
                                
                                // $siStatus = $siStatus && ($crashPercent >= $crashTarget);
                                $siStatus = $siStatus && (($crashPercent >= $crashTarget) || ($crashPercent <= $crashTarget) );
                            }
                            
                            if ($incentive->si_profession_course > 0) {
                                
                                $siStatus = $siStatus && ($professionPercent >= $professionTarget);
                            }
                            
                            if ($incentive->si_tesbo_course > 0) {
                                // return $siStatus;
                                $siStatus = $siStatus && ($tesboPercent <= $tesboTarget);
                            }
                          }else{
                              $siStatus = false;
                          }
                        //  return $currentMonthCustomer;
                        // return 'not coming good';
                        if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                            foreach ($currentMonthCustomer as $customer) {
                                // $trainings = DB::table('et_training')
                                //     ->where('customer_id', $customer->sno)
                                //      ->where('post_sale_check', 0)
                                //     ->get();
                                 $trainings = DB::table('et_proposal as t1')
                                        ->join(DB::raw('(
                                            SELECT MIN(sno) as min_sno
                                            FROM et_proposal
                                            WHERE post_sale_check = 0
                                            GROUP BY customer_id
                                        ) as t2'), 't1.sno', '=', 't2.min_sno')
                                        ->where('t1.customer_id', $customer->sno)
                                        ->select('t1.sno', 't1.customer_id',    't1.total_amount')
                                        ->get();
                            
                                    foreach ($trainings as $training) {
                                         // Determine course_id based on tesbo_check
                                        $course_id = null;
                                
                                        // if ($training->tesbo_check > 0) {
                                        //     $payment = PaymentModel::where('payment_id',$training->payment_id)->first();
                                        //     if ($payment && $payment->course_id) {
                                        //         $course_id = $payment->course_id;
                                        //     }
                                        // } else {
                                        //     $course_id = $training->course_id;
                                        // }
                                
                                        if (!$course_id) continue; // Skip if no course_id
                                
                                        $course = ManageCoursesModel::where('sno', $course_id)
                                            ->whereIn('course_type_id', [2, 3])
                                            ->first();
                                
                                        if (!$course) continue;
                                    $basePrice = $course->course_min_price;
                                    $soldPrice = $training->overall_fees;
                                    $profitAmount = $soldPrice - $basePrice;
                                    
                                    // if ($profitAmount > 0) {
                                        
                                       $originalAmount += $profitAmount; 
        
                                       $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                                      // return $pi_slabs;
                                        // Match against PI slabs
                                        foreach ($pi_slabs as $slab) {
                                            if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                                $slabPercentage = $slab['percentage'];
                                                $rewardFromThis = ($originalAmount * $slabPercentage) / 100;
                        
                                                $piRewards = $rewardFromThis > 0 ? $rewardFromThis : 0;
                                                $piPercentage = $profitPercent;
                                                $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                                break; // first matching slab
                                            }
                                        }
                                    // }
                                }
                            }
                            
                            
                        }
                         $piReward0 = $slabPercentage >0 ? ($originalAmount * $slabPercentage) / 100 : 0;
                         $piReward  = $piReward0 > 0 ?$piReward0 :0;
                        //  return $piReward;
                         //   return $rewardFromThisd;
                        if ($currentMonthCustomer->isNotEmpty()) {
                          foreach ($currentMonthCustomer as $customer) {
                
                            // $payment = DB::table('et_proposal')->select('et_proposal.sno', 'et_proposal.customer_id')
                            //   ->where('et_proposal.customer_id', $customer->sno)
                            // //   ->where('et_training.tesbo_check', 0)
                            //   ->sum('et_proposal.total_amount');
                
                            // $total_payment += $payment;
                            $proposal_ids=json_decode($customer->proposal_ids);
                            $total_payment_grant = DB::table('et_proposal')
                            ->whereIn('sno', $proposal_ids)
                            ->where('status', 0) 
                            ->sum('grant_total_amount');
                       
                                $total_payment += $total_payment_grant;
                
                
                            // $latestTraining = DB::table('et_proposal')
                            //   ->where('customer_id', $customer->sno)
                            // //   ->where('tesbo_check', 2)
                            //   ->orderByDesc('sno')
                            //   ->first();
                
                            // if ($latestTraining) {
                            //   $total_payment += $latestTraining->total_amount;
                            // }
                            
                            
                            $total_paid_payment_slot = DB::table('et_proposal_pay_slot')
                                          ->whereIn('et_proposal_pay_slot.proposal_sno', $proposal_ids)
                                          ->where('status', 0)
                                          ->sum('paidAmount');
                
                            // $paid_payment = DB::table('et_proposal')->select( 'et_proposal.sno', 'et_proposal.customer_id')
                            // ->join('et_proposal_pay_slot','et_proposal.sno','=','et_proposal_pay_slot.proposal_sno')
                            //   ->where('et_proposal.customer_id', $customer->sno)
                            //   ->sum('et_proposal_pay_slot.paidAmount');
                
                            $total_paid_payment += $total_paid_payment_slot;
                            
                             
                            
                          }
                                
                        }
                        
                        $gst_percent = 18;
             
                        $base_amount_paid = $total_paid_payment / (1 + ($gst_percent / 100));
                        
                        $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : 0;
                        $averageCollectionValue = $customerConvertCount > 0 ? $base_amount_paid / $customerConvertCount : 0;
                        // $totalAllPayment +=$total_payment;
                        // $totalAllPaidPayment +=$base_amount_paid;
                         // ECI Logic
                        $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                        $eciActualPercentage = number_format($eciActualPercentage, 2);
                        $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
            
                        // average 
                        // $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                        // $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
                
                        // $totalAllPayment += $total_payment;
                        // $totalAllPaidPayment += $total_paid_payment;
                    }
                  
                    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                        ->whereIn('et_customer.status', [0, 6])
                        ->where('et_customer.branch_id', $branchId)
                        ->where('et_lead.created_by', $staff->staff_id)
                        ->whereRaw('DATE(et_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                        ->select(
                            'et_customer.created_at as customer_created_at',
                            'et_lead.created_at as lead_created_at',
                            'et_lead.lead_mobile as lead_mobile'
                        )
                        ->get();
                    
                   
                    foreach ($allConverted as $row) {
                      
                      $mobile = $row->lead_mobile;
                        // Get the latest call
                         $lastCall = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->first();
                    
                            
                        $totalCallCount = DB::table('et_call_tracker')->select('sno')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                            ->orderByDesc('call_start_date')
                            ->count();
                        // Attach values to row
                        $row->call_created_at = $lastCall->call_start_date ?? null;
                        $row->customer_phone_no = $lastCall->customer_phone_no ?? null;
                        $row->call_count = $totalCallCount;
                    }
        
                    
                        
                        // return $allConverted;
                        
                    $convertedToday = 0;
                    $convertedMonth = 0;
                    $convertedOldMonth = 0;
                
                    foreach ($allConverted as $row) {
                         $mobile = $row->lead_mobile;
                          $totalCalldata = DB::table('et_call_tracker')
                            ->where('branch_id', $branchId)
                            ->where('branch_staff_id', $staff->staff_id)
                            ->where('customer_phone_no', 'like', "%{$mobile}")
                             ->select(
                                'et_call_tracker.call_start_date'
                            )
                            ->get();
                            
                        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                        $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
                        $callDate = Carbon::parse($row->call_created_at)->format('Y-m-d');
                        $call_count = $row->call_count;
                
                        if ($customerDate ===  $leadDate && $call_count ===  1) {
                            $convertedToday++;
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            $leadDate >= $startOfMonth && $leadDate <= $dates &&
                            $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                                $callDate = Carbon::parse($call->call_start_date);
                                return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
                            })
                            
                        ) {
                            $convertedMonth++;
                        } elseif (
                            $customerDate >= $startOfMonth && $customerDate <= $dates &&
                            ($leadDate < $startOfMonth || $leadDate > $dates)
                        ) {
                            $convertedOldMonth++;
                        }
                    }
                    // return $convertedToday;
                    $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                    $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                    // Old month = always 0
                    $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
                  
                    // 10x award calculation       
                    $actualConversion      = $customerConvertCount;
                    $actualABV             = $averageBusinessValue ?? 0;
                    $actualACV             = $averageCollectionValue ?? 0;
                   
                    //   $tenxStatus = (
                    //         $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    //         $actualConversion >= $targetConversion &&
                    //         $actualABV >= $targetABV &&
                    //         $actualACV >= $targetACV
                    //     );
                     $tenxStatus = (
                        $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                        $actualConversion >= $targetConversion 
                    );
                   // bi award calculation  
                    $biPerConversion = $incentive->bi_amount ?? 0;
                    $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                    
                    $biReward = $biAchievedCount * $biPerConversion;
                    $biStatus = $biAchievedCount > 0;
                    // return $piReward;
                    // return $staff->staff_id;
                    $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           'tenx_award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetConversion . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetABV . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . $targetACV . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $customerConvertCountthismonth . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary" 
                                                      >
                                                    ' . $actualConversion . '
                                             </span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . round($actualABV) . '</span> 
                                             <span class="fw-bold fs-2 badge bg-label-secondary">' . round($actualACV) . '</span>
                                             <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualDetailsModal(' . $staff->staff_id . ')" >Details</span>
                                             <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                                 <i class="mdi mdi-help-circle text-dark"></i>
                                             </label>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            'eci' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $eciTargetPercentage . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($eciActualPercentage, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $eciStatus,
                                'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                            ],
                        
                            'bi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($targetConversion . ' - ' . $actualConversion . ' = (' . $biAchievedCount . ')') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($biAchievedCount . ' × ' . $biPerConversion) . 
                                            '</span>',
                                'status' => $tenxStatus && $biStatus,
                                'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                            ],
                        
                            'si' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            "{$crashTarget}:{$professionTarget}:{$tesboTarget}" . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            number_format($crashPercent, 1) . ' : ' . 
                                            number_format($professionPercent, 1) . ' : ' . 
                                            number_format($tesboPercent, 1) . ' = ' . 
                                            number_format($crashPercent + $professionPercent + $tesboPercent) . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openCourseDetailsModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $siStatus,
                                'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                            ],
                        
                           'pi' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) . '%' : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . '% — ₹' . number_format($originalAmount) . 
                                            '</span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCalculationModal(' . $staff->staff_id . ')" >Details</span>',
                                'status' => $tenxStatus && $piReward > 0,
                                'reward' => ($tenxStatus && $piReward > 0)
                                    ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                    : 0,
                            ],
                        
                           'sp' => [
                                'target' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedOldMonth . '
                                            </td>
                                        </tr>
                                    </table>
                                ',
                            
                                'actual' => '
                                    <table class="table table-sm mb-0" style="border-collapse: collapse; background: transparent !important;">
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On day</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">On month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</span>
                                            </td>
                                        </tr>
                                        <tr style="border: none !important;">
                                            <td class="text-start" style="border: none !important; background: transparent !important;"><span class="badge bg-label-secondary fw-bold fs-3">Old Month</span></td>
                                            <td class="text-start text-black" style="border: none !important; background: transparent !important;">=</td>
                                            <td style="border: none !important; background: transparent !important;">
                                                <span class="badge bg-label-secondary fw-bold fs-3">₹0</span></span> </span><span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openManageCallModal(' . $staff->staff_id . ')" >Details</span>
                                            </td>
                                        </tr>
                                    </table>
                                ',
                                'status' => $tenxStatus && $spotTotalReward > 0,
                                'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
                            ],
        
                        
                           'li' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">All Incentives Achieved </span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            (($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward) 
                                                ? 'Achieved' 
                                                : 'Not Achieved') . 
                                            '</span>',
                                'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward),
                                'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus && $piReward)
                                    ? ($luxury['reward'] ?? 0)
                                    : 0,
                            ]
                        ]
        
                    ];
            
                } 
           
            
            if ($isCollection) {
                
                 $refferal_count = DB::table('et_referral_persons')
                      ->where('branch_id', $branchId)
                      ->where('referral_id', $staff->staff_id)
                      ->where('status', 0)
                      ->where('referral_type', 2)
                      ->whereYear('created_at', $year)
                      ->whereMonth('created_at', $month)
                      ->count();
                $dropoutCustomers = DB::table('et_training')
                        ->where('status', 2)
                        ->pluck('customer_id')
                        ->toArray();
                       
                $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_customer.sno', $dropoutCustomers) 
                    ->whereBetween('et_customer.created_at', [$startDateold, $endDateold])
                    // ->count();
                    ->pluck('et_customer.sno')
                    ->toArray();
                    // return $prevMonthConvertedCustomers;
                    
                    // first condition
               
            
                // here $secondPaymentCustomers  we need colclude the dat get $hacAmount
                  $hacAmount = DB::table('et_payment')
                        ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
                        ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) // ✅ Filter second payment customers
                        ->where('et_payment.status', 1) // paid amoun
                        ->whereYear('et_payment.initialPayDate', $year)
                        ->whereMonth('et_payment.initialPayDate', $month)
                        ->where('et_payment.branch_id', $branchId)
                        ->sum('et_payment.paidAmount');
                        // return $hacAmount;
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    //  return $ten_x;
                    $isHacCostingRequired = $ten_x['hac_10x'] == "1";
                    $isoutstandingRequired        = $ten_x['no_of_outstanding_10x'] == "1";
                    $isPostsaleRequired        = $ten_x['no_of_post_sale_10x'] == "1";
                   
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isHacCostingRequired) {
                        $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                        $actaulTenx  = $hacAmount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isoutstandingRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } 
                    
                        $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulREI  = $refferal_count ?? 0;
                        $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                        
                         $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                         
                        $EIaward = 0;
                        $EIStatus = false;
                        $targetEI = 0;
                        $actaulEI = 0;
                        
                        if ($isHacCostingRequired) {
                            $targetTenx  = optional($goalsetteam)->hac_over_all ?? 0;
                            $actaulTenx  = $hacAmount ?? 0;
                            $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false;
                        
                            // Only if HAC 10X achieved, calculate EI
                            if ($tenxStatus && $incentive->excess_incentive > 0) {
                                $excessAmount = $actaulTenx - $targetTenx;
                        
                                if ($excessAmount > 0) {
                                    $targetEI = $incentive->excess_incentive . '%'; // just for display
                                    $actaulEI = $excessAmount * ($incentive->excess_incentive / 100);
                                    $EIaward = $actaulEI;
                                    $EIStatus = true;
                                }
                            }
                        }
                        
                $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulTenx . 
                                            '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualCollectionModal(' . $staff->staff_id . ')" >Details</span>', 
                                             
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => ($tenxStatus && $incentive->tenx_warrior) ?  : 0,
                            ],
                        
                            
                            'EI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetEI . '</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info">' . number_format($actaulEI, 2) . '</span>',
                                'status' => $EIStatus,
                                'reward' => number_format($EIaward, 2),
                            ],
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isCRE) {
                  
                  $refferal_count = DB::table('et_referral_persons')
                      ->where('branch_id', $branchId)
                      ->where('referral_id', $staff->staff_id)
                      ->where('status', 0)
                      ->where('referral_type', 2)
                      ->whereYear('created_at', $year)
                      ->whereMonth('created_at', $month)
                      ->count();
            
                   
                    
                     $review_count = DB::table('et_review')
                        ->where('branch_id', $branchId)
                        ->where('created_by', $staff->staff_id)
                        ->where('status', 0)
                        ->whereYear('created_at', $year)
                        ->whereMonth('created_at', $month)
                        ->count();
                        
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                     //   return $ten_x;
                    $isNoOfReviewsRequired = $ten_x['no_of_reviews_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                   
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isNoOfReviewsRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->no_of_reviews ?? 0;
                        $actaulTenx  = $review_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }  
                        
                        $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulREI  = $refferal_count ?? 0;
                        $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                        
                        $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                        
                $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulTenx . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior . '%' .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '%' . '</span> <span class="fw-bold fs-2 badge bg-label-secondary badge-hover-clickable" style="cursor:pointer" onclick="openActualECIDetailsModal(' . $staff->staff_id . ')" >Details</span> <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => ($tenxStatus && $incentive->tenx_warrior) ?  : 0,
                            ],
                        
                            
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
                        
            }
            
            if ($isProduction) {
                
             
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
            
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    $isProductionCostingRequired = $ten_x['production_costing_10x'] == "1";
                    $isStudentMinRequired        = $ten_x['min_no_of_students_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    } elseif ($isStudentMinRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->student_count ?? 0;
                        $actaulTenx  = $actual_student_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    } elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                   //   return $pdiStatus;
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'PDI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . 
                                            ($matchedSlab ? $matchedSlab . ' = ' . round($slabPercentage, 2) : 'No Matching Slab') . 
                                            '</span>',
                            
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary me-2">' . 
                                            round($piPercentage, 2) . 
                                            '</span>',
                            
                                'status' =>  $pdiStatus,
                                'reward' => $tenxStatus && $pdiReward
                                    ? (($pdiReward >= 0 ? '+' : '-') . round(abs($pdiReward)))
                                    : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
            
            if ($isPC) {
                
                $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
                $std_count = TrainingModel::where('et_training.status', 0)
                    ->where('et_batch.status', 0)
                    ->leftJoin('et_batch', 'et_training.batch_id', '=', 'et_batch.sno')
                    ->where('et_training.staff_id', $staff->staff_id)
                    ->where('et_batch.start_date', '<=', $current_date)
                    ->where('et_batch.end_date', '>=', $current_date)
                    ->count();

     
                  // Initialize variables
                  $total_batch = $total_student = $total_free_batch = $total_staff = 0;
                  $overall_earned = $overall_earned_per = $success_staff_count = 0;
                  $slotType = $staff;
            
                  $slotType->earned_amount = $slotType->batch_count = $slotType->student_count = 0;
                  $slotType->present_count = $slotType->course_count = 0;
                  $slotType->slotDetails = [];
                  $slotType->avg_amnt = $slotType->salary = 0;
            
                  // Fetch batch IDs associated with staff
                  $batchIds = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->distinct()
                    ->pluck('batch_id')
                    ->toArray();
            
                  $slotType->batch_ids = (array) $batchIds; // Ensure it's an array
               
                  foreach ($slotType->batch_ids as $batchId) {
                    // Fetch slot details for the staff's batches
                    $slotDetails = BatchModel::select('et_batch.slot_id', 'et_slot.start_time', 'et_slot.end_time', 'et_slot.slot_name')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->whereIn('et_batch.sno', TrainingModel::where('branch_id', $branchId)
                        ->where('staff_id', $slotType->staff_id)
                        ->where(function ($query) use ($month, $year) {
                          $query->whereMonth('start_date', '<=', $month)
                            ->whereYear('start_date', '<=', $year)
                            ->whereMonth('end_date', '>=', $month)
                            ->whereYear('end_date', '>=', $year);
                        })
                        ->pluck('batch_id'))
                      ->where('et_batch.status', 0)
                      ->get();
            
                    $slotType->slotDetails = array_merge($slotType->slotDetails, $slotDetails->toArray());
            
                    // Fetch batch details
                    $batch = BatchModel::select('et_batch.*', 'et_slot.start_time', 'et_slot.end_time')
                      ->leftJoin('et_slot', 'et_slot.sno', '=', 'et_batch.slot_id')
                      ->find($batchId);
            
                    if ($batch) {
                      $startTime = Carbon::parse($batch->start_time);
                      $endTime = Carbon::parse($batch->end_time);
                      $batchDurationInHours = $startTime->diffInMinutes($endTime) / 60;
            
                      // Fetch attendance records
                      $attendanceRecords = AttendanceModel::select('per_hr_cost')
                        ->where([
                          ['batch_id', $batch->sno],
                          ['staff_id', $slotType->staff_id],
                          ['attendance', 'P']
                        ])
                        ->whereMonth('att_date', $month)
                        ->whereYear('att_date', $year)
                        ->get();
            
                      foreach ($attendanceRecords as $attendance) {
                        $slotType->earned_amount += ($attendance->per_hr_cost * $batchDurationInHours);
                      }
                    }
                  }
            
                  // Student count
                  $slotType->student_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('customer_id')
                    ->count('customer_id');
            
                  // Course count
                  $slotType->course_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('course_id')
                    ->count('course_id');
            
                  // Batch count
                  $slotType->batch_count = TrainingModel::where('branch_id', $branchId)
                    ->where('staff_id', $slotType->staff_id)
                    ->where(function ($query) use ($month, $year) {
                      $query->whereMonth('start_date', '<=', $month)
                        ->whereYear('start_date', '<=', $year)
                        ->whereMonth('end_date', '>=', $month)
                        ->whereYear('end_date', '>=', $year);
                    })
                    ->distinct('batch_id')
                    ->count('batch_id');
            
                  // Salary calculation
                  $slotType->salary = isset($slotType->basic_salary) ? ($slotType->basic_salary * 10) : 0;
                  // Average earned percentage calculation
                  $slotType->avg_amnt = ($slotType->salary > 0) ? (($slotType->earned_amount / $slotType->salary) * 100) : 0;
                  // Calculate free batch count
                  $total_free_batch = max(0, 8 - $slotType->batch_count);
                  $overall_earned += $slotType->earned_amount;
                  $overall_earned_per += $slotType->avg_amnt;
                  // Count success staff
                  if ($slotType->salary < $slotType->earned_amount) {
                    $success_staff_count++;
                  }
                  $staffproduction = $slotType;
                  $costing_amount = $staffproduction->earned_amount ?? 0;
                  
                    $slabs = json_decode($incentive->pdi_slab_json ?? '[]', true);
                    $studentCount = $staffproduction->student_count ?? 0;
                    
                    $matchedSlab = null;
                    $slabPercentage = 0;
                    $pdiReward = 0;
                    
                    foreach ($slabs as $slab) {
                        if ($studentCount >= $slab['min'] && $studentCount <= $slab['max']) {
                            $matchedSlab = $slab['min'] . '-' . $slab['max'];
                            $slabPercentage = $slab['percentage'];
                            break;
                        }
                    }
                    
                    $productionAmount = $staffproduction->total_amount ?? 0;
                    $piPercentage = $slabPercentage;
                    // $originalAmount = ($productionAmount * $piPercentage) / 100;
                    
                   
                  
                  
                  $refferal_count = DB::table('et_referral_persons')
                    ->where('branch_id', $branchId)
                    ->where('referral_id', $staff->staff_id)
                    ->where('status', 0)
                    ->where('referral_type', 2)
                    ->whereYear('created_at', $year)
                    ->whereMonth('created_at', $month)
                    ->count();
        
                    $basic_pay = $staff->basic_salary > 0 ? ($staff->basic_salary * 10) : 0;
                    $costing_amount_asign = $goalsetData[$staff->staff_id]->production_costing ?? 0;
                    $costing_amount2 = ($basic_pay > 0 && $costing_amount_asign > 0) ? ($costing_amount / $basic_pay) * $costing_amount_asign : 0;
                    $costing_amount = $costing_amount2;
                    
                    $ten_x = json_decode(optional($goalsetteam)->ten_x ?? '{}', true);
                    // return $ten_x;
                    $isProductionCostingRequired = $ten_x['productions_10x'] == "1";
                    $isReferenceSalesRequired    = $ten_x['reference_sales_10x'] == "1";
                    
                    $tenxStatus = false;
                    $targetTenx = 0;
                    $actaulTenx = 0;
                    
                    if ($isProductionCostingRequired) {
                        $targetTenx  = $costing_amount_asign ?? 0;
                        $actaulTenx  = $costing_amount ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx : false ;
                    }  elseif ($isReferenceSalesRequired) {
                        $targetTenx  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                        $actaulTenx  = $refferal_count ?? 0;
                        $tenxStatus = $targetTenx != 0 ? $actaulTenx >= $targetTenx :false;
                    }
                    
                    // pdi
                    $pdiReward = $piPercentage;
                    $pdiStatus =  $tenxStatus && $pdiReward > 0;
                    
                    $targetREI  = $goalsetData[$staff->staff_id]->reference_sales ?? 0;
                    $actaulREI  = $refferal_count ?? 0;
                    $REIStatus = $targetTenx != 0 ? $actaulREI >= $targetREI :false;
                    
                    $REIaward  = $actaulREI * $incentive->reference_incentive ??0;
                   //   return $pdiStatus;
                   $result[] = [
                        'staff_id' => $staff->staff_id,
                        'staff_name' => $staff->staff_name,
                        'staff_image' => $staff->staff_image,
                        'role_id' => $staff->role_id,
                        'nick_name' => $staff->nick_name,
                        'sub_department_name' => $staff->sub_department_name,
                        'department_name' => $staff->department_name,
            
                        'incentives' => [
                           '10X Award' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetTenx . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' .  round($actaulTenx)  . '
                                             </span>',
                                
                                'status' => $tenxStatus,
                                'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                            ],
                        
                            '10X Warrior' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $incentive->tenx_warrior .'</span>',
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . round($incentive->tenx_warrior, 1) . '</span>',
                                'status' => $tenxStatus && $incentive->tenx_warrior,
                                'reward' => (0) ?  : 0,
                            ],
                        
                            
                            'REI' => [
                                'target' => '<span class="fw-bold fs-2 badge bg-label-secondary">' . $targetREI . '</span>',
                                
                                'actual' => '<span class="fw-bold fs-2 badge bg-label-info" 
                                                      >
                                                    ' . $actaulREI . '
                                             </span>',
                                
                                'status' => $REIStatus,
                                'reward' => $REIStatus ? ($REIaward) : 0,
                            ],
        
                        
                        ]
        
                    ];
            }
        }
            return response()->json([
                'status' => 200,
                'data' => $result
            ]);
    }
    private function getTeamIncentiveStatus(array $executiveIds, array $allExecutiveIncentives): array
    {
        $finalStatus = [
            'tenx_award' => true,
            'eci' => true,
            'bi' => true,
            'si' => true,
            'pi' => true,
            'sp' => true,
        ];
    
        foreach ($executiveIds as $execId) {
            $key = 'staff_' . $execId;
    
            if (!isset($allExecutiveIncentives[$key])) {
                // If data missing, fail all
                foreach ($finalStatus as $type => $_) {
                    $finalStatus[$type] = false;
                }
                continue;
            }
    
            $incentiveSet = $allExecutiveIncentives[$key]['incentives'] ?? [];
    
            foreach ($finalStatus as $type => $_) {
                // If not true, then mark team as not fully achieved
                if (!isset($incentiveSet[$type]['status']) || $incentiveSet[$type]['status'] !== true) {
                    $finalStatus[$type] = false;
                }
            }
        }
    
        return $finalStatus;
    }

    private function calculateIncentivesForStaff($staff, $branchId , $month, $year, $goalsetData)
    {
        $finalStatus = [
            'tenx_award' => true,
            'eci' => true,
            'bi' => true,
            'si' => true,
            'pi' => true,
            'sp' => true,
        ];
      
          // Get the first and last date of the requested month
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();
    
        // Generate all dates in the month
        $dates = [];
        $currentDate = $startDate->copy();
        while ($currentDate->lte($endDate)) {
            $dates[] = $currentDate->toDateString();
            $currentDate->addDay();
        }
    
        // Directly use startDate and endDate for formatting
        $startOfMonth = $startDate->format('Y-m-d');
        $endOfMonth = $endDate->format('Y-m-d');
        // $finalStatus  = [];
        
        // foreach ($staff as $staff) {
        
               $current_date = date('Y-m-d'); // Define the current date
              //Sales Team 
              
              $allLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.branch_id', $branchId)
                ->whereNotIn('et_lead.status', [2, 6])
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.drop_verified', 0)
                ->where('et_lead.internal_status', 0)
                ->count();
        
              $monthLeadCount = DB::table('et_lead')->select('et_lead.sno')
                ->where('et_lead.created_by', $staff->sno)
                ->where('et_lead.branch_id', $branchId)
                ->whereYear('et_lead.registered_date', $year)
                ->whereMonth('et_lead.registered_date', $month)
                ->whereNotIn('et_lead.status', [2, 6])
                ->where('et_lead.spam_verified', 0)
                ->where('et_lead.drop_verified', 0)
                ->where('et_lead.internal_status', 0)
                ->count();
                
              $customerConvertCount = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
              ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                ->whereIn('et_customer.status',[0,6])
                ->where('et_customer.branch_id', $branchId)
                ->where('et_lead.created_by', $staff->sno)
                ->whereYear('et_customer.created_at', $year)
                ->whereMonth('et_customer.created_at', $month)
                ->count();
                
              $monthcall_out = DB::table('et_call_tracker')
                ->selectRaw('COUNT(CASE WHEN call_status = 0 THEN 1 ELSE NULL END) as outgoing_call_count')
                ->whereYear('call_start_date', $year)
                ->whereMonth('call_start_date', $month)
                ->where('et_call_tracker.branch_id', $branchId)
                ->where('et_call_tracker.branch_staff_id', $staff->staff_id)
                ->first();
              $monthcall_out = $monthcall_out->outgoing_call_count ?? 0;
        
        
              // customer ratio
              $convertion_rate = $allLeadCount > 0 ? ($customerConvertCount / $allLeadCount) * 100 : 0;
              $convertion_rate = number_format($convertion_rate, 2);
        
              //acr
              $averager_convertion_rate = $monthLeadCount > 0 ? ($customerConvertCount / $monthLeadCount) * 100 : 0;
              $averager_convertion_rate = number_format($averager_convertion_rate, 2);
        
                $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
                if (!$incentive) {
                    return []; // or return null or false based on your method return type
                }
        
                $luxury = json_decode($incentive->luxury_incentive, true);
                $pi_slabs = json_decode($incentive->pi_slab_json, true);
        
              $currentMonthCustomerCount = 0;
              $total_business_amount     = 0;
              $total_payment             = 0;
              $total_paid_payment        = 0;
              $averageBusinessValue      = 0;
              $averageCollectionValue    = 0;
              $crashCount = 0;
              $professionCount = 0;
              $tesboCount = 0;
              $courseTypeTotal = 0;
              $eciCustomerConvertCount = 0;
              $eciActualPercentage = 0;
              $eciTargetPercentage = $incentive->eci_count ?? 0;
              $eciStatus = false;
            
               $targetConversion = $goalsetData[$staff->sno]->conversion ?? 0;
                $targetABV             = $goalsetData[$staff->sno]->ABV ?? 0;
                $targetACV             = $goalsetData[$staff->sno]->ACV ?? 0;
                $crashTarget =0;
                $professionTarget =0;
                $tesboTarget =0;
                $crashPercent =0;
                $professionPercent=0;
                $tesboPercent=0;
                $piPercentage = 0;
                $originalAmount = 0;
                $piReward = 0;
                $matchedSlab = null;
                $slabPercentage = 0; 
                
               // Total Professional and Crash courses
                $groupedData = DB::table('et_training')
                    ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                    ->select(
                        'et_course.course_type_id',
                        DB::raw('COUNT(DISTINCT et_training.payment_id) AS total_trainings')
                    )
                    ->where('et_training.branch_id', $branchId)
                    ->whereMonth('et_training.created_at', $month)
                    ->whereYear('et_training.created_at', $year)
                    ->whereIn('et_course.course_type_id', [3, 4])
                    ->where('et_training.tesbo_check', '!=', 2)
                    ->where('et_training.post_sale_check', '!=', 1)
                    ->groupBy('et_course.course_type_id')
                    ->get();
                
                // Get valid TESBO count separately
                $teshobo_coures_total = DB::table('et_training')
                    ->where('branch_id', $branchId)
                    ->whereMonth('created_at', $month)
                    ->whereYear('created_at', $year)
                    ->where('tesbo_check', 2)
                    ->where('post_sale_check', '!=', 1)
                    ->distinct('payment_id')
                    ->count('payment_id');
                
                // Prepare tree output
                $crash_coures_total = 0;
                $professinal_coures_total = 0;
                
                foreach ($groupedData as $row) {
                    if ($row->course_type_id == 3) {
                        $professinal_coures_total = (int) $row->total_trainings;
                    } elseif ($row->course_type_id == 4) {
                        $crash_coures_total = (int) $row->total_trainings;
                    }
                }
                
                 $totalcours  = $professinal_coures_total + $crash_coures_total + $teshobo_coures_total;
             
               if ($customerConvertCount > 0) {
                $currentMonthCustomer = CustomerModel::select('et_customer.sno')->whereIn('et_customer.status',[0,6])
                ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                  ->where('et_customer.branch_id', $branchId)
                  ->whereIn('et_customer.status',[0,6])
                  ->where('et_lead.created_by', $staff->sno)
                  ->whereYear('et_customer.created_at', $year)
                  ->whereMonth('et_customer.created_at', $month)
                  ->get();
                  
                  
                    // here i need crash_coures_total ,  professinal_coures_total, teshobo_coures_total 
                // ECI early conversion before 15th
                $eciCustomerConvertCount = CustomerModel::join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
                    ->where('et_customer.branch_id', $branchId)
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereYear('et_customer.created_at', $year)
                    ->whereMonth('et_customer.created_at', $month)
                    ->whereDay('et_customer.created_at', '<=', 15)
                    ->count();
                    //   return $currentMonthCustomer;
                    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                    
                            // First: check if this customer has TESBO training
                            $hasTesbo = DB::table('et_training')
                                ->where('customer_id', $customer->sno)
                                ->where('branch_id', $branchId)
                                ->whereMonth('created_at', $month)
                                ->whereYear('created_at', $year)
                                ->where('tesbo_check', 2)
                                ->where('post_sale_check', '!=', 1)
                                ->exists();
                    
                            if ($hasTesbo) {
                                $tesboCount++;
                                continue; // skip crash/professional check if TESBO already counted
                            }
                    
                            // Then: check if customer has valid Professional or Crash training (not tesbo)
                            $nonTesboTrainings = DB::table('et_training')
                                ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                                ->where('et_training.customer_id', $customer->sno)
                                ->where('et_training.branch_id', $branchId)
                                ->whereMonth('et_training.created_at', $month)
                                ->whereYear('et_training.created_at', $year)
                                ->where('et_training.post_sale_check', '!=', 1)
                                ->where('et_training.tesbo_check', '!=', 2)
                                ->whereIn('et_course.course_type_id', [3, 4])
                                ->select('et_course.course_type_id')
                                ->get();
                    
                            $hasCrash = false;
                            $hasProfession = false;
                    
                            foreach ($nonTesboTrainings as $training) {
                                if ($training->course_type_id == 3) {
                                    $hasProfession = true;
                                } elseif ($training->course_type_id == 4) {
                                    $hasCrash = true;
                                }
                            }
                    
                            if ($hasCrash) $crashCount++;
                            if ($hasProfession) $professionCount++;
                        }
                    
                        $courseTypeTotal = $crashCount + $professionCount + $tesboCount;
                    }
                    // return $crashCount;
                    // spot incentive 
                    $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalcours) * 100 : 0;
                    $professionPercent = $incentive->si_profession_course > 0 ? ($totalcours / $professinal_coures_total) * 100 : 0;
                    $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalcours) * 100 : 0;
                    
                    $crashTarget = $incentive->si_crash_course ?? 0;
                    $professionTarget = $incentive->si_profession_course ?? 0;
                    $tesboTarget = $incentive->si_tesbo_course ?? 0;
                    
                    // only condition: Crash must be ≤ target
                    $siStatus = $crashPercent <= $crashTarget;
                    
                  
                    
                    if ($customerConvertCount > 0 && $currentMonthCustomer->isNotEmpty()) {
                        foreach ($currentMonthCustomer as $customer) {
                            // $trainings = DB::table('et_training')
                            //     ->where('customer_id', $customer->sno)
                            //       ->where('post_sale_check', 0)
                            //     ->get();
                                $trainings = DB::table('et_training as t1')
                                    ->join(DB::raw('(
                                        SELECT MIN(sno) as min_sno
                                        FROM et_training
                                        WHERE post_sale_check = 0
                                        GROUP BY customer_id
                                    ) as t2'), 't1.sno', '=', 't2.min_sno')
                                    ->where('t1.customer_id', $customer->sno)
                                    ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
                                    ->get();
                    
                            foreach ($trainings as $training) {
                                 // Determine course_id based on tesbo_check
                                $course_id = null;
                        
                                if ($training->tesbo_check > 0) {
                                    $payment = PaymentModel::where('payment_id',$training->payment_id)->first();
                                    if ($payment && $payment->course_id) {
                                        $course_id = $payment->course_id;
                                    }
                                } else {
                                    $course_id = $training->course_id;
                                }
                        
                                if (!$course_id) continue; // Skip if no course_id
                        
                                $course = ManageCoursesModel::where('sno', $course_id)
                                    ->whereIn('course_type_id', [2, 3])
                                    ->first();
                        
                                if (!$course) continue;
                    
                                $basePrice = $course->course_min_price;
                                $soldPrice = $training->overall_fees;
                    
                              
                                    $profitAmount = $soldPrice - $basePrice;
                                     $originalAmount += $profitAmount; // always include both + and -

                                     $profitPercent = ($basePrice != 0) ? ($profitAmount / $basePrice) * 100 : 0;
                    
                                    // Match against PI slabs
                                    foreach ($pi_slabs as $slab) {
                                        if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                                            $slabPercentage = $slab['percentage'];
                                            $rewardFromThis = ($profitAmount * $slabPercentage) / 100;
                    
                                            $piReward += $rewardFromThis;
                                            $piPercentage = $profitPercent;
                                            $matchedSlab = "{$slab['min']} < {$slab['max']}%";
                                            break; // first matching slab
                                        }
                                    }
                            }
                        }
                        
                        
                    }
               
                if ($currentMonthCustomer->isNotEmpty()) {
                  foreach ($currentMonthCustomer as $customer) {
        
                    $payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno', 'et_training.customer_id')
                      ->where('et_training.customer_id', $customer->sno)
                      ->where('et_training.tesbo_check', 0)
                      ->sum('et_training.overall_fees');
        
                    $total_payment += $payment;
        
        
                    $latestTraining = DB::table('et_training')
                      ->where('customer_id', $customer->sno)
                      ->where('tesbo_check', 2)
                      ->orderByDesc('sno')
                      ->first();
        
                    if ($latestTraining) {
                      $total_payment += $latestTraining->overall_fees;
                    }
        
                    $paid_payment = DB::table('et_training')->select('et_training.course_id', 'et_training.sno', 'et_training.customer_id')
                      ->where('et_training.customer_id', $customer->sno)
                      ->sum('et_training.paid_amount');
        
                    $total_paid_payment += $paid_payment;
                    
                  }
                }
                 // ECI Logic
                $eciActualPercentage = $targetConversion > 0 ? ($eciCustomerConvertCount / $targetConversion) * 100 : 0;
                $eciActualPercentage = number_format($eciActualPercentage, 2);
                $eciStatus = $eciActualPercentage >= $eciTargetPercentage;
    
                // average 
                $averageBusinessValue   = $customerConvertCount > 0 ? $total_payment / $customerConvertCount : '0';
                $averageCollectionValue = $customerConvertCount > 0 ? $total_paid_payment / $customerConvertCount : '0';
        
                // $totalAllPayment += $total_payment;
                // $totalAllPaidPayment += $total_paid_payment;
              }
              
               $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->where('et_lead.created_by', $staff->sno)
                    ->whereRaw('DATE(et_customer.created_at) BETWEEN ? AND ?', [$startOfMonth, $endOfMonth])
                    ->select(
                        'et_customer.created_at as customer_created_at',
                        'et_lead.created_at as lead_created_at'
                    )
                    ->get();
            
                $convertedToday = 0;
                $convertedMonth = 0;
                $convertedOldMonth = 0;
            
                foreach ($allConverted as $row) {
                    $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
                    $leadDate = Carbon::parse($row->lead_created_at)->format('Y-m-d');
            
                    if ($customerDate ===  $leadDate) {
                        $convertedToday++;
                    } elseif (
                        $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        $leadDate >= $startOfMonth && $leadDate <= $dates
                    ) {
                        $convertedMonth++;
                    } elseif (
                        $customerDate >= $startOfMonth && $customerDate <= $dates &&
                        ($leadDate < $startOfMonth || $leadDate > $dates)
                    ) {
                        $convertedOldMonth++;
                    }
                }
                
                $spotIncentiveDayAmount = $convertedToday * ($incentive->spot_incentive_day ?? 0);
                $spotIncentiveMonthAmount = $convertedMonth * ($incentive->spot_incentive_month ?? 0);
                // Old month = always 0
                $spotTotalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
              
                // 10x award calculation       
                $actualConversion      = $customerConvertCount;
                $actualABV             = $averageBusinessValue ?? 0;
                $actualACV             = $averageCollectionValue ?? 0;
               
               
                 $tenxStatus = (
                    $targetConversion > 0 && $targetABV > 0 && $targetACV > 0 &&
                    $actualConversion >= $targetConversion 
                );
               // bi award calculation  
                $biPerConversion = $incentive->bi_amount ?? 0;
                $biAchievedCount = max(0, $actualConversion - $targetConversion); // No negative bonus
                
                $biReward = $biAchievedCount * $biPerConversion;
                $biStatus = $biAchievedCount > 0;
                
                
                return [
        
                    'incentives' => [
                       'tenx_award' => [
                            'target' => "{$targetConversion}, {$targetABV}, {$targetACV}",
                            'actual' => " {$actualConversion}, " . round($actualABV) . ", " . round($actualACV) .
                                ' <label href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="CR, BV and CV">
                                    <i class="mdi mdi-help-circle text-dark"></i>
                                </label>',
                            'status' => $tenxStatus,
                            'reward' => $tenxStatus ? ($incentive->tenx_award ?? 0) : 0,
                        ],
                    
                        'eci' => [
                            'target' => $eciTargetPercentage . '%',
                            'actual' => round($eciActualPercentage, 1) . '%'. ' <label href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="right" title="70% of their target by 15th of each month"><i class="mdi mdi mdi-help-circle text-dark"></i></label>',
                            'status' => $eciStatus,
                            'reward' => ($tenxStatus && $eciStatus) ? ($incentive->eci_reward ?? 0) : 0,
                        ],
                    
                        'bi' => [
                            'target' => "{$targetConversion} - {$actualConversion} = ({$biAchievedCount})",
                            'actual' => "{$biAchievedCount} × {$biPerConversion}",
                            'status' =>  $biStatus,
                            'reward' => ($tenxStatus && $biStatus) ? $biReward : 0,
                        ],
                    
                        'si' => [
                            'target' => "{$crashTarget}:{$professionTarget}:{$tesboTarget}",
                            'actual' => round($crashPercent) . '%'. ':' . round($professionPercent) . '%'. ':' . round($tesboPercent). '%',
                            'status' => $tenxStatus && $siStatus,
                            'reward' => ($tenxStatus && $siStatus) ? 3000 : 0,
                        ],
                    
                        'pi' => [
                            'target' => $matchedSlab . round($slabPercentage, 2) . '%' ?? 'No Matching Slab',
                            'actual' => round($piPercentage, 2) . '%' . '₹'. $originalAmount,
                            'status' => $piReward > 0,
                            'reward' => ($tenxStatus && $piReward > 0)
                                ? (($piReward >= 0 ? '+' : '-') . round(abs($piReward)))
                                : 0,
                        ],
                    
                        'sp' => [
                            'target' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>' . $convertedOldMonth . '</td></tr>
                                </table>
                            ',
                            'actual' => '
                                <table class="table table-borderless table-sm mb-0">
                                    <tr><td class="text-end">On day</td><td class="text-black">=</td><td>' . $convertedToday . ' × ' . $incentive->spot_incentive_day . ' = ₹' . number_format($spotIncentiveDayAmount) . '</td></tr>
                                    <tr><td class="text-end">On month</td><td class="text-black">=</td><td>' . $convertedMonth . ' × ' . $incentive->spot_incentive_month . ' = ₹' . number_format($spotIncentiveMonthAmount) . '</td></tr>
                                    <tr><td class="text-end">Old Month</td><td class="text-black">=</td><td>₹0</td></tr>
                                </table>
                            ',
                            'status' => $tenxStatus && $spotTotalReward > 0,
                            'reward' => ($tenxStatus && $spotTotalReward > 0) ? $spotTotalReward : 0,
                        ],
    
                    
                        'li' => [
                            'target' => 'All Incentives Achieved',
                            'actual' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
                                ? 'Achieved'
                                : 'Not Achieved',
                            'status' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus),
                            'reward' => ($tenxStatus && $spotTotalReward > 0 && $siStatus && $eciStatus && $biStatus)
                                ? ($luxury['reward'] ?? 0)
                                : 0,
                                ]
                     ]
                ];
                
    }
    
    
    public function getConvertedCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }
    
        // Convert month name or number into intege
        $month = is_numeric($monthRaw)
            ? (int)$monthRaw
            : (int)date('m', strtotime($monthRaw . ' 1'));
    
        // Previous month and year
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $prevMonthStart = $currentMonthStart->copy()->subMonth();
        $prevMonth = $prevMonthStart->month;
        $prevYear  = $prevMonthStart->year;
    
        // 1. Get all converted customers this month (for detailed listing)
        $customerConvertThisMonth = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.created_at', 'et_customer.cus_mobile')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month)
            ->get();
    
        // 1a. For current month low MBC checks only take records from 1st to 25th
        // (Assuming your DB supports the DAY() function; adjust if needed)
        $prevMonthCustomerIdsCurrent = CustomerModel::whereIn('et_customer.status', [0, 6])
           ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month)
            ->pluck('et_customer.sno')
            ->toArray();
    
        // 2. Get previous month converted customers (with staff details)
        $prevMonthCustomerIdscus = CustomerModel::select(
                    'et_customer.sno',
                    'et_customer.cus_name',
                    'et_customer.created_at',
                    'et_customer.cus_mobile',
                    'et_staff.staff_name',
                    'et_staff.staff_image',
                    'et_department.department_name'
                )
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
            ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $prevYear)
            ->whereMonth('et_customer.created_at', $prevMonth)
            ->get();
    
        // 3. Get previous month converted customer IDs (for further checks)
        $prevMonthCustomerIds = CustomerModel::whereIn('et_customer.status', [0, 6])
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $branchId)
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $prevYear)
            ->whereMonth('et_customer.created_at', $prevMonth)
            ->pluck('et_customer.sno')
            ->toArray();
    
        // 4. First Condition: Dropout for previous month
        // $dropoutCustomers = DB::table('et_training')
        //     ->whereIn('customer_id', $prevMonthCustomerIds)
        //     ->where('status', 2)
        //     ->pluck('customer_id')
        //     ->toArray();
      // 1. Fully Paid Customers from Previous Month (only 1 record, full payment)
        $fullPaidCustomerIds = DB::table('et_proposal_pay_slot')
               ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->select('et_payment.customer_id')
            ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->groupBy('et_payment.customer_id')
            ->havingRaw('SUM(et_proposal_pay_slot.paidAmount) = MAX(et_proposal_pay_slot.total_amount)')
            ->pluck('et_payment.customer_id')
            ->toArray();
        // return $fullPaidCustomerIds;
        // 2. Customers who made a second payment this month
        $secondPaymentCustomersmulti =DB::table('et_proposal_pay_slot')
               ->join('et_payment', 'et_payment.pay_slot_id', '=', 'et_proposal_pay_slot.sno')
                ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->whereIn('et_payment.customer_id', $prevMonthCustomerIds)
            ->where('et_proposal_pay_slot.paid_status', 1)
            ->whereMonth('et_proposal_pay_slot.nextPayDate', $month)
            ->whereYear('et_proposal_pay_slot.nextPayDate', $year)
            ->pluck('et_payment.customer_id')
            ->unique()
            ->toArray();
            //  return $secondPaymentCustomersmulti;
        
      
       $secondPaymentCustomers =   array_values(array_unique(array_merge(
                $secondPaymentCustomersmulti,
                $fullPaidCustomerIds
            )));
        // return $secondPaymentCustomers;

        // return or use $secondPaymentCustomers

       
        // 6. Third Condition: Low MBC (min amount not paid) for previous month
        $branch = BranchModel::where('sno', $branchId)->first();
        // $dropRefundedIds = DB::table('et_drop_refund')
        //     ->join('et_training', 'et_drop_refund.training_id', '=', 'et_training.sno')
        //     ->pluck('et_training.customer_id')
        //     ->toArray();
    
        $lowMbcCustomerIds = DB::table('et_proposal')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->whereIn('et_proposal.customer_id', $prevMonthCustomerIds)
            ->where('et_proposal.branch_id', $branchId)
            // ->whereNotIn('et_proposal.customer_id', $dropRefundedIds)
            ->whereNotIn('et_proposal.status',[0,2])
            ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
            // ->whereRaw('DAY(et_customer.created_at) <= 25')
            ->groupBy('et_proposal.customer_id')
            ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost ?? 0])
            ->pluck('et_proposal.customer_id')
            ->toArray();
            // return $lowMbcCustomerIds;
    
        // 7. Combine all failed (bad) customers for previous month
        $badCustomerIdsPrev = array_unique(array_merge(
            // $dropoutCustomers,
            array_diff($prevMonthCustomerIds, $secondPaymentCustomers),
            $lowMbcCustomerIds
        ));
    
        // Now, for current month details: Using low MBC check for 1st to 25th only.
        // a. Dropout in current month (based on current-customer IDs filtered above)
        // $dropoutCustomersCurrent = DB::table('et_proposal')
        //     ->whereIn('customer_id', $prevMonthCustomerIdsCurrent)
        //     ->where('status', 2)
        //     ->pluck('customer_id')
        //     ->toArray();
    
        // b. Low MBC in current month (add the day limitation in the customer join above)
        $lowMbcCustomerIdsCurrent = DB::table('et_proposal')
            // ->join('et_payment', 'et_payment.payment_id', '=', 'et_training.payment_id')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->whereIn('et_proposal.customer_id', $prevMonthCustomerIdsCurrent)
            // ->where('et_payment.branch_id', $branchId)
            // ->whereNotIn('et_training.customer_id', $dropoutCustomersCurrent)
            ->whereNotIn('et_proposal.status',[0,2])
            ->where('et_proposal_pay_slot.balance_amount', '!=', 0)
            ->whereRaw('DAY(et_proposal.created_at) <= 25')
            ->groupBy('et_proposal.customer_id')
            ->havingRaw("SUM(et_proposal_pay_slot.paidAmount) < ?", [$branch->min_prd_cost])
            ->pluck('et_proposal.customer_id')
            ->toArray();
            // return $lowMbcCustomerIdsCurrent;
        $lowMbcCustomerIdspay = DB::table('et_proposal')
            ->join('et_customer', 'et_proposal.customer_id', '=', 'et_customer.sno')
            ->join('et_payment', 'et_payment.proposal_id', '=', 'et_proposal.sno')
            ->join('et_proposal_pay_slot', 'et_proposal_pay_slot.proposal_sno', '=', 'et_proposal.sno')
            ->whereIn('et_proposal.customer_id', $prevMonthCustomerIdsCurrent)
            ->where('et_proposal.branch_id', $branchId)
            // ->whereNotIn('et_training.customer_id', $dropRefundedIds)
            ->whereNotIn('et_proposal.status', [0,2])
            ->select(
                'et_proposal.customer_id',
                DB::raw('SUM(DISTINCT et_proposal_pay_slot.paidAmount) as total_paid_amount')
            )
            ->groupBy('et_proposal.customer_id')
            ->get()
            ->keyBy('customer_id'); // ← keep this as Collection, NOT array
        // return $lowMbcCustomerIdspay;
  
        // Combine current month bad customer IDs (only dropout and low MBC are considered)
        $badCustomerIdsCurrent = array_unique(array_merge(
            // $dropoutCustomersCurrent,
            $lowMbcCustomerIdsCurrent
        ));
        $dropoutCustomers=[];
    
        // 8. Build the final list for previous month with status & reason
        $finalDataPrev = $prevMonthCustomerIdscus->map(function ($cus) use ($dropoutCustomers, $secondPaymentCustomers, $lowMbcCustomerIds) {
            $reason = null;
            // Default: converted (green tick)
            $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';
    
            if (in_array($cus->sno, $dropoutCustomers)) {
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
                $reason = 'Dropout in previous month';
            } elseif (!in_array($cus->sno, $secondPaymentCustomers)) {
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
                $reason = 'No second payment in current month';
            } elseif (in_array($cus->sno, $lowMbcCustomerIds)) {
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                           </a>';
                $reason = 'Paid below low MBC';
            }
    
            return [
                'customer_name' => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                'status'        => $status,
                'reason'        => $reason ?? 'Successfully Paid MPC And Second Payment',
                'staff_name'    => $cus->staff_name,
                'staff_image'   => $cus->staff_image,
                'department_name'=> $cus->department_name,
            ];
        })->values();
    $dropoutCustomersCurrent=[];
        // 9. Build the final list for current month details with status & reason
        $finalDataCurrent = $customerConvertThisMonth->map(function ($cus) use ($dropoutCustomersCurrent, $lowMbcCustomerIdsCurrent,$lowMbcCustomerIdspay) {
            $reason = null;
            // Default status: converted
            $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';
               $amount = $lowMbcCustomerIdspay->get($cus->sno)?->total_paid_amount ?? 0;
    
            if (in_array($cus->sno, $dropoutCustomersCurrent)) {
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';
                $reason = 'Dropout in current month';
            } elseif (in_array($cus->sno, $lowMbcCustomerIdsCurrent)) {
                $status = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';
                $reason = 'Paid below low MBC (1st-25th day)';
            }
    
            return [
                'customer_name' => $cus->cus_name,
                'mobile'        => $cus->cus_mobile,
                'month'         => Carbon::parse($cus->created_at)->format('F Y'),
                'amount'        => $amount,
                'status'        => $status,
                'reason'        => $reason ?? 'Successfully Paid MPC Value'
            ];
        })->values();
    
        // 10. Build summary counts for display
        $prevMonthSummary = [
            'second_payment_total' => count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($dropoutCustomers) - count($lowMbcCustomerIds),
            'lmbc_total'           => count($lowMbcCustomerIds),
            'drop_count_total'     => count($dropoutCustomers),
            'converted_total'      => count($prevMonthCustomerIds)
        ];
      
       
        $minuscustold =  count($prevMonthCustomerIds) - count($secondPaymentCustomers) - count($lowMbcCustomerIds) - count($dropoutCustomers);
         $minus_value =  $minuscustold + count($lowMbcCustomerIdsCurrent) + count($dropoutCustomersCurrent) + count($dropoutCustomers);
        $finalCustomer = count($prevMonthCustomerIdsCurrent) - $minus_value;
        $currentMonthSummary = [
             'minus_value'             => $minus_value,
             'final_value'             => $finalCustomer > 0 ? $finalCustomer :0,
            'lmbc_total_current'   => count($lowMbcCustomerIdsCurrent),
            'drop_count_current'   => count($dropoutCustomersCurrent),
            'converted_total_current' => count($prevMonthCustomerIdsCurrent)
        ];
    
        return response()->json([
            'data_prev'       => $finalDataPrev,
            'data_current'    => $finalDataCurrent,
            'summary_prev'    => $prevMonthSummary,
            'summary_current' => $currentMonthSummary,
        ]);
    }

    public function getcalculationCustomers(Request $request)
    {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
        return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
        ? (int) $monthRaw
        : (int) date('m', strtotime($monthRaw . ' 1'));

    $prevDate = Carbon::createFromDate($year, $month, 1)->subMonth();
    $prevMonth = $prevDate->month;
    $prevYear  = $prevDate->year;

    $pi_slabs = [
        ['min' => 0, 'max' => 10, 'percentage' => 5],
        ['min' => 10, 'max' => 20, 'percentage' => 10],
        ['min' => 20, 'max' => 1000, 'percentage' => 15],
    ];

    $data = [];

    $prevMonthCustomerIdscus = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
       ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
        ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_customer.branch_id', $branchId)
        ->where('et_lead.created_by', $staffId)
        ->whereYear('et_customer.created_at', $year)
        ->whereMonth('et_customer.created_at', $month)
        ->get();
    $globalIndex = 1; 
 
    foreach ($prevMonthCustomerIdscus as  $customer) {
       
      
        $trainings = DB::table('et_training as t1')
                ->join(DB::raw('(
                    SELECT MIN(sno) as min_sno
                    FROM et_training
                    WHERE post_sale_check = 0
                    GROUP BY customer_id
                ) as t2'), 't1.sno', '=', 't2.min_sno')
                ->where('t1.customer_id', $customer->sno)
                ->select('t1.sno', 't1.customer_id', 't1.payment_id', 't1.tesbo_check', 't1.course_id', 't1.overall_fees')
                ->get();
        
    
        foreach ($trainings as $training) {
            // Determine course_id based on tesbo_check
            $course_id = null;
    
            if ($training->tesbo_check > 0) {
                $payment = PaymentModel::where('payment_id',$training->payment_id)->first();
                if ($payment && $payment->course_id) {
                    $course_id = $payment->course_id;
                }
            } else {
                $course_id = $training->course_id;
            }
    
            if (!$course_id) continue; // Skip if no course_id
    
            $course = ManageCoursesModel::where('sno', $course_id)
                ->whereIn('course_type_id', [2, 3])
                ->first();
    
            if (!$course) continue;
        
            $basePrice = $course->course_min_price;
            $soldPrice = $training->overall_fees;
            $profitAmount = $soldPrice - $basePrice;
        
            // Calculate confirmed amount only if there's profit
            $confirmAmount = 0;
            if ($profitAmount > 0) {
                $profitPercent = ($profitAmount / $basePrice) * 100;
                foreach ($pi_slabs as $slab) {
                    if ($profitPercent >= $slab['min'] && $profitPercent < $slab['max']) {
                        $confirmAmount = ($profitAmount * $slab['percentage']) / 100;
                        break;
                    }
                }
            }
        
            $data[] = [
                'sno'                 => $globalIndex++,
                'customer_name'       => $customer->cus_name,
                'mobile'              => $customer->cus_mobile,
                'month'               => Carbon::parse($customer->created_at)->format('F Y'),
                'course_name'         => $course->course_name,
                'original_amount'     => number_format($basePrice, 2),
                'confirm_amount'      => number_format($soldPrice, 2),
                'profit_loss_amount'  => ($profitAmount >= 0 ? '+' : '-') . number_format(abs($profitAmount), 2),
                'staff_name'          => $customer->staff_name,
                'staff_image'         => $customer->staff_image,
                'department_name'     => $customer->department_name,
            ];
        }
    }

    return response()->json(['data' => $data]);
}
    public function geteciCustomers(Request $request)
    {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
        return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
        ? (int) $monthRaw
        : (int) date('m', strtotime($monthRaw . ' 1'));
        
    // Define the 1st to 15th range of the selected month/year
    $now = Carbon::createFromDate($year, $month, 1);
    $startOfMonth = $now->copy()->startOfMonth();
    $middleOfMonth = $now->copy()->startOfMonth()->addDays(15); // 1st to 15th
    
    $customers = CustomerModel::select('et_customer.sno', 'et_customer.cus_name', 'et_customer.created_at', 'et_customer.cus_mobile', 'et_staff.staff_name', 'et_staff.staff_image', 'et_department.department_name')
        ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
        ->join('et_staff', 'et_staff.sno', '=', 'et_lead.created_by')
        ->join('et_department', 'et_department.sno', '=', 'et_staff.department_id')
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_customer.branch_id', $branchId)
        ->where('et_lead.created_by', $staffId)
        ->whereYear('et_customer.created_at', $year)
        ->whereMonth('et_customer.created_at', $month)
        ->get();

    $data = [];
    foreach ($customers as $index => $cus) {
        // Fetch course
        $course = DB::table('et_training')
            ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
            ->where('et_training.customer_id', $cus->sno)
            ->select('et_course.course_name')
            ->first();

        $data[] = [
            'sno'         => $index + 1,
            'name'        => $cus->cus_name,
            'mobile'        => $cus->cus_mobile,
            'course'      => $course->course_name ?? '--',
            'created_at'  => Carbon::parse($cus->created_at)->format('d-M-Y'),
            'status'      => Carbon::parse($cus->created_at)->between($startOfMonth, $middleOfMonth)
                        ? 'Converted'
                        : 'Eligible', // you can change this dynamically
            'staff_name'      => $cus->staff_name,
            'staff_image'     => $cus->staff_image,
            'department_name' => $cus->department_name,
        ];
    }

    return response()->json(['data' => $data]);
}

    public function getCallCustomers(Request $request)
    {
    $staffId   = $request->query('staff_id');
    $monthRaw  = $request->query('month');
    $year      = $request->query('year');
    $branchId  = $request->query('branch_id');

    if (!$staffId || !$monthRaw || !$year || !$branchId) {
        return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
    }

    $month = is_numeric($monthRaw)
        ? (int) $monthRaw
        : (int) date('m', strtotime($monthRaw . ' 1'));

    $now = Carbon::createFromDate($year, $month, 1);
    $startOfMonth = $now->copy()->startOfMonth();
    $middleOfMonth = $now->copy()->startOfMonth()->addDays(14);
    $endOfMonth = $now->copy()->endOfMonth(); // 🔧 FIXED
    $incentive = IncentiveModel::where('role_id', 11)
                    ->where('branch_id', $branchId)
                    ->where('status', 0)
                    ->first();
        
               
    $allConverted = CustomerModel::join('et_lead', 'et_customer.lead_id', '=', 'et_lead.sno')
        ->join('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
        ->leftJoin('et_department', 'et_staff.department_id', '=', 'et_department.sno')
        ->whereIn('et_customer.status', [0, 6])
        ->where('et_customer.branch_id', $branchId)
        ->where('et_lead.created_by', $staffId)
        ->whereBetween(DB::raw('DATE(et_customer.created_at)'), [$startOfMonth, $endOfMonth])
        ->select(
            'et_customer.sno',
            'et_lead.lead_mobile',
            'et_customer.created_at as customer_created_at',
            'et_lead.created_at as lead_created_at',
            'et_customer.cus_name',
            'et_customer.cus_mobile',
            'et_customer.created_at',
            'et_staff.staff_name',
            'et_staff.staff_image',
            'et_department.department_name'
        )
        ->get();

    $convertedToday = 0;
    $convertedMonth = 0;
    $convertedOldMonth = 0;

    $data = [];

    foreach ($allConverted as $index => $row) {
        $mobile = $row->lead_mobile;

        // Get the latest call
        $lastCall = DB::table('et_call_tracker')
            ->where('branch_id', $branchId)
            ->where('branch_staff_id', $staffId)
            ->where('customer_phone_no', 'like', "%{$mobile}")
            ->orderByDesc('call_start_date')
            ->first();

        $totalCallCount = DB::table('et_call_tracker')
            ->where('branch_id', $branchId)
            ->where('branch_staff_id', $staffId)
            ->where('customer_phone_no', 'like', "%{$mobile}")
            ->count();
        $totalCalldata = DB::table('et_call_tracker')
            ->where('branch_id', $branchId)
            ->where('branch_staff_id', $staffId)
            ->where('customer_phone_no', 'like', "%{$mobile}")
             ->select(
                'et_call_tracker.call_start_date'
            )
            ->get();
         
        //   return  $totalCalldata;
        // Date parsing
        $customerDate = Carbon::parse($row->customer_created_at)->format('Y-m-d');
        $leadDate     = Carbon::parse($row->lead_created_at)->format('Y-m-d');
        $callDate     = $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null;

        $convertedOnDay = $customerDate === $leadDate && $totalCallCount === 1;

        $convertedInMonth = !$convertedOnDay && // only if not already on-day
            $customerDate >= $startOfMonth->format('Y-m-d') &&
            $customerDate <= $endOfMonth->format('Y-m-d') &&
            $leadDate >= $startOfMonth->format('Y-m-d') &&
            $leadDate <= $endOfMonth->format('Y-m-d') &&
            $totalCalldata->contains(function ($call) use ($startOfMonth, $endOfMonth) {
                $callDate = Carbon::parse($call->call_start_date);
                return $callDate >= $startOfMonth && $callDate <= $endOfMonth;
            });
        
        $convertedOld = !$convertedOnDay && !$convertedInMonth && // only if not on-day or in-month
            $customerDate >= $startOfMonth->format('Y-m-d') &&
            $customerDate <= $endOfMonth->format('Y-m-d') &&
            ($leadDate < $startOfMonth->format('Y-m-d') && $totalCallCount > 1 || $leadDate > $endOfMonth->format('Y-m-d'));
            
        $otherstaffConvert = !$convertedOnDay && !$convertedInMonth && !$convertedOld && $totalCallCount === 0;
            

                        
        $statusTick = '<a href="javascript:;" class="btn btn-icon btn-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                            </svg>
                        </a>';
        $statusWrong = '<a href="javascript:;" class="btn btn-icon btn-sm">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                            </svg>
                          </a>';
                          
        $spotIncentiveDayAmount = $convertedOnDay ? ($incentive->spot_incentive_day ?? 0) : 0;
        $spotIncentiveMonthAmount = $convertedInMonth ? ($incentive->spot_incentive_month ?? 0) : 0;
        
        $totalReward = $spotIncentiveDayAmount + $spotIncentiveMonthAmount;
        
        $data[] = [
            'sno' => $index + 1,
            'name' => $row->cus_name,
            'mobile' => $row->cus_mobile,
            'totalCallCount' => $totalCallCount,
            'created_at' => Carbon::parse($row->customer_created_at)->format('d-M-Y'),
            'lead_created_at' => Carbon::parse($row->lead_created_at)->format('d-M-Y'),
            'call_start_date' => $lastCall ? Carbon::parse($lastCall->call_start_date)->format('Y-m-d') : null,
            'on_day' => $convertedOnDay ? $statusTick : $statusWrong,
            'on_month' => $convertedInMonth ? $statusTick : $statusWrong,
            'old_month' => $convertedOld ? $statusTick : $statusWrong,
            'otherstaff' => $otherstaffConvert,
            'Rewards' => $spotIncentiveDayAmount + $spotIncentiveMonthAmount,
            'staff_name' => $row->staff_name,
            'staff_image' => $row->staff_image,
            'department_name' => $row->department_name
        ];
    }

    return response()->json([
        'data' => $data,
        'summary' => [
            'on_day' => $convertedToday,
            'on_month' => $convertedMonth,
            'old_month' => $convertedOldMonth
        ]
    ]);
}

    public function getCollectionCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }
    
        $month = is_numeric($monthRaw)
            ? (int)$monthRaw
            : (int)date('m', strtotime($monthRaw . ' 1'));
    
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $nextMonthStart = $currentMonthStart->copy()->addMonth();
        
          $current = Carbon::create($year, $month, 1);
        // 20 years ago from now
        $startDateold = $current->copy()->subYears(20)->startOfMonth();
        $endDateold = $current->copy()->subMonth()->endOfMonth(); // exclude current month
        $staff = StaffModel::where('sno', $staffId)->first();

      
        $currentMonthStart = Carbon::create($year, $month, 1)->startOfMonth();
        $currentMonthEnd = Carbon::create($year, $month, 1)->endOfMonth();
         $dropoutCustomers = DB::table('et_training')
                        ->where('status', 2)
                        ->pluck('customer_id')
                        ->toArray();
                       
         $prevMonthConvertedCustomers = CustomerModel::select('et_customer.sno')
                    ->whereIn('et_customer.status', [0, 6])
                    ->where('et_customer.branch_id', $branchId)
                    ->whereNotIn('et_customer.sno', $dropoutCustomers) 
                    ->whereBetween('et_customer.created_at', [$startDateold, $endDateold])
                    ->pluck('et_customer.sno')
                    ->toArray();
    
        // ✅ 2. Get old month collection (scheduled earlier, paid now)
        $oldMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->where('et_payment.nextPayDate', '<', $currentMonthStart)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
      
        // ✅ 3. Get current month collection (scheduled and paid now)
        $currentMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->whereMonth('et_payment.nextPayDate', $month)
            ->whereYear('et_payment.nextPayDate', $year)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
           
    
        // ✅ 4. Get future month collection (scheduled later, paid now)
        $futureMonthCollection = DB::table('et_payment')
            ->join('et_customer', 'et_payment.customer_id', '=', 'et_customer.sno')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_payment.customer_id', $prevMonthConvertedCustomers) 
            ->whereNotBetween('et_customer.created_at', [$currentMonthStart, $currentMonthEnd])
            ->where('et_payment.status', 1)
            ->where('et_customer.status', 0)
            ->where('et_payment.paidAmount', '>', 0)
            ->where('et_payment.nextPayDate', '>', $nextMonthStart)
            ->whereMonth('et_payment.initialPayDate', $month)
            ->whereYear('et_payment.initialPayDate', $year)
            ->select('et_customer.cus_name', 'et_payment.paidAmount','et_payment.initialPayDate','et_payment.nextPayDate')
            ->get();
    
        // ✅ 5. Calculate totals
        $oldAmountTotal = $oldMonthCollection->sum('paidAmount');
        $currentAmountTotal = $currentMonthCollection->sum('paidAmount');
        $futureAmountTotal = $futureMonthCollection->sum('paidAmount');
    
        // Optional: You can calculate percentage based on targets if available
    
        $totalCollection = $oldAmountTotal + $currentAmountTotal + $futureAmountTotal;

        return response()->json([
            'staff' => $staff,
        
            'old_amount' => [
                'collection' => $oldAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($oldAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $oldMonthCollection,
            ],
        
            'current_amount' => [
                'collection' => $currentAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($currentAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $currentMonthCollection,
            ],
        
            'future_amount' => [
                'collection' => $futureAmountTotal,
                'percentage' => $totalCollection > 0 ? round(($futureAmountTotal / $totalCollection) * 100, 2) : 0,
                'customers'  => $futureMonthCollection,
            ],
        ]);
    }
    
    public function getCourseCustomers(Request $request)
    {
        $staffId   = $request->query('staff_id');
        $monthRaw  = $request->query('month');
        $year      = $request->query('year');
        $branchId  = $request->query('branch_id');
    
        if (!$staffId || !$monthRaw || !$year || !$branchId) {
            return response()->json(['data' => [], 'error' => 'Missing required parameters'], 400);
        }
    
        $month = is_numeric($monthRaw) ? (int)$monthRaw : (int)date('m', strtotime($monthRaw . ' 1'));
    
        $currentMonthStart = Carbon::createFromDate($year, $month, 1);
        $nextMonthStart = $currentMonthStart->copy()->addMonth();
        $staff = StaffModel::where('sno', $staffId)->first();
        
        $incentive = IncentiveModel::where('role_id', $staff->role_id)
                    ->where('branch_id', $branchId)
                    ->whereMonth('incentive_month', $month)
                    ->whereYear('incentive_month', $request->year)
                    ->where('status', 0)
                    ->first();
        // Course counts init
        $crashCount = 0;
        $professionCount = 0;
        $tesboCount = 0;
        
        $tesboCustomers = collect();
        $crashCustomers = collect();
        $professionCustomers = collect();
        
        // Grouped Professional and Crash Courses
        $groupedData = DB::table('et_training')
            ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
            ->select('et_course.course_type_id', DB::raw('COUNT(DISTINCT et_training.payment_id) AS total_trainings'))
            ->where('et_training.branch_id', $branchId)
            ->whereMonth('et_training.created_at', $month)
            ->whereYear('et_training.created_at', $year)
            ->whereIn('et_course.course_type_id', [3, 4])
            ->where('et_training.tesbo_check', '!=', 2)
            ->where('et_training.status', 0)
            ->where('et_training.post_sale_check', '!=', 1)
            ->groupBy('et_course.course_type_id')
            ->get();
    
        $teshobo_coures_total = DB::table('et_training')
            ->where('branch_id', $branchId)
            ->whereMonth('created_at', $month)
            ->whereYear('created_at', $year)
            ->where('tesbo_check', 2)
            ->where('status', 0)
            ->where('post_sale_check', '!=', 1)
            ->distinct('payment_id')
            ->count('payment_id');
    
        $crash_coures_total = 0;
        $professinal_coures_total = 0;
    
        foreach ($groupedData as $row) {
            if ($row->course_type_id == 3) {
                $professinal_coures_total = (int)$row->total_trainings;
            } elseif ($row->course_type_id == 4) {
                $crash_coures_total = (int)$row->total_trainings;
            }
        }
    
        // All customers created this month by staff
        $currentMonthCustomers = CustomerModel::select('et_customer.sno')
            ->join('et_lead', 'et_lead.sno', '=', 'et_customer.lead_id')
            ->where('et_customer.branch_id', $branchId)
            ->whereIn('et_customer.status', [0, 6])
            ->where('et_lead.created_by', $staffId)
            ->whereYear('et_customer.created_at', $year)
            ->whereMonth('et_customer.created_at', $month)
            ->get();
    
        foreach ($currentMonthCustomers as $customer) {
            // TESBO check
                $tesboData = DB::table('et_training')
                    ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                    ->join('et_customer', 'et_customer.sno', '=', 'et_training.customer_id')
                    ->where('et_training.customer_id', $customer->sno)
                    ->where('et_training.branch_id', $branchId)
                    ->whereMonth('et_training.created_at', $month)
                    ->whereYear('et_training.created_at', $year)
                    ->where('et_training.tesbo_check', 2)
                    ->where('et_training.post_sale_check', '!=', 1)
                    ->select('et_customer.cus_name', 'et_course.course_name', 'et_course.course_type_id')
                    ->first();
            
                if ($tesboData) {
                    $tesboCustomers->push($tesboData);
                    $tesboCount++;
                    continue;
                }
    
            // Professional or Crash
             $nonTesboTrainings = DB::table('et_training')
                ->join('et_course', 'et_course.sno', '=', 'et_training.course_id')
                ->join('et_customer', 'et_customer.sno', '=', 'et_training.customer_id')
                ->where('et_training.customer_id', $customer->sno)
                ->where('et_training.branch_id', $branchId)
                ->whereMonth('et_training.created_at', $month)
                ->whereYear('et_training.created_at', $year)
                ->where('et_training.tesbo_check', '!=', 2)
                ->where('et_training.post_sale_check', '!=', 1)
                ->whereIn('et_course.course_type_id', [3, 4])
                ->select('et_customer.cus_name', 'et_course.course_name', 'et_course.course_type_id')
                ->get();
    
            $hasCrash = false;
            $hasProfession = false;
    
           
            foreach ($nonTesboTrainings as $training) {
                if ($training->course_type_id == 3) {
                    $professionCustomers->push($training);
                    $professionCount++;
                } elseif ($training->course_type_id == 4) {
                    $crashCustomers->push($training);
                    $crashCount++;
                }
            }
    
            if ($hasCrash) $crashCount++;
            if ($hasProfession) $professionCount++;
        }
    
      
    
        $totalCustomers = max(1, $currentMonthCustomers->count()); // avoid division by 0
    
        $crashPercent = $incentive->si_crash_course > 0 ? ($crashCount / $totalCustomers) * 100 : 0;
        $professionPercent = $incentive->si_profession_course > 0 ? ($professionCount / $totalCustomers) * 100 : 0;
        $tesboPercent = $incentive->si_tesbo_course > 0 ? ($tesboCount / $totalCustomers) * 100 : 0;
    
        return response()->json([
            'staff' => $staff,
        
            'crash_course' => [
                'percentage' => $crashPercent,
                'count' => $crashCount,
                'customers' => $crashCustomers,
            ],
        
            'professional_course' => [
                'percentage' => $professionPercent,
                'count' => $professionCount,
                'customers' => $professionCustomers,
            ],
        
            'tesbo_course' => [
                'percentage' => $tesboPercent,
                'count' => $tesboCount,
                'customers' => $tesboCustomers,
            ],
        ]);
    }





}