<?php

namespace App\Http\Controllers\qr_promotion;

use App\Http\Controllers\Controller;
use App\Models\ManageCoursesModel;
use App\Models\StaffModel;
use App\Models\QrPromotionModel;
// use App\Models\GiftModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

// QrPromotion controller

class QrPromotion extends Controller
{


  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $helper = new \App\Helpers\Helpers();
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    if ($branch_id) {
      $get_branch_type = $helper->get_branch_id($branch_id)->branch_type ?? 0;
    } else {
      $get_branch_type =  0;
    }
    $search_fill = $request->search_fill ?? '';
   
    $date_filter = $request->dt_fill_issue_rpt;
    $from_date_filter = $request->from_date_fillter_textbox;
    $to_date_filter = $request->to_date_fillter_textbox;

    $query = QrPromotionModel::select('et_qr_promotion.*','et_staff.staff_name','et_staff.nick_name')
    // ->where('et_qr_promotion.branch_id',$branch_id)
    ->where('et_qr_promotion.status', '<', 2)->leftJoin('et_staff', 'et_qr_promotion.qr_staff_id', '=', 'et_staff.sno');

    // Date Filtering Logic
    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('et_qr_promotion.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('et_qr_promotion.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('et_qr_promotion.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('et_qr_promotion.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('et_qr_promotion.created_at', '<=', $toDate);
      }
    }
    
    if ($search_fill != '') {
        $query->where(function ($sub_query) use ($search_fill) {
            $sub_query->where('et_qr_promotion.discount_name', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.min_value', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.max_value', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_qr_promotion.expiry_date', 'LIKE', "%{$search_fill}%")
                ->orWhere('et_staff.staff_name', 'LIKE', "%{$search_fill}%");
        });
    }

    // Fetch Branch list ordered by sno in descending order
    $List_table = $query->orderByDesc('is_status')->paginate($perpage);
    $course_list = [];
      
    $Staff_list = StaffModel::select('sno', 'staff_name', 'nick_name')
      ->where('status', 0)
      ->where('branch_id', $branch_id)
      ->whereIn('role_id', [11,12])
      ->orderBy('staff_name', 'ASC')->get();
      
    $free_gift_list = [];
    
    $Event_list = [];

    return view('content.qr_promotion.list', [
      'List_table' => $List_table,
      'Course_list' => $course_list,
      'Staff_list' => $Staff_list,
      'Event_list' => $Event_list,
      'Free_gift_list' => $free_gift_list,
      'search_fill' => $search_fill,
      'perpage' => $perpage,
      'date_filter' => $date_filter,

    ])->with('filter_on', false);
  }

  public function Status($id, Request $request)
  {

    $staff =  QrPromotionModel::where('sno', $id)->first();
    $staff->status = $request->input('status', 0);
    $staff->update();
    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    $upd_QrPromotionModel = QrPromotionModel::where('sno', $id)->first();
    $upd_QrPromotionModel->status = 2;
    $upd_QrPromotionModel->Update();

    if ($upd_QrPromotionModel) {
      return response([
        'status'    => 200,
        'message'   => 'Staff Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Staff ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function Add(Request $request)
  {
    //   return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'qr_promotion_name' => 'required|max:255',
            'expiry_date' => 'required|date',
            'promotion_type' => 'required|max:255'
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->errors()->all(),
                'data' => null,
            ], 200);
        }
    
        // Use validated data
        $validated = $validator->validated();
    
        $add_category = new QrPromotionModel();
        $add_category->discount_name   = ucfirst($validated['qr_promotion_name']);
        $add_category->discount_type   = $request->promotion_type;
        $add_category->branch_id       = $request->branchId;
        $add_category->min_value       = $request->min_value;
        $add_category->max_value       = $request->max_value;
        $add_category->free_gifts_id = json_encode($request->free_gift_id ?? []);
        $add_category->course_id       = $request->course_id ?? 0;
        $add_category->event_id       = $request->event_id ?? 0;
        $add_category->expiry_date     = date('Y-m-d', strtotime($validated['expiry_date']));
        $add_category->qr_staff_id     = $request->qr_staff_id;
        $add_category->qr_desc         = $request->desc;
        $add_category->created_by      = $request->user()->user_id;
        $add_category->updated_by      = $request->user()->user_id;
        $add_category->save();
        
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'QR Promotion added successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the QR Promotion !'
          ]);
        }
        
        return redirect()->back();
    }
    
  public function Edit($id)
  {
    $data =  QrPromotionModel::where('sno', $id)->first();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'QrPromotion not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'QrPromotion fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function branch_sales_staff_list($id)
  {
    $data = StaffModel::select('sno', 'staff_name', 'nick_name')
      ->where('status', 0)
      ->where('branch_id', $id)
      ->whereIn('role_id', [11,12])
      ->orderBy('staff_name', 'ASC')->get();

    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Staff not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Staff fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update(Request $request)
  {
    //   return $request;
        // Validate incoming request
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|max:255',
            'qr_promotion_name' => 'required|max:255',
            'expiry_date' => 'required|date',
            'promotion_type' => 'required|max:255'
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 401,
                'message' => 'Incorrect format input fields',
                'error_msg' => $validator->errors()->all(),
                'data' => null,
            ], 200);
        }
    
        // Use validated data
        $validated = $validator->validated();
    
        $add_category = QrPromotionModel::where('sno', $request->edit_id)->first();

        $add_category->discount_name   = ucfirst($validated['qr_promotion_name']);
        $add_category->discount_type   = $request->promotion_type;
        $add_category->branch_id       = $request->branchId;
        if($request->promotion_type == 0 || $request->promotion_type == 1){
            $add_category->min_value       = $request->min_value;
            $add_category->max_value       = $request->max_value;
        }else{
            $add_category->min_value       = 0;
            $add_category->max_value       = 0;
        }
        if($request->promotion_type == 2){
            $add_category->course_id       = $request->course_id;
        }else{
            $add_category->course_id       = 0;
        }
        
        if($request->promotion_type == 4){
             $add_category->event_id = $request->event_id ?? 0;
        }else{
            $add_category->event_id  = 0;
        }
        
        if($request->promotion_type == 5){
            $add_category->free_gifts_id = json_encode($request->free_gift_id ?? []);
        }else{
            $add_category->free_gifts_id = '';
        }
        
        
        $add_category->expiry_date     = date('Y-m-d', strtotime($validated['expiry_date']));
        $add_category->qr_staff_id     = $request->qr_staff_id;
        $add_category->qr_desc         = $request->desc;
        $add_category->created_by      = $request->user()->user_id;
        $add_category->updated_by      = $request->user()->user_id;
        $add_category->save();
        
        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'QR Promotion Updated successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the QR Promotion !'
          ]);
        }
        
        return redirect()->back();
    }

}
