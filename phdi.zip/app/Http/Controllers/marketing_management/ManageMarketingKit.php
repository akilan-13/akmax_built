<?php

namespace App\Http\Controllers\marketing_management;

use App\Http\Controllers\Controller;
use App\Models\MarketingKitModel;
use App\Models\MarketingKitCartModel;
use App\Models\MarketingKitOrderModel;
use App\Models\VariableModel;
use App\Models\VariablesModel;
use App\Models\VariantModel;

use App\Models\MarketingKitCategoryModel;
use App\Models\MarketingKitSubCategoryModel;
use DateTime;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\MarketingCampaignExport;
use Razorpay\Api\Api;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Collection;
class ManageMarketingKit extends Controller
{
   public function index(Request $request)
   {
    $page     = $request->input('page', 1);
    $perPage  = (int) $request->input('sorting_filter', 25);
    $offset   = ($page - 1) * $perPage;
    $cus_fill = $request->cus_fill ?? '';

    $categories    = MarketingKitCategoryModel::where('status', 0)->get(['sno', 'category_name']);
    $Variabledata  = VariablesModel::where('status', 0)->get(['sno', 'variant_id', 'variables_name']);
    $Variantdatas  = VariantModel::where('status', 0)->get(['sno', 'variant_name']);

    // Attach variables to each variant
    $Variantdata = $Variantdatas->filter(function ($variant) use ($Variabledata) {
        $variables = $Variabledata->where('variant_id', $variant->sno)->values();
        if ($variables->isNotEmpty()) {
            $variant->variables = $variables;
            return true;
        }
        return false;
    })->values();

    // Base kit query
    $query = MarketingKitModel::where('za_marketing_kit.status', 0)
        ->join('marketing_category', 'za_marketing_kit.category_id', '=', 'marketing_category.sno')
        ->select('za_marketing_kit.*', 'marketing_category.category_name')
        ->orderBy('za_marketing_kit.sno', 'desc');

    $kits = $query->get();

    // Subcategory map [id => name]
    $subcategoriesMap = MarketingKitSubCategoryModel::pluck('marketing_subcategory_name', 'sno')->toArray();

    // Apply variant + subcategory filtering
    $kits = $kits->filter(function ($kit) use ($request) {
        $kitSubcats = json_decode($kit->sub_category_id, true);
        if (is_string($kitSubcats)) {
            $kitSubcats = json_decode($kitSubcats, true);
        }

        if (!empty($request->subcategories)) {
            if (!is_array($kitSubcats) || empty(array_intersect($request->subcategories, $kitSubcats))) {
                return false;
            }
        }

        if (!empty($request->variants) && is_array($request->variants)) {
            $variantData = json_decode($kit->variant_datas, true);
            if (!is_array($variantData)) return false;

            foreach ($request->variants as $variantId => $variableIds) {
                if (!is_array($variableIds) || empty($variableIds)) continue;

                $variantBlock = collect($variantData)->firstWhere('variant_id', (string) $variantId);
                if (!$variantBlock || empty($variantBlock['variables'])) return false;

                $kitVariableIds = collect($variantBlock['variables'])
                    ->pluck('variable_id')
                    ->map(fn($id) => (string) $id)
                    ->toArray();

                if (empty(array_intersect($variableIds, $kitVariableIds))) {
                    return false;
                }
            }
        }

        return true;
    })->values();

    // Attach subcategory names
    foreach ($kits as $kit) {
        $subcatIds = json_decode($kit->sub_category_id, true);
        if (is_string($subcatIds)) {
            $subcatIds = json_decode($subcatIds, true);
        }

        $kit->subcategory_names = collect($subcatIds)
            ->map(fn($id) => $subcategoriesMap[$id] ?? null)
            ->filter()
            ->values()
            ->toArray();
    }

    // Apply name search
    if ($cus_fill) {
        $kits = $kits->filter(function ($kit) use ($cus_fill) {
            return stripos($kit->marketing_kit_name, $cus_fill) !== false;
        })->values();
    }

    // Total and pagination
    $totalItems = $kits->count();
    $totalPages = ceil($totalItems / $perPage);

    // Apply pagination
    $kits = $kits->slice($offset, $perPage)->values();
    // return $kits;
    return view('content.marketing_management.manage_marketing_kit.marketing_kit', [
        'categories'  => $categories,
        'Variantdata' => $Variantdata,
        'kits'        => $kits,
        'perpage'     => $perPage,
        'cus_fill'    => $cus_fill,
        'pagination'  => [
            'current_page' => $page,
            'total_pages'  => $totalPages,
            'total_items'  => $totalItems,
            'perPage'      => $perPage,
        ]
    ]);
}

   public function getcategories()
    {
    return MarketingKitCategoryModel::where('sno', $subcategoryId)->where('status',0)->get(['sno', 'category_name']);

  }
  public function getSubcategories($categoryId)
  {
      return MarketingKitSubCategoryModel::where('marketing_category_id', $categoryId)->where('status',0)->get(['sno', 'marketing_subcategory_name']);
  }

  public function getVariables($subcategoryId)
  {
      return VariableModel::where('sno', $subcategoryId)->where('status',0)->get(['sno', 'color_name','color_code','width','height','variable']);
  }
  public function MarketingKitAdd(Request $request)
  {
      $validated = $request->validate([
          'marketing_kit_name' => 'required|string|max:255',
          'category_id' => 'required|integer',
          'sub_category_id' => 'required',
          'file_type' => 'required',
      ]);
    // return $request->all();


    //   $fileName = '';

    //   if ($request->hasFile('marketing_attachments')) {
    //     $file = $request->file('marketing_attachments');
    //     $fileName = time() . '_' . $file->getClientOriginalName();
    //     $destinationPath = public_path('marketing_kits');
    //     $file->move($destinationPath, $fileName);

    //     $filePath = $destinationPath . '/' . $fileName;
    //     $apiKey = '5c67a80e923be51253e2216e814b1e8a0bfff34d'; // Ensure this is valid

    //     $response = Http::attach(
    //         'image', // field name
    //         file_get_contents($filePath), // actual file content
    //         $fileName // file name
    //     )->asMultipart()->post('https://app.imagify.io/api/upload/', [
    //         [
    //             'name' => 'data',
    //             'contents' => json_encode([
    //                 'ultra' => true,
    //                 'resize' => ['width' => 800], // optional resize
    //             ]),
    //         ],
    //         [
    //             'name' => 'key',
    //             'contents' => $apiKey,
    //         ]
    //     ]);

    //     $data = json_decode($response->body(), true);

    //     if (isset($data['success']) && $data['success']) {
    //         $optimizedUrl = $data['data']['image'];
    //         $optimizedContent = file_get_contents($optimizedUrl);
    //         file_put_contents($filePath, $optimizedContent);
    //     } else {
    //         \Log::error('Imagify compression failed', [
    //             'error' => $data['message'] ?? 'Unknown error',
    //             'response' => $data,
    //         ]);
    //     }
    // }


     $fileName = null;


     if ($request->source_type === 'upload' && $request->hasFile('marketing_attachments')) {
          $file = $request->file('marketing_attachments');
          $fileName = time() . '_' . $file->getClientOriginalName();
          $destinationPath = public_path('marketing_kits');
          $file->move($destinationPath, $fileName);
      
          $filePath = $destinationPath . '/' . $fileName;
      
          // Check if the uploaded file is an image
          $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
          $fileMimeType = mime_content_type($filePath);
      
          if (in_array($fileMimeType, $allowedMimeTypes)) {
              // Compress image using Imagify
              $apiKey = '5c67a80e923be51253e2216e814b1e8a0bfff34d'; // replace with your actual API key
      
              $response = Http::withHeaders([
                  'Authorization' => 'token ' . $apiKey,
              ])->attach(
                  'image',
                  file_get_contents($filePath),
                  $fileName
              )->asMultipart()->post('https://app.imagify.io/api/upload/', [
                  [
                      'name' => 'data',
                      'contents' => json_encode([
                          'aggressive' => true,
                      ]),
                  ]
              ]);
      
              $data = json_decode($response->body(), true);
      
              if (isset($data['success']) && $data['success']) {
                  $optimizedUrl = $data['image'];
                  $optimizedContent = file_get_contents($optimizedUrl);
                  file_put_contents($filePath, $optimizedContent);
              } else {
                  \Log::error('Imagify compression failed', [
                      'error' => $data['detail'] ?? 'Unknown error',
                      'response' => $data,
                  ]);
              }
          } else {
              // Skip Imagify for non-image files
              \Log::info("File is not an image. Skipping compression: {$fileName}");
          }
      }
  

      $fileNamethumbnail = '';
      if ($request->hasFile('marketing_thumbnail')) {
          $fileNamethumbnail = time() . '_' . $request->file('marketing_thumbnail')->getClientOriginalName();
          $destinationPath = public_path('marketing_kits_thumbnail');
          $request->file('marketing_thumbnail')->move($destinationPath, $fileNamethumbnail);
          $path = $fileNamethumbnail;
      }


      // Generate a unique category ID
      $add = MarketingKitModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

      if (!$add) {
        $year = substr(date('y'), -2);
        $marketing_kit_id = 'MK-0001/' . $year;
      } else {
        $data = $add->marketing_kit_id;
        $slice = explode('/', $data);
        $result = preg_replace('/[^0-9]/', '', $slice[0]);
        $next_number = (int)$result + 1;
        $requestId = sprintf('MK-%04d', $next_number);
        $year = substr(date('y'), -2);
        $marketing_kit_id = $requestId . '/' . $year;
      }

    //   return $request->all();
      $kit = new MarketingKitModel();
      $kit->marketing_kit_name = $request->marketing_kit_name;
      $kit->marketing_kit_id = $marketing_kit_id;
      $kit->category_id = $request->category_id;
      $kit->sub_category_id = $request->sub_category_id;
      $kit->file_type = $request->file_type;
      $kit->preview_check = $request->preview_check;
      $kit->download_check = $request->download_check;
      $kit->buy_check = $request->buy_check;
      $kit->delivery_charges = $request->delivery_charges;
      $kit->buy_items = $request->buy_check ? $request->buy_items : null;
      $kit->variant_datas = $request->variant_datas;
      $kit->source_type = $request->source_type;
       if ($request->source_type === 'upload') {
            $kit->marketing_attachments = $fileName;
            $kit->marketing_url = null;
        } else if ($request->source_type === 'url') {
            $kit->marketing_attachments = null;
            $kit->marketing_url = $request->marketing_url;
        }
      $kit->marketing_thumbnail = $fileNamethumbnail;
      $kit->description = $request->description;
      $kit->created_by = auth()->id();
      $kit->updated_by = auth()->id();
      $kit->save();

      // return response()->json(['status' => 'success']);
      return response()->json([
        'status'         => $data['success'] ?? false,
        'original_size'   => $data['data']['original_size'] ?? null,
        'optimized_size'  => $data['data']['optimized_size'] ?? null,
        'saved_bytes'     => $data['data']['saved_bytes'] ?? null,
        'saved_percent'   => $data['data']['saved_percent'] ?? null,
        'message'         => $data['message'] ?? null,
    ]);

  }


  public function MarketingKitList(Request $request) 
   {
    // Step 1: Fetch kits with category name via joi
    $query = MarketingKitModel::where('za_marketing_kit.status', 0)
        ->join('marketing_category', 'za_marketing_kit.category_id', '=', 'marketing_category.sno')
        ->select('za_marketing_kit.*', 'marketing_category.category_name as category_name'); // Add category name

    $kits = $query->get();

    // Step 2: Fetch all subcategories (to map later)
    $subcategoriesMap = MarketingKitSubCategoryModel::pluck('marketing_subcategory_name', 'sno')->toArray(); // [34 => "Posters", ...]

    // Step 3: Filter kits
    $kits = $kits->filter(function ($kit) use ($request) {
        $kitSubcats = json_decode($kit->sub_category_id, true);
        if (is_string($kitSubcats)) {
            $kitSubcats = json_decode($kitSubcats, true);
        }

        if (!empty($request->subcategories)) {
            if (!is_array($kitSubcats) || empty(array_intersect($request->subcategories, $kitSubcats))) {
                return false;
            }
        }

        if (!empty($request->variants) && is_array($request->variants)) {
            $variantData = json_decode($kit->variant_datas, true);
            if (!is_array($variantData)) return false;

            foreach ($request->variants as $variantId => $variableIds) {
                if (!is_array($variableIds) || empty($variableIds)) continue;

                $variantBlock = collect($variantData)->firstWhere('variant_id', (string) $variantId);
                if (!$variantBlock || empty($variantBlock['variables'])) return false;

                $kitVariableIds = collect($variantBlock['variables'])
                    ->pluck('variable_id')
                    ->map(fn($id) => (string) $id)
                    ->toArray();

                if (empty(array_intersect($variableIds, $kitVariableIds))) {
                    return false;
                }
            }
        }

        return true;
    })->values();

    // Step 4: Add subcategory names to each kit
    foreach ($kits as $kit) {
        $subcatIds = json_decode($kit->sub_category_id, true);
        if (is_string($subcatIds)) {
            $subcatIds = json_decode($subcatIds, true);
        }

        $kit->subcategory_names = collect($subcatIds)
            ->map(function ($id) use ($subcategoriesMap) {
                return $subcategoriesMap[$id] ?? null;
            })
            ->filter()
            ->values()
            ->toArray();
    }

    // Step 5: Sort
    if ($request->sort === 'New to Old') {
        $kits = $kits->sortByDesc('sno')->values();
    } elseif ($request->sort === 'Old to New') {
        $kits = $kits->sortBy('sno')->values();
    } else {
        $kits = $kits->sortByDesc('sno')->values();
    }

    return response()->json([
        'kits' => $kits,
        'kit_count' => str_pad($kits->count(), 2, '0', STR_PAD_LEFT)
    ]);
}




  public function softDelete(Request $request)
  {
      $request->validate([
          'id' => 'required|integer',
      ]);

      $kit = MarketingKitModel::where('sno',$request->id)->first();
      if ($kit) {
          $kit->status = 2;
          $kit->updated_by = auth()->id();
          $kit->save();

          return response()->json(['status' => 'success']);
      }

      return response()->json(['status' => 'error', 'message' => 'Kit not found'], 404);
  }

 
  public function MarketingKitView(Request $request, $id)
  {
    $kitsview = MarketingKitModel::where('status', 0)
        ->where('sno', $id)
        ->first();

    if (!$kitsview) {
        return response()->json(['message' => 'Marketing kit not found'], 404);
    }

    // Decode JSON fields
    $buy_items = json_decode($kitsview->buy_items, true) ?? [];
    $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
    $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
    $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];
    $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];

    // Category & Subcategories
    $category = MarketingKitCategoryModel::find($kitsview->category_id);
    $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

    // Color Details
    $colorIds = collect($colorVarients)->pluck('color_id')->unique();
    $colors = VariableModel::whereIn('sno', $colorIds)->where('variable', 'color')->get(['sno', 'color_name', 'color_code']);

    $enrichedColors = collect($colorVarients)->map(function ($color) use ($colors) {
        $info = $colors->firstWhere('sno', $color['color_id']);
        return array_merge($color, [
            'color_name' => $info->color_name ?? null,
            'color_code' => $info->color_code ?? null,
        ]);
    });

    // Size Details
    $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
    $sizes = VariableModel::whereIn('sno', $sizeIds)->where('variable', 'size')->get(['sno', 'width', 'height']);

    $enrichedSizes = collect($sizeVarients)->map(function ($size) use ($sizes) {
        $info = $sizes->firstWhere('sno', $size['size_id']);
        return array_merge($size, [
            'width' => $info->width ?? null,
            'height' => $info->height ?? null,
        ]);
    });

    // Variant + Variables
    $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
    $variableIds = collect($variantDatas)->pluck('variables')->flatten(1)->pluck('variable_id')->unique();

    $variants = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
    $variables = VariablesModel::whereIn('sno', $variableIds)->get(['sno', 'variables_name']);

    $enrichedVariants = collect($variantDatas)->map(function ($variant) use ($variants, $variables) {
        $variantName = $variants->firstWhere('sno', $variant['variant_id'])?->variant_name ?? null;

        $enrichedVars = collect($variant['variables'])->map(function ($var) use ($variables) {
            $variableName = $variables->firstWhere('sno', $var['variable_id'])?->variables_name ?? null;
            return [
                'variable_id' => $var['variable_id'],
                'variable_name' => $variableName,
                'cost' => $var['cost'],
            ];
        });

        return [
            'variant_id' => $variant['variant_id'],
            'variant_name' => $variantName,
            'variables' => $enrichedVars,
        ];
    });

    // Final assembled response
    $kitsview->buy_items = $buy_items;
    $kitsview->category_name = $category?->category_name;
    $kitsview->sub_categories = $subCategories;
    $kitsview->color_details = $enrichedColors;
    $kitsview->size_details = $enrichedSizes;
    $kitsview->variant_details = $enrichedVariants;

    return response()->json($kitsview);
}

  public function MarketingKitEdit(Request $request,$id)
  {
      $kitsview = MarketingKitModel::where('status', 0)
          ->where('sno', $id)
          ->first();

      if (!$kitsview) {
          return response()->json(['message' => 'Marketing kit not found'], 404);
      }

      // Convert JSON fields to arrays
      $buy_items = json_decode($kitsview->buy_items, true) ?? [];
      $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
      $colorVarients = json_decode($kitsview->color_varients, true) ?? [];
      $sizeVarients = json_decode($kitsview->size_varients, true) ?? [];

      // Category name
      $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();

      // Subcategory names
      $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();

      // Color details
      $colorIds = collect($colorVarients)->pluck('color_id')->unique();
      $colors = VariableModel::whereIn('sno', $colorIds)
          ->where('variable', 'color')
          ->get(['sno', 'color_name', 'color_code']);

      // Size details
      $sizeIds = collect($sizeVarients)->pluck('size_id')->unique();
      $sizes = VariableModel::whereIn('sno', $sizeIds)
          ->where('variable', 'size')
          ->get(['sno', 'width', 'height']);

      // Add extra info to the kit object
      $kitsview->buy_items = $buy_items;
      $kitsview->category_name = $category?->category_name;
      $kitsview->sub_categories = $subCategories;
      $kitsview->color_details = $colorVarients;
      $kitsview->size_details = $sizeVarients;

      // Replace color IDs with names
      $enrichedColors = [];

      foreach ($colorVarients as $color) {
          $colorInfo = $colors->firstWhere('sno', $color['color_id']);
          $color['color_name'] = $colorInfo->color_name ?? null;
          $color['color_code'] = $colorInfo->color_code ?? null;
          $enrichedColors[] = $color;
      }

      $kitsview->color_details = $enrichedColors;

      // Replace size IDs with dimensions
      $enrichedSizes = [];

      foreach ($sizeVarients as $size) {
          $sizeInfo = $sizes->firstWhere('sno', $size['size_id']);
          $size['width'] = $sizeInfo->width ?? null;
          $size['height'] = $sizeInfo->height ?? null;
          $enrichedSizes[] = $size;
      }

      $kitsview->size_details = $enrichedSizes;

      return response()->json($kitsview);
  }
 
 
 
  public function GetMarketingPayment(Request $request)
  {
    $marketing_kit_id = $request->marketing_kit_id;
    $add_to_cart_id   = $request->add_to_cart_id; // maybe or not it will come one or two add_to_cart_items ?
    $user_id   = auth()->id();
    $branch_id = $request->user()->branch_id;
     if(!empty($add_to_cart_id)){
      $cartItems = MarketingKitCartModel::where('branch_id', $branch_id)->where('sno', $add_to_cart_id)
      ->where('user_id', $user_id)
      ->where('status', 0)
      ->get();
      //we will do after the else condition finished okay
     }else{
      $kitsview = MarketingKitModel::where('status', 0)
          ->where('sno', $marketing_kit_id)
          ->first();

      if (!$kitsview) {
          return response()->json(['message' => 'Marketing kit not found'], 404);
      }

      // Convert JSON fields to arrays
        $buy_items = json_decode($kitsview->buy_items, true) ?? [];
        $subCategoryIds = json_decode($kitsview->sub_category_id, true) ?? [];
        $variantDatas = json_decode($kitsview->variant_datas, true) ?? [];
        
        // Category name
        $category = MarketingKitCategoryModel::where('sno', $kitsview->category_id)->first();
        
        // Subcategory names
        $subCategories = MarketingKitSubCategoryModel::whereIn('sno', $subCategoryIds)->get();
        
        // Fetch variable details used in variants
        $allVariableIds = collect($variantDatas)
            ->pluck('variables')
            ->flatten(1)
            ->pluck('variable_id')
            ->unique();
        $variantIds = collect($variantDatas)->pluck('variant_id')->unique();
        $variantMasters = VariantModel::whereIn('sno', $variantIds)->get(['sno', 'variant_name']);
        $variableDetails = VariablesModel::whereIn('sno', $allVariableIds)->get([
            'sno', 'variables_name'
        ]);
        
        // Enrich variant_datas
        $enrichedVariants = [];
        foreach ($variantDatas as $variant) {
            $enrichedVariables = [];
        
            foreach ($variant['variables'] ?? [] as $variable) {
                $varInfo = $variableDetails->firstWhere('sno', $variable['variable_id']);
                $enrichedVariables[] = [
                    'variable_id' => $variable['variable_id'],
                    'cost'        => $variable['cost'],
                    'name'        => $varInfo->variables_name ?? null,
                ];
            }
        
           $variantMaster = $variantMasters->firstWhere('sno', $variant['variant_id']);

            $enrichedVariants[] = [
                'variant_id'   => $variant['variant_id'],
                'variant_name' => $variantMaster?->variant_name,
                'variables'    => $enrichedVariables
            ];
        }
        
        // Attach to response object
        $kitsview->buy_items       = $buy_items;
        $kitsview->category_name   = $category?->category_name;
        $kitsview->sub_categories  = $subCategories;
        $kitsview->variant_datas   = $enrichedVariants;
        
        // Remove these legacy static keys:
        unset($kitsview->color_varients, $kitsview->size_varients);
        unset($kitsview->color_details, $kitsview->size_details);
        
        // Filter out buy_items already in cart
        $filtered_buy_items = [];
        
        foreach ($buy_items as $item) {
            $exists = MarketingKitCartModel::where([
                'user_id'         => $user_id,
                'branch_id'       => $branch_id,
                'marketing_kit_id'=> $kitsview->sno,
                'buy_item_id'     => $item['index_id'],
                'status'          => 0
            ])->exists();
        
            if (!$exists) {
                $filtered_buy_items[] = $item;
            }
        }
        
        $kitsview->buy_items = $filtered_buy_items;
        return response()->json($kitsview);
     }


  }
  


  public function MarketingKitFilterList() 
  {
    $categories = MarketingKitCategoryModel::where('status', 0)->get(['sno', 'category_name']);

    $subCategories = MarketingKitSubCategoryModel::where('status', 0)
        ->get(['sno', 'marketing_category_id', 'marketing_subcategory_name']);

    // Count marketing kits per subcategory
    $kits = MarketingKitModel::where('status', 0)->get(['sub_category_id']);

    $subcatCounts = [];

    foreach ($kits as $kit) {
        $subcatIds = json_decode($kit->sub_category_id, true);
        if (is_string($subcatIds)) $subcatIds = json_decode($subcatIds, true);

        if (is_array($subcatIds)) {
            foreach ($subcatIds as $subId) {
                if (!isset($subcatCounts[$subId])) $subcatCounts[$subId] = 0;
                $subcatCounts[$subId]++;
            }
        }
    }

    // Add count to each subcategory
    $subCategories = $subCategories->map(function ($sub) use ($subcatCounts) {
        $sub->kit_count = $subcatCounts[$sub->sno] ?? 0;
        return $sub;
    });

    $variantList = VariantModel::where('status', 0)->get(['sno', 'variant_name']);
    $variableList = VariablesModel::where('status', 0)->get(['sno', 'variant_id', 'variables_name']);

    return response()->json([
        'categories' => $categories,
        'subcategories' => $subCategories,
        'variants' => $variantList,
        'variables' => $variableList,
    ]);
}


 
 

  

  

}
