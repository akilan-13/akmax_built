<?php

namespace App\Http\Controllers\customer_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CustomerModel;
use App\Models\ManageIssueModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class ManageIssue extends Controller
{
    public function index(Request $request){

        $branch_id = $request->user()->branch_id;

        $customers = CustomerModel::where('status', '!=', 2)->where('branch_id', $branch_id)->get();
        $staffs = StaffModel::where('status', '!=', 2)->where('branch_id', $branch_id)->get();

        $issues = ManageIssueModel::where('et_manage_issue.branch_id', $branch_id)
        ->select('et_manage_issue.*', 'et_customer.cus_name', 'et_customer.customer_id', 'et_staff.staff_name', 'et_staff.staff_image')
        ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_issue.customer_id')
        ->leftJoin('et_staff', 'et_staff.sno', '=', 'et_manage_issue.assign_staff_id')
        ->orderBy('et_manage_issue.sno', 'desc')
        ->get();

        return view('content.customer_management.manage_issue', compact('customers', 'staffs', 'issues'));
    }

    public function Create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'issue_reason' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 422,
                'message' => 'Incorret Input Field Format',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null
            ], 422);
        }

        $user_id = $request->user()->user_id;
        $branch_id = $request->user()->branch_id;


        $CREATE = new ManageIssueModel();
        $CREATE->branch_id = $branch_id;
        $CREATE->customer_id = $request->customer_id;
        $CREATE->assign_staff_id = $request->assign_staff_id;
        $CREATE->attend_staff_id = $request->attend_staff_id;
        $CREATE->issue_date = Carbon::parse($request->issue_date)->format('Y-m-d H:i:s');
        $CREATE->issue_reason = $request->issue_reason;
        $CREATE->created_by = $user_id;
        $CREATE->updated_by = $user_id;
        $CREATE->save();

        if ($CREATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Issue Added Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Issue Creation Failed'
            ]);
            return redirect()->back();
        }
    }

    public function complete_issue(Request $request){

        $sno = $request->complete_id;
        $user_id = $request->user()->user_id;
        
        $UPDATE = ManageIssueModel::where('sno', $sno)->where('status', '!=', 1)->first();
        $UPDATE->issue_close_date = Carbon::parse($request->complete_date)->format('Y-m-d H:i:s');
        $UPDATE->solution = $request->solution;
        $UPDATE->updated_by = $user_id;
        $UPDATE->status = 1;
        $UPDATE->update();

        if ($UPDATE) {
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'Issue Closed Successfully'
            ]);
            return redirect()->back();
        } else {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Issue Closing Failed'
            ]);
            return redirect()->back();
        }
    }

    public function View($id = ''){
        $data = ManageIssueModel::where('et_manage_issue.sno', $id)
            ->select(
                'et_manage_issue.*',
                'et_customer.cus_name',
                'et_customer.customer_id',
                'assign_staff.staff_name as assign_staff_name',
                'assign_staff.staff_image as assign_staff_image',
                'attend_staff.staff_name as attend_staff_name',
                'attend_staff.staff_image as attend_staff_image',
                'et_job_position.job_position_name'
                )
            ->leftJoin('et_customer', 'et_customer.sno', '=', 'et_manage_issue.customer_id')            
            ->leftJoin('et_staff as assign_staff', 'assign_staff.sno', '=', 'et_manage_issue.assign_staff_id')
            ->leftJoin('et_staff as attend_staff', 'attend_staff.sno', '=', 'et_manage_issue.attend_staff_id')
            ->leftJoin('et_job_position', 'et_job_position.sno', '=', 'attend_staff.position_role')
            ->first();

        if($data){
            return response([
                'status' => 200,
                'message' => 'Data Fetched Successfully!',
                'error_msg' => null,
                'data' => $data
            ], 200);
        } else {
            return response([
                'status' => 404,
                'message' => 'Data Fetched Unsuccessfull!',
                'error_msg' => null,
                'data' => null
            ], 404);
        }
    }
}
