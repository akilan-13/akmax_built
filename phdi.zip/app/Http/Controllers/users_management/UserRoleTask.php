<?php

namespace App\Http\Controllers\users_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\UserRoleExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
class UserRoleTask extends Controller
{
 public function index()
{
    // Step 1️⃣: Get all exams and map counts per role
    $examData = \DB::table('et_manage_exam')->get();

    $examCounts = [];
    foreach ($examData as $exam) {
        $roles = json_decode($exam->role_id, true);
        if (is_array($roles)) {
            foreach ($roles as $rId) {
                $rId = (int)$rId;
                if (!isset($examCounts[$rId])) {
                    $examCounts[$rId] = 0;
                }
                $examCounts[$rId]++;
            }
        }
    }

    // Step 2️⃣: Build userRole data (same as before)
    $userRole = \DB::table('et_user_role')
    ->where('et_user_role.status', '!=', 2)
    ->leftJoin('et_user_role as parent_role', 'et_user_role.user_role_id', '=', 'parent_role.sno')
    ->leftJoin('et_user_role_permission', 'et_user_role_permission.role_id', '=', 'et_user_role.sno')
    ->leftJoin('et_staff', 'et_staff.role_id', '=', 'et_user_role.sno')
    ->select(
        'et_user_role.sno',
        'et_user_role.role_id',
        'et_user_role.role_name',
        'et_user_role.map_under',
        'et_user_role.user_role_id',
        'et_user_role.status',
        'et_user_role_permission.status as permission_status',
        \DB::raw('COUNT(DISTINCT CASE WHEN et_staff.sno > 0 AND et_staff.status = 0 THEN et_staff.sno END) AS staff_count'),
        \DB::raw('COALESCE(MAX(CASE WHEN et_staff.status = 0 THEN 1 ELSE 0 END), 0) AS role_status'),
        'parent_role.role_name as parent_role_name'
    )
    ->groupBy([
        'et_user_role.sno',
        'et_user_role.role_id',
        'et_user_role.role_name',
        'et_user_role.map_under',
        'et_user_role.user_role_id',
        'et_user_role.status',
        'et_user_role_permission.status',
        'parent_role.role_name'
    ])
    ->orderBy('et_user_role.sno', 'ASC')
    ->get();


    // Step 3️⃣: Merge exam counts into userRole collection
    $userRole->transform(function ($item) use ($examCounts) {
        $item->exam_count = $examCounts[$item->sno] ?? 0;
        return $item;
    });

    // Step 4️⃣: Fetch task counts per role (unchanged)
    $taskCounts = \DB::table('et_task_master')
        ->select('role_id', 'task_type', \DB::raw('COUNT(*) as total'))
        ->groupBy('role_id', 'task_type')
        ->get()
        ->groupBy(function ($item) {
            return (int) $item->role_id;
        });

    $pageConfigs = ['myLayout' => 'default'];

    return view('content.users_management.user_role_task.list', compact('userRole', 'taskCounts', 'pageConfigs'));
}






  public function ExportExcel()
  {
    return Excel::download(new UserRoleExport, 'user-role-export.xlsx'); // Adjust filename and extension as needed
  }
  public function List()
  {
    $user = UserRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'role_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->role_name;
      $map_under = $request->has('map_under') ? 1 : 0;
      $user_role_id       = $request->user_role_id;
      // $user_id            = $request->user()->id;
      $user_id            = $request->user()->user_id;
      $chk = UserRoleModel::where('role_name', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = UserRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $role_id = "UR-0001/" . $year;
        } else {

          $data = $category_check->role_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("UR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $role_id = $request . '/' . $year;
        }


        $add_user = new UserRoleModel();
        $add_user->role_id           = $role_id;
        $add_user->role_name         = Ucfirst($role_name);
        $add_user->map_under         = $map_under;
        $add_user->user_role_id      = $user_role_id;
        $add_user->created_by        = $user_id;
        $add_user->updated_by        = $user_id;

        $add_user->save();

        if ($add_user) {
            // Flash a success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'User Role added Successfully!'
            ]);
        
            // Store role_id and current time in the session
            session([
                'role_id' => $add_user->sno,
                'role_id_set_time' => now(),
            ]);
        
            // Redirect to the users manage add page
            return redirect()->route('users-manage-users_add');
        } else {
            // Flash an error message
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the User Role!'
            ]);
        
            // Redirect back to the previous page
            return redirect()->back();
        }

      }
      
    }
  }

  public function Edit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }

  public function Update($id, Request $request)
  {
    $validator = Validator::make($request->all(), [
        'role_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $role_name    = $request->role_name;
    $map_under    = $request->map_under;
    $user_role_id = $request->user_role_id;

    $upd_user = UserRoleModel::where('sno', $id)->first();

    if (!$upd_user) {
        return response()->json([
            'status'    => 404,
            'message'   => 'User role not found',
            'error_msg' => null,
            'data'      => null,
        ], 404);
    }

    $chk = UserRoleModel::where('role_name', ucwords($role_name))
                        ->where('status', '!=', 2)
                        ->first();

    if ($chk && $chk->sno != $id) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been assigned!',
            'data'      => null,
        ], 200);
    }

    $upd_user->role_name    = ucwords($role_name);
    $upd_user->map_under    = $map_under;
    $upd_user->user_role_id = $user_role_id;
    
    if ($upd_user->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 500,
            'message'   => 'Failed to update user role',
            'error_msg' => 'Something went wrong, please try again',
            'data'      => null,
        ], 500);
    }
}

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
public function edit_task(Request $request) 
{   
    $request->validate([
        'role_id' => 'required|string',       // now string because it's encoded
        'task_type' => 'required|string',
    ]);

    // Decode the values
    $role_id = base64_decode($request->role_id);
    $task_type = base64_decode($request->task_type);

    $tasks = DB::table('et_task_master')
        ->where('role_id', $role_id)
        ->where('task_type', $task_type)
        ->get();
   $roledetails =  UserRoleModel::where('sno', $role_id)->first();
   //   return $tasks;
    return view('content.users_management.user_role_task.edit_task', compact('tasks', 'role_id', 'task_type','roledetails'));
}
  // TaskController.php
  public function updateTasks(Request $request) {
    $request->validate([
        'role_id' => 'required|integer',
        'task_type' => 'required|string',
        'tasks' => 'required|array',
        'tasks.*.task_name' => 'required|string',
        'tasks.*.measurement_metric' => 'required|string',
        'tasks.*.date_or_range' => 'nullable|string',
    ]);

    foreach ($request->tasks as $task) {
        DB::table('et_task_master')->updateOrInsert(
            [
                'role_id' => $request->role_id,
                'task_type' => $request->task_type,
                'task_name' => $task['task_name'],
                'date_or_range' => $task['date_or_range'] ?? null
            ],
            [
                'measurement_metric' => $task['measurement_metric'],
                'updated_by' => auth()->id(),
                'updated_at' => now()
            ]
        );
    }

    return response()->json([
        'status' => true,
        'message' => 'Tasks updated successfully!',
        'redirect_url' => url('/users/user_role_task') // send redirect URL
    ]);
}
  public function importJson(Request $request)
 {
    try {
        $request->validate([
            'file' => 'required|mimes:json|max:2048',
            'role_id' => 'required|integer',
        ]);

        $file = $request->file('file');
        $path = $file->getRealPath();
        $json = json_decode(file_get_contents($path), true);

        if (!$json) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid JSON format.'
            ]);
        }

        $inserted = 0;
        $skipped = 0;

        foreach ($json as $frequency => $tasks) {
            foreach ($tasks as $task) {
                $dateOrRange = $frequency === 'monthly_schedule'
                    ? ($task['date_or_range'] ?? null)
                    : null;

                $taskName = trim($task['task']);
                $metric = $task['measurement_metric'] ?? null;

                // 🔍 Duplicate check (role + task_type + task_name + date_or_range)
                $exists = DB::table('et_task_master')
                    ->where('role_id', $request->role_id)
                    ->where('task_type', $frequency)
                    ->where('task_name', $taskName)
                    ->when($dateOrRange, fn($q) => $q->where('date_or_range', $dateOrRange))
                    ->exists();

                if ($exists) {
                    $skipped++;
                    continue;
                }

                DB::table('et_task_master')->insert([
                    'role_id' => $request->role_id,
                    'task_type' => $frequency,
                    'date_or_range' => $dateOrRange,
                    'task_name' => $taskName,
                    'measurement_metric' => $metric,
                    'created_by' => auth()->id(),
                    'created_at' => now(),
                ]);

                $inserted++;
            }
        }

        return response()->json([
            'status' => true,
            'message' => 'JSON tasks import completed.',
            'role_id' => $request->role_id,
            'summary' => [
                'inserted' => $inserted,
                'skipped' => $skipped,
                'total' => $inserted + $skipped,
            ]
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => $e->getMessage(),
        ]);
    }
}
 public function addTask(Request $request)
 {
    $request->validate([
        'role_id' => 'required',
        'task_type' => 'required',
        'task_name' => 'required|string',
        'measurement_metric' => 'required|string',
    ]);

    try {
        $exists = DB::table('et_task_master')
            ->where('role_id', $request->role_id)
            ->where('task_type', $request->task_type)
            ->where('task_name', $request->task_name)
            ->exists();

        if ($exists) {
            return response()->json(['status' => false, 'message' => 'Duplicate task — already exists!']);
        }

        DB::table('et_task_master')->insert([
            'role_id' => $request->role_id,
            'task_type' => $request->task_type,
            'date_or_range' => $request->task_type === 'monthly_schedule' ? $request->date_or_range : null,
            'task_name' => $request->task_name,
            'measurement_metric' => $request->measurement_metric,
            'created_by' => auth()->id(),
            'created_at' => now(),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Task added successfully!',
            'role_id' => $request->role_id, // <--- add this
        ]);
    } catch (\Exception $e) {
        return response()->json(['status' => false, 'message' => $e->getMessage()]);
    }
}

// TaskController.php
public function getTaskCounts($role_id)
{
    $counts = DB::table('et_task_master')
        ->where('role_id', $role_id)
        ->select('task_type', DB::raw('COUNT(*) as total'))
        ->groupBy('task_type')
        ->pluck('total','task_type');

    return response()->json([
        'status' => true,
        'counts' => $counts
    ]);
}
 public function ViewTask($encryptedId)
{
    $helper = new \App\Helpers\Helpers();
    
    // 🔹 Decrypt the encrypted ID
    $id = $helper->encrypt_decrypt($encryptedId, 'decrypt');

    if (!$id) {
        return redirect()->back()->with('error', 'Invalid request. Unable to decrypt ID.');
    }

    // 🔹 Fetch the task details
    $tasks = DB::table('et_task_master')
        ->where('role_id', $id)
        ->get();
    
    if (!$tasks) {
        return redirect()->back()->with('error', 'Task not found.');
    }

    // 🔹 Fetch the related role
    $roledetails = UserRoleModel::where('sno', $id)->first();

    return view('content.users_management.user_role_task.view_task', compact('tasks', 'roledetails'));
}
public function toggleFavorite(Request $request)
{
    $taskId = $request->task_id;

    $task = DB::table('et_task_master')->where('task_id', $taskId)->first();

    if (!$task) {
        return response()->json(['status' => 'error', 'message' => 'Task not found']);
    }

    $newStatus = $task->favorite ? 0 : 1; // ✅ toggle correctly

    DB::table('et_task_master')->where('task_id', $taskId)->update(['favorite' => $newStatus]);

    return response()->json([
        'status' => 'success',
        'favorite' => $newStatus,
        'task_type' => $task->task_type
    ]);
}



public function toggleAllFavorites(Request $request)
{
    $type = $request->type;
    $favorite = $request->favorite ? 1 : 0;

    DB::table('et_task_master')
        ->where('task_type', $type)
        ->update(['favorite' => $favorite]);

    return response()->json([
        'status' => 'success',
        'message' => $favorite ? 'All tasks favorited!' : 'All favorites removed.'
    ]);
}
public function fetchAssessment(Request $request)
{
    $roleId = $request->role_id;

    $assessments = \DB::table('et_manage_exam')
        ->whereJsonContains('role_id', (string)$roleId)
        ->select('exam_name', 'level_id','duration', 'created_at')
        ->orderBy('created_at', 'desc')
        ->get();

    return response()->json([
        'status' => 'success',
        'data' => $assessments,
    ]);
}


  
  
}