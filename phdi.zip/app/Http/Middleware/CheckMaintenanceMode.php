<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\MaintenanceModeModel;
use Symfony\Component\HttpFoundation\Response;

class CheckMaintenanceMode
{
    public function handle(Request $request, Closure $next): Response
    {
        // Get current route name or URI
        $currentRoute = $request->route()->getName();
        $currentUri = $request->path();
        
        // If no route name, use URI as slug
        $slug = $currentRoute ?: $this->uriToSlug($currentUri);
        
        // $branch_id = auth()->check() ? auth()->user()->branch_id : null;
        
        // if ($branch_id) {
            // Check if this route/slug is in maintenance mode
            $maintenanceRecord = MaintenanceModeModel::where('slug', $slug)
                ->latest('sno')
                ->first();
            
            if ($maintenanceRecord && $maintenanceRecord->status == 1) {
                // Redirect to maintenance page
                return redirect()->route('maintenance_page')->with([
                    'maintenance_slug' => $slug,
                    'maintenance_since' => $maintenanceRecord->maintenance_date
                ]);
            }
        // }
        
        return $next($request);
    }
    
    /**
     * Convert URI to slug format
     */
    private function uriToSlug($uri)
    {
        // Convert URI to slug format (e.g., 'admin/users' -> 'admin-users')
        return str_replace('/', '-', $uri);
    }
}