<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InternCollegeModel extends Model
{
    use HasFactory;

    protected $table = 'et_intern_college';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'college_name',
        'college_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status'
    ];
}
