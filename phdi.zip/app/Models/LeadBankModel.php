<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadBankModel extends Model
{
    use HasFactory;
    public $table      = "et_lead_bank";
    public $primaryKey = 'sno';


    protected $fillable = [
        'branch_id',
        'lead_type',
        'lead_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'transfer_reason', 
        'transfer_comment', 
        'status',
    ];
}
