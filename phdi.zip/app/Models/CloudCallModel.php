<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CloudCallModel extends Model
{
    use HasFactory;

    protected $table = 'et_cloud_call';

    protected $fillable = [
        'call_id',
        'caller_number',
        'state',
        'start_time',
        'end_time',
        'duration',
        'action',
        'log_details',
        'department_name',
        'received_by',
        'audioUrl',
        'audio_file',
        'status',
        'call_app'
    ];
}
