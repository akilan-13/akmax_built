<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalTypeModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'journal_type_id',
        'journal_type_name',
        'journal_bg_color',
        'journal_des',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',

    ];
}
