<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerFeedbackResponseModel extends Model
{
    use HasFactory;
    
    protected $table = "et_customer_feedback_response";
    protected $primaryKey = 'id';

    protected $fillable = [
        'question_id',
        'rating',
        'reference_id',
        'suggestions',
        'submitted_by',
        'submitted_at',
    ];

    public function question()
    {
        return $this->belongsTo(CustomerFeedBackQuestionModel::class, 'question_id', 'sno');
    }
}