<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobRollModel extends Model
{
    use HasFactory;
    public $table      = "et_job_roll";
    public $primaryKey = 'sno';


    protected $fillable = [
        'job_roll_id',
        'job_roll_name',
        'job_roll_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
