<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewTypeModel extends Model
{
    use HasFactory;
    public $table = "et_interview_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'interview_type_id',
        'interview_type_name',
        'interview_type_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
