<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadPotentialModel extends Model
{
    use HasFactory;
    public $table      = 'et_potential_type';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'lead_potential_id',
        'lead_potential_name',
        'potential_type_image',
        'lead_potential_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
