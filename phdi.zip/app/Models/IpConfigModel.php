<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IpConfigModel extends Model
{
    use HasFactory;
    public $table = 'et_ip_config';
    public $primaryKey = 'sno';
    protected $fillable = [
        'branch_type',
        'branch_id',
        'ip_ids',
        'ip_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
