<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrDirectoryModel extends Model
{
    use HasFactory;
    public $table      = 'et_hr_directory';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'hr_directory_id',
        'company_name',
        'branch_status',
        'address',
        'location_url',
        'company_desc',
        'hr_contact_name',
        'hr_contact_phone',
        'hired_count',
        'total_vacancy_count',
        'created_by',
        'updated_by',
        'status',
    ];
}
