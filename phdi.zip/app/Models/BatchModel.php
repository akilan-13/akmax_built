<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchModel extends Model
{
    use HasFactory;
    public $table      = "et_batch";
    public $primaryKey = 'sno';


    protected $fillable = [
        'batch_id',
        'branch_id',
        'batch_name',
        'course_type_id',
        'course_id',
        'slot_id',
        'start_date',
        'end_date',
        'classroom_id',
        'max_students',
        'satff_id',
        'batch_desc',
        'batch_staff',
        'attendance_status',
        'reschedule_start_date',
        'reschedule_end_date',
        'updated_at',
        'updated_by',
        'created_at',
        'created_by',
        'status',
    ];
}
