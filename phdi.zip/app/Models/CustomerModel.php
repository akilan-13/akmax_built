<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerModel extends Model
{
    use HasFactory;
    public $table      = "et_customer";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'customer_id',
        'lead_id',
        'branch_id',
        'cus_name',
        'cus_gender',
        'cus_dob',
        'cus_mobile',
        'country_code',
        'proposal_ids',
        'cus_alternate_mobile',
        'cus_email_id',
        'contact_person',
        'doj',
        'cus_marital_status',
        'course_id',
        'enroll_course_id',
        'enroll_course_type_id',
        'course_mode_id',
        'enroll_course_mode_id',
        'course_type_id',
        'batch_id',
        'enroll_batch_id',
        'country',
        'state',
        'vip',
        'city',
        'address',
        'door_no',
        'pincode',
        'cus_pic',
        'coupon_code_ref',
        'referral_person_name',
        'customer_ref',
        'is_placement',
        'free_shd_count',
        'final_fee',
        'created_by',
        'updated_by',
        'status',
        'drop_refund_id',
        'drop_date',
        'refunded_amount',
        'drop_verified',
        'jumper_skiper',
        'post_sale_check'
    ];
}
