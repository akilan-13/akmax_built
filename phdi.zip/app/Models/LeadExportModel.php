<?php

namespace App\Models;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Collection;

class LeadExportModel implements FromCollection, WithHeadings
{

    public function collection()
    {
        return new Collection([]);
    }

    public function headings(): array
    {
        return [
            'Lead Name*',
            'Mobile No*',
            'Email ID*',
            'Date* (' . date('d-m-Y') . ')',
        ];
    }
}