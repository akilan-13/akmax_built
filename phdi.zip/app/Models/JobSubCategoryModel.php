<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobSubCategoryModel extends Model
{
    use HasFactory;

    public $table      = "et_job_subcategory"; // Set the table name
    public $primaryKey = 'sno'; // Set the primary key column


    // Define fillable attributes
    protected $fillable = [
        'branch_id',
        'job_category_id',
        'job_subcategory_name',
        'job_subcategory_descr',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
