<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseAssigne_model extends Model
{
    use HasFactory;
    public $table      = 'et_branch_course';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'branch_type',
        'branch_id',
        'assign_date',
        'course_type_id',
        'course_id',
        'created_by',
        'created_at',
        'status',
    ];
}
