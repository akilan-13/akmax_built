<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewModel extends Model
{
    use HasFactory;
    public $table = 'et_placement_interview';
    public $primaryKey = 'sno';

    protected $fillable = [
        'placement_interview_id',
        'branch_id',
        'customer_id',
        'job_id',
        'interview_checklist_status',
        'job_salary',
        'job_position',
        'interview_status',
        'created_by',
        'updated_by',
        'created_at',
        'status',
    ];
}
