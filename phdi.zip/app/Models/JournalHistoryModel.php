<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalHistoryModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_history";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'customer_id',
        'service_id',
        'journal_id',
        'submitted_date',
        'submitted_documents',
        'reviewed_date',
        'reviewer_comment',
        'reviewer_document',
        'accepted_date',
        'rejected_date',
        'rejected_reason',
        'publiched_paper',
        'published_url',
        'published_author',
        'published_files',
        'published_date',
        'resubmitted_date',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
    ];
}
