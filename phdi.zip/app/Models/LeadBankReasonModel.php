<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadBankReasonModel extends Model
{
    use HasFactory;
    public $table      = "et_lead_bank_reason";
    public $primaryKey = 'sno';


    protected $fillable = [
        'sno',
        'reason_name',
        'comments_check',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'comments_check',
        'status',
    ];
}
