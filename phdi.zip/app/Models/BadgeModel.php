<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BadgeModel extends Model
{
    use HasFactory;
    public $table      = 'et_badge';
    public $primaryKey = 'sno';

    protected $fillable = [
        'badge_name',
        'award_type',
        'eligibility_count',
        'eligibility_period',
        'st_date',
        'end_date',
        'st_month',
        'end_month',
        'st_year',
        'end_year',
        'image',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
