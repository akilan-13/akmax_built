<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JustDialModel extends Model
{
    use HasFactory;
    public $table      = "et_justdial_lead";
    public $primaryKey = 'sno';


    protected $fillable = [
        'lead_id',
        'lead_name',
        'lead_type',
        'lead_mobile',
        'lead_alternate_mobile',
        'lead_email_id',
        'prefix',
        'registered_date',
        'state',
        'city',
        'area',
        'dnc_mobile',
        'dnc_phone',
        'company',
        'pincode',
        'lead_knowledge_tags',
        'time',
        'branchpin',
        'parentid',
        'updated_at'
    ];
}
