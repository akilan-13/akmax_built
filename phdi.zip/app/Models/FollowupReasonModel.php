<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FollowupReasonModel extends Model
{
    use HasFactory;
    public $table      = "et_followup_reason";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'branch_id',
        'reason_name',
        'comments_check',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
