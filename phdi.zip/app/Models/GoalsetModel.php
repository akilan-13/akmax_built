<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoalsetModel extends Model
{

    use HasFactory;
    public $table = 'et_goalset';
    public $primaryKey = 'sno';

    protected $fillable = [
        'goalset_id',
        'branch_id',
        'schedule_month',
        'department_id',
        'sub_department_id',
        'job_position_id',
        'Registration_count',
        'Business_value',
        'collection_value',
        'harvest_amount',
        'min_harverst_amount',
        'min_students_alloted',
        'max_free_slot',
        'productivity_performance',
        'target_amount',
        'max_slot_alloted_hrs',
        'max_resolved_complaint_hrs',
        'goalset_description',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
