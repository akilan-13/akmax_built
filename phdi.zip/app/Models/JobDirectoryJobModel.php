<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobDirectoryJobModel extends Model
{
    use HasFactory;
    public $table      = 'et_job_directorys_job';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'job_dir_id',
        'company_id',
        'job_name_id',
        'salary',
        'interview_type_id',
        'vacancy_count',
        'job_interview_date',
        'job_link',
        'job_salary',
        'job_description',
        'created_by',
        'updated_by',
        'status',
    ];
}
