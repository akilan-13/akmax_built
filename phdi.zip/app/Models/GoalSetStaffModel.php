<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoalSetStaffModel extends Model
{

    use HasFactory;
    public $table = 'et_goal_set_staff';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'goal_month',
        'goal_date',
        'team_id',
        'department_id',
        'staff_id',
        'conversion',
        'CR',
        'ABV',
        'ACV',
        'avg_call_out',
        'no_of_walk',
        'no_of_followup',
        'working_hours',
        'no_of_post_sale',
        'harvesting_percentage',
        'min_no_of_students',
        'rework',
        'no_of_papers',
        'productions',
        'no_of_reviews',
        'given_links',
        'no_of_placements',
        'mou',
        'reference_sales',
        'conversion_actual',
        'CR_actual',
        'ABV_actual',
        'ACV_actual',
        'avg_call_out_actual',
        'no_of_walk_actual',
        'no_of_followup_actual',
        'working_hours_actual',
        'no_of_post_sale_actual',
        'harvesting_percentage_actual',
        'min_no_of_students_actual',
        'rework_actual',
        'no_of_papers_actual',
        'productions_actual',
        'no_of_reviews_actual',
        'given_links_actual',
        'no_of_placements_actual',
        'mou_actual',
        'reference_sales_actual',
        'goal_completed',
        'status_10x',
        'goalset_percentage',
        'status',
        'created_by',
        'updated_by',
    ];
}
