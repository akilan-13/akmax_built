<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadModel extends Model
{
    use HasFactory;
    public $table      = "et_lead";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'lead_id',
        'branch_id',
        'entity_id',
        'lead_name',
        'lead_mobile',
        'lead_alternate_mobile',
        'lead_email_id',
        'lead_gender',
        'lead_dob',
        'lead_marital_status',
        'country',
        'state',
        'city',
        'address',
        'field',
        'qualification',
        'lead_source_id',
        'lead_type_id',
        'lead_group',
        'lead_question_id',
        'service_id',
        'service_category_id',
        'lead_potential_type_id',
        'university_id',
        'lead_answer',
        'lead_score',
        'lead_comments',
        'lead_knowledge_tags',
        'pages',
        'created_by',
        'updated_by',
        'status',
        'lead_status_id',
        'lead_condition',
        'converted_by',
        'registered_date',
        'drop_reason',
        'internal_reason',
        'drop_comments',
        'spam_comments',
        'internal_comments',
        'internal_status',
        'spam_reason',
        'spam_verified',
        'incoming_count',
        'door_no',
        'pincode',
        'is_qr_discount',
        'outgoing_count',
        'transfer_status',
        'is_potential',
        'is_dead',
        'is_spam',
        'potentail_reason',
        'potential_verify',
        'potential_comments',
        'missed_reject_count'
    ];
}
