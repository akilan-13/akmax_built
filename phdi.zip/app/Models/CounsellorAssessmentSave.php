<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CounsellorAssessmentSave  extends Model
{
    use HasFactory;
    public $table      = "et_counsellor_assessment_save";
    public $primaryKey = 'sno';

    protected $fillable = [
        'lead_id',
        'branch_id',
        'assessment_question_id',
        'category_id',
        'assessment_question_answer',
        'created_by',
        'updated_by',
        'status',
    ];
}
