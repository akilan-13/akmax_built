<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobTimeModel extends Model
{
    use HasFactory;
    public $table      = "et_job_time";
    public $primaryKey = 'sno';


    protected $fillable = [
        'job_time_id',
        'job_time_name',
        'start_time',
        'end_time',
        'job_time_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
