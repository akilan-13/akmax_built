<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalMonitorModel extends Model
{

    use HasFactory;
    public $table = 'et_journal_monitor';
    public $primaryKey = 'sno';
    protected $fillable = [
        'reviewed_document',
        'reviewer_comment',
        'rejected_reason',
        'published_date',
        'paper_name',
        'author_name',
        'published_url',
        'submitted_count',
        'published_document',
        'published_desc',
    ];
}
