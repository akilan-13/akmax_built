<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseQuestionModel extends Model
{
    use HasFactory;
    public $table      = "et_course_question";
    public $primaryKey = 'sno';
    // public $timestamps = false;

    protected $fillable = [
        'course_question_name',
        'course_question_type',
        'course_question_option',
        'created_by',
        'created_at',
        'status',
    ];
}
