<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class IssueNoteModel extends Model
{
    use HasFactory;
    public $table      = 'et_issue_note';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'customer_id',
        'issue',
        'category',
        'priority_level',
        'resolved_type',
        'staff_id',
        'description',
        'attachment',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
