<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class HrDirectoryBranchModel extends Model
{
    use HasFactory;
    public $table      = 'et_hr_directory_branch';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'company_id',
        'main_branch_status',
        'branch_name',
        'branch_location_url',
        'branch_address',
        'branch_desc',
        'branch_hr_name',
        'branch_hr_phone',
        'created_by',
        'updated_by',
        'status',
    ];
}
