<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IntegrationModel extends Model
{
    use HasFactory;
    public $table = "et_integration";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'api_name',
        'api_key',
        'developer_link',
        'image',
        'created_by',
        'updated_by',
        'status',
    ];
}
