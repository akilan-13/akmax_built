<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadQuestionModel extends Model
{
    use HasFactory;
    public $table      = "et_lead_question";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'lead_question_name',
        'lead_question_type',
        'lead_question_option',
        'created_by',
        'created_at',
        'status',
    ];
}
