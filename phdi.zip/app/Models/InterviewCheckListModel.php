<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewCheckListModel extends Model
{
    use HasFactory;
    public $table      = "et_interview_checklist";
    public $primaryKey = 'sno';


    protected $fillable = [
        'interview_checklist_id',
        'interview_checklist_name',
        'interview_checklist_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
