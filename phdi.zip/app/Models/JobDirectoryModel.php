<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class JobDirectoryModel extends Model
{
    use HasFactory;
    public $table      = 'et_job_directory';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'job_directory_id',
        'job_company_id',
        'company_branch_id',
        'interview_date',
        'duration',
        'course_type_id',
        'company_description',
        'job_postion_name',
        'job_salary',
        'interview_type_id',
        'vacancy_count',
        'job_interview_date',
        'job_link',
        'job_descritpion',
        'created_by',
        'updated_by',
        'status',
    ];
}
