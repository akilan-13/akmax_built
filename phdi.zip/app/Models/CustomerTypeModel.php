<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerTypeModel extends Model
{
    use HasFactory;
    public $table      = "et_customer_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'customer_type_id',
        'customer_type_name',
        'customer_type_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
