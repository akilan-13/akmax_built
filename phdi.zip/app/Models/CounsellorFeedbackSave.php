<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CounsellorFeedbackSave  extends Model
{
    use HasFactory;
    public $table      = "et_counsellor_feedback_save";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'lead_id',
        'feedback_question_id',
        'feedback_question_answer',
        'counsellor_id',
        'rating',
        'comments',
        'created_by',
        'updated_by',
        'status',
    ];
}
