<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HotLeadModel extends Model
{
    use HasFactory;
    public $table = 'et_hot_lead';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'branch_id',
        'lead_id',
        'staff_id',
        'startdate',
        'enddate',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
