<?php

namespace App\Models;

use App\Models\EventModel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class EventExports implements FromCollection, WithHeadings
{

    protected $counter = 0;
    // public function collection()
    // {
    //     $leads = LeadModel::select('et_lead.*', 'et_appointment.status as appointment_status', 'et_appointment.appointment_date', 'et_lead_type.lead_type_name', 'et_lead_type.sno as lead_type_id', 'et_lead_source.lead_source_name', 'et_lead_source.sno as lead_source_id')->leftjoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
    //         ->leftjoin('et_appointment', 'et_lead.sno', '=', 'et_appointment.lead_id')
    //         ->join('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')->whereNotIn('et_lead.status', [3, 2])->distinct()->orderBy('sno', 'desc')->get(['sno', 'lead_name', 'lead_mobile', 'lead_dob', 'lead_email_id', 'lead_type_id', 'lead_source_id', 'status']);

    //     return $leads->map(function ($lead) {
    //         $this->counter++;
    //         return [
    //             'S.No' => $this->counter,
    //             'Lead' => $lead->lead_name,
    //             'Mobile' => $lead->lead_mobile,
    //             'DOB' => $lead->lead_dob,
    //             'Email' => $lead->lead_email_id,
    //             'Lead Type' => $lead->lead_type_name, // Assuming leadType relationship exists
    //             'Source' => $lead->lead_source_name, // Assuming leadSource relationship exists
    //             'Status' => $lead->status,
    //         ];
    //     });
    // }
    public function collection()
    {

        // Main query with joins and subquery
        $events = EventModel::select('et_branch.branch_name', 'et_event_type.event_type_name as event_type_name', 'et_event_category.event_category_name as event_category_name', 'et_event.*')
            ->join('et_branch', 'et_event.branch_name_id', '=', 'et_branch.sno')
            ->join('et_event_category', 'et_event.event_category', '=', 'et_event_category.sno')
            ->join('et_event_type', 'et_event.event_type_id', '=', 'et_event_type.sno')
            ->where('et_event.status', '!=', 2)
            ->orderBy('et_event.sno', 'desc')->get();
        $statusMap = [
            0 => 'Active',
            1 => 'Inactive',
            2 => 'Delete',
            3 => 'Number Only',
            4 => 'Customer',
            5 => 'Drop',
        ];
        return $events->map(function ($event) use ($statusMap) {
            $this->counter++;
            return [
                'S.No' => $this->counter,
                'Branch' => $event->branch_name,
                'Event Name' => $event->event_name,
                'Event Category' => $event->event_category_name,
                'Event Type' => $event->event_type_name,
                'Event Date' => $event->event_date,
                'Contact Person' => $event->contact_person_name,
                'Contact Mobile' => $event->contact_person_mob_no,
                'Status' => isset($statusMap[$event->status]) ? $statusMap[$event->status] : 'Unknown',
            ];
        });
    }

    public function headings(): array
    {
        return [
            'S.No',
            'Branch',
            'Event Name',
            'Event Category',
            'Event Type',
            'Event Date',
            'Contact Person',
            'Contact Mobile',
            'Status',
        ];
    }
}
