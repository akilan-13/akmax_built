<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamScheduleModel extends Model
{
    use HasFactory;
    public $table      = 'et_exam_schedule';
    public $primaryKey = 'sno';

    protected $fillable = [
        'job_role_id',
        'schedule_name',
        'duration',
        'unit',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
