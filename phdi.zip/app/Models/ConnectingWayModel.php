<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConnectingWayModel extends Model
{
    use HasFactory;

    public $table = "et_connecting_way";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'connecting_way_name',
        'appointment_mode_id',
        'url_link',
        'connecting_way_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

    public function appointment()
    {
        return $this->belongsTo(AppointmentModeModel::class, 'appointment_mode_id', 'sno');
    }
}
