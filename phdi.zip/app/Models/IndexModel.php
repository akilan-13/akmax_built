<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndexModel extends Model
{
    use HasFactory;
    public $table      = "et_indexing";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'index_id',
        'index_name',
        'index_des',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',

    ];
}
