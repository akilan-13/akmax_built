<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobSkillTagModel extends Model
{
    use HasFactory;
    public $table      = "et_job_skill_tag";
    public $primaryKey = 'sno';


    protected $fillable = [
        'job_skill_tag_id',
        'job_skill_tag_name',
        'job_skill_tag_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
