<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HolidayModel extends Model
{
    use HasFactory;
    public $table      = "et_holiday";
    public $primaryKey = 'sno';


    protected $fillable = [
        'sno',
        'branch_id',
        'hol_date',
        'hol_reason',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}