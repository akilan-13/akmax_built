<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndustryTypeModel extends Model
{
    use HasFactory;
    public $table = "et_industry_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'branch_id',
        'industry_type_id',
        'industry_type_name',
        'industry_type_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
