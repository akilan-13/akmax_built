<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IncentiveModel extends Model
{
    use HasFactory;
    public $table      = "et_incentive";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'role_id',
        'tenx_award',
        'tenx_warrior',
        'eci_count',
        'eci_reward',
        'warrior_reward',
        'second_payment_check',
        'check_accepted_paper',
        'si_incentive_json',
        'si_lead_reward',
        'pi_lead_reward',
        'bi_amount',
        'pi_lead_percent',
        'pi_lead_base',
        'spot_incentive_lead',
        'spot_incentive_month',
        'spot_incentive_day',
        'incentive_month',
        'luxury_incentive',
        'pi_slab_json',
        'ri_amount',
        'spot_incentive_percent',
        'journal_extra_reward',
        'journal_extra_count',
        'double_x_reward',
        'performance_incentive_missed_call',
        'performance_incentive_outgoing_call_count',
        'performance_incentive_reward',
        'perform_incent_attend',
        'created_by',
        'updated_by',
        'status',
        'ceiling',
        'quarterly',
        'twenty_five_percentage',
        'fifty_percentage',
        'six_month',
        'twelve_month',
        'nine_monthadd',
        'twelve_monthadd',
        'overall_year',
        'dynamic',
        'presale',
        'megabonus',
    ];
}