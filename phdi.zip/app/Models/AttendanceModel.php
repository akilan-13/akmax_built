<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceModel extends Model
{
    use HasFactory;
    public $table      = "et_attendance";
    public $primaryKey = 'sno';


    protected $fillable = [
        'attendance_id',
        'branch_id',
        'att_date',
        'staff_id',
        'feedback',
        'feedback_score',
        'customer_id',
        'batch_id',
        'course_id',
        'attendance',
        'total_duration',
        'per_hr_cost',
        'total_cost',
        'created_by',
        'created_at',
        'status',
    ];
}
