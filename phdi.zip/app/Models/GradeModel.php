<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GradeModel extends Model
{
    use HasFactory;
    public $table = "et_grade";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'job_position_id',
        'grade_id',
        'grade_name',
        'grade_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
