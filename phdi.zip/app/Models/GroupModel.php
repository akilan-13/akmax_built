<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GroupModel extends Model
{
    use HasFactory;
    public $table      = "et_group";
    public $primaryKey = 'sno';


    protected $fillable = [
        'group_id',
        'group_name',
        'group_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
