<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GradeTemplateModel extends Model
{

    use HasFactory;
    public $table      = 'et_grade_template';
    public $primaryKey = 'sno';

    protected $fillable = [
        'grade_template_id',
        'branch_id',
        'grade_template_name',
        'grade_name',
        'grade_min_value',
        'grade_max_value',
        'grade_color',
        'grade_logo',
        'grade_desc',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
