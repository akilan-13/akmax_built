<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DailyTaskModel extends Model
{
    use HasFactory;
    public $table = "et_daily_tasks";
    public $primaryKey = 'sno';

    protected $fillable = [
        'service_id',
        'task_id',
        'staff_id',
        'task_date',
        'min_page_or_per',
        'max_page_or_per',
        'checked_checklist',
        'qc_checklist',
        'delivery_checklist',
        'reject_reason',
        'rework_reason',
        'rework_check',
        'task_completed_by',
        'task_completed_date_time',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];

}
