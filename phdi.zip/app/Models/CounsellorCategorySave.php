<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CounsellorCategorySave  extends Model
{
    use HasFactory;
    public $table      = "et_counsellor_category_save";
    public $primaryKey = 'sno';

    protected $fillable = [
        'lead_id',
        'category_question_id',
        'category_id',
        'category_question_type',
        'category_question_answer',
        'score',
        'created_by',
        'updated_by',
        'status',
    ];
}
