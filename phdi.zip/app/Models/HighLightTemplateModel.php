<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HighLightTemplateModel extends Model
{
    use HasFactory;
    public $table      = 'et_highlight_template';
    public $primaryKey = 'sno';

    protected $fillable = [
        'highlight_template_id',
        'branch_id',
        'highlight_name',
        'highlight_subject',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
