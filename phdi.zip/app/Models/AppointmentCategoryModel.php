<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppointmentCategoryModel extends Model
{
    use HasFactory;
    public $table      = "et_appointment_category";
    public $primaryKey = 'sno';

    protected $fillable = [
        'appointment_category',
        'description',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
