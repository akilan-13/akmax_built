<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobRequestModel extends Model
{
    use HasFactory;

    protected $table = 'et_job_request';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'branch_id',
        'job_request_id',
        'job_role_name',
        'min_salary',
        'max_salary',
        'vacancy_count',
        'skill_required',
        'experience',
        'closing_date',
        'job_description',
        'status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
    ];

}
