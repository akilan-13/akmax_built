<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerFeedBackQuestionModel extends Model
{
  use HasFactory;
  public $table      = "et_customer_feedback_question";
  public $primaryKey = 'sno';

  protected $fillable = [
    'question_name',
    'question_type',
    'question_option',
    'created_by',
    'updated_by',
    'status',
  ];
}
