<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GoalSetTeamModel extends Model
{

  use HasFactory;
  public $table = 'et_goal_set_team';
  public $primaryKey = 'sno';

  protected $fillable = [
    'branch_id',
    'team_id',
    'team_goal_month',
    'team_goal_year',
    'department_id',
    'conversion_over_all',
    'conversion_check',
    'conversion_type',
    'cr_over_all',
    'cr_check',
    'cr_type',
    'abv_over_all',
    'abv_check',
    'abv_type',
    'acv_over_all',
    'acv_check',
    'acv_type',
    'avg_call_out_over_all',
    'avg_call_out_check',
    'avg_call_out_type',
    'no_of_walk_over_all',
    'no_of_walk_check',
    'no_of_walk_type',
    'no_of_followup_over_all',
    'no_of_followup_check',
    'no_of_followup_type',
    'working_hours_over_all',
    'working_hours_check',
    'working_hours_type',
    'no_of_post_sale_over_all',
    'no_of_post_sale_check',
    'no_of_post_sale_type',
    'harvesting_percentage_over_all',
    'harvesting_percentage_check',
    'harvesting_percentage_type',
    'min_no_of_students_over_all',
    'min_no_of_students_check',
    'min_no_of_students_type',
    'rework_over_all',
    'rework_check',
    'rework_type',
    'no_of_papers_over_all',
    'no_of_papers_check',
    'no_of_papers_type',
    'productions_over_all',
    'productions_check',
    'productions_type',
    'no_of_reviews_over_all',
    'no_of_reviews_check',
    'no_of_reviews_type',
    'given_links_over_all',
    'given_links_check',
    'given_links_type',
    'no_of_placements_over_all',
    'no_of_placements_check',
    'no_of_placements_type',
    'mou_over_all',
    'mou_check',
    'mou_type',
    'working_hours_actual',
    'rework_actual',
    'reference_sales_over_all',
    'reference_sales_check',
    'reference_sales_type',
    'ten_x',
    'created_by',
    'updated_by',
    'status',
  ];
}
