<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadMetricsModel extends Model
{
    use HasFactory;
    public $table      = 'et_lead_metrics';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'minimum_cr',
        'minimum_cr_color',
        'maximum_cr_color',
        'minimum_abv',
        'minimum_abv_color',
        'maximum_abv_color',
        'minimum_acv',
        'minimum_acv_color',
        'maximum_acv_color',
        'created_by',
        'created_at',
        'status',
    ];
}
