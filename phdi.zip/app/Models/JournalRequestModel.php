<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalRequestModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_request";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'request_name',
        'request_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
