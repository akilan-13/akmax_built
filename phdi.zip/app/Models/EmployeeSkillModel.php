<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeSkillModel extends Model
{
    use HasFactory;
    public $table      = 'et_employee_skill';
    public $primaryKey = 'sno';

    protected $fillable = [
        'employee_skill',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
