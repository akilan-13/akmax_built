<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobRoleTagModel extends Model
{
    use HasFactory;
    public $table      = "et_job_role_tag";
    public $primaryKey = 'sno';


    protected $fillable = [
        'job_role_tag_id',
        'job_role_tag_name',
        'job_role_tag_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
