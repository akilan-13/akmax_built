<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalIndexModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_index";
    public $primaryKey = 'sno';


    protected $fillable = [
        'index_name',
        'index_url',
        'index_desc',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'status',
    ];
}
