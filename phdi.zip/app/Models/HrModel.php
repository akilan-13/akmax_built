<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HrModel extends Model
{
    use HasFactory;

    public $table      = "et_company_hr";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'hr_name',
        'hr_mobile_no',
        'hr_email_id',
        'company_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
