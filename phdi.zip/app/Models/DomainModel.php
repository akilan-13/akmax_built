<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DomainModel extends Model
{
    use HasFactory;
    public $table      = "et_domain";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'domain_id',
        'domain_name',
        'domain_des',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',

    ];
}
