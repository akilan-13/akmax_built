<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalCategoryModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_category";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'journal_category_name',
        'category_des',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
