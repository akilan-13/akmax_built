<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalSubCategoryModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_subcategory";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'journal_subcategoryname',
        'journal_category_name',
        'journal_sub_des',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
