<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseTypeModel extends Model
{
    use HasFactory;
    public $table      = "et_course_type";
    public $primaryKey = 'sno';
    //public $timestamps = false;


    protected $fillable = [
        'course_type_id',
        'course_type_name',
        'last_fees_duration_days',
        'fees_schedule',
        'course_category_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
