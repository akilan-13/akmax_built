<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InternEducationModel extends Model
{
    use HasFactory;
    public $table      = 'et_intern_education';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'education',
        'education_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
