<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JournalBookletModel extends Model
{
    use HasFactory;
    public $table      = "et_journal_booklet";
    public $primaryKey = 'sno';

    protected $fillable = [
        'journal_name',
        'journal_desc',
        'journal_link',
        'domain_id',
        'journal_score',
        'contact_details',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
