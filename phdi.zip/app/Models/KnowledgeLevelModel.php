<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KnowledgeLevelModel extends Model
{
    use HasFactory;
    public $table      = "et_knowledge_level";
    public $primaryKey = 'sno';


    protected $fillable = [
        'knowledge_level_id',
        'knowledge_level_name',
        'bg_color',
        'knowledge_level_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
