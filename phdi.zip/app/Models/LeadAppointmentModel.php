<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadAppointmentModel extends Model
{
    use HasFactory;
    public $table = "et_lead_appointment";
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'lead_appointment_id',
        'lead_id',
        'appointment_category',
        'appointment_date',
        'appointment_reason',
        'department_id',
        'pc_id',
        'staff_id',
        'appt_desc',
        'convo_message',
        'convo_message_score',
        'lead_type',
        'appt_desc',
        'status_reason_message',
        're_appointment_date',
        'appointment_status',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
