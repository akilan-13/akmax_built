<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FreeSlotModel extends Model
{
    use HasFactory;
    public $table = 'et_free_slot';
    public $primaryKey = 'sno';

    protected $fillable = [
        'free_slot_id',
        'branch_id',
        'staff_id',
        'slot_id',
        'course_id',
        'batch_start_date',
        'batch_end_date',
        'shift_time_id',
        'batch_id',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
