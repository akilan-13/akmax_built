<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateTemplateModel extends Model
{
    use HasFactory;
    public $table      = 'et_certificate_template';
    public $primaryKey = 'sno';

    protected $fillable = [
        'certificate_template_id',
        'branch_id',
        'certificate_template_name',
        'certificate_template_file',
        'certificate_template_desc',
        'created_by',
        'created_at',
        'updated_by',
        'status',
    ];
}
