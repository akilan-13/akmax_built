<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BrandModel extends Model
{
    use HasFactory;
    public $table      = "et_brand";
    public $primaryKey = 'sno';


    protected $fillable = [
        'brand_id',
        'brand_name',
        'brand_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
