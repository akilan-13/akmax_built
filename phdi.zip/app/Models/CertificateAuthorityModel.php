<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateAuthorityModel extends Model
{
    use HasFactory;
    public $table      = 'et_certificate_authority';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'batch_id',
        'manage_cert_id',
        'batch_cmpltd_date',
        'req_cert_date',
        'req_accpt_date',
        'cert_genr_date',
        'cert_sent_date',
        'cert_receive_date',
        'total_stud_count',
        'req_stud_count',
        'confirm_stud_count',
        'distr_stud_count',
        'pending_stud_count',
        'certificate_authority_status_id',
        'cert_status_id',
        'student_id',
        'status',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
