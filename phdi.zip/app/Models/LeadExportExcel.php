<?php

namespace App\Models;

use App\Models\BatchModel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class LeadExportExcel implements FromCollection, WithHeadings
{
    protected $branchId;
    protected $filters;
    protected $counter = 0;

    public function __construct($branchId, $filters = [])
    {
        $this->branchId = $branchId;
        $this->filters = $filters; // Store filters for later use
        return $filters;
    }

    public function collection(): Collection
    {

        $query = LeadModel::select(
            'et_lead.sno',
            'et_lead.lead_id',
            'et_lead.lead_mobile',
            'et_lead.registered_date',
            'et_lead.created_at',
            'et_lead.lead_email_id',
            'et_lead.lead_gender',
            'et_lead.lead_dob',
            'et_lead.lead_answer',
            'et_lead.lead_marital_status',
            'et_lead_status.lead_bg_color',
            'et_staff.staff_name',
            'et_staff.nick_name',
            'et_lead.lead_score',
            'et_lead.status',
            'et_lead.lead_condition',
            'et_lead.lead_status_id',
            'et_lead.lead_name',
            'et_lead_type.lead_type_name',
            'et_lead_type.sno as lead_type_id',
            'et_lead_source.lead_source_name',
            'et_lead_source.sno as lead_source_id',
            'et_potential_type.potential_type_name as potential_type_name',
            'et_potential_type.emoji',
            'et_potential_type.emoji_color',
            'latest_appointment.appointment_date',
            DB::raw('COALESCE(latest_appointment.total_app_score, 0) as total_app_score'),
            DB::raw('COALESCE(appointment_counts.total_appointments, 0) as total_appointments')
        )
            ->leftJoin(DB::raw('(SELECT lead_id, status, appointment_date,
          SUM(app_score) OVER (PARTITION BY lead_id) AS total_app_score
          FROM et_appointment
          WHERE (lead_id, appointment_date) IN (
              SELECT lead_id, MAX(appointment_date) AS appointment_date
              FROM et_appointment
              GROUP BY lead_id
          )) AS latest_appointment'), 'et_lead.sno', '=', 'latest_appointment.lead_id')
            ->leftJoin(DB::raw('(SELECT lead_id, COUNT(*) as total_appointments
          FROM et_appointment
          GROUP BY lead_id) AS appointment_counts'), 'et_lead.sno', '=', 'appointment_counts.lead_id')
            ->leftJoin('et_lead_type', 'et_lead.lead_type_id', '=', 'et_lead_type.sno')
            ->leftJoin('et_lead_status', 'et_lead.lead_status_id', '=', 'et_lead_status.sno')
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->leftJoin('et_potential_type', function ($join) {
                $join->on('et_lead.lead_score', '>=', DB::raw('CAST(SUBSTRING_INDEX(et_potential_type.lead_potential_score, "-", 1) AS UNSIGNED)'))
                    ->on('et_lead.lead_score', '<=', DB::raw('CAST(SUBSTRING_INDEX(et_potential_type.lead_potential_score, "-", -1) AS UNSIGNED)'));
            })
            ->whereNotIn('et_lead.status', [3, 2, 6, 5, 7]);

        if (!empty($this->branchId) && $this->branchId != 0) {
            $query->where('et_lead.branch_id', $this->branchId);
        }



        if (!empty($this->filters['lead_type_fill'])) {

            $query->where('et_lead.lead_type_id', $this->filters['lead_type_fill']);
        }
        if (!empty($this->filters['lead_source_fill'])) {
            $query->where('et_lead.lead_source_id', $this->filters['lead_source_fill']);
        }
        if (!empty($this->filters['course_fill'])) {
            $query->whereJsonContains('et_lead.course_id', $this->filters['course_fill'])
                ->whereRaw('JSON_LENGTH(et_lead.course_id) = 1');
        }
        if (!empty($this->filters['potential_type_fill'])) {
            $query->where('et_lead.lead_score', $this->filters['potential_type_fill']);
        }
        if (!empty($this->filters['lead_status_fill'])) {
            $query->where('et_lead.status', $this->filters['lead_status_fill']);
        }
        if (!empty($this->filters['staff_fill'])) {
            $query->where('et_lead.created_by', $this->filters['staff_fill']);
        }


        if (!empty($this->filters['date_filter'] == 'today')) {
            $todayDate = date("Y-m-d");
            $query->whereDate('et_lead.created_at', $todayDate);
        } elseif (!empty($this->filters['date_filter'] == 'week')) {
            $today = date('l');
            if ($today == "Sunday") {
                $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
                $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
                $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $query->whereBetween('et_lead.created_at', [$weekFromDate, $weekToDate]);
        } elseif (!empty($this->filters['date_filter'] == 'monthly')) {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $query->whereBetween('et_lead.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
        } elseif (!empty($this->filters['date_filter'] == 'custom_date')) {
            if (!empty($this->filters['from_date_fillter_textbox']) && !empty($this->filters['to_date_fillter_textbox'])) {
                $fromDate = date('Y-m-d', strtotime($this->filters['from_date_fillter_textbox']));
                $toDate = date('Y-m-d', strtotime($this->filters['to_date_fillter_textbox']));
                $query->whereBetween('et_lead.created_at', [$fromDate, $toDate]);
            } elseif ($this->filters['from_date_fillter_textbox']) {
                $fromDate = date('Y-m-d', strtotime($this->filters['from_date_fillter_textbox']));
                $query->where('et_lead.created_at', '>=', $fromDate);
            } elseif ($this->filters['to_date_fillter_textbox']) {
                $toDate = date('Y-m-d', strtotime($this->filters['to_date_fillter_textbox']));
                $query->where('et_lead.created_at', '<=', $toDate);
            }
        }
        if (!empty($this->filters['fin_yr_fill'])) {
            $helper = new \App\Helpers\Helpers();
            $selected_fin_year = $helper->get_fin_year_by_sno($this->filters['fin_yr_fill']);

            if ($selected_fin_year) {
                $monthsArray = json_decode($selected_fin_year->financial_month, true);

                if (is_array($monthsArray) && !empty($monthsArray)) {
                    $monthConditions = [];

                    foreach ($monthsArray as $month) {
                        if (is_numeric($month) && $month >= 1 && $month <= 12) {
                            $monthConditions[] = [
                                'year'  => date('Y'),
                                'month' => (int) $month,
                            ];
                        }
                    }

                    if (!empty($monthConditions)) {
                        $leads->where(function ($query) use ($monthConditions) {
                            foreach ($monthConditions as $condition) {
                                $query->orWhere(function ($q) use ($condition) {
                                    $q->whereYear('et_lead.created_at', $condition['year'])
                                        ->whereMonth('et_lead.created_at', $condition['month']);
                                });
                            }
                        });
                    }
                }
            }
        }




        $leads = $query->get();
        // dd($leads);


        $statusMap = [
            0 => 'Active',
            1 => 'Inactive',
            2 => 'Delete',
            3 => 'Number only',
            4 => 'Customer',
            5 => 'Drop',
            6 => 'Spam',
        ];


        return collect($leads->map(function ($lead) use ($statusMap,) {
            $this->counter++;

            return [
                'S.No' => $this->counter,
                'Date' => $lead->registered_date,
                'Lead Name' => $lead->lead_name,
                'Lead source' => $lead->lead_source_name,
                'Mobile No' => $lead->lead_mobile,
                'Mail Id' => $lead->lead_email_id,
                'Sales Person' => $lead->staff_name,
                'Status' => $statusMap[$lead->status] ?? 'Unknown'
            ];
        }));
    }

    public function headings(): array
    {
        return [
            'S.No',
            'Date',
            'Lead Name',
            'Lead source',
            'Mobile No',
            'Mail Id',
            'Sales Person',
            'Status',
        ];
    }
    //  public function styles(Worksheet $sheet)
    // {
    //     return [
    //         // Apply bold and color to the first row (headings)
    //         1 => [
    //             'font' => [
    //                 'bold' => true,
    //                 'color' => ['rgb' => 'FFFFFF'], // White text
    //             ],
    //             'fill' => [
    //                 'fillType' => 'solid',
    //                 'startColor' => ['rgb' => 'F40B0B'], // Green background
    //             ],
    //         ],
    //     ];
    // }
}
