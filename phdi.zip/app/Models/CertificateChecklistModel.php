<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateChecklistModel extends Model
{
    use HasFactory;
    public $table      = "et_certificate_checklist";
    public $primaryKey = 'sno';


    protected $fillable = [
        'certificate_checklist_id',
        'certificate_checklist_name',
        'certificate_checklist_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
