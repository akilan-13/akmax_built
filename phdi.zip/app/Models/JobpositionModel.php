<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobpositionModel extends Model
{
  use HasFactory;
  public $table = "et_job_position";
  public $primaryKey = 'sno';

  protected $fillable = [
    'job_position_id',
    'branch_id',
    'external_uuid',
    'department_id',
    'division_id',
    'job_position_name',
    'grade_name',
    'level_name',
    'per_hour_cost',
    'job_position_desc',
    'created_by',
    'created_at',
    'status',
  ];
}
