<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttachmentModel extends Model
{
    use HasFactory;
    public $table      = "et_attachment";
    public $primaryKey = 'sno';


    protected $fillable = [
        'attachment_id',
        'attachment_name',
        'attachment_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
