<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobModel extends Model
{
    use HasFactory;

    public $table      = "et_jobs";
    public $primaryKey = 'sno';


    // Define fillable attributes
    protected $fillable = [
        'branch_id',
        'job_id',
        'job_category_id',
        'job_subcategory_id',
        'company_id',
        'interview_mode_id',
        'salary',
        'vacancy_count',
        'experience',
        'last_apply_date',
        'interview_date',
        'interview_checklist_id',
        'skill_description',
        'interest_student_ids',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}
