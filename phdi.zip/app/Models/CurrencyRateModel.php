<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CurrencyRateModel extends Model
{
    use HasFactory;
    public $table = "et_currency_rates";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'date',
        'date_time',
        'currency_data',
        'created_at',
        'updated_at',
        'status',
    ];
}