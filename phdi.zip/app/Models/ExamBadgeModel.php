<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamBadgeModel extends Model
{
    use HasFactory;
    public $table = 'et_exam_badge';
    public $primaryKey = 'sno';

    protected $fillable = [
        'badge_name',
        'job_id',
        'badge_image',
        'badge_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
