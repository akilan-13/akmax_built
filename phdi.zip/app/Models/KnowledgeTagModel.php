<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KnowledgeTagModel extends Model
{
    use HasFactory;
    public $table      = "et_knowledge_tag";
    public $primaryKey = 'sno';


    protected $fillable = [
        'knowledge_tag_id',
        'knowledge_tag_name',
        'knowledge_tag_level',
        'created_by',
        'created_at',
        'status',
    ];
}
