<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CustomerPlacementModel extends Model
{
    use HasFactory;
    public $table      = 'et_customer_placement';
    public $primaryKey = 'sno';

    protected $fillable = [
        'job_name_id',
        'customer_id',
        'company_id',
        'interview_round',
        'selected',
        'doj',
        'salary',
        'created_by',
        'updated_by',
        'status',
    ];
}
