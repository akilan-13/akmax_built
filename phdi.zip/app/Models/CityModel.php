<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CityModel extends Model
{
    use HasFactory;
    public $table      = "et_cities";
    public $primaryKey = 'id';


    protected $fillable = [
        'cid',
        'name',
        'state_id',
        'created_by',
        'created_at',
        'status'
    ];
}