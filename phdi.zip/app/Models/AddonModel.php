<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddonModel extends Model
{
    use HasFactory;
    public $table      = "et_addon";
    public $primaryKey = 'sno';


    protected $fillable = [
        'addon_id',
        'branch_id',
        'addon_name',
        'payment_type',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status,'
    ];
}
