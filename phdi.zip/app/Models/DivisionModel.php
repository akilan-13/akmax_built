<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DivisionModel extends Model
{
    use HasFactory;
    public $table      = 'et_division';
    public $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'department_id',
        'entity_id',
        'external_uuid',
        'division_name',
        'division_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
