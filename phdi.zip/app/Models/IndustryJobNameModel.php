<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IndustryJobNameModel extends Model
{
    use HasFactory;
    public $table = "et_industry_job_name";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'branch_id',
        'industry_job_name_id',
        'industry_type_id',
        'job_name',
        'job_desc',
        'created_by',
        'updated_by',
        'status',
    ];
}
