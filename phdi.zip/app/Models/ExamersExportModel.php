<?php

namespace App\Models;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Collection;

class ExamersExportModel implements FromCollection, WithHeadings
{

  public function collection()
  {
    return new Collection([]);
  }

  public function headings(): array
  {
    return [
      'Examer Name*',
      'Email ID*',
      'Mobile NO*',
    ];
  }
}
