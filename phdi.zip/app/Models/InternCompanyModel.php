<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InternCompanyModel extends Model
{
    use HasFactory;
    public $table      = 'et_intern_company';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'company',
        'branch_id',
        'email',
        'letter_header',
        'letter_footer',
        'letter_logo',
        'logo_width',
        'logo_height',
        'signature',
        'letter_pad_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
