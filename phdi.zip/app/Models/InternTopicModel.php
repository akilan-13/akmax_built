<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InternTopicModel extends Model {
    use HasFactory;
    public $table      = 'et_topic';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'topic_id',
        'branch_id',
        'title',
        'topic_desc',
        'created_by',
        'created_at',
        'status',
    ];
}