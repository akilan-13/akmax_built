<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebHookHandler\WebhookReceiverController;
use App\Http\Controllers\mobile_apps\CustomerAppController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//Post
Route::post('/webhooks/add_broadcast', [WebhookReceiverController::class, 'broadcastMessage']);
Route::post('/webhooks/new_department', [WebhookReceiverController::class, 'DepartmentHook']);
Route::post('/webhooks/new_division', [WebhookReceiverController::class, 'DivisionHook']);
Route::post('/webhooks/new_job_position', [WebhookReceiverController::class, 'JobPositionHook']);
Route::post('/webhooks/new_staff_add', [WebhookReceiverController::class, 'StaffAddHook']);
Route::post('/webhooks/update_department_uuid', [WebhookReceiverController::class, 'UpdateDepartmentUUID']);
Route::post('/webhooks/update_division_uuid', [WebhookReceiverController::class, 'UpdateDivisionUUID']);
Route::post('/webhooks/update_jobrole_uuid', [WebhookReceiverController::class, 'UpdateJobPositionUUID']);
Route::post('/webhooks/update_staff_uuid', [WebhookReceiverController::class, 'UpdateStaffUUID']);
Route::post('/webhooks/update_userrole_uuid', [WebhookReceiverController::class, 'UpdateUserRoleUUID']);
Route::post('/webhooks/staff_attendance_update', [WebhookReceiverController::class, 'StaffAddAttendanceHook']);
Route::post('/webhooks/staff_attendance_update_essl', [WebhookReceiverController::class, 'StaffAddAttendanceHookEssl']);

Route::post('/webhooks/update_exist_staff', [WebhookReceiverController::class, 'UpdateExistStaff']);
Route::get('/exist-staff-count', [WebhookReceiverController::class, 'existStaffCount']);
Route::get('/exist-staff-list', [WebhookReceiverController::class, 'existStaffList']);

// Get
Route::get('/staff_data_get', [WebhookReceiverController::class, 'StaffData']);
Route::get('/department_data_get', [WebhookReceiverController::class, 'DepartmentList']);
Route::get('/division_data_get', [WebhookReceiverController::class, 'DivisionList']);
Route::get('/job_role_data_get', [WebhookReceiverController::class, 'JobPostionList']);
Route::get('/get_user_role_egc', [WebhookReceiverController::class, 'UserRoleList']);
Route::get('/erp_user_credential_check', [WebhookReceiverController::class, 'userCrendentialCheck']);

// Customer Mobile App

Route::prefix('customer_app')->group(function () {
    Route::post('/login', [CustomerAppController::class, 'customerLogin']);
    Route::post('/verify_otp', [CustomerAppController::class, 'verifyOtp']);
    Route::post('/customer_details', [CustomerAppController::class, 'customerDetails']);
    Route::post('/proposal_data', [CustomerAppController::class, 'proposalData']);
    // Payments
    Route::post('/payment_data', [CustomerAppController::class, 'PaymentData']);
    Route::post('/payment_details', [CustomerAppController::class, 'PaymentDetails']);
    Route::post('/payment_slot_details', [CustomerAppController::class, 'PaymentSlotDetails']);
    // Journal
    Route::post('/service_data', [CustomerAppController::class, 'serviceData']);
    Route::post('/milestone_data', [CustomerAppController::class, 'milestoneData']);
    Route::post('/journal_services', [CustomerAppController::class, 'getJournalServices']);
    Route::post('/journal_list', [CustomerAppController::class, 'getJournalList']);
    Route::post('/journal_history_list', [CustomerAppController::class, 'getJournalHistory']);
    // Chat
    Route::post('/chat_proposal_publication_list', [CustomerAppController::class, 'ChatProposalPublicationList']);
    Route::post('/chat_list', [CustomerAppController::class, 'getChatList']);
    Route::post('/chat_add', [CustomerAppController::class, 'CreateChat']);
    Route::post('/chat_mark_all_read', [CustomerAppController::class, 'markSeen']);
    
});
 