@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Document')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <!-- Users List Table -->
    <div class="card">
        <div class="card-body px-1 py-1">
            <div class="nav-align-right nav-tabs-shadow">

                <div class="tab-content">
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Questionnaire</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">HRM</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Questionnaire
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>

                    <div class="row">


                      <div class="row my-2">
    <div class="col-lg-4 mb-3">
        <label class="text-dark mb-1 fs-6 fw-semibold">Question Name<span class="text-danger">*</span></label>
        <input type="text" class="form-control" placeholder="Enter Question Name" value="EGC Abbreviation ?"/>
    </div>
    <div class="col-lg-4 mb-3">
        <label class="text-dark mb-1 fs-6 fw-semibold">Input Value<span class="text-danger">*</span></label>
        <select id="question_label_value" class="select3 form-select">
            <option value="">Select Input Value</option>
            <option value="text_field">Text Field</option>
            <option value="text_area" selected>Text Area</option>
            <option value="multiple_images">Multiple Images</option>
            <option value="date_field">Date Field</option>
            <option value="check_box">Check Box</option>
            <option value="radio_button">Radio Button</option>
            <option value="list_box">List Box</option>
        </select>
    </div>

    <!-- Dynamic section will be appended here -->
    <div class="col-lg-4 mb-3 mt-3" id="dynamic_input_section"></div>

    <div class="col-lg-2 mb-3 d-flex align-items-center">
        <div class="form-check form-check-inline mt-4">
            <input class="form-check-input cred_check" type="checkbox" />
            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
        </div>
    </div>
</div>

                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <a href="#" class="btn btn-outline-danger text-primary fw-bold waves-effect">Cancel</a>
                            <a href="#" class="btn btn-primary">Update Question</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>



<!-- Label Value Function Start -->
<script>
    function payment_mode_option_label_func() {
        var question_label_value = document.getElementById("question_label_value").value;
        var payment_mode_option_check_box = document.getElementById("payment_mode_option_check_box");
        var payment_mode_option_radio_button = document.getElementById("payment_mode_option_radio_button");
        var payment_mode_option_list_box = document.getElementById("payment_mode_option_list_box");

        if (question_label_value == "check_box") {
            payment_mode_option_check_box.style.display = "block";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        } else if (question_label_value == "radio_button") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "block";
            payment_mode_option_list_box.style.display = "none";
        } else if (question_label_value == "list_box") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "block";
        } else {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        }
    }
</script>
<script>
$(document).ready(function() {
    $('.select3').select2({width: '100%'});

    $('#question_label_value').on('change', function() {
        var type = $(this).val();
        var $container = $('#dynamic_input_section');
        $container.empty(); // clear previous content

        if(type === 'check_box' || type === 'radio_button' || type === 'list_box') {
            var uid = 'dyn-' + Date.now() + '-' + Math.floor(Math.random()*1000);
            var title = type.replace('_',' ').replace(/\b\w/g, l => l.toUpperCase());

            var html = `
            <div class="col-lg-12">
              <div class="accordion" id="accordion-${uid}">
                <div class="accordion-item mb-2">
                  <h2 class="accordion-header" id="heading-${uid}">
                    <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse-${uid}" aria-expanded="false" aria-controls="collapse-${uid}">
                      ${title} Options
                    </button>
                  </h2>
                  <div id="collapse-${uid}" class="accordion-collapse collapse" aria-labelledby="heading-${uid}">
                    <div class="accordion-body px-2">
                      <div class="scroll-y max-h-200px p-3 ${type}-container" style="overflow-x:hidden;">
                        <div class="option-item row mb-2">
                          <div class="col-lg-10">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Option 1 <span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" placeholder="Enter Option 1"></textarea>
                          </div>
                          <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1"></div>
                        </div>
                      </div>
                      <div class="mb-1 mt-1">
                        <button class="btn btn-primary mt-2 add-option-btn">Add Option</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;

            $container.append(html);
        }
    });

    // Add new option dynamically
    $(document).on('click', '.add-option-btn', function(e) {
        e.preventDefault();
        var $container = $(this).closest('.accordion-body').find('.scroll-y');
        var count = $container.find('.option-item').length + 1;

        var html = `
        <div class="option-item row mb-2">
          <div class="col-lg-10">
            <label class="text-dark mb-1 fs-6 fw-semibold">Option ${count} <span class="text-danger">*</span></label>
            <textarea class="form-control" rows="1" placeholder="Enter Option ${count}"></textarea>
          </div>
          <div class="col-lg-2 d-flex justify-content-center align-items-end mb-1">
            <a href="javascript:;" class="btn btn-outline-danger delete-option px-2 py-2"><i class="mdi mdi-delete fs-4"></i></a>
          </div>
        </div>`;
        $container.append(html);
    });

    // Delete option and renumber
    $(document).on('click', '.delete-option', function() {
        var $container = $(this).closest('.scroll-y');
        $(this).closest('.option-item').remove();

        // Renumber all options
        $container.find('.option-item').each(function(index){
            var number = index + 1;
            $(this).find('label').html(`Option ${number} <span class="text-danger">*</span>`);
            $(this).find('textarea').attr('placeholder', `Enter Option ${number}`);
        });
    });
});
</script>

@endsection
