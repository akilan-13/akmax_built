@extends('layouts/layoutMaster')

@section('title', 'Onboarding Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;             
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
/* 
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); } 
        100% { transform: translateY(0px); } 
    } */
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Onboarding Staff</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management 
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Enroll
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2 flex-column">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                    <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
                </a>
                <div class="d-flex justify-content-center align-items-center gap-2 bg-gray-200 py-1 px-2 rounded" >
                    <span class="bg-label-success py-2 px-2 rounded" style="border: 2px solid #000;"></span>
                    <span class="text-black fw-semibold fs-7">Documents Pending</span>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()" 
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between gap-2">
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input class="searchQueryInput" type="text" name="searchQueryInput" placeholder="Enter Staff Name/ Mobile No" value="" />
                            <a href="{{url('hr_enroll/manage_staff')}}" class="searchQuerySubmit" type="submit" name="searchQuerySubmit">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Staff</th>
                            <th class="min-w-100px">Company / Entity</th>
                            <th class="min-w-100px">Dept /Div</th>
                            <th class="min-w-100px">Job Role / 
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date Of Joining">DOJ</span></th>
                            <th class="min-w-100px">Type</th>
                            <th class="min-w-100px">Salary</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-80px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        <tr style="border-left: 5px solid #099DDA;background-color: #D9EDD9;">
                            <td>
                                <div class="d-flex">                                     
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle">
                                         <!-- style="border: 3px solid #099DDA;border-radius: 50%;" data-kt-image-input="true"> -->
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">Prathap K</span>
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                    class="mdi mdi-face-man text-info"></i></span>                                                       
                                        </label>
                                        <div class="d-flex text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name">
                                                Mahendran
                                            </a>
                                            <div class="">
                                                <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                    data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Mob No</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">9685741250</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Email ID</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">prathapk12@gmail.com</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Educational</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">ME</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Elysium Techonologies Pvt Ltd">
                                        Elysium Techonologies Pvt Ltd
                                    </label>

                                    <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Click My Project">
                                        Click My Project
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Production">
                                        Production
                                    </label>
                                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Developer">
                                        Developer
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                                    <span class="fs-7">Junior Developer</span>
                                </label>
                                <div class="d-block">
                                    <span class="fs-8 fw-semibold bg-snapchat text-black badge">29-Sep-2025</span>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-warning fs-7 text-black fw-bold mb-2">
                                   Fresher
                                </label>
                            </td>
                            <td align="right">
                                <label class="badge bg-label-danger fw-bold mb-2">
                                    <span class="mdi mdi-currency-rupee fw-bold fs-8"></span>
                                    <span class="fs-7">12,000</span>
                                </label>
                            </td>
                            <td>
                                <label class="badge bg-whatsapp fs-7 rounded" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    Onboard
                                </label>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Hold</span>
                                    </a>  
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Reject</span>
                                    </a>  
                                </div>
                            </td>
                            <td class="text-end">
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                                        </a>                                        
                                        <a href="{{ url('/hr_enroll/manage_staff/update_staff')}}" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                        </a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_submit_document">
                                            <span><i class="mdi mdi-text-box-plus-outline fs-3 text-black me-1"></i>Submit Document</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr style="border-left: 5px solid #2B1A66;">
                            <td>
                                <div class="d-flex">                                         
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle">
                                         <!-- style="border: 3px solid #2B1A66;border-radius: 50%;" data-kt-image-input="true"> -->
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">Manish Kannan V</span>
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                    class="mdi mdi-face-man text-info"></i></span>                                                       
                                        </label>
                                        <div class="d-flex text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name">
                                                Ajay
                                            </a>
                                            <div class="">
                                                <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                    data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Mob No</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">9632104587</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Email ID</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">manishk45@gmail.com</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Educational</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">BSc</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Elysian Intelligence Business Solution">
                                        Elysian Intelligence Business Solution
                                    </label>

                                    <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="EiBS">
                                        EiBS
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Production">
                                        Production
                                    </label>
                                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Digital Marketing">
                                        Digital Marketing
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                                    <span class="fs-7">Digital Marketer</span>
                                </label>
                                <div class="d-block">
                                    <span class="fs-8 fw-semibold bg-snapchat text-black badge">03-Oct-2025</span>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-warning fs-7 text-black fw-bold mb-2">
                                   Experience 
                                </label>
                                <label class="text-center d-block">
                                    <span class="text-info badge border border-info rounded fs-9">2 Years</span>
                                </label>
                            </td>
                            <td align="right">
                                <label class="badge bg-label-danger fw-bold mb-2">
                                    <span class="mdi mdi-currency-rupee fw-bold fs-8"></span>
                                    <span class="fs-7">25,000</span>
                                </label>
                            </td>
                            <td>
                                <label class="badge bg-github fs-7 rounded" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    Hold
                                </label>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Onboard</span>
                                    </a>  
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Reject</span>
                                    </a>  
                                </div>
                            </td>
                            <td class="text-end">
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                                        </a>                                        
                                        <a href="{{ url('/hr_enroll/manage_staff/update_staff')}}" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr style="border-left: 5px solid #39484F;">
                            <td>
                                <div class="d-flex">                                        
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle">
                                         <!-- style="border: 3px solid #39484F;border-radius: 50%;" data-kt-image-input="true"> -->
                                            <img src="{{ asset('assets/egc_images/auth/user_5.png') }}"
                                                alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">Sathish S</span>
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                    class="mdi mdi-face-man text-danger"></i></span>                                                       
                                        </label>
                                        <div class="d-flex text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name">
                                                Lokesh
                                            </a>
                                            <div class="">
                                                <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                    data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Mob No</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">8745120369</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Email ID</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">sathisssh@gmail.com</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Educational</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">MCA</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Elysium Academy">
                                        Elysium Academy
                                    </label>

                                    <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="EAPL">
                                        EAPL
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Sales">
                                        Sales
                                    </label>
                                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Pre Sales">
                                        Pre Sales
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                                    <span class="fs-7">Sales Executive</span>
                                </label>
                                <div class="d-block">
                                    <span class="fs-8 fw-semibold bg-snapchat text-black badge">07-Oct-2025</span>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-warning fs-7 text-black fw-bold mb-2">
                                   Experience 
                                </label>
                                <label class="text-center d-block">
                                    <span class="text-info badge border border-info rounded fs-9">2 Years</span>
                                </label>
                            </td>
                            <td align="right">
                                <label class="badge bg-label-danger fw-bold mb-2">
                                    <span class="mdi mdi-currency-rupee fw-bold fs-8"></span>
                                    <span class="fs-7">18,000</span>
                                </label>
                            </td>
                            <td>
                                <label class="badge bg-youtube fs-7 rounded" >
                                    Rejected
                                </label>
                            </td>
                            <td class="text-end">
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                                        </a>                                        
                                        <a href="{{ url('/hr_enroll/manage_staff/update_staff')}}" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                        <tr style="border-left: 5px solid #E31C3B;">
                            <td>
                                <div class="d-flex">                                     
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle">
                                            <img src="{{ asset('assets/egc_images/auth/user_1.png') }}"
                                                alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                id="uploadedlogo" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">Mohan Raj H</span>
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                    class="mdi mdi-face-man text-danger"></i></span>                                                       
                                        </label>
                                        <div class="d-flex text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name">
                                                Rajesh
                                            </a>
                                            <div class="">
                                                <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                    data-bs-toggle="dropdown" data-trigger="hover">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Mob No</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">6987451259</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Email ID</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">mohanraaj@gmail.com</div>
                                                    </div>
                                                    <div class="mb-2 d-flex">
                                                        <div class="fw-semibold w-30">Educational</div>
                                                        <div class="mx-1">:</div>
                                                        <div class="fw-bold">MCA</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Elysium Embedded School">
                                        Elysium Embedded School
                                    </label>

                                    <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="EES">
                                        EES
                                    </label>
                                </div>
                            </td>
                            <td>
                                <div class="d-flex align-items-start justify-content-center flex-column">
                                    <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Production">
                                        Production
                                    </label>
                                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Trainer">
                                        Trainer
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-label-info fs-7 fw-bold mb-2 text-truncate" style="color: #046d85 !important;overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"  data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="Senior Soft Skill Trainer">
                                    <span class="fs-7">Senior Soft Skill Trainer</span>
                                </label>
                                <div class="d-block">
                                    <span class="fs-8 fw-semibold bg-snapchat text-black badge">10-Oct-2025</span>
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-warning fs-7 text-black fw-bold mb-2">
                                   Fresher 
                                </label>
                            </td>
                            <td align="right">
                                <label class="badge bg-label-danger fw-bold mb-2">
                                    <span class="mdi mdi-currency-rupee fw-bold fs-8"></span>
                                    <span class="fs-7">15,000</span>
                                </label>
                            </td>
                            <td>
                                <label class="badge bg-linkedin fs-7 rounded" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    Pre-Joining
                                </label>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Onboard</span>
                                    </a>  
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Hold</span>
                                    </a>  
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#">
                                        <span>Reject</span>
                                    </a>  
                                </div>
                            </td>
                            <td class="text-end">
                                <span class="text-end">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                                        </a>                                        
                                        <a href="{{ url('/hr_enroll/manage_staff/update_staff')}}" class="dropdown-item">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->

<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#company_info" aria-controls="company_info" aria-selected="false">
                                    Company Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#designation_info" aria-controls="designation_info" aria-selected="false">
                                    Designation Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_work_info" aria-controls="edu_work_info" aria-selected="false">
                                    Education and Work Info
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Mahesh Kumar</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Nick Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthik</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mobile No</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9874587450</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile No</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9898745120</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Dhana Balan P</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9685859641</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12/A, First Floor,block C, Park Avenue, Cross Street, Vanathi Street, Narayanapuram, Madurai - 625014</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-150 h-auto rounded-circle"
                                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="fw-semibold text-dark fs-6">Documents</label>
                                    <div class="d-flex align-items-center justify-content-start flex-wrap border border-gray-300 gap-3 py-2 rounded">
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                    </div>
                                </div>
                            </div>
                        </div>  
                        <div class="tab-pane fade" id="company_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Elysium Technologies Pvt Ltd</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Entity Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Click My Project</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sales</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Management</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Development Executive</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <label class="fw-bold text-black fs-5"><u>Credentials</u></label>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Teams</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Spark</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Whatsapp</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="designation_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthik</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">15-Sep-2024</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Senior Executive</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">₹ 35,000 /-</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">₹ 145/-</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Managing, Leadership</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Under Graduate</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">BBA</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">MKU</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Work Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Experience</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Manager</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Year</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">2 Years</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Global Corporate</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12-Aug-2022</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">25-Jul-2022</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Submit Document--->
<div class="modal fade" id="kt_modal_submit_document" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Submit Document - <span class="badge bg-whatsapp">Onboard</span></h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mb-3">
                    <div class="col-lg-6 mb-2 border-end">
                        <div class="row">
                            <div class="col-lg-12 d-flex align-items-center px-1 mb-1">                                               
                                <div class="symbol symbol-35px me-2">
                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                        <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                            alt="user-avatar"  class="w-px-100 h-auto rounded-circle"
                                            id="uploadedlogo" />
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <label class="fs-5 fw-bold">Mahesh Kumar</label>
                                    <div class="d-flex text-primary">
                                        <a href="javascript:;" class="text-primary fw-semibold fs-7" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Staff Nick Name">
                                            Karthik
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-domain fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name"></i>
                                <label class="fs-7 fw-semibold text-black">Elysium Techonologies Pvt Ltd</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-office-building fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Entity Name"></i>
                                <label class="fs-7 fw-semibold text-black">Click My Project</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-graph fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name"></i>
                                <label class="fs-7 fw-semibold text-black">Sales</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-file-tree fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Division Name"></i>
                                <label class="fs-7 fw-semibold text-black">Business Development Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-briefcase fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Position"></i>
                                <label class="fs-7 fw-semibold text-black">Senior Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-calendar-badge-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining"></i>
                                <label class="fs-7 fw-semibold text-black">12-Sep-2024</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Documents<span
                            class="text-danger">*</span></label>
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                                <p class="mb-2">Drag & Drop your files here or click to select</p>
                                <input
                                    type="file"
                                    id="fileInput"
                                    name="file_upload[]"
                                    class="d-none"
                                    multiple

                                />
                                <button
                                    type="button"
                                    class="btn btn-outline-primary"
                                    onclick="document.getElementById('fileInput').click()"
                                >
                                    Browse Files
                                </button>
                            </div>
                        <div id="fileList" class="text-muted"></div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary me-3" id="departure_submit_butt" data-bs-dismiss="modal">Submit</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Submit Document-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function () {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
@endsection
