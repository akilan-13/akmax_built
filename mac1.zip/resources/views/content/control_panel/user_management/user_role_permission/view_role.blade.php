@extends('layouts/layoutMaster')

@section('title', 'View Role')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js', 
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">View User Role</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            User Management 
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            User Role Permission
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
       <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="fs-5 text-primary fw-bold mb-2">User Role Details</label>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="row">
                                    <label class="col-5 text-black fs-6 fw-semibold mb-3">User Role</label>
                                    <label class="col-1 text-black fs-6 fw-semibold mb-3">:</label>
                                    <label class="col-6 text-black fs-6 fw-semibold mb-3">CEO</label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <div class="row">
                                    <label class="col-5 text-black fs-6 fw-semibold mb-3">Map Under</label>
                                    <label class="col-1 text-black fs-6 fw-semibold mb-3">:</label>
                                    <label class="col-6 text-black fs-6 fw-semibold mb-3">-</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="fs-5 text-primary fw-bold">Permission Details</label>
                        <div class="row">
                            <div class="col-lg-12 mb-2" id="accessHeadDiv" style="display: none;">
                                <div class="card" style="background-color: #bebebeff !important;">
                                    <div class="card-body">  
                                        <div class="row px-1">
                                            <div class="col-lg-4 ">
                                                <input class="form-check-input " type="radio" name="access_head" id="view_rbh" value="1" checked/>
                                                <label class="text-black fs-6 fw-semibold" for="view_rbh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Regional Branch Head">RBH</label>
                                            </div>
                                            <div class="col-lg-4 ">
                                                <input class="form-check-input " type="radio" name="access_head" id="view_rfh" value="2"  />
                                                <label class="text-black fs-6 fw-semibold" for="view_rfh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Regional Franchises Head">RFH</label>
                                            </div>
                                            <div class="col-lg-4 ">
                                                <input class="form-check-input " type="radio" name="access_head" id="view_gm" value="3" />
                                                <label class="text-black fs-6 fw-semibold" for="view_gm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Global Head">GH</label>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div class="col-lg-12 mb-2 ">
                                <div class="card" style="background-color: #bebebeff !important;">
                                    <div class="card-body">
                                        <div class="row px-1">
                                            <div class="col-lg-6">
                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" checked/>
                                                <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>

                                            </div>
                                            <div class="col-lg-6">
                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" />
                                                <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center py-4">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input select-all" type="checkbox" id="selectAllMain" checked />
                            <label class="text-dark fs-6 fw-semibold" for="selectAllMain">Select All</label>
                        </div>
                    </div>  
                </div>  
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="accordion accordion-danger-solid" id="accordionDashboard">
                            <div class="accordion-item">
                                <h2 class="accordion-header border border-white border-2 rounded" id="headingDashboard" >
                                    <button class="accordion-button collapsed d-flex align-items-center bg-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseDashboard" aria-expanded="false" aria-controls="collapseDashboard">
                                        <input type="checkbox" class="form-check-input me-3 parent-checkbox text-white" checked data-target="#collapseDashboard" name="dashboard">
                                        <span class="fs-6 fw-bold">Dashboard</span>
                                    </button>
                                </h2>
                                <div id="collapseDashboard" class="accordion-collapse collapse" aria-labelledby="headingDashboard" data-bs-parent="#accordionDashboard">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 " name="dashboard_list" checked>
                                                <label class="fs-6">CEO</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 " name="dashboard_add" checked>
                                                <label class="fs-6">Accounts</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 " name="dashboard_edit" checked>
                                                <label class="fs-6">Corporate Admin</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 " name="dashboard_delete" checked>
                                                <label class="fs-6">IT Support</label>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card" style="background-color: #bebebeff !important;">
                                                    <div class="card-body">
                                                        <div class="row px-1">
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" checked/>
                                                                <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" checked />
                                                                <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="accordion accordion-danger-solid" id="accordionSwitchPanel">
                            <div class="accordion-item">
                                <h2 class="accordion-header border border-white border-2 rounded" id="headingSwitchPanel" >
                                    <button class="accordion-button collapsed d-flex align-items-center bg-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSwitchPanel" aria-expanded="false" aria-controls="collapseSwitchPanel">
                                        <input type="checkbox" class="form-check-input me-3 parent-checkbox text-white" checked data-target="#collapseSwitchPanel" name="dashboard">
                                        <span class="fs-6 fw-bold">Switch Portal</span>
                                    </button>
                                </h2>
                                <div id="collapseSwitchPanel" class="accordion-collapse collapse" aria-labelledby="headingSwitchPanel" data-bs-parent="#accordionSwitchPanel">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="management" checked>
                                                <label class="fs-6">Management</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="business">
                                                <label class="fs-6">Business</label>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card" style="background-color: #bebebeff !important;">
                                                    <div class="card-body">
                                                        <div class="row px-1">
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" />
                                                                <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" checked />
                                                                <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>  
            </div>  
       </div>
    </div>
</div>


<script>
  $(document).ready(function() {
      // Hide or show the div based on the selected radio button
      $('input[name="manage_branch"]').on('change', function() {
          if ($('#view_mm').is(':checked')) {
              $('#accessHeadDiv').show(); // Show the div when "Multi Manage" is selected
          } else {
              $('#accessHeadDiv').hide(); // Hide the div when "Single Manage" is selected
          }
      });

      // Trigger change event on page load to check the initial state
      $('input[name="manage_branch"]:checked').trigger('change');
  });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {

        // Handle "select all" (parent checkbox)
        document.querySelectorAll(".parent-checkbox").forEach(function (parent) {
            parent.addEventListener("change", function () {
                const target = document.querySelector(this.dataset.target);
                if (target) {
                    const children = target.querySelectorAll(".child-checkbox");
                    children.forEach(child => child.checked = this.checked);
                }
            });
        });

        // Auto-check parent if any child is checked
        document.querySelectorAll(".child-checkbox").forEach(function (child) {
            child.addEventListener("change", function () {
                const parentCollapse = this.closest(".accordion-collapse");
                if (parentCollapse) {
                    const parentCheckbox = parentCollapse.previousElementSibling.querySelector(".parent-checkbox");
                    const children = parentCollapse.querySelectorAll(".child-checkbox");
                    const allChecked = [...children].every(ch => ch.checked);
                    const anyChecked = [...children].some(ch => ch.checked);

                    parentCheckbox.checked = allChecked;
                    parentCheckbox.indeterminate = !allChecked && anyChecked;
                }
            });
        });

    });
</script>

@endsection
