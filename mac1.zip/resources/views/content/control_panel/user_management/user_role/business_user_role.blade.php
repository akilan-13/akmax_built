@extends('layouts/layoutMaster')

@section('title', 'User Role')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Business User Role</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                User Management
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
             <div>
                <a href="/user_management/user_role" class="btn btn-sm fw-bold btn-primary">
                    <span class="me-2"><i class="mdi mdi-swap-horizontal-bold"></i></span>Management User Role
                </a>
            </div>
        </div>
        <div class="card-body">
            <!-- <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_add_user_role" class="btn btn-sm fw-bold btn-primary">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add User Role
                </a>
            </div> -->
            <div class="row">
                <div class="col-lg-12">
                     <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px">Role</th>
                            <th class="min-w-200px">Map Under</th>
                            <th class="min-w-80px">Status</th>
                            <th class="min-w-50px"><span class="text-end">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                        @if (count($userRole) > 0)
                        @foreach ($userRole as $category)
                            <tr>
                            <td>{{ $category->role_name }}</td>
                            <td>{{ $category->parent_role_name  ?? '-'}}</td>
                            <td>
                            @if($category->sno == '1')
                                <label class="switch switch-square">
                                <input type="checkbox" class="switch-input"    {{ $category->status == 0 ? 'checked' : '' }}  onchange="updateRoleStatus('{{ $category->sno }}', this.checked)" disabled/>
                                <span class="switch-toggle-slider">
                                    <span class="switch-on"></span>
                                    <span class="switch-off"></span>
                                </span>
                                </label>
                                @else
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input"
                                        {{ $category->status == 0 ? 'checked' : '' }}
                                        onchange="updateRoleStatus('{{ $category->sno }}', this.checked)" />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                                @endif
                            </td>
                            <td>
                                @if($category->sno == '1')
                                @else
                                <span class="text-end">
                                   
                                <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_user_role" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit" onclick="populateUpdateModal('{{ $category->sno }}')">
                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                </a>
                                <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_user_role" title="Delete" onclick="confirmDelete('{{ $category->sno }}', '{{ $category->role_name }}', '{{ $category->role_id }}')">
                                    <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                </a>
                                
                                </span>
                                @endif
                            </td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                                <th ></th>
                                <th >No data available</th>
                                <th ></th>
                                <th ></th>
                            </tr>
                            @endif
                        </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>


<!--begin::Modal - Add User Role-->
<div class="modal fade" id="kt_modal_add_user_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create User Role</h3>
        </div>
        <form id="addSlotForm" action="{{ route('add_business_user_role') }}" method="POST" >
        @csrf
        <div class="row">
            <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Company<span
                      class="text-danger">*</span></label>
              <select id="company_id" name="company_id" class="select3 form-select ">
                  <option value="">Select Company Name</option>
                      @if(isset($company_list))
                      @foreach($company_list as $clist)
                      <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                      @endforeach
                      @endif
              </select>
              <div class="text-danger" id="company_id_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Entity<span
                      class="text-danger">*</span></label>
              <select id="entity_id" name="entity_id" class="select3 form-select ">
                  <option value="">Select Entity Name</option>
              </select>
              <div class="text-danger" id="entity_id_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">User Role (from <span id="entity_name"></span>)<span class="text-danger">*</span></label>
              <select id="erp_user_role_name" name="erp_user_role_name" class="select3 form-select ">
                  <option value="">Select User Role</option>
                  <!-- <option value="new_userRole">New</option> -->
              </select>
              <div class="text-danger" id="erp_user_role_name_err"></div>
          </div>
          <input type="hidden" name="user_role_name_hidden" id="user_role_name_hidden">
          <input type="hidden" name="erp_role_id" id="erp_role_id">
          <input type="hidden" name="erp_under_role_id" id="erp_under_role_id">
          <div class="col-lg-12 mb-3 d-none" id="new_userRole">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Role Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="user_role_name" name="role_name"  placeholder="Enter User Role Name" />
            <div class="text-danger" id="user_role_name_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="map_under" id="map_under" onclick="map_under_func();" />
              <label class="text-dark fs-6 fw-semibold">Map Under</label>
            </div>
          </div>
          <div class="col-lg-12 mb-3" id="role_tbox" style="display:none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Role<span class="text-danger">*</span></label>
            <select  class="select3 form-select" id="user_role_id" name="user_role_id">
              <option value="">Select User Role</option>
            </select>
            <div class="text-danger" id="user_role_id_err"></div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="button" id="createBtn" class="btn btn-primary" onclick="AddvalidateForm_grade()" >Create User Role</button>
        </div>
        </form>
      </div>
     
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add User Role-->


<!--begin::Modal - Edit User Role-->
<div class="modal fade" id="kt_modal_edit_user_role" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update User Role</h3>
        </div>
        <form id="updateRoleForm">
        <div class="row">
          <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Role Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="user_role_name_edit" name="role_name" placeholder="Enter User Role Name" value="" />
            <div class="text-danger" id="user_role_name_edit_err"></div>
          </div>
          <div class="col-lg-12 mb-3">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="map_under_edit" id="map_under_edit" onclick="map_under_func_edit();" />
              <label class="text-dark fs-6 fw-semibold">Map Under</label>
            </div>
          </div>
          <div class="col-lg-12 mb-3" id="role_tbox_edit" style="display:none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">User Role<span class="text-danger">*</span></label>
            <select  class="select3 form-select" id="user_role_id_edit" name="user_role_id">
              <option value="">Select User Role</option>
            </select>
            <div class="text-danger" id="user_role_id_edit_err"></div>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-4">
          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" >Update User Role</button>
        </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit User Role-->

<!--begin::Modal - Delete User Role-->
<div class="modal fade" id="kt_modal_delete_user_role" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
        <span id="delete_message"></span>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-danger me-3" onclick="deleterole()">Yes, delete!</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete User Role-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
  /* Customize Toastr notification */
  .toast-success {
            background-color: green;
        }
  /* Customize Toastr notification */
  .toast-error {
      background-color: red;
  }
  
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
  
  let currentCategoryId;

</script>

<script>
  function map_under_func() {
    var map_under = document.getElementById("map_under");
    var role_tbox = document.getElementById("role_tbox");

    if (map_under.checked) {
      role_tbox.style.display = "block";
    } else {
      role_tbox.style.display = "none";
    }
  }

  function map_under_func_edit() {
    var map_under_edit = document.getElementById("map_under_edit");
    var role_tbox_edit = document.getElementById("role_tbox_edit");

    if (map_under_edit.checked) {
      role_tbox_edit.style.display = "block";
    } else {
      role_tbox_edit.style.display = "none";
    }
  }
</script>

<script>
   function AddvalidateForm_grade() {
        var err = 0;

        // Validate knowledge Name
        var user_role_name = document.getElementById("user_role_name").value.trim();
        if (user_role_name === "") {
            document.getElementById('user_role_name_err').innerHTML = 'User Role Name is required...!';
            document.getElementById('user_role_name').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('user_role_name').classList.remove('error_msg');
            document.getElementById('user_role_name_err').innerHTML = '';
        }

        // Validate User Role Select if checkbox is checked
        var map_under = document.getElementById("map_under").checked;
        var user_role_id = document.getElementById("user_role_id").value.trim();
        if (map_under && user_role_id === "") {
            document.getElementById('user_role_id_err').innerHTML = 'User Role is required...!';
            document.getElementById('user_role_id').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('user_role_id').classList.remove('error_msg');
            document.getElementById('user_role_id_err').innerHTML = '';
        }
        if(err>0){
            $("#createbtn").prop('disabled', false);
            return false;
          }else{
              $("#createbtn").prop('disabled', true);
              $('#addSlotForm').submit();
          }
        
    }

  

    function validateUpdateRoleForm() {
          var err = 0;

          var user_role_name = document.getElementById("user_role_name_edit").value.trim();
          if (user_role_name === "") {
              document.getElementById('user_role_name_edit_err').innerHTML = 'User Role Name is required...!';
              document.getElementById('user_role_name_edit').classList.add('error_msg');
              err++;
          } else {
              document.getElementById('user_role_name_edit').classList.remove('error_msg');
              document.getElementById('user_role_name_edit_err').innerHTML = '';
          }

          var map_under = document.getElementById("map_under_edit").checked;
          var user_role_id = document.getElementById("user_role_id_edit").value.trim();
          if (map_under && user_role_id === "") {
              document.getElementById('user_role_id_edit_err').innerHTML = 'User Role is required...!';
              document.getElementById('user_role_id_edit').classList.add('error_msg');
              err++;
          } else {
              document.getElementById('user_role_id_edit').classList.remove('error_msg');
              document.getElementById('user_role_id_edit_err').innerHTML = '';
          }

          return err === 0;
         
    }
       

    $(document).ready(function() {

      $.ajax({
          url: "{{ route('business_user_role') }}",
          type: "GET",
          success: function(response) {
              if (response.status === 200 && response.data) {
                  // Populate the select dropdown with fetched course categories
                  var selectDropdown = $('#user_role_id');
                  selectDropdown.empty();
                  selectDropdown.append($(
                      '<option value="">Select User Role</option>'));
                  response.data.forEach(function(level) {
                    // if (level.sno !== 1) { // Exclude the role with sno == 1
                    //     selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.role_name));
                    // }
                      selectDropdown.append($('<option></option>').attr('value', level.sno)
                          .text(level.role_name));
                  });
              }
          },
          error: function(error) {
              console.error('Error fetching course categories:', error);
          }
      });

      $.ajax({
          url: "{{ route('business_user_role') }}",
          type: "GET",
          success: function(response) {
              if (response.status === 200 && response.data) {
                  // Populate the select dropdown with fetched course categories
                  var selectDropdown = $('#user_role_id_edit');
                  selectDropdown.empty();
                  selectDropdown.append($(
                      '<option value="">Select User Role</option>'));
                  response.data.forEach(function(level) {
                    // if (level.sno !== 1) { // Exclude the role with sno == 1
                    //     selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.role_name));
                    // }
                      selectDropdown.append($('<option></option>').attr('value', level.sno)
                          .text(level.role_name));
                  });
              }
          },
          error: function(error) {
              console.error('Error fetching course categories:', error);
          }
      });

      
    });



function populateUpdateModal(categoryId) {

    currentCategoryId = categoryId;
    fetch(`/business_user_role_edit/${categoryId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                const role = data.data;
                console.log(role);

                // document.getElementById('role_id_edit').value = role.sno;
                document.getElementById('user_role_name_edit').value = role.role_name;
                document.getElementById('map_under_edit').checked = role.map_under === 1;

                if (role.map_under === 1) {
                    document.getElementById('role_tbox_edit').style.display = "block";
                } else {
                    document.getElementById('role_tbox_edit').style.display = "none";
                }
                
                const selectElement = $('#user_role_id_edit');
                selectElement.val(role.user_role_id).trigger('change');


            } else {
                console.error('Error fetching category:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
}
$(document).ready(function() {
    // Initialize the select2 plugin on the select element
    $('#user_role_id_edit').select2();
});

function updateRoleType() {
    const slottypeId = currentCategoryId;
    const newName = document.getElementById('user_role_name_edit').value;
    const map_under = document.getElementById('map_under_edit').checked ? 1 : 0;
    const user_role_id = document.getElementById('user_role_id_edit').value;

    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch(`/business_user_role_update/${slottypeId}`, {
        method: 'POST', // Corrected method for updating
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({
            role_name: newName,
            map_under: map_under,
            user_role_id: user_role_id
        }),
    })
    .then(response => response.json()) // Ensure JSON response is parsed
    .then(data => {
        if (data.status === 200) {
            toastr.success(data.message);
            location.reload(); // Uncomment if you want to refresh after update
        } else {
            toastr.error(data.error_msg || 'Failed to update User Role');
        }
    })
    .catch(error => {
        console.error('Error updating user role:', error);
        toastr.error('An unexpected error occurred. Please try again.');
    });
}


document.getElementById('updateRoleForm').addEventListener('submit', function(event) {
    event.preventDefault();
    if (validateUpdateRoleForm()) {
        updateRoleType();
    }
});

function confirmDelete(id, name, ids) {
    document.querySelector('#kt_modal_delete_user_role .btn-danger').setAttribute(
        'data-id', id);
    $('#delete_message').html('Are you sure you want to delete <br> <b>' + name + '</b> User Role ?');
}

function deleterole() {

    var categoryId = document.querySelector('#kt_modal_delete_user_role .btn-danger').getAttribute('data-id');

    fetch('/business_user_role_delete/' + categoryId, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('User Role Deleted successfully!');
                location.reload();

            } else {

                console.error(data.error_msg);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function updateRoleStatus(categoryId, isChecked) {
    const status = isChecked ? 0 : 1; // Set status based on checkbox state

    fetch(`/business_user_role_status/${categoryId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('User Role status Updated successfully!');
            } else {
                console.error('Error updating User Role status:', data.message);
            }
        })
        .catch(error => {
            console.error('Error updating User Role status:', error);
        });
}

</script>
<script>
    function exportToExcel() {
        // Replace with your server endpoint for exporting to Excel
        let url = '/role/export-excel';

        // Example AJAX call to trigger export
        $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
                // Handle success, such as downloading the file
                window.location.href = url; // Redirect to download link
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error('Error exporting to Excel:', error);
            }
        });
    }

    // Event listener for Excel export button
    $('#export_excel').on('click', function(e) {
        e.preventDefault();
        exportToExcel();
    });
</script>

<script>
    $(document).ready(function() {

        $('#company_id').on('change', function() {
            let company = $(this).val();
            let entity = $('#entity_id');
            entity.empty().append('<option value="">Select Entity</option>');

            if (company) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: { company_id: company },
                    success: function(res) {
                        if (res.status === 200 && res.data) {
                            res.data.forEach(function(row) {
                                entity.append(
                                    $('<option></option>')
                                    .val(row.sno)
                                    .attr('data-baseurl', row.entity_base_url)
                                    .text(row.entity_name)
                                );
                            });
                        }
                    }
                });
            }
        });

        $('#entity_id').on('change', function() {
            let baseurl = $(this).find(':selected').data('baseurl');
            let dropdown = $('#erp_user_role_name');
            let entity_name = $(this).find(':selected').text();
            $('#entity_name').text(entity_name);
            dropdown.empty()
                .append('<option value="">Select Department</option>')
                .append('<option value="new_userRole">New</option>');

            const verify_key='egcsecret2030datagetapierp';

            if (baseurl) {
                $.ajax({
                    url: baseurl + 'api/get_user_role_egc',
                    type: "GET",
                    data:{auth_key:verify_key},
                    success: function(res) {
                        if (res.status === 200 && res.data) {
                            res.data.forEach(function(depart) {
                                dropdown.append(
                                    $('<option></option>')
                                    .val(depart.sno)
                                    .attr('data-userrolename', depart.role_name) // ✅ FIXED
                                    .attr('data-underroleid', depart.user_role_id) // ✅ FIXED
                                    .text(depart.role_name)
                                );
                            });

                            // set next ID if user selects other
                            $('#erp_role_id').val(res.nextId);
                        }
                    }
                });
            }
        });

        $('#erp_user_role_name').on('change', function() {
            if ($(this).val() == 'new_userRole') {
                $('#new_userRole').removeClass('d-none');
            } else {
                $('#new_userRole').addClass('d-none');

                // auto fill hidden name
                let name = $(this).find(':selected').data('userrolename') || $(this).find(':selected').text();
                $('#user_role_name_hidden').val(name);
            }
        });
    });
</script>


@endsection
