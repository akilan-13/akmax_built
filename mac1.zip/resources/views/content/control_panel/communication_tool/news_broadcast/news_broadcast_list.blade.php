@extends('layouts/layoutMaster')

@section('title', 'News Broadcast')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection


@section('content')
<style>
  .scroll-container-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    max-width: 100%;
    overflow: hidden;
  }

  .scroll-container {
    display: flex;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 10px 40px;
    gap: 10px;
    scrollbar-width: none;
  }

  .scroll-container::-webkit-scrollbar {
    display: none;
  }

  .item {
    flex: 0 0 auto;
    text-align: center;
    font-weight: bold;
    border-radius: 8px;
  }

  .scroll-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: #099DDA;
    border: none;
    padding: 10px 10px;
    cursor: pointer;
    z-index: 10;
    border-radius: 4px;
    display: none;
  }

  .scroll-btn.left {
    left: 0;
  }

  .scroll-btn.right {
    right: 0;
  }
</style>
<style>
    .skeleton-loader {
        /*display: flex;*/
        /*flex-direction: row;*/
        /*gap: 10px;*/
    }

    .skeleton-row {
        display: flex;
        flex-direction: row;
        gap: 10px;
    }

    .skeleton {
        width: 100%;
        height: 30px; /* Adjust height as needed */
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s infinite;
    }

    .skeleton-cell {
        flex: 1;
        height: 40px; /* Match the row height */
    }

    @keyframes loading {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
    }
</style>
<style>
   .roles_container{
       max-height:200px;
       overflow-y:scroll;
   }
    .role-badge {
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: background-color 0.3s ease;
    }

    .role-badge:hover {
        background-color: #f0f8ff; /* subtle hover for badge */
    }

    .role-remove-btn {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: none;
        background-color: #ccc;
        color: #fff;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .role-remove-btn:hover {
        background-color: #ff4d4f; /* red on hover */
        transform: scale(1.4) rotate(90deg);
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    
    
     .branch_container{
       max-height:200px;
       overflow-y:scroll;
   }
    .branch-badge {
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: background-color 0.3s ease;
    }

    .branch-badge:hover {
        background-color: #f0f8ff; /* subtle hover for badge */
    }

    .branch-remove-btn {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: none;
        background-color: #ccc;
        color: #fff;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .branch-remove-btn:hover {
        background-color: #ff4d4f; /* red on hover */
        transform: scale(1.4) rotate(90deg);
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
</style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
       
    @endphp
<!-- Users List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">News Broadcast</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Communication Tool
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="/settings/add_news_broadcast" class="btn btn-sm fw-bold btn-primary">
                      <span class="me-2"><i class="mdi mdi-plus"></i></span>Add News Broadcast
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
               <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [6,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Broadcast..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-middle fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-200px">Broadcast</th>
                                <th class="min-w-100px">Start Date /<br>End Date</th>
                                <th class="min-w-100px">Branch /<br>Roles</th>
                                <th class="min-w-50px">Phase</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-50px">Action</th>
                            </tr>
                        </thead>
                        <tbody id="theme-table-body" class="text-black fw-semibold fs-7">
                            <!-- Full row skeleton loader -->
                            <tr class="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
                
              </div>
            </div>
        </div>
    </div>

<div class="modal fade" id="kt_modal_view_theme" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                           <h3 class="text-center mb-4 text-black">View Template <span id="template_name_view"></span></h3>
                    </div>
                   <div class="container">
                       <div id="ent_wrapper_view">
              
                        </div>
                   </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>



<!--begin::Modal - Delete Country-->
<div class="modal fade" id="kt_modal_delete_country" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
      <span id="delete_message"></span>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
        <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal" onclick="deleteFunc()">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Country-->

<!-- ------------------------------------------------------------------------------------------------------------------------- -->

<!-- toaster  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .toast-info {
        background-color: #7239ea;
    }

</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>

 <!-- status Change -->
 
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/news_broadcast_status_change/${Id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Status Updated successfully!');
                loadThemes(1); // Reload themes based on current page
            }
        })
        .catch(error => console.error(error));
    }

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function getPhaseBadge(startDate, endDate) {
        const now = new Date();
        const start = new Date(startDate);
        const end = new Date(endDate);

        if (start > now) {
            return `<span class="badge bg-warning fw-bold text-black fs-6">Scheduled</span>`;
        } else if (start <= now && end >= now) {
            return `<span class="badge bg-success fw-bold text-white fs-6">Live</span>`;
        } else if (end < now) {
            return `<span class="badge bg-danger fw-bold text-white fs-6">Expired</span>`;
        }
        return '';
    }

    function buildRow(item) {
        const isActive = (item.status == 0);
        let roleIds = item.role_ids || [];
        let branchIds = item.branch_ids || [];

        return `
            <tr>
                <td>
                    <label>${item.template_name}</label>
                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="${item.broadcast_message}">
                        <i class="mdi mdi-help-circle text-dark"></i>
                    </a>   
                </td>
                <td>
                    <div><span class="text-success">${formatDate(item.start_date)}</span></div>
                    <div><span class="text-danger">${formatDate(item.end_date)}</span></div>
                </td>
                <td>
                    <a href="#" class="" onclick="OpenPopupBranch('${item.sno}', event)"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch">
                        <i class="ms-1 mdi mdi-graph-outline fs-4"></i>
                    </a>
                    <div class="dropdown-menu py-2 px-4 text-black branch_drop_down_menu_${item.sno} branch_dropdown-menu_class" style="max-width: 300px!important;min-width: 300px!important;">
                        <div class="text-black text-end fw-semibold fs-7 mb-2" style="margin-left: 250px;">
                            <button type="button" class="branch-remove-btn ms-2" title="Close Popup" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                onclick="ClosePopupBranch('${item.sno}')">
                                &times;
                            </button>
                        </div>
                        <div class="fs-6 fw-bold bg-label-success px-2 py-2 rounded mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.template_name}">${item.template_name}</div>
                        <div class="row text-black text-center fw-semibold fs-7 mb-2">
                            <u>Branch Details</u> 
                        </div>
                        <div class="branch_fetch_container"></div>
                        <div class="row text-black text-center fw-semibold fs-7 mb-2">
                            <u>Add Branch</u> 
                        </div>
                        <form class="add_branch_form" method="POST" onsubmit="event.preventDefault(); updateBranch('${item.sno}')">
                            @csrf
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                                    <input type="hidden" id="edit_branch_sno" name="edit_branch_sno" value="${item.sno}">
                                    <input type="hidden" id="branch_id_hide_table${item.sno}" value="${branchIds.join(',')}">
                                    <select class="select3 form-select" id="branch_id_table${item.sno}" name="Add_branch_table[${item.sno}][]" data-placeholder="Select branch" multiple required>
                                    </select>
                                    <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8">
                                <button type="submit" class="btn btn-primary me-3">Update branch</button>
                            </div><br>
                        </form>
                    </div>
                
                
                    <a href="#" class="" onclick="OpenPopup('${item.sno}', event)"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Roles">
                        <i class="ms-1 mdi mdi-account-tie fs-4"></i>
                    </a>
                    <div class="dropdown-menu py-2 px-4 text-black drop_down_menu_${item.sno} dropdown-menu_class" style="max-width: 300px!important;min-width: 300px!important;">
                        <div class="text-black text-end fw-semibold fs-7 mb-2" style="margin-left: 250px;">
                            <button type="button" class="role-remove-btn ms-2" title="Close Popup" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                onclick="ClosePopup('${item.sno}')">
                                &times;
                            </button>
                        </div>
                        <div class="fs-6 fw-bold bg-label-success px-2 py-2 rounded mb-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.template_name}">${item.template_name}</div>
                        <div class="row text-black text-center fw-semibold fs-7 mb-2">
                            <u>Roles Details</u> 
                        </div>
                        <div class="role_fetch_container"></div>
                        <div class="row text-black text-center fw-semibold fs-7 mb-2">
                            <u>Add Roles</u> 
                        </div>
                        <form class="add_role_form" method="POST" onsubmit="event.preventDefault(); sendUserRoles('${item.sno}')">
                            @csrf
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                                    <input type="hidden" id="edit_role_sno" name="edit_role_sno" value="${item.sno}">
                                    <input type="hidden" id="role_id_hide_table${item.sno}" value="${roleIds.join(',')}">
                                    <select class="select3 form-select" id="role_id_table${item.sno}" name="Add_role_table[${item.sno}][]" data-placeholder="Select Role" multiple required>
                                    </select>
                                    <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8">
                                <button type="submit" class="btn btn-primary me-3">Update Role</button>
                            </div><br>
                        </form>
                    </div>
                </td>
                <td>
                    ${getPhaseBadge(item.start_date, item.end_date)}
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${isActive ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)" />
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                    <span class="text-end">
                        <a class="btn btn-icon btn-sm p-0 me-2" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>    
                        <div class="dropdown-menu dropdown-menu-end">
                            <a href="{{ url('/edit_news_broadcast') }}/${item.encrypted_id}" class="dropdown-item" >
                                <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                <span>Edit</span>
                            </a>
                            <a href="#" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_theme" onclick="openViewTheme('${item.sno}')">
                                <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                <span>View</span>
                            </a>
                            <a href="#" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_country" onclick="confirmDelete('${item.sno}', '${item.template_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                                <span>Delete</span>
                            </a>
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }


        function loadThemes(page = 1) {
            const perpage = document.getElementById('perpage').value;
            const search = document.getElementById('search_filter').value;
            const url = `/communication_tool/news_broadcast?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

            // Show skeleton loader and clear old data before fetching new data
            isLoading = true;
            document.getElementById('theme-table-body').innerHTML = ''; // Clear old data
            document.getElementById('theme-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
            $('#skeleton-loader').show(); // Show skeleton loader

            if (abortController.signal) {
                abortController.abort(); // Abort the previous request
            }
            abortController = new AbortController();


            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                res.data.forEach(item => {
                    document.getElementById('theme-table-body').insertAdjacentHTML('beforeend', buildRow(item));
                    initializeSelect2(item.sno);
                });

            updatePagination(res.current_page, res.last_page, res.total, perpage);

                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
        }

        function initializeSelect2(sno) {
            // Initialize select2 only for the dynamically added select elements
            $(`#branch_id_table${sno}`).select2({
                dropdownParent: $(`#branch_id_table${sno}`).closest('.col-lg-12'),
                width: '100%'
            });
            
            $(`#role_id_table${sno}`).select2({
                dropdownParent: $(`#role_id_table${sno}`).closest('.col-lg-12'),
                width: '100%'
            });
        }

         function skeletenRow(){
            return `
                <tr class="skeleton-loader" id="skeleton-loader">
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                </tr>
                `;
        }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

      // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
    function ClosePopup(sno) {
        $('.drop_down_menu_' + sno).removeClass('show');
    }

function removeRole(sno, roleId, btn) {
    fetch("{{ route('broadcast_roles_remove') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ sno: sno, role_id: roleId })
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            // Remove the badge from DOM
            btn.closest('.role-badge').remove();

            // Update assigned roles list by removing the deleted role
            var assignedRoles = ($('#role_id_hide_table' + sno).val() || " ").split(",");
            assignedRoles = assignedRoles.filter(id => id !== String(roleId));

            // Update hidden input with new assigned roles
            $('#role_id_hide_table' + sno).val(assignedRoles.join(','));

            // Repopulate dropdown with updated assigned roles excluded
            populateRoleDropdown(sno, assignedRoles);

            $('.drop_down_menu_'+sno).addClass('show');

            console.log('Role removed successfully');
        } else {
            alert('Failed to remove role.');
        }
    })
    .catch(err => console.error(err));
}

function OpenPopup(sno, event) {
    event.preventDefault(); // Prevent page scroll

    // Close all open popups first
     $('.dropdown-menu_class').removeClass('show');  // Close role popups
    // Ensure that the branch popup is also closed when opening the role popup
    $('.branch_dropdown-menu_class').removeClass('show');
    
    // Now toggle the visibility of the current popup
    let dropdownMenu = $('.drop_down_menu_' + sno);

    // Check if the popup is currently visible
    if (dropdownMenu.hasClass('show')) {
        // If it's open, close it
        dropdownMenu.removeClass('show');
    } else {
        // If it's closed, open it
        dropdownMenu.addClass('show');

        // Update the role values
        $('#edit_role_sno').val(sno);

        // Get existing roles from the hidden input field
        var existingRoles = ($('#role_id_hide_table' + sno).val() || "").split(",");
        populateRoleDropdown(sno, existingRoles);

        // Fetch role data from the server
        $.ajax({
            url: `/role_list_broadcast/${sno}`,
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var roles = response.data.roles;
                    var roleCon = $('.role_fetch_container');
                    var html = '';

                    if (roles) {
                        html += '<div class="mb-2"><div class="text-info">Roles:</div><div class="roles_container">';

                        roles.forEach(function(role) {
                            var roleName = role.role_name || '-';
                            var roleId = role.id;

                            html += `
                                <div class="role-badge bg-label-info mb-1 rounded px-2 py-1 d-flex align-items-center justify-content-between">
                                    <span>${roleName}</span>
                                    <button type="button" class="role-remove-btn ms-2" title="Remove Role" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        onclick="removeRole(${sno}, '${roleId}', this)">
                                        &times;
                                    </button>
                                </div>
                            `;
                        });

                        html += '</div></div></div>';
                    } else {
                        html = '<div class="text-muted fs-8 text-center">No Roles found.</div>';
                    }

                    roleCon.html(html);
                }
            },
            error: function(error) {
                console.error('Error fetching data:', error);
            }
        });
    }
}


function sendUserRoles() {
    var form = $('.add_role_form');
    var edit_role_sno = $('#edit_role_sno').val();
    var role_ids = $('#role_id_table' + edit_role_sno).val() || [];

    // Prepare the payload
    var payload = {
        edit_role_sno: edit_role_sno,
        Add_role_table: {}
    };
    payload.Add_role_table[edit_role_sno] = role_ids;
    

    
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Make the AJAX request to send the role data
    $.ajax({
        url: `/update_broadcast_roles`, // Make sure this is the correct URL for updating the roles
        type: 'POST',
        data: payload,
        headers: {
            "X-CSRF-TOKEN": csrfToken
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                var roles = response.roles;
                var roleCon = $('.role_fetch_container');
                $('#role_id_table' + edit_role_sno).val(null).trigger('change'); // Clear the dropdown

                // Update the hidden input field with the new roles
                var assignedRoleIds = roles.map(r => r.id);
                $('#role_id_hide_table' + edit_role_sno).val(assignedRoleIds.join(','));

                // Repopulate dropdown with updated assigned roles excluded
                populateRoleDropdown(edit_role_sno, assignedRoleIds);

                // Update the roles section in the popup with the new roles
                var html = '';

                if (Array.isArray(roles) && roles.length > 0) {
                    html += '<div class="mb-2"><div class="text-info">Roles:</div><div class="roles_container">';

                    roles.forEach(function(role) {
                        html += `
                            <div class="role-badge bg-label-info mb-1 rounded px-2 py-1 d-flex align-items-center justify-content-between">
                                <span>${role.role_name}</span>
                                <button type="button" class="role-remove-btn ms-2" title="Remove Role"
                                    onclick="removeRole(${edit_role_sno}, '${role.id}', this)">
                                    &times;
                                </button>
                            </div>
                        `;
                    });

                    html += '</div></div></div>';
                } else {
                    html = '<div class="text-muted fs-8 text-center">No Roles found.</div>';
                }

                roleCon.html(html);
            } else {
                alert('Failed to update roles.');
            }
        },
        error: function(xhr) {
            console.error('Error updating roles', xhr);
            alert('An error occurred while updating roles.');
        }
    });
}


function populateRoleDropdown(sno, assignedRoles) {
    $.ajax({
        url: "{{ route('user_role') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                var role_drop = $('#role_id_table' + sno);
                role_drop.empty();

                var existingRoles = assignedRoles || [];

                response.data.forEach(function(role) {
                    if (!existingRoles.includes(String(role.sno))) {
                        role_drop.append(
                            $('<option></option>')
                                .attr('value', role.sno)
                                .text(role.role_name)
                        );
                    }
                });
            }
        },
        error: function(error) {
            console.error('Error fetching roles:', error);
        }
    });
}
</script>


<!--update Branch-->
<script>

function ClosePopupBranch(sno) {
    $('.branch_drop_down_menu_' + sno).removeClass('show');
}

function removeBranch(sno, roleId, btn) {
    fetch("{{ route('broadcast_branch_remove') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ sno: sno, branch_id: roleId })
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            // Remove the badge from DOM
            btn.closest('.branch-badge').remove();

            // Update assigned roles list by removing the deleted role
            var assignedRoles = ($('#branch_id_hide_table' + sno).val() || " ").split(",");
            assignedRoles = assignedRoles.filter(id => id !== String(roleId));

            // Update hidden input with new assigned roles
            $('#branch_id_hide_table' + sno).val(assignedRoles.join(','));

            // Repopulate dropdown with updated assigned roles excluded
            populateBranchDropdown(sno, assignedRoles);

            $('.branch_drop_down_menu_'+sno).addClass('show');

            console.log('Branch removed successfully');
        } else {
            console.error('Failed to remove Branch.');
        }
    })
    .catch(err => console.error(err));
}

function OpenPopupBranch(sno, event) {
    event.preventDefault(); // Prevent page scroll

    // Close all open popups first
    $('.dropdown-menu_class').removeClass('show');  // Close role popups
    // Ensure that the branch popup is also closed when opening the role popup
    $('.branch_dropdown-menu_class').removeClass('show');
    
    // Now toggle the visibility of the current popup
    let dropdownMenu = $('.branch_drop_down_menu_' + sno);

    // Check if the popup is currently visible
    if (dropdownMenu.hasClass('show')) {
        // If it's open, close it
        dropdownMenu.removeClass('show');
    } else {
        // If it's closed, open it
        dropdownMenu.addClass('show');

        // Update the role values
        $('#edit_branch_sno').val(sno);

        // Get existing roles from the hidden input field
        var existingRoles = ($('#branch_id_hide_table' + sno).val() || "").split(",");
        populateBranchDropdown(sno, existingRoles);

        // Fetch role data from the server
        $.ajax({
            url: `/branch_list_broadcast/${sno}`,
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var branches = response.data.branches;
                    var roleCon = $('.branch_fetch_container');
                    var html = '';

                    if (branches) {
                        html += '<div class="mb-2"><div class="text-info">Branch:</div><div class="branch_container">';

                        branches.forEach(function(branch) {
                            var branchName = branch.branch_name || '-';
                            var branchId = branch.id;

                            html += `
                                <div class="branch-badge bg-label-info mb-1 rounded px-2 py-1 d-flex align-items-center justify-content-between">
                                    <span>${branchName}</span>
                                    <button type="button" class="branch-remove-btn ms-2" title="Remove Role" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        onclick="removeBranch(${sno}, '${branchId}', this)">
                                        &times;
                                    </button>
                                </div>
                            `;
                        });

                        html += '</div></div></div>';
                    } else {
                        html = '<div class="text-muted fs-8 text-center">No Branch found.</div>';
                    }

                    roleCon.html(html);
                }
            },
            error: function(error) {
                console.error('Error fetching data:', error);
            }
        });
    }
}


function updateBranch() {
    var form = $('.add_branch_form');
    var edit_branch_sno = $('#edit_branch_sno').val();
    var branch_ids = $('#branch_id_table' + edit_branch_sno).val() || [];

    // Prepare the payload
    var payload = {
        edit_branch_sno: edit_branch_sno,
        Add_branch_table: {}
    };
    payload.Add_branch_table[edit_branch_sno] = branch_ids;
    
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Make the AJAX request to send the role data
    $.ajax({
        url: `/update_broadcast_branch`, // Make sure this is the correct URL for updating the roles
        type: 'POST',
        data: payload,
        headers: {
            "X-CSRF-TOKEN": csrfToken
        },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                var branches = response.branches;
                var roleCon = $('.branch_fetch_container');
                $('#branch_id_table' + edit_branch_sno).val(null).trigger('change'); // Clear the dropdown

                // Update the hidden input field with the new roles
                var assignedBranchIds = branches.map(r => r.id);
                $('#branch_id_hide_table' + edit_branch_sno).val(assignedBranchIds.join(','));

                // Repopulate dropdown with updated assigned roles excluded
                populateBranchDropdown(edit_branch_sno, assignedBranchIds);

                // Update the roles section in the popup with the new roles
                var html = '';
               
                if (Array.isArray(branches) && branches.length > 0) {
                    html += '<div class="mb-2"><div class="text-info">Branch:</div><div class="branch_container">';

                    branches.forEach(function(branch) {
                        html += `
                            <div class="branch-badge bg-label-info mb-1 rounded px-2 py-1 d-flex align-items-center justify-content-between">
                                <span>${branch.branch_name}</span>
                                <button type="button" class="branch-remove-btn ms-2" title="Remove Branch"
                                    onclick="removeBranch(${edit_branch_sno}, '${branch.id}', this)">
                                    &times;
                                </button>
                            </div>
                        `;
                    });

                    html += '</div></div></div>';
                } else {
                    html = '<div class="text-muted fs-8 text-center">No Branch found.</div>';
                }

                roleCon.html(html);
            } else {
                console.error('Failed to update roles.');
            }
        },
        error: function(xhr) {
            console.error('Error updating roles', xhr);
            console.error('An error occurred while updating roles.');
        }
    });
}


function populateBranchDropdown(sno, assignedRoles) {
    $.ajax({
        url: "{{ route('branch_list') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                var role_drop = $('#branch_id_table' + sno);
                role_drop.empty();

                var existingRoles = assignedRoles || [];
                    console.log(existingRoles)
                response.data.forEach(function(role) {
                    if (!existingRoles.includes(String(role.sno))) {
                        role_drop.append(
                            $('<option></option>')
                                .attr('value', role.sno)
                                .text(role.branch_name)
                        );
                    }
                });
            }
        },
        error: function(error) {
            console.error('Error fetching roles:', error);
        }
    });
}
</script>






<!-- Delete Function -->
<script>
      function confirmDelete(id, name) {
  
          document.querySelector('#kt_modal_delete_country .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Country ?<br> <b class="text-black fw-bold fs-4">' +
              name +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_country .btn-danger').getAttribute('data-id');

          fetch('/news_broadcast_update_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                       loadThemes(1);
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {

              });
      }
</script>
<script>
    var newsUpdated =[];
    function openViewTheme(id){
        var settings = {}; 
        newsUpdated =[];
         $.ajax({
                url: "/news_broadcast_by_id",
                type: "GET",
                data: { theme_id: id },
                success: function (response) {
                    if (response.status === "200" && response.data) {
                        // merge DB theme into settings
                            $('#template_name_view').text(' - ' +response.allData.template_name);
                          var themeIndex = parseInt(response.data.theme) - 1;
                            
                      
                         newsUpdated = response.content || [];
                         getSettings(newsUpdated);
                         
                        if (themes[themeIndex]) {
                             $.extend(true, settings, response.data);
                        }
                        
                    }
                    // re-init ticker
                    $('#ent_wrapper_view').html('').removeClass();
                    $('#ent_wrapper_view').easyNewsTicker(settings);
                },
                error: function (xhr) {
                    console.error("Theme fetch error:", xhr.responseText);
                    toastr.error("Error fetching theme.");
                    getSettings();
                    // fallback to base settings
                    $('#ent_wrapper_view').html('').removeClass();
                    $('#ent_wrapper_view').easyNewsTicker(settings);
                }
            });
            function getSettings(customNews) {
                var news, updateNews, i;
                settings = {
                  position: 'fixed' ,
                  height: 50,
                  theme: 1,
                  margin: '0px',
                  roundness: 0,
                  shadow: {
                    enable: false,
                    type: 1,
                    reverse: false
                  },
                  animation: {
                    effect: 'scroll',
                    scroll_speed: parseInt($('#animation-scroll_speed').val()),
                    easing: "easeInOutCirc",
                    duration:500,
                    delay: 2000
                  },
                  data: null,
                  label: {
                    onMobile: {
                      enable: true
                    },
                    enable: true,
                    padding: '15px',
                    fontFamily: "Roboto",
                    fontSize: 14,
                    fontWeight: "700",
                    background: "#DA0037",
                    color: "#EEE",
                    text: "News",
                    logo: ""
                  },
                  news: {
                    background: "#EEE",
                    padding: "0 15px",
                    prefix: {
                      enable: true,
                      fontFamily: "Roboto",
                      fontSize: 14,
                      fontWeight: "700",
                      background: "#444",
                      color: "#EEE",
                      roundness:5,
                      padding: "5px 10px"
                    },
                    date: {
                      enable: true,
                      fontFamily: "Roboto",
                      fontSize: 14,
                      fontWeight: "700",
                      background: "none",
                      color: $('#news-date-color').val(),
                      roundness: 0,
                      padding: "0px"
                    },
                    heading: {
                      color: "#171717",
                      fontFamily: "Roboto",
                      fontSize: 16,
                      fontWeight: "400"
                    },
                    separator: {
                      size: 10,
                      background: "#DA0037"
                    }
                  },
                  navigation: {
                    onMobile: {
                      enable: true
                    },
                    enable: true,
                    autohide: false,
                    padding: "15px",
                    background: "#171717",
                    color: "#EEE",
                    hover: "#EEE"
                  }
                };
        
                var defaultNews = [
                  { date: 'June 23, 2022', prefix: 'CNN: World', heading: 'A Muslim teenager was killed at a protest in India. His family wants answers.', url: '#' },
                  { date: 'June 23, 2022', prefix: 'CNN: US Politics', heading: 'Biden administration agrees to cancel another $6 billion in student loan debt for defrauded borrowers.', url: 'https://edition.cnn.com/2022/06/23/politics/biden-student-loan-debt-cancellation-borrower-defense/index.html' },
                  { date: '26.05.2022 10:32', prefix: 'CNN: Buisiness', heading: 'Black former Tesla contractor turned down $15 million award in racial harassment suit, likely setting up new trial.', url: 'https://edition.cnn.com/2022/06/22/business/california-tesla-racism-lawsuit/index.html' },
                  { date: 'June 23, 2022', prefix: 'BBC: Climate', heading: "Just Stop Oil: Activists says they have 'a duty to protest'.", url: 'https://www.bbc.com/news/newsbeat-61635328' },
                  { date: 'June 23, 2022', prefix: 'BBC: Science', heading: 'Five major planets to line up in rare planetary conjunction.', url: 'https://www.bbc.com/news/science-environment-61910977' }
                ];
        
                var updateNews = customNews && customNews.length > 0 ? customNews : defaultNews;
        
                if (!settings.news.prefix.enable) {
                  for (i = 0; i < updateNews.length; i++) {
                    delete updateNews[i].prefix;
                  }
                }
                if (!settings.news.date.enable) {
                  for (i = 0; i < updateNews.length; i++) {
                    delete updateNews[i].date;
                  }
                }
                settings.data = updateNews;
            }
      
            var settings, themes;
            themes = [
          {
            label: {
              background: '#DA0037',
              color: '#EEE'
            },
            news: {
              background: '#EEE',
              heading: {
                color: '#171717'
              },
              separator: {
                background: '#DA0037'
              },
              prefix: {
                background: '#444',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#444'
              }
            },
            navigation: {
              background: '#171717',
              color: '#EEE',
              hover: '#EEE'
            }
          },
          {
            label: {
              background: '#DA0037',
              color: '#EEE'
            },
            news: {
              background: '#171717',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#DA0037'
              },
              prefix: {
                background: '#DA0037',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#EEE'
              }
            },
            navigation: {
              background: '#EEEEEE',
              color: '#171717',
              hover: '#171717'
            }
          },
          {
            label: {
              background: '#1B1A17',
              color: '#F0A500'
            },
            news: {
              background: '#F0A500',
              heading: {
                color: '#1B1A17'
              },
              separator: {
                background: '#1B1A17'
              },
              prefix: {
                background: '#1B1A17',
                color: '#F0A500'
              },
              date: {
                background: 'none',
                color: '#1B1A17'
              }
            },
            navigation: {
              background: '#1B1A17',
              color: '#EEE',
              hover: '#F0A500'
            }
          },
          {
            label: {
              background: '#F0A500',
              color: '#1B1A17'
            },
            news: {
              background: '#1B1A17',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#F0A500'
              },
              prefix: {
                background: '#EEE',
                color: '#1B1A17'
              },
              date: {
                background: 'none',
                color: '#F0A500'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#1B1A17',
              hover: '#F0A500'
            }
          },
          {
            label: {
              background: '#222831',
              color: '#EEE'
            },
            news: {
              background: '#00ADB5',
              heading: {
                color: '#222831'
              },
              separator: {
                background: '#222831'
              },
              prefix: {
                background: '#EEE',
                color: '#00ADB5'
              },
              date: {
                background: 'none',
                color: '#222831'
              }
            },
            navigation: {
              background: '#222831',
              color: '#EEE',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#00ADB5',
              color: '#EEE'
            },
            news: {
              background: '#222831',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#00ADB5'
              },
              prefix: {
                background: '#EEE',
                color: '#00ADB5'
              },
              date: {
                background: 'none',
                color: '#EEE'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#222831',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#FF5722',
              color: '#EEE'
            },
            news: {
              background: '#303841',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#FF5722'
              },
              prefix: {
                background: '#00ADB5',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#FF5722'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#303841',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#FF5722',
              color: '#EEE'
            },
            news: {
              background: '#EEEEEE',
              heading: {
                color: '#303841'
              },
              separator: {
                background: '#FF5722'
              },
              prefix: {
                background: '#00ADB5',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#FF5722'
              }
            },
            navigation: {
              background: '#303841',
              color: '#EEE',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#EEE',
              color: '#FF5722'
            },
            news: {
              background: '#FF5722',
              heading: {
                color: '#222831'
              },
              separator: {
                background: '#222831'
              },
              prefix: {
                background: '#222831',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#222831'
              }
            },
            navigation: {
              background: '#303841',
              color: '#EEE',
              hover: '#FF5722'
            }
          },
          {
            label: {
              background: '#14274E',
              color: '#EEE'
            },
            news: {
              background: '#F1F6F9',
              heading: {
                color: '#14274E'
              },
              separator: {
                background: '#9BA4B4'
              },
              prefix: {
                background: '#9BA4B4',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#9BA4B4'
              }
            },
            navigation: {
              background: '#9BA4B4',
              color: '#14274E',
              hover: '#EEE'
            }
          }
        ];
            
            getSettings(newsUpdated)

            $('#ent_wrapper_view').easyNewsTicker(settings);
      
    }
</script>

@endsection