@extends('layouts/layoutMaster')

@section('title', 'Manage Company')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
     'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
     'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
  @vite(['resources/assets/js/form_wizard_icons.js'])
@endsection


@section('content')

<div class="card mb-2">
  <div class="card-header border-bottom pb-1">
      <div class="d-flex align-items-start justify-content-start flex-column">
          <h5 class="card-title mb-1 text-black">Create Branch</h5>
          <nav aria-label="breadcrumb">
              <ol class="breadcrumb custom-breadcrumb">
                  <!-- Home -->
                  <li class="breadcrumb-item">
                      <a href="{{ url('/dashboard') }}">
                          <i class="mdi mdi-home"></i> Home
                      </a>
                  </li>
                  <li class="breadcrumb-item" aria-current="page">
                      <a href="javascript:void(0);">
                          <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                      </a>
                  </li>
                  <li class="breadcrumb-item " aria-current="page">
                      <a href="javascript:void(0);" >
                          Entity Hub
                      </a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                      <a href="javascript:void(0);" class="active-link">
                          Manage Branch
                      </a>
                  </li>
              </ol>
          </nav>
      </div>
  </div>
</div>
<div class="bs-stepper wizard-vertical vertical wizard-vertical-icons-example wizard-vertical-icons mt-2 gap-3 ">
  <div class="bs-stepper-header gap-lg-2">
    <div class="step" data-target="#location">
      <button type="button" class="step-trigger">
        <span class="avatar">
          <span class="avatar-initial rounded-2">
            <i class="fa-solid fa-location-dot"></i>
          </span>
        </span>
        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
          <span class="bs-stepper-title">Branch And Location</span>
          <span class="bs-stepper-subtitle">Setup Address And Location</span>
        </span>
      </button>
    </div>
    <div class="step" data-target="#Contact">
      <button type="button" class="step-trigger">
        <span class="avatar">
          <span class="avatar-initial rounded-2">
            <i class="fa-solid fa-phone"></i>
          </span>
        </span>
        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
          <span class="bs-stepper-title">Contact & Online Presence</span>
          <span class="bs-stepper-subtitle">Setup Contact & Online Presence</span>
        </span>
      </button>
    </div>
    <div class="step" data-target="#Compliance">
      <button type="button" class="step-trigger">
        <span class="avatar">
          <span class="avatar-initial rounded-2">
            <i class="fa-solid fa-handshake"></i>
          </span>
        </span>
        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
          <span class="bs-stepper-title">Compliance & Agreements</span>
          <span class="bs-stepper-subtitle">Setup Compliance & Agreements</span>
        </span>
      </button>
    </div>
      <div class="step" data-target="#Banking">
      <button type="button" class="step-trigger">
        <span class="avatar">
          <span class="avatar-initial rounded-2">
            <i class="fa-solid fa-building-columns"></i>
          </span>
        </span>
        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
          <span class="bs-stepper-title">Banking</span>
          <span class="bs-stepper-subtitle">Setup Banking</span>
        </span>
      </button>
    </div>
    <div class="step" data-target="#Collection">
      <button type="button" class="step-trigger">
        <span class="avatar">
          <span class="avatar-initial rounded-2">
            <i class="fa-solid fa-grip"></i>
          </span>
        </span>
        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
          <span class="bs-stepper-title">Collection Info & API</span>
          <span class="bs-stepper-subtitle">Setup Collection Info & API </span>
        </span>
      </button>
    </div>
  </div>
  <div class="bs-stepper-content">
      <div id="location" class="content">
        <div class="row">
          <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Branch Name" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Branch Category<span
                        class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Branch Category</option>
                    <option value="1">Branch - CICO</option>
                    <option value="2">Branch - CIFO</option>
                    <option value="3">Branch - FICO</option>
                    <option value="3">Branch - FIFO</option>
                </select>
            </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                  <select class="select3 form-select">
                      <option value="">Select Country</option>
                      <option value="1">USA</option>
                      <option value="2">UAE</option>
                      <option value="3">India</option>
                      <option value="4">South Africa</option>
                  </select>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                  <select class="select3 form-select">
                      <option value="">Select State</option>
                      <option value="1">Tamilnadu</option>
                      <option value="2">Andhra Pradesh</option>
                      <option value="3">Kerala</option>
                      <option value="4">Karnataka</option>
                  </select>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                  <select class="select3 form-select">
                      <option value="">Select City</option>
                      <option value="1">Madurai</option>
                      <option value="2">Virudhunagar</option>
                      <option value="3">Thirunelveli</option>
                      <option value="4">Coimbatore</option>
                      <option value="5">Chennai</option>
                  </select>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Area / Street" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Pincode" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span
                          class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter City Short Code" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Latitude" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Longitude" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                  <select class="select3 form-select">
                      <option value="">Select Time Zone</option>
                      <option value="1">India (UTC +05:30)</option>
                      <option value="2">United States (UTC -04:00)</option>
                      <option value="3">United Kingdom (UTC +01:00)</option>
                  </select>
              </div>
              <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span
                        class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Currency Format</option>
                    <option value="1">INR - &#8377;</option>
                </select>
            </div>
            </div>
            <div class="col-12 d-flex justify-content-between">
              <button class="btn btn-outline-secondary btn-prev"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1"></i>
                <span class="align-middle d-sm-inline-block d-none">Previous</span>
              </button>
              <button class="btn btn-primary btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
            </div>

      </div>
      <div id="Contact" class="content">
        <div class="row">
          <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Mobile No" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Business Email ID" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Communication Email ID" />
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="divider text-center">
                  <div class="divider-text text-black fs-5">Online Presence</div>
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Location URL" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="Enter Website URL" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                  <input type="text" class="form-control" placeholder="Enter Facebook Link" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                  <input type="text" class="form-control" placeholder="Enter Instagram Link" />
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                  <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code" />
              </div>
            </div>

        </div>
        <div class="col-12 d-flex justify-content-between">
            <button class="btn btn-outline-secondary btn-prev"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1"></i>
              <span class="align-middle d-sm-inline-block d-none">Previous</span>
            </button>
            <button class="btn btn-primary btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
        </div>
      </div>
      <div id="Compliance" class="content">
        <div class="row">
          <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                <input type="text" class="form-control" placeholder="Enter CIN No" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                <input type="text" class="form-control" placeholder="Enter GST No" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                <input type="text" class="form-control" placeholder="Enter PAN No" />
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="divider text-center">
                  <div class="divider-text text-black fs-5">Agreement Info</div>
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                  <div class="input-group input-group-merge">
                      <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                      <input type="text" id="agree_stdt" placeholder="Select Date" class="form-control">
                  </div>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                  <div class="input-group input-group-merge">
                      <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                      <input type="text" id="agree_eddt" placeholder="Select Date" class="form-control">
                  </div>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                  <div class="input-group input-group-merge">
                      <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                      <input type="text" id="open_dt" placeholder="Select Date" class="form-control">
                  </div>
              </div>
            </div>

        </div>
        <div class="col-12 d-flex justify-content-between">
              <button class="btn btn-outline-secondary btn-prev"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1"></i>
                <span class="align-middle d-sm-inline-block d-none">Previous</span>
              </button>
              <button class="btn btn-primary btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
            </div>
      </div>
      <div id="Banking" class="content">
        <div class="row">
          <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Name" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account Holder" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Account No" />
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter IFSC Code" />
            </div>
        </div>
        <div class="col-12 d-flex justify-content-between">
          <button class="btn btn-outline-secondary btn-prev"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1"></i>
            <span class="align-middle d-sm-inline-block d-none">Previous</span>
          </button>
          <button class="btn btn-primary btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
        </div>
      </div>
      <div id="Collection" class="content">
        <div class="row">
          <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span
                        class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="cllt_cl_dt" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span
                        class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="reg_cl_dt" placeholder="Select Date" class="form-control">
                </div>
            </div>
            <div class="col-lg-6 mb-3">
                <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span
                        class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="Enter Minimum Amount Receive" />
            </div>
            <div class="col-lg-6 mb-3">
                <input class="form-check-input" type="checkbox" id="bus_cls_dt" onclick="bus_cls_dt_func();" />
                <label class="text-black mb-1 fs-6 fw-semibold" id="bus_cls_dt_txt">Business Closing Date (In
                    Count)<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="bus_cls_dt_tbox"
                    placeholder="Enter Business Closing Date(In Count)" />
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="divider text-center">
                  <div class="divider-text text-black fs-5">API Details</div>
                </div>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                  <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key"></textarea>
              </div>
              <div class="col-lg-6 mb-3">
                  <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                  <textarea class="form-control h-auto" rows="1" placeholder="Enter Description"></textarea>
              </div>
            </div>

        </div>
        <div class="col-12 d-flex justify-content-between">
          <button class="btn btn-outline-secondary btn-prev"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
            <span class="align-middle d-sm-inline-block d-none">Previous</span>
          </button>
          <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_branch">Add Branch</button>
        </div>
      </div>
  </div>
</div>



<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_create_branch" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
            </div>
            <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure you want to
                Create Branch ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                <a href="#" class="btn btn-success me-3" data-bs-dismiss="modal">Yes</a>
                <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->

<!--begin::Modal - Create Branch-->
<div class="modal fade" id="kt_modal_create_branch" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                <span id="create_label"> Create Branch </span> ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <a href="{{url('/branch')}}" class="btn fw-bold btn-primary me-3">Yes</a>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Branch-->



<script>
function bus_cls_dt_func() {
    var bus_cls_dt = document.getElementById("bus_cls_dt");
    var bus_cls_dt_txt = document.getElementById("bus_cls_dt_txt");
    var bus_cls_dt_tbox = document.getElementById("bus_cls_dt_tbox");

    if (bus_cls_dt.checked) {
        bus_cls_dt_txt.innerHTML = "Business Closing Date is Month End";
        bus_cls_dt_tbox.style.setProperty("display", "none", "important");
    } else {
        bus_cls_dt_txt.innerHTML = "Business Closing Date (In Count) <span class='text-danger'>*</span>";
        bus_cls_dt_tbox.style.setProperty("display", "block", "important");
    }
}
</script>

@endsection
