<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyModel extends Model
{
    use HasFactory;
    public $table      = "egc_company";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'company_id',
        'company_name',
        'company_type',
        'company_mail',
        'company_short_name',
        'company_base_color',
        'company_logo',
        'company_in_menu',
        'social_media_details',
        'company_website',
        'company_ct_person',
        'company_ct_number',
        'company_country',
        'company_state',
        'company_city',
        'company_area',
        'company_door_no',
        'company_pincode',
        'company_gst',
        'company_cin',
        'company_pan',
        'company_tax',
        'company_desc',
        'company_bank_name',
        'company_bank_branch',
        'company_acc_holder',
        'company_acc_no',
        'company_ifsc',
        'created_by',
        'updated_by',
        'updated_at',
        'status',
    ];
}