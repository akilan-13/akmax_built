<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffFamilyModel extends Model
{
  use HasFactory;

  protected $table = 'egc_staff';
  protected $primaryKey = 'sno';
  public $timestamps = true;

  protected $fillable = [
    'staff_id',
    'father_name',
    'father_occup',
    'mother_name',
    'mother_occup',
    'anniversary_date',
    'spouse_name',
    'spouse_mobile',
    'spouse_dob',
    'spouse_working',
    'spouse_designation',
    'spouse_company_name',
    'spouse_salary',
    'has_children',
    'children_count',
    'children_details',
    'has_siblings',
    'siblings_detail',
    'gender',
    'dob',
    'discount',
    'coupon_code',
    'login_access',
    'date_of_joining',
    'contact_person_name',
    'contact_person_no',
    'martial_status',
    'address',
    'staff_image',
    'user_name',
    'attachment',
    'knowledge_tag',
    'nick_name',
    'position_role',
    'password',
    'credential',
    'description',
    'created_by',
    'created_at',
    'updated_by',
    'updated_at',
    'status',
    'shift_time_id',
    'basic_salary',
    'per_hour_cost',
    'dep_reason',
    'notice_end_date',
    'notice_start_date',
    'employee_skill_id',
    'staff_last_date',
  ];
}
