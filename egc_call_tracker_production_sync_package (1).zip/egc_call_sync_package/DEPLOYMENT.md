# Deployment order

## PhDiZone
1. Copy updated SalesApp.php.
2. Copy updated CallTrackerModel.php.
3. Add EgcCallTrackerSyncService.php.
4. Add SyncCallTrackerToEgc.php.
5. Merge the EGC service block from config/services.egc.example.php into config/services.php.
6. Add .env values.
7. Run migration:
   php artisan migrate
8. Configure a persistent queue worker.

## EGC
1. Add InternalCallTrackerController.php.
2. Add/update CallTrackerModel.php.
3. Merge egc_sync block from config/services.egc.example.php into config/services.php.
4. Add route from routes_egc_sync.php.example to routes/api.php.
5. Set the same EGC_SYNC_SECRET.
6. Run migration:
   php artisan migrate
7. Clear cached config:
   php artisan optimize:clear

## Verification
- Save an outgoing call from PhDiZone.
- Confirm local et_call_tracker row is created with external_uuid and synced status.
- Confirm one egc_call_tracker row with the same external_uuid and entity_id=1.
- Repeat the exact same HTTP payload: EGC must return 200 and create no second row.
- Force EGC down: local save must still return 200 and egc_sync_status should become pending/failed.
- Restore EGC and confirm queue retry changes the local status to synced.
