<?php

return [

    'egc_sync' => [
        'secret' => env('EGC_SYNC_SECRET'),
    ],

];
