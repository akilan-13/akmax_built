<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        /*
         * Old dump declared external_uuid as BIGINT. It must be a string
         * because the source application uses a UUID as the global
         * idempotency key.
         */
        Schema::table('egc_call_tracker', function (Blueprint $table) {
            $table->string('external_uuid', 64)
                ->nullable()
                ->change();
        });

        Schema::table('egc_call_tracker', function (Blueprint $table) {
            $table->unique(
                'external_uuid',
                'uq_egc_call_tracker_external_uuid'
            );

            $table->index(
                ['entity_id', 'call_start_date', 'branch_staff_id'],
                'idx_egc_call_tracker_entity_date_staff'
            );

            $table->index(
                ['staff_phone_no', 'call_start_date'],
                'idx_egc_call_tracker_staff_phone_date'
            );

            $table->index(
                ['customer_phone_no', 'call_start_date'],
                'idx_egc_call_tracker_customer_phone_date'
            );
        });
    }

    public function down(): void
    {
        Schema::table('egc_call_tracker', function (Blueprint $table) {
            $table->dropUnique('uq_egc_call_tracker_external_uuid');
            $table->dropIndex('idx_egc_call_tracker_entity_date_staff');
            $table->dropIndex('idx_egc_call_tracker_staff_phone_date');
            $table->dropIndex('idx_egc_call_tracker_customer_phone_date');
        });

        /*
         * Reverting to BIGINT can fail if UUID rows have been synchronized.
         * Do not blindly change the production type back to BIGINT.
         * The down migration therefore intentionally leaves the string type.
         */
    }
};
