# PhDiZone -> EGC Call Tracker Synchronization

## Architecture

1. PhDiZone `CallTrackerLogSave` saves the call locally in `et_call_tracker`.
2. The local transaction commits first.
3. The controller immediately attempts to sync the committed record to EGC.
4. If the remote call fails, the local row remains authoritative with
   `egc_sync_status = pending`.
5. A queue job retries synchronization.
6. EGC authenticates the request with HMAC SHA-256 and a five-minute timestamp
   window.
7. EGC uses `external_uuid` as the idempotency key. A repeated request never
   creates a second call or increments contact counters twice.
8. EGC preserves `entity_id` exactly as sent:
   0 = EGC, 1 = PhDiZone, 2 = Academy, 3 = EiBS, etc.

## Files

### PhDiZone
- `app/Http/Controllers/mobile_apps/SalesApp.php`
- `app/Models/CallTrackerModel.php`
- `app/Services/EgcCallTrackerSyncService.php`
- `app/Jobs/SyncCallTrackerToEgc.php`
- `database/migrations/2026_09_14_000001_add_egc_sync_fields_to_et_call_tracker.php`
- `.env.egc.example`

### EGC
- `app/Http/Controllers/Api/InternalCallTrackerController.php`
- `app/Models/CallTrackerModel.php`
- `database/migrations/2026_09_14_000002_upgrade_egc_call_tracker_external_uuid.php`
- `config/services.egc.example.php`
- `routes_egc_sync.php.example`

## Important installation notes

Do not replace your existing `config/services.php` wholesale.
Merge the `egc` / `egc_sync` entries into the existing file.

Do not replace your existing `routes/api.php` wholesale.
Add the single EGC internal route.

Do not run the EGC migration until you confirm `external_uuid` currently contains
only NULL values or values that are safely convertible to strings. The supplied
dump contains only NULL values for that column.

Set the SAME `EGC_SYNC_SECRET` in PhDiZone and EGC.

PhDiZone:
- `EGC_SOURCE_ENTITY_ID=1`

For other source entity applications:
- Academy: `EGC_SOURCE_ENTITY_ID=2`
- EiBS: `EGC_SOURCE_ENTITY_ID=3`
- Main EGC does not use this sender service; its own calls remain `entity_id=0`.

The source application should own its entity ID. The receiver should not infer
business ownership from the current CUG number mapping because the same phone/CUG
may be in a different assignment during a migration.

## Audio

The source sends `audio_file` as a full URL such as:
`https://phdizone-domain/call_audios/<filename>`

This avoids copying potentially large recordings during the call-save request.
If EGC needs physical local copies, add a separate authenticated media-copy
endpoint/job. Do not download arbitrary source URLs in a public controller.

## Queue

The immediate sync attempt is intentionally small-timeout (default 3 seconds).
The queue is the recovery mechanism, not a second source of truth.

Run a persistent worker under Supervisor/systemd in production.

Example:
`php artisan queue:work --queue=default --sleep=1 --tries=5 --timeout=30`

## Security

Use a long random secret (64+ characters).
Never log the secret or Authorization values.
Expose the EGC sync route only through HTTPS and your normal web firewall/reverse proxy.
The HMAC uses:
`timestamp + "." + raw JSON body`
