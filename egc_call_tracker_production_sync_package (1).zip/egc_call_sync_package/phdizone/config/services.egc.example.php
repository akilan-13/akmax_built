<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Existing service definitions
    |--------------------------------------------------------------------------
    | Keep all existing entries in your real config/services.php.
    | Add only the "egc" block below.
    */

    'egc' => [
        'base_url' => env('EGC_BASE_URL'),
        'sync_secret' => env('EGC_SYNC_SECRET'),
        'source_name' => env('EGC_SOURCE_NAME', 'phdizone'),
        'source_entity_id' => (int) env('EGC_SOURCE_ENTITY_ID', 1),
        'timeout' => (int) env('EGC_SYNC_TIMEOUT', 3),
    ],

];
