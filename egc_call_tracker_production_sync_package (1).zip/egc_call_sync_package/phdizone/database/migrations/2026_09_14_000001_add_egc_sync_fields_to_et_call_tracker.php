<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('et_call_tracker', function (Blueprint $table) {
            $table->string('external_uuid', 64)->nullable()->after('audio_file');
            $table->string('egc_sync_status', 20)->default('pending')->after('external_uuid');
            $table->unsignedInteger('egc_sync_attempts')->default(0)->after('egc_sync_status');
            $table->text('egc_sync_error')->nullable()->after('egc_sync_attempts');
            $table->dateTime('egc_synced_at')->nullable()->after('egc_sync_error');

            $table->index('egc_sync_status', 'idx_et_call_tracker_egc_sync_status');
            $table->unique('external_uuid', 'uq_et_call_tracker_external_uuid');
        });
    }

    public function down(): void
    {
        Schema::table('et_call_tracker', function (Blueprint $table) {
            $table->dropIndex('idx_et_call_tracker_egc_sync_status');
            $table->dropUnique('uq_et_call_tracker_external_uuid');
            $table->dropColumn([
                'external_uuid',
                'egc_sync_status',
                'egc_sync_attempts',
                'egc_sync_error',
                'egc_synced_at',
            ]);
        });
    }
};
