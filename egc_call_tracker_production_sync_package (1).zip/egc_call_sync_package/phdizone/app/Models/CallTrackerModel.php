<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CallTrackerModel extends Model
{
    use HasFactory;

    protected $table = 'et_call_tracker';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'branch_id',
        'branch_staff_id',
        'call_tracker_staff_id',
        'staff_phone_no',
        'customer_phone_no',
        'customer_name',
        'customer_status',
        'customer_reason',
        'call_start_date',
        'call_end_date',
        'call_start_time',
        'call_end_time',
        'call_duration',
        'latitude',
        'longitude',
        'call_status',
        'count_status',
        'contact_id',
        'audio_file',
        'external_uuid',
        'egc_sync_status',
        'egc_sync_attempts',
        'egc_sync_error',
        'egc_synced_at',
        'updated_at',
        'created_at',
    ];

    protected $casts = [
        'egc_sync_attempts' => 'integer',
        'egc_synced_at' => 'datetime',
    ];
}
