<?php

namespace App\Jobs;

use App\Models\CallTrackerModel;
use App\Services\EgcCallTrackerSyncService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SyncCallTrackerToEgc implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 5;
    public array $backoff = [30, 120, 300, 900, 1800];
    public int $timeout = 20;

    public function __construct(public int $callTrackerId)
    {
    }

    public function handle(EgcCallTrackerSyncService $service): void
    {
        $call = CallTrackerModel::find($this->callTrackerId);

        if (!$call) {
            return;
        }

        if ($call->egc_sync_status === 'synced') {
            return;
        }

        $result = $service->sync(
            $call,
            (int) $call->call_tracker_staff_id,
            (int) $call->branch_id
        );

        if (!empty($result['success'])) {
            return;
        }

        /*
         * Throwing causes Laravel to release the job according to backoff.
         * external_uuid guarantees that an already-synced call cannot be
         * duplicated when a worker retries after an ambiguous network failure.
         */
        throw new \RuntimeException(
            'EGC call tracker sync pending: ' . ($result['message'] ?? 'Unknown error')
        );
    }

    public function failed(\Throwable $exception): void
    {
        CallTrackerModel::whereKey($this->callTrackerId)->update([
            'egc_sync_status' => 'failed',
            'egc_sync_error' => mb_substr($exception->getMessage(), 0, 2000),
        ]);

        Log::error('EGC call tracker synchronization job permanently failed', [
            'call_tracker_id' => $this->callTrackerId,
            'exception' => $exception->getMessage(),
        ]);
    }
}
