<?php

namespace App\Services;

use App\Models\CallTrackerModel;
use Carbon\Carbon;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class EgcCallTrackerSyncService
{
    public function sync(CallTrackerModel $callTracker, int $staffId, int $branchId): array
    {
        $baseUrl = rtrim((string) config('services.egc.base_url'), '/');
        $secret = (string) config('services.egc.sync_secret');
        $sourceEntityId = (int) config('services.egc.source_entity_id', 1);
        $sourceName = (string) config('services.egc.source_name', 'phdizone');
        $timeout = (int) config('services.egc.timeout', 3);

        if ($baseUrl === '' || $secret === '') {
            $this->markFailure($callTracker, 'EGC synchronization is not configured.');
            return [
                'success' => false,
                'status' => 'pending',
                'message' => 'EGC synchronization is not configured.',
            ];
        }

        if (empty($callTracker->external_uuid)) {
            $callTracker->external_uuid = (string) Str::uuid();
            $callTracker->save();
        }

        $payload = [
            'external_uuid' => (string) $callTracker->external_uuid,
            'source_call_id' => (int) $callTracker->sno,
            'source' => $sourceName,
            'source_entity_id' => $sourceEntityId,
            'entity_id' => $sourceEntityId,

            'branch_id' => (int) $branchId,
            'branch_staff_id' => (int) $callTracker->branch_staff_id,
            'call_tracker_staff_id' => (int) $callTracker->call_tracker_staff_id,
            'staff_phone_no' => (string) $callTracker->staff_phone_no,

            'customer_phone_no' => (string) $callTracker->customer_phone_no,
            'customer_name' => $callTracker->customer_name,
            'customer_status' => (int) ($callTracker->customer_status ?? 0),
            'customer_reason' => $callTracker->customer_reason,

            'call_start_date' => $callTracker->call_start_date,
            'call_end_date' => $callTracker->call_end_date,
            'call_start_time' => $callTracker->call_start_time,
            'call_end_time' => $callTracker->call_end_time,
            'call_duration' => $callTracker->call_duration ?: '00:00:00',

            'latitude' => $callTracker->latitude,
            'longitude' => $callTracker->longitude,
            'call_status' => (int) $callTracker->call_status,
            'count_status' => (int) ($callTracker->count_status ?? 1),

            /*
             * EGC stores this as a text field. A full source URL is used so
             * EGC can play/download the recording without duplicating files.
             */
            'audio_file' => $callTracker->audio_file
                ? url('/call_audios/' . rawurlencode($callTracker->audio_file))
                : null,

            'created_at' => optional($callTracker->created_at)->toIso8601String(),
            'updated_at' => optional($callTracker->updated_at)->toIso8601String(),
        ];

        $body = json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );

        if ($body === false) {
            $this->markFailure($callTracker, 'Unable to encode EGC sync payload.');
            return [
                'success' => false,
                'status' => 'pending',
                'message' => 'Unable to encode EGC sync payload.',
            ];
        }

        $timestamp = (string) time();
        $signature = hash_hmac('sha256', $timestamp . '.' . $body, $secret);

        $attempt = (int) ($callTracker->egc_sync_attempts ?? 0) + 1;

        try {
            $callTracker->forceFill([
                'egc_sync_status' => 'syncing',
                'egc_sync_attempts' => $attempt,
                'egc_sync_error' => null,
            ])->save();

            /** @var Response $response */
            $response = Http::asJson()
                ->acceptJson()
                ->timeout($timeout)
                ->connectTimeout($timeout)
                ->withHeaders([
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    'X-EGC-Source' => $sourceName,
                    'X-EGC-Timestamp' => $timestamp,
                    'X-EGC-Signature' => $signature,
                    'X-EGC-Idempotency-Key' => (string) $callTracker->external_uuid,
                ])
                ->post($baseUrl . '/api/internal/call-tracker/sync', $payload);

            if ($response->successful() && data_get($response->json(), 'status') === 200) {
                $callTracker->forceFill([
                    'egc_sync_status' => 'synced',
                    'egc_sync_error' => null,
                    'egc_synced_at' => Carbon::now('Asia/Kolkata'),
                ])->save();

                return [
                    'success' => true,
                    'status' => 'synced',
                    'response' => $response->json(),
                ];
            }

            $message = (string) (
                data_get($response->json(), 'message')
                ?: data_get($response->json(), 'error_msg')
                ?: ('EGC returned HTTP ' . $response->status())
            );

            $this->markFailure($callTracker, $message);

            Log::warning('EGC call tracker synchronization failed', [
                'call_tracker_id' => $callTracker->sno,
                'external_uuid' => $callTracker->external_uuid,
                'http_status' => $response->status(),
                'response' => $response->json(),
            ]);

            return [
                'success' => false,
                'status' => 'pending',
                'message' => $message,
            ];
        } catch (\Throwable $e) {
            $this->markFailure($callTracker, $e->getMessage());

            Log::warning('EGC call tracker synchronization exception', [
                'call_tracker_id' => $callTracker->sno,
                'external_uuid' => $callTracker->external_uuid,
                'exception' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'status' => 'pending',
                'message' => $e->getMessage(),
            ];
        }
    }

    private function markFailure(CallTrackerModel $callTracker, string $message): void
    {
        $callTracker->forceFill([
            'egc_sync_status' => 'pending',
            'egc_sync_error' => mb_substr($message, 0, 2000),
        ])->save();
    }
}
