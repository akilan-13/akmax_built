@extends('layouts/layoutMaster')

@section('title', 'Manage Holiday')

@section('vendor-style')
    @vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
    @vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    ])
@endsection
@section('page-script')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
        .fc-button.fc-button-primary{
            background:#ab2b22;
            border-color:white;
        }
        .fc-button.fc-button-primary:hover{
            background:white;
            border-color:#ab2b22;
            color:#ab2b22;
        }
        .fc-event {
            cursor: pointer;
            font-weight: 500;
        }
        .fc-h-event {
            border-color:#038701;
        }
        .fc .fc-button-primary:not(.fc-prev-button):not(.fc-next-button):active, .fc .fc-button-primary:not(.fc-prev-button):not(.fc-next-button).fc-button-active{
            background-color:#ab2b22 !important;
            color:white !important;
        }
        .fc .fc-button-primary:not(:disabled).fc-button-active:focus, .fc .fc-button-primary:not(:disabled):active:focus{
            box-shadow:none !important;
        }
        .fc .fc-button-primary:not(:disabled).fc-button-active, .fc .fc-button-primary:not(:disabled):active{
            background-color:#FBA919;
            border-color:#FBA919;
        }
        .fc .fc-button-primary:focus {
            box-shadow: none;
        }


    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Holiday</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_import_holiday">
                        <span class="" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Import"><i class="mdi mdi-import"></i></span>
                    </a>
                    <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_import_holiday">
                        <span class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Export"><i class="mdi mdi-export"></i></span>
                    </a> -->
                    <a href="{{ url('/entity_hub/manage_holiday') }}" class="btn btn-sm fw-bold btn-primary" >
                        <span class="" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="List View"><i class="mdi mdi-list-box-outline"></i></span>
                    </a>
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_add_holiday">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Holiday
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="container-fluid">

            <div class="card mb-3">
                <div class="card-body row g-3">

                    <div class="col-md-3">
                        <select id="companyFilter" class="form-select select3">
                            <option value="">All Companies</option>
                            <option value="0">Elysium Groups of Companies</option>
                            @foreach($companies as $company)
                                <option value="{{ $company->sno }}">
                                    {{ $company->company_name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- <div class="col-md-3">
                        <select id="statusFilter" class="form-select select3">
                            <option value="">All Status</option>
                            <option value="0">Active</option>
                            <option value="1">Inactive</option>
                        </select>
                    </div> -->

                    <div class="col-md-3">
                        <div class="d-flex justify-contnet-start gap-2">
                        <button id="filterBtn" class="btn btn-primary ">
                            <span class="mdi mdi-magnify"></span>
                        </button>
                        <button id="refreshBtn" class="btn btn-primary ">
                            <span class="mdi mdi-refresh"></span>
                        </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div id="holidayCalendar"></div>
                </div>
            </div>

        </div>
        </div>
    </div>


<!--begin::Modal - Add Drop -->
<div class="modal fade" id="kt_modal_add_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Holiday</h3>
                </div>
                <form id="AddHolidayForm" class="needs-validation" novalidate method="POST" action="{{ route('holiday_add') }}" onsubmit="return AddHolidayForm()">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday Name <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="hol_reason_add" id="hol_reason_add" placeholder="Enter Holiday Name"></textarea>
                            <div class="text-danger" id="hol_reason_add_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Company <span class="text-danger">*</span></label>
                            <select name="company_ids[]" class="select3 form-select" id="companySelectsholiday" multiple>
                                <option value="all" selected>All Companies</option>
                                <option value="0" >Elysium Groups of Companies</option>
                                @foreach ($Company as $clist)
                                    <option value="{{ $clist->sno }}">{{ $clist->company_name }}</option>
                                @endforeach
                            </select>
                            <div class="text-danger" id="company_ids_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Start Date <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_add" name="hol_date_add" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_add_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">End Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_end_add" name="hol_date_end_add" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_end_add_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="createHolidayBtn">Create Holiday</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!--end::Modal - Add Drop Reason-->

    <div class="modal fade" id="kt_modal_import_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Holiday</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Holiday Import</label>
                            <a href="javascript:;" download="Holiday Data"  class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="uploadMaterialForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf 
                        <div class="row mt-2">
                        
                    
                        <!-- File Upload -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday File<span class="text-danger">*</span></label>
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                            <p class="mb-2">Drag & Drop your files here or click to select</p>
                            <div class="small text-center mb-2">Allowed excel,.xls,.xlsx,.xlsm,.csv </div>
                            <input type="file" id="fileInput" name="file_upload" class="d-none" accept=".xls,.xlsx,.xlsm,.csv"/>
                            <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('fileInput').click()">
                                Browse Files
                            </button>
                            </div>
                            <div id="fileList" class="text-muted"></div>
                            <div class="text-danger" id="err_mssg"></div>
                        </div>
                        </div>
                    
                        <!-- Footer -->
                        <div class="row">
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <div class="position-relative">
                            <button type="submit" class="btn btn-primary" id="uploadButton">Upload</button>
                            <div id="uploadLoader" class="import-loader d-none">
                                <div class="spinner-border text-light" role="status"></div>
                                <span class="ms-2"></span>
                            </div>
                            </div>
                        </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

<!--begin::Modal - Edit Drop Reason-->
<div class="modal fade" id="kt_modal_edit_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Holiday</h3>
                </div>
                <form id="EditHolidayForm" class="needs-validation" novalidate method="POST" action="{{ route('holiday_update') }}">
                    @csrf
                    <input type="hidden" id="holiday_id" name="holiday_id" />
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday Name <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="hol_reason_edit" id="hol_reason_edit" placeholder="Enter Holiday Name"></textarea>
                            <div class="text-danger" id="hol_reason_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Company <span class="text-danger">*</span></label>
                            <select name="company_ids[]" class="select3 form-select" id="companySelectsholidayEdit" multiple>
                                <option value="all" selected>All Companies</option>
                                <option value="0" >Elysium Groups of Companies</option>
                                @foreach ($Company as $clist)
                                    <option value="{{ $clist->sno }}">{{ $clist->company_name }}</option>
                                @endforeach
                            </select>
                            <div class="text-danger" id="company_ids_edit_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Start Date <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_edit" name="hol_date_edit" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_edit_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">End Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_end_edit" name="hol_date_end_edit" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_end_edit_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Holiday</button>
                    </div>
                </form>                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Drop Reason-->

 <!--begin::Modal View Entity--->
    <div class="modal fade" id="holidayModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex align-items-center mb-2 gap-2">
                        <div class="avatar-stack">
                            <img src="{{ asset('assets/common/logo_small.png') }}" id="view_entity_logo" alt="user-avatar"
                                class="avatar-img" />
                        </div>
                        <div class="">
                            <span class="text-black fw-semibold fs-3" id="holidayTitle">View Holiday</span>
                        </div>
                    </div>
                </div>

                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-0 px-10 px-xl-20 bg-white rounded">
                    <div class="row my-3">
                        <div class="col-lg-12">
                            <div class="row mb-4">
                                <label class="col-5  text-dark fs-7 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                <div class="col-6">
                                    <div class="" id="holidayCompany"></div>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-7 fw-semibold">Start Date</label>
                                <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                <div class="col-6">
                                    <div class="" id="holidayStart"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-7 fw-semibold">End Date</label>
                                <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                <div class="col-6">
                                    <div class="" id="holidayEnd"></div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-5 text-dark fs-6 fw-semibold">Total Days</label>
                                <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                <div class="col-6">
                                    <div class="" id="holidayDays"></div>
                                    </a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -View Entity-->





{{-- entity's social media --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field-edit-entity").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>




<!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
   <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#filter_form').submit();
            }
        }
    </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

</script>
    <script>
    function AddHolidayForm() {
        var err = 0;

        // Date validation
        var hol_date_add = document.getElementById("hol_date_add").value;
        if (hol_date_add === "") {
            $('#hol_date_add_err').html('Start Date is required...!');
            err++;
        } else {
            $('#hol_date_add_err').html('');
        }
        var hol_date_end_add = document.getElementById("hol_date_end_add").value;
        if (hol_date_end_add === "") {
            $('#hol_date_end_add_err').html('End Date is required...!');
            err++;
        } else {
            $('#hol_date_end_add_err').html('');
        }

        // Holiday Name validation
        var hol_reason_add = document.getElementById("hol_reason_add").value;
        if (hol_reason_add === "") {
            $('#hol_reason_add_err').html('Holiday Name is required...!');
            err++;
        } else {
            $('#hol_reason_add_err').html('');
        }

        // Company selection validation
        var companySelect = document.getElementById("companySelectsholiday");
        var selectedCompanies = Array.from(companySelect.selectedOptions).map(opt => opt.value);

        // if (selectedCompanies.length === 0 || selectedCompanies.includes('all')) {
        //     $('#company_ids_err').html('Please select at least one company.');
        //     err++;
        // } else {
        //     $('#company_ids_err').html('');
        // }

        // If no errors, allow form submission
        if (err === 0) {
            var submitButton = document.getElementById('createHolidayBtn');
            submitButton.disabled = true;
            submitButton.innerText = 'Please wait...';
            return true;
        } else {
            return false;
        }
    }


</script>

<script>
    function EditHolidayForm() {
      var err = 0;
      var hol_date_edit = document.getElementById("hol_date_edit").value;
      if (hol_date_edit === "") {
          $('#hol_date_edit_err').html('Date is required...!');
          err++;
      } else {
          $('#hol_date_edit_err').html('');
      }
      var hol_date_end_edit = document.getElementById("hol_date_end_edit").value;
      if (hol_date_end_edit === "") {
          $('#hol_date_end_edit_err').html('Date is required...!');
          err++;
      } else {
          $('#hol_date_end_edit_err').html('');
      }

      var hol_reason_edit = document.getElementById("hol_reason_edit").value;
      if (hol_reason_edit === "") {
          $('#hol_reason_edit_err').html('Holiday Name is required...!');
          err++;
      } else {
          $('#hol_reason_edit_err').html('');
      }
    
      if (err > 0) {
            return false;
        } else {
            return true;
        }
    }
</script>

<script>
    function editmodel(element) {
        var sno = element.getAttribute('data-sno');
        var date = element.getAttribute('data-date');
        var end_date = element.getAttribute('data-enddate');
        var reason = element.getAttribute('data-reason');
        var company = JSON.parse(element.getAttribute('data-company')); 

        var formattedDate = new Date(date);

        if (isNaN(formattedDate)) {
            console.error("Invalid date format");
            return;
        }

        var day = formattedDate.getDate();
        var month = formattedDate.toLocaleString('default', { month: 'short' }); // Get short month name
        var year = formattedDate.getFullYear();

        var formattedDateString = day + '-' + month + '-' + year;

        var formattedDateEnd = new Date(end_date);

        if (isNaN(formattedDateEnd)) {
            console.error("Invalid date format");
            return;
        }

        var dayEnd = formattedDateEnd.getDate();
        var monthEnd = formattedDateEnd.toLocaleString('default', { month: 'short' }); // Get short month name
        var yearEnd = formattedDateEnd.getFullYear();

        var formattedDateEndString = dayEnd + '-' + monthEnd + '-' + yearEnd;

        // Populate the form fields
        document.getElementById('holiday_id').value = sno;
        document.getElementById('hol_date_edit').value = formattedDateString;
        document.getElementById('hol_date_end_edit').value = formattedDateEndString;
        document.getElementById('hol_reason_edit').value = reason;

        // Populate the branch select field
      
        var branchSelect = document.getElementById('companySelectsholidayEdit');
        if (branchSelect) {
            // First reset all selected
            for (let i = 0; i < branchSelect.options.length; i++) {
                branchSelect.options[i].selected = false;
            }
            
            // Now set selected those in company array
            company.forEach(function(branch_id) {
                for (let i = 0; i < branchSelect.options.length; i++) {
                    if (branchSelect.options[i].value === branch_id.toString()) { // Important: === and .toString()
                        branchSelect.options[i].selected = true;
                        break;
                    }
                }
            });
            
            // Important: trigger change event if select3/select2 is used
            branchSelect.dispatchEvent(new Event('change'));
        }



        // Check if staff or student was selected
        var staffCheckbox = document.getElementById('holiday_staff_edit');
        var studentCheckbox = document.getElementById('holiday_student_edit');

        if (staffCheckbox) {
            staffCheckbox.checked = (staff_check == 1);
        }
        if (studentCheckbox) {
            studentCheckbox.checked = (student_check == 1);
        }
    }
</script>

<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {

    let calendarEl = document.getElementById('holidayCalendar');

    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 'auto',

        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,listWeek'
        },

        events: function (info, successCallback, failureCallback) {
            $.ajax({
                url: "{{ url('/holiday-calendar/events') }}",
                data: {
                    start: info.startStr,
                    end: info.endStr,
                    company_id: $('#companyFilter').val(),
                    status: $('#statusFilter').val()
                },
                success: successCallback,
                error: failureCallback
            });
        },

        eventDidMount: function (info) {
            new bootstrap.Tooltip(info.el, {
                title: `<b>${info.event.title}</b><br>${info.event.extendedProps.company}`,
                placement: 'top',
                trigger: 'hover',
                html: true,
                container: 'body'
            });
        },

        eventClick: function (info) {

            $('#holidayTitle').text(info.event.title);
            $('#holidayCompany').text(info.event.extendedProps.company);
            $('#holidayStatus').html(
                info.event.extendedProps.status == 1
                    ? '<span class="badge bg-danger">Inactive</span>'
                    : '<span class="badge bg-success">Active</span>'
            );

            $('#holidayStart').text(info.event.start.toDateString());
            $('#holidayEnd').text(info.event.end.toDateString());
            $('#holidayDays').text(info.event.extendedProps.days + ' Days');

            $('#holidayModal').modal('show');
        }
    });

    calendar.render();

    $('#filterBtn').on('click', function () {
        calendar.refetchEvents();
    });

    $('#refreshBtn').on('click', function () {
        $('#companyFilter').val('')
        $('#companyFilter').val('').change();
        $('#statusFilter').val('');
        calendar.refetchEvents();
    });

});

    </script>


 <script>
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const fileList = document.getElementById("fileList");

        const allowedExtensions = ["xls", "xlsx", "xlsm", "csv"];

        // Highlight on drag
        dropArea.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropArea.classList.add("bg-light");
        });

        dropArea.addEventListener("dragleave", () => {
            dropArea.classList.remove("bg-light");
        });

        // Handle drop
        dropArea.addEventListener("drop", (e) => {
            e.preventDefault();
            dropArea.classList.remove("bg-light");

            const droppedFiles = Array.from(e.dataTransfer.files);
            const validFiles = droppedFiles.filter(isValidExcelFile);

            if (validFiles.length !== droppedFiles.length) {
                $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
            }else{
                $('#err_mssg').text("")
            }

            if (validFiles.length > 0) {
                fileInput.files = createFileList(validFiles);
                displayFileNames(validFiles);
                $('#err_mssg').text("")
            }
        });

        // Handle manual file selection
        fileInput.addEventListener("change", (e) => {
            const selectedFiles = Array.from(e.target.files);
            const validFiles = selectedFiles.filter(isValidExcelFile);

            if (validFiles.length !== selectedFiles.length) {
                $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
                fileInput.value = ""; // reset invalid file
                return;
            }else{
                $('#err_mssg').text("")
            }

            displayFileNames(validFiles);
        });

        // Validate file type
        function isValidExcelFile(file) {
            const ext = file.name.split(".").pop().toLowerCase();
            return allowedExtensions.includes(ext);
        }

        // Display file names
        function displayFileNames(files) {
            fileList.innerHTML = files
                .map((file, index) => `<span>${index + 1}. ${file.name}</span>`)
                .join("");
        }

        // Create a new FileList object (needed when filtering dropped files)
        function createFileList(files) {
            const dataTransfer = new DataTransfer();
            files.forEach(file => dataTransfer.items.add(file));
            return dataTransfer.files;
        }
    </script>
    <style>
        #dropArea {
            cursor: pointer;
        }
        #dropArea.bg-light {
            background-color: #f8f9fa;
        }
        #fileList p {
            margin: 0;
            font-size: 0.8rem;
        }
    </style>
    <script>

        document.getElementById('uploadMaterialForm').addEventListener('submit', function (event) {
            event.preventDefault();
            
            const errMssg = document.getElementById('err_mssg');
            errMssg.innerHTML = "";
            
            
            
            const fileInput = document.getElementById('fileInput');
            
            
            
                // ✅ For non-lab docs → file required
                if (!fileInput.value || fileInput.files.length === 0) {
                errMssg.textContent = "Please select at least one file to upload.";
                return;
                }
            
            
            const formData = new FormData();
                for (let i = 0; i < fileInput.files.length; i++) {
                formData.append('file_upload', fileInput.files[i]);
                }
            
            
            const uploadButton = document.getElementById('uploadButton');
            const uploadLoader = document.getElementById('uploadLoader');
            
            uploadButton.disabled = true;
            uploadLoader.classList.remove('d-none');
            
            fetch('{{ route("upload_holiday_calender") }}', {
                method: 'POST',
                headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                },
                body: formData
            })
                .then(async response => {
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.includes("application/json")) {
                    return response.json();
                } else {
                    const text = await response.text();
                    throw new Error("Server returned non-JSON response:\n" + text);
                }
                })
                .then(data => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                if (data.success) {
                    toastr.success('File uploaded successfully!');
                
                    // Reset full form
                    document.getElementById('uploadMaterialForm').reset();
                    // Reset file input + file list
                    $('#fileInput').val('');
                    $('#fileList').empty();
                    $('#err_mssg').text('');
                
                    // Hide modal
                    $('#kt_modal_import_holiday').modal('hide');
                }
                else {
                    errMssg.textContent = data.message || "An error occurred while uploading files.";
                }
                })
                .catch(error => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                console.error('Error:', error);
                errMssg.textContent = "An error occurred while uploading files.";
                });
        });


        function sampleToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/holiday/sample-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link
                   
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
            //  location.reload();
        }

        // Event listener for Excel export button
        $('#sample_excel').on('click', function(e) {
            // e.preventDefault();
            sampleToExcel();
             setTimeout(function() {
                location.reload();
            }, 2000); // 2000 milliseconds = 2 seconds           
        });
    </script>
    
@endsection
