@extends('layouts/layoutMaster')

@section('title', 'Manage Holiday')

@section('vendor-style')
    @vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
    @vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    ])
@endsection
@section('page-script')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Holiday</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_import_holiday">
                        <span class="" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Import"><i class="mdi mdi-import"></i></span>
                    </a>
                    <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_import_holiday">
                        <span class="me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Export"><i class="mdi mdi-export"></i></span>
                    </a> -->
                    <a  href="{{ url('/entity_hub/holiday_calender') }}" class="btn btn-sm fw-bold btn-primary" >
                        <span class="" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Calender View"><i class="mdi mdi-calendar-month-outline"></i></span>
                    </a>
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_add_holiday">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Holiday
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                   <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Holiday..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Holiday</th>
                                <th class="min-w-100px">Date</th>
                                <th class="min-w-150px">Company </th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>



    


   <div class="modal fade" id="kt_modal_import_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Holiday</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Holiday Import</label>
                            <a href="javascript:;" download="Holiday Data"  class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="uploadMaterialForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf 
                        <div class="row mt-2">
                        
                    
                        <!-- File Upload -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday File<span class="text-danger">*</span></label>
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                            <p class="mb-2">Drag & Drop your files here or click to select</p>
                            <div class="small text-center mb-2">Allowed excel,.xls,.xlsx,.xlsm,.csv </div>
                            <input type="file" id="fileInput" name="file_upload" class="d-none" accept=".xls,.xlsx,.xlsm,.csv"/>
                            <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('fileInput').click()">
                                Browse Files
                            </button>
                            </div>
                            <div id="fileList" class="text-muted"></div>
                            <div class="text-danger" id="err_mssg"></div>
                        </div>
                        </div>
                    
                        <!-- Footer -->
                        <div class="row">
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <div class="position-relative">
                            <button type="submit" class="btn btn-primary" id="uploadButton">Upload</button>
                            <div id="uploadLoader" class="import-loader d-none">
                                <div class="spinner-border text-light" role="status"></div>
                                <span class="ms-2"></span>
                            </div>
                            </div>
                        </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>


<!--begin::Modal - Add Drop -->
<div class="modal fade" id="kt_modal_add_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <div class="modal-dialog modal-md">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Holiday</h3>
                </div>
                <form id="AddHolidayForm" class="needs-validation" novalidate method="POST" action="{{ route('holiday_add') }}" onsubmit="return AddHolidayForm()">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday Name <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="hol_reason_add" id="hol_reason_add" placeholder="Enter Holiday Name"></textarea>
                            <div class="text-danger" id="hol_reason_add_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Company <span class="text-danger">*</span></label>
                            <select name="company_ids[]" class="select3 form-select" id="companySelectsholiday" multiple>
                                <option value="all" selected>All Companies</option>
                                <option value="0" >Elysium Groups of Companies</option>
                                @foreach ($Company as $clist)
                                    <option value="{{ $clist->sno }}">{{ $clist->company_name }}</option>
                                @endforeach
                            </select>
                            <div class="text-danger" id="company_ids_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Start Date <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_add" name="hol_date_add" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_add_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">End Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_end_add" name="hol_date_end_add" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_end_add_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="createHolidayBtn">Create Holiday</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!--end::Modal - Add Drop Reason-->

<!--begin::Modal - Edit Drop Reason-->
<div class="modal fade" id="kt_modal_edit_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Update Holiday</h3>
                </div>
                <form id="EditHolidayForm" class="needs-validation" novalidate method="POST" action="{{ route('holiday_update') }}">
                    @csrf
                    <input type="hidden" id="holiday_id" name="holiday_id" />
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Holiday Name <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="hol_reason_edit" id="hol_reason_edit" placeholder="Enter Holiday Name"></textarea>
                            <div class="text-danger" id="hol_reason_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Company <span class="text-danger">*</span></label>
                            <select name="company_ids[]" class="select3 form-select" id="companySelectsholidayEdit" multiple>
                                <option value="all" selected>All Companies</option>
                                <option value="0" >Elysium Groups of Companies</option>
                                @foreach ($Company as $clist)
                                    <option value="{{ $clist->sno }}">{{ $clist->company_name }}</option>
                                @endforeach
                            </select>
                            <div class="text-danger" id="company_ids_edit_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Start Date <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_edit" name="hol_date_edit" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_edit_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">End Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="hol_date_end_edit" name="hol_date_end_edit" readonly placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y') ?>" />
                            </div>
                            <div class="text-danger" id="hol_date_end_edit_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Holiday</button>
                    </div>
                </form>                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Drop Reason-->

<!--begin::Modal - Delete Drop Reason -->
<div class="modal fade" id="kt_modal_delete_holiday" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"> <span
                    id="delete_message"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal"
                    onclick="deleteCourseCategory()">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Drop Reason-->
    

{{-- entity's social media --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field-edit-entity").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>

<!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
   <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#filter_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#filter_form').submit();
            }
        }
    </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
   
    function buildRow(item,index) {
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        return `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="text-truncate max-w-175px fw-medium fs-7" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" data-bs-original-title="${data.hol_reason}">${data.hol_reason}</div>
                    </div>
                </td>
                <td>
                    <label class="badge bg-success fw-semibold text-white fs-8 d-block text-nowrap mb-2">
                        ${data.hol_date ? formatDateCommon(data.hol_date) : '-'}
                    </label>
                    ${item.totalDays > 1 ? 
                    `<label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                        ${data.hol_date ? formatDateCommon(data.hol_end_date) : '-'}
                    </label>`
                    :
                    ''
                    }
                    
                </td>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-175px fw-medium fs-7 "
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="${item.company_names}">${item.company_names}
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatusEntity('${item.sno}', this.checked)" />
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                    <div class="text-center">
                        <a class="btn btn-icon btn-sm waves-effect waves-light" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width:200px !important">
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_edit_holiday"
                                 data-sno="${data.sno}"
                                    data-date="${data.hol_date}"
                                    data-enddate="${data.hol_end_date}"
                                    data-reason="${data.hol_reason}"
                                    data-company='${data.company_ids}'
                                 onclick="editmodel(this)">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_delete_holiday" onclick="confirmDelete('${item.sno}','${data.hol_date}','${data.hol_reason}')">
                                <span><i
                                        class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/entity_hub/manage_holiday?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(5));
            }
                 $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>
    <script>
    function AddHolidayForm() {
        var err = 0;

        // Date validation
        var hol_date_add = document.getElementById("hol_date_add").value;
        if (hol_date_add === "") {
            $('#hol_date_add_err').html('Start Date is required...!');
            err++;
        } else {
            $('#hol_date_add_err').html('');
        }
        var hol_date_end_add = document.getElementById("hol_date_end_add").value;
        if (hol_date_end_add === "") {
            $('#hol_date_end_add_err').html('End Date is required...!');
            err++;
        } else {
            $('#hol_date_end_add_err').html('');
        }

        // Holiday Name validation
        var hol_reason_add = document.getElementById("hol_reason_add").value;
        if (hol_reason_add === "") {
            $('#hol_reason_add_err').html('Holiday Name is required...!');
            err++;
        } else {
            $('#hol_reason_add_err').html('');
        }

        // Company selection validation
        var companySelect = document.getElementById("companySelectsholiday");
        var selectedCompanies = Array.from(companySelect.selectedOptions).map(opt => opt.value);

        // if (selectedCompanies.length === 0 || selectedCompanies.includes('all')) {
        //     $('#company_ids_err').html('Please select at least one company.');
        //     err++;
        // } else {
        //     $('#company_ids_err').html('');
        // }

        // If no errors, allow form submission
        if (err === 0) {
            var submitButton = document.getElementById('createHolidayBtn');
            submitButton.disabled = true;
            submitButton.innerText = 'Please wait...';
            return true;
        } else {
            return false;
        }
    }


</script>

<script>
    function EditHolidayForm() {
      var err = 0;
      var hol_date_edit = document.getElementById("hol_date_edit").value;
      if (hol_date_edit === "") {
          $('#hol_date_edit_err').html('Date is required...!');
          err++;
      } else {
          $('#hol_date_edit_err').html('');
      }
      var hol_date_end_edit = document.getElementById("hol_date_end_edit").value;
      if (hol_date_end_edit === "") {
          $('#hol_date_end_edit_err').html('Date is required...!');
          err++;
      } else {
          $('#hol_date_end_edit_err').html('');
      }

      var hol_reason_edit = document.getElementById("hol_reason_edit").value;
      if (hol_reason_edit === "") {
          $('#hol_reason_edit_err').html('Holiday Name is required...!');
          err++;
      } else {
          $('#hol_reason_edit_err').html('');
      }
    
      if (err > 0) {
            return false;
        } else {
            return true;
        }
    }
</script>

<script>
    function editmodel(element) {
        var sno = element.getAttribute('data-sno');
        var date = element.getAttribute('data-date');
        var end_date = element.getAttribute('data-enddate');
        var reason = element.getAttribute('data-reason');
        var company = JSON.parse(element.getAttribute('data-company')); 

        var formattedDate = new Date(date);

        if (isNaN(formattedDate)) {
            console.error("Invalid date format");
            return;
        }

        var day = formattedDate.getDate();
        var month = formattedDate.toLocaleString('default', { month: 'short' }); // Get short month name
        var year = formattedDate.getFullYear();

        var formattedDateString = day + '-' + month + '-' + year;

        var formattedDateEnd = new Date(end_date);

        if (isNaN(formattedDateEnd)) {
            console.error("Invalid date format");
            return;
        }

        var dayEnd = formattedDateEnd.getDate();
        var monthEnd = formattedDateEnd.toLocaleString('default', { month: 'short' }); // Get short month name
        var yearEnd = formattedDateEnd.getFullYear();

        var formattedDateEndString = dayEnd + '-' + monthEnd + '-' + yearEnd;

        // Populate the form fields
        document.getElementById('holiday_id').value = sno;
        document.getElementById('hol_date_edit').value = formattedDateString;
        document.getElementById('hol_date_end_edit').value = formattedDateEndString;
        document.getElementById('hol_reason_edit').value = reason;

        // Populate the branch select field
      
        var branchSelect = document.getElementById('companySelectsholidayEdit');
        if (branchSelect) {
            // First reset all selected
            for (let i = 0; i < branchSelect.options.length; i++) {
                branchSelect.options[i].selected = false;
            }
            
            // Now set selected those in company array
            company.forEach(function(branch_id) {
                for (let i = 0; i < branchSelect.options.length; i++) {
                    if (branchSelect.options[i].value === branch_id.toString()) { // Important: === and .toString()
                        branchSelect.options[i].selected = true;
                        break;
                    }
                }
            });
            
            // Important: trigger change event if select3/select2 is used
            branchSelect.dispatchEvent(new Event('change'));
        }



        // Check if staff or student was selected
        var staffCheckbox = document.getElementById('holiday_staff_edit');
        var studentCheckbox = document.getElementById('holiday_student_edit');

        if (staffCheckbox) {
            staffCheckbox.checked = (staff_check == 1);
        }
        if (studentCheckbox) {
            studentCheckbox.checked = (student_check == 1);
        }
    }
</script>




<script>
    function confirmDelete(id, date, name) {
        const deleteButton = document.querySelector('#kt_modal_delete_holiday .btn-danger');
        
        if (deleteButton) {
            var formattedDate = new Date(date);
            if (isNaN(formattedDate)) {
                console.error("Invalid date format");
                return;
            }
            var day = formattedDate.getDate();
            var month = formattedDate.toLocaleString('default', { month: 'short' }); 
            var year = formattedDate.getFullYear();

            var formattedDateString = day + '-' + month + '-' + year;

            deleteButton.setAttribute('data-id', id);

            $('#delete_message').html(`Are you sure you want to delete <br> <b>${name} - ${formattedDateString}</b> Holiday?`);
        } else {
            console.error('Delete button not found');
        }
    }

    function deleteCourseCategory() {
        const deleteButton = document.querySelector('#kt_modal_delete_holiday .btn-danger');
        const categoryId = deleteButton ? deleteButton.getAttribute('data-id') : null;

        if (categoryId) {
            fetch(`/holiday_delete/${categoryId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Ensure CSRF token is set correctly
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.message);
                }
            })
            .catch(error => {
                toastr.error('An error occurred. Please try again. ' + error.message);
            });
        } else {
            toastr.error('Category ID not found.');
        }
    }

</script>
<script>
    function updatelevelStatusEntity(UniversityId, isChecked) {
        const status = isChecked ? 0 : 1; // Set status based on checkbox state

        fetch(`/holiday_status/${UniversityId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Holiday status Updated successfully!');
                    loadThemes(1);
                } else {
                    toastr.error('Error updating Holiday status');
                }
            })
            .catch(error => {
                console.error('Error updating Holiday status:', error);
            });
    }
</script>


 <script>
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const fileList = document.getElementById("fileList");

        const allowedExtensions = ["xls", "xlsx", "xlsm", "csv"];

        // Highlight on drag
        dropArea.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropArea.classList.add("bg-light");
        });

        dropArea.addEventListener("dragleave", () => {
            dropArea.classList.remove("bg-light");
        });

        // Handle drop
        dropArea.addEventListener("drop", (e) => {
            e.preventDefault();
            dropArea.classList.remove("bg-light");

            const droppedFiles = Array.from(e.dataTransfer.files);
            const validFiles = droppedFiles.filter(isValidExcelFile);

            if (validFiles.length !== droppedFiles.length) {
                $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
            }else{
                $('#err_mssg').text("")
            }

            if (validFiles.length > 0) {
                fileInput.files = createFileList(validFiles);
                displayFileNames(validFiles);
                $('#err_mssg').text("")
            }
        });

        // Handle manual file selection
        fileInput.addEventListener("change", (e) => {
            const selectedFiles = Array.from(e.target.files);
            const validFiles = selectedFiles.filter(isValidExcelFile);

            if (validFiles.length !== selectedFiles.length) {
                $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
                fileInput.value = ""; // reset invalid file
                return;
            }else{
                $('#err_mssg').text("")
            }

            displayFileNames(validFiles);
        });

        // Validate file type
        function isValidExcelFile(file) {
            const ext = file.name.split(".").pop().toLowerCase();
            return allowedExtensions.includes(ext);
        }

        // Display file names
        function displayFileNames(files) {
            fileList.innerHTML = files
                .map((file, index) => `<span>${index + 1}. ${file.name}</span>`)
                .join("");
        }

        // Create a new FileList object (needed when filtering dropped files)
        function createFileList(files) {
            const dataTransfer = new DataTransfer();
            files.forEach(file => dataTransfer.items.add(file));
            return dataTransfer.files;
        }
    </script>
    <style>
        #dropArea {
            cursor: pointer;
        }
        #dropArea.bg-light {
            background-color: #f8f9fa;
        }
        #fileList p {
            margin: 0;
            font-size: 0.8rem;
        }
    </style>
    <script>

        document.getElementById('uploadMaterialForm').addEventListener('submit', function (event) {
            event.preventDefault();
            
            const errMssg = document.getElementById('err_mssg');
            errMssg.innerHTML = "";
            
            
            
            const fileInput = document.getElementById('fileInput');
            
            
            
                // ✅ For non-lab docs → file required
                if (!fileInput.value || fileInput.files.length === 0) {
                errMssg.textContent = "Please select at least one file to upload.";
                return;
                }
            
            
            const formData = new FormData();
                for (let i = 0; i < fileInput.files.length; i++) {
                formData.append('file_upload', fileInput.files[i]);
                }
            
            
            const uploadButton = document.getElementById('uploadButton');
            const uploadLoader = document.getElementById('uploadLoader');
            
            uploadButton.disabled = true;
            uploadLoader.classList.remove('d-none');
            
            fetch('{{ route("upload_holiday_calender") }}', {
                method: 'POST',
                headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                },
                body: formData
            })
                .then(async response => {
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.includes("application/json")) {
                    return response.json();
                } else {
                    const text = await response.text();
                    throw new Error("Server returned non-JSON response:\n" + text);
                }
                })
                .then(data => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                if (data.success) {
                    toastr.success('File uploaded successfully!');
                
                    // Reset full form
                    document.getElementById('uploadMaterialForm').reset();
                    // Reset file input + file list
                    $('#fileInput').val('');
                    $('#fileList').empty();
                    $('#err_mssg').text('');
                
                    // Hide modal
                    $('#kt_modal_import_holiday').modal('hide');
                }
                else {
                    errMssg.textContent = data.message || "An error occurred while uploading files.";
                }
                })
                .catch(error => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                console.error('Error:', error);
                errMssg.textContent = "An error occurred while uploading files.";
                });
        });


        function sampleToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/holiday/sample-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link
                   
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
            //  location.reload();
        }

        // Event listener for Excel export button
        $('#sample_excel').on('click', function(e) {
            // e.preventDefault();
            sampleToExcel();
             setTimeout(function() {
                location.reload();
            }, 2000); // 2000 milliseconds = 2 seconds           
        });
    </script>
@endsection
