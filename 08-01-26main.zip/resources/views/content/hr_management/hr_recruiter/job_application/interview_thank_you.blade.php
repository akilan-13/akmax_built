<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Interview Completed - {{$applicant->applicant_name}}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

     <!-- Minimal Favicon Setup -->
    <link rel="icon" href="{{ asset('assets/common/logo_small.png') }}" type="image/png">
    <link rel="apple-touch-icon" href="{{ asset('assets/common/logo_small.png') }}">

    <!-- Add to homescreen meta tags -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

  <style>
    /* Mobile-First CSS Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
    }

    :root {
        --primary: #ab2b22;
        --primary-light: #ffeeecff;
        --primary-dark: #3a56d4;
        --success: #2ecc71;
        --success-light: #e8f8ef;
        --danger: #e74c3c;
        --danger-light: #fdedec;
        --warning: #fba919;
        --dark: #2c3e50;
        --light: #f8f9fa;
        --gray: #95a5a6;
        --border: #e1e8ed;
        --shadow: 0 2px 10px rgba(0,0,0,0.08);
        --shadow-lg: 0 5px 20px rgba(0,0,0,0.15);
        --radius: 16px;
        --radius-sm: 8px;
        --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        background: linear-gradient(135deg, #f5f7fb 0%, #e8edff 100%);
        color: var(--dark);
        line-height: 1.5;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        overflow-x: hidden;
        min-height: 100vh;
        padding-bottom: env(safe-area-inset-bottom);
    }

    /* Safe area for iPhone X+ */
    @supports (padding: max(0px)) {
        body {
            padding-left: max(0px, env(safe-area-inset-left));
            padding-right: max(0px, env(safe-area-inset-right));
        }
    }

    /* Main Container */
    .container {
        max-width: 100%;
        padding: 0;
        margin: 0 auto;
        min-height: 100vh;
    }

    /* Curved Header Background */
    .header-background {
        background: linear-gradient(135deg, var(--warning), #ab2b22);
        height: 160px;
        border-bottom-left-radius: 40px;
        border-bottom-right-radius: 40px;
        position: relative;
        overflow: hidden;
        padding: 20px;
        padding-top: max(40px, env(safe-area-inset-top));
        box-shadow: 0 4px 20px rgba(67, 97, 238, 0.3);
    }

    .header-background::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 100px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        transform: translateY(-50%);
    }

    /* Enhanced Language Selector */
    .language-selector {
        background: white;
        border-radius: var(--radius);
        padding: 25px;
        margin: 20px;
        box-shadow: var(--shadow-lg);
        border: none;
        position: relative;
        z-index: 10;
    }

    @media (min-width: 768px) {
        .language-selector {
            max-width: 500px;
            margin: 30px auto;
        }
    }

    .language-header {
        text-align: center;
        margin-bottom: 25px;
        color: var(--primary);
        font-size: 22px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
    }

    .language-header i {
        font-size: 28px;
        margin-top:6px
    }

    .language-dropdown-container {
        position: relative;
        margin-bottom: 15px;
    }


    .custom-select {
        position: relative;
        width: 100%;
    }

    .custom-select-trigger {
        padding: 18px 20px;
        border: 2px solid var(--primary-light);
        border-radius: var(--radius);
        background: #fff;
        font-size: 17px;
        font-weight: 600;
        color: var(--dark);
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(67, 97, 238, 0.1);
        background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%234361ee' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 20px center;
        background-size: 24px;
    }

    .custom-options {
      position: absolute;
      width: 100%;
      background: white;
      border: 2px solid var(--primary-light);
      border-radius: var(--radius);
      margin-top: 6px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.12);
      display: none;
      max-height: 250px;
      overflow-y: auto;
      z-index: 99999;
    }

    .custom-select.open .custom-options {
        display: block;
    }

    .custom-option {
        padding: 15px 20px;
        font-size: 16px;
        cursor: pointer;
        transition: 0.2s;
    }

    .custom-option:hover {
        background: rgba(67, 97, 238, 0.08);
    }

    .custom-option.selected {
        background: rgba(67, 97, 238, 0.15);
        font-weight: 700;
    }


    .language-note {
        /* text-align: center; */
        font-size: 14px;
        color: var(--gray);
        margin-top: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    /* Company Logo in Curved Header */
    .logo-center {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80px;
        position: relative;
        z-index: 2;
        margin-bottom: 20px;
       
    }

    .logo-center img {
        max-height: 60px;
        max-width: 200px;
        object-fit: contain;
        filter: drop-shadow(0 2px 8px rgba(0,0,0,0.1));
    }

    /* Sticky Header Section */
    .sticky-header {
        position: sticky;
        top: 0;
        z-index: 100;
        /* background: white; */
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        border-bottom-left-radius: 20px;
        border-bottom-right-radius: 20px;
        /* padding: 15px 0 10px; */
        margin-bottom: 15px;
    }

    /* Student Profile */
    .student-info {
        background: white;
        margin: -40px 20px 20px;
        padding: 13px;
        border-radius: var(--radius);
        box-shadow: var(--shadow-lg);
        position: relative;
        z-index: 5;
    }

    .student-profile {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .student-pic {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid var(--primary-light);
        box-shadow: 0 4px 12px rgba(171, 43, 34, 0.2);
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        flex-shrink: 0;
    }

    @media (min-width: 768px) {
        .student-pic {
            width: 80px;
            height: 80px;
        }
    }

    .student-pic img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .student-pic.fallback {
        background: linear-gradient(135deg, var(--primary), #fba919);
        color: white;
        font-size: 24px;
        font-weight: bold;
    }

    .student-details {
        flex: 1;
        min-width: 0;
    }

    .student-name {
        font-size: 22px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 5px;
    }

    .student-subtitle {
        color: var(--gray);
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Enhanced Sticky Section Tabs */
    .section-tabs-container {
        position: sticky;
        top: 0;
        z-index: 90;
        background: white;
        padding: 12px 0;
        box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        margin-bottom: 10px;
    }

    @media (max-height: 700px) {
        .section-tabs-container {
            top: 0;
        }
    }

    .section-tabs {
        display: flex;
        overflow-x: auto;
        gap: 8px;
        padding: 0 20px;
        scrollbar-width: none;
        -ms-overflow-style: none;
        scroll-padding-left: 20px;
    }

    .section-tabs::-webkit-scrollbar {
        display: none;
    }

    .section-tab {
        padding: 14px 22px;
        background: white;
        border-radius: 50px;
        font-weight: 600;
        font-size: 14px;
        color: var(--gray);
        white-space: nowrap;
        border: 2px solid var(--border);
        cursor: pointer;
        transition: var(--transition);
        flex-shrink: 0;
        position: relative;
        overflow: hidden;
    }

    @media (min-width: 768px) {
        .section-tabs {
            justify-content: center;
        }

        .section-tab {
            padding: 16px 24px;
            font-size: 15px;
        }
    }

    .section-tab::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 3px;
        background: var(--primary);
        transition: var(--transition);
    }

    .section-tab:hover {
        border-color: var(--primary-light);
    }

    .section-tab.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(67, 97, 238, 0.2);
    }

    .section-tab.active::after {
        width: 80%;
    }

    .section-tab.completed {
        background: var(--success-light);
        border-color: var(--success);
        color: var(--success);
    }

    /* Current Section Info - Sticky */
    .current-section-container {
        position: sticky;
        top: 65px;
        z-index: 80;
        background: white;
        padding: 15px 20px;
        margin: 0;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        border-left: 4px solid var(--primary);
        margin-bottom: 20px;
    }

    @media (min-width: 768px) {
        .current-section-container {
            top: 70px;
        }
    }

    @media (max-height: 700px) {
        .current-section-container {
            top: 55px;
        }
    }

    .current-section {
        display: flex;
        align-items: center;
        gap: 15px;
        background: transparent;
        padding: 0;
        margin: 0;
        box-shadow: none;
        border: none;
    }

    .section-icon {
        width: 45px;
        height: 45px;
        background: linear-gradient(135deg, var(--primary), #fba919);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 18px;
        box-shadow: 0 4px 12px rgba(171, 43, 34, 0.3);
    }

    .section-info {
        flex: 1;
    }

    .section-info h3 {
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 6px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .section-info p {
        font-size: 14px;
        color: var(--gray);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* Progress Indicator */
    .section-progress {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 8px;
    }

    .progress-bar-section {
        flex: 1;
        height: 6px;
        background: var(--border);
        border-radius: 3px;
        overflow: hidden;
    }

    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--primary), #fba919);
        border-radius: 3px;
        transition: width 0.5s ease;
    }

    .progress-text {
        font-size: 12px;
        font-weight: 600;
        color: var(--primary);
        white-space: nowrap;
    }

    /* Questions Container */
    .questions-container {
        padding: 0 20px 140px;
        position: relative;
        z-index: 1;
    }

    @media (min-width: 1024px) {
        .questions-container {
            padding: 0 40px 120px;
        }
    }

    /* Enhanced Question Card */
    .question-card {
        background: white;
        border-radius: var(--radius);
        margin-bottom: 20px;
        padding: 18px;
        box-shadow: var(--shadow);
        border: 2px solid transparent;
        position: relative;
        transition: var(--transition);
        animation: slideIn 0.4s ease forwards;
        opacity: 0;
    }

    .question-card.active {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
        transform: translateY(-2px);
    }

    .question-number {
        display: flex;
        align-items: center;
        gap: 12px;
        /* margin-bottom: 16px; */
    }

    .number-circle {
        width: 32px;
        height: 32px;
        background: var(--primary-light);
        color: var(--primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 15px;
        flex-shrink: 0;
    }

    .question-text {
        font-size: 14px;
        margin-bottom:6px;
        font-weight: 600;
        line-height: 1.4;
        color: var(--dark);
        flex: 1;
    }

    /* Answer Options */
    .options-container {
        margin-top: 15px;
    }

    .yesno-options {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 15px;
    }

    .yesno-option {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 10px;
        border-radius: var(--radius);
        border: 2px solid var(--border);
        background: white;
        transition: var(--transition);
        cursor: pointer;
        text-align: center;
        min-height: 100px;
    }

    .yesno-option.selected-yes {
        border-color: var(--success);
        background: var(--success-light);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(46, 204, 113, 0.15);
    }

    .yesno-option.selected-no {
        border-color: var(--danger);
        background: var(--danger-light);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(231, 76, 60, 0.15);
    }

    .yesno-option i {
        font-size: 32px;
        margin-bottom: 8px;
    }

    .yesno-option.selected-yes i {
        color: var(--success);
    }

    .yesno-option.selected-no i {
        color: var(--danger);
    }

    /* Rating Slider */
    /* .rating-container {
        padding: 15px 0;
    } */

    .emoji-scale {
        display: flex;
        justify-content: space-between;
        /* margin-bottom: 15px; */
        overflow-x: auto;
        /* padding-bottom: 10px; */
    }

    .emoji-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 8px 4px;
        border-radius: var(--radius-sm);
        cursor: pointer;
        transition: var(--transition);
        min-width: 50px;
        flex-shrink: 0;
    }

    .emoji-item.active {
        background: var(--primary-light);
        transform: scale(1.1);
    }

    .emoji {
        font-size: 20px;
        margin-bottom: 5px;
        transition: var(--transition);
    }

    .emoji-label {
        font-size: 11px;
        color: var(--gray);
        text-align: center;
        white-space: nowrap;
    }

    .mobile-slider {
        width: 100%;
        height: 8px;
        -webkit-appearance: none;
        appearance: none;
        background: linear-gradient(to right, var(--danger), var(--warning), var(--success));
        border-radius: 4px;
        outline: none;
        margin: 20px 0;
    }

    .mobile-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 44px;
        height: 44px;
        background: white;
        border-radius: 50%;
        border: 4px solid var(--primary);
        box-shadow: 0 3px 12px rgba(0,0,0,0.2);
        cursor: pointer;
        transition: var(--transition);
    }

    .rating-value {
        text-align: center;
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        background: var(--primary-light);
        padding: 12px 24px;
        border-radius: 50px;
        display: inline-block;
        margin: 10px auto;
        min-width: 120px;
    }

    /* Multiple Choice Options */
    .mcq-options {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
    }

    @media (min-width: 768px) {
        .mcq-options {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    .mcq-option {
        padding: 16px;
        border: 2px solid var(--border);
        border-radius: var(--radius);
        background: white;
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
        transition: var(--transition);
    }

    .mcq-option.selected {
        border-color: var(--primary);
        background: var(--primary-light);
    }

    .mcq-option .option-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-weight: 700;
        font-size: 16px;
        flex-shrink: 0;
    }

    .mcq-option.selected .option-icon {
        background: var(--primary);
        color: white;
    }

    /* Question Validation */
    .validation-message {
        background: var(--danger-light);
        color: var(--danger);
        padding: 12px 16px;
        border-radius: var(--radius);
        margin: 10px 0 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        font-size: 14px;
        border: 2px solid var(--danger);
        animation: shake 0.5s ease;
    }

    /* Navigation Footer */
    .navigation-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: white;
        padding: 16px 20px;
        padding-bottom: max(16px, env(safe-area-inset-bottom));
        display: flex;
        gap: 12px;
        box-shadow: 0 -2px 20px rgba(0,0,0,0.1);
        z-index: 1000;
    }

    @media (min-width: 1024px) {
        .navigation-footer {
            padding: 20px 40px;
            padding-bottom: max(20px, env(safe-area-inset-bottom));
        }
    }

    .nav-btn {
        flex: 1;
        padding: 16px;
        border: none;
        border-radius: var(--radius);
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: var(--transition);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        min-height: 56px;
    }

    .nav-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .nav-btn:active:not(:disabled) {
        transform: translateY(2px);
    }

    .btn-prev {
        background: white;
        color: var(--gray);
        border: 2px solid var(--border);
    }

    .btn-next {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
        border: none;
        box-shadow: var(--shadow);
    }

    .btn-submit {
        background:  var(--primary);
        color: white;
        border: none;
        box-shadow: var(--shadow);
    }

    /* Thank You Screen */
    .thank-you-container {
        padding: 40px 20px;
        min-height: 70vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
    }

    .success-animation {
        width: 120px;
        height: 120px;
        background: linear-gradient(135deg, var(--success), #27ae60);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 30px;
        animation: scaleIn 0.6s ease, float 3s ease-in-out infinite;
    }

    .success-animation i {
        font-size: 50px;
        color: white;
    }

    .thank-you-title {
        font-size: 24px;
        font-weight: 800;
        color: var(--dark);
        margin-bottom: 15px;
        background: linear-gradient(135deg, var(--primary), #fba919);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Loading States */
    .loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 60px 20px;
        gap: 20px;
    }

    .loader {
        width: 60px;
        height: 60px;
        border: 4px solid var(--primary-light);
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    /* Animations */
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes scaleIn {
        from {
            transform: scale(0);
            opacity: 0;
        }
        to {
            transform: scale(1);
            opacity: 1;
        }
    }

    @keyframes float {
        0%, 100% {
            transform: translateY(0);
        }
        50% {
            transform: translateY(-10px);
        }
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }

    /* Touch Optimizations */
    @media (hover: none) and (pointer: coarse) {
        .yesno-option,
        .mcq-option,
        .emoji-item {
            min-height: 44px;
        }

        .nav-btn {
            min-height: 56px;
        }

        .mobile-slider::-webkit-slider-thumb {
            width: 48px;
            height: 48px;
        }
    }

    /* Container Responsive */
    @media (min-width: 768px) {
        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header-background {
            height: 180px;
            border-bottom-left-radius: 50px;
            border-bottom-right-radius: 50px;
        }
    }

    @media (min-width: 1024px) {
        .container {
            max-width: 800px;
        }
    }

    /* Dark Mode */
    @media (prefers-color-scheme: dark) {
        :root {
            --dark: #ecf0f1;
            --light: #2c3e50;
            --border: #34495e;
            --gray: #bdc3c7;
            --primary-light: rgba(67, 97, 238, 0.2);
        }

        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }

        .header-background {
            background: linear-gradient(135deg, #3a56d4, #5a4fcf);
        }

        .language-selector,
        .student-info,
        .question-card,
        .current-section-container,
        .section-tab {
            background: #2c3e50;
            border-color: #34495e;
        }

        .navigation-footer {
            background: #2c3e50;
        }

        .btn-prev {
            background: #34495e;
            border-color: #4a6278;
            color: #ecf0f1;
        }
    }

    /* radio */
    /* Inline wrapper */
    .language-inline-wrap {
        display: flex;
        align-items: center;
        gap: 40px;
        flex-wrap: wrap; /* mobile friendly */
    }

    /* Radios inline */
    .language-radio-container {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-top: 0;
        margin-left:30px
    }

    /* Radio item */
    .language-radio {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        font-size: 15px;
    }

    /* Hide native radio */
    .language-radio input {
        display: none;
    }

    /* Custom radio */
    .radio-custom {
        width: 22px;
        height: 22px;
        border: 2px solid #ddd;
        border-radius: 50%;
        position: relative;
    }

    /* Checked dot */
    .language-radio input:checked + .radio-custom::after {
        content: '';
        width: 10px;
        height: 10px;
        background: #fba919;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    /* Label */
    .radio-label {
        font-weight: 500;
        white-space: nowrap;
    }

    /* Go button */
    #languageSubmit {
        padding: 8px 20px;
        font-size: 1rem;
        font-weight: 700;
        color: #fff;
        background-color: var(--primary);
        border: none;
        border-radius: 13px;
        cursor: pointer;
        transition: background 0.3s, transform 0.2s;
    }

    #languageSubmit:hover {
        transform: translateY(-2px);
    }

    #languageSubmit:active {
        transform: translateY(0);
    }
    /* poppers */
    #confettiCanvas {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
    }

  </style>
</head>

<body>
    <div class="container">
        <!-- Thank You Screen -->
        <div id="thankYouScreen" style="display: none;"></div>


    </div>
    <script src="https://cdn.jsdelivr.net/npm/tsparticles@3/tsparticles.bundle.min.js"></script>
 


  <script>
    // Pass PHP variables to JavaScript
    const CUSTOMER_NAME = "{{$applicant->applicant_name}}";
    const BATCH_ID = "";
    const CATEGORY_ID = "";
    const SCHEDULE_ID = "";
    const category_name = "{{$applicant->interview_category_name}}";
    const FEEDBACK_SUBMITTED = 'true';
    window.COUPON = "";
    window.PERCENTAGE = "";

    // Mobile-optimized feedback system with wizard sections
    const FeedbackApp = {
        init() {

            this.showThankYou();
            return;
        },
        showThankYou() {

            console.log('✅ showThankYou CALLED');
            const appScreen = document.getElementById('appScreen');
            const thankYouScreen = document.getElementById('thankYouScreen');

            if (appScreen) appScreen.style.display = 'none';
            if (thankYouScreen) thankYouScreen.style.display = 'block';

            thankYouScreen.innerHTML = `
                <!-- Confetti Layer -->
                <canvas id="confettiCanvas"></canvas>

                <div class="thank-you-container">
                    <div class="success-animation">
                        <i class="fas fa-check"></i>
                    </div>

                    <h1 class="thank-you-title">
                        🎉 Thank You${CUSTOMER_NAME ? ' ' + CUSTOMER_NAME : ''}
                    </h1>

                    <p class="thank-you-message">
                        You have successfully completed your interview.
                    </p>

                    <div style="margin-top: 25px; background: rgba(251, 165, 25, 0.08); padding: 20px; border-radius: var(--radius); max-width: 420px;">
                        <h3 style="color: var(--primary); margin-bottom: 10px; font-size: 16px;">
                            <i class="fas fa-info-circle"></i> What Happens Next?
                        </h3>

                        <ul style="font-size: 14px; color: var(--dark); line-height: 1.6; padding-left: 20px; margin: 0; text-align:start;">
                            <li>
                                Thank you for completing the 
                                <strong>${category_name || 'interview'}</strong> 
                                with <strong>Elysium Group of Companies</strong>.
                            </li>
                            <li>
                                Your interview responses have been successfully recorded.
                            </li>
                            <li>
                                Our recruitment team will review your interview and assess your profile.
                            </li>
                            <li>
                                If you are shortlisted, our HR or technical team will reach out to you for the next steps.
                            </li>
                            <li>
                                Please monitor your registered email and phone number for further communication.
                            </li>
                        </ul>
                    </div>

                    <p style="margin-top: 20px; font-size: 13px; color: #666;">
                        We appreciate your interest in opportunities at Elysium Group of Companies and wish you all the best.
                    </p>
                </div>
            `;



            // Use requestAnimationFrame to ensure DOM is painted
            requestAnimationFrame(() => {
                const canvas = document.getElementById("confettiCanvas");
                if (canvas) {
                    startConfetti(canvas); // pass canvas as param
                } else {
                    console.warn("❌ Confetti canvas not found");
                }
            });
        }

    };

    // Initialize app when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        console.log('DOM loaded, initializing FeedbackApp');
        FeedbackApp.init();
    });
   
    // Confetti Animation
    function startConfetti() {
        const canvas = document.getElementById("confettiCanvas");
        const ctx = canvas.getContext("2d");

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const confettiPieces = [];

        for (let i = 0; i < 120; i++) {
            confettiPieces.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height - canvas.height,
                size: Math.random() * 8 + 4,
                speed: Math.random() * 3 + 2,
                color: `hsl(${Math.random() * 360}, 85%, 60%)`,
                rotate: Math.random() * 360
            });
        }

        let animationId;

        function drawConfetti() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            confettiPieces.forEach(p => {
                ctx.fillStyle = p.color;
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotate * Math.PI / 180);
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
                ctx.restore();

                p.y += p.speed;
                p.rotate += 5;

                if (p.y > canvas.height) {
                    p.y = -10;
                    p.x = Math.random() * canvas.width;
                }
            });

            animationId = requestAnimationFrame(drawConfetti);
        }

        drawConfetti();

        // Stop confetti after 25 seconds
        setTimeout(() => {
            cancelAnimationFrame(animationId);
            // Optional: clear canvas when done
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }, 25000);
    }

    

    // Make app accessible globally for debugging
    window.FeedbackApp = FeedbackApp;
  </script>


</body>
</html>
