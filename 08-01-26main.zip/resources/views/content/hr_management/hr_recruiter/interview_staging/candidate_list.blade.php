@if(count($candidates))
<table class="table table-row-dashed table-striped table-hover mb-0 bg-white">
    <thead >
        <tr class="fw-bold fs-6 gs-0 bg-primary">
            <th>Name</th>
            <th>mobile / Email</th>
            <th>Status</th>
            <th>Applied On</th>
        </tr>
    </thead>
    <tbody>
        @foreach($candidates as $c)

        @php 
            $statuBadge='';
            $statuClass='';
            if($c->hiring_status ==1){
                $statuBadge='Selected';
                $statuClass='bg-label-success';
            }
            elseif ($c->applicant_status == 1) {
                $statuBadge='New Applicant ww';
                $statuClass='bg-label-warning';
            }elseif($c->applicant_status == 3){
                if($c->shortlist_check == 1){
                    $statuBadge='Shortlisted';
                    $statuClass='bg-label-info';
                }else{
                    $statuBadge='Not Eligible';
                    $statuClass='bg-label-danger';
                }
            }else{
                $statuBadge='New Applicant';
                $statuClass='bg-label-warning';
            }
        @endphp
        <tr>
            <td>{{ $c->applicant_name }}</td>
            <td>
                <div>{{ $c->mobile}}</div>
                <div>{{ $c->email }}</div>
            </td>
            <td>
              <span class="badge rounded {{$statuClass}} text-black fw-semibold fs-7">{{ $statuBadge }}</span> 
            </td>
            <td>{{ date('d M Y', strtotime($c->created_at)) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="text-center text-muted py-4">
    No candidates found
</div>
@endif
