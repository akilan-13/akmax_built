@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn{
        width: 100%;
        height: 100%;
        display:none;
        color:black;
        background-color:rgba(0,0,0,0.2);
    }

    .document-thumbnail:hover .view-btn{
        display:flex;
        justify-content:center;
        align-items:center;
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <ul class="nav nav-tabs border-bottom-0" role="tablist">
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/manage_staff') }}"
                    type="button"
                    class="nav-link active"
                    role="tab">
                    Staff
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/exit_staff') }}"
                    type="button"
                    class="nav-link"
                    role="tab">
                    Exit Staff
                </a>
            </li>
        </ul>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                 <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Manage Staff</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Enroll
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                @if($user_id == 0)
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_old_staff">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Old Staff
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_report">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>update report
                </a>
                @endif
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"  data-bs-toggle="modal" data-bs-target="#kt_modal_update_staffId" onclick="open_update_staffId()">
                    <span class="me-2"><i class="mdi mdi-account-box-edit-outline"></i></span>Update Staff Id
                </a>
                <a href="{{ url('hr_enroll/manage_staff/add_staff') }}" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Staff
                </a>
            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
            
            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups of Companies</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;"  class="filterSubmit" id="filterSubmit" >
                    <span class="btn btn-primary btn-sm" > Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                 <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary" >
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-100px">Company / Entity</th>
                                <th class="min-w-100px">Dept /Div /<br>Job Role</th>
                                <th class="min-w-100px">Date Of Joining</th>
                                <th class="min-w-100px">Salary</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Send Test Template-->
<div class="modal fade" id="kt_modal_send_test_template" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Test Template</h3>
                </div>
               
                <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">
                
                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                         <div class="text-danger" id="communication_err"></div>
                    </div>
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description">Thank you for your Service Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of </textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Test Template</button>
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Test Template-->

<!--begin::Modal Filter-->
<div class="modal fade" id="kt_modal_update_staffId" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">

            <div class="modal-header border-0">
                <h3 class="text-center w-100">Update Staff ID</h3>
                <button class="btn btn-sm btn-icon btn-light" data-bs-dismiss="modal">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>

            <div class="modal-body px-6 pb-6">

                <!-- COMPANY TABS -->
                <ul class="nav nav-tabs" id="companyTabs">
                    <li class="nav-item">
                        <a class="nav-link company-tab active" data-company="0"
                           data-bs-toggle="tab" href="#">EGC</a>
                    </li>

                    @foreach ($company_list as $comp)
                        <li class="nav-item">
                            <a class="nav-link company-tab"
                               data-company="{{$comp->sno}}"
                               data-bs-toggle="tab" href="#">
                               {{ $comp->company_name }}
                            </a>
                        </li>
                    @endforeach
                </ul>

                <!-- STAFF LIST -->
                <div class="mt-4" id="companyStaffList">
                    <div class="text-center text-muted py-5">
                        Loading staff...
                    </div>
                </div>

                <!-- BULK UPDATE BUTTON -->
                <div class="mt-4 text-end" id="bulkUpdateContainer" style="display:none;">
                    <button class="btn btn-primary" id="bulkUpdateBtn">
                        Bulk Update Staff IDs
                    </button>
                </div>

            </div>

        </div>
    </div>
</div>
<!--end::Modal Filter-->

<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3"  onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<!--begin::Modal exit staff--->
<div class="modal fade" id="kt_modal_exit_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Exit Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="cus_drp_form" action="{{ route('departure_staff') }}" method="POST" enctype="multipart/form-data" autocomplete="off" onsubmit="return status_change_validation()">
            @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="exist_sts_change_id" name="exist_sts_change_id"/>
                <input type="hidden" id="exist_staff_id" name="exist_staff_id"/>
                <div class="row mb-3">
                    <div class="col-lg-6 mb-2 border-end">
                        <div class="row">
                            <div class="col-lg-12 d-flex align-items-center px-1 mb-1">
                                <div class="symbol symbol-35px me-2">
                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                        <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                            alt="user-avatar"  class="w-px-100 h-auto rounded-circle"
                                            id="exist_staff_profile_image" />
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <label class="fs-5 fw-bold" id="exist_staff_name">Mahesh Kumar</label>
                                    <div class="d-flex text-primary">
                                        <a href="javascript:;" class="text-primary fw-semibold fs-7" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Staff Nick Name" id="exist_nick_name">
                                            Karthik
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-domain fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_staff_company_name">Elysium Techonologies Pvt Ltd</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-office-building fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Entity Name"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_entity_name">Click My Project</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-graph fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_staff_department">Sales</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-file-tree fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Division Name"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_staff_division">Business Development Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-briefcase fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Position"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_staff_job_role">Senior Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-calendar-badge-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining"></i>
                                <label class="fs-7 fw-semibold text-black" id="exist_staff_doj">12-Sep-2024</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <div class="row mt-2 mb-3">
                            <div class="col-lg-6">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="notice_period" id="notice_period" value="4" onchange="departure_func(4);" checked/>
                                    <label class="form-check-label" for="notice_period">Notice Period</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="relieve" id="relieve" value="5" onchange="departure_func(5);" />
                                    <label class="form-check-label" for="relieve">Relieve</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="upscond" id="upscond" value="6" onchange="departure_func(6);" />
                                    <label class="form-check-label" for="franchise">Abscond</label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="terminate" id="terminate" value="7" onchange="departure_func(7);" />
                                    <label class="form-check-label" for="franchise">Terminate</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="date_view">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Last Attend Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="staff_last_date" name="staff_last_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-lg-6 mt-2" style="display:none;" id="starting_date">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="notice_start_date" name="notice_start_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                                </div>
                            </div>
                            <div class="col-lg-6 mt-2" style="display:none;" id="ending_date">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="notice_end_date" name="notice_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly  />
                                </div>
                                <div id="notice_end_date_err" class="text-danger"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="reason_add">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="1" id="dep_reason" name="dep_reason" placeholder="Enter Reason"></textarea>
                            <div id="dep_reason_err" class="text-danger"></div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-primary me-3" id="departure_submit_butt" >Exit Period</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - exit staff-->

<!--begin::Modal Schedule Orientation--->
<div class="modal fade" id="kt_modal_schedule_orientation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Schedule Orientation</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="col-lg-6 mb-2 border-end">
                        <div class="row">
                            <div class="col-lg-12 d-flex align-items-center px-1 mb-1">
                                <div class="symbol symbol-35px me-2">
                                    <div class="image-input image-input-circle" data-kt-image-input="true">
                                        <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                            alt="user-avatar"  class="w-px-100 h-auto rounded-circle"
                                            id="uploadedlogo" />
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <label class="fs-5 fw-bold">Mahesh Kumar</label>
                                    <div class="d-flex text-primary">
                                        <a href="javascript:;" class="text-primary fw-semibold fs-7" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Staff Nick Name">
                                            Karthik
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-domain fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name"></i>
                                <label class="fs-7 fw-semibold text-black">Elysium Techonologies Pvt Ltd</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-office-building fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Entity Name"></i>
                                <label class="fs-7 fw-semibold text-black">Click My Project</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-graph fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name"></i>
                                <label class="fs-7 fw-semibold text-black">Sales</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-file-tree fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Division Name"></i>
                                <label class="fs-7 fw-semibold text-black">Business Development Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-briefcase fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Position"></i>
                                <label class="fs-7 fw-semibold text-black">Senior Executive</label>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                <i class="mdi mdi-calendar-badge-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining"></i>
                                <label class="fs-7 fw-semibold text-black">12-Sep-2024</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-2">
                        <div class="row mt-2 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">1st Scehdule Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="schdeule_date" name="schdeule_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="row mt-2 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">2nd Scehdule Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="schdeule_date_2" name="schdeule_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                        <div class="row mt-2 mb-2">
                            <label class="text-dark mb-1 fs-6 fw-semibold">3rd Scehdule Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="schdeule_date_3" name="schdeule_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary me-3" id="departure_submit_butt" data-bs-dismiss="modal">Schedule</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Schedule Orientation-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_old_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Add Old Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form  method="POST" action="{{ route('add_old_staff') }}" enctype="multipart/form-data" autocomplete="off" id="addOldStaffForm">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="staff_data_payload" name="staff_data_payload"/>
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="staff_company_name" name="staff_company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            @if(isset($company_list))
                            @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="staff_entity_name" name="staff_entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                        <select id="staff_branch_name" name="staff_branch_name" class="select3 form-select">
                            <option value="">Select Branch Name</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-12">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff data :</label>
                        <span lass="text-black mb-1 fs-6 fw-semibold "id="total_Staff_data">0 </span>Record Found
                        <div lass="text-black mb-1 fs-6 fw-semibold "id="total_Staff_list"></div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                    <button type="button" class="btn btn-primary me-3" id="submitStaffBtn" onclick="submit_form()">Add Old Staff</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_staff_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Staff Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form  method="POST" action="{{ route('update_staff_timestamp_report') }}" enctype="multipart/form-data" autocomplete="off" id="updateTimestampForm">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                         <input type="text" id="date_timestamp" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Timestamp data :</label>
                        <span lass="text-black mb-1 fs-6 fw-semibold "id="total_timestamp_data">0 </span>Record Found
                      
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                    <button type="button" class="btn btn-primary me-3" id="submitTimestampBtn" onclick="submit_timestamp_form()">Update Staff Timestamp</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <!-- <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div> -->
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->


<div class="modal fade" id="filePreviewModal" tabindex="-1" aria-labelledby="filePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="filePreviewModalLabel">File Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Modal content dynamically injected -->
                <div id="filePreviewContent" class="d-flex justify-content-center align-items-center">
                    <!-- Preview content will be added here dynamically -->
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="view_staff_img_sm" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <div class="skeleton-loader-view w-150px" ></div>
                    <label class="fs-5 fw-semibold text-primary view-data" id="view_staff_name" style="display:none;">Mahesh Kumar</label>
                    <div class="skeleton-loader-view w-125px" ></div>
                    <label class="fs-6 fw-semibold text-black view-data"id="view_staff_mobile" style="display:none;">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_idol" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#contact_info" aria-controls="contact_info" aria-selected="false">
                                    Contact Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#work_info" aria-controls="work_info" aria-selected="false">
                                    Work Type
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_info" aria-controls="edu_info" aria-selected="false">
                                    Education Details
                                </button>
                            </li>
                            <!-- <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Application" aria-controls="Application" aria-selected="false">
                                    Application Details
                                </button>
                            </li> -->
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#StaffCheckList" aria-controls="StaffCheckList" aria-selected="false">
                                    Staff Checklist
                                </button>
                            </li>
                            <!-- <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Orientation" aria-controls="Orientation" aria-selected="false">
                                    Orientation
                                </button>
                            </li> -->
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_email" style="display:none;">-</label>
                                        </div>
                                        
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Birth</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_dob" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Gender</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_gender" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_father_name" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_father_occup" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_name" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_occup" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Tongue</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_tongue" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Languages Known</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_language_knw" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_marital_status" style="display:none;">Married</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Children</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_has_children" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Siblings</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_has_siblings" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Hobby</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_hobby" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_descrip" style="display:none;">-</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-175px h-175px rounded-circle"
                                                id="view_staff_profile_image" style="border: 2px solid #ab2b22;"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                  <div class="row">

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Company Details</div>
                                    </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Details</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_company_type" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_department" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>


                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_division" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_job_role" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>

                                  <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Designation Details</div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_nick_name" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_doj" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-danger view-data" id="view_staff_salary" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                     <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-danger view-data" id="view_staff_per_hr_cost" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75" ></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_skill_tag" style="display:none;">-</label>
                                        </div>
                                    </div>
                                  </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Login Credentials</div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <label class="fw-semibold fs-6 text-black view-data" id="view_staff_user_name" style="display:none;">-</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="row mb-2">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" ></div>
                                                <label class="fw-semibold fs-6 text-black view-data" id="view_staff_password" style="display:none;">-</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Other Credentials</div>
                                    </div>

                                    <div id="otherCredentialsContainer"></div>

                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    
                                  <div class="row">
                                    <div id="contactPersonContainer"></div>
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Permanent Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_permnt_address">-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Residential Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_temp_address">-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_alternate_no">-</label>
                                      </div>
                                    </div>

                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_exp_type">Experience</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Shifted Company Count</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_shift_comp_count">2</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Total Years Of Experience</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-primary text-white px-3 fs-7" id="view_total_yr_exp">3</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div id="workDetailsContainer" class="row"></div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Attachment Details</div>
                                    </div>

                                    <div id="documentContainer" class="col-lg-12 d-flex align-items-center justify-content-start gap-3 flex-wrap py-3 px-1">
                                        
                                    </div>
                                    


                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_info" role="tabpanel">
                            <div class="row mb-2">

                              <div class="col-lg-12">
                                  <div class="row mb-2">
                                        <label class="col-3 fw-semibold fs-7 text-dark">Course Completed</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_completed_course_tag">-</label>
                                    </div>
                                </div>


                                <div class="divider text-start-center">
                                  <div class="divider-text fs-5 text-primary fw-semibold my-2">Educational Details</div>
                                </div>


                               <div id="educationContainer" class="row"></div>
                                
                                
                                
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Application" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Java , C# , .Net ,FullStack</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Non Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sales Management , SEO Analyst</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Interview Attended Company</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-label-primary text-primary fw-semibold fs-6 rounded">EIBS</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Already Attended Interview In Elysium Groups</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Attended Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2024 , 04-11-2024 , 12-01-2025</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Submit Original Certificate</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Travel For Official Purpose</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Immediate Joining</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2025</label>
                                      </div>
                                    </div>


                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="StaffCheckList" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div id="documentCheckContainer" class="row"></div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Orientation" role="tabpanel">
                            <div class="row mb-2">
                                <h5 class="title fw-bold mt-2 text-warning">Staff Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <img src="#"
                                              style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Company Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>

                                  <h5 class="title fw-bold mt-2 text-warning">Department Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <img src="#"
                                              style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

 <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

<script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
   
     
<script>
    function open_update_staffId(){
        loadCompanyStaff(0);
    }

// CLICK COMPANY TAB
$(document).on("click", ".company-tab", function () {
    let companyId = $(this).data("company");
    loadCompanyStaff(companyId);
});

// COMMON FUNCTION TO LOAD STAFF
function loadCompanyStaff(companyId) {

    $("#companyStaffList").html(`
        <div class="text-center py-5">
            <div class="spinner-border"></div>
            <p>Loading staff...</p>
        </div>
    `);

    $.ajax({
        url: "/get-company-staff",
        type: "GET",
        data: { company_id: companyId },
        success: function (res) {

            // RENDER STAFF TABLE HTML COMING FROM BACKEND
            $("#companyStaffList").html(res.staff_html);

            // Show Bulk Update button when list loads
            $("#bulkUpdateContainer").show();
        }
    });
}

// BULK UPDATE BUTTON CLICK
$("#bulkUpdateBtn").on("click", function () {

    let updates = [];

    $("tr").each(function () {

        let sno = $(this).find(".staff-id-input").data("sno");

        if (!sno) return; // skip non-staff rows

        let staff_id = $(this).find(".staff-id-input").val();
        let timechamp_id = $(this).find(".staff-timechamp-id-input").val();

        updates.push({
            sno: sno,
            staff_id: staff_id,
            timechamp_id: timechamp_id
        });
    });

    $.ajax({
        url: "/bulk-update-staff-id",
        type: "POST",
        data: {
            _token: $("meta[name='csrf-token']").attr("content"),
            updates: updates
        },
        success: function (res) {
            toastr.success("Bulk Update Successful!");
            window.location.href = '/hr_enroll/manage_staff';
        }
    });
});

</script>

   <script>
     function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    // window.location.href = '/hr_enroll/manage_staff';
                    submitBtn.disabled = false;
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
     function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {    
        
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
  
        let staff_image = '';
        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }
        staff_image = `{{ asset('${staff_image}') }}`;
         
        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle">
                                <img src="${staff_image}" 
                                    alt="user-avatar"  class="w-px-40 h-px-40 rounded-circle"
                                    id="uploadedlogo" onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}' ${(item.gender == 1 ? 'user_2.png' : 'user_7.png')}"/>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label>
                                <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.staff_name}</span>
                                ${item.gender == 1 ?
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                        class="mdi mdi-face-man text-info"></i></span>`
                                 : 
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i
                                        class="mdi mdi-face-woman text-info"></i></span>`
                                }
                                
                            </label>
                            <span class="fs-8 me-1 d-block text-primary text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.nick_name || '-'}</span>
                            <div class="d-flex  fs-8" style="color:rgb(114,57,234) !important;">
                                <a href="javascript:;" class=" fs-8" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Staff Nick Name" style="color:rgb(114,57,234) !important;">
                                    ${data.staff_id || '-'}
                                </a>
                                <div class="">
                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                        data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9" style="color:rgb(114,57,234) !important;"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Mob No</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.mobile_no || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Email ID</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.email_id || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">DOB</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                ${data.dob ? formatDateCommon(data.dob) : '-'}
                                                <span 
                                                    class="badge fs-8 bg-info" 
                                                    data-bs-toggle="tooltip" 
                                                    title="${data.dob ? getNextBDayDate(data.dob).full : '-'}">
                                                    ${data.dob ? getNextBDayDate(data.dob).short : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Educational</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">
                                            ${data.education && Array.isArray(data.education) && data.education.length > 0 ? data.education : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    ${data.company_type == 1 ?
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold fs-7 text-truncate badge bg-label-danger d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>
                     </div>`
                    :
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>

                        <label class="fw-semibold fs-7 text-truncate badge  d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: ${item.company_base_color || ''};"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.entity_name || '-'}" >
                            ${data.entity_name || '-'}
                        </label>
                    </div>`
                    }
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column gap-1">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.department_name || '-'}">
                            ${data.department_name || '-'}
                        </label>
                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.division_name || '-'}">
                            ${data.division_name || '-'}
                        </label>
                        <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                            <span class="fs-7">${data.job_role_name || '-'}</span>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                           ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                        </label>
                        <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                           ${data.date_of_joining ? getExperienceDuration(data.date_of_joining) : '0 Day'}
                        </label>
                    </div>
                </td>
                <td align="right">
                    <label class="badge bg-success text-white fw-bold mb-2 text-nowrap">
                        <span class="mdi mdi-currency-rupee text-white fw-bold fs-8"></span>
                        <span class="fs-7">${data.basic_salary ? new Intl.NumberFormat('en-IN').format(data.basic_salary) :'-'}</span>
                    </label>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                    
                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                         ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${item.sno})">
                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i> View</span>
                            </a>`
                            :''}
                            <a href="{{ url('/hr_enroll/manage_staff/update_staff/${item.encrypted_id}')}}" class="dropdown-item">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_exit_staff" onclick="existStaffModal(${item.sno})">
                                <span><i class="mdi mdi-exit-to-app fs-3 text-black me-1"></i></span>
                                <span>Exit</span>
                            </a>
                             <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_test_template" >
                                <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Test Template</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_staff" onclick="confirmDelete('${item.sno}', '${item.staff_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>` : ''}
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_enroll/manage_staff?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
  function departure_data_fetch_func(data){
    let image = '';
    if (data.staff_image) {
      var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
      image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
    } else if (data.cus_gender == 1 || data.cus_gender === '1') {
      image = `<img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
    } else if (data.cus_gender == 2 || data.cus_gender === '2') {
      image = `<img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
    }
    var html = `<div class="row mt-4 mb-3">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}"/>

                  <div class="col-lg-3 mb-3">
                      <div class="row">
                          <div class="align-items-sm-center gap-4">
                              ${image}
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9 mb-3">
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">
                              <span class="badge bg-info">${data.department_name}</span></label>
                      </div>
                  </div>
              </div>`;
    document.getElementById('staff_data_view').innerHTML = html;

  }
  departure_func(4)
  function departure_func(val) {
    // Fetch elements required for all conditions
    $('#exist_sts_change_id').val(val);
    $('#dep_reason_err').html('');
    $('#notice_end_date_err').html('');
    var reason_add = document.getElementById("reason_add");
    var date_view = document.getElementById("date_view");
    var starting_date = document.getElementById("starting_date");
    var ending_date = document.getElementById("ending_date");
    // Hide all elements initially
    reason_add.style.display = "none";
    date_view.style.display = "none";
    starting_date.style.display = "none";
    ending_date.style.display = "none";
    // Handle specific conditions based on `val`
    switch (val) {
        case 4: // Show both dates and reason
            starting_date.style.display = "block";
            ending_date.style.display = "block";
            reason_add.style.display = "block";
            $('#notice_period').prop('checked', true);
            $('#relieve').prop('checked', false);
            $('#upscond').prop('checked', false);
            $('#terminate').prop('checked', false);
            $('#departure_submit_butt').html('Notice Period');
            break;
        case 5: // Show reason only
            reason_add.style.display = "block";
            $('#notice_period').prop('checked', false);
            $('#relieve').prop('checked', true);
            $('#upscond').prop('checked', false);
            $('#terminate').prop('checked', false);
            $('#departure_submit_butt').html('Relive');
            break;
        case 6: // Show reason and date view only
            reason_add.style.display = "block";
            date_view.style.display = "block";
            $('#notice_period').prop('checked', false);
            $('#relieve').prop('checked', false);
            $('#upscond').prop('checked', true);
            $('#terminate').prop('checked', false);
            $('#departure_submit_butt').html('Abscond');
            break;
        case 7: // Show reason only
            reason_add.style.display = "block";
            $('#notice_period').prop('checked', false);
            $('#relieve').prop('checked', false);
            $('#upscond').prop('checked', false);
            $('#terminate').prop('checked', true);
            $('#departure_submit_butt').html('Terminate');
            break;
    }
  }
  function status_change_validation(){
    var err = 0;
    var exist_sts_change_id = $('#exist_sts_change_id').val();
    if(exist_sts_change_id==4){
      var notice_end_date = $('#notice_end_date').val().trim();
      if(notice_end_date==''){
        $('#notice_end_date_err').html('Notice end date is requered..!');
        err++;
      }else{
        $('#notice_end_date_err').html('');
      }
    }

    var dep_reason = $('#dep_reason').val().trim();
    if(dep_reason==''){
      $('#dep_reason_err').html('Enter Reason is requered..!');
      err++;
    }else{
      $('#dep_reason_err').html('');
    }
    return err===0;
  }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function () {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
 <script>
$(document).ready(function() {

    // When company changes
    $('#staff_company_name').on('change', function() {
        var companyId = $(this).val();
        var entityDropdown = $('#staff_entity_name');

        // Reset dropdown
        entityDropdown.empty().append('<option value="">Select Entity</option>');

        if (companyId) {
            $.ajax({
                url: "{{ route('entity_list') }}",
                type: "GET",
                data: { company_id: companyId },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            entityDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .attr('data-baseurl', entity.entity_base_url)
                                    .text(entity.entity_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
    });

    // When entity changes
    $('#staff_entity_name').on('change', function() {
         $('#staff_add_btn').prop('disabled', true);
         $('#staff_data_payload').val('');
         $('#total_Staff_data').text('0');
          var entityId = $(this).val();
          const verify_key='egcsecret2030datagetapierp';
         var branchDropdown = $('#staff_branch_name');
         if (entityId) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: { entity_id: entityId},
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            branchDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .text(entity.branch_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
        var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
        if (baseurl) {
            var url = baseurl + 'api/staff_data_get';
            $.ajax({
                url: url,
                type: "GET",
                data:{auth_key:verify_key},
                success: function(response) {
                    console.log('response:', response);
                    if (response.status === 200 && response.data) {
                        console.log(response.data);
                        var length=response.data.length;
                        var staffData =response.data;
                        $('#total_Staff_data').text(length+' ')
                        // TODO: handle data display or form updates here
                        if(length > 0){
                            $('#staff_add_btn').prop('disabled', false);
                            // $('#staff_data_payload').val(JSON.stringify(staffData));
                        }else{
                             $('#staff_add_btn').prop('disabled', true);
                        }
                        staffData.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                       
                        staffData.map((sdata)=>{
                            if(sdata.external_uuid){
                                sdata.alreadyExists=1;
                            }else{
                                sdata.alreadyExists=0;
                            }
                        })
                        loadDataView(staffData,baseurl)
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff data:', error);
                }
            });
        }
    });

});
</script>

 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }

    
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

            result = result.trim();

            // Add "In" or "Ago"
            if (isFuture) {
                result = `In ${result}`;
            } else if (result !== '0 days') {
                // result += ' ago';
                result += '';
            }

            return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }

</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
     $(document).ready(function() {
            // Business dropdown
            $('#company_fill').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_fill');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // depart list
            $('#entity_fill').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#department_fill');

                stateDropdown.empty().append('<option value="">Select Department</option>');

                if (entity_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }

                
            });
            // division dropdown
             $('#department_fill').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#division_fill');
                stateDropdown.empty().append('<option value="">Select Division</option>');

                let erp_depert = $(this).find(':selected').data('erpdepartmentid');
                $('#erp_department_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpdivisionid', state.erp_division_id)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
             });

              $('#division_fill').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#job_role_fill');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                let erp_depert = $(this).find(':selected').data('erpdivisionid');
                $('#erp_division_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpjobroleid', state.erp_job_role_id)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
             });

        })
</script>

<script>
    $('#sendMessageBtn').on('click', function(e) {
        var err =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

       
        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();

       
      
            if(sms ==1 || email ==1 || whatsapp == 1){
                $('#communication_err').text('');
            }else{
                $('#communication_err').text('Please Select Any One Communication.!');
                err++;
            }
        
   

        if(err == 0){
              $('#sendMessageBtn').prop('disabled', true);
               $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/send_test_template',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        // location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#sendMessageBtn').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#sendMessageBtn').prop('disabled', true);
                      resetButton();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send Test Template');
                $('#sendMessageBtn .spinner-border').addClass('d-none');
            }
    });
</script>
<script>
    function send_proposal_whatsapp_func() {
       const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
        const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

</script>

<script>
    function viewStaff(id) {
            // Show skeleton loaders before fetch
        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
            skeleton.style.display = 'block'; // Show skeleton loaders
        });
    
        // Hide actual data elements
        document.querySelectorAll('.view-data').forEach(element => {
            element.style.display = 'none'; // Hide actual data until it is loaded
        });
        
        fetch('/staff_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    let staff_image = '';
                    if (com.staff_image && com.staff_image.trim() !== '') {
                        if (com.company_type == 1) {
                            staff_image = `staff_images/Management/${com.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
                        }
                    } else {
                        staff_image = com.gender == 1
                            ? 'assets/egc_images/auth/user_2.png'
                            : 'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;

                    document.getElementById('view_staff_img_sm').src = staff_image;
                    document.getElementById('view_staff_profile_image').src = staff_image;
                    
                    document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                        skeleton.style.display = 'none'; // Hide skeleton loaders
                    });
                    document.querySelectorAll('.view-data').forEach(element => {
                        element.style.display = 'block'; // Show actual data
                    });

                    let skillsJson = safeJsonParse(com.knowledge_tag); 
                    let skillsArray = safeJsonParse(skillsJson);  
                    let skillNames = Array.isArray(skillsArray)
                        ? skillsArray.map(s => s.value)
                        : [];

                    let displaySkills = skillNames.join(", ");


                    let courseTagJson = safeJsonParse(com.course_tag); 
                    let courseTagArray = safeJsonParse(courseTagJson);  
                    let courseNames = Array.isArray(courseTagArray)
                        ? courseTagArray.map(s => s.value)
                        : [];

                    let displayCourseTag = courseNames.join(", ");
                    
                    $('#view_staff_name').html(com.staff_name);
                    $('#view_staff_mobile').html(com.mobile_no);
                    $('#view_staff_email').html(com.email_id);
                    $('#view_staff_dob').html(com.dob ? formatDateCommon(com.dob) : '-');
                    $('#view_staff_gender').html(com.gender==1?'Male' :(com.gender==2?'Female' :'Other'));
                    $('#view_staff_father_name').html(com.father_name||'-');
                    $('#view_staff_mother_name').html(com.mother_name||'-');
                    $('#view_staff_father_occup').html(com.father_occup||'-');
                    $('#view_staff_mother_occup').html(com.mother_occup||'-');
                    $('#view_staff_mother_tongue').html(com.mother_tongue||'-');
                    $('#view_staff_language_knw').html(com.language_known ? com.language_known.join(','): '-');
                    $('#view_staff_marital_status').html(com.martial_status == 2 ? 'Unmarried' :(com.martial_status == 1 ? 'Married':'-'));
                    $('#view_staff_has_children').html(com.has_children||'-');
                    $('#view_staff_has_siblings').html(com.has_siblings||'-');
                    $('#view_staff_hobby').html(com.hobbies ? com.hobbies.join(','): '-');
                    $('#view_staff_descrip').html(com.description||'-');

                    /* company details */
                    $('#view_staff_company_type').html(com.company_type==1?'Mangement' :'Buisness');
                    $('#view_staff_department').html(com.department_name || '-');
                    $('#view_staff_division').html(com.division_name || '-');
                    $('#view_staff_job_role').html(com.job_role_name|| '-');

                    /* Designation  details */
                    $('#view_staff_nick_name').html(com.nick_name || '-');
                    $('#view_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');
                    $('#view_staff_salary').html(com.basic_salary ? '₹ '+ new Intl.NumberFormat('en-IN').format(com.basic_salary) :'-');
                    $('#view_staff_per_hr_cost').html(com.per_hour_cost ? '₹ '+ new Intl.NumberFormat('en-IN').format(com.per_hour_cost) :'-');
                    $('#view_staff_skill_tag').html(displaySkills || '-');

                     /* Login  details */
                    $('#view_staff_user_name').html(com.user_name || '-');
                    $('#view_staff_password').html(com.password || '-');

                    /* other Credential */
                    if (com.other_credential && com.other_credential.length > 0) {
                        let credentialsHTML = '';
                        
                        com.other_credential.forEach((credential) => {
                            credentialsHTML += `
                                <h5 class="title fw-bold mt-2 text-warning">${credential.credential_name} Credentials</h5>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.user_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.password || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <a class="text-truncate max-w-150px" href="${credential.url_link || '#'}" target="_blank">${credential.url_link ? credential.url_link : '-'}</a>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.description || '-'}</label>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('otherCredentialsContainer').innerHTML = credentialsHTML;
                    } else {
                        document.getElementById('otherCredentialsContainer').innerHTML = '<p>No other credentials available.</p>';
                    }

                    
                    if (com.contact_person_name && com.contact_person_name.length > 0) { 
                        let contactPersonHTML = '';
                        const contactPersonNo = com.contact_person_no || [];
                        const relationship = com.relationship || [];
                        
                        com.contact_person_name.forEach((contact, index) => {
                            contactPersonHTML += `
                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${contact || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${contactPersonNo[index] || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Relation ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${relationship[index] || '-'}</label>
                                    </div>
                                </div>
                            `;
                        });

                        document.getElementById('contactPersonContainer').innerHTML = contactPersonHTML;
                    } else {
                        document.getElementById('contactPersonContainer').innerHTML = '';
                    }

                    


                    $('#view_staff_permnt_address').html(com.address || '-');
                    $('#view_staff_temp_address').html(com.residential_address || '-');
                    $('#view_staff_alternate_no').html(com.alternative_no || '-');

                    /* Work Details */
                    $('#view_exp_type').html(com.exp_type ==1 ? 'Fresher' :(com.exp_type == 2 ? 'Experience' :'-') );
                    $('#view_shift_comp_count').html(com.total_company_shift || '-');
                    $('#view_total_yr_exp').html(com.total_experience || '-');

                    if (com.work_details && com.work_details.length > 0) {
                        let worksHTML = '';
                        
                        com.work_details.forEach((work,index) => {
                            let compCount =index+1;
                            worksHTML += `
                                <h5 class="title fw-bold mt-2 text-warning">${compCount + getOrdinalSuffix(compCount)} Company</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.position || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">
                                        <span class="badge bg-primary text-white px-3 fs-7">${work.year_of_experience || '-'}</span>
                                    </label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.company_name || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-danger">${work.salary ? '₹ '+ new Intl.NumberFormat('en-IN').format(work.salary) +' /-':'-'} </label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.start_date ? formatDateCommon(work.start_date) : '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.end_date ? formatDateCommon(work.end_date) : '-'}</label>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('workDetailsContainer').innerHTML = worksHTML;
                    } else {
                        document.getElementById('workDetailsContainer').innerHTML = '<p>No Experience Details.</p>';
                    }

                    if (com.documents && com.documents.length > 0) {
                        let documentHTML = '';

                        com.documents.forEach((document, index) => {
                            let documentName = document.document_name || 'Unknown Document';

                            // Start with a Bootstrap card for each document
                            documentHTML += `
                                <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                                    <div class="card shadow-sm">
                                        <div class="card-body">
                                            <h5 class="card-title text-primary">${documentName}</h5>
                                            <div class="d-flex flex-wrap justify-content-start gap-3">
                            `;

                            // Loop through the files for each document
                            document.files.forEach((file, fileIndex) => {
                                const fileExtension = file.split('.').pop().toLowerCase();
                                let fileHTML = '';

                                // Check if the file is an image
                                if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
                                    fileHTML = `
                                    
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
                                            <img src="${file}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <span class="view-btn">
                                                    <i class="mdi mdi-eye"></i> 
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                } 
                                // If the file is a document (pdf, docx, etc.)
                                else if (['pdf'].includes(fileExtension)) {
                                    fileHTML = `
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
                                        
                                            <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <span class="view-btn">
                                                    <i class="mdi mdi-eye"></i> 
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                } 
                                // If file is unsupported (other types)
                                else {
                                    fileHTML = `
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" >
                                        
                                            <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <a href="${file}" download class="view-btn">
                                                    <i class="mdi mdi-download-circle-outline text-dark fs-3 fw-light"></i> 
                                                </a>
                                                
                                            </div>
                                        </div>
                                    `;
                                }

                                // Add the file's HTML to the document's section
                                documentHTML += fileHTML;
                            });

                            // Close the card layout and document container
                            documentHTML += `
                                        </div> 
                                    </div> 
                                </div>
                            </div> 
                            `;
                        });

                        // Insert the generated HTML into the container
                        document.getElementById('documentContainer').innerHTML = documentHTML;
                    } else {
                        document.getElementById('documentContainer').innerHTML = '<p class="text-muted">No documents available.</p>';
                    }


                    if (com.qualification && com.qualification.length > 0) {
                        let educationHTML = '';
                        
                        com.qualification.forEach((qualification,index) => {
                            let compCount =index+1;
                            educationHTML += `
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.qualification_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">${qualification.degree_name || '-'}</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.major || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.university_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Year</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.year || '-'}</label>
                                    </div>
                                </div>
                                <hr>
                            `;
                        });
                        document.getElementById('educationContainer').innerHTML = educationHTML;
                    } else {
                        document.getElementById('educationContainer').innerHTML = '<p>No Qualification Found.</p>';
                    }


                    if (com.document_checkList && com.document_checkList.length > 0) {
                        let docCheckListHTML = '';
                        
                        com.document_checkList.forEach((checklist,index) => {
                            let compCount =index+1;
                            docCheckListHTML += `
                                <div class="form-check mb-3">
                                    <input class="form-check-input checklist-item" type="checkbox" ${checklist.is_checked ==1 ? 'checked' :''} disabled>
                                    <label class="fw-semibold fs-6 text-black" >${checklist.document_checklist}</label>
                                </div>
                            `;
                        });
                        document.getElementById('documentCheckContainer').innerHTML = docCheckListHTML;
                    } else {
                        document.getElementById('documentCheckContainer').innerHTML = '<p>No Documents.</p>';
                    }

                    $('#view_staff_completed_course_tag').html(displayCourseTag || '-');
                    


                    
                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    function safeJsonParse(str) {
        try { return JSON.parse(str); }
        catch(e) { return str; }
    }

    function getOrdinalSuffix(number) {
        const suffixes = ["th", "st", "nd", "rd"];
        const remainder = number % 100;
        return suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    }

    function previewFile(file,doc_name) {
        const fileExtension = file.split('.').pop().toLowerCase();
        $('#filePreviewModalLabel').text(doc_name)
        const previewContainer = document.getElementById('filePreviewContent');
        previewContainer.innerHTML = ''; // Clear any previous content

        // Handle the preview based on file type
        if (['pdf', 'docx'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <iframe src="${file}" style="width: 100%; height: 500px;" frameborder="0"></iframe>
            `;
        } else if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <img src="${file}" alt="Preview Image" style="width: 100%; max-height: 500px; object-fit: contain;" />
            `;
        } else {
            previewContainer.innerHTML = `
                <p class="text-center text-muted">File format not supported for preview.</p>
            `;
        }
    }

    function loadDataView(list, baseurl) {
        let html = "";

        if (list.length === 0) {
            html += `<span class="text-center text-danger">No attendance found</span>`;
        } else {
            list.forEach(a => {
                html += `
                    <span class="list-group-item d-flex align-items-center justify-content-between mb-3 shadow-sm rounded px-3 py-2 ${a.alreadyExists == 1 ? 'bg-label-dark':'bg-label-success'} " >
                        
                        <!-- LEFT SIDE -->
                        <div class="d-flex align-items-center">
                            <img src="${a.staff_image}"
                             alt="${a.staff_name}"
                             class="rounded-circle me-3 staff-avatar"
                             width="50" height="50"
                             onerror="replaceWithInitials(this, '${a.staff_name.replace(/'/g, "\\'")}')">

                            <div>
                                <h6 class="fw-semibold mb-0">
                                    ${a.staff_name}
                                    <span class="text-primary small">(${a.nick_name})</span>
                                    ${a.alreadyExists == 1 ?
                                        ``
                                        :
                                        '<span class="badge bg-label-danger">New</span>'
                                        }
                                </h6>
                                <small class="text-muted">
                                    ${a.role_name} | ${a.department_name}
                                </small>
                            </div>
                        </div>

                        <!-- RIGHT SIDE (Created At) -->
                        <span class="badge bg-success-subtle text-success fw-semibold">
                            ${formatDateCommon(a.created_at)}
                        </span>

                    </span>
                `;
            });
        }

        document.getElementById("total_Staff_list").innerHTML = html;
    }

    function getInitials(name) {
        if (!name) return '';
        const words = name.trim().split(' ');
        
        return (words[0][0]).toUpperCase();
    }

    function getAvatarColor(name) {
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

    function replaceWithInitials(img, name) {
        console.log(img,name)
        const initials = getInitials(name);
        const color = getAvatarColor(name);
        console.log(name ,initials)
        const div = document.createElement('div');
        div.className = `rounded-circle ${color} text-white d-flex align-items-center justify-content-center me-3 fw-bold`;
        div.style.width = '50px';
        div.style.height = '50px';
        div.innerText = initials;

        img.replaceWith(div);
    }


</script>
<script>
    function existStaffModal(id){
        
        $('#exist_staff_id').val(id);

        fetch('/staff_view/' + id, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                var com = data.data;
                let staff_image = '';
                if (com.staff_image && com.staff_image.trim() !== '') {
                    if (com.company_type == 1) {
                        staff_image = `staff_images/Management/${com.staff_image}`;
                    } else {
                        staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
                    }
                } else {
                    staff_image = com.gender == 1
                        ? 'assets/egc_images/auth/user_2.png'
                        : 'assets/egc_images/auth/user_7.png';
                }
                staff_image = `{{ asset('${staff_image}') }}`;

                document.getElementById('exist_staff_profile_image').src = staff_image;
                
                document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                    skeleton.style.display = 'none'; // Hide skeleton loaders
                });
                document.querySelectorAll('.exist-data').forEach(element => {
                    element.style.display = 'block'; // Show actual data
                });
                
                $('#exist_staff_name').html(com.staff_name);
                $('#exist_staff_nick_name').html(com.nick_name || '-');
                $('#exist_staff_company_name').html(com.company_type==1?'Elysium Groups of Companies' :com.company_name);
                $('#exist_staff_entity_name').html(com.company_type==1?'-' :com.entity_name);
                $('#exist_staff_department').html(com.department_name || '-');
                $('#exist_staff_division').html(com.division_name || '-');
                $('#exist_staff_job_role').html(com.job_role_name|| '-');
                $('#exist_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');
                
            } else {
                console.error(data.error_msg);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    
</script>
@endsection
