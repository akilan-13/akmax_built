<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\TimeZoneModel;


class TimeZone extends Controller
{
  protected static $branch_id = 1;
 
 public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $time_zone = TimeZoneModel::select('egc_countrytimezones.*','egc_countries.name as country_name')->where('egc_countrytimezones.status', '!=', 2)
    ->join('egc_countries','egc_countries.id','=','egc_countrytimezones.country_id');
    if ($search_filter != '') {
        $time_zone->where(function ($subquery) use ($search_filter) {
            $subquery->where('egc_countrytimezones.time_zone', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_countrytimezones.utc_offset', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_countries.name', 'LIKE', "%{$search_filter}%");  
        });
    }
    $time_zone = $time_zone->orderBy('egc_countrytimezones.sno', 'desc')->paginate($perpage);

    $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $time_zone->map(function ($item) use ($helper) {
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'time_zone' => $item->time_zone,
                'utc_offset' => $item->utc_offset,
                'country_id' => $item->country_id,
                'country_name' => $item->country_name,
                'data' => $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $time_zone->currentPage(),
            'last_page' => $time_zone->lastPage(),
            'total' => $time_zone->total(),
        ]);
    }
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.settings.common.timezone.timezone_list', [
      'perpage' => $perpage,
      'search_filter' => $search_filter,

    ]);
  }
  
  public function List(Request $request)
  {

      // $countryId = $request->input('country_id');
         $timeZone = TimeZoneModel::select('egc_countrytimezones.*','egc_countries.name as country_name')->join('egc_countries','egc_countries.id','=','egc_countrytimezones.country_id')->where('egc_countrytimezones.status',0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $timeZone
      ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_id' => 'required|max:255',
      'time_zone' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $country_id                     = $request->country_id;
      $time_zone                   = $request->time_zone;
      $utc_offset                 = $request->utc_offset;
      $description                = $request->description;


      $user_id                    = $request->user()->user_id ?? 1;
      $chk = TimeZoneModel::where('time_zone',$time_zone)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Time Zone has been already created!'
        ]);
      } else {
        $category_check = TimeZoneModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

       

        $add_category = new TimeZoneModel();
        $add_category->country_id = $country_id;
        $add_category->time_zone  = $time_zone ;
        $add_category->utc_offset = $utc_offset;
        $add_category->description = $description;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Time Zone added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Time Zone!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'template Created successfully!');
    }
  }

  public function Edit($id)
  {
    $editcategory = TimeZoneModel::where('sno', $id)->first();

    return view('content.settings.common_setting.sms_template', [
      'editcategory' => $editcategory,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {

    // return $request;
    $validator = Validator::make($request->all(), [
      'country_id' => 'required|max:255',
      'time_zone' => 'required|max:255'

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $country_id                     = $request->country_id;
      $time_zone                   = $request->time_zone;
      $utc_offset                 = $request->utc_offset;
      $description                = $request->description;

      $upd_CourseCategoryModel =  TimeZoneModel::where('sno', $id)->first();

      $chk = TimeZoneModel::where('time_zone', $time_zone)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Time Zone has been  already assigned!'
        ]);
        return redirect()->back();
      } else {

        $upd_CourseCategoryModel->country_id  = $country_id;
        $upd_CourseCategoryModel->time_zone  = $time_zone;
        $upd_CourseCategoryModel->utc_offset  = $utc_offset;
        $upd_CourseCategoryModel->description  = $description;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Time Zone updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Time Zone !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  TimeZoneModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  TimeZoneModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}