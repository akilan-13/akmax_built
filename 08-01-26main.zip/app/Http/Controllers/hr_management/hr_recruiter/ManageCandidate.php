<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\ApplicantModel;
use App\Models\InterviewScheduleQuestionModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class ManageCandidate extends Controller
{
  public function index(Request $request)
  {

    
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = ApplicantModel::
       where('egc_applicant.status','!=',2)
      ->leftJoin('egc_job_request', 'egc_applicant.job_request_id', 'egc_job_request.sno')
      ->leftJoin('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_source', 'egc_applicant.source_id', 'egc_source.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->distinct('egc_applicant.sno')
      ->select(
        'egc_applicant.*',
      'egc_job_request.status as job_request_status',
      'egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_source.source_name as applicant_source_name',
      'egc_company.company_base_color',);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.applicant_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.mobile', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_applicant.email', 'LIKE', "%{$search_filter}%");
          });
      }

        if ($job_role_fill) {
          $jobRequest->where('egc_job_request.job_role_name', $job_role_fill);
        }
        if ($closing_date_filt) {
          $jobRequest->where('egc_job_request.created_at', $closing_date_filt);
        }
        if ($exp_type_filt) {
          $jobRequest->where('egc_applicant.experience_id', $exp_type_filt);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('egc_applicant.created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('egc_applicant.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('egc_applicant.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('egc_applicant.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('egc_applicant.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('egc_applicant.created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
           
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'data' => $item,
                  'old_data' => $item->old_data,
                  'drive_data' => $item->drive_data,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     
      return view('content.hr_management.hr_recruiter.manage_candidate.candidate_list', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
   
  }

}
