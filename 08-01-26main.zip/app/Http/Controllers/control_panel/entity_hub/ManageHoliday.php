<?php

namespace App\Http\Controllers\control_panel\entity_hub;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Models\HolidayExportExcel;
use Maatwebsite\Excel\Facades\Excel;


class ManageHoliday extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        
      $Entity = HolidayModel::where('egc_holiday.status', '!=', 2)
      ->select('egc_holiday.*',
      //  'egc_countries.name',
      //   'egc_states.name as statename',
      //    'egc_cities.name as citiesname',
      //     'egc_company.company_name',
      //     'egc_company_type.company_type_name',
      //      'egc_company_type.slug_name'
    );
      // ->leftJoin('egc_company', 'egc_company.sno', 'egc_entity.company_id')
      // ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno');
    
      
        // if($search_filter != '') {
        //     $Entity->where(function ($subquery) use ($search_filter) {
        //         $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_ct_person', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_ct_number', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_mail', 'LIKE', "%{$search_filter}%");
        //     });
        // }
        
    $Entity = $Entity->orderBy('egc_holiday.sno', 'asc')->paginate($perpage);
     $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Entity->map(function ($item) use ($helper) {
            $hol_start_date = Carbon::parse($item->hol_date);
            $hol_end_date = Carbon::parse($item->hol_end_date);
            $days_between = $hol_start_date->diffInDays($hol_end_date) + 1;
           
            $company_ids = $item->company_ids ? json_decode($item->company_ids) : [];
            $company_names_query = DB::table('egc_company')
                ->whereIn('sno', $company_ids)
                ->where('status', 0)
                ->orderBy('sno', 'asc')
                ->pluck('company_name');
                
            if (in_array(0, $company_ids)) {
                $company_names = $company_names_query->prepend('Elysium Groups of Companies');
            } else {
                $company_names = $company_names_query;
            }
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'company_names' => $company_names,
                'totalDays' => $days_between,
                'data'=> $item,
                // 'company_name' => $item->company_name,
                // 'entity_name' => $item->entity_name,
                // 'entity_mail' => $item->entity_mail,
                // 'company_type_name' => $item->company_type_name,
                //  'slug_name' => $item->slug_name,
                // 'company_mail' => $item->company_mail,
                // 'company_address' => $company_address,
                // 'entity_website' => $item->entity_website,
                // 'entity_ct_person' => $item->entity_ct_person,
                // 'entity_ct_number' => $item->entity_ct_number,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $Entity->currentPage(),
            'last_page' => $Entity->lastPage(),
            'total' => $Entity->total(),
        ]);
    }

    $Company = CompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    
    return view('content.control_panel.entity_hub.manage_holiday.holiday_list',[
        'ListTable' => $Entity,
          'Company' => $Company,
          'social_media_list' => $social_media_list,
          'perpage' => $perpage,
            'search_filter' => $search_filter,
      ]);
  }
  
    public function List(Request $request)
  {

      $company_id = $request->input('company_id');
      $entity = HolidayModel::where('status', 0)->where('company_id', $company_id)->orderBy('sno', 'asc')->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $entity
      ], 200);
  }
  

  public function HolidayCalender(Request $request)
  {
   
      $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        
      $Entity = HolidayModel::where('egc_holiday.status', '!=', 2)
      ->select('egc_holiday.*',
      //  'egc_countries.name',
      //   'egc_states.name as statename',
      //    'egc_cities.name as citiesname',
      //     'egc_company.company_name',
      //     'egc_company_type.company_type_name',
      //      'egc_company_type.slug_name'
    );
      // ->leftJoin('egc_company', 'egc_company.sno', 'egc_entity.company_id')
      // ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno');
    
      
        // if($search_filter != '') {
        //     $Entity->where(function ($subquery) use ($search_filter) {
        //         $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_ct_person', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_ct_number', 'LIKE', "%{$search_filter}%")
        //             ->orWhere('egc_entity.entity_mail', 'LIKE', "%{$search_filter}%");
        //     });
        // }
        
    $Entity = $Entity->orderBy('egc_holiday.sno', 'asc')->paginate($perpage);
     $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Entity->map(function ($item) use ($helper) {
            $hol_start_date = Carbon::parse($item->hol_date);
            $hol_end_date = Carbon::parse($item->hol_end_date);
            $days_between = $hol_start_date->diffInDays($hol_end_date) + 1;
           
            $company_ids = $item->company_ids ? json_decode($item->company_ids) : [];
            $company_names_query = DB::table('egc_company')
                ->whereIn('sno', $company_ids)
                ->where('status', 0)
                ->orderBy('sno', 'asc')
                ->pluck('company_name');
                
            if (in_array(0, $company_ids)) {
                $company_names = $company_names_query->prepend('Elysium Groups of Companies');
            } else {
                $company_names = $company_names_query;
            }
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'start_date' => $item->hol_date,
                'end_date' => $item->hol_end_date,
                'status' => $item->status,
                'company_names' => $company_names,
                'totalDays' => $days_between,
                'data'=> $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $Entity->currentPage(),
            'last_page' => $Entity->lastPage(),
            'total' => $Entity->total(),
        ]);
    }

    $companies  = CompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $Company  = CompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    
    return view('content.control_panel.entity_hub.manage_holiday.holiday_calender',[
        'ListTable' => $Entity,
          'companies' => $companies ,
          'Company' => $Company ,
          'social_media_list' => $social_media_list,
          'perpage' => $perpage,
            'search_filter' => $search_filter,
      ]);
  }


 public function calendarEvents(Request $request)
{
    $company_id = $request->company_id;
    $status     = $request->status;
    $start      = $request->start;
    $end        = $request->end;

    $query = HolidayModel::where('status', '!=', 2);

    if ($status !== null && $status !== '') {
        $query->where('status', $status);
    }

    // Company filter
    if ($company_id !== null && $company_id !== '') {
        if ($company_id == 0) {
            $query->whereJsonContains('company_ids', '0');
        } else {
            $query->whereJsonContains('company_ids', $company_id);
        }
    }

    if ($start && $end) {
        $query->whereBetween('hol_date', [$start, $end]);
    }

    $holidays = $query->get();
    $events = [];
    // return  $holidays;
    foreach ($holidays as $holiday) {

        $company_ids = json_decode($holiday->company_ids, true) ?? [];

        // Company title logic
        if($company_id !== null && $company_id !== ''){
            if ($company_id == 0) {
                $company_title = 'Elysium Groups of Companies';
            } else {
                $company_title = DB::table('egc_company')
                    ->where('sno', $company_id)
                    ->where('status', 0)
                    ->pluck('company_name')
                    ->implode(', ');
            }
        }else{
            if (in_array(0, $company_ids)) {
                $company_title = DB::table('egc_company')
                    ->whereIn('sno', $company_ids)
                    ->where('status', 0)
                    ->pluck('company_name')
                    ->prepend('Elysium Groups of Companies')
                    ->implode(', ');
            } else {
                $company_title = DB::table('egc_company')
                    ->whereIn('sno', $company_ids)
                    ->where('status', 0)
                    ->pluck('company_name')
                    ->implode(', ');
            }  
        }

        $events[] = [
            'id'    => $holiday->sno,
            'title' => $holiday->hol_reason,
            'start' => $holiday->hol_date,
            'end'   => Carbon::parse($holiday->hol_end_date)->addDay()->toDateString(),
            'backgroundColor' => $holiday->status == 1 ? '#dc3545' : '#038701',
            'extendedProps' => [
                'company' => $company_title,
                'status'  => $holiday->status,
                'days'    => Carbon::parse($holiday->hol_date)
                                ->diffInDays($holiday->hol_end_date) + 1,
            ]
        ];
    }

    return response()->json($events);
}



  public function Add(Request $request)
{

 
    // Validate the incoming data
    $validator = Validator::make($request->all(), [
        'hol_date_add' => 'required|date|max:255',
        'hol_date_end_add' => 'required|date|max:255',
        'hol_reason_add' => 'required|string|max:255', // Add validation for holiday reason
        'company_ids' => 'required|array',  // Ensure company selection is required
    ]);

    // If validation fails, return response with errors
    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $hol_date   = date('Y-m-d', strtotime($request->hol_date_add));
    $hol_end_date   = date('Y-m-d', strtotime($request->hol_date_end_add));
    $hol_reason = $request->hol_reason_add;
    $company_ids = $request->input('company_ids');
    $user_id    = $request->user()->user_id;
   
    // If "All Companies" (sno=0) is selected, fetch all companies
    if (in_array("all", $company_ids)) {
        $company_ids = DB::table("egc_company")
            ->where("status", 0)
            ->pluck("sno")
            ->map(fn($id) => (string)$id) 
            ->prepend("0")
            ->toArray();
    }


    // Check if the holiday already exists for the selected companies on the chosen date
    $chk = HolidayModel::where('hol_date', $hol_date)
        ->whereIn('company_ids', $company_ids)
        ->where('status', '!=', 2)
        ->first();

    // If the holiday already exists, return error
    if ($chk) {
        session()->flash('toastr', [
            'status'  => 401,
            'type'    => 'error',
            'message' => 'Holiday already exists for the selected date and companies!'
        ]);
        return redirect()->back();
    }

    // Begin database transaction to ensure atomicity
    DB::beginTransaction();
    $company_ids = $this->normalizeCompanyIds($company_ids);

    try {
        // Create a new holiday entry
        $add_category = new HolidayModel();
        $add_category->hol_date       = $hol_date;
        $add_category->hol_end_date       = $hol_end_date;
        $add_category->hol_reason     = $hol_reason;
        $add_category->company_ids    = json_encode($company_ids);  // Store selected companies
        $add_category->created_by     = $user_id;
        $add_category->updated_by     = $user_id;
        $add_category->save();

        // Commit the transaction after saving the holiday
        DB::commit();

        session()->flash('toastr', [
            'type'    => 'success',
            'message' => 'Holiday added successfully!'
        ]);
    } catch (\Exception $e) {
        DB::rollBack();  // Rollback in case of any failure

        session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Failed to add holiday: ' . $e->getMessage()
        ]);
    }

    // Redirect back to the previous page
    return redirect()->back();
}


private function normalizeCompanyIds(array $company_ids)
{
    return array_values(
        array_unique(
            array_map('strval', $company_ids)
        )
    );
}
  
  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
        'hol_date_edit' => 'required|date|max:255',
    ]);

    if ($validator->fails()) {
        return response([
            'status' => 401,
            'message' => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data' => null,
        ], 200);
    }

    DB::beginTransaction();

    try {
        $holiday_id = $request->holiday_id;
        $new_date = date('Y-m-d', strtotime($request->hol_date_edit));
        $new_enddate = date('Y-m-d', strtotime($request->hol_date_end_edit));
        $new_reason = $request->hol_reason_edit;
        $company_ids = $request->input('company_ids');
        $user_id = $request->user()->user_id;

    
        // If "All Companies" (sno=0) is selected, fetch all companies
        if (in_array("all", $company_ids)) {
            $company_ids = DB::table("egc_company")->where("status", 0)->pluck("sno")->prepend(0)->toArray();
        }

        // Check if the holiday already exists for the selected companies on the chosen date
        $chk = HolidayModel::where('hol_date', $new_date)
            ->whereIn('company_ids', $company_ids)
            ->where('status', '!=', 2)
            ->where('sno', '!=',$holiday_id)
            ->first();

        // If the holiday already exists, return error
        if ($chk) {
            session()->flash('toastr', [
                'status'  => 401,
                'type'    => 'error',
                'message' => 'Holiday already exists for the selected date and companies!'
            ]);
            return redirect()->back();
        }

        $holiday = HolidayModel::where('sno', $holiday_id)->first();

        if (!$holiday) {
            throw new \Exception('Holiday not found.');
        }

       
        // 6. Finally Update Holiday Data
        $holiday->hol_date       = $new_date;
        $holiday->hol_end_date       = $new_enddate;
        $holiday->hol_reason     = $new_reason;
        $holiday->company_ids    = json_encode($company_ids);
        $holiday->updated_by = $user_id;
        $holiday->save();
      

        DB::commit();

        session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Holiday updated successfully!'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();
        
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Failed to update holiday: ' . $e->getMessage()
        ]);
    }

    return redirect()->back();
}

   public function Status($id, Request $request)
  {

        $staff =  HolidayModel::where('sno', $id)->first();
        // return $staff;
        $staff->status = $request->input('status', 0);
        $staff->update();

        if ($staff) {
        return response([
            'status'    => 200,
            'message'   => 'Holiday  Status Successfully Updated!',
            'error_msg' => 'Could not, update  Holiday  Status!',
            'data'      => null,
        ], 200);
        } else {
        return response([
            'status'    => 200,
            'message'   => 'Could not update Holiday  Status!',
            'error_msg' => 'Could not, update  Holiday  Status!',
            'data'      => null,
        ], 200);
        }
    }
  public function Delete($id)
  {
    $upd_StaffModel = HolidayModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Holiday Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Entity ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('egc_entity')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }

  public function sampleHolidayEntryExcel()
    {
        return Excel::download(
            new HolidayExportExcel(),
            'holiday-entry-sample.xlsx'
        );
    }

    public function importHolidayCalendar(Request $request)
{
    $validator = Validator::make($request->all(), [
        'file_upload' => 'required|file|mimes:xls,xlsx,xlsm,csv',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => 'Invalid file format'
        ]);
    }

    DB::beginTransaction();

    try {
        $rows = Excel::toArray([], $request->file('file_upload'))[0];

        // Remove header row
        unset($rows[0]);

        $userId = auth()->user()->user_id;
        $insertCount = 0;

        foreach ($rows as $index => $row) {

            // Skip empty rows
            if (
                empty($row[0]) ||
                empty($row[1]) ||
                empty($row[2]) ||
                empty($row[3])
            ) {
                continue;
            }

            $holDate     = Carbon::parse($row[0])->format('Y-m-d');
            $holEndDate  = Carbon::parse($row[1])->format('Y-m-d');
            $holReason   = trim($row[2]);
            $companyName = trim($row[3]);

            /**
             * Company mapping
             */
            if ($companyName === 'All') {
                $companyIds = DB::table('egc_company')
                    ->where('status', 0)
                    ->pluck('sno')
                    ->map(fn($id) => (string)$id)
                    ->prepend('0')
                    ->toArray();
            }
            elseif ($companyName === 'Elysium Groups') {
                $companyIds = ['0'];
            }
            else {
                $companySno = DB::table('egc_company')
                    ->where('company_name', $companyName)
                    ->where('status', 0)
                    ->value('sno');

                if (!$companySno) {
                    continue; // skip invalid company
                }

                $companyIds = [(string)$companySno];
            }

            $companyIds = $this->normalizeCompanyIds($companyIds);

            /**
             * Duplicate check
             */
            $exists = HolidayModel::where('hol_date', $holDate)
                ->where('status', '!=', 2)
                ->get()
                ->filter(function ($item) use ($companyIds) {
                    return array_intersect(
                        json_decode($item->company_ids, true),
                        $companyIds
                    );
                })
                ->isNotEmpty();

            if ($exists) {
                continue;
            }

            /**
             * Insert
             */
            HolidayModel::create([
                'hol_date'      => $holDate,
                'hol_end_date'  => $holEndDate,
                'hol_reason'    => $holReason,
                'company_ids'   => json_encode($companyIds),
                'created_by'    => $userId,
                'updated_by'    => $userId,
            ]);

            $insertCount++;
        }

        DB::commit();

        return response()->json([
            'success' => true,
            'message' => "{$insertCount} holidays imported successfully"
        ]);

    } catch (\Exception $e) {

        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Import failed: ' . $e->getMessage()
        ]);
    }
}
}
