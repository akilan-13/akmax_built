<?php

namespace App\Services;

use Google\Client;
use Google\Service\Drive;
use Google\Service\Drive\DriveFile;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Exception;
use Symfony\Component\HttpFoundation\StreamedResponse;
class GoogleDriveService
{
    protected Client $client;
    protected Drive $drive;
    protected ?string $rootFolderId;

    public function __construct()
    {
        $this->rootFolderId = env('GOOGLE_DRIVE_FOLDER_ID'); // Optional root folder

        // Initialize Google Client
        $this->client = new Client();
        $this->client->setApplicationName(config('app.name'));
        $this->client->setScopes([Drive::DRIVE]);
        $this->client->setAccessType('offline'); // offline to allow refresh token
        $this->client->setClientId(env('GOOGLE_CLIENT_ID'));
        $this->client->setClientSecret(env('GOOGLE_CLIENT_SECRET'));

        $refreshToken = env('GOOGLE_REFRESH_TOKEN');
        if (!$refreshToken) {
            throw new Exception('Google refresh token missing in .env');
        }

        // Use permanent refresh token to get access token automatically
        $this->client->refreshToken($refreshToken);

        $this->drive = new Drive($this->client);
    }
    

    protected function authenticate(): void
    {
        $refreshToken = env('GOOGLE_REFRESH_TOKEN');

        if (!$refreshToken) {
            throw new \Exception('Google refresh token missing in .env');
        }

        // Fetch a valid access token using refresh token
        $accessToken = $this->client->fetchAccessTokenWithRefreshToken($refreshToken);
        
        if (isset($accessToken['error'])) {
            throw new \Exception('Failed to fetch access token: ' . $accessToken['error']);
        }

        // Set the access token
        $this->client->setAccessToken($accessToken);
    }

    /**
     * Upload file to Google Drive
     */
    public function upload(UploadedFile $file, ?string $folderId = null): DriveFile
    {
        try {
            $metadata = [
                'name' => $this->sanitizeFileName($file->getClientOriginalName())
            ];

            $parent = $folderId ?? $this->rootFolderId;
            if ($parent) {
                $metadata['parents'] = [$parent];
            }

            $driveFile = new DriveFile($metadata);

            $uploadedFile = $this->drive->files->create($driveFile, [
                'data' => file_get_contents($file->getRealPath()),
                'mimeType' => $file->getMimeType(),
                'uploadType' => 'multipart',
                'fields' => 'id,name,size,webViewLink'
            ]);

            Log::info('Google Drive upload success', [
                'file_id' => $uploadedFile->id,
                'name' => $uploadedFile->name,
            ]);

            return $uploadedFile;

        } catch (Exception $e) {
            Log::error('Google Drive upload failed', [
                'error' => $e->getMessage()
            ]);

            throw new Exception('Google Drive upload failed: ' . $e->getMessage());
        }
    }

    /**
     * List files
     */
    public function listFiles(int $limit = 20): array
    {
        try {
            $params = [
                'pageSize' => $limit,
                'fields' => 'files(id,name,size,webViewLink,createdTime)',
                'orderBy' => 'createdTime desc'
            ];

            if ($this->rootFolderId) {
                $params['q'] = "'{$this->rootFolderId}' in parents and trashed = false";
            }

            $files = $this->drive->files->listFiles($params);
            return $files->getFiles();

        } catch (Exception $e) {
            Log::error('Google Drive list failed', ['error' => $e->getMessage()]);
            throw new Exception('Unable to list Google Drive files: ' . $e->getMessage());
        }
    }

    /**
     * Delete file
     */
    public function delete(string $fileId): bool
    {
        try {
            $this->drive->files->delete($fileId);
            Log::info('Google Drive file deleted', ['file_id' => $fileId]);
            return true;
        } catch (Exception $e) {
            Log::error('Google Drive delete failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            throw new Exception('Failed to delete file: ' . $e->getMessage());
        }
    }

    /**
     * Create folder
     */
    public function createFolder(string $name, ?string $parentId = null): DriveFile
    {
        try {
            $metadata = [
                'name' => $name,
                'mimeType' => 'application/vnd.google-apps.folder'
            ];

            if ($parentId) {
                $metadata['parents'] = [$parentId];
            }

            return $this->drive->files->create(
                new DriveFile($metadata),
                ['fields' => 'id,name']
            );

        } catch (Exception $e) {
            Log::error('Google Drive folder create failed', [
                'error' => $e->getMessage()
            ]);
            throw new Exception('Folder creation failed: ' . $e->getMessage());
        }
    }

    /**
     * Sanitize file name
     */
    protected function sanitizeFileName(string $name): string
    {
        return preg_replace('/[^A-Za-z0-9\.\-_]/', '_', $name);
    }

    public function makeFolderPublicViewer(string $folderId): bool
    {
        try {
            // $this->authenticate();

            $permission = new \Google\Service\Drive\Permission([
                'type' => 'anyone',
                'role' => 'reader',
                'allowFileDiscovery' => false, // 🔑 IMPORTANT
            ]);

            $this->drive->permissions->create(
                $folderId,
                $permission,
                [
                    'sendNotificationEmail' => false,
                    'fields' => 'id'
                ]
            );

            Log::info('Folder link-only viewer access granted', [
                'folder_id' => $folderId
            ]);

            return true;

        } catch (Exception $e) {
            throw new Exception(
                'Unable to set link-only viewer access: ' . $e->getMessage()
            );
        }
    }



    public function hasPublicViewerAccess(string $folderId): bool
    {
        try {
            // $this->authenticate();

            $permissions = $this->drive->permissions->listPermissions(
                $folderId,
                ['fields' => 'permissions(id,type,role,allowFileDiscovery)']
            );

            foreach ($permissions->getPermissions() as $permission) {
                if (
                    $permission->getType() === 'anyone' &&
                    $permission->getRole() === 'reader' &&
                    $permission->getAllowFileDiscovery() === false
                ) {
                    return true;
                }
            }

            return false;

        } catch (Exception $e) {
            throw new Exception(
                'Unable to check folder permissions: ' . $e->getMessage()
            );
        }
    }



    public function ensurePublicViewerAccess(string $folderId): bool
    {
        // $this->authenticate();

        if ($this->hasPublicViewerAccess($folderId)) {
            return true;
        }

        $permission = new \Google\Service\Drive\Permission([
            'type' => 'anyone',
            'role' => 'reader',
            'allowFileDiscovery' => false, // 🔒 LINK-ONLY
        ]);

        $this->drive->permissions->create(
            $folderId,
            $permission,
            [
                'sendNotificationEmail' => false,
                'fields' => 'id'
            ]
        );

        return true;
    }


    public function makeFolderRestricted(string $folderId): bool
    {
        try {
            // Get all permissions
            $permissions = $this->drive->permissions->listPermissions(
                $folderId,
                ['fields' => 'permissions(id,type,role)']
            );

            // Remove 'anyone' permissions
            foreach ($permissions->getPermissions() as $permission) {
                if ($permission->getType() === 'anyone') {
                    $this->drive->permissions->delete($folderId, $permission->getId());
                }
            }

            Log::info('Folder restricted access enforced', [
                'folder_id' => $folderId
            ]);

            return true;

        } catch (Exception $e) {
            throw new Exception(
                'Unable to restrict folder access: ' . $e->getMessage()
            );
        }
    }

    public function hasRestrictedAccess(string $folderId): bool
    {
        try {

            $permissions = $this->drive->permissions->listPermissions(
                $folderId,
                ['fields' => 'permissions(id,type,role)']
            );

            foreach ($permissions->getPermissions() as $permission) {
                // If there is any 'anyone' permission, it's not restricted
                if ($permission->getType() === 'anyone') {
                    return false;
                }
            }

            return true; // No 'anyone' permissions found
        } catch (Exception $e) {
            throw new Exception(
                'Unable to check folder permissions: ' . $e->getMessage()
            );
        }
    }

    public function ensureRestrictedAccess(string $folderId): bool
    {
        if ($this->hasRestrictedAccess($folderId)) {
            return true;
        }

        return $this->makeFolderRestricted($folderId);
    }

    public function downloadFile(string $fileId): string
    {
        try {
            $response = $this->drive->files->get($fileId, [
                'alt' => 'media'
            ]);

            $content = $response->getBody()->getContents();

            if (!$content) {
                throw new Exception('Empty file content from Drive API');
            }

            $tempPath = storage_path('app/drive_' . uniqid());
            file_put_contents($tempPath, $content);

            return $tempPath;

        } catch (Exception $e) {
            Log::error('Google Drive download failed', [
                'file_id' => $fileId,
                'error' => $e->getMessage()
            ]);
            throw new Exception('Unable to download file from Google Drive');
        }
    }
    

    public function streamFile(string $fileId): StreamedResponse
    {
        try {
            // Always ensure token is valid
            // $this->authenticate();

            // Get file metadata (for mime type & name)
            $file = $this->drive->files->get(
                $fileId,
                ['fields' => 'name,mimeType,size']
            );

            // Stream file content
            $response = $this->drive->files->get(
                $fileId,
                ['alt' => 'media']
            );

            $mimeType = $file->getMimeType() ?? 'application/octet-stream';
            $fileName = $file->getName() ?? 'document';
            

            return response()->stream(
                function () use ($response) {
                    echo $response->getBody()->getContents();
                },
                200,
                [
                    'Content-Type'        => $mimeType,
                    'Content-Disposition' => 'inline; filename="'.$fileName.'"',
                    'Cache-Control'       => 'private, no-store, no-cache',
                    'Pragma'              => 'no-cache',
                    'X-Content-Type-Options' => 'nosniff',
                ]
            );

        } catch (Exception $e) {
            Log::error('Drive stream failed', [
                'file_id' => $fileId,
                'error'   => $e->getMessage(),
            ]);

            abort(404, 'Unable to preview file');
        }
    }


}
