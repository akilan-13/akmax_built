<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicantStatusModel extends Model
{
    use HasFactory;

    protected $table = 'egc_applicant_status';
    protected $primaryKey = 'sno';
    public $timestamps = false; // Because created_on & updated_on are custom columns

    protected $fillable = [
        'applicant_status_name',
        'status_color',
        'applicant_desc',
        'status',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
    ];

}
