<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HolidayModel extends Model {
    use HasFactory;
    public $table      = 'egc_holiday';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'company_ids',
        'entity_ids',
        'branch_ids',
        'hol_date',
        'hol_end_date',
        'hol_reason',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}