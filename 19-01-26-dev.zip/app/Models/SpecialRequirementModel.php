<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SpecialRequirementModel extends Model {
    use HasFactory;
    public $table      = 'egc_special_requirements';
    public $primaryKey = 'sno';

    protected $fillable = [
        'erp_requirement_id',
        'company_type',
        'company_id',
        'entity_id',
        'requirement_name',
        'requirement_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}