<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepartmentModel extends Model
{
    use HasFactory;
    public $table      = 'egc_department';
    public $primaryKey = 'sno';

    protected $fillable = [
        'department_id',
        'erp_department_id',
        'company_type',
        'company_id',
        'entity_id',
        'branch_id',
        'department_name',
        'department_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
