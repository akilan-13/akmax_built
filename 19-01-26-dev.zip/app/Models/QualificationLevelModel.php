<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QualificationLevelModel extends Model {
    use HasFactory;
    public $table      = 'egc_qualification_level';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'qualification_level_name',
        'description',
        'created_by',
        'created_at',
        'status',
    ];
}