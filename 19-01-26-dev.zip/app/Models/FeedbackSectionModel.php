<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeedbackSectionModel extends Model {
    use HasFactory;
    public $table      = 'egc_feedback_section';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'section_name',
        'section_icon',
        'section_desc',
        'created_by',
        'created_at',
        'updated_at',
        'updated_by',
        'status',
    ];
}