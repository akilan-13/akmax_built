<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CredentialModel extends Model
{
    use HasFactory;
    public $table = "egc_credential";
    public $primaryKey = 'sno';

    protected $fillable = [
        'credential_id',
        'credential_name',
        'credential_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
