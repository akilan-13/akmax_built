<?php

namespace App\Http\Controllers\settings\management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use App\Models\DivisionModel;
use App\Models\JobRoleModel;
use Carbon\Carbon;

class Division extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      
    $Division = DivisionModel::where('egc_division.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_division.*','egc_department.department_name')
      ->join('egc_department', 'egc_division.department_id', 'egc_department.sno');

      
       if ($search_filter != '') {
            $Division->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Division=$Division->orderBy('egc_division.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Division->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'division_name' => $item->division_name,
                    'department_name' => $item->department_name,
                    'department_id' => $item->department_id,
                    'division_desc' => $item->division_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Division->currentPage(),
                'last_page' => $Division->lastPage(),
                'total' => $Division->total(),
            ]);
        }
      $Department = DepartmentModel::where('egc_department.status',  0)->orderBy('sno', 'asc')
            ->where('egc_department.company_type',1)->get();

    // return $Department;

    return view('content.settings.management.division.division_list', [
      'ListTable' => $Division,
      'Department' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }
  public function BuisenessIndex()
  {
    $Division = DivisionModel::where('egc_division.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_division.*', 'egc_entity.entity_name as entityname', 'egc_branch.branch_name', 'egc_branch.franchise_name', 'egc_branch.branch_type', 'egc_department.department_name as deptname')
      ->leftJoin('egc_entity', 'egc_division.entity_id', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'egc_division.branch_id', 'egc_branch.sno')
      ->leftJoin('egc_department', 'egc_division.department_id', 'egc_department.sno')
      ->orderBy('egc_division.sno', 'desc')->get();
    // return $Department;
    $pageConfigs = ['myLayout' => 'default'];
    return view('content.settings.management.division.division_list', [
      'ListTable' => $Division,
      'pageConfigs' => $pageConfigs
    ]);
  }
  public function Status($id, Request $request)
  {

    $staff =  DivisionModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Staff  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DivisionModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function DepartDivisionList(Request $request)
  {

    $department_id = $request->department_id;
    $Department = DivisionModel::where('status', '!=', 2)->where('department_id', $department_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }


  public function JobPostionList(Request $request)
  {
    
    $division_id = $request->division_id;

    $startTime = microtime(true);
    $job_position = JobRoleModel::where('division_id', $division_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }
  public function JobPostionListEntity(Request $request)
  {

    $entity_id = $request->entity_id;

    $startTime = microtime(true);
    $job_position = JobRoleModel::where('entity_id', $entity_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'department_id' => 'required',
      'division_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $department_id = $request->department_id;
      $division_name = $request->division_name;
      $Desc = $request->division_desc;
      $branch_id = $request->branchId;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', $division_name)->where('company_type', 1)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = new DivisionModel();
        $add_division->division_name = $division_name;
        $add_division->department_id = $department_id;
        $add_division->division_desc = $Desc;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
  public function Edit($id)
  {
    $data = DivisionModel::where('sno', $id)->first();
    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Division not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Division fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }
  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'department_id' => 'required',
      'division_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $department_id = $request->department_id;
      $division_name = $request->division_name;
      $sno = $request->edit_id;
      $Desc = $request->division_desc;
      $user_id = $request->user()->user_id;
      $chk = DivisionModel::where('division_name', $division_name)->where('company_type', 1)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Division Name Already Exists!'
        ]);
        return redirect()->back();
      } else {

        $add_division = DivisionModel::where('sno', $sno)->first();
        $add_division->division_name = $division_name;
        $add_division->department_id = $department_id;
        $add_division->division_desc = $Desc;
        $add_division->created_by = $user_id;
        $add_division->updated_by = $user_id;

        $add_division->save();

        if ($add_division) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Division updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Division!'
          ]);
        }
      }
      return redirect()->back();
    }
  }
}