<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Validator;

class EmailTemplate extends Controller
{
  protected static $branch_id = 1;

  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = EmailTemplateModel::where('status', '!=', 2);
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('email_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('email_subject', 'LIKE', "%{$search_filter}%");
            });
        }

        $Department=$Department->orderBy('sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'email_name' => $item->email_name,
                    'email_subject' => $item->email_subject,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
    return view('content.settings.common.email_template.email_template_list',[
          'perpage'=>$perpage,
          'search_filter'=>$search_filter,
    ]);
  }
  public function List()
  {
    $LedgerCategory = EmailTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $LedgerCategory
    ], 200);
  }
  public function EmailAdd()
  {
    return view('content.settings.common.email_template.add');
  }

 

  public function Edit($id)
  {
    // Decrypt the ID
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    $Edit = EmailTemplateModel::where('sno', $decryptedValue)->first();
    return view('content.settings.common.email_template.edit', [
      'edit' => $Edit
    ]);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'email_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $email_name       = $request->email_name;
      $email_subject          = $request->email_subject;
      $user_id                    = $request->user()->user_id;
      $chk = EmailTemplateModel::where('email_name', ucwords($email_name))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Email is exist!'
        ]);
        return redirect('settings/email_template');
      } else {
        $category_check = EmailTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $email_template_id = 'ET-0001/' . $year;
        } else {

          $data = $category_check->email_template_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf('ET-%04d', $next_number);

          $year = substr(date('y'), -2);
          $email_template_id = $request . '/' . $year;
        }

        $add_ledger = new EmailTemplateModel();
        $add_ledger->email_template_id         = $email_template_id;
        $add_ledger->email_name       = Ucfirst($email_name);
        $add_ledger->email_subject       = $email_subject;
        $add_ledger->branch_id         = 0;
        $add_ledger->created_by        = $user_id;
        $add_ledger->updated_by        = $user_id;


        $add_ledger->save();

        if ($add_ledger) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Email added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Email!'
          ]);
        }
      }
      return redirect('settings/email_template');
    }
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'email_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $email_name       = $request->email_name;
      $email_subject       = $request->email_subject;
      $edit_id       = $request->edit_id;

      $upd_LedgerCategoryModel =  EmailTemplateModel::where('sno', $edit_id)->first();

      $chk = EmailTemplateModel::where('email_name', ucwords($email_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Ledger is exist!'
        ]);
        return redirect()->back();
      } else {


        $upd_LedgerCategoryModel->email_name  = Ucfirst($email_name);
        $upd_LedgerCategoryModel->email_subject  = $email_subject;
        $upd_LedgerCategoryModel->update();
        // return $upd_LedgerCategoryModel;

        if ($upd_LedgerCategoryModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Email Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Email!'
          ]);
        }
      }
    }
    return redirect('settings/email_template');
  }


  public function Delete($id)
  {
    $upd_LedgerCategoryModel = EmailTemplateModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status  = 2;
    $upd_LedgerCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  EmailTemplateModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
