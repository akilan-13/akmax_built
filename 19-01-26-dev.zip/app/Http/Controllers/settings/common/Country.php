<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\User;

class Country extends Controller
{
//   protected static $branch_id = 1;
  // public function index()
  // {
  //   return view('content.settings.common.country.country_list');
  // }
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $country = CountryModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $country->where(function ($subquery) use ($search_filter) {
            $subquery->where('name', 'LIKE', "%{$search_filter}%")
                ->orWhere('sortname', 'LIKE', "%{$search_filter}%")
                ->orWhere('phonecode', 'LIKE', "%{$search_filter}%");
                
        });
    }
    $country=$country->orderBy('id', 'desc')->paginate($perpage);
    $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $country->map(function ($item) use ($helper) {
            return [
                'sno' => $item->id,
                'status' => $item->status,
                'name' => $item->name,
                'sortname' => $item->sortname,
                'phonecode' => $item->phonecode,
                'item' => $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $country->currentPage(),
            'last_page' => $country->lastPage(),
            'total' => $country->total(),
        ]);
    }
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.settings.common.country.country_list', [
      'country' => $country,
      'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }

  public function List()
  {
      $city = CountryModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    
    public function List_for_edit()
  {
    $sms_template = CountryModel::orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $sortname                   = $request->sortname;
      $name                 = $request->name;
      $phonecode                = $request->phonecode;
      $user_id                    = $request->user()->user_id ?? 1;
      $chk = CountryModel::where('name', $name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
      } else {
        $category_check = CountryModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();

        $add_category = new CountryModel();
        $add_category->sortname  = $sortname;
        $add_category->name = $name;
        $add_category->phonecode = $phonecode;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Country added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Country!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'Country Created successfully!');
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $sortname                   = $request->sortname;
      $name                 = $request->name;
      $phonecode                = $request->phonecode;

      $upd_CourseCategoryModel =  CountryModel::where('id', $id)->first();

      $chk = CountryModel::where('name', $name)->where('id', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Country has been already assigned!'
        ]);
        return redirect()->back();
      } else {
        $upd_CourseCategoryModel->sortname  = $sortname;
        $upd_CourseCategoryModel->name  = $name;
        $upd_CourseCategoryModel->phonecode  = $phonecode;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Country updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Country !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CountryModel::where('id', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CountryModel::where('id', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
