<?php

namespace App\Http\Controllers\authentications;

use App\Http\Controllers\Controller;
use App\Http\Controllers\user_management\UserRole;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\ManageEntityModel;
use App\Models\UserRolePermissionModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\Response;
  use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Http;
class Login extends Controller
{
  public function index(Request $request)
  {

    $ipAddress = $request->ip();
    return view('content.authentications.login', compact('ipAddress'));
    // return view('content.dashboard.login');
  }
  public function get_staff()
  {
    return view('content.dashboard.get_staff');
  }
  public function forgot_password()
  {
    return view('content.dashboard.forgot_password');
  }
  public function new_password()
  {
    return view('content.dashboard.new_password');
  }
  
  public function downloadLoginReport()
  {
    $today = Carbon::today();

    // Fetch users who logged in today (via token)
    $userIds = DB::table('personal_access_tokens')
        ->whereDate('created_at', $today)
        ->distinct()
        ->pluck('tokenable_id');

    $users = DB::table('users')
        ->whereIn('id', $userIds)
        ->get(['id', 'name', 'email']);

    // Prepare content
    $content = "Logged In Users - " . now()->format('d-m-Y') . "\n\n";
    foreach ($users as $user) {
        $content .= "ID: {$user->id} | Name: {$user->name} | Email: {$user->email}\n";
    }

    // Download as .txt file
    return Response::make($content, 200, [
        'Content-Type' => 'text/plain',
        'Content-Disposition' => 'attachment; filename="login_users_' . now()->format('Ymd') . '.txt"',
    ]);
}
  public function updateProfile(Request $request)
  {
    $user = Auth::user(); // Get authenticated user

    // Validate request
    $request->validate([
      'staff_password' => 'nullable|min:6', // Password is optional, must be at least 6 characters if provided
      'staff_image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Image validation
    ]);

    // Update password in user table if provided
    if ($request->filled('staff_password')) {
      $user->password = Hash::make($request->staff_password); // Hash and update password
      $user->save();
    }

    // Update password in staff table if exists
    $staff = $user->staff;
    

    
    if ($staff) {
      if ($request->filled('staff_password')) {
        $staff->password = $request->staff_password; // Hash and update password
      }

      // Handle profile image upload
       if ($request->hasFile('staff_image')) {
            $image = $request->file('staff_image');
            $extension = $image->extension();
    
            // Determine folder based on company type
            if ($staff->company_type == 1) {
                $folderPath = public_path('staff_images/Management');
            } else {
                $folderPath = public_path("staff_images/Buisness/{$staff->company_id}/{$staff->entity_id}");
            }
    
            // Create directory if not exists
            if (!File::exists($folderPath)) {
                File::makeDirectory($folderPath, 0777, true, true);
            }
    
            // Build file name
            $staff_imageName = 'staff_' . $staff->sno . '.' . $extension;
    
            // Move uploaded image
            $image->move($folderPath, $staff_imageName);
    
            // Save relative path (optional — here we just store file name)
            $staff->staff_image = $staff_imageName;
        }

      $staff->save(); // Save staff record after updating password and/or image
    }

    return back()->with('success', 'Profile updated successfully.');
  }
  
  public function login(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255',
      'password' => 'required',
    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => $validator->errors()
      ]);
      return back()->withInput();
    }

    $remember = $request->has('remember');
    $user = User::select('users.*', 'egc_staff.status as staff_status')
      ->where('users.name', $request->name)
      ->leftJoin('egc_staff', 'users.user_id', '=', 'egc_staff.sno')
      ->leftJoin('egc_company', 'users.company_id', '=', 'egc_company.sno')
      ->leftJoin('egc_entity', 'users.entity_id', '=', 'egc_entity.sno')
      ->leftJoin('egc_branch', 'users.branch_id', '=', 'egc_branch.sno')
      ->where('egc_staff.status', 0)
      ->first();

    

    if (!$user) {
        DB::table('user_login_logs')->insert([
            'user_id'    => 0,        
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 1, // failed
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'User not found.'
      ]);
      return back()->withInput();
    }

    if ($user->staff_status == 1) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is inactive. Please contact the administrator.'
      ]);
      return back()->withInput();
    } elseif ($user->staff_status == 2) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'This user is deactivated. Please contact the administrator.'
      ]);
      return back()->withInput();
    }
    if ($user->name !== $request->name) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Username is case-sensitive. Please enter the correct case.'
      ]);
      return back()->withInput();
    }

    if (!Hash::check($request->password, $user->password)) {

      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Invalid credentials'
      ]);
      return back()->withInput();
    }

    Auth::login($user, $remember);
    
    session(['user_id' => $user->id]);
    
    // ✅ Log login info to user_login_logs
        DB::table('user_login_logs')->insert([
            'user_id'    => $user->id,
            'login_at'   => Carbon::now('Asia/Kolkata'),
            'ip_address' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
            'user_name'  => $request->name,
            'password'   => $request->password,
            'type'       => 0, // success
            'created_at' => Carbon::now('Asia/Kolkata'),
            'updated_at' => Carbon::now('Asia/Kolkata'),
        ]);
    $staff = StaffModel::where('sno', $user->user_id)->first();
    // Carbon::parse($staff->updated_at)->timezone('Asia/Kolkata')->format('Y-m-d h:i A');
    // $staff->save();
    if ($staff) {
        $staff->updated_at = Carbon::now('Asia/Kolkata');
        $staff->save();
    }
    $permissions = UserRolePermissionModel::where('role_id', $user->role_id)->where('status', 0)->first();

    // dd($permissions);
    // Assuming you have a method in the User model to check role permissions
    if (!$permissions) {
      // Redirect to the role_permission_error page if the user doesn't have the role
      return redirect()->route('role_permission_error');
    }
    // Create a personal access token
    $token = $user->createToken('auth_token')->plainTextToken;

    // Set the cookie with the token, valid for 1 day
    // Cookie::queue('auth_token', $token, 1440);

    session()->flash('toastr', [
      'type' => 'success',
      'message' => 'Logged in Successfully!'
    ]);

    if ($request->expectsJson()) {
      return response()->json([
        'status' => 200,
        'message' => 'Logged in Successfully',
        'data' => [
          'redirect_url' => route('dashboard'),
          'token' => $token,
        ]
      ]);
    } else {
      return redirect()->route('dashboard');  // Ensure correct route name
    }
  }

  public function destroy(Request $request)
  {
      
      // Get the current authenticated user
    $user = Auth::user();

    if ($user) {
        // Update the latest login log with logout time
        DB::table('user_login_logs')
            ->where('user_id', $user->id)
            ->whereNull('logout_at') // Ensure we only update the last active session
            ->latest('login_at')
            ->limit(1)
            ->update([
                'logout_at' => now(),
                'updated_at' => now()
            ]);
    }
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    $cookieName = config('session.cookie'); // Get the session cookie name from configuration
    \Cookie::queue(\Cookie::forget($cookieName));

    return redirect('/');
  }

  /**
   * Convert duration into Carbon interval and return timestamp or string
   */
  private function getDurationInterval($duration, $time)
  {
    // Create a fresh Carbon instance for each calculation
    $carbon = Carbon::now();

    switch ($duration) {
      case 'Hours':
        return new \DateInterval('PT' . $time . 'H');
      case 'Minutes':
        return new \DateInterval('PT' . $time . 'M');
      case 'Days':
        return new \DateInterval('P' . $time . 'D');
      case 'Months':
        return new \DateInterval('P' . $time . 'M');
      case 'Years':
        return new \DateInterval('P' . $time . 'Y');
      default:
        return new \DateInterval('PT0S');
    }
  }

  

    public function switchToErp(Request $request)
    {

    
        $user_id = $request->user()->user_id;

        $staff = StaffModel::find($user_id);
         
        if (!$staff) {
            session()->flash('toastr', [
              'type' => 'error',
              'message' => 'Staff Not Found'
          ]);
          return back()->withInput();
        }
        $staff->entity_id = $request->switch_entity_id;
        $entity = ManageEntityModel::find($staff->entity_id);

        if (!$entity) {
            abort(404, "ERP Entity not found");
        }

      
        $apiCheck = $this->verifyCredential(
            $entity->entity_base_url,
            $staff->user_name,
            $staff->password,
            'egcsecret2030datagetapierp'
        );
        // return $apiCheck;
         $apiResponse = $apiCheck->getData();

        if ($apiResponse->status !== 'success') {
            session()->flash('toastr', [
                'type' => 'error',
                'message' => $apiResponse->message ?? 'Unauthorized user'
            ]);
            return back()->withInput();
        }

        

       

        $erpBaseUrl = rtrim($entity->entity_base_url, '/');
        $erpRouteName = "erp{$entity->sno}.sso.login";

        // encrypted payload instead of sending password
        $encryptedPayload = Crypt::encrypt([
            'email' => $staff->email_id,
            'user_name' => $staff->user_name,
            'user_id' => $staff->sno,
            'secret_token' => 'egcswitchportal2027',
            'timestamp' => now()->timestamp
        ]);

        // signed URL verifies authenticity
        $signedUrl = URL::temporarySignedRoute(
            $erpRouteName,
            now()->addMinutes(5),
            ['data' => $encryptedPayload]
        );

        return redirect("$erpBaseUrl/auto-login?token=" . urlencode($signedUrl));
    }


    public function verify(Request $request)
    {
        if (!$request->hasValidSignature()) {
            abort(401, "Invalid or expired SSO URL");
        }

        $data = Crypt::decrypt($request->data);

        return response()->json([
            "message" => "Signature Verified",
            "data" => $data
        ]);
    }

    private function verifyCredential($base_url, $username, $password, $verify_key)
    {
        $api_url = rtrim($base_url, '/') . '/api/erp_user_credential_check';

        try {
            $response = Http::get($api_url, [
                'name'     => $username,
                'password' => $password,
                'auth_key' => $verify_key
            ]);

            $json = $response->json();

          // return $json;

            if ($response->failed()) {
                return response()->json([
                    'status'  => 'error',
                    'message' => 'Remote ERP returned an error.',
                    'error'   => $json
                ]);
            }

            return response()->json([
                'status'  => $json['type'] === 'Success' ? 'success' : 'error',
                'message' => $json['message'] ?? 'Unknown response',
                'data'    => $json['data'] ?? []
            ]);

        } catch (\Throwable $e) {
            return response()->json([
                'status'  => 'error',
                'message' => 'API call failed.',
                'error'   => $e->getMessage(),
            ]);
        }
    }

   
}
