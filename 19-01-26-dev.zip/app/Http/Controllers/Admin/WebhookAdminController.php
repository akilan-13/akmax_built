<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Events\WebhookDispatchedEvent;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Http\Request;

class WebhookAdminController extends Controller
{
    public function index(Request $request)
    {
         $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $webhooks = WebhookDispatchModel::with('attemptLogs')
            ->orderBy('created_at', 'desc')
            ->paginate($perpage);
       
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $webhooks->map(function ($item) use ($helper) {
               
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'url' => $item->webhook->url ?? 'N/A',
                    'attempts' => $item->attempts,
                    'last_response' => $item->last_response,
                    'attempt_logs' => $item->attempt_logs,
                    'last_attempt_at' => $item->last_attempt_at,
                    'next_attempt_at' => $item->next_attempt_at,
                    'data' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $webhooks->currentPage(),
                'last_page' => $webhooks->lastPage(),
                'total' => $webhooks->total(),
            ]);
        }

        return view('content.admin.webhooks.webhooks_list', [
            'webhooks' => $webhooks,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
        ]);
    }

    public function retry($id)
    {
        $dispatch = WebhookDispatchModel::findOrFail($id);

        if ($dispatch->status !== 2) {
            SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            $dispatch->update(['status' => 1]); 
            broadcast(new WebhookDispatchedEvent($dispatch));
        }

        if (request()->ajax()) {
            return response()->json(['success' => true]);
        }

        return redirect()->back()->with('success', 'Webhook retried successfully.');
    }

    function webhooksLog(Request $request){

        $id =$request->dispatch_sno;
        // $id =2;
        $dispatch =WebhookDispatchModel::where('egc_webhook_dispatches.sno',$id)
        ->select(
            'egc_webhook_dispatches.http_status',
            'egc_webhook_dispatches.status',
            'egc_sub_erp_webhooks.webhook_module',
            'egc_sub_erp_webhooks.url',
            'egc_sub_erp_webhooks.url',
            'egc_entity.entity_name',
            'egc_entity.entity_base_color',
            'egc_entity.entity_short_name',
            'egc_company.company_name',
            'egc_company.company_base_color',
            )
        ->join('egc_sub_erp_webhooks', 'egc_webhook_dispatches.sub_erp_webhook_sno', 'egc_sub_erp_webhooks.sno')
        ->join('egc_company', 'egc_sub_erp_webhooks.company_id', 'egc_company.sno')
        ->join('egc_entity', 'egc_sub_erp_webhooks.entity_id', 'egc_entity.sno')
        ->first();

        $attempts = WebhookDispatchAttemptModel::where('webhook_dispatch_sno',$id)->get();
        $dispatch->attempt_logs=$attempts;

         return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $dispatch
        ], 200);
        

    }
}
