<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\UserRoleExport;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use Maatwebsite\Excel\Facades\Excel;

class UserRole extends Controller
{

  public function index()
  {
      $userRole = UserRoleModel::where('egc_user_role.status', '!=', 2)
        ->leftJoin('egc_user_role as parent_role', 'egc_user_role.user_role_id', '=', 'parent_role.sno')
        ->select(
          'egc_user_role.sno',
          'egc_user_role.role_id',
          'egc_user_role.role_name',
          'egc_user_role.map_under',
          'egc_user_role.user_role_id',
          'egc_user_role.status',
          'parent_role.role_name as parent_role_name'
        )
        ->where('egc_user_role.company_type',1)
        ->orderBy('egc_user_role.sno', 'desc')
        ->get();
      $pageConfigs = ['myLayout' => 'default'];
      return view('content.control_panel.user_management.user_role.user_role_list', compact('userRole', 'pageConfigs'));
      // return view('content.user_management.user_role.list');
  }


  public function ExportExcel()
  {
    return Excel::download(new UserRoleExport, 'user-role-export.xlsx'); // Adjust filename and extension as needed
  }
  public function List()
  {
    $user = UserRoleModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

   public function ListByEntity(Request $request)
  {
      $entity_id=$request->entity_id;
    $user = UserRoleModel::where('status', 0)->where('entity_id',$entity_id)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'role_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->role_name;
      $map_under = $request->has('map_under') ? 1 : 0;
      $user_role_id       = $request->user_role_id;
      // $user_id            = $request->user()->id;
      $entity_id            = 0;
      $user_id            = $request->user()->user_id;
      $chk = UserRoleModel::where('role_name', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = UserRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $role_id = "UR-0001/" . $year;
        } else {

          $data = $category_check->role_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("UR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $role_id = $request . '/' . $year;
        }


        $add_user = new UserRoleModel();
        $add_user->role_id           = $role_id;
        $add_user->role_name         = Ucfirst($role_name);
        $add_user->map_under         = $map_under;
        $add_user->user_role_id      = $user_role_id;
        $add_user->created_by        = $user_id;
        $add_user->updated_by        = $user_id;

        $add_user->save();

        if ($add_user) {
            // Flash a success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'User Role added Successfully!'
            ]);
        
            // Store role_id and current time in the session
            session([
                'role_id' => $add_user->sno,
                'role_id_segc_time' => now(),
            ]);
        
            // Redirect to the users manage add page
            return redirect()->back();
        } else {
            // Flash an error message
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the User Role!'
            ]);
        
            // Redirect back to the previous page
            return redirect()->back();
        }

      }
      
    }
  }

  public function Edit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }



public function Update($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'role_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $role_name    = $request->role_name;
    $map_under    = $request->map_under;
    $user_role_id = $request->user_role_id;

    $upd_user = UserRoleModel::where('sno', $id)->first();

    if (!$upd_user) {
        return response()->json([
            'status'    => 404,
            'message'   => 'User role not found',
            'error_msg' => null,
            'data'      => null,
        ], 404);
    }

    $chk = UserRoleModel::where('role_name', ucwords($role_name))
                        ->where('status', '!=', 2)
                        ->first();

    if ($chk && $chk->sno != $id) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been assigned!',
            'data'      => null,
        ], 200);
    }

    $upd_user->role_name    = ucwords($role_name);
    $upd_user->map_under    = $map_under;
    $upd_user->user_role_id = $user_role_id;
    
    if ($upd_user->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 500,
            'message'   => 'Failed to update user role',
            'error_msg' => 'Something went wrong, please try again',
            'data'      => null,
        ], 500);
    }
}

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


  public function businessIndex()
  {
      $userRole = UserRoleModel::where('egc_user_role.status', '!=', 2)
        ->leftJoin('egc_user_role as parent_role', 'egc_user_role.user_role_id', '=', 'parent_role.sno')
        ->select(
          'egc_user_role.sno',
          'egc_user_role.role_id',
          'egc_user_role.erp_role_id',
          'egc_entity.entity_name',
          'egc_entity.entity_short_name',
          'egc_company.company_name',
          'egc_company.company_base_color',
          'egc_user_role.role_name',
          'egc_user_role.map_under',
          'egc_user_role.user_role_id',
          'egc_user_role.status',
          'parent_role.role_name as parent_role_name'
        )
        ->join('egc_company', 'egc_user_role.company_id', 'egc_company.sno')
        ->join('egc_entity', 'egc_user_role.entity_id', 'egc_entity.sno')
        ->where('egc_user_role.company_type',2)
        ->orderBy('egc_user_role.sno', 'desc')
        ->get();
      $pageConfigs = ['myLayout' => 'default'];
      $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.control_panel.user_management.user_role.business_user_role', compact('userRole','company_list', 'pageConfigs'));
      // return view('content.user_management.user_role.list');
  }


  public function businessList()
  {
    $user = UserRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

 public function businessAdd(Request $request)
{
    // 🧩 Step 1: Validate input
    $validator = Validator::make($request->all(), [
        'company_id' => 'required|integer',
        'entity_id'  => 'required|integer'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $company_id = $request->company_id;
    $entity_id  = $request->entity_id;

    // 🧩 Step 2: Get entity base URL
    $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

    if (!$entity_url) {
        return response()->json([
            'status'  => 404,
            'message' => 'Entity URL not found for the given entity ID.',
        ], 200);
    }

    // 🧩 Step 3: Call external API using Http facade
    $verify_key = 'egcsecret2030datagetapierp';
    $api_url = rtrim($entity_url, '/') . '/api/get_user_role_egc';

    try {
        $response = Http::get($api_url, ['auth_key' => $verify_key]);

        if (!$response->successful()) {
            return response()->json([
                'status'  => 500,
                'message' => 'Failed to fetch user roles from entity API.',
                'error'   => $response->body(),
            ], 200);
        }

        $userRoleData = $response->json()['data'] ?? [];

        if (empty($userRoleData)) {
            return response()->json([
                'status'  => 404,
                'message' => 'No user roles found in API response.',
            ], 200);
        }

        // 🧩 Step 4: Loop and insert roles
        foreach ($userRoleData as $userRole) {
            $role_name = ucfirst($userRole['role_name'] ?? null);
            if (!$role_name) continue;

            $company_type = 2;
            $map_under = 0;
            $erp_role_id = $userRole['sno'] ?? 0;
            $erp_under_role_id = $userRole['user_role_id'] ?? 0;
            $user_id = $request->user()->user_id ?? null;

            // 🔍 Check if role already exists
            $chk = UserRoleModel::where('role_name', $role_name)
                ->where('entity_id', $entity_id)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) continue; // skip duplicates

            // 🧩 Step 5: Generate next role_id
            $last = UserRoleModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();

            if (!$last) {
                $year = substr(date("y"), -2);
                $role_id = "UR-0001/{$year}";
            } else {
                $data = $last->role_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $prefix = sprintf("UR-%04d", $next_number);
                $year = substr(date("y"), -2);
                $role_id = "{$prefix}/{$year}";
            }

            // 🧩 Step 6: Save to DB
            $add_user = new UserRoleModel();
            $add_user->role_id          = $role_id;
            $add_user->company_type     = $company_type;
            $add_user->company_id       = $company_id;
            $add_user->entity_id        = $entity_id;
            $add_user->erp_role_id      = $erp_role_id;
            $add_user->erp_under_role_id = $erp_under_role_id;
            $add_user->role_name        = $role_name;
            $add_user->map_under        = $map_under;
            $add_user->user_role_id     = 0;
            $add_user->created_by       = 1;
            $add_user->updated_by       = 1;
            $add_user->save();
        }

        return response()->json([
            'status'  => 200,
            'message' => 'Business roles imported successfully.',
        ]);

    } catch (\Throwable $e) {
        // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
        return response()->json([
            'status'  => 500,
            'message' => 'Something went wrong while fetching user roles.',
            'error'   => $e->getMessage(),
        ], 200);
    }
}


  public function businessEdit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }



public function businessUpdate($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'role_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $role_name    = $request->role_name;
    $map_under    = $request->map_under;
    $user_role_id = $request->user_role_id;

    $upd_user = UserRoleModel::where('sno', $id)->first();

    if (!$upd_user) {
        return response()->json([
            'status'    => 404,
            'message'   => 'User role not found',
            'error_msg' => null,
            'data'      => null,
        ], 404);
    }

    $chk = UserRoleModel::where('role_name', ucwords($role_name))
                        ->where('status', '!=', 2)
                        ->first();

    if ($chk && $chk->sno != $id) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been assigned!',
            'data'      => null,
        ], 200);
    }

    $upd_user->role_name    = ucwords($role_name);
    $upd_user->map_under    = $map_under;
    $upd_user->user_role_id = $user_role_id;
    
    if ($upd_user->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 500,
            'message'   => 'Failed to update user role',
            'error_msg' => 'Something went wrong, please try again',
            'data'      => null,
        ], 500);
    }
}

  public function businessDelete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function businessStatus($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

    public function AddOldData(Request $request)
    {

      // return $request;
      // Validate incoming request
      $helper = new \App\Helpers\Helpers();
      $validator = Validator::make($request->all(), [
        'staff_company_name' => 'required',
        'staff_entity_name' => 'required',
      ]);

      if ($validator->fails()) {
        return response()->json([
          'status' => 401,
          'message' => 'Incorrect format input fields',
          'error_msg' => $validator->errors()->all(),
          'data' => null,
        ], 200);
      }

      $user_id = $request->user()->user_id ?? 1;
      
      $company_type=2;
      $company_id=$request->staff_company_name;
      $entity_id=$request->staff_entity_name;

      $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

        if (!$entity_url) {
            return response()->json([
                'status'  => 404,
                'message' => 'Entity URL not found for the given entity ID.',
            ], 200);
        }

        // 🧩 Step 3: Call external API using Http facade
        $verify_key = 'egcsecret2030datagetapierp';
        $api_url = rtrim($entity_url, '/') . '/api/get_user_role_egc';

        try {
            $response = Http::get($api_url, ['auth_key' => $verify_key]);

            if (!$response->successful()) {
                return response()->json([
                    'status'  => 500,
                    'message' => 'Failed to fetch Data from entity API.',
                    'error'   => $response->body(),
                ], 200);
            }

            $ErpData = $response->json()['data'] ?? [];
            $filteredErpData = array_filter($ErpData, function($staff) {
                return $staff['external_uuid'] == null;
            });
            $filteredErpData = array_values($filteredErpData);

       


            if (empty($ErpData)) {
                return response()->json([
                    'status'  => 404,
                    'message' => 'No user roles found in API response.',
                ], 200);
            }

            foreach ($ErpData as $userRole) {
              $role_name = ucfirst($userRole['role_name'] ?? null);
              if (!$role_name) continue;

              $company_type = 2;
              $map_under = 0;
              $erp_role_id = $userRole['sno'] ?? 0;
              $erp_under_role_id = $userRole['user_role_id'] ?? 0;
              $map_under = $userRole['map_under'] ?? 0;
              $user_id = $request->user()->user_id ?? null;
              $user_role_id =0;
              if($map_under == 1){
                $user_role_id = $helper->get_sno_by_erpId($erp_under_role_id, 'egc_user_role', 'erp_role_id',$entity_id);
                $user_role_id = $user_role_id ?? 0;
              }
              

              // 🔍 Check if role already exists
              $chk = UserRoleModel::where('erp_role_id', $erp_role_id)
                  ->where('entity_id', $entity_id)
                  ->where('status', '!=', 2)
                  ->first();

              if ($chk){
                  $user_role_id = $helper->get_sno_by_erpId($chk->erp_under_role_id, 'egc_user_role', 'erp_role_id',$entity_id);
                  $user_role_id = $user_role_id ?? 0;
                  $chk->role_name=$role_name;
                  $chk->erp_role_id=$erp_role_id;
                  $chk->user_role_id=$user_role_id;
                  $chk->erp_under_role_id=$erp_under_role_id;
                  $chk->update();
                  $this->dispatchWebhooks($chk, $user_id=1,'Update_UserRole_uuid');
                  continue; 
              }else{
                  
                // 🧩 Step 5: Generate next role_id
                $last = UserRoleModel::where('status', '!=', 2)
                    ->orderBy('sno', 'desc')
                    ->first();

                if (!$last) {
                    $year = substr(date("y"), -2);
                    $role_id = "UR-0001/{$year}";
                } else {
                    $data = $last->role_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int)$result + 1;
                    $prefix = sprintf("UR-%04d", $next_number);
                    $year = substr(date("y"), -2);
                    $role_id = "{$prefix}/{$year}";
                }

                // 🧩 Step 6: Save to DB
                $add_user = new UserRoleModel();
                $add_user->role_id          = $role_id;
                $add_user->company_type     = $company_type;
                $add_user->company_id       = $company_id;
                $add_user->entity_id        = $entity_id;
                $add_user->erp_role_id      = $erp_role_id;
                $add_user->erp_under_role_id = $erp_under_role_id;
                $add_user->role_name        = $role_name;
                $add_user->map_under        = $map_under;
                $add_user->user_role_id     = 0;
                $add_user->created_by       = 1;
                $add_user->updated_by       = 1;
                $add_user->save();
                if($add_user){
                  $this->dispatchWebhooks($add_user, $user_id=1,'Update_UserRole_uuid');
                }
              }


            }


            return response()->json([
                'status'  => 200,
                'message' => 'Business Job Role imported successfully.',
            ]);

        } catch (\Throwable $e) {
            // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
            return response()->json([
                'status'  => 500,
                'message' => 'Something went wrong while fetching Job Role.',
                'error'   => $e->getMessage(),
            ], 200);
        }
    }

    protected function sendWebhookNow($dispatch, $hook)
    {
        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => true];
            } else {
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch));
                return ['success' => false];
            }
        } catch (\Throwable $e) {
            \Log::error("Immediate webhook send failed: " . $e->getMessage());
            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return ['success' => false];
        }
    }

     protected function dispatchWebhooks(UserRoleModel $broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',$broadcast->entity_id)->first();
        if($webhook){
            $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => get_class($broadcast),
              'dispatchable_id' => $broadcast->sno,
              'message_uuid' => $broadcast->sno,
              'payload' => $broadcast->toArray(),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

           // broadcast creation once
            broadcast(new WebhookDispatchedEvent($dispatch));

          // enqueue the job
         try {
              $result = $this->sendWebhookNow($dispatch, $webhook);
                \Log::info("send result : " . json_encode($result));

                if (!$result['success']) {
                    // If fails, dispatch to queue
                    SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                }
            } catch (\Throwable $e) {
                // On any exception, fallback to queue
                SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
                \Log::error("Webhook fallback to queue: " . $e->getMessage());
            }
        }
          
  }
  

}
