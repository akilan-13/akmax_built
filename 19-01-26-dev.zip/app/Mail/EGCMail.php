<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class EGCMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    /**
     * The mail data array.
     *
     * @var array
     */
    public $mailData;

    /**
     * The dynamic "From" address.
     *
     * @var string|null
     */
    public $fromAddress;

    public $fromName;

   public $documentPath;

    public function __construct($mailData, $fromAddress, $fromName,$documentPath = null)
    {
        $this->mailData    = $mailData;
        $this->fromAddress = $fromAddress;
        $this->fromName    = $fromName;
        $this->documentPath = $documentPath; // Assign document path


    }

    public function build()
    {
        // $template = EmailTemplate::where('status', 0)
        //     ->first();
        // return $this->subject('Your Member Registration for EPC is Approved')

        $email = $this->from($this->fromAddress, $this->fromName)
        ->replyTo($this->mailData['branchemail'])
        ->subject($this->mailData['subject'])
        ->view('emails.emailTemplate')
        ->with([
            'content'     => $this->mailData['content'],
            'branchNo'    => $this->mailData['branchNo'],
            'branchemail' => $this->mailData['branchemail'],
            'instaLink'   => $this->mailData['instaLink'],
            'fbLink'      => $this->mailData['fbLink'],
            'salesMobile' => $this->mailData['salesMobile'],
        ]);

        if ($this->documentPath) {
            $email->attach($this->documentPath);
        }
            return $email;
    }
}