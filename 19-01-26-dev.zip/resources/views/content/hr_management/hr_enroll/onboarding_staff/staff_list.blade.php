@extends('layouts/layoutMaster')

@section('title', 'Manage Onboarding')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<style>
   .circular-progress {
    --progress: 50;
    --deg: calc((var(--progress) / 100) * 360deg);
    width: 60px;
    height: 60px;
    border-radius: 50%;
    position: relative;
    margin: 1em auto;
    background: conic-gradient(#E0E0E0 var(--deg), #E0E0E0 0deg);
    box-shadow: 0 2px 5px rgba(0,0,0,0.16), 0 2px 10px rgba(0,0,0,0.12);
    transition: all .4s linear;
}

.circular-progress::before {
    content: attr(data-progress) '%';
    position: absolute;
    inset: 0;
    margin: auto;
    width: 85%;
    height: 85%;
    background: var(--inner-color, #ab2b22);
    border-radius: 50%;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.95);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    box-shadow: inset 0 2px 5px rgba(0,0,0,0.2);
    transition: background 0.4s ease;
}

    .table-responsive {
        overflow-x: auto;
        position: relative;
    }

    .table thead th,
    .table tbody td {
        white-space: nowrap;
    }

    .sticky-col {
        position: sticky;
        z-index: 5;
    }

    .left-col {
        left: 0;
        z-index: 10;
        box-shadow: 3px 0 5px -2px rgba(0,0,0,0.1);
    }

    .right-col {
        right: 0;
        z-index: 10;
        box-shadow: -3px 0 5px -2px rgba(0,0,0,0.1);
    }

        /* Optional: Adjust scrollbar appearance */
    .table-responsive::-webkit-scrollbar {
        height: 8px;
    }
    .table-responsive::-webkit-scrollbar-thumb {
        background-color: #bdbdbd;
        border-radius: 10px;
    }

</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Manage Onboarding</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Enroll
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between gap-2">
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input class="searchQueryInput" type="text" name="searchQueryInput" placeholder="Enter Staff Name/ Mobile No" value="" oninput="toggleIcons(this)" />
                            <a href="{{url('/hr_enroll/manage_onboarding')}}" class="searchQuerySubmit searchIcon">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22"
                                        d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                        C16,11.11 15.41,12.59 14.44,13.73
                                        L14.71,14H15.5L20.5,19L19,20.5
                                        L14,15.5V14.71L13.73,14.44
                                        C12.59,15.41 11.11,16
                                        9.5,16A6.5,6.5 0 0,1 3,9.5
                                        A6.5,6.5 0 0,1 9.5,3
                                        M9.5,5C7,5 5,7 5,9.5
                                        C5,12 7,14 9.5,14
                                        C12,14 14,12 14,9.5
                                        C14,7 12,5 9.5,5Z"/>
                                </svg>
                            </a>
                            <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22"
                                        d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                        A8,8 0 0,0 4,12H1L4.89,16.89
                                        L9,12H6A6,6 0 0,1 12,6
                                        C13.66,6 15.14,6.69 16.22,7.78
                                        L17.65,6.35M19.11,7.11L15,12
                                        H18A6,6 0 0,1 12,18
                                        C10.34,18 8.86,17.31 7.78,16.22
                                        L6.35,17.65C7.8,19.1 9.79,20
                                        12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive position-relative" style="overflow-x:auto;">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead class="bg-primary text-white">
                            <tr class="text-start align-top fw-bold fs-6 gs-0">
                                <th class="sticky-col left-col bg-primary text-white min-w-200px">Staff</th>
                                <th class="min-w-150px text-center">Staging 1</th>
                                <th class="min-w-150px text-center">Staging 2</th>
                                <th class="min-w-150px text-center">Staging 3</th>
                                <th class="min-w-150px text-center">Staging 4</th>
                                <th class="min-w-150px text-center">Staging 5</th>
                                <th class="min-w-150px text-center">Staging 6</th>
                                <th class="min-w-150px text-center">Staging 7</th>
                                <th class="sticky-col right-col bg-primary text-white min-w-150px">Completion %</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            <tr class="bg-label-danger">
                                <td class="sticky-col left-col bg-label-danger">
                                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:#099DDA;"></div>
                                    <div class="d-flex align-items-center ">
                                        <div class="symbol symbol-35px me-2">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-px-50 h-auto rounded-circle" />
                                        </div>
                                        <div>
                                            <label>
                                                <span class="fs-7 me-1 text-black">Mahesh Kumar</span>
                                                <i class="mdi mdi-face-man text-info" title="Male"></i>
                                            </label>
                                            <div class="text-primary fs-8">Karthik</div>
                                        </div>
                                    </div>
                                    <div class="d-block">
                                        <label class="fw-semibold fs-7 text-black">HR Executive</label>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-success border-4">
                                                <i class="mdi mdi-sticker-emoji fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 38%;" aria-valuenow="38" aria-valuemin="0" aria-valuemax="38"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">38%</span>
                                        </div>
                                        <label class="fw-semibold text-primary small">18-Oct-2025</label>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-success border-4">
                                                <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 38%;" aria-valuenow="38" aria-valuemin="0" aria-valuemax="38"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">38%</span>
                                        </div>
                                        <label class="fw-semibold text-primary small">18-Oct-2025</label>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-warning border-4">
                                                <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                                <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 67%;" aria-valuenow="67" aria-valuemin="0" aria-valuemax="67"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">67%</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-warning border-4">
                                                <i class="mdi mdi-emoticon-cry-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 67%;" aria-valuenow="67" aria-valuemin="0" aria-valuemax="67"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">67%</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-warning border-4">
                                                <i class="mdi mdi-emoticon-frown-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                            <div class="progress-bar bg-primary " role="progressbar" style="width: 84%;" aria-valuenow="84" aria-valuemin="0" aria-valuemax="84"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">84%</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-dark border-4">
                                                <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="0"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">0%</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center align-middle">
                                    <div class="d-flex flex-column align-items-center gap-1">
                                        <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                            <div class="rounded-circle p-2 border border-dark border-4">
                                                <i class="mdi mdi-emoticon-angry-outline fs-1 text-black"></i>
                                            </div>
                                        </label>
                                        <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                            <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                                <div class="progress-bar bg-primary " role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="0"></div>
                                            </div>
                                            <span class="fw-semibold text-black small">0%</span>
                                        </div>
                                    </div>
                                </td>
                                <td class="sticky-col right-col bg-label-danger">
                                    <div class="circular-progress" data-progress="57"></div>
                                </td>
                            </tr>
                            <tr class="bg-label-success">
                                <td class="sticky-col left-col bg-label-success" >
                                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:#FAB845;"></div>
                                    <div class="d-flex align-items-center ">
                                        <div class="symbol symbol-35px me-2">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-px-50 h-auto rounded-circle" />
                                        </div>
                                        <div>
                                            <label>
                                                <span class="fs-7 me-1 text-black">Raj Kumar</span>
                                                <i class="mdi mdi-face-man text-info" title="Male"></i>
                                            </label>
                                            <div class="text-primary fs-8">Raj</div>
                                        </div>
                                    </div>
                                    <div class="d-block">
                                        <label class="fw-semibold fs-7 text-black">HR Head</label>
                                    </div>
                                </td>
                              <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-success border-4">
                                      <i class="mdi mdi-sticker-emoji fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 38%;" aria-valuenow="38" aria-valuemin="0" aria-valuemax="38"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">38%</span>
                                  </div>
                                  <label class="fw-semibold text-primary small">18-Oct-2025</label>
                                </div>
                              </td>

                                <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-success border-4">
                                      <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 38%;" aria-valuenow="38" aria-valuemin="0" aria-valuemax="38"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">38%</span>
                                  </div>
                                  <label class="fw-semibold text-primary small">18-Oct-2025</label>
                                </div>
                              </td>

                                <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-warning border-4">
                                        <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 67%;" aria-valuenow="67" aria-valuemin="0" aria-valuemax="67"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">67%</span>
                                  </div>

                                </div>
                              </td>
                               <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-warning border-4">
                                      <i class="mdi mdi-emoticon-cry-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 67%;" aria-valuenow="67" aria-valuemin="0" aria-valuemax="67"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">67%</span>
                                  </div>

                                </div>
                              </td>
                               <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-warning border-4">
                                      <i class="mdi mdi-emoticon-frown-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 84%;" aria-valuenow="84" aria-valuemin="0" aria-valuemax="84"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">84%</span>
                                  </div>

                                </div>
                              </td>
                                <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-dark border-4">
                                      <i class="mdi mdi-emoticon-dead-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="0"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">0%</span>
                                  </div>

                                </div>
                              </td>
                               <td class="text-center align-middle">
                                <div class="d-flex flex-column align-items-center gap-1">
                                  <label class="cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
                                    <div class="rounded-circle p-2 border border-dark border-4">
                                      <i class="mdi mdi-emoticon-angry-outline fs-1 text-black"></i>
                                    </div>
                                  </label>
                                  <div class="d-flex align-items-center gap-2" style="max-width: 100px; width: 100%;">
                                    <div class="progress bg-label-primary rounded flex-grow-1 border border-primary" style="height: 12px;">
                                      <div class="progress-bar bg-primary " role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="0"></div>
                                    </div>
                                    <span class="fw-semibold text-black small">0%</span>
                                  </div>

                                </div>
                              </td>
                                <td class="sticky-col right-col bg-label-success">
                                    <div class="circular-progress" data-progress="99"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#contact_info" aria-controls="contact_info" aria-selected="false">
                                    Contact Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#work_info" aria-controls="work_info" aria-selected="false">
                                    Work Type
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_info" aria-controls="edu_info" aria-selected="false">
                                    Education Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Application" aria-controls="Application" aria-selected="false">
                                    Application Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#StaffCheckList" aria-controls="StaffCheckList" aria-selected="false">
                                    Staff Checklist
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Orientation" aria-controls="Orientation" aria-selected="false">
                                    Orientation
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Birth</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">09-Jan-2001</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Gender</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Male</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Saravanen</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Bank Manager</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Nila</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Tongue</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Languages Known</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Tamil , English</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Children</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Studying 5th Grade</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Siblings</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">No</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Hobby</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Drawing , Shooting ,Story Writing </label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-150 h-auto rounded-circle"
                                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                  <div class="row">

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Company Details</div>
                                    </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Details</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>


                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Operation</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>

                                  <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Designation Details</div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Nick</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-Oct-2025</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                     <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 100</label>
                                    </div>
                                  </div>
                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Leadership , Management , Postive</label>
                                    </div>
                                  </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Login Credentials</div>
                                    </div>


                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                    </div>
                                    </div>
                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                    </div>
                                    </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Other Credentials</div>
                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Teams Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">Firewall Credentials</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">nick123</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <a class="text-truncate max-w-150px" href="http://192.168.3.98:5080/hr_enroll/manage_staff/add_staff">-</a>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                      </div>

                                    </div>


                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sibi Kumar</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7485196785</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Residential Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">18I Gandhi Nagar Happy Street Madurai</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Permanent Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">122K K K Nagar D-block Madurai</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7584967821</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 1</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">7721869435</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number 2</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9978428965</label>
                                      </div>
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Experience</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Shifted Company Count</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">2</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Total Years Of Experience</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-primary text-white px-3 fs-7">3</span>
                                        </label>
                                      </div>
                                    </div>

                                    <h5 class="title fw-bold mt-2 text-warning">1st Company</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-primary text-white px-3 fs-7">1</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">TCS</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 20,000 /-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">01-Oct-2021</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">18-Jul-2022</label>
                                      </div>
                                    </div>



                                    <h5 class="title fw-bold mt-2 text-warning">2nd Company</h5>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Developer</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-primary text-white px-3 fs-7">2</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">CTS</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-danger">₹ 15,000 /-</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">27-Nov-2023</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-6">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12-Feb-2024</label>
                                      </div>
                                    </div>

                                    <div class="divider text-start-center">
                                      <div class="divider-text fs-5 text-primary fw-semibold my-2">Attachment Details</div>
                                    </div>

                                    <div class="col-lg-12 d-flex align-items-center justify-content-start gap-3 flex-wrap py-3 px-1">

                                      <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                        <label class=" fw-semibold fs-7 text-dark">Resume</label>
                                        <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                              style="width:100px; height:100px;" />
                                      </div>

                                      <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                        <label class=" fw-semibold fs-7 text-dark">Aadhar card</label>
                                        <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                              style="width:100px; height:100px;" />
                                      </div>

                                      <div class="d-flex flex-column gap-1 justify-content-center align-items-center">
                                        <label class=" fw-semibold fs-7 text-dark">Pan Card</label>
                                        <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                              style="width:100px; height:100px;" />
                                      </div>
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_info" role="tabpanel">
                            <div class="row mb-2">

                              <div class="col-lg-12">
                                  <div class="row mb-2">
                                        <label class="col-3 fw-semibold fs-7 text-dark">Course Completed</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes, Java , Python , C++ , C# , HTML , JS , CSS , REACT , SQL and Ruby</label>
                                    </div>
                                </div>


                                <div class="divider text-start-center">
                                  <div class="divider-text fs-5 text-primary fw-semibold my-2">Educational Details</div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning text-warning">UG</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Under Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6">
                                           <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">BBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">MKU</label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">PG</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Post Graduate</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 ">
                                           <span class="badge bg-label-danger text-danger fw-semibold fs-6 rounded">MBA</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance And Application</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">SRM</label>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="Application" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                  <div class="row">
                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Java , C# , .Net ,FullStack</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Non Technical Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sales Management , SEO Analyst</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Interview Attended Company</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                           <span class="badge bg-label-primary text-primary fw-semibold fs-6 rounded">EIBS</span>
                                        </label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Already Attended Interview In Elysium Groups</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Attended Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2024 , 04-11-2024 , 12-01-2025</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Submit Original Certificate</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Travel For Official Purpose</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Immediate Joining</label>
                                      </div>
                                    </div>

                                    <div class="col-lg-12">
                                      <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Joining Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">07-10-2025</label>
                                      </div>
                                    </div>


                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="StaffCheckList" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check1">
                                        <label class="fw-semibold fs-6 text-black" for="check1">Educational certificates verified (Degree, Diploma, Transcripts), experience/resume checked (previous employment verification)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check2" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check2">Identity proof verified (Aadhaar, Passport, Driving License), address proof verified (Ration Card, Utility Bill),</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check3" checked>
                                        <label class="fw-semibold fs-6 text-black" for="check3">Official documents submitted (Joining Letter, Form 16)</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check4"checked>
                                        <label class="fw-semibold fs-6 text-black" for="check4">and alternate contact/emergency details provided (alternate mobile number, emergency contact).</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check5">
                                        <label class="fw-semibold fs-6 text-black" for="check5">Verify identity proof, address proof, and educational certificates.</label>
                                    </div>
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item" type="checkbox" id="check6">
                                        <label class="fw-semibold fs-6 text-black" for="check6">Check previous experience/resume, submission of official documents, and provide alternate/emergency contact details.</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Orientation" role="tabpanel">
                            <div class="row mb-2">
                                <h5 class="title fw-bold mt-2 text-warning">Staff Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                              style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Company Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                  </div>

                                  <h5 class="title fw-bold mt-2 text-warning">Department Introduction</h5>

                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                  </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                          <img src="{{ asset('assets/egc_images/auth/document.svg') }}"
                                              style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

<!--begin::Modal onboarding checklist--->
<div class="modal fade" id="kt_modal_onboard_checklist" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <h3 class="text-black">Onboarding Checklist</h3>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                alt="user-avatar"  class="w-px-75 h-auto rounded-circle"
                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                        <label class="fs-6 fw-semibold text-black">9874587450</label>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-5 px-10 px-xl-20 bg-white">
                <div class="row mt-4">
                    <div class="col-lg-12 d-flex align-items-center justify-content-end mb-2">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" id="selectAll">
                            <label class="form-check-label fw-semibold" for="selectAll">
                                Select All
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div style="max-height: 300px; overflow-y: auto;">
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check1">
                                <label class="form-check-label" for="check1">Educational certificates verified (Degree, Diploma, Transcripts), experience/resume checked (previous employment verification)</label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check2">
                                <label class="form-check-label" for="check2">Identity proof verified (Aadhaar, Passport, Driving License), address proof verified (Ration Card, Utility Bill)</label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check3">
                                <label class="form-check-label" for="check3">Official documents submitted (Joining Letter, Form 16)</label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check4">
                                <label class="form-check-label" for="check4">Alternate contact/emergency details provided (alternate mobile number, emergency contact).</label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check5">
                                <label class="form-check-label" for="check5">Verify identity proof, address proof, and educational certificates.</label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input checklist-item" type="checkbox" id="check6">
                                <label class="form-check-label" for="check6">Check previous experience/resume, submission of official documents, and provide alternate/emergency contact details.</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <label class="fw-bold fs-6 mb-2 text-black">Metrics</label>
                        <div class="row">
                            <div class="col-lg-4">
                                <label class="text-black fs-6 fw-semibold">Culture Score<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Culture Score">
                            </div>
                            <div class="col-lg-4">
                                <label class="text-black fs-6 fw-semibold">Knowledge<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Knowledge">
                            </div>
                            <div class="col-lg-4">
                                <label class="text-black fs-6 fw-semibold">First Impression<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter First Impression">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center py-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Submit</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - onboarding checklist-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function () {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>

<script>
$(document).ready(function () {
    // When "Select All" is toggled
    $('#selectAll').on('change', function () {
        $('.checklist-item').prop('checked', this.checked);
        this.indeterminate = false; // reset any mixed state
    });

    // When any individual checkbox is toggled
    $('.checklist-item').on('change', function () {
        const total = $('.checklist-item').length;
        const checked = $('.checklist-item:checked').length;

        if (checked === total) {
            // All checked
            $('#selectAll').prop('checked', true).prop('checked', true);
        } else if (checked === 0) {
            // None checked
            $('#selectAll').prop('checked', false).prop('checked', false);
        } else {
            // Some checked → checked
            $('#selectAll').prop('checked', false).prop('checked', false);
        }
    });
});
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    document.querySelectorAll('.circular-progress').forEach(el => {
        const progress = parseInt(el.getAttribute('data-progress')) || 0;
        el.style.setProperty('--progress', progress);

        let fillColor, innerColor;

        if (progress === 100) {
            // ✅ Full Green
            fillColor = 'conic-gradient(#2ecc71 var(--deg), #a8e063 0deg)';
            innerColor = '#fff';
        } else if (progress === 0) {
            // ⚫ Gray
            fillColor = 'conic-gradient(#d6dfe2 var(--deg), #525252ff 0deg)';
            innerColor = '#fff';
        } else {
            // 🟠 Middle Progress
            fillColor = 'conic-gradient(#fba919 var(--deg), #E0E0E0 0deg)';
            innerColor = '#fff';
        }

        // Apply the colors dynamically
        el.style.background = fillColor;
        el.style.setProperty('--inner-color', innerColor);
    });
</script>




@endsection