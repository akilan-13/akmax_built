@extends('layouts/layoutMaster')

@section('title', 'Manage Exit Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
    .avatar-stack {
        display: flex;
        align-items: center;
    }

    .avatar-img {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        border: 2px solid #ab2b22;
        margin-left: -12px; /* overlap */
        box-shadow: 0 4px 8px rgba(0,0,0,0.2); /* 3D shadow */
        transform: perspective(500px) rotateY(-10deg); /* slight 3D tilt */
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .avatar-img:first-child {
        margin-left: 0; /* prevent first from shifting */
    }

    .avatar-img:nth-child(2) {
        z-index: 3; /* center one always on top */
    }

    .avatar-img:hover {
        transform: perspective(500px) rotateY(0deg) scale(1.1);
        box-shadow: 0 6px 12px rgba(0,0,0,0.3);
        z-index: 2; /* bring hovered one on top */
    }

</style>
@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 mb-0">
        <ul class="nav nav-tabs border-bottom-0" role="tablist">
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/manage_staff') }}"
                    type="button"
                    class="nav-link"
                    role="tab">
                    Staff
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/exit_staff') }}"
                    type="button"
                    class="nav-link active"
                    role="tab">
                    Exit Staff
                </a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Manage Exit Staff</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management 
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Enroll
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                    <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>
            </div>
        </div>
         <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
            
            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;"  class="filterSubmit" id="filterSubmit" >
                    <span class="btn btn-primary btn-sm" > Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
            <div class="col-lg-12">
                <div class="table-responsived">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-100px">Company / Entity</th>
                                <th class="min-w-100px">Dept /Div /<br>Job Role</th>
                                <th class="min-w-100px">Date Of Joining</th>
                                <th class="min-w-100px">Exit Status</th>
                                <th class="min-w-100px">Reason</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->


<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick=" deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_id" name="sts_change_id"/>
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#company_info" aria-controls="company_info" aria-selected="false">
                                    Company Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#designation_info" aria-controls="designation_info" aria-selected="false">
                                    Designation Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_work_info" aria-controls="edu_work_info" aria-selected="false">
                                    Education and Work Info
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Mahesh Kumar</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Nick Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthik</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mobile No</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9874587450</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile No</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9898745120</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Dhana Balan P</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">9685859641</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Address</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12/A, First Floor,block C, Park Avenue, Cross Street, Vanathi Street, Narayanapuram, Madurai - 625014</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar"  class="w-px-150 h-auto rounded-circle"
                                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="fw-semibold text-dark fs-6">Documents</label>
                                    <div class="d-flex align-items-center justify-content-start flex-wrap border border-gray-300 gap-3 py-2 rounded">
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                        <img src="{{ asset('assets/egc_images/default_doc.png') }}"
                                                alt="user-avatar"  class="w-px-50 h-auto rounded border border-gray-800"
                                                id="uploadedlogo" />
                                    </div>
                                </div>
                            </div>
                        </div>  
                        <div class="tab-pane fade" id="company_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Elysium Technologies Pvt Ltd</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Entity Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Click My Project</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Sales</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Management</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Development Executive</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <label class="fw-bold text-black fs-5"><u>Credentials</u></label>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Teams</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Spark</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-lg-12 mb-2">
                                            <label class="fw-semibold text-black fs-7"><u>Whatsapp</u></label>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">mahesh1602</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="designation_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthik</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">15-Sep-2024</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Senior Executive</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">₹ 35,000 /-</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">₹ 145/-</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Managing, Leadership</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Under Graduate</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Degree</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">BBA</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Finance</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">MKU</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Work Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Experience</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Business Manager</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Experience Year</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">2 Years</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Global Corporate</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">12-Aug-2022</label>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">25-Jul-2022</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function () {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

     function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

            result = result.trim();

            // Add "In" or "Ago"
            if (isFuture) {
                result = `In ${result}`;
            } else if (result !== '0 days') {
                // result += ' ago';
                result += '';
            }

            return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }
   
    function buildRow(item,index) {    
        
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
  
        let staff_image = '';
        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }
        staff_image = `{{ asset('${staff_image}') }}`;
        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle">
                                <img src="${staff_image}" 
                                    alt="user-avatar"  class="w-px-40 h-px-40 rounded-circle"
                                    id="uploadedlogo" onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}' ${(item.gender == 1 ? 'user_2.png' : 'user_7.png')}"/>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label>
                                <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.staff_name}</span>
                                ${item.gender == 1 ?
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                        class="mdi mdi-face-man text-info"></i></span>`
                                 : 
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i
                                        class="mdi mdi-face-woman text-info"></i></span>`
                                }
                                
                            </label>
                            <span class="fs-8 me-1 d-block text-primary text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.nick_name || '-'}</span>
                            <div class="d-flex  fs-8" style="color:rgb(114,57,234) !important;">
                                <a href="javascript:;" class=" fs-8" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Staff Nick Name" style="color:rgb(114,57,234) !important;">
                                    ${data.staff_id || '-'}
                                </a>
                                <div class="">
                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                        data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9" style="color:rgb(114,57,234) !important;"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Mob No</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.mobile_no || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Email ID</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.email_id || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">DOB</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                ${data.dob ? formatDateCommon(data.dob) : '-'}
                                                <span 
                                                    class="badge fs-8 bg-info" 
                                                    data-bs-toggle="tooltip" 
                                                    title="${data.dob ? getNextBDayDate(data.dob).full : '-'}">
                                                    ${data.dob ? getNextBDayDate(data.dob).short : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Educational</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">
                                            ${data.education && Array.isArray(data.education) && data.education.length > 0 ? data.education : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    ${data.company_type == 1 ?
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold fs-7 text-truncate badge bg-label-danger d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>
                     </div>`
                    :
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>

                        <label class="fw-semibold fs-7 text-truncate badge  d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: ${item.company_base_color || ''};"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.entity_name || '-'}" >
                            ${data.entity_name || '-'}
                        </label>
                    </div>`
                    }
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column gap-1">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.department_name || '-'}">
                            ${data.department_name || '-'}
                        </label>
                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.division_name || '-'}">
                            ${data.division_name || '-'}
                        </label>
                        <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                            <span class="fs-7">${data.job_role_name || '-'}</span>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                           ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                        </label>
                        <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                           ${data.date_of_joining ? getExperienceDuration(data.date_of_joining) : '0 Day'}
                        </label>
                    </div>
                </td>
                <td align="right">
                    <label class="badge bg-warning fs-7 text-black fw-bold mb-2">
                        Abscond
                    </label>
                    <label class="d-block">
                        <span class="text-dark fs-9 fw-semibold">
                            19-Sep-2025
                        </span>
                    </label>
                </td>
                <td>
                    <label class="badge bg-gray-200 border border-success text-black border-2 rounded fw-bold mb-2">
                        <span class="fs-7">${data.dep_reason || '-'}</span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                    
                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                            
                         <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${item.sno})">
                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_staff" onclick="confirmDelete('${item.sno}', '${item.staff_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_enroll/exit_staff?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>
<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
@endsection
