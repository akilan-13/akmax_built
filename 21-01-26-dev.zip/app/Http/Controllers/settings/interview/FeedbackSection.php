<?php

namespace App\Http\Controllers\settings\interview;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FeedbackSectionModel;
use Illuminate\Support\Facades\Validator;

class FeedbackSection extends Controller
{
    
     public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = FeedbackSectionModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('section_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('section_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'section_name' => $item->section_name,
                    'section_icon' => $item->section_icon,
                    'section_desc' => $item->section_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.interview.feedback_section.feedback_section_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = FeedbackSectionModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {
        $validator = Validator::make( $request->all(), [
            'section_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $section_name       = $request->section_name;
            $section_icon       = $request->section_icon;
            $section_desc          = $request->section_desc;
            $user_id                    = 1;
            $chk = FeedbackSectionModel::where( 'section_name', $section_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Feedback Section is exist!'
                ] );
                return redirect()->back();
            } else {
                $add_branchtype = new FeedbackSectionModel();
                $add_branchtype->section_name       = $section_name;
                $add_branchtype->section_icon       = $section_icon;
                $add_branchtype->section_desc       = $section_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => ' Feedback Section added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the  Feedback Section!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'section_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $section_name       = $request->section_name;
            $section_icon       = $request->section_icon;
            $section_desc       = $request->section_desc;
            $document_id       = $request->edit_id;

            $upd_FeedbackSectionModel =  FeedbackSectionModel::where( 'sno', $document_id )->first();

            $chk = FeedbackSectionModel::where( 'section_name', $section_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Feedback Section is exist!'
                ] );
                return redirect()->back();
            }

            $upd_FeedbackSectionModel->section_name  = $section_name;
            $upd_FeedbackSectionModel->section_icon  = $section_icon;
            $upd_FeedbackSectionModel->section_desc  = $section_desc;
            $upd_FeedbackSectionModel->update();

            if ( $upd_FeedbackSectionModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => ' Feedback Section Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the  Feedback Section!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_FeedbackSectionModel = FeedbackSectionModel::where( 'sno', $id )->first();
        $upd_FeedbackSectionModel->status  = 2;
        $upd_FeedbackSectionModel->Update();

        return response( [
            'status'    => 200,
            'message'   => ' Feedback Section Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_FeedbackSectionModel =  FeedbackSectionModel::where( 'sno', $id )->first();
        $upd_FeedbackSectionModel->status = $request->input( 'status', 0 );
        $upd_FeedbackSectionModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

}
