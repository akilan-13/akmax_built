<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class MaritalStatus extends Controller
{
    public function index()
    {
        return view(
            'content.settings.recruitment.marital_status.marital_status_list');
    }

}
