<?php

namespace App\Http\Controllers\settings\common;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\Internal_cugsModel;




class Internal_cugs extends Controller
{
   
    public function index()
    {
      return view('content.settings.common.internal_cugs.internal_cugs_list');
    }

    public function List()
    {  
      $branch_id = $request->user()->branch_id;
      $CourseSubCategory = Internal_cugsModel::where('branch_id', $branch_id)->where('status', 0)
        ->orderBy('sno', 'desc')
        ->get();
      // Prepare and return the response
      return response([
        'status'    => 200,
        'message'   => null,
        'error_msg' => null,
        'data'      => $CourseSubCategory
      ], 200);
    }

public function Add(Request $request)
{
    $branch_id = $request->user()->branch_id;

    $validator = Validator::make($request->all(), [
        'phone_no' => 'required|max:255'
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $user_name     = $request->user_name;
    $cug_mobile_no = $request->phone_no;
    $user_id       = $request->user()->user_id;

    $chk = Internal_cugsModel::where('cug_mobile_no', $cug_mobile_no)
        ->where('branch_id', $branch_id)
        ->where('status', '!=', 2)
        ->first();

    if ($chk) {
        session()->flash('toastr', [
            'status'  => 401,
            'type'    => 'error',
            'message' => 'Internal Cug has already been created!'
        ]);
    } else {
        $add_cug = new Internal_cugsModel();
        $add_cug->user_name     = $user_name;
        $add_cug->cug_mobile_no = $cug_mobile_no;
        $add_cug->branch_id     = $branch_id;
        $add_cug->created_by    = $user_id;
        $add_cug->updated_by    = $user_id;

        if ($add_cug->save()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Internal Cug added Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not add the Internal Cug!'
            ]);
        }
    }
    return redirect()->back();
}

public function Update(Request $request)
{
    $branch_id = $request->user()->branch_id;

    $validator = Validator::make($request->all(), [
        'phone_no_edit' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $user_name     = $request->user_name_edit;
    $cug_mobile_no = $request->phone_no_edit;
    $sno           = $request->edit_id;

    $upd_cug = Internal_cugsModel::where('sno', $sno)->first();

    if (!$upd_cug) {
        session()->flash('toastr', [
            'type'    => 'error',
            'message' => 'Cug record not found!'
        ]);
        return redirect()->back();
    }

    $chk = Internal_cugsModel::where('cug_mobile_no', $cug_mobile_no)
        ->where('status', '!=', 2)
        ->where('sno', '!=', $sno)
        ->first();

    if ($chk) {
        session()->flash('toastr', [
            'status'  => 401,
            'type'    => 'error',
            'message' => 'Cug has already been created!'
        ]);
    } else {
        $upd_cug->user_name     = $user_name;
        $upd_cug->cug_mobile_no = $cug_mobile_no;

        if ($upd_cug->save()) {
            session()->flash('toastr', [
                'type'    => 'success',
                'message' => 'Internal Cug updated Successfully!'
            ]);
        } else {
            session()->flash('toastr', [
                'type'    => 'error',
                'message' => 'Could not update the Internal Cug!'
            ]);
        }
    }

    return redirect()->back();
}



    public function Delete($id)
    {
      $upd_CourseCategoryModel =  Internal_cugsModel::where('sno', $id)->first();
      $upd_CourseCategoryModel->status  = 2;
      // return $upd_CourseCategoryModel;
      $upd_CourseCategoryModel->Update();
  
  
      return response([
        'status'    => 200,
        'message'   => 'Successfully Deleted!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  
    // public function Status($id, Request $request)
    // {
  
    //   $summary_reason =  Internal_cugsModel::where('sno', $id)->first();
    //   $summary_reason->status = $request->input('status', 0);
    //   $summary_reason->update();
  
    //   return response([
    //     'status'    => 200,
    //     'message'   => 'Successfully Status Updated!',
    //     'error_msg' => null,
    //     'data'      => null,
    //   ], 200);
    // }
  }