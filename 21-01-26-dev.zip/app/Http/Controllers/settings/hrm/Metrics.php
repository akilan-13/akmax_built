<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MetricsModel;
use Illuminate\Support\Facades\Validator;

class Metrics extends Controller
{
    
    
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = MetricsModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('metrics_score', 'LIKE', "%{$search_filter}%")
                    ->orWhere('metrics_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('metrics_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'metrics_name' => $item->metrics_name,
                    'metrics_score' => $item->metrics_score,
                    'metrics_desc' => $item->metrics_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.hrm.metrics.metrics_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = MetricsModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'metrics_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $metrics_name       = $request->metrics_name;
            $metrics_score       = $request->metrics_score;
            $metrics_desc          = $request->metrics_desc;
            $user_id                    = 1;
            $chk = MetricsModel::where( 'metrics_name', $metrics_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Metrics is exist!'
                ] );
                return redirect()->back();
            } else {
                $add_branchtype = new MetricsModel();
                $add_branchtype->metrics_score         = $metrics_score;
                $add_branchtype->metrics_name       = $metrics_name;
                $add_branchtype->metrics_desc       = $metrics_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Metrics added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Metrics!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'metrics_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $metrics_name       = $request->metrics_name;
             $metrics_score       = $request->metrics_score;
            $metrics_desc       = $request->metrics_desc;
            $document_id       = $request->edit_id;

            $upd_MetricsModel =  MetricsModel::where( 'sno', $document_id )->first();

            $chk = MetricsModel::where( 'metrics_name', $metrics_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Document is exist!'
                ] );
                return redirect()->back();
            }

            $upd_MetricsModel->metrics_name  = $metrics_name;
            $upd_MetricsModel->metrics_score  = $metrics_score;
            $upd_MetricsModel->metrics_desc  = $metrics_desc;
            $upd_MetricsModel->update();

            if ( $upd_MetricsModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Metrics Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Metrics!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_MetricsModel = MetricsModel::where( 'sno', $id )->first();
        $upd_MetricsModel->status  = 2;
        $upd_MetricsModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Metrics Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_MetricsModel =  MetricsModel::where( 'sno', $id )->first();
        $upd_MetricsModel->status = $request->input( 'status', 0 );
        $upd_MetricsModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
