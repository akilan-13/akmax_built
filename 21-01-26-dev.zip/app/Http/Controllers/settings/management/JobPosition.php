<?php

namespace App\Http\Controllers\settings\management;

use App\Http\Controllers\Controller;
use App\Models\JobpositionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JobPosition extends Controller
{
  protected static $branch_id = 1;
  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $entity_id=$request->user()->entity_id ?? 1;

    $startTime = microtime(true);
    $job_position = JobpositionModel::select(
      'egc_job_position.*',
      'egc_department.department_name',
      'egc_department.department_desc',
      'egc_division.division_name', 
      'egc_division.division_desc', 
      'egc_division.department_id'
  )
  ->join('egc_department', 'egc_department.sno', '=' , 'egc_job_position.department_id')
  ->join('egc_division', 'egc_division.sno', '=', 'egc_job_position.division_id')
  ->join('egc_branch', 'egc_branch.sno', '=', 'egc_job_position.branch_id')
  ->where('egc_job_position.status', '!=', 2)
  ->where('egc_branch.entity_id', $entity_id);
    if ($search_filter != '') {
      $job_position->where(function ($subquery) use ($search_filter) {
          $subquery->where('egc_job_position.job_position_name', 'LIKE', "%{$search_filter}%")
              ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
              ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%");
              
      });
  }
  $job_position =$job_position->orderBy('egc_job_position.sno', 'desc')
  ->paginate($perpage);

   // return $job_position;
    $pageConfigs = ['myLayout' => 'default'];
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return view('content.settings.management.job_role.job_role_list',[
      'job_position' => $job_position,
      'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }

  public function list()
  {

    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobpositionModel::where('branch_id', self::$branch_id) ->where('sub_department_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }
  public function JobPostionList()
  {
    // $dept_id = 5;
    $dept_id = $_GET['id'] ?? '';
    $startTime = microtime(true);
    $job_position = JobpositionModel::where('division_id', $dept_id)->where('status', 0)->orderBy('sno', 'desc')->get();
    $endTime = microtime(true);
    $executionTime = $endTime - $startTime;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
      'execution_time' => $executionTime . ' seconds',
    ], 200);
  }


  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_position_name' => 'required|max:255',

    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $job_position_name = $request->job_position_name;
      $department_id = $request->department_id;
      $division_id = $request->sub_department_id;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;

      // dd($request);

      $branch_id = $request->user()->branch_id;
      $user_id = $request->user()->user_id;
      $chk = JobpositionModel::where('job_position_name', $job_position_name)->where('branch_id', $branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Job Position has been  already created!',
        ]);
      } else {
        $category_check = JobpositionModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date("y"), -2);
          $job_position_id = "JP-0001/" . $year;
        } else {

          $data = $category_check->job_position_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf("JP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $job_position_id = $request . '/' . $year;
        }

        $add_category = new JobpositionModel();
        $add_category->job_position_id = $job_position_id;
        $add_category->job_position_name = $job_position_name;
        $add_category->department_id = $department_id;
        $add_category->division_id = $division_id;
        $add_category->per_hour_cost = $per_hour_cost;
        $add_category->job_position_desc = $job_position_desc;
        $add_category->branch_id = $branch_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'job position added Successfully!',
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the job position!',
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'knowledge Created successfully!');
    }
  }

  public function Edit($id)
  {
    $job_position = JobpositionModel::where('sno', $id)->first();

    // return $job_position;
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,
    ], 200);
  }


  public function Update($id, Request $request)
  {

    $validator = Validator::make($request->all(), [
      'job_position_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $branch_id = $request->user()->branch_id;
      $job_position_name = $request->job_position_name;
      $per_hour_cost = $request->per_hour_cost;
      $job_position_desc = $request->job_position_desc;
      $department_id = $request->department_id;
      $division_id = $request->sub_department_id;

      $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();

      $chk = JobpositionModel::where('job_position_name', $job_position_name)->where('branch_id', $branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $upd_CourseCategoryModel->job_position_name = $job_position_name;
        $upd_CourseCategoryModel->per_hour_cost = $per_hour_cost;
        $upd_CourseCategoryModel->job_position_desc = $job_position_desc;
        $upd_CourseCategoryModel->department_id = $department_id;
        $upd_CourseCategoryModel->division_id = $division_id;
        $upd_CourseCategoryModel->update();
      }


      if ($upd_CourseCategoryModel) {
        $result = response([
          'status' => 200,
          'message' => 'Successfully Updated!',
          'error_msg' => null,
          'data' => null,
        ], 200);
      } else {
        $result = response([
          'status' => 401,
          'message' => 'Incorrect format input feilds',
          'error_msg' => 'Incorrect format input feilds',
          'data' => null,
        ], 401);
      }
      return $result;
    }

    // return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel = JobpositionModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
