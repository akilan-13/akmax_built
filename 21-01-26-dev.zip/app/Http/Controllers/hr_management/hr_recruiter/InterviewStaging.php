<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use App\Models\InterviewScheduleQuestionModel;
use App\Models\InterviewSessionModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\JobConfirmationModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Mail\EGCMail;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Mail;
use App\Models\ApplicantModel;
use App\Models\SocialMediaModel;
use App\Models\OnboardingStaffModel;

class InterviewStaging extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
      ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->select('egc_job_request.*','egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_entity.entity_base_color',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_entity.entity_logo',
      'egc_company.company_base_color')
      ->orderBy('egc_job_request.sno','desc')
      ->get();
     
        foreach($jobRequest as $request){
          $interviewStageList = InterviewScheduleStageModel::where('egc_interview_schedule_stage.status','!=',2)
            ->join('egc_interview_schedule', 'egc_interview_schedule_stage.interview_schedule_id', 'egc_interview_schedule.sno')
            ->join('egc_interview_category', 'egc_interview_schedule_stage.interview_category_id', 'egc_interview_category.sno')
            ->join('egc_interview_mode', 'egc_interview_schedule_stage.mode', 'egc_interview_mode.sno')
            ->where('egc_interview_schedule.job_request_id',$request->sno)
            ->select('egc_interview_schedule_stage.*','egc_interview_category.interview_category_name','egc_interview_mode.interview_mode_name','egc_interview_mode.mode_icon')
            ->orderBy('egc_interview_schedule_stage.stage_order','asc')
            ->get();
           
            $appicants=DB::table('egc_applicant')->where('job_request_id',$request->sno)->where('status','!=',2)->count();
            $hired_count=DB::table('egc_applicant')->where('job_request_id',$request->sno)->where('hiring_status',1)->where('status','!=',2)->count();
            $appicantShorlist=DB::table('egc_applicant')->where('job_request_id',$request->sno)->where('shortlist_check',1)->where('status','!=',2)->count();
            $request->candidate_count=$appicants;
            $request->shortlist_count=$appicantShorlist;
            $request->hired_count=$hired_count;
             $request->interviewStageList =$interviewStageList;   
        }

      $helper = new \App\Helpers\Helpers();
        // return $jobRequest;
        $reasonList=DB::table('egc_interview_reject_reason')->where('status','!=',2)->get();
      return view('content.hr_management.hr_recruiter.interview_staging.staging_list', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
          'reasonList' => $reasonList,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          // 'jobRequest' => $jobRequest,
          // 'perpage' => $perpage,
          // 'search_filter' => $search_filter,
      ]);
  }

   


  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }
      

  public function candidateList(Request $request)
    {
        $jobRequestId = $request->job_request_id;
        $filterType   = $request->filter_type;
        $stageId      = $request->stage_id;

        $query = DB::table('egc_applicant')->select('egc_applicant.*', 'egc_job_role.job_position_name as job_role_name')
            ->where('egc_applicant.job_request_id', $jobRequestId)
            ->join('egc_job_request', 'egc_job_request.sno', '=', 'egc_applicant.job_request_id')
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->where('egc_applicant.status', '!=', 2);
        $jobRequestData = JobRequestModel::where('egc_job_request.status','!=',2)
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->select('egc_job_request.*','egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_entity.entity_base_color',
            'egc_job_role.job_position_name as job_role_name',
            'egc_company.company_name',
            'egc_entity.entity_logo',
            'egc_company.company_base_color')
            ->where('egc_job_request.sno', $jobRequestId)
            ->first();


        // Default / Candidates
        if ($filterType === 'candidates') {
         $candidates = $query
            ->orderBy('egc_applicant.created_at', 'desc')
            ->get();

           return view(
                'content.hr_management.hr_recruiter.interview_staging.candidate_list',
                compact('candidates')
            );
        }

        // Shortlisted
        elseif ($filterType === 'shortlisted') {
            $query->where('egc_applicant.shortlist_check', 1);
            $candidates = $query
            ->orderBy('egc_applicant.created_at', 'desc')
            ->get();

           return view(
                'content.hr_management.hr_recruiter.interview_staging.candidate_list',
                compact('candidates')
            );
        }

        // Interview Stage
        elseif ($filterType === 'stage' && $stageId) {

           $stage = DB::table('egc_interview_schedule_stage')
                ->join('egc_interview_category', 'egc_interview_category.sno', '=', 'egc_interview_schedule_stage.interview_category_id')
                ->where('egc_interview_schedule_stage.sno', $stageId)
                ->select('egc_interview_schedule_stage.*','egc_interview_category.interview_category_name')
                ->first();

            $selectedIds = [];

            if (!empty($stage->selected_ids)) {
                $decoded = json_decode($stage->selected_ids, true);
                if (is_array($decoded)) {
                    $selectedIds = $decoded;
                }
            }
            $rejectedIds = [];

            if (!empty($stage->selected_ids)) {
                $decoded = json_decode($stage->rejected_ids, true);
                if (is_array($decoded)) {
                    $rejectedIds = $decoded;
                }
            }

            $isLastStage = !DB::table('egc_interview_schedule_stage')
               ->join('egc_interview_schedule', 'egc_interview_schedule.sno', '=', 'egc_interview_schedule_stage.interview_schedule_id')
              ->where('egc_interview_schedule.job_request_id', $jobRequestId)
              ->where('egc_interview_schedule_stage.sno', '>', $stageId)
              ->exists();
            

            $ids = [];

            if ($stage && $stage->shortlist_applicant_ids) {
                $decoded = json_decode($stage->shortlist_applicant_ids, true);
                if (is_array($decoded)) {
                    $ids = $decoded;
                }
            }

            // If no shortlisted applicants
            if (empty($ids)) {
                return view(
                    'content.hr_management.hr_recruiter.interview_staging.interview_result',
                    ['candidates' => collect()]
                );
            }

            // 2️⃣ Fetch applicants
            $candidates = DB::table('egc_applicant')
                ->whereIn('sno', $ids)
                ->where('status', '!=', 2)
                ->orderBy('created_at', 'desc')
                ->get();

            // 3️⃣ Fetch answers (MATCH saveAnswer())
            $answers = DB::table('egc_interview_answers as ia')
              ->where('ia.interview_schedule_stage_id', $stageId)
              ->whereIn('ia.created_by', $ids)
              ->where('ia.status', 1)
              ->select(
                  'ia.created_by as applicant_id',
                  'ia.interview_question_id',
                  'ia.answer_type',
                  'ia.answer_text',
                  'ia.answer_file',
                  'ia.time_taken',
                  'ia.retake_count',
                  'ia.created_at'
              )
              ->orderBy('ia.created_at')
              ->get()
              ->groupBy('applicant_id');


            $stageQuestions = DB::table('egc_interview_schedule_questions as sq')
              ->join('egc_interview_question as iq', 'iq.sno', '=', 'sq.interview_question_id')
              ->where('sq.interview_schedule_stage_id', $stageId)
              ->select(
                  'sq.interview_question_id',
                  'iq.field_name as question_text'
              )
              ->orderBy('sq.sno')
              ->get();

          foreach ($candidates as $candidate) {
              $candidate->is_selected = in_array((string)$candidate->sno, $selectedIds) ? 1 : 0;
              $candidate->is_rejected  = in_array((string)$candidate->sno, $rejectedIds) ? 1 : 0;
              $candidateAnswers = $answers[$candidate->sno] ?? collect();

              $candidate->questions = $stageQuestions->map(function ($q) use ($candidateAnswers) {

                  $answer = $candidateAnswers
                      ->firstWhere('interview_question_id', $q->interview_question_id);

                  return (object) [
                      'question_text' => $q->question_text,

                      'answer_type'   => $answer->answer_type   ?? null,
                      'answer_text'   => $answer->answer_text   ?? null,
                      'answer_file'   => $answer->answer_file   ?? null,
                      'time_taken'    => $answer->time_taken    ?? 0,
                      'created_at'    => $answer->created_at    ?? null,
                      'retake_count' => $answer->retake_count ?? 0,

                      // ✅ SIMPLE STATUS
                      'status' => $answer ? 'completed' : 'not_answered'
                  ];
              });

                $totalQuestions = $candidate->questions->count();
                $answeredCount  = $candidate->questions
                  ->where('status', 'completed')
                  ->count();
                // $candidate->is_selected = $selected ? 1 : 0;
                $candidate->is_completed = ($totalQuestions > 0 && $answeredCount === $totalQuestions);
                $candidate->is_last_stage = $isLastStage;
              
          }

          $directInterviewData = null;

            if (!empty($stage->direct_interview)) {
                $directInterviewData = json_decode($stage->direct_interview, true);
            }

          
            return view(
                'content.hr_management.hr_recruiter.interview_staging.interview_result',
                compact('candidates','stageId','stage','directInterviewData')
            );
        }

        // Hired
        elseif ($filterType === 'hired') {
            $query->where('hiring_status', 1); 
            $candidates = $query
                ->orderBy('created_at', 'desc')
                ->get();
            return view(
            'content.hr_management.hr_recruiter.interview_staging.hired_list',
            compact('candidates','jobRequestData'));
        }


        $candidates = $query
            ->orderBy('egc_applicant.created_at', 'desc')
            ->get();

        return view(
            'content.hr_management.hr_recruiter.interview_staging.candidate_list',
            compact('candidates')
        );
    }


public function hireCandidate(Request $request)
{
    $request->validate([
        'applicant_id' => 'required|integer'
    ]);
    //    return  $request->direct_interview;
    $userId = auth()->user()->user_id;

    DB::beginTransaction();

    try {
        $applicantId = (string) $request->applicant_id;

        /* -----------------------------
           1️⃣ Mark applicant as hired
        ------------------------------ */
        DB::table('egc_applicant')
            ->where('sno', $applicantId)
            ->update([
                'hiring_status' => 1,
                'updated_at'    => now()
            ]);

        /* -----------------------------
           2️⃣ Find CURRENT interview stage
        ------------------------------ */
        $currentStage = DB::table('egc_interview_schedule_stage')
            ->whereJsonContains('shortlist_applicant_ids', $applicantId)
            ->orderBy('stage_order', 'desc')
            ->first();

        if (!$currentStage) {
            throw new \Exception('Current interview stage not found');
        }

        /* -----------------------------
           3️⃣ Update selected_ids safely
        ------------------------------ */
        $selectedIds = [];

        if (!empty($currentStage->selected_ids)) {
            $decoded = json_decode($currentStage->selected_ids, true);
            if (is_array($decoded)) {
                $selectedIds = $decoded;
            }
        }

        if (!in_array($applicantId, $selectedIds)) {
            $selectedIds[] = $applicantId;

            DB::table('egc_interview_schedule_stage')
                ->where('sno', $currentStage->sno)
                ->update([
                    'selected_ids' => json_encode(array_values($selectedIds)),
                    'updated_at'   => now()
                ]);
        }

        if ($currentStage->mode == 4 && $request->direct_interview) {
            $directInterview = json_decode($request->direct_interview, true);

            DB::table('egc_interview_schedule_stage')
                ->where('sno', $currentStage->sno)
                ->update([
                    'direct_interview' => json_encode([
                        'applicant_id' => $directInterview['appliacant_id'] ?? null,
                        'interview_category_id' => $directInterview['interview_category'] ?? null,
                        'interview_date' => $directInterview['interview_date'] ?? null,
                        'interview_time' => $directInterview['interview_time'] ?? null,
                        'description'    => $directInterview['description'] ?? null,  
                        'created_by'     => $userId,
                        'created_at'     => now()
                    ])
                ]);
        }


        DB::commit();

        return response()->json([
            'success' => true,
            'message' => 'Candidate hired successfully'
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Failed to hire candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
}


public function shortlistCandidate(Request $request)
{
    $request->validate([
        'applicant_id' => 'required|integer'
    ]);

    DB::beginTransaction();

    $userId = auth()->user()->user_id;

    try {
        $applicantId = (string) $request->applicant_id;

        /* -----------------------------
           1️⃣ Mark applicant shortlisted
        ------------------------------ */
        DB::table('egc_applicant')
            ->where('sno', $applicantId)
            ->update([
                'shortlist_check' => 1,
                'updated_at'      => now()
            ]);

        /* -----------------------------
           2️⃣ Get applicant current stage
        ------------------------------ */
        $currentStage = DB::table('egc_interview_schedule_stage')
            ->whereJsonContains('shortlist_applicant_ids', $applicantId)
            ->orderBy('stage_order', 'desc')
            ->first();

        if (!$currentStage) {
            throw new \Exception('Current interview stage not found');
        }

        /* -----------------------------
           3️⃣ Get NEXT stage
        ------------------------------ */
        $nextStage = DB::table('egc_interview_schedule_stage')
            ->where('interview_schedule_id', $currentStage->interview_schedule_id)
            ->where('stage_order', '>', $currentStage->stage_order)
            ->orderBy('stage_order')
            ->first();

        // If last stage → nothing to shortlist into
        if (!$nextStage) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant shortlisted (last stage reached)'
            ]);
        }

        /* -----------------------------
           4️⃣ Update shortlist_applicant_ids
        ------------------------------ */
       $ids = [];

        if ($nextStage->shortlist_applicant_ids) {
            $decoded = json_decode($nextStage->shortlist_applicant_ids, true);
            if (is_array($decoded)) {
                $ids = $decoded;
            }
        }

        // Already shortlisted → stop
        if (in_array($applicantId, $ids)) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant already shortlisted'
            ]);
        }

        // ✅ ADD applicant to next stage
        $ids[] = $applicantId;

        DB::table('egc_interview_schedule_stage')
            ->where('sno', $nextStage->sno)
            ->update([
                'shortlist_applicant_ids' => json_encode(array_values($ids)),
                'updated_at'              => now()
            ]);

            $currentIds = [];

          if ($currentStage->selected_ids) {
              $decoded = json_decode($currentStage->selected_ids, true);
              if (is_array($decoded)) {
                  $currentIds = $decoded;
              }
          }

          if (!in_array($applicantId, $currentIds)) {
              $currentIds[] = $applicantId;

              DB::table('egc_interview_schedule_stage')
                  ->where('sno', $currentStage->sno)
                  ->update([
                      'selected_ids' => json_encode(array_values($currentIds)),
                      'updated_at' => now()
                  ]);
          }

        DB::commit();

        return response()->json([
            'success' => true,
            'next_stage_id' => $nextStage->sno
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Failed to shortlist candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
}
public function rejectCandidate(Request $request)
{
    $request->validate([
        'applicant_id' => 'required|integer'
    ]);

    DB::beginTransaction();

    try {
        $applicantId = (string) $request->applicant_id;

        /* -----------------------------
           1️⃣ Mark applicant shortlisted
        ------------------------------ */
        DB::table('egc_applicant')
            ->where('sno', $applicantId)
            ->update([
                'shortlist_check' => 1,
                'updated_at'      => now()
            ]);

        /* -----------------------------
           2️⃣ Get applicant current stage
        ------------------------------ */
        $currentStage = DB::table('egc_interview_schedule_stage')
            ->whereJsonContains('shortlist_applicant_ids', $applicantId)
            ->orderBy('stage_order', 'desc')
            ->first();

        if (!$currentStage) {
            throw new \Exception('Current interview stage not found');
        }

        /* -----------------------------
           3️⃣ Get NEXT stage
        ------------------------------ */
        $nextStage = DB::table('egc_interview_schedule_stage')
            ->where('interview_schedule_id', $currentStage->interview_schedule_id)
            ->where('stage_order', '>', $currentStage->stage_order)
            ->orderBy('stage_order')
            ->first();

        // If last stage → nothing to shortlist into
        if (!$nextStage) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant shortlisted (last stage reached)'
            ]);
        }

        /* -----------------------------
           4️⃣ Update shortlist_applicant_ids
        ------------------------------ */
       $ids = [];

        if ($nextStage->shortlist_applicant_ids) {
            $decoded = json_decode($nextStage->shortlist_applicant_ids, true);
            if (is_array($decoded)) {
                $ids = $decoded;
            }
        }

        // Already shortlisted → stop
        if (in_array($applicantId, $ids)) {
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Applicant already shortlisted'
            ]);
        }

        // ✅ ADD applicant to next stage
        $ids[] = $applicantId;

        DB::table('egc_interview_schedule_stage')
            ->where('sno', $nextStage->sno)
            ->update([
                'shortlist_applicant_ids' => json_encode(array_values($ids)),
                'updated_at'              => now()
            ]);

            $currentIds = [];

          if ($currentStage->selected_ids) {
              $decoded = json_decode($currentStage->selected_ids, true);
              if (is_array($decoded)) {
                  $currentIds = $decoded;
              }
          }

          if (!in_array($applicantId, $currentIds)) {
              $currentIds[] = $applicantId;

              DB::table('egc_interview_schedule_stage')
                  ->where('sno', $currentStage->sno)
                  ->update([
                      'selected_ids' => json_encode(array_values($currentIds)),
                      'updated_at' => now()
                  ]);
          }

          if ($currentStage->mode == 4 && $request->direct_interview) {
            $directInterview = json_decode($request->direct_interview, true);

            DB::table('egc_interview_schedule_stage')
                ->where('sno', $currentStage->sno)
                ->update([
                    'direct_interview' => json_encode([
                        'applicant_id' => $directInterview['appliacant_id'] ?? null,
                        'interview_category_id' => $directInterview['interview_category'] ?? null,
                        'interview_date' => $directInterview['interview_date'] ?? null,
                        'interview_time' => $directInterview['interview_time'] ?? null,
                        'description'    => $directInterview['description'] ?? null,  
                        'created_by'     => $userId,
                        'created_at'     => now()
                    ])
                ]);
        }

        DB::commit();

        return response()->json([
            'success' => true,
            'next_stage_id' => $nextStage->sno
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'success' => false,
            'message' => 'Failed to shortlist candidate',
            'error'   => $e->getMessage()
        ], 500);
    }
}

public function stream(InterviewAnswerModel $answer)
{
    // Optional: add permission check here

    if (!$answer->answer_file) {
        abort(404);
    }

    return Storage::disk('interview')->response(
        $answer->answer_file
    );
}


public function sendConfirmationBulk(Request $request)
{
    $userId = auth()->user()->user_id;

    // return $request->all();

    foreach ($request->shortlist_data as $candidate) {

        // generate token
        $token = Str::uuid();

        $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
            ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
            ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
            ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
            ->select('egc_job_request.*','egc_entity.entity_name',
            'egc_entity.entity_short_name',
            'egc_entity.entity_base_color',
            'egc_job_role.job_position_name as job_role_name',
            'egc_company.company_name',
            'egc_entity.entity_logo',
            'egc_company.company_base_color')
            ->where('egc_job_request.sno', $request->job_request_id)
            ->first();

        $applicant = ApplicantModel::where('sno', $candidate['sno'])->first();

            $helper = new \App\Helpers\Helpers();
            $encrypted_values = $helper->encrypt_decrypt($token, 'encrypt');
            $Link =url('job-confirmation/' . $token);
            
            if(!$applicant->confirmation_link){
                    $channelId = 23;
                    $shortUrlData = $this->shortenUrl($Link,$channelId);
                    $shortUrl = $shortUrlData['shorturl'];
                    $urlId =$shortUrlData['id'];
                    if($shortUrl){
                        DB::table('egc_applicant')
                        ->where('sno', $candidate['sno'])
                        ->update(['confirmation_link' => $shortUrl]);
                    }
            }
            $confirmationUrl=DB::table('egc_applicant')->where('egc_applicant.sno',$candidate['sno'])->first();
            $shortsendUrl = $confirmationUrl->confirmation_link ;
            $job_url_key = basename($shortsendUrl);

        $jobConfirmation = JobConfirmationModel::updateOrCreate(
            [
                'job_request_id' => $jobRequest->sno,
                'applicant_id' => $candidate['sno'],  
            ],
            [
                'reporting_date' =>  date('Y-m-d', strtotime($request->reporting_date)),
                'confirmation_link' => $confirmationUrl->confirmation_link,
                'token' => $token,
                'expiry_date' =>  date('Y-m-d', strtotime($request->link_expiry)),
                'email_sent'      => 0,
                'whatsapp_send'      => 0,
                'communication_read'      => 0,
                'status'      => 0,
                'created_at'  => now(),
                'created_by'  => $userId ?? 0,
                'updated_by'  => $userId ?? 0
            ]
        );

        


            if ($applicant->email) {
                $emailTemplate_id =5; 
                $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $emailTemplate_id)->first();
    
                // Gender condition
                $genderPrefix = 'Mr/Ms'; // Default value
                // if ($lead->lead_gender == 1) {
                //   $genderPrefix = 'Mr';
                // } elseif ($lead->lead_gender == 2) {
                //   $genderPrefix = 'Ms';
                // }
                $helper = new \App\Helpers\Helpers();
                $branch = $helper->general_setting_data();
                $baseURL= url('/');
                $content = $emailTemplate->email_subject;
                $hr_mobile = $branch->hr_head_no;
                $hr_email = $branch->hr_head_mail_id;
                $socialMediaDetails = json_decode($branch->social_media_details, true);
                $socialMediaList = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();

                $facebook_link = null;
                $instagram_link = null;
                $twitter_link = null;
                $linkedin_link = null;
                $youtube_link = null;
                $pinterest_link = null;

                foreach ($socialMediaList as $socialMedia) {
                  $sno = $socialMedia->sno;

                  if (isset($socialMediaDetails[$sno])) {
                      $url = $socialMediaDetails[$sno];
                      switch ($socialMedia->social_media_name) {
                          case 'Instagram':
                              $instagram_link = $url;
                              break;
                          case 'Facebook':
                              $facebook_link = $url;
                              break;
                          case 'Twitter':
                              $twitter_link = $url;
                              break;
                          case 'LinkedIn':
                              $linkedin_link = $url;
                              break;
                          case 'YouTube':
                              $youtube_link = $url;
                              break;
                          case 'Pinterest':
                              $pinterest_link = $url;
                              break;
                      }
                  }
                }

                $dynamicSubject = str_replace('#otp', '000000', $emailTemplate->email_name);

                $content = str_replace('#candidate_name', $applicant->applicant_name ?? 'Candidate', $content);
                $content = str_replace('#job_title', $jobRequest->job_role_name ?? 'Developer', $content);
                $content = str_replace('#job_location', 'Madurai', $content);
                $content = str_replace('#joining_date',$jobConfirmation->reporting_date ? date('d-M-Y', strtotime($jobConfirmation->reporting_date)): '-' , $content);
                $content = str_replace('#confirmation_deadline',$jobConfirmation->expiry_date ? date('d-M-Y', strtotime($jobConfirmation->expiry_date)): '-' , $content);
                $content = str_replace('#job_confirmation_link',$jobConfirmation->confirmation_link ?? $Link, $content);
                $content = str_replace('#hr_contact',  $hr_mobile ?? '8220011465', $content);
                $content = str_replace('#hr_email',  $hr_email ?? 'hrelysiumgroups@gmail.com', $content);
                $branchNo = $branch->hr_head_no;
                $branchemail = $branch->hr_head_mail_id;
                $fbLink = $facebook_link ?? 'https://www.facebook.com/PhDiZone/';
                $instaLink = $instagram_link ?? 'https://www.instagram.com/phdizoneresearch/';
                $url= 'www.elysiumgroup.com';
        
                $mailData = [
                      'url'         => $url,
                      'subject'     => $dynamicSubject,
                      'content'     => $content,
                      'branchNo'    => $hr_mobile,
                      'branchemail' => $hr_email, // Use the message content from the request
                      'fbLink'      => $fbLink,      // Use the message content from the request
                      'instaLink'   => $instaLink,   // Use the message content from the request
                      'salesMobile' => $hr_mobile ?? '8220011465',
                  ];
        
                $to_address = $applicant->email;
                $from_address = 'elysiumgroups@elysium.community';
                $from_name =  'Elysium Groups ';
        
                  // return $mailData;
                Mail::to($to_address)->send(new EGCMail($mailData, $from_address, $from_name));

                DB::table('egc_job_confirmations')
                ->where('sno', $jobConfirmation->sno)
                ->update(['email_sent' => 1]);

            }

        // send email (optional)
    }

    return response()->json(['success' => true]);
}


    public function shortenUrl($longUrl,$channelId)
    {
        $response = Http::withToken('aFLQFlykraqpANsi')
            ->post('https://chotta.link/api/url/add', [
                'url' => $longUrl
            ]);
    
        if ($response->successful() && isset($response['shorturl'])) {
            
            $shortUrl = $response['shorturl'];
            $urlId =$response['id'];
            
            $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

            $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);
    
            if ($assignResponse->successful()) {
                return $response; // success
            }
        }
        
    
        return null;
    }


     public function jobConfirmationPage($token,Request $request)
    {

        $confirmation = JobConfirmationModel::where('token', $token)
            ->whereDate('expiry_date', '>=', now())
            ->first();

        $helper = new \App\Helpers\Helpers();
        $branch = $helper->general_setting_data();
        $hr_mobile = $branch->hr_head_no;
        $hr_email = $branch->hr_head_mail_id;

        if (!$confirmation) {
            return view('content.hr_management.hr_recruiter.interview_staging.confirmation_expired',compact('hr_mobile','hr_email'));
        }
                            
        $applicant = ApplicantModel::select(
            'egc_applicant.*',
            'egc_job_role.job_position_name as job_role_name',
            'egc_job_confirmations.reporting_date',
            'egc_job_confirmations.status as confirmation_status',
        )
        ->join('egc_job_confirmations', 'egc_applicant.sno', 'egc_job_confirmations.applicant_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_applicant.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_confirmations.token', $token)
        ->first();

        // return $applicant;

        if ($applicant->confirmation_status ==1) {
            return redirect()->route(
                'job.confirmation.thankyou.accept',$token);
        }
        if ($applicant->confirmation_status ==2) {
            return redirect()->route(
                'job.confirmation.thankyou.decline',$token);
        }
        
        return view('content.hr_management.hr_recruiter.interview_staging.job_confirmation', [
            'token' => $token,
            'applicant' => $applicant,
            'candidate_name' => $applicant->applicant_name ?? 'Candidate',
            'job_title' => $applicant->job_role_name ?? 'Developer',
            'reporting_date' => $applicant->reporting_date,
        ]);
    }

    public function jobConfirmationSubmit(Request $request)
    {
        $request->validate([
            'token' => 'required',
            'status' => 'required|in:Accepted,Rejected',
        ]);

        $token = $request->token;
        $applicant = ApplicantModel::select(
            'egc_applicant.*',
            'egc_job_role.job_position_name as job_role_name',
            'egc_job_confirmations.reporting_date',
            'egc_job_confirmations.status as confirmation_status',
        )
        ->join('egc_job_confirmations', 'egc_applicant.sno', 'egc_job_confirmations.applicant_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_applicant.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_confirmations.token', $token)
        ->first();
        

        $confirmation = JobConfirmationModel::where('token', $request->token)->first();

        if (!$confirmation) {
            return response()->json([
                'success' => false,
                'redirect_url' => route('job.confirmation.expired')
            ]);
        }
     
        // Already responded
        if ($confirmation->status !=0) {
            return response()->json([
                'success' => true,
                'redirect_url' => route(
                    'job.confirmation.thankyou',
                    strtolower($confirmation->status)
                )
            ]);
        }

        // Update response
        $confirmation->update([
            'status' => $request->status == 'Accepted' ? 1 : ($request->status == 'Rejected' ? 2 : 0),
            'updated_at' => now(),
        ]);

        if ($confirmation->status == 1) {

            // Prevent duplicate onboarding
            $exists = OnboardingStaffModel::where('applicant_id', $confirmation->applicant_id)
                ->where('job_request_id', $applicant->job_request_id)
                ->exists();
            $job_role=DB::table('egc_job_role')->where('sno',$applicant->job_role_id)->first();
            if (!$exists) {
               $onboarding= OnboardingStaffModel::create([
                    'applicant_id'        => $confirmation->applicant_id,
                    'job_request_id'      => $applicant->job_request_id,
                    'job_confirmation_id' => $confirmation->sno,

                    'candidate_name'      => $applicant->applicant_name,
                    'personal_email'      => $applicant->email,
                    'mobile'              => $applicant->mobile,

                    'job_role_id'         => $applicant->job_role_id,
                    'department_id'         => $job_role->department_id,
                    'division_id'         => $job_role->division_id,
                    'doj'                 => $confirmation->reporting_date,
                    'offer_accepted_at'   => now(),

                    'onboarding_step'     => 'initiated',
                    'document_status'     => 'pending',

                    'status'              => 0,
                    'created_by'          => 0, // system
                ]);

                $checklists = DB::table('egc_onboarding_checklist_master')
                    ->where('status', 0)
                    ->get();

                foreach ($checklists as $item) {
                    DB::table('egc_onboarding_employee_checklist')->insert([
                        'onboarding_employee_id' => $onboarding->sno,
                        'checklist_id'           => $item->sno,
                        'status'                 => 0,
                    ]);
                }
            }
        }

        if ($confirmation->status ==1) {
            $url = route('job.confirmation.thankyou.accept',$token);
        }elseif ($confirmation->status ==2) {
            $url = route('job.confirmation.thankyou.decline',$token);
        }else{
            $url = route('job.confirmation.thankyou.expired',$token);
        }
                         
        return response()->json([
            'success' => true,
            'redirect_url' => $url
        ]);
    }
    
    public function jobConfirmationExpired($token,Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch = $helper->general_setting_data();
        $hr_mobile = $branch->hr_head_no;
        $hr_email = $branch->hr_head_mail_id;
                            
        $applicant = ApplicantModel::select(
            'egc_applicant.*',
            'egc_job_role.job_position_name as job_role_name',
            'egc_job_confirmations.reporting_date',
            'egc_job_confirmations.status as confirmation_status',
        )
        ->join('egc_job_confirmations', 'egc_applicant.sno', 'egc_job_confirmations.applicant_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_applicant.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_confirmations.token', $token)
        ->first();

        // return $applicant;

        
        return view('content.hr_management.hr_recruiter.interview_staging.confirmation_expired', [
            'token' => $token,
            'applicant' => $applicant,
            'candidate_name' => $applicant->applicant_name ?? 'Candidate',
            'job_title' => $applicant->job_role_name ?? 'Developer',
            'reporting_date' => $applicant->reporting_date,
            'hr_mobile' => $hr_mobile,
            'hr_email' => $hr_email ,
        ]);
    }

    public function jobConfirmationAccept($token,Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch = $helper->general_setting_data();
        $hr_mobile = $branch->hr_head_no;
        $hr_email = $branch->hr_head_mail_id;
                            
        $applicant = ApplicantModel::select(
            'egc_applicant.*',
            'egc_job_role.job_position_name as job_role_name',
            'egc_job_confirmations.reporting_date',
            'egc_job_confirmations.status as confirmation_status',
        )
        ->join('egc_job_confirmations', 'egc_applicant.sno', 'egc_job_confirmations.applicant_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_applicant.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_confirmations.token', $token)
        ->first();

        // return $applicant;

        
        return view('content.hr_management.hr_recruiter.interview_staging.job_accepted', [
            'token' => $token,
            'applicant' => $applicant,
            'candidate_name' => $applicant->applicant_name ?? 'Candidate',
            'job_title' => $applicant->job_role_name ?? 'Developer',
            'reporting_date' => $applicant->reporting_date,
            'hr_mobile' => $hr_mobile,
            'hr_email' => $hr_email ,
        ]);
    }

    public function jobConfirmationDecline($token,Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $branch = $helper->general_setting_data();
        $hr_mobile = $branch->hr_head_no;
        $hr_email = $branch->hr_head_mail_id;
                            
        $applicant = ApplicantModel::select(
            'egc_applicant.*',
            'egc_job_role.job_position_name as job_role_name',
            'egc_job_confirmations.reporting_date',
            'egc_job_confirmations.status as confirmation_status',
        )
        ->join('egc_job_confirmations', 'egc_applicant.sno', 'egc_job_confirmations.applicant_id')
        ->join('egc_job_request', 'egc_job_request.sno', 'egc_applicant.job_request_id')
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->where('egc_job_confirmations.token', $token)
        ->first();

        // return $applicant;

        
        return view('content.hr_management.hr_recruiter.interview_staging.job_declined', [
            'token' => $token,
            'applicant' => $applicant,
            'candidate_name' => $applicant->applicant_name ?? 'Candidate',
            'job_title' => $applicant->job_role_name ?? 'Developer',
            'reporting_date' => $applicant->reporting_date,
            'hr_mobile' => $hr_mobile,
            'hr_email' => $hr_email ,
        ]);
    }

}
