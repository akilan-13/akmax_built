<table class="table table-bordered">
    <thead>
        <tr class="text-start align-center  fw-bold fs-6 gs-0 bg-primary">
            <th>Staff Name</th>
            <th>Department /<br>Job role</th>
            <th>Employee ID</th>
            <th>Timechamp ID</th>
        </tr>
    </thead>
    <tbody>
        @foreach($staff as $s)
        @php
            $staff_image = '';

            // Check if staff image exists and construct path based on company type
            if ($s->staff_image && trim($s->staff_image) !== '') {
                if ($s->company_type == 1) {
                    // For Management company type
                    $staff_image = 'staff_images/Management/' . $s->staff_image;
                } else {
                    // For other company types
                    $staff_image = 'staff_images/Buisness/' . $s->company_id . '/' . $s->entity_id . '/' . $s->staff_image;
                }
            } else {
                // Default image based on gender if staff image is not provided
                $staff_image = $s->gender == 1
                    ? 'assets/egc_images/auth/user_2.png'
                    : 'assets/egc_images/auth/user_7.png';
            }
            $staff_image = asset($staff_image);
        @endphp
        <tr>
            <td style="position:relative;">
            <!-- Color Bar on the left -->
            <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:{{$s->company_base_color ?? ''}};"></div>
            
            <div class="d-flex">
                <div class="symbol symbol-35px me-2">
                    <div class="image-input image-input-circle">
                        <!-- Correct img tag with dynamic src -->
                        <img src="{{$staff_image}}" alt="user-avatar" class="w-px-40 h-px-40 rounded-circle" id="uploadedlogo" />
                    </div>
                </div>
                <div class="mb-0">
                    <label>
                        <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">{{$s->staff_name}}</span>
                        <!-- Gender Icon -->
                        @if($s->gender == 1)
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i class="mdi mdi-face-man text-info"></i></span>
                        @else
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i class="mdi mdi-face-woman text-info"></i></span>
                        @endif
                    </label>
                    <span class="fs-8 me-1 d-block text-primary text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Nickname">{{$s->nick_name ?? '-'}}</span>
                </div>
            </div>
        </td>
            <td>
                <div class="d-flex align-items-start justify-content-center flex-column">
                    <label class="fw-semibold text-black fs-7 text-truncate d-block"
                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 175px;"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="{{$s->department_name ?? '-'}}">{{$s->department_name ?? '-'}}
                    </label>
                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 175px;"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="{{$s->job_role_name ?? '-'}}">
                        {{$s->job_role_name ?? '-'}}
                    </label>
                </div>
            </td>
            <td>
                <input type="text"
                       class="form-control staff-id-input"
                       data-sno="{{ $s->sno }}"
                       value="{{ $s->staff_id }}">
            </td>
            <td>
                <input type="text"
                       class="form-control staff-timechamp-id-input"
                       data-sno="{{ $s->sno }}"
                       value="{{ $s->timechamp_id ??'' }}">
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
