@extends('layouts/layoutMaster')

@section('title', 'Update Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js', 
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Update Staff</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management 
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            HR Enroll
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Manage Staff
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
       <div class="row">
            <div class="col-lg-4 mb-2 border-end">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Personal Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mb-2">Staff Image</label>
                        <div class="d-flex align-items-sm-center justify-content-start">
                            <div class="d-flex align-items-start justify-content-center flex-column">
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="Attachment"
                                    class="d-block w-px-120 h-px-120 rounded" id="staff_add" style="border: 2px solid #ab2b22;"/>
                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                            </div>
                            <div class="button-wrapper">
                                <div class="d-flex align-items-start justify-content-start mt-2 mb-2">
                                    <label class="btn btn-sm btn-primary me-2" tabindex="0">
                                        <!-- <i class="mdi mdi-tray-arrow-up"></i> -->
                                        <span class="fw-semibold text-white fs-6">Upload</span>
                                        <input type="file" name='staff_add_icon' id="staff_add_icon"
                                            class="staff_add_cls" hidden accept="image/png, image/jpeg" />
                                    </label>
                                    <button type="button" class="btn btn-sm btn-outline-danger staff-add-reset">
                                        <!-- <i class="mdi mdi-reload"></i> -->
                                        <span class="fw-semibold text-primary fs-6">Reset</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="staff_name" name='staff_name' placeholder="Enter Staff Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"  value="Mahesh Kumar"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Gender<span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_male">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_male" value="1" checked />
                                    Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_female">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_female" value="2" />
                                    Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_others">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_others" value="3" />
                                    Others</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" name="dob" placeholder="Select Date" class="form-control common_datepicker"
                                value="16-02-1986" />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                            placeholder="Enter Mobile No" onkeyup="mobile_chk(this.value)" value="9874587450"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold">Alternate Mobile No</label>
                        <input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                            placeholder="Enter Alternate Mobile No" onkeyup="mobile_chk(this.value)" value="9898745120"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="email_id" name="email_id" placeholder="Enter E-Mail ID"
                            title="Please enter a valid email address" oninput=" this.value = this.value.toLowerCase();" value="mahesh1602@gmail.com"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="contact_person_name" name="contact_person_name"
                            placeholder="Enter Contact  Person Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" value="Dhana Balan P"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile Number<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control me-2" maxlength="10"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                            id="contact_person_no" name="contact_person_no" placeholder="Enter Contact  Person Mobile Number" value="9685859641"/>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Marital Status</label>
                        <select id="martial_status" name="martial_status" class="select3 form-select">
                            <option value="">Select Marital Status</option>
                            <option value="1" selected>Married</option>
                            <option value="2">Un Married</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Address</label>
                        <textarea class="form-control" rows="3" id="address" name="address"
                            placeholder="Enter Address">12/A, First Floor,block C, Park Avenue, Cross Street, Vanathi Street, Narayanapuram, Madurai - 625014</textarea>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark fs-6 fw-semibold mt-2">Other Attachment</label>
                        <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                            <div class="dz-message needsclick fs-6">
                                <div class="text-center text-black me-3">Drop files here or click to upload</div>
                            </div>
                            <div class="fallback">
                                <input type="file" name="attachment[]" multiple>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="3" id="description" name="description"
                            placeholder="Enter Description"></textarea>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 mb-2">
                <div class="col-lg-12 mb-3">
                    <label class="fs-5 text-primary fw-bold">Company Details</label>
                </div>
                <div class="col-lg-12 mb-3">
                    <div class="form-check form-check-inline mb-3">
                        <label class="form-check-label" for="management">
                            <input class="form-check-input" type="radio" name="company" id="management" value="1"   />
                            Management
                        </label>
                    </div>
                    <div class="form-check form-check-inline mb-3">
                        <label class="form-check-label" for="business">
                            <input class="form-check-input" type="radio" name="company" id="business" value="2" checked/>
                            Business
                        </label>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3 business_div" style="display: none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                            <select id="company_name" name="company_name" class="select3 form-select">
                                <option value="">Select Company Name</option>
                                <option value="1">Elysium Academy</option>
                                <option value="2" selected>Elysium Technologies Pvt Ltd</option>
                                <option value="3">Elysian Intelligence Business Solution</option>
                                <option value="4">Elysian Embbed School</option>
                                <option value="5">Elysium Communication</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3 business_div" style="display: none;">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                            <select id="entity_name" name="entity_name" class="select3 form-select">
                                <option value="">Select Entity Name</option>
                                <option value="1">Elysium Academy</option>
                                <option value="2">E-Pro</option>
                                <option value="3" selected>Click My Project</option>
                                <option value="4">Elysian Intelligence Business Solution</option>
                                <option value="5">SEO Business</option>
                                <option value="6">PhD iZone</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                            <div class="management_div" style="display: none;">
                                <select id="" name="department" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1">HR Management</option>
                                    <option value="2">Accounts & Finance</option>
                                    <option value="3">Corporate Admin</option>
                                    <option value="4">IT Support</option>
                                </select>
                            </div>
                            <div class="business_div" style="display: none;">
                                <select id="" name="department" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1">Management</option>
                                    <option value="2" selected>Sales</option>
                                    <option value="3">Production</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division<span class="text-danger">*</span></label>
                            <div class="management_div" style="display: none;">
                                <select id="" name="division" class="select3 form-select">
                                    <option value="">Select Division</option>
                                    <option value="1">HR Recruitment</option>
                                    <option value="2">HR Operation</option>
                                    <option value="3">HR Assessment</option>
                                    <option value="4">HR Training</option>
                                </select>
                            </div>
                            <div class="business_div" style="display: none;">
                                <select id="" name="division" class="select3 form-select">
                                    <option value="">Select Division</option>
                                    <option value="1">Internal Managment</option>
                                    <option value="2" selected>Business Management</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                            <div class="management_div" style="display: none;">
                                <select id="" name="job_role" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1">HR Assistant</option>
                                    <option value="2">Recruitor</option>
                                    <option value="3">HR Executive</option>
                                    <option value="4">HR Manager</option>
                                </select>
                            </div>
                            <div class="business_div" style="display: none;">
                                <select id="" name="job_role" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1">Sales Executives</option>
                                    <option value="2">Developer</option>
                                    <option value="3">CRE</option>
                                    <option value="4" selected>Business Development Executives</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="fs-5 text-primary fw-bold">Educational Details</label>
                </div>
                <div class="col-lg-12 mb-3">
                    <div id="education-wrapper" class=" scroll-y" style="max-height:300px;overflow-x:hidden;">
                        <div class="education-row">
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Qualification Type<span class="text-danger">*</span></label>
                                    <select id="qualification_type_0" name="qualification_type[]" class="select3 form-select">
                                        <option value="">Select Qualification Type</option>
                                        <option value="1">Doctrate</option>
                                        <option value="2">M.Phil</option>
                                        <option value="3">Post Graduate</option>
                                        <option value="4" selected>Under Graduate</option>
                                        <option value="5">Diploma</option>
                                        <option value="6">HSC</option>
                                        <option value="7">SSLC</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Degree<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="degree[]" placeholder="Enter Degree" value="BBA" />
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Major<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="major[]" placeholder="Enter Major" value="Finance" />
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Institute / University Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="univ_name[]" placeholder="Enter Institute / University Name" value="MKU" />
                                </div>
                                <div class="col-lg-1 d-flex align-items-end mb-3">
                                    <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_edu_del" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="mb-1 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary" id="add-edu-btn">
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="fs-5 text-primary fw-bold">Work Details</label>
                </div>
                <div class="col-lg-12 mb-3">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                            <select id="work_type" name="work_type" class="select3 form-select">
                                <option value="">Select Type</option>
                                <option value="1">Fresher</option>
                                <option value="2" selected>Experience</option>
                            </select>
                        </div>
                    </div>
                    <div id="work-exp-wrapper"  class="scroll-y" style="max-height:300px;overflow-x:hidden;">
                        <div class="work-exp-row">
                            <div class="row">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Position<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="position[]" placeholder="Enter Position" value="Business Manager"/>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Experience Years<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="exp_yrs[]" placeholder="Enter Experience Years" value="2 years" />
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="company_name[]" placeholder="Enter Company Name" value="Global Corporate"/>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Salary<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="salary[]" placeholder="Enter Salary" />
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="work_st_date" name="work_st_date[]" placeholder="Select Date" class="form-control common_datepicker"
                                                    value="12-08-2020" />
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="work_end_date" name="work_end_date[]" placeholder="Select Date" class="form-control common_datepicker"
                                                    value="25-07-2022" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1 d-flex align-items-center mb-3">
                                    <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_work_del" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="row work-exp-div">
                        <div class="mb-1 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary" id="add-work-btn">
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="fs-5 text-primary fw-bold">Designation Details</label>
                </div>
                <div class="col-lg-12 mb-3">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pseudo Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="pseudo_name" name="pseudo_name"
                                placeholder="Enter Pseudo Name" value="Karthik"
                                oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date of Joining<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="staff_doj" name="doj" autocomplete="off" placeholder="Select Date" class="form-control common_datepicker"
                                    value="15-09-2024" />
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Job Position<span class="text-danger">*</span></label>
                            <select id="job_position" name="job_position" class="select3 form-select">
                                <option value="">Select Job Position</option>
                                <option value="1" selected>Senior Recruitor</option>
                                <option value="2">Recruiter Trainer</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="basic_salary" name="basic_salary"
                                placeholder="Enter Basic Salary" value="35,000"/>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="per_hr_cost" name="per_hr_cost"
                                placeholder="Enter Per Hour Cost" value="145"/>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Skill Tag<span class="text-danger">*</span></label>
                            <div class="form-floating form-floating-outline">
                                <input id="skill_tag" name="skill_tag" class="form-control h-auto skill_tag" row="1" placeholder="Select Product Tags" value="Managing">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" id="login_access" name="login_access"
                                    onclick="login_func();" value="1" checked/><span id="user_name_label">Login
                                    Credentials
                                </span><span class="text-danger login_fields">*</span>
                            </label>
                            <input type="text" class="form-control login_fields" id="loginuser_name" name="loginuser_name" value="mahesh"
                                placeholder="Enter User Name" onkeyup="user_name_chk(this.value)" />
                        </div>
                        <div class="col-lg-4 mb-3 login_fields">
                            <label class="text-black mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                            <div class="form-password-toggle">
                                <div class="input-group input-group-merge">
                                    <input type="password" class="form-control" id="loginpassword" name="loginpassword"
                                        placeholder="Enter Password" aria-describedby="password" value="mahesh1602" />
                                    <span class="input-group-text cursor-pointer"><i
                                            class="mdi mdi-eye-off-outline fs-4"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" id="other_access" name="other_access" checked data-bs-toggle="modal" data-bs-target="#kt_modal_other_credentials"/>Other Credentials
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between">
                <a href="{{url('/hr_enroll/manage_staff')}}" class="btn btn-outline-danger text-primary fw-bold">Cancel</a>
                <a href="javascript:;" type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_confirmation_staff">Update Staff</a>
            </div>
       </div>
    </div>
</div>

<!--begin::Modal - Other Credentials-->
<div class="modal fade" id="kt_modal_other_credentials" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
             <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Other Credentials</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mt-2">
                        <div class="col-lg-12 mb-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="skype_id" data-cred="skype" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Teams</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="spark_id" data-cred="spark" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Spark</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="firewall_id" data-cred="firewall" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Firewall</label>
                            </div>
                        </div>
                        <div class="mb-2" id="skype_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Teams Credentials</h5>
                            <div class="row mt-2">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="spark_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Spark Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="firewall_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Firewall Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Password<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <button type="reset" class="btn btn-outline-danger me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Give Access</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Other Credentials-->

<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
            </div>
            <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure you want to
                Update Staff ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label class="text-black">Mahesh</label>
                    <span class="ms-2 me-2">-</span>
                    <label class="text-black">EGCS-0001/24</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                <a href="{{url ('/hr_enroll/manage_staff')}}" class="btn btn-success me-3">Yes</a>
                <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->

<!--Staff Add Credentials Accordion Start-->
<script>
    'use strict';

    (function () {
        // Accordion toggle
        const credentials_acrd = document.querySelectorAll('.credentials_acrd');
        credentials_acrd.forEach(el => {
            el.addEventListener('click', event => {
                event.preventDefault();
                const card = el.closest('.card');
                const collapseEl = card.querySelector('.collapse.credentials_acrd_body');

                new bootstrap.Collapse(collapseEl);
                card.querySelector('.card-header').classList.toggle('collapsed');
                Helpers._toggleClass(el.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
            });
        });

        // Generic credential toggle
        function toggleCredential(id, show) {
            const section = document.getElementById(id + '_cred');
            if (section) section.style.display = show ? 'block' : 'none';
        }

        // Select All
        document.getElementById('credential_check_all')?.addEventListener('change', function () {
            const checked = this.checked;
            document.querySelectorAll('.cred_check').forEach(cb => {
                cb.checked = checked;
                toggleCredential(cb.dataset.cred, checked);
            });
        });

        // Individual checkbox handling
        document.querySelectorAll('.cred_check').forEach(cb => {
            cb.addEventListener('change', function () {
                toggleCredential(this.dataset.cred, this.checked);
            });
        });

        // Dropdown-based create credential
        document.getElementById('create_cred')?.addEventListener('change', function () {
            const value = this.value;
            ['skype', 'spark', 'firewall'].forEach(id => {
                toggleCredential(id, id === value);
            });
        });
    })();
</script>


<script>
    $(document).ready(function () {
        // Run once on load
        toggleDivs();

        // Change event on radio buttons
        $("input[name='company']").on("change", function () {
            toggleDivs();
        });

        function toggleDivs() {
            if ($("#management").is(":checked")) {
                $(".management_div").show();
                $(".business_div").hide();
            } else if ($("#business").is(":checked")) {
                $(".business_div").show();
                $(".management_div").hide();
            }
        }
    });
</script>

<script>
    $(document).ready(function () {
        let eduIndex = 1; // unique IDs for selects

        // Initialize the first select3
        $(".select3").select2();

        // Add More Education
        $("#add-edu-btn").click(function () {
            let clone = $(".education-row:first").clone(false, false); // clone without events

            // reset values
            clone.find("input").val("");
            clone.find("select").val("");

            // find select
            let newSelect = clone.find("select.select3");

            // remove any cloned select2 container if present
            clone.find(".select2").remove();  
            newSelect.show(); // make sure <select> is visible

            // assign unique id
            newSelect.attr("id", "qualification_type_" + eduIndex);
            eduIndex++;

            // re-init select2
            newSelect.select2();

            // show delete button
            clone.find(".staff_edu_del").show();

            // append to wrapper
            $("#education-wrapper").append(clone);
        });

        // Delete Education Row
        $(document).on("click", ".staff_edu_del", function () {
            $(this).closest(".education-row").remove();
        });
    });
</script>

<script>
    login_func()

    function login_func() {

        var login_access = document.getElementById("login_access");
        if (login_access.checked) {
            $('#user_name_label').html('Username');
            $('.login_fields').show();
        } else {
            $('#user_name_label').html('Login Credentials');
            $('.login_fields').hide();
        }
    }
</script>

<script>
    $(document).ready(function () {
        // Hide wrapper by default
        $("#work-exp-wrapper").hide();
        $("#add-work-btn").hide();
        $(".work-exp-div").hide();

        // Handle type change
        $("#work_type").change(function () {
            if ($(this).val() === "2") {
                // Experience selected
                $("#work-exp-wrapper").show();
                $("#add-work-btn").show();
                $(".work-exp-div").show();
            } else {
                // Fresher selected
                $("#work-exp-wrapper").hide();
                $("#add-work-btn").hide();
                $(".work-exp-div").hide();

                // Reset rows to only the first one (clean form)
                $("#work-exp-wrapper .work-exp-row:not(:first)").remove();
                $("#work-exp-wrapper")
                    .find("input")
                    .val(""); // clear inputs
                $("#work-exp-wrapper .staff_work_del").hide(); // hide delete button in first row
            }
        });

        // Add More Work Experience
        $("#add-work-btn").click(function () {
            let clone = $(".work-exp-row:first").clone(false, false);

            // clear values
            clone.find("input").val("");

            // show delete button
            clone.find(".staff_work_del").show();

            // append
            $("#work-exp-wrapper").append(clone);

            // re-init datepicker if needed
            clone.find(".common_datepicker").datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true
            });
        });

        // Delete Work Row
        $(document).on("click", ".staff_work_del", function () {
            $(this).closest(".work-exp-row").remove();
        });

        // Initialize first datepickers
        $(".common_datepicker").datepicker({
            format: "yyyy-mm-dd",
            autoclose: true,
            todayHighlight: true
        });
    });
</script>


@endsection
