@extends('layouts/blankLayout')
@section('title', 'Not Eligible')
@section('content')

<style>
    body {
        background: linear-gradient(135deg, #f2f2f2 0%, #e6f7ff 100%);
        font-family: 'Inter', sans-serif;
    }
</style>

<div class="container my-5 ">
    <div class="row justify-content-center" >
        <div class="col-lg-6 col-md-8 col-sm-10">

            <div class="card shadow-lg border-0 rounded-4 text-center p-4">

                {{-- Warning Icon --}}
                <div class="mb-4">
                    <div class="rounded-circle bg-warning d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                        <i class="mdi mdi-alert text-white fs-2"></i>
                    </div>
                </div>

                {{-- Title --}}
                <h3 class="fw-bold mb-3">Not Eligible for Interview</h3>

                {{-- Dynamic Message --}}
                <p class="text-muted fs-6 mb-3">
                    Sorry <span class="fw-semibold text-primary">{{ $applicant_name ?? 'Candidate' }}</span>, you are not eligible for the interview for the 
                    <span class="fw-semibold text-danger">{{ $job_role_name ?? 'selected job' }}</span> role.
                </p>

                {{-- Guidance --}}
                <p class="text-muted mb-4">
                    If you have any questions, please contact us:
                </p>

                {{-- Contact Info --}}
                <div class="d-flex flex-column align-items-center gap-2">
                    <p class="mb-0">
                        <i class="mdi mdi-phone me-2"></i>
                        <a href="tel:+91{{$hr_mobile}}" class="text-decoration-none text-primary">+91 {{$hr_mobile}}</a>
                    </p>
                    <p class="mb-0">
                        <i class="mdi mdi-email me-2"></i>
                        <!-- <a href="mailto:{{ $hr_email }}" class="text-decoration-none text-primary" >
                            {{ $hr_email }}
                             
                        </a> -->
                        <a href="https://mail.google.com/mail/?view=cm&to={{ $hr_email }}" class="text-decoration-none text-primary">
                            {{ $hr_email }}
                        </a>
                        
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>

@endsection