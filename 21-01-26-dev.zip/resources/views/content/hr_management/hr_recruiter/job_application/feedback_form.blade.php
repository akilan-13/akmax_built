<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Feedback - {{$applicant->applicant_name}}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

     <!-- Minimal Favicon Setup -->
    <link rel="icon" href="{{ asset('assets/common/logo_small.png') }}" type="image/png">
    <link rel="apple-touch-icon" href="{{ asset('assets/common/logo_small.png') }}">

    <!-- Add to homescreen meta tags -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

  <style>
    /* Mobile-First CSS Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
    }

    :root {
        --primary: #ab2b22;
        --primary-light: #ffbeb6;
        --primary-dark: #3a56d4;
        --success: #2ecc71;
        --success-light: #e8f8ef;
        --danger: #e74c3c;
        --danger-light: #fdedec;
        --warning: #fba919;
        --dark: #2c3e50;
        --light: #f8f9fa;
        --gray: #95a5a6;
        --border: #e1e8ed;
        --shadow: 0 2px 10px rgba(0,0,0,0.08);
        --shadow-lg: 0 5px 20px rgba(0,0,0,0.15);
        --radius: 16px;
        --radius-sm: 8px;
        --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        background: linear-gradient(135deg, #f5f7fb 0%, #e8edff 100%);
        color: var(--dark);
        line-height: 1.5;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        overflow-x: hidden;
        min-height: 100vh;
        padding-bottom: env(safe-area-inset-bottom);
    }

    /* Safe area for iPhone X+ */
    @supports (padding: max(0px)) {
        body {
            padding-left: max(0px, env(safe-area-inset-left));
            padding-right: max(0px, env(safe-area-inset-right));
        }
    }

    /* Main Container */
    .container {
        max-width: 100%;
        padding: 0;
        margin: 0 auto;
        min-height: 100vh;
    }

    /* Curved Header Background */
    .header-background {
        background: linear-gradient(135deg, var(--warning), #ab2b22);
        height: 160px;
        border-bottom-left-radius: 40px;
        border-bottom-right-radius: 40px;
        position: relative;
        overflow: hidden;
        padding: 20px;
        padding-top: max(40px, env(safe-area-inset-top));
        box-shadow: 0 4px 20px rgba(67, 97, 238, 0.3);
    }

    .header-background::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 100px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        transform: translateY(-50%);
    }

    /* Enhanced Language Selector */
    .language-selector {
        background: white;
        border-radius: var(--radius);
        padding: 25px;
        margin: 20px;
        box-shadow: var(--shadow-lg);
        border: none;
        position: relative;
        z-index: 10;
    }

    @media (min-width: 768px) {
        .language-selector {
            max-width: 500px;
            margin: 30px auto;
        }
    }

    .language-header {
        text-align: center;
        margin-bottom: 25px;
        color: var(--primary);
        font-size: 22px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
    }

    .language-header i {
        font-size: 28px;
        margin-top:6px
    }

    .language-dropdown-container {
        position: relative;
        margin-bottom: 15px;
    }


    .custom-select {
        position: relative;
        width: 100%;
    }

    .custom-select-trigger {
        padding: 18px 20px;
        border: 2px solid var(--primary-light);
        border-radius: var(--radius);
        background: #fff;
        font-size: 17px;
        font-weight: 600;
        color: var(--dark);
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(67, 97, 238, 0.1);
        background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%234361ee' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 20px center;
        background-size: 24px;
    }

    .custom-options {
      position: absolute;
      width: 100%;
      background: white;
      border: 2px solid var(--primary-light);
      border-radius: var(--radius);
      margin-top: 6px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.12);
      display: none;
      max-height: 250px;
      overflow-y: auto;
      z-index: 99999;
    }

    .custom-select.open .custom-options {
        display: block;
    }

    .custom-option {
        padding: 15px 20px;
        font-size: 16px;
        cursor: pointer;
        transition: 0.2s;
    }

    .custom-option:hover {
        background: rgba(67, 97, 238, 0.08);
    }

    .custom-option.selected {
        background: rgba(67, 97, 238, 0.15);
        font-weight: 700;
    }


    .language-note {
        /* text-align: center; */
        font-size: 14px;
        color: var(--gray);
        margin-top: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    /* Company Logo in Curved Header */
    .logo-center {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 80px;
        position: relative;
        z-index: 2;
        margin-bottom: 20px;
       
    }

    .logo-center img {
        max-height: 60px;
        max-width: 200px;
        object-fit: contain;
        filter: drop-shadow(0 2px 8px rgba(0,0,0,0.1));
        background:white;
        border-radius:8px;
        padding:5px 10px;
    }

    /* Sticky Header Section */
    .sticky-header {
        position: sticky;
        top: 0;
        z-index: 100;
        /* background: white; */
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        border-bottom-left-radius: 20px;
        border-bottom-right-radius: 20px;
        /* padding: 15px 0 10px; */
        margin-bottom: 15px;
    }

    /* Student Profile */
    .student-info {
        background: white;
        margin: -40px 20px 20px;
        padding: 13px;
        border-radius: var(--radius);
        box-shadow: var(--shadow-lg);
        position: relative;
        z-index: 5;
    }

    .student-profile {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .student-pic {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid var(--primary-light);
        box-shadow: 0 4px 12px rgba(171, 43, 34, 0.2);
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        flex-shrink: 0;
    }

    @media (min-width: 768px) {
        .student-pic {
            width: 80px;
            height: 80px;
        }
    }

    .student-pic img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .student-pic.fallback {
        background: linear-gradient(135deg, var(--primary), #fba919);
        color: white;
        font-size: 24px;
        font-weight: bold;
    }

    .student-details {
        flex: 1;
        min-width: 0;
    }

    .student-name {
        font-size: 22px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 5px;
    }

    .student-subtitle {
        color: var(--gray);
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Enhanced Sticky Section Tabs */
    .section-tabs-container {
        position: sticky;
        top: 0;
        z-index: 90;
        background: white;
        padding: 12px 0;
        box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        margin-bottom: 10px;
    }

    @media (max-height: 700px) {
        .section-tabs-container {
            top: 0;
        }
    }

    .section-tabs {
        display: flex;
        overflow-x: auto;
        gap: 8px;
        padding: 0 20px;
        scrollbar-width: none;
        -ms-overflow-style: none;
        scroll-padding-left: 20px;
    }

    .section-tabs::-webkit-scrollbar {
        display: none;
    }

    .section-tab {
        padding: 14px 22px;
        background: white;
        border-radius: 50px;
        font-weight: 600;
        font-size: 14px;
        color: var(--gray);
        white-space: nowrap;
        border: 2px solid var(--border);
        cursor: pointer;
        transition: var(--transition);
        flex-shrink: 0;
        position: relative;
        overflow: hidden;
    }

    @media (min-width: 768px) {
        .section-tabs {
            justify-content: center;
        }

        .section-tab {
            padding: 16px 24px;
            font-size: 15px;
        }
    }

    .section-tab::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 3px;
        background: var(--primary);
        transition: var(--transition);
    }

    .section-tab:hover {
        border-color: var(--primary-light);
    }

    .section-tab.active {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(67, 97, 238, 0.2);
    }

    .section-tab.active::after {
        width: 80%;
    }

    .section-tab.completed {
        background: var(--success-light);
        border-color: var(--success);
        color: var(--success);
    }

    /* Current Section Info - Sticky */
    .current-section-container {
        position: sticky;
        top: 65px;
        z-index: 80;
        background: white;
        padding: 15px 20px;
        margin: 0;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        border-left: 4px solid var(--primary);
        margin-bottom: 20px;
    }

    @media (min-width: 768px) {
        .current-section-container {
            top: 70px;
        }
    }

    @media (max-height: 700px) {
        .current-section-container {
            top: 55px;
        }
    }

    .current-section {
        display: flex;
        align-items: center;
        gap: 15px;
        background: transparent;
        padding: 0;
        margin: 0;
        box-shadow: none;
        border: none;
    }

    .section-icon {
        width: 45px;
        height: 45px;
        background: linear-gradient(135deg, var(--primary), #fba919);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 18px;
        box-shadow: 0 4px 12px rgba(171, 43, 34, 0.3);
    }

    .section-info {
        flex: 1;
    }

    .section-info h3 {
        font-size: 17px;
        font-weight: 700;
        margin-bottom: 6px;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .section-info p {
        font-size: 14px;
        color: var(--gray);
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* Progress Indicator */
    .section-progress {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 8px;
    }

    .progress-bar-section {
        flex: 1;
        height: 6px;
        background: var(--border);
        border-radius: 3px;
        overflow: hidden;
    }

    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--primary), #fba919);
        border-radius: 3px;
        transition: width 0.5s ease;
    }

    .progress-text {
        font-size: 12px;
        font-weight: 600;
        color: var(--primary);
        white-space: nowrap;
    }

    /* Questions Container */
    .questions-container {
        padding: 0 20px 140px;
        position: relative;
        z-index: 1;
    }

    @media (min-width: 1024px) {
        .questions-container {
            padding: 0 40px 120px;
        }
    }

    /* Enhanced Question Card */
    .question-card {
        background: white;
        border-radius: var(--radius);
        margin-bottom: 20px;
        padding: 18px;
        box-shadow: var(--shadow);
        border: 2px solid transparent;
        position: relative;
        transition: var(--transition);
        animation: slideIn 0.4s ease forwards;
        opacity: 0;
    }

    .question-card.active {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
        transform: translateY(-2px);
    }

    .question-number {
        display: flex;
        align-items: center;
        gap: 12px;
        /* margin-bottom: 16px; */
    }

    .number-circle {
        width: 32px;
        height: 32px;
        background: var(--primary-light);
        color: var(--primary);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 15px;
        flex-shrink: 0;
    }

    .question-text {
        font-size: 14px;
        margin-bottom:6px;
        font-weight: 600;
        line-height: 1.4;
        color: var(--dark);
        flex: 1;
    }

    /* Answer Options */
    .options-container {
        margin-top: 15px;
    }

    .yesno-options {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 15px;
    }

    .yesno-option {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 10px;
        border-radius: var(--radius);
        border: 2px solid var(--border);
        background: white;
        transition: var(--transition);
        cursor: pointer;
        text-align: center;
        min-height: 100px;
    }

    .yesno-option.selected-yes {
        border-color: var(--success);
        background: var(--success-light);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(46, 204, 113, 0.15);
    }

    .yesno-option.selected-no {
        border-color: var(--danger);
        background: var(--danger-light);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(231, 76, 60, 0.15);
    }

    .yesno-option i {
        font-size: 32px;
        margin-bottom: 8px;
    }

    .yesno-option.selected-yes i {
        color: var(--success);
    }

    .yesno-option.selected-no i {
        color: var(--danger);
    }

    /* Rating Slider */
    /* .rating-container {
        padding: 15px 0;
    } */

    .emoji-scale {
        display: flex;
        justify-content: space-between;
        /* margin-bottom: 15px; */
        overflow-x: auto;
        /* padding-bottom: 10px; */
    }

    .emoji-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 8px 4px;
        border-radius: var(--radius-sm);
        cursor: pointer;
        transition: var(--transition);
        min-width: 50px;
        flex-shrink: 0;
    }

    .emoji-item.active {
        background: var(--primary-light);
        transform: scale(1.1);
    }

    .emoji {
        font-size: 20px;
        margin-bottom: 5px;
        transition: var(--transition);
    }

    .emoji-label {
        font-size: 11px;
        color: var(--gray);
        text-align: center;
        white-space: nowrap;
    }

    .mobile-slider {
        width: 100%;
        height: 8px;
        -webkit-appearance: none;
        appearance: none;
        background: linear-gradient(to right, var(--danger), var(--warning), var(--success));
        border-radius: 4px;
        outline: none;
        margin: 20px 0;
    }

    .mobile-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 44px;
        height: 44px;
        background: white;
        border-radius: 50%;
        border: 4px solid var(--primary);
        box-shadow: 0 3px 12px rgba(0,0,0,0.2);
        cursor: pointer;
        transition: var(--transition);
    }

    .rating-value {
        text-align: center;
        font-size: 18px;
        font-weight: 700;
        color: var(--primary);
        background: var(--primary-light);
        padding: 12px 24px;
        border-radius: 50px;
        display: inline-block;
        margin: 10px auto;
        min-width: 120px;
    }

    /* Multiple Choice Options */
    .mcq-options {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
    }

    @media (min-width: 768px) {
        .mcq-options {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    .mcq-option {
        padding: 16px;
        border: 2px solid var(--border);
        border-radius: var(--radius);
        background: white;
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
        transition: var(--transition);
    }

    .mcq-option.selected {
        border-color: var(--primary);
        background: var(--primary-light);
    }

    .mcq-option .option-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-weight: 700;
        font-size: 16px;
        flex-shrink: 0;
    }

    .mcq-option.selected .option-icon {
        background: var(--primary);
        color: white;
    }

    /* Question Validation */
    .validation-message {
        background: var(--danger-light);
        color: var(--danger);
        padding: 12px 16px;
        border-radius: var(--radius);
        margin: 10px 0 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
        font-size: 14px;
        border: 2px solid var(--danger);
        animation: shake 0.5s ease;
    }

    /* Navigation Footer */
    .navigation-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: white;
        padding: 16px 20px;
        padding-bottom: max(16px, env(safe-area-inset-bottom));
        display: flex;
        gap: 12px;
        box-shadow: 0 -2px 20px rgba(0,0,0,0.1);
        z-index: 1000;
    }

    @media (min-width: 1024px) {
        .navigation-footer {
            padding: 20px 40px;
            padding-bottom: max(20px, env(safe-area-inset-bottom));
        }
    }

    .nav-btn {
        flex: 1;
        padding: 16px;
        border: none;
        border-radius: var(--radius);
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: var(--transition);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        min-height: 56px;
    }

    .nav-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .nav-btn:active:not(:disabled) {
        transform: translateY(2px);
    }

    .btn-prev {
        background: white;
        color: var(--gray);
        border: 2px solid var(--border);
    }

    .btn-next {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
        border: none;
        box-shadow: var(--shadow);
    }

    .btn-submit {
        background:  var(--primary);
        color: white;
        border: none;
        box-shadow: var(--shadow);
    }

    /* Thank You Screen */
    .thank-you-container {
        padding: 40px 20px;
        min-height: 70vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
    }

    .success-animation {
        width: 120px;
        height: 120px;
        background: linear-gradient(135deg, var(--success), #27ae60);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 30px;
        animation: scaleIn 0.6s ease, float 3s ease-in-out infinite;
    }

    .success-animation i {
        font-size: 50px;
        color: white;
    }

    .thank-you-title {
        font-size: 24px;
        font-weight: 800;
        color: var(--dark);
        margin-bottom: 15px;
        background: linear-gradient(135deg, var(--primary), #fba919);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Loading States */
    .loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 60px 20px;
        gap: 20px;
    }

    .loader {
        width: 60px;
        height: 60px;
        border: 4px solid var(--primary-light);
        border-top-color: var(--primary);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    /* Animations */
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes scaleIn {
        from {
            transform: scale(0);
            opacity: 0;
        }
        to {
            transform: scale(1);
            opacity: 1;
        }
    }

    @keyframes float {
        0%, 100% {
            transform: translateY(0);
        }
        50% {
            transform: translateY(-10px);
        }
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }

    /* Touch Optimizations */
    @media (hover: none) and (pointer: coarse) {
        .yesno-option,
        .mcq-option,
        .emoji-item {
            min-height: 44px;
        }

        .nav-btn {
            min-height: 56px;
        }

        .mobile-slider::-webkit-slider-thumb {
            width: 48px;
            height: 48px;
        }
    }

    /* Container Responsive */
    @media (min-width: 768px) {
        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .header-background {
            height: 180px;
            border-bottom-left-radius: 50px;
            border-bottom-right-radius: 50px;
        }
    }

    @media (min-width: 1024px) {
        .container {
            max-width: 800px;
        }
    }

    /* Dark Mode */
    @media (prefers-color-scheme: dark) {
        :root {
            --dark: #ecf0f1;
            --light: #2c3e50;
            --border: #34495e;
            --gray: #bdc3c7;
            --primary-light: rgba(67, 97, 238, 0.2);
        }

        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }

        .header-background {
            background: linear-gradient(135deg, #fba919, #ab2b22);
        }

        .language-selector,
        .student-info,
        .question-card,
        .current-section-container,
        .section-tab {
            background: #2c3e50;
            border-color: #34495e;
        }

        .navigation-footer {
            background: #2c3e50;
        }

        .btn-prev {
            background: #34495e;
            border-color: #4a6278;
            color: #ecf0f1;
        }
    }

    /* radio */
    /* Inline wrapper */
    .language-inline-wrap {
        display: flex;
        align-items: center;
        gap: 40px;
        flex-wrap: wrap; /* mobile friendly */
    }

    /* Radios inline */
    .language-radio-container {
        display: flex;
        align-items: center;
        gap: 16px;
        margin-top: 0;
        margin-left:30px
    }

    /* Radio item */
    .language-radio {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        font-size: 15px;
    }

    /* Hide native radio */
    .language-radio input {
        display: none;
    }

    /* Custom radio */
    .radio-custom {
        width: 22px;
        height: 22px;
        border: 2px solid #ddd;
        border-radius: 50%;
        position: relative;
    }

    /* Checked dot */
    .language-radio input:checked + .radio-custom::after {
        content: '';
        width: 10px;
        height: 10px;
        background: #fba919;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    /* Label */
    .radio-label {
        font-weight: 500;
        white-space: nowrap;
    }

    /* Go button */
    #languageSubmit {
        padding: 8px 20px;
        font-size: 1rem;
        font-weight: 700;
        color: #fff;
        background-color: var(--primary);
        border: none;
        border-radius: 13px;
        cursor: pointer;
        transition: background 0.3s, transform 0.2s;
    }

    #languageSubmit:hover {
        transform: translateY(-2px);
    }

    #languageSubmit:active {
        transform: translateY(0);
    }
    /* poppers */
    #confettiCanvas {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
    }

  </style>
</head>

<body>
    <div class="container">
      @if(!$feedback_submitted)
        <!-- Language Selection Screen -->
        <div id="feedbackContainer">
            <div class="header-background">
                <div class="logo-center">
                    <img src="{{ asset('assets/common/logo_full.png') }}" alt="Company Logo">
                </div>
            </div>
            <div class="student-info">
                <div class="student-profile">
                    <div class="student-pic">
                        @if($applicant->cus_pic)
                            <img src="{{ asset('cus_pics/' . $applicant->cus_pic) }}" alt="{{$applicant->applicant_name}}"
                                onerror="this.style.display='none'; this.parentElement.classList.add('fallback'); this.parentElement.innerHTML='{{ substr($applicant->applicant_name, 0, 1) }}';">
                        @else
                            <div class="fallback" style="font-weight:bold;color:#ab2b22;">{{ substr($applicant->applicant_name, 0, 1) }}</div>
                        @endif
                    </div>
                    <div class="student-details">
                        <div class="student-name">{{$applicant->applicant_name}}</div>
                        <div class="student-subtitle">
                            <i class="fas fa-comment-dots"></i>
                            <span>Share your valuable feedback</span>
                        </div>
                    </div>
                </div>
            </div>
            <div id="languageScreen" class="language-selector">

                <div class="language-header">
                    <i class="fa-solid fa-language"></i>
                    <h4>Select Your Language</h4>
                </div>

                <div class="language-inline-wrap">
                    <div class="language-radio-container">
                        @foreach($languages as $language)
                            <label class="language-radio">
                                <input
                                    type="radio"
                                    name="language"
                                    value="{{ $language->language_id }}"
                                    {{ strtolower($language->name) === 'english' ? 'checked' : '' }}
                                >
                                <span class="radio-custom"></span>
                                <span class="radio-label">{{ $language->name }}</span>
                            </label>
                        @endforeach
                    </div>

                    <button id="languageSubmit" class="btn btn-primary">Go</button>
                </div>

                <!-- Hidden input (keeps your existing JS intact) -->
                <input type="hidden" id="languageSelect" />

                <div class="language-note">
                    <i class="fas fa-info-circle"></i>
                    <span>Your questions will be displayed in the selected language</span>
                </div>
            </div>
        </div>
      @endif
        <!-- Main App Screen (Hidden initially) -->
        <div id="appScreen" style="display: none;">
            <!-- Sticky Section Tabs -->
            <div class="section-tabs-container" style="display:none;">
                <div class="section-tabs" id="sectionTabs">
                    <!-- Sections will be loaded dynamically -->
                </div>
            </div>
            <!-- Sticky Header Section -->
            <div class="sticky-header">
              <!-- Sticky Current Section Info -->
              <div class="current-section-container" id="currentSectionInfo">
                  <div class="current-section">
                      <div class="section-icon" id="currentSectionIcon">1</div>
                      <div class="section-info">
                          <h3><i class="fas fa-layer-group"></i> <span id="currentSectionTitle">Loading Section...</span></h3>
                          <p><i class="fas fa-question-circle"></i> <span id="currentSectionDesc">Please wait while we load your questions</span></p>
                          <div class="section-progress" id="sectionProgress" style="display: none;">
                              <div class="progress-bar-section">
                                  <div class="progress-fill" id="sectionProgressFill"></div>
                              </div>
                              <div class="progress-text" id="sectionProgressText">0/0</div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>

            <!-- Questions Container -->
            <main class="questions-container" id="questionsContainer">
                <!-- Questions will be loaded dynamically -->
            </main>

            <!-- Navigation Footer -->
            <div class="navigation-footer" id="navigationFooter">
                <button class="nav-btn btn-prev" id="prevBtn" onclick="FeedbackApp.prevSection()" disabled>
                    <i class="fas fa-arrow-left"></i>
                    <span>Previous</span>
                </button>
                <button class="nav-btn btn-next" id="nextBtn" onclick="FeedbackApp.nextSection()" disabled>
                    <span>Next Section</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
                <button class="nav-btn btn-submit" id="submitBtn" onclick="FeedbackApp.submitFeedback()" style="display: none;">
                    <i class="fas fa-paper-plane"></i>
                    <span>Submit Feedback</span>
                </button>
            </div>
        </div>

        <!-- Thank You Screen -->
        <div id="thankYouScreen" style="display: none;"></div>


    </div>
    <script src="https://cdn.jsdelivr.net/npm/tsparticles@3/tsparticles.bundle.min.js"></script>
 <script>
   document.addEventListener("DOMContentLoaded", () => {
      const radios = document.querySelectorAll('input[name="language"]');
      const realSelect = document.getElementById("languageSelect");
      const submitBtn = document.getElementById("languageSubmit");

      function applyLanguage(value) {
          realSelect.value = value;
          if (window.FeedbackApp) {
              FeedbackApp.selectLanguage(value);
          }
      }

      // Set default value (English)
      const defaultRadio = document.querySelector('input[name="language"]:checked');
      if (defaultRadio) {
          realSelect.value = defaultRadio.value;
      }

      // Submit button click
        if(submitBtn){
            submitBtn.addEventListener('click', () => {
                const selectedRadio = document.querySelector('input[name="language"]:checked');
                if (selectedRadio) {
                    applyLanguage(selectedRadio.value);
                }
            });
        }
  });

</script>


  <script>
    // Pass PHP variables to JavaScript
    const CUSTOMER_ID = "{{$applicant->sno}}";
    const BATCH_ID = "{{$applicant->interview_schedule_stage_id}}";
    const CATEGORY_ID = "{{$applicant->interview_category_id}}";
    const SCHEDULE_ID = "{{$applicant->interview_schedule_id}}";
    const category_name = "{{$applicant->interview_category_name}}";
    const FEEDBACK_SUBMITTED = {{ $feedback_submitted ? 'true' : 'false' }};
    window.COUPON = "{{ $coupon ?? '' }}";
    window.PERCENTAGE = "{{ $percentage ?? '' }}";

    // Mobile-optimized feedback system with wizard sections
    const FeedbackApp = {
        config: {
            yesNoOptions: [
                {
                    type: 'yes',
                    icon: 'fa-smile',
                    text: 'Yes',
                    desc: 'I understand clearly',
                    color: 'var(--success)',
                    bgColor: 'var(--success-light)'
                },
                {
                    type: 'no',
                    icon: 'fa-frown',
                    text: 'No',
                    desc: 'I need clarification',
                    color: 'var(--danger)',
                    bgColor: 'var(--danger-light)'
                }
            ],
            ratingEmojis: [
                { emoji: '😡', label: 'Poor', value: 1 },
                { emoji: '😠', label: 'Fair', value: 2 },
                { emoji: '😐', label: 'Okay', value: 3 },
                { emoji: '😄', label: 'Good', value: 4 },
                { emoji: '🤩', label: 'Excellent', value: 5 }
            ]
        },

        state: {
            languageId: null,
            questions: [],
            sections: [],
            answers: {},
            currentSectionIndex: 0,
            submitted: false,
            csrfToken: '{{ csrf_token() }}'
        },

        init() {
            this.setupEventListeners();

            // Check if feedback already submitted
            if (FEEDBACK_SUBMITTED === true) {
                this.showThankYou();
                return;
            }
        },

        setupEventListeners() {
            document.addEventListener("change", (e) => {
                if (e.target && e.target.id === "languageSelect") {
                    console.log("first");
                    if (e.target.value) {
                        console.log("second");
                        this.selectLanguage(e.target.value);
                    }else{
                        console.log("empty");
                    }
                }
            });
        },


        async selectLanguage(languageId) {
            console.log('Selecting language ID:', languageId);
            this.state.languageId = languageId;

            // Show loading
            const languageScreen = document.getElementById('languageScreen');
            console.log("languageSelect before replace:", document.getElementById("languageSelect"));

            languageScreen.innerHTML = `
                <div class="loading">
                    <div class="loader"></div>
                    <p>Loading questions in your language...</p>
                </div>
            `;
            console.log("languageSelect after replace:", document.getElementById("languageSelect"));


            try {
                // Fetch questions for selected language
                const response = await fetch(`/applicant_feedback_list/${languageId}?applicant_id=${CUSTOMER_ID}&category_id=${CATEGORY_ID}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                console.log('Response status:', response.status);

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                console.log('Response data:', data);

                if (data.status === 200) {
                    this.state.questions = data.data || [];
                    console.log('Questions loaded:', this.state.questions.length);

                    if (this.state.questions.length > 0) {
                        this.processSections();
                        this.showAppScreen();
                    } else {
                        throw new Error('No questions found for this language');
                    }
                } else {
                    throw new Error(data.message || 'Failed to load questions');
                }
            } catch (error) {
                console.error('Error loading questions:', error);
                languageScreen.innerHTML = `
                    <div style="text-align: center; padding: 40px 20px;">
                        <div style="font-size: 48px; color: var(--danger); margin-bottom: 20px;">
                            <i class="fas fa-exclamation-circle"></i>
                        </div>
                        <h3 style="margin-bottom: 10px;">Error Loading Questions</h3>
                        <p style="color: var(--gray); margin-bottom: 20px;">${error.message}</p>
                        <p style="color: var(--gray); margin-bottom: 20px; font-size: 14px;">
                            Language ID: ${languageId}
                        </p>
                        <button onclick="window.location.reload()"
                                style="background: var(--primary); color: white; border: none; padding: 12px 24px; border-radius: var(--radius); font-weight: 600; cursor: pointer; margin: 5px;">
                            Try Again
                        </button>
                        <button onclick="FeedbackApp.resetLanguage()"
                                style="background: var(--gray); color: white; border: none; padding: 12px 24px; border-radius: var(--radius); font-weight: 600; cursor: pointer; margin: 5px;">
                            Change Language
                        </button>
                    </div>
                `;
            }
        },

        resetLanguage() {
            const languageScreen = document.getElementById('languageScreen');
            languageScreen.innerHTML = `
                <h2><i class="fas fa-globe"></i> Select Your Language</h2>
                <select class="language-dropdown" id="languageSelect">
                    <option value="">Choose a language...</option>
                    ${LANGUAGES.map(lang => `
                        <option value="${lang.sno}">${lang.name}</option>
                    `).join('')}
                </select>
            `;

            // Re-attach event listener
            const languageSelect = document.getElementById('languageSelect');
            if (languageSelect) {
                languageSelect.addEventListener('change', (e) => {
                    if (e.target.value) {
                        this.selectLanguage(e.target.value);
                    }
                });
            }
        },

        processSections() {
            // Group questions by section
            const sectionsMap = {};

            this.state.questions.forEach(question => {
                const sectionId = question.section_id;
                if (!sectionsMap[sectionId]) {
                    // Use question.section (not section_name)
                    sectionsMap[sectionId] = {
                        id: sectionId,
                        name: question.section_name  || `Section ${sectionId}`,  // Changed from section_name to section
                        questions: []
                    };
                }
                sectionsMap[sectionId].questions.push(question);
            });

            this.state.sections = Object.values(sectionsMap);
            console.log('Sections processed:', this.state.sections);

            // Render section tabs
            this.renderSectionTabs();

            // Load first section
            this.loadSection(0);
        },

        renderSectionTabs() {
            const sectionTabs = document.getElementById('sectionTabs');
            if (!sectionTabs) return;

            sectionTabs.innerHTML = this.state.sections.map((section, index) => {
                const isCurrent = index === this.state.currentSectionIndex;
                const isCompleted = this.isSectionCompleted(section.id);

                return `
                    <div class="section-tab ${isCurrent ? 'active' : ''} ${isCompleted ? 'completed' : ''}"
                        onclick="FeedbackApp.loadSection(${index})"
                        data-section-id="${section.id}">
                        ${section.name}  <!-- This should now show the section name -->
                    </div>
                `;
            }).join('');
        },

        isSectionCompleted(sectionId) {
            const section = this.state.sections.find(s => s.id === sectionId);
            if (!section) return false;

            return section.questions.every(question => {
                const questionId = `section_${sectionId}_q_${question.sno}`;
                return this.state.answers[questionId] !== undefined;
            });
        },

        showAppScreen() {
            const languageScreen = document.getElementById('languageScreen');
            const appScreen = document.getElementById('appScreen');

            if (languageScreen) languageScreen.style.display = 'none';
            if (appScreen) appScreen.style.display = 'block';
        },

        // Also update the loadSection method to show progress
        loadSection(sectionIndex) {
            if (sectionIndex < 0 || sectionIndex >= this.state.sections.length) {
                console.error('Invalid section index:', sectionIndex);
                return;
            }

            this.state.currentSectionIndex = sectionIndex;
            const section = this.state.sections[sectionIndex];

            // Update current section info
            const sectionIcon = document.getElementById('currentSectionIcon');
            const sectionTitle = document.getElementById('currentSectionTitle');
            const sectionDesc = document.getElementById('currentSectionDesc');

            if (sectionIcon) sectionIcon.textContent = sectionIndex + 1;
            if (sectionTitle) sectionTitle.textContent = section.name;
            if (sectionDesc) sectionDesc.textContent = `${section.questions.length} Questions In This Section`;

            // Update section progress
            this.updateSectionProgress(section);

            // Render section questions
            this.renderSectionQuestions(section);

            // Update navigation buttons
            this.updateNavigationButtons();

            // Update section tabs
            this.renderSectionTabs();

            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        },

        renderSectionQuestions(section) {
            const container = document.getElementById('questionsContainer');
            if (!container) return;

            container.innerHTML = section.questions.map((question, qIndex) => {
                const questionId = `section_${section.id}_q_${question.sno}`;
                const isAnswered = this.state.answers[questionId] !== undefined;

                return `
                    <div class="question-card ${isAnswered ? 'active' : ''}"
                        id="question-${questionId}"
                        style="animation-delay: ${qIndex * 0.1}s"
                        data-question-id="${questionId}"
                        data-question-type="${question.category_question_type}">
                        <div class="question-number">
                            <div class="number-circle">${qIndex + 1}</div>
                            <div class="question-text">${question.category_question_name || 'Question'}</div>
                        </div>
                        ${this.renderAnswerInput(question, questionId, isAnswered)}
                    </div>
                `;
            }).join('');

            // Attach delegated events
            this.attachDelegatedEvents(container);
        },
        attachDelegatedEvents(container) {
            container.addEventListener('click', (e) => {
                const emojiItem = e.target.closest('.emoji-item');
                if (emojiItem) {
                    const questionCard = e.target.closest('.question-card');
                    const questionId = questionCard.dataset.questionId;
                    const value = emojiItem.dataset.value;
                    this.selectRating(questionId, value);
                    return;
                }

                const yesnoOption = e.target.closest('.yesno-option');
                if (yesnoOption) {
                    const questionCard = e.target.closest('.question-card');
                    const questionId = questionCard.dataset.questionId;
                    const type = yesnoOption.dataset.type;
                    this.selectYesNo(questionId, type);
                    return;
                }

                const mcqOption = e.target.closest('.mcq-option');
                if (mcqOption) {
                    const questionCard = e.target.closest('.question-card');
                    const questionId = questionCard.dataset.questionId;
                    const value = mcqOption.dataset.value;
                    this.selectMCQ(questionId, value);
                    return;
                }
            });

            // Optional: touch feedback
            container.querySelectorAll('.yesno-option, .mcq-option, .emoji-item').forEach(el => {
                el.addEventListener('touchstart', () => el.style.transform = 'scale(0.98)');
                el.addEventListener('touchend', () => setTimeout(() => el.style.transform = '', 150));
            });
        },


        renderAnswerInput(question, questionId, isAnswered) {
            const type = question.category_question_type;
            const currentAnswer = this.state.answers[questionId];

            switch(type) {
                case 'yes_no':
                    return this.renderYesNoOptions(questionId, currentAnswer);
                case 'slider':
                    return this.renderSlider(questionId, currentAnswer || 3);
                case 'radio_button':
                    return this.renderRadioOptions(question, questionId, currentAnswer);
                default:
                    return this.renderDefaultInput(questionId);
            }
        },

        renderYesNoOptions(questionId, currentAnswer) {
            return `
                <div class="options-container">
                    <div class="yesno-options">
                        ${this.config.yesNoOptions.map(option => `
                            <div class="yesno-option ${currentAnswer === option.type ? `selected-${option.type}` : ''}"
                                onclick="FeedbackApp.selectYesNo('${questionId}', '${option.type}')">
                                <i class="fas ${option.icon}"></i>
                                <div class="yesno-text">${option.text}</div>
                                <div class="yesno-desc">${option.desc}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        },

        renderSlider(questionId, currentValue) {
            const emoji = this.config.ratingEmojis.find(e => e.value == currentValue) || this.config.ratingEmojis[3];

            return `
                <div class="rating-container">
                    <div class="emoji-scale">
                        ${this.config.ratingEmojis.map(item => `
                            <div class="emoji-item ${item.value == currentValue ? 'active' : ''}"
                                data-click="rating"
                                data-value="${item.value}">
                                <div class="emoji">${item.emoji}</div>
                                <div class="emoji-label">${item.label}</div>
                            </div>
                        `).join('')}
                    </div>

                    <input type="range"
                          min="1"
                          max="5"
                          value="${currentValue}"
                          class="mobile-slider"
                          oninput="FeedbackApp.updateSlider('${questionId}', this.value)"
                          id="slider-${questionId}">

                    <div style="text-align: center;">
                        <span class="rating-value" id="rating-value-${questionId}">${currentValue}/5 - ${emoji.label}</span>
                    </div>
                </div>
            `;
        },

        renderRadioOptions(question, questionId, currentAnswer) {
            let options = [];
            try {
                options = JSON.parse(question.category_question_option || '[]');
            } catch (e) {
                options = [
                    { text: 'Strongly Disagree', value: 1 },
                    { text: 'Disagree', value: 2 },
                    { text: 'Neutral', value: 3 },
                    { text: 'Agree', value: 4 },
                    { text: 'Strongly Agree', value: 5 }
                ];
            }

            return `
                <div class="options-container">
                    <div class="mcq-options">
                        ${options.map((option, index) => {
                            const optionValue = (option.value || option.score || (index + 1)).toString();
                            const optionText = option.text || option.value || `Option ${index + 1}`;
                            const isSelected = currentAnswer === optionValue;

                            return `
                                <div class="mcq-option ${isSelected ? 'selected' : ''}"
                                    onclick="FeedbackApp.selectMCQ('${questionId}', '${optionValue}')"
                                    data-value="${optionValue}">
                                    <div class="option-icon">${String.fromCharCode(65 + index)}</div>
                                    <div class="option-content">
                                        <div class="option-text">${optionText}</div>
                                        ${option.desc ? `<div class="option-desc">${option.desc}</div>` : ''}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        },

        renderDefaultInput(questionId) {
            const currentAnswer = this.state.answers[questionId] || '';
            return `
                <div class="options-container">
                    <textarea class="text-input"
                            placeholder="Type your answer here..."
                            oninput="FeedbackApp.updateTextAnswer('${questionId}', this.value)"
                            style="width: 100%; padding: 16px; border: 2px solid var(--border); border-radius: var(--radius); font-family: inherit; font-size: 16px; min-height: 120px; resize: vertical;"
                            id="textarea-${questionId}">${currentAnswer}</textarea>
                </div>
            `;
        },

        attachQuestionEvents(sectionId) {
            const section = this.state.sections.find(s => s.id === sectionId);
            if (!section) return;

            section.questions.forEach(q => {
                const questionId = `section_${sectionId}_q_${q.sno}`;
                const card = document.getElementById(`question-${questionId}`);
                if (!card) return;

                // Touch feedback
                card.querySelectorAll('.yesno-option, .mcq-option, .emoji-item').forEach(el => {
                    el.addEventListener('touchstart', () => el.style.transform = 'scale(0.98)');
                    el.addEventListener('touchend', () => setTimeout(() => el.style.transform = '', 150));
                });
            });
        },


        // Answer handling methods
        selectYesNo(questionId, answer) {
            this.state.answers[questionId] = answer;
            this.updateQuestionCard(questionId);
            this.checkSectionCompletion();
        },

        selectRating(questionId, value) {
            this.state.answers[questionId] = parseInt(value);
            this.updateSlider(questionId, value);
            this.checkSectionCompletion();
        },

        updateSlider(questionId, value) {
            const intValue = parseInt(value);
            this.state.answers[questionId] = intValue;

            const card = document.getElementById(`question-${questionId}`);
            if (!card) return;

            // Slider
            const slider = card.querySelector('.mobile-slider');
            if (slider) slider.value = intValue;

            // Emoji highlight only inside this question
            card.querySelectorAll('.emoji-item').forEach(item => {
                const itemValue = parseInt(item.getAttribute('data-value'));
                item.classList.toggle('active', itemValue === intValue);
            });

            // Update rating text
            const emoji = this.config.ratingEmojis.find(e => e.value == intValue);
            const ratingValue = card.querySelector(`#rating-value-${questionId}`);
            if (ratingValue && emoji) {
                ratingValue.textContent = `${intValue}/7 - ${emoji.label}`;
            }

            // Update card & section progress
            this.updateQuestionCard(questionId);
            this.checkSectionCompletion();
        },


        selectMCQ(questionId, value) {
            this.state.answers[questionId] = parseInt(value);

            const card = document.getElementById(`question-${questionId}`);
            if (!card) return;

            // Highlight only this question's options
            card.querySelectorAll('.mcq-option').forEach(option => {
                option.classList.toggle('selected', option.getAttribute('data-value') === value);
            });

            this.updateQuestionCard(questionId);
            this.checkSectionCompletion();
        },


        updateTextAnswer(questionId, value) {
            if (value.trim()) {
                this.state.answers[questionId] = value.trim();
            } else {
                delete this.state.answers[questionId];
            }
            this.updateQuestionCard(questionId);
            this.checkSectionCompletion();
        },

        updateQuestionCard(questionId) {
            const card = document.getElementById(`question-${questionId}`);
            if (card) {
                const isAnswered = this.state.answers[questionId] !== undefined;
                card.classList.toggle('active', isAnswered);
            }
        },

        checkSectionCompletion() {
            const currentSection = this.state.sections[this.state.currentSectionIndex];
            const isCompleted = this.isSectionCompleted(currentSection.id);

            // Update section tab
            const sectionTab = document.querySelector(`.section-tab[data-section-id="${currentSection.id}"]`);
            if (sectionTab) {
                sectionTab.classList.toggle('completed', isCompleted);
            }

            // Update progress indicator
            this.updateSectionProgress(currentSection);

            // Update navigation buttons
            this.updateNavigationButtons();

            return isCompleted;
        },

        updateSectionProgress(section) {
            const answeredCount = section.questions.filter(question => {
                const questionId = `section_${section.id}_q_${question.sno}`;
                return this.state.answers[questionId] !== undefined;
            }).length;

            const totalCount = section.questions.length;
            const percentage = totalCount > 0 ? (answeredCount / totalCount) * 100 : 0;

            const progressFill = document.getElementById('sectionProgressFill');
            const progressText = document.getElementById('sectionProgressText');
            const sectionProgress = document.getElementById('sectionProgress');

            if (progressFill && progressText && sectionProgress) {
                progressFill.style.width = `${percentage}%`;
                progressText.textContent = `${answeredCount}/${totalCount}`;
                sectionProgress.style.display = 'flex';
            }
        },
        updateNavigationButtons() {
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            const submitBtn = document.getElementById('submitBtn');

            if (!prevBtn || !nextBtn || !submitBtn) return;

            // Previous button
            prevBtn.disabled = this.state.currentSectionIndex === 0;

            // Next/Submit button
            const currentSection = this.state.sections[this.state.currentSectionIndex];
            const isCurrentSectionComplete = this.isSectionCompleted(currentSection.id);

            if (this.state.currentSectionIndex === this.state.sections.length - 1) {
                // Last section
                nextBtn.style.display = 'none';
                submitBtn.style.display = 'flex';
                submitBtn.disabled = !isCurrentSectionComplete;
            } else {
                // Not last section
                nextBtn.style.display = 'flex';
                submitBtn.style.display = 'none';
                nextBtn.disabled = !isCurrentSectionComplete;
            }
        },

        prevSection() {
            if (this.state.currentSectionIndex > 0) {
                this.loadSection(this.state.currentSectionIndex - 1);
            }
        },

        nextSection() {
            const currentSection = this.state.sections[this.state.currentSectionIndex];

            if (this.isSectionCompleted(currentSection.id)) {
                this.loadSection(this.state.currentSectionIndex + 1);
            } else {
                // Show validation message
                const container = document.getElementById('questionsContainer');
                const validationMsg = document.createElement('div');
                validationMsg.className = 'validation-message';
                validationMsg.innerHTML = `
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Please answer all questions in this section before proceeding to the next section.</span>
                `;

                // Remove any existing validation message
                const existingMsg = container.querySelector('.validation-message');
                if (existingMsg) existingMsg.remove();

                // Add new message at the top
                if (container.firstChild) {
                    container.insertBefore(validationMsg, container.firstChild);
                } else {
                    container.appendChild(validationMsg);
                }

                // Scroll to top to show message
                window.scrollTo({ top: 0, behavior: 'smooth' });

                // Remove message after 5 seconds
                setTimeout(() => {
                    if (validationMsg.parentNode) {
                        validationMsg.remove();
                    }
                }, 5000);
            }
        },


        async submitFeedback() {
          const submitBtn = document.getElementById('submitBtn');
          if (!submitBtn || submitBtn.disabled) return;

          submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
          let originalHTML = ' Submit Feedback';
          submitBtn.disabled = true;

          try {
              const formData = new FormData();

              Object.keys(this.state.answers).forEach(key => {
                  const match = key.match(/section_(\d+)_q_(\d+)/);
                  if (!match) return;

                  const questionId = match[2];
                  const answer = this.state.answers[key];

                  formData.append(`answers[${questionId}][question_id]`, questionId);
                  formData.append(`answers[${questionId}][score]`, answer);
              });

              // FIXED
              formData.append('_token', this.state.csrfToken);
              formData.append('interview_category_id', CATEGORY_ID);
              formData.append('interview_stage_id', BATCH_ID);
              formData.append('interview_schedule_id', SCHEDULE_ID);
              // Get selected language_id
              const languageInput = document.getElementById('languageSelect');
              const language_id = languageInput ? languageInput.value : 15; // default language_id if none selected
              formData.append('language_id', language_id);

              const response = await fetch(`/submit_applicant_feedback/${CUSTOMER_ID}`, {
                  method: 'POST',
                  body: formData,
                  headers: {
                      'X-Requested-With': 'XMLHttpRequest',
                      'Accept': 'application/json'
                  }
              });

              const result = await response.json();

              if (response.ok && result.status === 200) {
                //   window.COUPON = result.coupon || '';
                //   window.PERCENTAGE = result.percentage || '';
                  this.state.submitted = true;
                    let feedbackContainer = document.getElementById('feedbackContainer');
                   if(feedbackContainer){
                        feedbackContainer.style.display='none';
                   }
                  this.showThankYou();
              } else {
                  throw new Error(result.message || 'Submission failed');
              }

          } catch (error) {
              console.error('Error: ' + error.message);
              submitBtn.innerHTML = originalHTML;
              submitBtn.disabled = false;
          }
        },


        showThankYou() {

            console.log('✅ showThankYou CALLED');
            const appScreen = document.getElementById('appScreen');
            const thankYouScreen = document.getElementById('thankYouScreen');

            if (appScreen) appScreen.style.display = 'none';
            if (thankYouScreen) thankYouScreen.style.display = 'block';

            thankYouScreen.innerHTML = `
                <!-- Confetti Layer -->
                <canvas id="confettiCanvas"></canvas>

                <div class="thank-you-container">
                    <div class="success-animation">
                        <i class="fas fa-check"></i>
                    </div>

                    <h1 class="thank-you-title">🎉 Thank You!</h1>

                    <p class="thank-you-message">
                        Your interview feedback has been submitted successfully.
                    </p>

                    <div style="margin-top: 25px; background: rgba(251, 165, 25, 0.08); padding: 20px; border-radius: var(--radius); max-width: 420px;">
                        <h3 style="color: var(--primary); margin-bottom: 10px; font-size: 16px;">
                            <i class="fas fa-info-circle"></i> What Happens Next?
                        </h3>

                        <ul style="font-size: 14px; color: var(--dark); line-height: 1.6; padding-left: 20px; margin: 0; text-align:start;">
                            <li>Thank you for attending the <strong>${category_name || 'Interview'}</strong> conducted by <strong>Elysium Group of Companies</strong>.</li>
                            <li>Your feedback helps us continuously improve our interview and evaluation process.</li>
                            <li>If shortlisted, you will be contacted by our HR or technical team for the next stage.</li>
                            <li>Please keep an eye on your email and phone for further updates.</li>
                        </ul>
                    </div>

                    <p style="margin-top: 20px; font-size: 13px; color: #666;">
                        We appreciate your time and interest in being part of Elysium Group of Companies.
                    </p>
                </div>
            `;


            // Use requestAnimationFrame to ensure DOM is painted
            requestAnimationFrame(() => {
                const canvas = document.getElementById("confettiCanvas");
                if (canvas) {
                    startConfetti(canvas); // pass canvas as param
                } else {
                    console.warn("❌ Confetti canvas not found");
                }
            });
        }

    };

    // Initialize app when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        console.log('DOM loaded, initializing FeedbackApp');
        FeedbackApp.init();
    });

    // Global functions
    function copyCoupon() {
        const code = document.getElementById("couponCode");
        if (!code) return;

        navigator.clipboard.writeText(code.textContent).then(() => {
            // Show toast
            const toast = document.createElement("div");
            toast.textContent = "Copied to clipboard!";
            toast.style.cssText = `
                position: fixed;
                bottom: 80px;
                left: 50%;
                transform: translateX(-50%);
                background: #28a745;
                color: white;
                padding: 12px 24px;
                border-radius: 8px;
                z-index: 9999;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                font-weight: 600;
            `;
            document.body.appendChild(toast);

            setTimeout(() => {
                toast.remove();
            }, 2000);
        });
    }
    // Confetti Animation
    function startConfetti() {
        const canvas = document.getElementById("confettiCanvas");
        const ctx = canvas.getContext("2d");

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const confettiPieces = [];

        for (let i = 0; i < 120; i++) {
            confettiPieces.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height - canvas.height,
                size: Math.random() * 8 + 4,
                speed: Math.random() * 3 + 2,
                color: `hsl(${Math.random() * 360}, 85%, 60%)`,
                rotate: Math.random() * 360
            });
        }

        let animationId;

        function drawConfetti() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            confettiPieces.forEach(p => {
                ctx.fillStyle = p.color;
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotate * Math.PI / 180);
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
                ctx.restore();

                p.y += p.speed;
                p.rotate += 5;

                if (p.y > canvas.height) {
                    p.y = -10;
                    p.x = Math.random() * canvas.width;
                }
            });

            animationId = requestAnimationFrame(drawConfetti);
        }

        drawConfetti();

        // Stop confetti after 25 seconds
        setTimeout(() => {
            cancelAnimationFrame(animationId);
            // Optional: clear canvas when done
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }, 25000);
    }

    // function startConfetti(canvas) {
    //     const ctx = canvas.getContext("2d");
    //     canvas.width = window.innerWidth;
    //     canvas.height = window.innerHeight;

    //     const confettiPieces = [];
    //     const totalPieces = 120;

    //     for (let i = 0; i < totalPieces; i++) {
    //         const fromLeft = Math.random() < 0.5;
    //         confettiPieces.push({
    //             x: fromLeft ? 0 : canvas.width,
    //             y: canvas.height + Math.random() * 100,
    //             size: Math.random() * 8 + 4,
    //             speedX: (Math.random() * 4 + 2) * (fromLeft ? 1 : -1),
    //             speedY: -(Math.random() * 5 + 2),
    //             color: `hsl(${Math.random() * 360}, 85%, 60%)`,
    //             rotate: Math.random() * 360,
    //             rotateSpeed: Math.random() * 10 - 5,
    //             gravity: 0.2 + Math.random() * 0.3
    //         });
    //     }

    //     let animationId;
    //     const stopTime = Date.now() + 25000; // 25 seconds

    //     function drawConfetti() {
    //         ctx.clearRect(0, 0, canvas.width, canvas.height);

    //         confettiPieces.forEach(p => {
    //             ctx.save();
    //             ctx.translate(p.x, p.y);
    //             ctx.rotate(p.rotate * Math.PI / 180);
    //             ctx.fillStyle = p.color;
    //             ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
    //             ctx.restore();

    //             p.x += p.speedX;
    //             p.y += p.speedY;
    //             p.speedY += p.gravity;
    //             p.rotate += p.rotateSpeed;

    //             if (p.y > canvas.height + 20 || p.x < -20 || p.x > canvas.width + 20) {
    //                 const fromLeft = Math.random() < 0.5;
    //                 p.x = fromLeft ? 0 : canvas.width;
    //                 p.y = canvas.height + Math.random() * 50;
    //                 p.speedX = (Math.random() * 4 + 2) * (fromLeft ? 1 : -1);
    //                 p.speedY = -(Math.random() * 5 + 2);
    //                 p.gravity = 0.2 + Math.random() * 0.3;
    //             }
    //         });

    //         // Stop after 25 seconds
    //         if (Date.now() < stopTime) {
    //             animationId = requestAnimationFrame(drawConfetti);
    //         } else {
    //             cancelAnimationFrame(animationId);
    //             // Optional: clear canvas after stop
    //             ctx.clearRect(0, 0, canvas.width, canvas.height);
    //             canvas.remove(); // remove canvas from DOM
    //         }
    //     }

    //     drawConfetti();
    // }

    // Make app accessible globally for debugging
    window.FeedbackApp = FeedbackApp;
  </script>


</body>
</html>
