@extends('layouts/layoutMaster')

@section('title', 'Job Request')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/quill/quill.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@vite(['resources/assets/js/forms_tagify.js'])
@endsection


@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .tagify__dropdown {
        z-index: 999999 !important;
    }
    .tagify__dropdown__wrapper {
        z-index: 999999 !important;
    }

     #aiBtn.ai-loading {
        opacity: 0.7;
        pointer-events: none;
    }


    .searchBar {
          width: 100%;
          display: flex;
          flex-direction: row;
          align-items: center;
          position: relative;
      }

      


      .searchQueryInput {
          width: 100%;
          height: 2.8rem;
          background: #f5f5f5;
          outline: none;
          border: none;
          border-radius: 0.5rem;
          padding: 0 6rem 0 1.5rem; /* extra space for 2 icons */
          font-size: 1rem;
      }

      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }
      .searchAction {
          position: absolute;
          background: none;
          border: none;
          outline: none;
          right:0;
      }
      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }

      
      .searchSubmit, .refreshBar {
            padding: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 5px;
        }

        .searchSubmit:hover, .refreshBar:hover {
            background-color: #f5f5f5;
            border-radius: 50%;
        }

        .searchSubmit {
            background-color: transparent;
        }

        .refreshBar {
            background-color: transparent;
            display: none; /* Hidden initially */
        }

        .searchQueryInput:focus + .searchAction .searchSubmit {
            background-color: #f5f5f5;
        }

        .searchQueryInput:focus + .searchAction .refreshBar {
            display: block;
        }

        /* Optional: Adding a smooth transition for the search icon and refresh icon */
        .searchSubmit, .refreshBar {
            transition: transform 0.2s ease;
        }

        .searchSubmit:hover, .refreshBar:hover {
            transform: scale(1.2);
            background:none;
        }

      .searchIcon {
          right: 3rem; /* search stays left of refresh */
      }

      .refreshIcon {
          right: 0.8rem; /* refresh at far right */
      }

      .searchQuerySubmit:hover {
          cursor: pointer;
      }
</style>

<style>
      .skeleton-loader {
          /*display: flex;*/
          /*flex-direction: row;*/
          /*gap: 10px;*/
      }

      .skeleton-row {
          display: flex;
          flex-direction: row;
          gap: 10px;
      }

      .skeleton {
          width: 100%;
          height: 30px; /* Adjust height as needed */
          background: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
          background-size: 200% 100%;
          border-radius: 4px;
          animation: loading 1.2s infinite;
      }

      .skeleton-cell {
          flex: 1;
          height: 40px; /* Match the row height */
      }

      /*@keyframes loading {*/
      /*    0% { background-position: 200% 0; }*/
      /*    100% { background-position: -200% 0; }*/
      /*}*/
      
      .skeleton-loader-view {
              background-color: #e0e0e0;
              background-image: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
              background-size: 200% 100%;
              animation: loading 1.2s infinite;
              border-radius: 4px;
              height: 20px;
          }
          
          .skeleton-loader-view.max-w-75 {
              width: 75%;
          }
          
          @keyframes loading {
              0% {
                  background-position: -200% 0;
              }
              100% {
                  background-position: 200% 0;
              }
          }
  </style>

<!-- Lead List Table -->
 @php
  
    $user_id = auth()->user()->user_id ??'1' ;
    $auth_id = auth()->user()->id ??'1';
  @endphp
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center mb-2 gap-2">
        <div>
            <h5 class="card-title mb-1">Job Request</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                <span><i class="mdi mdi-filter-outline"></i></span>
            </a>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_job_request">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Job Request
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="branch_filter mb-4" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Job Role</label>
                    <input type="text" class="form-control" id="job_role_fill" name="job_role_fill"  placeholder="Enter Job Role" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Experience</label>
                    <select id="exp_type_filt" name="exp_type_filt" class="select3 form-select">
                        <option value="">All</option>
                        <option value="2">Fresher</option>
                        <option value="3">Experience</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="closing_date_filt" name="closing_date_filt" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <button type="button" class="btn btn-sm btn-primary fw-semibold fs-6 me-2" class="filterSubmit" id="filterSubmit">Go</button>
                <a href="{{ url('/hr_management/job_request') }}" class="btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Job Role Name..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold text-primary"  ></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold text-primary" ></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Job Role</th>
                            <th class="min-w-100px">Experience</th>
                            <th class="min-w-100px">Vacancy Count</th>
                            <th class="min-w-100px">Closing Date</th>
                            <th class="min-w-100px">Skills Required</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                        <tr class="skeleton-loader" id="skeleton-loader" >
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Create Campaign-->
<div class="modal fade" id="kt_modal_create_job_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Create Job Request</h3>
                </div>
                <form id="jobRequestform" method="POST" action="{{ route('add_job_request') }}" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="job_role_name" name="job_role_name" placeholder="Enter Job Role Name" value="" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        <div class="text-danger" id="job_role_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Experience Type<span class="text-danger">*</span></label>
                        <select id="exp_type" name="exp_type[]" class="select3 form-select" multiple data-placeholder="Select Type">
                            <option value="">Select Type</option>
                            <option value="1">Fresher</option>
                            <option value="2">Experience</option>
                        </select>
                         <div class="text-danger" id="exp_type_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Years of Experience<span class="text-danger">*</span></label>
                        <input type="text" id="experience_year" name="experience_year" class="form-control" placeholder="Enter Years of Experience"  value="0"/>
                        <div class="text-danger" id="experience_year_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">No Of Vacancy<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="vacancy_count" name="vacancy_count" placeholder="Enter No Of Vacancy" value="" />
                        <div class="text-danger" id="vacancy_count_err"></div>
                    </div>
                    <div class="col-lg-4 mb-2" id="">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="closing_date" name="closing_date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                        <div class="text-danger" id="closing_date_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Minimum Salary</label>
                        <input type="text" id="min_salary" name="min_salary" class="form-control" placeholder="Enter Minimum Salary" />
                        <div class="text-danger" id="min_salary_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Maximum Salary</label>
                        <input type="text" id="max_salary" name="max_salary" class="form-control" placeholder="Enter Maximum Salary" />
                        <div class="text-danger" id="max_salary_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Skills Required<span class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="skill_KnowledgeTag" name="skill_KnowledgeTag" class="form-control h-auto" placeholder="Select Skills Required" value="">
                            
                        </div>
                        <div class="text-danger" id="skill_KnowledgeTag_err"></div>
                    </div>
                    <div class="col-lg-12 mb-3" >
                        <div class="d-flex justify-content-between">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Job Description<span class="text-danger">*</span></label>
                            <button type="button" id="aiBtn" 
                                class="btn btn-sm btn-light-primary border rounded-pill px-3 fw-bold shadow-sm"
                                onclick="generateAiDescription()">
                                <span class="d-flex justify-content-center align-items-center gap-1">
                                    <i class="mdi mdi-robot-outline"></i>
                                    <span>AI</span>
                                </span>
                                
                            </button>
                        </div>
                        
                        <div class="col-lg-12 mb-3" id="show_text_edit">
                            <input type="hidden" name="edit_text" id="edit_text">
                            <div id="create_job_description"
                                    class="scroll-y max-h-300px  border-top-none p-3 bg-white"></div>
                                <div class="error_msg text-danger fw-semibold mt-2 fs-7"></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4 mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="submitRequsetBtn" class="btn btn-primary" onclick="validation_func()">
                        <span id="yesBtnText">Create Job Request</span>
                        <span id="yesBtnLoader" style="display: none;" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Campaign-->

<!--begin::Modal - Update Job Request-->
<div class="modal fade" id="kt_modal_update_job_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Update Job Request</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Role Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter Job Role Name" value="Software Trainer" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Years of Experience<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Years of Experience" value="2 years"/>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">No Of Vacancy<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="" placeholder="Enter No Of Vacancy" value="03" />
                    </div>
                    <div class="col-lg-4 mb-2" id="">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Closing Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="" placeholder="Select Date" class="form-control common_datepicker" value="10-Dec-2025" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Minimum Salary</label>
                        <input type="text" class="form-control" placeholder="Enter Minimum Salary" value="₹ 10,000"/>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Maximum Salary</label>
                        <input type="text" class="form-control" placeholder="Enter Maximum Salary" value="₹ 15,000"/>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Skills Required<span class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="KnowledgeTagEdit" name="KnowledgeTagEdit" class="form-control h-auto" placeholder="Select Skills Required" value="Data Scienece - Beginner, Java, PHP">
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Job Description<span class="text-danger">*</span></label>
                        <div class="border border-gray-200 px-3 py-3 rounded">
                            <div id="create_job_description_editor_edit">
                                <h4>Job Title: Software Trainer</h4>
                                <p class="text-black"><strong>Location:</strong> [City, State]</p>
                                <p class="text-black"><strong>Job Type:</strong> Full-time / Part-time / Contract</p>
                                <p class="text-black"><strong>Experience:</strong> 1-5 Years</p>

                                <h4>Job Overview:</h4>
                                <p class="text-black">We are looking for a skilled <strong>Software Trainer</strong> to design, deliver, and manage training sessions for employees, clients, or students on various software tools and applications. The ideal candidate will have excellent communication skills, a passion for teaching, and practical experience in software technologies.</p>

                                <h4>Key Responsibilities:</h4>
                                <ul class="text-black">
                                    <li class="text-black">Conduct training sessions (online and offline) on software applications, tools, and programming languages.</li>
                                    <li class="text-black">Develop and update training materials, manuals, and guides.</li>
                                    <li class="text-black">Assess trainees’ understanding and provide feedback to improve skills.</li>
                                    <li class="text-black">Customize training programs based on participant requirements and learning levels.</li>
                                    <li class="text-black">Stay up-to-date with the latest software trends, updates, and industry standards.</li>
                                    <li class="text-black">Assist in onboarding new employees with software systems and best practices.</li>
                                    <li class="text-black">Troubleshoot software-related issues and provide guidance during practical exercises.</li>
                                </ul>

                                <h4>Required Skills and Qualifications:</h4>
                                <ul class="text-black">
                                    <li class="text-black">Bachelor’s degree in Computer Science, Information Technology, or related field.</li>
                                    <li class="text-black">Strong knowledge of software tools (MS Office, programming languages, database systems, etc.).</li>
                                    <li class="text-black">Previous experience as a software trainer, instructor, or in a training role.</li>
                                    <li class="text-black">Excellent verbal and written communication skills.</li>
                                    <li class="text-black">Ability to simplify complex technical concepts for learners.</li>
                                    <li class="text-black">Patience, creativity, and strong interpersonal skills.</li>
                                </ul>

                                <h4>Preferred Qualifications:</h4>
                                <ul class="text-black">
                                    <li class="text-black">Certification in relevant software or programming languages.</li>
                                    <li class="text-black">Experience in e-learning platforms and LMS tools.</li>
                                    <li class="text-black">Experience with large group training and corporate training environments.</li>
                                </ul>

                                <h4>What We Offer:</h4>
                                <ul class="text-black">
                                    <li class="text-black">Competitive salary and benefits.</li>
                                    <li class="text-black">Opportunity to work with diverse teams and learners.</li>
                                    <li class="text-black">Career growth and professional development opportunities.</li>
                                    <li class="text-black">Supportive and innovative learning environment.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-4 mb-2">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Job Request</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Job Request-->

<!--begin::Modal - Delete Campaign-->
<div class=" modal fade" id="kt_modal_delete_job_request" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Job Request?
                <div class="mt-1">
                    <span class="fs-5 fw-bold text-danger">Software Trainer</span>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign-->

<!--begin::Modal - Update Campaign-->
<div class="modal fade" id="kt_modal_view_training" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">View Training</h3>
                </div>
                <div class="row mt-4" id="staff_view_div">
                    <div class="row mt-4" id="">
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Staff Photo</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">
                                    <div class="row">
                                        <div class="align-items-sm-center gap-4">
                                            <div class="symbol symbol-35px me-2">
                                                <div class="image-input image-input-circle" data-kt-image-input="true">
                                                    <div class="d-block overlay text-center me-3">
                                                        <div
                                                            class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px">
                                                            <img src="{{ asset('assets/eapl_images/user_1.png') }}"
                                                                alt="user-avatar"
                                                                class="d-block w-90px h-100px rounded border border-gray-600 border-solid"
                                                                id="uploadedlogo" />
                                                        </div>
                                                        <div
                                                            class="overlay-layer card-rounded bg-dark bg-opacity-75 shadow w-100px h-100px">
            
                                                            <a class="justify-content-end align-items-center"
                                                                href="{{ asset('assets/eapl_images/user_1.png') }}" download>
                                                                <i
                                                                    class="mdi mdi-download-circle-outline text-white fs-3 text-hover-success ms-7"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Created Date</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">30-Jul-2025</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">Pradeep</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Qualification</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">M.Sc</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Work Type</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">Experience</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Position</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">Senior Developer</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-7 fw-semibold">Experience</label>
                                <label class="col-1 text-dark fs-6 fw-bold">:</label>
                                <label class="col-7 text-dark fs-6 fw-bold">3 years</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-2">
                            <h5 class="title mt-4 fw-bold" style="text-decoration-line: underline;">Resume</h5>
                            <div class="d-flex align-items-center justify-content-start gap-2">
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <h5 class="title mt-4 fw-bold" style="text-decoration-line: underline;">Certificate</h5>
                            <div class="d-flex align-items-center justify-content-start gap-2">
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                                <a href="{{ asset('assets/eapl_images/def_pdf.png') }}" class="overlay-wrapper bgi-no-repeat bgi-position-center bgi-size-cover card-rounded w-100px h-100px" download>
                                    <img src="{{ asset('assets/eapl_images/def_pdf.png') }}" class="h-100px w-100px" />
                                </a>
                            </div>
                        </div>
                    </div>
                    <h5 class="title mt-4 fw-bold" style="text-decoration-line: underline;">Domain Excellence</h5>
                    <div class="row">
                        <div class="col-lg-4">
                            <ul class="">
                                <li class="text-dark fs-6 fw-bold">Data Science</li>
                                <li class="text-dark fs-6 fw-bold">Java</li>
                                <li class="text-dark fs-6 fw-bold">PHP</li>
                            </ul>
                        </div>            
                    </div>
            
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Campaign-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
  /* Customize Toastr container */
  .toast {
      background-color: #39484f;
  }

  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: red;
  }

 
</style>
<script>
  // Display Toastr messages
      @if (Session::has('toastr'))
          var type = "{{ Session::get('toastr')['type'] }}";
          var message = "{{ Session::get('toastr')['message'] }}";
          toastr[type](message);
      @endif
</script>

<script>
    $('#branch_filter').click(function() {
        $('.branch_filter').slideToggle('slow');
    });
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#lead_week_st_dt_fill').val(firstday);
            $('#lead_week_ed_dt_fill').val(lastday);

        }
        // else if (dt_fill_issue_rpt == "week") {
        //     today_dt_iss_rpt.style.display = "none";
        //     week_from_dt_iss_rpt.style.display = "block";
        //     week_to_dt_iss_rpt.style.display = "block";
        //     monthly_dt_iss_rpt.style.display = "none";
        //     from_dt_iss_rpt.style.display = "none";
        //     to_dt_iss_rpt.style.display = "none";

        //     var curr = new Date; // get current date
        //     var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
        //     var last = first + 6; // last day is the first day + 6

        //     var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
        //     firstday = firstday.split("-").reverse().join("-");
        //     var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
        //     lastday = lastday.split("-").reverse().join("-");
        //     $('#week_from_date_fil').val(firstday);
        //     $('#week_to_date_fil').val(lastday);

        // } 
        else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {    
         
        return `
            <tr>
                <td>
                    <label class="fs-7 fw-semibold text-black">${item.job_role_name}</label>
                </td>
                <td>
                    <label class="fs-7 fw-semibold text-dark">${item.experience} Years</label>
                </td>
                <td>
                    <label class="badge rounded-circle bg-label-danger border border-danger fs-7 fw-semibold text-black">${item.vacancy_count || '00'}</label>
                </td>
                <td>
                    <label class="fs-7 fw-semibold text-black badge bg-warning">${item.closing_date ? formatDate(item.closing_date) : '-'}</label>
                </td>
                <td>
                    <label class="fs-7 fw-semibold text-truncate max-w-100px">
                        Java, PHP, Data Science
                    </label>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td>
                    <span class="text-end">
                        <a class="btn btn-icon btn-sm p-0 me-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_update_job_request" onclick="EditModal('${item.sno}')">
                                <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                <span>Edit</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_job_request" onclick="confirmDelete('${item.sno}', '${item.job_role_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                                <span>Delete</span>
                            </a>
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const closing_date_filt = document.getElementById('closing_date_filt').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const exp_type_filt = document.getElementById('exp_type_filt').value;

        const url = `/hr_management/job_request?page=${page}&sorting_filter=${perpage}&search_filter=${search}&closing_date_filt=${closing_date_filt}&exp_type_filt=${exp_type_filt}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

<!-- Quill JS -->
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>

<script>
   $(document).ready(function() {
          // Basic
          //------------------------------------------------------
          const skill_KnowledgeTagEl = document.querySelector('#skill_KnowledgeTag');
          let whitelist = [];
          // Fetch data using $.ajax (jQuery)
          $.ajax({
              url: "{{ route('job_skill_tag') }}",
              type: 'GET',
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      response.data.forEach(function(tags) {
                          whitelist.push(tags.job_skill_tag_name); // Populate whitelist array
                      });

                      initializeTagify(); // Call Tagify initialization after data fetch
                  }
              },
              error: function(error) {
                  console.error('Error fetching knowledge tags:', error);
              }
          });

          function initializeTagify() {
              // Inline initialization of Tagify
              let KnowledgeTag = new Tagify(skill_KnowledgeTagEl, {
                  whitelist: whitelist,
                  maxTags: 500, // allows to select max items
                  dropdown: {
                      maxItems: 1000, // display max items
                      classname: 'tags-inline', // Custom inline class
                      enabled: 0,
                      closeOnSelect: true
                  }
              });

              // Ensure the z-index is set correctly after initialization
              KnowledgeTag.DOM.dropdown.style.zIndex = '9999';
          }
      });


  </script>

  <script>
     function submit_form() {
        const form = document.getElementById("jobRequestform");
        const submitBtn = document.getElementById("submitRequsetBtn");
        const submitBtnText = document.getElementById("yesBtnText");
        const submitBtnLoader = document.getElementById("yesBtnLoader");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;
            submitBtnText.style.display = "none"; // Hide "Yes"
            submitBtnLoader.style.display = "inline-block"; // Show loader

            

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    // window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                    submitBtnText.style.display = "inline-block"; // Show "Yes" again
                    submitBtnLoader.style.display = "none"; // Hide loader
                }
            });
        }
    }
  </script>

  <script>

  function validation_func(stage) {
    let err = false; 
  
        if (!$('#job_role_name').val().trim()) { $('#job_role_name_err').text('Job Role Name is required.'); err = true; }else{$('#job_role_name_err').text('');}
        if ($('#exp_type').val() =='') { $('#exp_type_err').text('Experience Type is required.'); err = true; }else{$('#exp_type_err').text('');}
        if (!$('#experience_year').val().trim()) { $('#experience_year_err').text('Experience Year is required.'); err = true; }else{$('#experience_year_err').text('');}
        if (!$('#vacancy_count').val().trim()) { $('#vacancy_count_err').text('Vacancy Count is required.'); err = true; }else{$('#vacancy_count_err').text('');}
        let closingDate = $('#closing_date').val().trim();

        if (!closingDate) {
            $('#closing_date_err').text('Closing date is required.');
            err = true;
        } else {
            // Convert string to date
            let inputDate = new Date(closingDate);
            let today = new Date();

            // Remove time portion for accurate comparison
            today.setHours(0,0,0,0);
            inputDate.setHours(0,0,0,0);

            if (inputDate < today) {
                $('#closing_date_err').text('Closing date must be today or a future date.');
                err = true;
            } else {
                $('#closing_date_err').text('');
            }
        }

        if (!$('#min_salary').val().trim()) { $('#min_salary_err').text('Minimum Salary is required.'); err = true; }else{$('#min_salary_err').text('');}
        if (!$('#max_salary').val().trim()) { $('#max_salary_err').text('Maximum Salary is required.'); err = true; }else{$('#max_salary_err').text('');}
        if (!$('#skill_KnowledgeTag').val().trim()) { $('#skill_KnowledgeTag_err').text('Skill Tag is required.'); err = true; }else{$('#skill_KnowledgeTag_err').text('');}
        const content = quill.root.innerHTML.trim();
          if (content === '<p><br></p>' || content === '') {
              e.preventDefault();
              $('#show_text_edit').find('.error_msg')
                  .text('Job Description is required.')
                  .show();
          } else {
              $('#edit_text').val(content);
              $('#show_text_edit').find('.error_msg').text('').hide();
          }
        if (!err) {
            submit_form();
        } 
    
  }
  </script>

  <script>
  let quill;
   var aiInProgress = false;
   $(document).ready(function() {
      // ✅ Initialize Quill editor once
      quill = new Quill('#create_job_description', {
          theme: 'snow',
          placeholder: 'Type something...',
          modules: {
              toolbar: [
                  [{ 'header': [1, 2, false] }],
                  ['bold', 'italic', 'underline'],
                  ['link', 'blockquote', 'code-block'],
                  [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                  ['clean']
              ]
          }
      });

      // ✅ Handle form submit
    //   $('#edit_training_form').on('submit', function(e) {
    //       const content = quill.root.innerHTML.trim();
    //       if (content === '<p><br></p>' || content === '') {
    //           e.preventDefault();
    //           $('#show_text_edit').find('.error_msg')
    //               .text('Content is required.')
    //               .show();
    //       } else {
    //           $('#edit_text').val(content);
    //           $('#show_text_edit').find('.error_msg').text('').hide();
    //       }
    //   });
  });
   

   


    $(document).ready(function () {
        $('.common_datepicker').datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-M-yyyy'
        });
    });

        // ------------------------------------
        // 2. AI DESCRIPTION GENERATOR
        // ------------------------------------

        function generateAiDescription() {

            if (aiInProgress) return;

            let jobRoleName = $('#job_role_name').val().trim();

            if (!jobRoleName) {
                $('#job_role_name_err').text("Enter Job Role Name before generating AI description.");
                return;
            } else {
                $('#job_role_name_err').text("");
            }

            aiInProgress = true;

            $("#aiBtn")
                .prop("disabled", true)
                .html(`<span class="spinner-border spinner-border-sm me-1"></span>Generating...`);

           

            $.ajax({
                url: "{{ route('generate-job-description') }}",
                type: 'POST',
                data: { job_role_name: jobRoleName },
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },

                success: function (response) {

                    if (response.status === 200 && response.data) {

                        // SAFE way to insert HTML into Quill
                        // let delta = window.quill.clipboard.convert({ html: response.data });
                        // window.quill.setContents(delta, 'silent');
                       if (quill) {
                            quill.root.innerHTML = response.data || '';
                        }

                     
                    }
                },

                error: function (error) {
                    console.error('AI Error:', error);
                },

                complete: function () {
                    aiInProgress = false;

                    $("#aiBtn")
                        .prop("disabled", false)
                        .html(`<span class="d-flex justify-content-center align-items-center gap-1">
                                <i class="mdi mdi-robot-outline"></i><span>AI</span>
                            </span>`);
                }
            });
        }

    </script>

  
@endsection