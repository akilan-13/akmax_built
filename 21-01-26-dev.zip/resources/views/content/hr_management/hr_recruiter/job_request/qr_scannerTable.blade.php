@if (isset($List_table) > 0)
    @foreach ($List_table as $i => $list)
    <tr>
        <td>
            <span data-bs-toggle="tooltip" data-bs-placement="top" title="{{ \Carbon\Carbon::parse($list->created_at)->format('d-M-Y h:i A') }}">
                <i class="mdi mdi-calendar text-primary"></i> {{ \Carbon\Carbon::parse($list->created_at)->format('d-M-Y') }}<br>
                <i class="mdi mdi-clock-outline text-success"></i> {{ \Carbon\Carbon::parse($list->created_at)->format('h:i A') }}
            </span>
        </td>
        <td>{{$list->device}} </td>
        <td>{{$list->applicant_name ?? 'N/A'}} </td>
        <td>{{$list->ipaddress}}</td>
        <td>{{$list->latitude ?? 'N/A'}}</td>
        <td>{{$list->longitude ?? 'N/A'}}</td>
        <td>
            <a href="javascript:;"  class="dropdown-item" onclick="ViewLocation('{{$list->ipaddress}}','{{$list->latitude}}','{{$list->longitude}}')">
                <span><i class="mdi mdi-map-marker-radius fs-3 text-black "></i></span> 
            </a>
        </td>
    </tr>
    @endforeach
@endif
   
