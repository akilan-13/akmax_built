@extends('layouts/blankLayout')

<title>{{ $candidate_name }} | Job Confirmation | Elysium Groups</title>

<style>
:root {
    --erp-primary: #b0302b;
    --erp-secondary: #f59e0b;
    --erp-gradient: linear-gradient(160deg, #b0302b, #f59e0b);
    --erp-bg: #eef1f6;
    --erp-gradient-light: linear-gradient(160deg, #b02f2b30, #f59f0b27);
}

body {
    background: var(--erp-bg);
}

/* CARD */
.confirm-card {
    background: #fff;
    border-radius: 26px;
    overflow: hidden;
    box-shadow: 0 12px 30px rgba(0,0,0,.15);
}

@media (max-width: 576px) {
    .confirm-card {
        width: 100%;
        max-width: 360px;   /* phone width */
        margin: 0 auto;
    }
}

/* HEADER (MOBILE APP STYLE) */
.confirm-header {
    background: var(--erp-gradient);
    padding: 18px 16px 22px;   /* reduced height */
    text-align: center;
    /*border-bottom-left-radius: 28px;*/
    /*border-bottom-right-radius: 28px;*/
}

.confirm-header img {
    background: #fff;
    padding: 6px 12px;
    border-radius: 14px;
    margin-bottom: 14px;
}

.confirm-header h4 {
    font-size: 20px;
    font-weight: 700;
    margin: 0;
    color: #111;
}

/* BODY */
.confirm-body {
    padding: 26px 20px;
    font-size: 15px;
    line-height: 1.6;
}

.candidate-name {
    font-weight: 700;
}

.job-title {
    color: var(--erp-primary);
    font-weight: 700;
}

/* INFO LIST (MOBILE FRIENDLY) */
.info-box {
    background: #f9fafb;
    border-radius: 18px;
    padding: 16px;
    margin: 20px 0;
}

.info-row {
    display: flex;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 14px;
}

.info-row strong {
    color: #374151;
}

/* BUTTONS */
.btn-accept {
    background: #22c55e;              /* brighter green */
    color: #fff;
    border: none;
    border-radius: 18px;
    padding: 15px;
    font-size: 15px;
    font-weight: 700;
    box-shadow: 0 6px 14px rgba(34,197,94,.35);
}
.btn-decline {
    border-radius: 18px;
    padding: 14px;
    font-size: 15px;
    font-weight: 600;
    background: #fff;
}

/* FOOTER */
.confirm-footer {
    text-align: center;
    font-size: 13px;
    padding: 14px;
    color: #6b7280;
}

/* DESKTOP TWEAK */
@media (min-width: 768px) {
    .confirm-body {
        padding: 36px;
    }
    .confirm-header h4 {
        font-size: 24px;
    }
}

@media (max-width: 576px) {
    .confirm-body {
        padding: 20px 18px;
    }
}

.fullcontainer{
    background: var(--erp-gradient-light);
}

</style>

@section('content')
<div class="min-vh-100 d-flex align-items-center justify-content-center px-3 fullcontainer">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-8">

                <div class="confirm-card">

                    {{-- HEADER --}}
                    <div class="confirm-header">
                        <img src="{{ asset('assets/common/logo_full.png') }}" height="38" class="mb-3 bg-white rounded px-2">
                        <h4>Job Offer Confirmation</h4>
                        <!--<p>Elysium Groups</p>-->
                    </div>

                    {{-- BODY --}}
                    <div class="confirm-body">

                        <p class="mb-3">
                            Dear <span class="candidate-name">{{ $applicant->applicant_name }}</span>,
                        </p>

                        <p class="mb-3">
                            We are pleased to offer you the position of
                            <span class="job-title">{{ $applicant->job_role_name }}</span>.
                        </p>

                        {{-- INFO --}}
                        <div class="info-box">
                            <div class="info-row">
                                <strong>Email</strong>
                                <span>{{ $applicant->email }}</span>
                            </div>
                            <div class="info-row">
                                <strong>Mobile</strong>
                                <span>{{ $applicant->mobile }}</span>
                            </div>
                            <div class="info-row mb-0">
                                <strong>Reporting Date</strong>
                                <span>{{ date('d M Y', strtotime($applicant->reporting_date)) }}</span>
                            </div>
                        </div>

                        {{-- ACTION --}}
                        <div class="d-grid gap-3 mt-4">
                            <button type="button"
                                class="btn btn-accept btn-success text-white btn-lg"
                                onclick="openModal('Accepted')">
                                <i class="mdi mdi-check-circle me-2"></i>
                                Accept Offer
                            </button>

                            <button type="button"
                                class="btn btn-outline-danger btn-decline btn-lg"
                                onclick="openModal('Rejected')">
                                <i class="mdi mdi-close-circle me-2"></i>
                                Decline Offer
                            </button>
                        </div>

                    </div>

                    {{-- FOOTER --}}
                    <div class="confirm-footer">
                        © {{ date('Y') }} Elysium Groups
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">

            <div class="modal-header border-0">
                <h5 class="modal-title fw-semibold" id="modalTitle">Confirm Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body px-4">
                <p class="mb-2" id="modalMessage"></p>

                <div class="alert alert-warning small">
                    Please confirm that the information provided is accurate and you agree
                    to proceed with this action.
                </div>

                <div class="form-check mt-3">
                    <input class="form-check-input" type="checkbox" id="agreeCheckbox">
                    <label class="form-check-label" for="agreeCheckbox">
                        I agree and confirm my decision
                    </label>
                </div>

                <input type="hidden" id="modalStatus">
                <input type="hidden" id="modalToken" value="{{ $token }}">
            </div>

            <div class=" d-flex justify-content-end gap-2 border-0 px-4 pb-4">
                <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" id="confirmYesBtn" disabled>
                    Yes, Confirm
                </button>
            </div>

        </div>
    </div>
</div>

<script>
function openModal(status) {
    $('#modalStatus').val(status);
    $('#agreeCheckbox').prop('checked', false);
    $('#confirmYesBtn').prop('disabled', true);

    if (status === 'Accepted') {
        $('#modalTitle').text('Accept Job Offer');
        $('#modalMessage').html(
            'You are about to <strong class="text-success">accept</strong> the job offer at <strong>Elysium Groups</strong>.'
        );
        $('#confirmYesBtn').removeClass('btn-danger').addClass('btn-success');
    } else {
        $('#modalTitle').text('Decline Job Offer');
        $('#modalMessage').html(
            'You are about to <strong class="text-danger">decline</strong> the job offer at <strong>Elysium Groups</strong>.'
        );
        $('#confirmYesBtn').removeClass('btn-success').addClass('btn-danger');
    }

    $('#confirmationModal').modal('show');
}

// Enable button only when checkbox checked
$('#agreeCheckbox').on('change', function () {
    $('#confirmYesBtn').prop('disabled', !this.checked);
});

// Submit via AJAX
$('#confirmYesBtn').on('click', function () {

    let status = $('#modalStatus').val();
    let token = $('#modalToken').val();

    $('#confirmYesBtn').prop('disabled', true).text('Submitting...');

    $.ajax({
        url: "{{ route('job.confirmation.submit') }}",
        type: "POST",
        data: {
            _token: "{{ csrf_token() }}",
            token: token,
            status: status
        },
        success: function (res) {
            window.location.href = res.redirect_url;
        },
        error: function () {
            // toase('Something went wrong. Please try again.');
            $('#confirmYesBtn').prop('disabled', false).text('Yes, Confirm');
        }
    });
});
</script>

@endsection
