<style>
.timeline {
    position: relative;
    margin-left: 30px;
}

/* Base grey line */
.timeline::before {
    content: '';
    position: absolute;
    left: 8px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dcdcdc;
    transform: translateX(-50%);
}

/* Green progress line */
.timeline::after {
    content: '';
    position: absolute;
    left: 8px;
    top: 0;
    width: 2px;
    background: #4caf50;
    height: var(--progress-height, 0px);
    transition: height 0.3s ease;
    transform: translateX(-50%);
}

.timeline-item {
    position: relative;
    padding-left: 40px;
    margin-bottom: 28px;
}

.timeline-dot {
    position: absolute;
    left: 8px;
    top: 4px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #bdbdbd;
    transform: translateX(-50%);
    z-index: 2;
}

/* Completed */
.timeline-item.completed .timeline-dot {
    background: #4caf50;
}

/* Active */
.timeline-item.active .timeline-dot {
    background: #4caf50;
    box-shadow: 0 0 0 4px rgba(76, 175, 80, 0.25);
}

.timeline-title {
    font-weight: 600;
}

.timeline-time {
    font-size: 12px;
    color: #888;
}
html:not([dir=rtl]) .timeline-item {
    border-left: none;
}
</style>
@php
    $activeIndex = collect($activities)->search(fn($a) => $a->is_current);

    // fallback safety
    if ($activeIndex === false) {
        $activeIndex = -1;
    }

    $progressHeight = ($activeIndex + 1) * 55;
@endphp

<div class="activity_container p-6">
    <h5 class="mb-3">Interview Overview </h5>

    <div class="timeline" style="--progress-height: {{ $progressHeight }}px">

        @foreach($activities as $index => $activity)
            <div class="timeline-item
                {{ $index < $activeIndex ? 'completed' : '' }}
                {{ $index === $activeIndex ? 'active' : '' }}">

                <div class="timeline-dot"></div>

                <div>
                    <div class="timeline-title">
                        {{ $activity->status }}
                    </div>

                    @if($activity->time)
                        <div class="timeline-time">
                            {{ $activity->time }}
                        </div>
                    @endif
                </div>
            </div>
        @endforeach


    </div>
</div>
