@extends('layouts/layoutMaster')

@section('title', 'Interview Staging')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
    .emoji-box {
        background: #fff;
        border: 1.5px solid #e2e5ea;
        border-radius: 12px;
        padding: 18px 10px;
        text-align: center;
        cursor: pointer;
        transition: all 0.25s ease;
        width: 130px;
        height: 150px;
    }

    .interview-card {
    border-radius: 14px;
}

.stat-box {
    cursor: pointer;
    min-width: 130px;
}

.stat-card {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    transition: all .25s ease;
    border: 1px solid transparent;
}

.stat-box:hover .stat-card {
    background: #fff;
    border-color: #dee2e6;
    transform: translateY(-2px);
}

.stat-box.active .stat-card {
    background: #ab2b22;
    color: #fff;
}

.stat-count {
    font-size: 22px;
    font-weight: 700;
}

.stat-label {
    font-size: 13px;
    font-weight: 500;
    opacity: .85;
}


.skeleton {
    background: linear-gradient(
        90deg,
        #f1f1f1 25%,
        #e6e6e6 37%,
        #f1f1f1 63%
    );
    background-size: 400% 100%;
    animation: skeleton-loading 1.4s ease infinite;
}

@keyframes skeleton-loading {
    0% { background-position: 100% 50%; }
    100% { background-position: 0 50%; }
}

.skeleton-row {
    height: 42px;
    border-radius: 6px;
    margin-bottom: 10px;
}


</style>

<!-- Lead List Table -->
<div class="card card-action mb-3">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Interview Staging</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Recruitment
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<div class="card p-4" style="box-shadow: none;">

@if(isset($jobRequest) && count($jobRequest))
<div class="accordion" id="jobRequestAccordion">

@foreach($jobRequest as $request)

<div class="accordion-item border-0 mb-3 interview-card">

    {{-- HEADER --}}
    <h2 class="accordion-header" id="heading-{{ $request->sno }}">
        <button class="accordion-button collapsed bg-white px-4 py-3"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#collapse-{{ $request->sno }}"
                aria-expanded="false">

            <div class="d-flex w-100 justify-content-between align-items-center">
                <div>
                    <h6 class="mb-0 fw-bold">{{ $request->job_role_name }}</h6>
                    <small class="text-muted">{{ $request->company_name }}</small>
                </div>

                <span class="badge rounded-pill px-3 py-2"
                      style="background: {{ $request->entity_base_color ?? '#6c757d' }}">
                    {{ $request->entity_name }}
                </span>
            </div>
        </button>
    </h2>

    {{-- BODY --}}
    <div id="collapse-{{ $request->sno }}"
         class="accordion-collapse collapse"
         data-bs-parent="#jobRequestAccordion">

        <div class="accordion-body bg-light">

            {{-- STAT CARDS --}}
            <div class="row g-3 interview-stats mb-3">

                <div class="col stat-box active"
                     data-type="candidates"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{ $request->candidate_count }}</div>
                        <div class="stat-label">Candidates</div>
                    </div>
                </div>

                <!-- <div class="col stat-box"
                     data-type="shortlisted"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{ $request->shortlist_count }}</div>
                        <div class="stat-label">Shortlisted</div>
                    </div>
                </div> -->

                @foreach($request->interviewStageList as $stage)
                    @php
                        $ids = $stage->shortlist_applicant_ids
                            ? json_decode($stage->shortlist_applicant_ids)
                            : [];
                    @endphp
                    <div class="col stat-box"
                         data-type="stage"
                         data-stage="{{ $stage->sno }}"
                         data-job="{{ $request->sno }}">
                        <div class="stat-card">
                            <div class="stat-count">{{ count($ids) }}</div>
                            <div class="stat-label">
                                {{ $stage->interview_category_name }}
                            </div>
                        </div>
                    </div>
                @endforeach

                <div class="col stat-box"
                     data-type="hired"
                     data-job="{{ $request->sno }}">
                    <div class="stat-card">
                        <div class="stat-count">{{$request->hired_count}}</div>
                        <div class="stat-label">Hired</div>
                    </div>
                </div>

            </div>

            {{-- AJAX PANEL --}}
            <div class="card shadow-sm border-0">
                <div class="card-body p-0">
                    <div id="candidate-panel-{{ $request->sno }}">
                        <div class="text-center text-muted py-4">
                            Expand to load candidates
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
@endforeach

</div>
@else
<div class="text-center text-muted">No Request Found</div>
@endif

</div>


<div class="modal fade" id="hireModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title text-success fw-semibold">
          Confirm Hiring
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="hire-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="hire-email"></span></p>
          <p class="mb-0"><strong>Final Stage:</strong> <span id="hire-stage"></span></p>
        </div>
        <input type="hidden" name="direct_interview_payload_hire" id="direct_interview_payload_hire" value="">
        <div class="alert alert-danger small">
          Hiring is <strong>final</strong>. This action cannot be reverted.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="hire-agree"
                 onchange="document.getElementById('hire-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I confirm that this candidate is approved for hiring
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-success" id="hire-confirm" disabled>
          Hire Candidate
        </button>
      </div>

    </div>
  </div>
</div>


<div class="modal fade" id="shortlistModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title fw-semibold">
          Shortlist Candidate
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="sl-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="sl-email"></span></p>
          <p class="mb-0"><strong>Current Stage:</strong> <span id="sl-stage"></span></p>
        </div>
        <input type="hidden" name="direct_interview_payload" id="direct_interview_payload" value="">
        <div class="alert alert-warning small">
          This applicant will move to the <strong>next interview stage</strong>.
          Please ensure the evaluation is complete.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="sl-agree"
                 onchange="document.getElementById('sl-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I have reviewed the interview results and confirm shortlisting
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" id="sl-confirm" disabled>
          Shortlist Candidate
        </button>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="RejectModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content rounded-4 shadow">

      <div class="modal-header border-0">
        <h5 class="modal-title fw-semibold">
          Reject Candidate
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <div class="mb-3">
          <p class="mb-1"><strong>Name:</strong> <span id="rjct-name"></span></p>
          <p class="mb-1"><strong>Email:</strong> <span id="rjct-email"></span></p>
          <p class="mb-0"><strong>Current Stage:</strong> <span id="rjct-stage"></span></p>
        </div>
        <input type="hidden" name="direct_interview_payload_reject" id="direct_interview_payload_reject" value="">
        <div class="col-lg-12 mb-3">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Reason<span class="text-danger">*</span></label>
            <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleAddSpam(this.value)">
                <option value="">Select Reason</option>
                @if (isset($reasonList) && count($reasonList) > 0)
                @foreach ($reasonList as $reason_spam)
                <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                    {{ $reason_spam->reason_name }}
                </option>
                @endforeach
                @endif
                <option value="1">Others</option>
            </select>
            <div class="text-danger" id="reason_select_err"></div>
        </div>
        <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
            <div class="text-danger" id="reason_text_err"></div>
        </div>
        <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
            <div class="text-danger" id="spam_comments_err"></div>
        </div>
        <div class="alert alert-warning small">
          This applicant will move to the <strong>next interview stage</strong>.
          Please ensure the evaluation is complete.
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input"
                 type="checkbox"
                 id="rjct-agree"
                 onchange="document.getElementById('rjct-confirm').disabled = !this.checked">
          <label class="form-check-label">
            I have reviewed the interview results and confirm Rejecting
          </label>
        </div>
      </div>

      <div class="modal-footer border-0">
        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary" id="rjct-confirm" disabled>
          Reject Candidate
        </button>
      </div>

    </div>
  </div>
</div>


<div class="modal fade" id="jobConfirmationModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                        <div class="row mb-2">
                            <h3 class="text-black">Send Job Confirmation</h3>
                        </div>
                    </div>
                    <div class="d-flex flex-column gap-1">
                        <label class="fs-5 fw-semibold text-primary view-data" id="send_job_role_name" >-</label>
                        <label class="text-end">
                            <span id="send_count" class="fs-6 fw-semibold text-black view-data badge bg-success rounded-circle">00</span>
                        </label>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white ">
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <label class="form-label">Confirmation Link Expiry</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="link_expiry" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y', strtotime('+3 days'));?>" />
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <label class="form-label">Reporting Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="reporting_date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date('d-M-Y', strtotime('+4 days'));?>" />
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="job_request_id_send" id="job_request_id_send" value="">
                    <div class="d-flex justify-content-end align-items-center gap-2 mt-4">
                        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" id="sendCommunicationBtn">
                            <span id="sendLoader" class="me-2"></span>Send Communication
                        </button>
                    </div>
                </div>
                
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>



<script>
    let fetchControllers = {};  
    let responseCache   = {}; 

    function skeletonTable() {
        let rows = '';
        for (let i = 0; i < 6; i++) {
            rows += `<div class="skeleton-row skeleton"></div>`;
        }

        return `
            <div class="p-4">
                ${rows}
            </div>
        `;
    }

</script>

<script>
$(document).ready(function () {

    /* Load candidates ONLY when accordion opens */
    $('.accordion-collapse').on('shown.bs.collapse', function () {

        let jobId = $(this).attr('id').replace('collapse-', '');
        let card  = $(this).closest('.accordion-item');

        let defaultBox = card.find('.stat-box[data-type="candidates"]');

        if (!defaultBox.data('loaded')) {
            defaultBox.data('loaded', true);
            loadCandidates(jobId, 'candidates');
        }
    });

    /* Stat box click */
    $(document).on('click', '.stat-box', function () {

        let card = $(this).closest('.accordion-item');
        card.find('.stat-box').removeClass('active');
        $(this).addClass('active');

        let jobId = $(this).data('job');
        let type  = $(this).data('type');
        let stage = $(this).data('stage') ?? '';

        loadCandidates(jobId, type, stage);
        clearJobCache(jobId)
    });

});

$('.stat-box').css('pointer-events', 'none');
setTimeout(() => {
    $('.stat-box').css('pointer-events', 'auto');
}, 300);
</script>
<script>
function loadCandidates(jobId, type, stage = '') {

    const panel   = document.getElementById('candidate-panel-' + jobId);
    const cacheKey = `${jobId}_${type}_${stage}`;

    /* ===============================
       CACHE HIT
    =============================== */
    if (responseCache[cacheKey]) {
        panel.innerHTML = responseCache[cacheKey];
        return;
    }

    /* ===============================
       ABORT PREVIOUS REQUEST (PER JOB)
    =============================== */
    if (fetchControllers[jobId]) {
        fetchControllers[jobId].abort();
    }

    fetchControllers[jobId] = new AbortController();

    /* ===============================
       SKELETON LOADER
    =============================== */
    panel.innerHTML = skeletonTable();

    /* ===============================
       FETCH
    =============================== */
    const params = new URLSearchParams({
        job_request_id: jobId,
        filter_type: type,
        stage_id: stage
    });

    fetch(`{{ route('monitoring_candidate_list') }}?${params}`, {
        signal: fetchControllers[jobId].signal
    })
    .then(res => res.text())
    .then(html => {

        // cache response
        responseCache[cacheKey] = html;

        panel.innerHTML = html;
    })
    .catch(err => {
        if (err.name !== 'AbortError') {
            panel.innerHTML = `
                <div class="text-danger text-center py-4">
                    Failed to load data
                </div>
            `;
        }
    })
    .finally(() => {
        delete fetchControllers[jobId];
    });
}

function clearJobCache(jobId) {
    Object.keys(responseCache).forEach(key => {
        if (key.startsWith(jobId + '_')) {
            delete responseCache[key];
        }
    });
}
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {

    let selectedApplicant = null;

    /* ===============================
       OPEN MODALS (GLOBAL)
    =============================== */
    window.openShortlistModal = function (id, name, email, stageName = '', mode = '',category_id='') {
        selectedApplicant = id;

        if(mode == '4') {

            let payloadData = {
                appliacant_id: id,
                intervewiw_mode: mode,
                interview_category: category_id,
                interview_date: document.getElementById('direct_date_' + id)?.value ?? null,
                interview_time: document.getElementById('direct_time_' + id)?.value ?? null,
                description: document.getElementById('direct_desc_' + id)?.value ?? null
            };

           document.getElementById('direct_interview_payload').value =
                JSON.stringify(payloadData);
        }

        document.getElementById('sl-name').innerText  = name;
        document.getElementById('sl-email').innerText = email;
        document.getElementById('sl-stage').innerText = stageName;

        resetShortlistModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('shortlistModal')
        ).show();
    };

    window.openRejectModal = function (id, name, email, stageName = '', mode = '',category_id='') {
        selectedApplicant = id;

        if(mode == '4') {

            let payloadData = {
                appliacant_id: id,
                intervewiw_mode: mode,
                interview_category: category_id,
                interview_date: document.getElementById('direct_date_' + id)?.value ?? null,
                interview_time: document.getElementById('direct_time_' + id)?.value ?? null,
                description: document.getElementById('direct_desc_' + id)?.value ?? null
            };

           document.getElementById('direct_interview_payload_reject').value =
                JSON.stringify(payloadData);
        }

        document.getElementById('rjct-name').innerText  = name;
        document.getElementById('rjct-email').innerText = email;
        document.getElementById('rjct-stage').innerText = stageName;

        resetRejectModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('RejectModal')
        ).show();
    };

    window.openHireModal = function (id, name, email, stageName = '', mode = '',category_id='') {
        selectedApplicant = id;

        if(mode == '4') {
            let payloadData = {
                appliacant_id: id,
                intervewiw_mode: mode,
                interview_category: category_id,
                interview_date: document.getElementById('direct_date_' + id)?.value ?? null,
                interview_time: document.getElementById('direct_time_' + id)?.value ?? null,
                description: document.getElementById('direct_desc_' + id)?.value ?? null
            };

           document.getElementById('direct_interview_payload_hire').value =
                JSON.stringify(payloadData);
        }

        document.getElementById('hire-name').innerText  = name;
        document.getElementById('hire-email').innerText = email;
        document.getElementById('hire-stage').innerText = stageName;

        resetHireModal();
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('hireModal')
        ).show();
    };

    /* ===============================
       RESET MODALS
    =============================== */
    function resetShortlistModal() {
        const agree = document.getElementById('sl-agree');
        const btn   = document.getElementById('sl-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }
    function resetRejectModal() {
        const agree = document.getElementById('rjct-agree');
        const btn   = document.getElementById('rjct-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }

    function resetHireModal() {
        const agree = document.getElementById('hire-agree');
        const btn   = document.getElementById('hire-confirm');

        agree.checked = false;
        btn.disabled  = true;
        btn.classList.remove('disabled');
    }

    /* ===============================
       CHECKBOX ENABLE/DISABLE
    =============================== */
    document.getElementById('sl-agree').addEventListener('change', function () {
        document.getElementById('sl-confirm').disabled = !this.checked;
    });
    document.getElementById('rjct-agree').addEventListener('change', function () {
        document.getElementById('rjct-confirm').disabled = !this.checked;
    });

    document.getElementById('hire-agree').addEventListener('change', function () {
        document.getElementById('hire-confirm').disabled = !this.checked;
    });

    /* ===============================
       SUBMIT SHORTLIST
    =============================== */
    document.getElementById('sl-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Processing...';
        let direct_interview = document.getElementById('direct_interview_payload').value;

        fetch("{{ route('hr.shortlist.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant,
                direct_interview: direct_interview ?? null
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload();
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Shortlist Candidate';
        });
    });

     /* ===============================
       SUBMIT Reject
    =============================== */
    document.getElementById('rjct-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Processing...';
        let direct_interview = document.getElementById('direct_interview_payload_reject').value;
        var reject_reason = $('#reject_reason').val().trim();
        var other_reason = $('#other_reason').val().trim();

        fetch("{{ route('hr.reject.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant,
                reject_reason: reject_reason,
                other_reason: other_reason,
                direct_interview: direct_interview ?? null
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload();
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Reject Candidate';
        });
    });

    /* ===============================
       SUBMIT HIRE
    =============================== */
    document.getElementById('hire-confirm').addEventListener('click', function () {

        if (!selectedApplicant) return;

        this.disabled = true;
        this.innerHTML = 'Hiring...';
        let direct_interview = document.getElementById('direct_interview_payload_hire').value;
        fetch("{{ route('hr.hire.candidate') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicant_id: selectedApplicant,
                direct_interview: direct_interview ?? null
            })
        })
        .then(res => res.json())
        .then(() =>{
            location.reload()
        } )
        .catch(() => {
            this.disabled = false;
            this.innerHTML = 'Hire Candidate';
        });
    });

});
</script>
<script>
    function toggleAddSpam(value) {
          var ReasonDiv = document.getElementById('reason_div');
          var ReasonText = document.getElementById('reason_text');
          var CommentsDiv = document.getElementById('comments_div');
          var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
          var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;
    
          if (value == '1') {
              ReasonDiv.style.display = 'block';
              ReasonText.setAttribute('required', 'required');
          } else {
              ReasonDiv.style.display = 'none';
              ReasonText.removeAttribute('required');
          }
    
          if (commentsCheck == '1') {
              CommentsDiv.style.display = 'block';
          } else {
              CommentsDiv.style.display = 'none';
          }
      }
</script>

<script>
    $(document).ready(function () {

        /* ================= CHECK ALL ================= */
        $(document).on('change', '#checkAll', function () {
            const isChecked = $(this).prop('checked');
            $('#studs_table_event_attendance tbody input[type="checkbox"]')
                .prop('checked', isChecked);
        });

        /* ================= OPEN MODAL ================= */
        $(document).on('click', '#updateShortlistBtn', function () {

            let selectedCount = $('#studs_table_event_attendance tbody input[type="checkbox"]:checked').length;

            if (selectedCount === 0) {
                toastr.warning('Please select at least one candidate');
                return;
            }
            $('#send_count').text(selectedCount);
            $('#send_job_role_name').text($('#hired_job_role_name').val());
            $('#job_request_id_send').val($('#hired_job_request_id').val());
            $('#jobConfirmationModal').modal('show');
        });

        /* ================= SEND COMMUNICATION ================= */
        $(document).on('click', '#sendCommunicationBtn', function () {

            let shortlistData = [];

            $('#studs_table_event_attendance tbody input[type="checkbox"]').each(function () {
                if ($(this).prop('checked')) {
                    shortlistData.push({
                        sno: $(this).attr('id').split('_')[2]
                    });
                }
            });

            const payload = {
                shortlist_data: shortlistData,
                job_request_id: $('#job_request_id_send').val(),
                reporting_date: $('#reporting_date').val(),
                link_expiry: $('#link_expiry').val(),
            };
            console.log(payload);
            if (!payload.reporting_date || !payload.link_expiry) {
                toastr.error('Please fill all required fields');
                return;
            }

            $('#sendCommunicationBtn').prop('disabled', true);
            $('#sendLoader').addClass('spinner-border spinner-border-sm');

            $.ajax({
                url: '/send_confirmation_bulk',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: payload,
                success: function (res) {
                    toastr.success('Job confirmation sent successfully');
                    $('#sendLoader').removeClass('spinner-border spinner-border-sm');
                    $('#sendCommunicationBtn').prop('disabled', false);
                    $('#jobConfirmationModal').modal('hide');
                    location.reload();
                },
                error: function () {
                    toastr.error('Something went wrong');
                    $('#sendLoader').removeClass('spinner-border spinner-border-sm');
                    $('#sendCommunicationBtn').prop('disabled', false);
                    
                }
            });
        });

    });
</script>

<!-- ALTER TABLE `egc_interview_schedule` ADD `hired_applicant_ids` TEXT NULL AFTER `status`;
ALTER TABLE `egc_applicant` ADD `hiring_status` INT(11) NULL DEFAULT '0' AFTER `shortlist_check`;
ALTER TABLE `egc_applicant` ADD `hiring_details` TEXT NULL AFTER `hiring_status`; -->

@endsection
