<style>
.candidate-container {
    display: flex;
    align-items: start;
    border-radius: 6px;
    border-style: none;
    position: relative;
    margin-left: 0px;
    box-shadow: rgba(47, 43, 61, 0.16) 0px 4px 11px 0px;
}

.candidate-list {
    background-color: rgb(255, 255, 255);
    color: rgba(47, 43, 61, 0.78);
    box-shadow: rgba(47, 43, 61, 0.1) 0px 4px 18px 0px;
    background-image: none;
    margin-right: 20px;
    transition: box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
    border-radius: 6px;
}

.candidate-content {
    width: 0px;
    flex-grow: 1;
}

</style>

@if(count($candidates))
<input type="hidden" id="hired_job_role_name" value="{{$jobRequestData->job_role_name}}">
<input type="hidden" id="hired_job_request_id" value="{{$jobRequestData->sno}}">
<div class="d-flex justify-content-between align-items-center p-4">
    <h4 class="text-primary fw-bold mb-0">Selected Candidates</h4>
    <button type="button" id="updateShortlistBtn" class="btn btn-primary">Send Job Confirmation</button>
</div>
<table class="table table-row-dashed table-striped table-hover mb-0 bg-white" id="studs_table_event_attendance">
    <thead >
        <tr class="fw-bold fs-6 gs-0 bg-primary">
            <th class="w-200px"><input type="checkbox" id="checkAll" class="form-check-input border-white me-1" checked/>Name</th>
            <th>mobile / Email</th>
            <th>Status</th>
            <th>Applied On</th>
        </tr>
    </thead>
    <tbody>
        @foreach($candidates as $c)

        @php 
            $statuBadge='';
            $statuClass='';
            if($c->hiring_status ==1){
                $statuBadge='Selected';
                $statuClass='bg-label-success';
            }
            elseif ($c->applicant_status == 1) {
                $statuBadge='New Applicant';
                $statuClass='bg-label-warning';
            }elseif($c->applicant_status == 3){
                if($c->shortlist_check == 1){
                    $statuBadge='New Applicant';
                    $statuClass='bg-label-info';
                }else{
                    $statuBadge='Not Eligible';
                    $statuClass='bg-label-danger';
                }
            }else{
                $statuBadge='New Applicant';
                $statuClass='bg-label-warning';
            }
        @endphp
        <tr>
            <td>
                <div class="d-flex gap-2 align-items-center">
                    <div>
                        <input class="form-check-input"
                            type="checkbox"
                            checked
                            name="shortlist_check_{{ $c->sno }}"
                            id="shortlist_check_{{ $c->sno }}"
                            value="1">
                    </div>
                    <div>
                        <div class="fw-semibold">{{ $c->applicant_name }}</div>
                    </div>
                </div>
                
            </td>
            <td>
                <div>{{ $c->mobile}}</div>
                <div>{{ $c->email }}</div>
            </td>
            <td>
              <span class="badge rounded {{$statuClass}} text-black fw-semibold fs-7">{{ $statuBadge }}</span> 
            </td>
            <td>{{ date('d M Y', strtotime($c->created_at)) }}</td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="text-center text-muted py-4">
    No candidates found
</div>
@endif
