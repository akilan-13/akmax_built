@extends('layouts/layoutMaster')

@section('title', 'Webhook Moniter')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
        
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li>        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link"
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link ">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link ">
                                    Business
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="{{ url('/admin/webhooks') }}" type="button"
                                    class="nav-link scroll-link active">
                                    Webhook Moniter
                                </a>
                            </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>  
            </ul>
        </div>
        <div class="card-body">
            <h4 class="ms-2">Webhook Moniter</h4>
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [6,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Webhook..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12"> 
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-center text-nowrap align-middle  fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-150px text-center">URL</th>
                                    <th class="min-w-50px">Status</th>
                                    <th class="min-w-100px">Attempts</th>
                                    <th class="min-w-100px">Last Attempt</th>
                                    <th class="min-w-100px">Next Attempt</th>
                                    <th class="min-w-80px text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                <tr class="skeleton-loader" id="skeleton-loader">
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="kt_modal_failure_data" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex align-items-center mb-2 gap-2">
                        <div class="">
                            <span class="text-black fw-semibold fs-3">View Webhook Log</span>
                        </div>
                    </div>
                </div>

                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <div class="row mb-3">
                            <div class="" id="error_container">
                                
                            </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
   
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {  
         var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        var bg_color=item.status ==2 ? 'bg-success' :
                        (item.status ==3 ? 'bg-danger' :
                        (item.status ==1 ? 'bg-warning' : 'bg-secondary')
                        );
            var statusName=item.status ==2 ? 'Success' :
                        (item.status ==3 ? 'Failed' :
                        (item.status ==1 ? 'Processing' : 'Pending')
                        );
        return `
            <tr id="webhook-${item.sno}">
                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="text-truncate max-w-150px fw-semibold fs-7"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${item.url}">${item.url}
                        </div>
                    </div>
                </td>
                <td align="center" >
                    <div data-bs-toggle="modal" data-bs-target="#kt_modal_failure_data" onclick="openErrorModal(${item.sno})">
                        <span class="badge status ${bg_color}" data-bs-toggle="tooltip" title='${item.last_response}'>${statusName}</span>
                    </div>
                </td>
                <td align="center">
                    <span class="badge bg-info attempts">${item.attempts}</span>
                </td>
                <td align="start">
                        <span class="badge bg-danger last-attempt">${item.last_attempt_at ? formatDateTime(item.last_attempt_at) : '-'}</span>
                </td>
                <td align="center">
                        <span class="badge bg-warning text-black next-attempt">${item.next_attempt_at ? formatDateTime(item.next_attempt_at) : '-'}</span>
                </td>
                <td class="action text-center ">
                    ${item.status != 2 ? `
                    <form class="retry-form" data-id="${item.sno}" action="/admin/webhooks/retry/${item.sno}" method="POST">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <button type="submit" class="btn btn-sm btn-primary">Retry</button>
                    </form>` : 
                    '<span class="mdi mdi-check-circle-outline text-success"></span>'}
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/admin/webhooks?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<!-- Add Validation -->
<script>
        document.addEventListener('click', function(e) {
            if(e.target.closest('.retry-form button')){
                e.preventDefault();
                const form = e.target.closest('.retry-form');
                const sno = form.dataset.id;

                fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': form.querySelector('[name="_token"]').value,
                        'X-Requested-With': 'XMLHttpRequest',
                    }
                })
                .then(res => res.json())
                .then(res => {
                    if(res.success){
                        toastr.success('Retry triggered successfully');
                        loadThemes(currentPage); // reload current page
                    } else {
                        toastr.error('Failed to trigger retry');
                    }
                })
                .catch(err => console.error(err));
            }
        });


        var pusher = new Pusher('9996b96e908059a0d53f', {
            cluster: 'ap2',
            encrypted: true
        });
            console.log("before socket start")
        // Subscribe to the 'webhooks' channel (private channel)
       var channel = pusher.subscribe('webhooks');

     
        // Listen for the 'WebhookDispatchedEvent' event
        channel.bind('WebhookDispatchedEvent', function(e) {
            // support either e.id or e.sno
            const id = (e.id !== undefined ? e.id : e.sno);
            if (!id) return; // defensive

            const row = document.getElementById('webhook-' + id);

            // compute badge classes from status
            const statusName = e.status == 2 ? 'Success' :
                            (e.status == 3 ? 'Failed' :
                                (e.status == 1 ? 'Processing' : 'Pending'));
            const bgColorClass = e.status == 2 ? 'bg-success' :
                                (e.status == 3 ? 'bg-danger' :
                                (e.status == 1 ? 'bg-warning' : 'bg-secondary'));

            if (row) {
                // update existing row
                const statusCell = row.querySelector('.status');
                if (statusCell) {
                    statusCell.className = `badge status ${bgColorClass}`;
                    statusCell.innerText = statusName;

                    // Set tooltip title to last_response
                       const tooltipText = e.last_response ? e.last_response : '';

                        statusCell.setAttribute("title", tooltipText);
                        statusCell.setAttribute("data-bs-original-title", tooltipText);
                }
                const attemptsEl = row.querySelector('.attempts');
                if (attemptsEl) attemptsEl.innerText = e.attempts ?? '';

                const lastAttemptEl = row.querySelector('.last-attempt');
                if (lastAttemptEl) lastAttemptEl.innerText = e.last_attempt_at ? formatDateTime(e.last_attempt_at) : '-';

                const nextAttemptEl = row.querySelector('.next-attempt');
                if (nextAttemptEl) nextAttemptEl.innerText = e.next_attempt_at ? formatDateTime(e.next_attempt_at) : '-';

                // if success remove retry button
                if (e.status == 2) {
                    const actionCell = row.querySelector('.action');
                    if (actionCell) actionCell.innerHTML = '<span class="mdi mdi-check-circle-outline text-success"></span>';
                }

                 const tooltip = bootstrap.Tooltip.getInstance(statusCell);
                    if (tooltip) tooltip.dispose();
                    new bootstrap.Tooltip(statusCell);
            } else {
                // new row (insert at top)
                const tableBody = document.getElementById('list-table-body');
                tableBody.insertAdjacentHTML('afterbegin', buildRow(e, 1));
            }
        });


        function formatDateTime(dateString) {
            if (!dateString) return '';

            const date = new Date(dateString);
            const options = {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true,
            };
            return date.toLocaleString('en-GB', options).replace(',', '');
        }
</script>


<script>
function openErrorModal(dispatchSno) {

    document.getElementById('error_container').innerHTML =
        '<div class="p-4 text-center text-muted">Loading webhook logs...</div>';

    fetch(`/webhooks_log?dispatch_sno=${dispatchSno}`)
        .then(res => res.json())
        .then(res => {
            if (res.status !== 200 || !res.data) {
                throw new Error('Invalid response');
            }

            renderWebhookLog(res.data);
        })
        .catch(err => {
            document.getElementById('error_container').innerHTML =
                `<div class="p-4 text-danger">Failed to load webhook logs</div>`;
            console.error(err);
        });
}
</script>
<script>
function renderWebhookLog(data) {

    let attemptsHtml = data.attempt_logs.map((a, i) => `
        <div class="border rounded p-3 mb-3 ${a.http_status != 200 ? 'border-danger' : 'border-success'} max-h-450px scroll-y">
            <div class="d-flex justify-content-between mb-2">
                <strong>Attempt #${i + 1}</strong>
                <span class="badge ${a.http_status != 200 ? 'bg-danger' : 'bg-success'}">
                    HTTP ${a.http_status}
                </span>
            </div>

            <small class="text-muted">Attempted at: ${a.attempted_at}</small>
            <small class="text-muted">Attempted id: ${a.sno}</small>

            <hr>

            <h6 class="text-muted">Request Body</h6>
            <pre class="bg-light p-2 rounded small  max-h-350px scroll-y" >${prettyJSON(a.request_body)}</pre>

            <h6 class="text-muted mt-2">Response Body</h6>
            <pre class="bg-light p-2 rounded small  ">${renderResponseBody(a.response_body)}</pre>
        </div>
    `).join('');

    const html = `
        <div class="p-4">

            <div class="mb-3">
                <span class="badge" style="background:${data.company_base_color}">
                    ${data.company_name}
                </span>
                <span class="badge bg-dark ms-2">
                    ${data.webhook_module}
                </span>
            </div>

            <div class="mb-2">
                <strong>Entity:</strong> ${data.entity_name}
            </div>

            <div class="mb-2">
                <strong>Webhook URL:</strong><br>
                <code class="small">${data.url}</code>
            </div>

            <hr>

            <h5 class="mb-3">Dispatch Attempts</h5>

            ${attemptsHtml}
        </div>
    `;

    document.getElementById('error_container').innerHTML = html;
}

function prettyJSON(value) {
    try {
        return JSON.stringify(
            typeof value === 'string' ? JSON.parse(value) : value,
            null,
            2
        );
    } catch {
        return value || '—';
    }
}


function renderResponseBody(body) {
    if (!body) return '<pre class="bg-light p-2 rounded small max-h-350px scroll-y">—</pre>';

    const safe = escapeHTML(body);

    // HTML detected
    if (body.includes('<html') || body.includes('<!DOCTYPE')) {
        return `
            <pre class="bg-light p-2 rounded small text-danger max-h-350px scroll-y">
            ${safe}
            </pre>`;
    }

    // JSON detected
    try {
        const json = typeof body === 'string' ? JSON.parse(body) : body;
        return `
            <pre class="bg-light p-2 rounded small max-h-350px scroll-y">
                ${JSON.stringify(json, null, 2)}
            </pre>`;
    } catch {}

    // Plain text fallback
    return `
        <pre class="bg-light p-2 rounded small max-h-350px scroll-y">
            ${safe}
        </pre>`;
}

function escapeHTML(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

</script>




@endsection
