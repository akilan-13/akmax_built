<?php

namespace App\Http\Controllers\production;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\AttendanceModel;
use App\Models\BatchExtensionModel;
use App\Models\BatchModel;
use App\Models\BatchChecklistModel;
use App\Models\BranchModel;
use App\Models\FreeSlotModel;
use App\Models\ManageCertificateModel;
use App\Models\ManageCoursesModel;
use App\Models\ManageCoursesSyllabusModel;
use App\Models\ShiftTimeModel;
use App\Models\StaffCredentialModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffKnowledgeModel;
use App\Models\StaffModel;
use App\Models\StaffpointsModel;
use App\Models\StudentpointsModel;
use App\Models\StaffWorkInfoModel;
use App\Models\BatchSummaryModel;
use App\Models\SummaryReasonModel;
use App\Models\SyllabusUpdateModel;
use App\Models\TrainingModel;
use App\Models\CustomerModel;
use App\Models\CourseTypeModel;
use App\Models\FeedBackStudentQuestionModel;
use Carbon\Carbon;
use App\Models\WhatsappApiConfigureModel;
use DateTime;
use App\Models\EmailTemplateModel;
use App\Mail\EAPLMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class StaffBoard extends Controller
{
  public function index(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $user_id = $request->user()->user_id;
    $role_id = $request->user()->role_id;
    $query = StaffModel::select(
      'za_staff.sno',
      'za_staff.position_role',
      'za_staff.staff_id',
      'za_staff.staff_name',
      'za_staff.department_id',
      'za_staff.gender',
      'za_staff.dob',
      'za_staff.mobile_no',
      'za_department.department_name',
      'za_staff.email_id',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_staff.basic_salary',
      'za_staff.status AS staff_status',
      'za_staff_education_info.degree_name AS highest_degree_name',
      'za_staff_education_info.major AS highest_major',
      'za_staff_education_info.university_name AS highest_university_name',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name',
      DB::raw('COUNT(DISTINCT za_training.course_id) AS course_count'),
      DB::raw('COUNT(DISTINCT za_training.customer_id) AS customer_count'),
      DB::raw('COUNT(DISTINCT za_training.batch_id) AS batch_count')
    )
      ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
      ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->leftJoin('za_staff_education_info', function ($join) {
        $join->on('za_staff_education_info.staff_id', '=', 'za_staff.sno')
          ->whereRaw('za_staff_education_info.qualification_type = (
                            SELECT MIN(qualification_type)
                            FROM za_staff_education_info
                            WHERE staff_id = za_staff.sno
                          )');
      })
      ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_training', 'za_training.staff_id', '=', 'za_staff.sno')
      ->where('za_staff.status', 0);
    $query->whereIn('za_staff.sub_department_id', [4, 5, 13]);
    if ($branch_id > 0) {
      $query->where('za_staff.branch_id', $branch_id);
    }
    $query->groupBy(
      'za_staff.sno',
      'za_staff.position_role',
      'za_staff.status',
      'za_staff.staff_id',
      'za_department.department_name',
      'za_staff.staff_name',
      'za_staff.department_id',
      'za_staff.gender',
      'za_staff.dob',
      'za_staff.mobile_no',
      'za_staff.email_id',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_staff.basic_salary',
      'za_staff_education_info.degree_name',
      'za_staff_education_info.major',
      'za_staff_education_info.university_name',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name'
    );
    $staff = $query->orderBy('za_staff.sno', 'desc')->distinct()->get();

    if ($role_id == 22 || $role_id == 17) {
      $helper = new \App\Helpers\Helpers();
      $encryptedValue = $helper->encrypt_decrypt($user_id, 'encrypt');
      $staffBatch = url('/production/staff_board/staff_manage_batch/' . $encryptedValue);
      return redirect($staffBatch);
    }
    // return $reasonList;

    // dd($staffWithCounts);

    return view('content.production.staff_board.staff_board_list', [
      'staff' => $staff,
      'jop_position_list_fill' => '',

      'staff_name_fill' => '',
      'staff_nick_name_fill' => '',
      'department_fill' => '',
      'job_position_fill' => '',
      'job_roll_fill' => '',
    ])->with('filter_on', false);
  }

  public function list_filter(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    // Retrieve filter inputs with default values
    $staff_name_fill = $request->input('staff_name_fill', '');
    $staff_nick_name_fill = $request->input('staff_nick_name_fill', '');
    $job_position_fill = $request->input('job_position_fill_sno', '');

    $user_id = $request->user()->user_id;
    $role_id = $request->user()->role_id;
    // Start building the query
    $query = StaffModel::select(
      'za_staff.sno',
      'za_staff.position_role',
      'za_staff.staff_id',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.department_id',
      'za_staff.dob',
      'za_staff.mobile_no',
      'za_department.department_name',
      'za_staff.email_id',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_staff.basic_salary',
      'za_staff.status AS staff_status',
      'za_staff_education_info.degree_name AS highest_degree_name',
      'za_staff_education_info.major AS highest_major',
      'za_staff_education_info.university_name AS highest_university_name',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name',
      DB::raw('COUNT(DISTINCT za_training.course_id) AS course_count'),
      DB::raw('COUNT(DISTINCT za_training.customer_id) AS customer_count'),
      DB::raw('COUNT(DISTINCT za_training.batch_id) AS batch_count')
    )
      ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
      ->leftJoin('za_department', 'za_department.sno', '=', 'za_staff.department_id')
      ->leftJoin('za_staff_education_info', function ($join) {
        $join->on('za_staff_education_info.staff_id', '=', 'za_staff.sno')
          ->whereRaw('za_staff_education_info.qualification_type = (
                  SELECT MIN(qualification_type)
                  FROM za_staff_education_info
                  WHERE staff_id = za_staff.sno
              )');
      })
      ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_training', 'za_training.staff_id', '=', 'za_staff.sno')
      ->where('za_staff.status', 0);
    $query->where('za_staff.sub_department_id', 4);
    if ($branch_id > 0) {
      $query->where('za_staff.branch_id', $branch_id);
    }

    $query->groupBy(
      'za_staff.sno',
      'za_staff.position_role',
      'za_staff.status',
      'za_staff.staff_id',
      'za_staff.staff_name',
      'za_staff.gender',
      'za_staff.dob',
      'za_staff.mobile_no',
      'za_staff.email_id',
      'za_staff.department_id',
      'za_department.department_name',
      'za_staff.staff_image',
      'za_staff.nick_name',
      'za_staff.knowledge_tag',
      'za_staff.basic_salary',
      'za_staff_education_info.degree_name',
      'za_staff_education_info.major',
      'za_staff_education_info.university_name',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name'
    );

    // Apply filters if provided
    if ($staff_name_fill) {
      $query->where('za_staff.staff_name', 'LIKE', "%{$staff_name_fill}%");
    }
    if ($staff_nick_name_fill) {
      $query->where('za_staff.nick_name', 'LIKE', "%{$staff_nick_name_fill}%");
    }
    if ($job_position_fill) {
      $query->where('za_staff.position_role', $job_position_fill);
    }

    // Fetch staff list ordered by sno in descending order
    $staff = $query->orderBy('za_staff.sno', 'desc')->distinct()->get();

    // Clear specific session variables
    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');

    if ($role_id == 22) {
      $helper = new \App\Helpers\Helpers();
      $encryptedValue = $helper->encrypt_decrypt($user_id, 'encrypt');
      $staffBatch = url('/production/staff_board/staff_manage_batch/' . $encryptedValue);
      return redirect($staffBatch);
    }

    // Return the view with data
    return view('content.production.staff_board.staff_board_list', [
      'staff' => $staff,
      'job_position_list_fill' => $job_position_fill,
      'staff_name_fill' => $staff_name_fill,
      'staff_nick_name_fill' => $staff_nick_name_fill,
      'job_position_fill' => $job_position_fill,
    ])->with('filter_on', true);
  }


  public function staff_manage_batch($id, Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $branchId = $request->user()->branch_id;
    $staff = StaffModel::where('za_staff.sno', $id)->where('za_staff.status', 0)->first();

    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno')
      ->where('za_training.status', '!=', 2);

    // Fetch batch data with necessary joins
    $batches = BatchModel::where('za_batch.staff_id', $id)
      ->select(
        'za_batch.sno',
        'za_batch.status',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        // 'za_batch_extension.status as exten_status',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        DB::raw('(
            SELECT COUNT(*)
            FROM za_training
            WHERE za_training.batch_id = za_batch.sno
              AND za_training.status != 2
        ) as allocated_students')
      )
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      // ->leftJoin('za_batch_extension', 'za_batch.sno', '=', 'za_batch_extension.batch_id')
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->where('za_batch.start_date', '<=', today())
      ->where('za_batch.status', 0)
      // ->where('za_batch_extension.status', 0)
      ->groupBy(
        'za_batch.sno',
        'za_batch.status',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        // 'za_batch_extension.status',
        'za_slot.end_time'
      )
      ->get();

    // return $batches;

    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    // $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Get the current day of the week
    $currentDay = Carbon::now()->format('l');

    // Map through the batches to format dates and add additional fields
    $formattedBatches = $batches->map(function ($item) use ($dateFormat, $days) {
      // Format dates and times
      $item->formatted_start_date = Carbon::parse($item->start_date)->format($dateFormat);
      $item->formatted_end_date = Carbon::parse($item->end_date)->format($dateFormat);
      $item->formatted_start_time = Carbon::parse($item->start_time)->format('h:i:A'); // Use 'H:i' for sorting
      $item->formatted_end_time = Carbon::parse($item->end_time)->format('h:i:A'); // Use 'H:i' for sorting



      // Convert slot_type_days from JSON to an array of day names
      $dayIndices = json_decode($item->slot_type_days);
      $dayNames = [];

      foreach ($dayIndices as $index) {
        // $dayIndex = (int)$index - 1; // Convert to 0-based index
        $dayIndex = (int)$index;
        $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
      }

      // Join day names into a comma-separated string
      $item->days = implode(', ', $dayNames);

      // Calculate available students
      $isAttendanceHave = AttendanceModel::where('batch_id', $item->sno) // Fixed undefined variable
        ->whereDate('att_date', now()->format('Y-m-d'))
        ->count(); // Get count of attendance records

      // Assign the attendance count to the item
      $item->is_attendance_have = $isAttendanceHave > 0 ? $isAttendanceHave : 0;

      return $item;
    });

    // Filter batches to only include those where current day is in the days
    $filteredBatches = $formattedBatches->filter(function ($item) use ($currentDay) {
      return in_array($currentDay, explode(', ', $item->days));
    });

    // Sort batches by start time
    $sortedBatches = $filteredBatches->sortBy('formatted_start_time');
    // return $sortedBatches;
    $checklist = BatchChecklistModel::select('*')->where('status', '=', 0)->get();

    // return $staff;
    return view('content.production.staff_board.staff_manage_batch', compact('sortedBatches', 'staff', 'checklist'));
  }


  public function studentDetails($id, Request $request)
  {
    // Get the current date and day
    $currentDate = now()->format('d-M-Y'); // e.g., 12-Aug-2024
    $currentDay = now()->format('D'); // e.g., Mon

    // Fetch batch details
    $batch = BatchModel::where('za_batch.sno', $id)
      ->where('za_batch.status', 0)
      ->select('za_batch.*', 'za_course.course_days', 'za_course.course_duration', 'za_course.course_name', 'za_course.course_version', 'za_course_type.course_type_name', 'za_slot.slot_name', 'za_slot.start_time', 'za_slot.end_time')
      ->join('za_course', 'za_batch.course_id', '=', 'za_course.sno')
      ->join('za_course_type', 'za_course.course_type_id', '=', 'za_course_type.sno')
      ->join('za_slot', 'za_batch.slot_id', '=', 'za_slot.sno')
      ->first();
    // Subquery to calculate allocated students
    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno');

    $batches = BatchModel::where('za_batch.sno', $id)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
      )
      ->leftJoin('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->leftJoin('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->leftJoin('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->where('za_batch.status', '!=', 2)
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        'za_slot.end_time'
      )
      ->get();

    // Fetch student details
    $students = TrainingModel::where('za_training.batch_id', $batch->sno)
      //   ->where('za_training.staff_id', $batch->staff_id)
      ->where('za_training.course_id', $batch->course_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_name', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->leftJoin('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->leftJoin('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->where('za_customer.status', '!=', 6)
      ->get();
    // return $batches;
    return response()->json([
      'status' => 200,
      'message' => 'Student details successfully retrieved!',
      'data' => [
        'current_date' => $currentDate,
        'current_day' => $currentDay,
        'students' => $students,
        'batch_details' => $batch
      ],
    ]);
  }


  public function Attendance(Request $request)
  {
    $helper = new \App\Helpers\Helpers();
    $validator = Validator::make($request->all(), [
      'batch_id'         => 'required',
      'student_ids'      => 'required|array',
      'student_ids.*'    => 'required|integer',  // Ensure each student ID is an integer
      'attendance'      => 'required|array',
      'attendance.*'    => 'required|string',    // Ensure each attendance value is a string
      'current_duration' => 'required|array',
      'current_duration.*' => 'required|integer',
      'total_days'      => 'required|integer', // Ensure total_days is an integer
      'total_durations' => 'required|integer', // Ensure total_durations is an integer
    ]);

    if ($validator->fails()) {
      return response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $currentDate = now()->format('Y-m-d');
      $batch_id = $request->batch_id;
      $student_ids = $request->student_ids;
      $attendance = $request->attendance;
      $current_duration = $request->current_duration;
      $user_id = $request->user()->user_id;
      $branch_id = $request->user()->branch_id;
      $total_days = $request->total_days;
      $total_durations = $request->total_durations;

      // return $request;

      $batch = BatchModel::where('sno', $batch_id)->first();
      $branch_check = BranchModel::where('sno', $branch_id)->orderBy('sno', 'desc')->first();
      $branch_code = $branch_check->city_short_code;



      // Ensure that the arrays have the same length
      if (count($student_ids) !== count($attendance) || count($student_ids) !== count($current_duration)) {
        return response([
          'status'    => 401,
          'message'   => 'Mismatch in array lengths',
          'data'      => null,
        ], 200);
      }

      // Save attendance records
      foreach ($student_ids as $index => $student_id) {

        $cos_check = AttendanceModel::orderBy('sno', 'desc')->first();
        if (!$cos_check) {
          $year = date("Y");
          $attendance_id = $year . '/' . $branch_code . '/' . "AT0001";
        } else {
          $data = $cos_check->attendance_id;
          $slice = explode("/", $data);
          $result_cos = preg_replace('/[^0-9]/', '', $slice[2]);
          $next_number_cos = (int)$result_cos + 1;
          $request_cos = sprintf("AT%04d", $next_number_cos);
          $year = date("Y");
          $attendance_id = $year . '/' . $branch_code . '/' . $request_cos;
        }
        $minusDuration = ($total_days > 0 && $attendance[$index] == 'P') ? $total_durations / $total_days : 0;
        $courses = TrainingModel::where('batch_id', $batch->sno)->where('customer_id', $student_id)->first();
        $per_hr_cost = $courses->overall_fees / $total_durations;
        $total_cost = $per_hr_cost * $minusDuration;

        $add_category = new AttendanceModel();
        $add_category->attendance_id = $attendance_id;
        $add_category->att_date      = $currentDate;
        $add_category->customer_id   = $student_id;
        $add_category->course_id     = $batch->course_id;
        $add_category->batch_id      = $batch_id;
        $add_category->staff_id      = $batch->staff_id;
        $add_category->attendance    = $attendance[$index];
        $add_category->total_duration = $minusDuration;
        $add_category->per_hr_cost    = $per_hr_cost;
        $add_category->total_cost     = $total_cost;
        $add_category->branch_id     = $branch_id;
        $add_category->created_by    = $user_id;
        $add_category->updated_by    = $user_id;
        $add_category->status        = 1;
        $add_category->save();

        if ($attendance[$index] == 'P') {
          $stud_points = 15;
        } elseif ($attendance[$index] == 'A') {
          $stud_points = 16;
        } elseif ($attendance[$index] == 'L') {
          $stud_points = 17;
        }
        $pointsDataFullAttendance = $helper->get_points_by_id($stud_points); // Points for P
        $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
        $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

        // Save new points for the staff (full attendance)
        $newPointsFull = new StudentpointsModel();
        $newPointsFull->branch_id = $branch_id;
        $newPointsFull->student_id = $student_id;
        $newPointsFull->points_id = $stud_points;
        $newPointsFull->points = $pointFull;
        $newPointsFull->reason = $reasonFull;
        $newPointsFull->save();

        // Update staff's available points
        $student_points = CustomerModel::where('sno', $student_id)->first();
        if ($student_points) {
          $student_points->points_score += $pointFull;
          $student_points->save();
        }
      }

      if ($add_category) {
        // Check if all attendance values are 'A'
        if (count(array_diff($attendance, ['A'])) == 0) {
          \Log::info('All attendance is A: ', $attendance);
          return response([
            'status' => 302,
            'message' => 'All attendance is A. Redirecting...',
            'redirect_url' => '/production/staff_board',
          ], 302)->header('Content-Type', 'application/json');
        }

        if (!in_array('A', $attendance) || !in_array('L', $attendance)) {
          $helper = new \App\Helpers\Helpers();
          // return $attendance;

          $pointsDataFullAttendance = $helper->get_points_by_id(7); // Points for full attendance
          $pointFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points : 0;
          $reasonFull = $pointsDataFullAttendance ? $pointsDataFullAttendance->points_name : '';

          // Save new points for the staff (full attendance)
          $newPointsFull = new StaffpointsModel();
          $newPointsFull->branch_id = $branch_id;
          $newPointsFull->staff_id = $user_id;
          $newPointsFull->points_by = $batch_id;
          $newPointsFull->points_id = 7;
          $newPointsFull->points = $pointFull;
          $newPointsFull->reason = $reasonFull;
          $newPointsFull->save();

          // Update staff's available points
          $staff_points = StaffModel::where('sno', $user_id)->first();
          if ($staff_points) {
            $staff_points->avaiable_points += $pointFull;
            $staff_points->save();
          }
        }

        // Update Staff Faculty Points
        // Define point category:
        // 6 Attendance, 7 Full Attendance, 8 5 Star Review, 9 Course Complete On time, 10 Student Placed
        $helper = new \App\Helpers\Helpers();
        $pointsData = $helper->get_points_by_id(6);
        $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
        $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string

        // Save new points for the staff
        $newPoints = new StaffpointsModel();
        $newPoints->branch_id = $branch_id;
        $newPoints->staff_id = $user_id;
        $newPoints->points_by = $batch_id;
        $newPoints->points_id = 6;
        $newPoints->points = $point;
        $newPoints->reason = $reason;
        $newPoints->save();

        // Update staff's available points
        $staff_points = StaffModel::where('sno', $user_id)->first();
        if ($staff_points) {
          $staff_points->avaiable_points += $point; // Increment the available points
          $staff_points->save();
        }

        return response([
          'status'    => 200,
          'message'   => 'Attendance added successfully!',
          'error_msg' => null,
          'data'      => null,
        ], 200)->header('Content-Type', 'application/json');
      } else {
        $result = response([
          'status'    => 401,
          'message'   => 'Attendance not added!',
          'error_msg' => 'Incorrect format input feilds',
          'data'      => null,
        ], 401);
      }
      return $result;
    }
  }


  public function staff_manage_batch_feedback($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }

    // Initialize arrays for chapters, sections, and topics
    $topics = [];


    // Subquery to calculate allocated students
    $allocatedStudentsSubquery = DB::table('za_training')
      ->select(DB::raw('COUNT(*)'))
      ->whereRaw('za_training.batch_id = za_batch.sno');

    // Fetch batch data with necessary joins
    $batch = BatchModel::where('za_batch.sno', $decryptedValue)
      ->select(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.classroom_id',
        'za_batch.course_summ',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_days',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time as slot_start_time',
        'za_slot.end_time as slot_end_time',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image',
        DB::raw('(' . $allocatedStudentsSubquery->toSql() . ') as allocated_students')
      )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->leftJoin('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->where('za_batch.status', '!=', 2)
      ->where('za_slot_type.status', '!=', 2)
      ->where('za_slot.status', '!=', 2)
      ->groupBy(
        'za_batch.sno',
        'za_batch.batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_slot.slot_type_days',
        'za_batch.max_students',
        'za_batch.course_summ',
        'za_batch.classroom_id',
        'za_class_room.class_room_name',
        'za_batch.course_id',
        'za_course.course_name',
        'za_course.course_days',
        'za_course.course_version',
        'za_batch.course_type_id',
        'za_course_type.course_type_name',
        'za_batch.slot_id',
        'za_slot.slot_name',
        'za_slot_type.slot_type_name',
        'za_slot.start_time',
        'za_slot.end_time',
        'za_staff.staff_name',
        'za_staff.nick_name',
        'za_staff.gender',
        'za_staff.staff_image'
      )
      ->first();
    // dd($batch);
    // Fetch general settings
    $helper = new Helpers();
    $generalSettings = $helper->general_setting_data();

    // Check if general settings are available
    $dateFormat = $generalSettings ? $generalSettings->date_format : 'Y-m-d'; // Default to 'Y-m-d' if not available

    // Define days of the week
    $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];


    // Format dates and times
    $batch->formatted_created = Carbon::parse($batch->create_at)->format($dateFormat);
    $batch->formatted_start_date = Carbon::parse($batch->start_date)->format($dateFormat);
    $batch->formatted_end_date = Carbon::parse($batch->end_date)->format($dateFormat);
    $batch->formatted_start_time = Carbon::parse($batch->start_time)->format('h:i A'); // 12-hour format with AM/PM
    $batch->formatted_end_time = Carbon::parse($batch->end_time)->format('h:i A');   // 12-hour format with AM/PM


    // Convert slot_type_days from JSON to an array of day names
    $dayIndices = json_decode($batch->slot_type_days);
    $dayNames = [];

    foreach ($dayIndices as $index) {
      //   $dayIndex = (int)$index - 1; // Convert to 0-based index
      $dayIndex = (int)$index;
      $dayNames[] = isset($days[$dayIndex]) ? $days[$dayIndex] : '-';
    }

    // Join day names into a comma-separated string
    $batch->days = implode(', ', $dayNames);

    // Calculate available students
    $batch->available_students = $batch->max_students - $batch->allocated_students;
    // return $batch;

    $students = TrainingModel::where('za_training.batch_id', $batch->sno)
      // ->where('za_training.staff_id', $batch->staff_id)
      ->where('za_training.course_id', $batch->course_id)
      ->where('za_training.status', 0)
      ->select('za_customer.sno', 'za_customer.cus_pic', 'za_customer.cus_name', 'za_customer.cus_gender', 'za_customer.customer_id', 'za_customer.cus_gender', 'za_course.course_days', 'za_course.course_duration')
      ->join('za_customer', 'za_training.customer_id', '=', 'za_customer.sno')
      ->join('za_course', 'za_training.course_id', '=', 'za_course.sno')
      ->get();


    // Find the course by decrypted ID
    $view = ManageCoursesModel::where('sno', $batch->course_id)->first();

    // Check if the course is not found
    if (!$view) {
      return redirect()->back()->with('error', 'Course View not found');
    }
    // Fetch unique chapters with their latest section based on maximum sno
    $chapter_views = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
      ->select('course_chapter_id', DB::raw('MAX(sno) as max_sno'))
      ->groupBy('course_chapter_id')
      ->orderBy('sno', 'ASC')
      ->get();

    foreach ($chapter_views as $chapter) {
      // Fetch the latest section for each chapter
      $latest_sections = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
        ->where('course_chapter_id', $chapter->course_chapter_id)
        ->select('session_id', DB::raw('MAX(sno) as max_sno'))
        ->where('status', 0)
        ->orderBy('sno', 'ASC')
        ->groupBy('session_id')
        ->get();

      foreach ($latest_sections as $sec) {
        // Fetch the latest topics for each section
        $latest_topics = ManageCoursesSyllabusModel::where('course_id', $batch->course_id)
          ->where('course_chapter_id', $chapter->course_chapter_id)
          ->where('session_id', $sec->session_id)
          ->where('status', 0)
          ->select('topic_id', DB::raw('MAX(sno) as max_sno'))
          ->orderBy('sno', 'ASC')
          ->groupBy('topic_id')
          ->get();


        // Store topics under each section
        $topics[$chapter->course_chapter_id][$sec->session_id] = $latest_topics;
        // $topics[$chapter->course_chapter_id][$sec->session_id] = SyllabusUpdateModel::where('batch_id', $batch->sno)
        //   ->where('chapter_id', $chapter->course_chapter_id)
        //   ->where('section_id', $sec->session_id)
        //   // ->whereIn('topic_id', $latest_topics->pluck('topic_id')->toArray())
        //   // ->where('staff_id', $batch->staff_id)
        //   ->get();
      }
    }


    $reasonList = SummaryReasonModel::select('*')
      ->where('status', 0)
      ->orderBy('sno', 'desc')->get();

    // return $topics;

    return view('content.production.staff_board.staff_manage_batch_feedback', [
      'view'              => $view,
      'topics'            => $topics,
      'batch_edit_id'   => $decryptedValue,
      'batch'             => $batch,
      'students'          => $students,
      'reasonList'        => $reasonList
    ]);
  }


  public function staff_board_view($id = '')
  {
    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    // Fetch staff details for editing
    $view = StaffModel::select(
      'za_staff.*',
      'za_staff.sno AS staff_sno',
      'za_staff.user_name AS loginuser_name',
      'za_staff.password AS loginpassword',
      'za_staff.status AS staff_status',
      'za_job_position.job_position_name',
      'za_staff_work_info.staff_type',
      'za_shift_time.shift_start_time',
      'za_shift_time.shift_end_time',
      'za_shift_time.shift_lunch_start',
      'za_shift_time.shift_lunch_end',
      'za_shift_time.shift_time_name'
    )
      ->leftJoin('za_staff_credential', 'za_staff_credential.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_education_info', 'za_staff_education_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_shift_time', 'za_shift_time.shift_time_id', '=', 'za_staff.sno')
      ->leftJoin('za_staff_work_info', 'za_staff_work_info.staff_id', '=', 'za_staff.sno')
      ->leftJoin('za_job_position', 'za_job_position.sno', '=', 'za_staff.position_role')
      ->where('za_staff.status', '!=', 2)
      ->where('za_staff.sno', '=', $decryptedValue)
      ->first();

    $educationInfo = StaffEducationInfoModel::where('staff_id', $decryptedValue)
      ->where('status', '!=', 2)
      ->get();

    $workInfo = StaffWorkInfoModel::where('staff_id', $decryptedValue)
      ->where('status', '!=', 2)
      ->get();

    $credentialInfo = StaffCredentialModel::join('za_credential', 'za_credential.sno', '=', 'za_staff_credential.credential_id')
      ->where('za_staff_credential.status', '!=', 2)
      ->where('za_staff_credential.staff_id', '=', $decryptedValue)
      ->get();

    $shiftTime = ShiftTimeModel::where('sno', $view->shift_time_id)
      ->first();
    // return $view->shift_time_id;

    $staffknowledgeInfo = StaffKnowledgeModel::join('za_knowledge_tag', 'za_knowledge_tag.sno', '=', 'za_staff_knowledge_tag.knowledge_id')
      ->where('za_staff_knowledge_tag.status', '!=', 2)
      ->where('za_staff_knowledge_tag.staff_id', '=', $decryptedValue)
      ->select('za_knowledge_tag.knowledge_tag_name') // Select columns you need
      ->get();

    return view('content.production.staff_board.staff_board_view', [
      'view' => $view,
      'educationInfo' => $educationInfo,
      'workInfo' => $workInfo,
      'credentialInfo' => $credentialInfo,
      'staffknowledgeInfo' => $staffknowledgeInfo,
      'shiftTime' => $shiftTime,
      'id' => $decryptedValue,
    ]);
  }


  public function SyllabusUpdate(Request $request)
  {
    // Validate request inputs
    $validator = Validator::make($request->all(), [
      'batch_id' => 'required',
      'chapter_id' => 'required',
      'section_id' => 'required',
      'topics' => 'required|json',
    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Validation errors',
        'error_msg' => $validator->errors(),
        'data' => null,
      ], 200);
    }

    $date = now()->format('Y-m-d');
    $batch_id = $request->batch_id;
    $chapter_id = $request->chapter_id;
    $section_id = $request->section_id;
    $reason = $request->reason;
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    // Fetch the batch
    $batch = BatchModel::where('sno', $batch_id)->first();

    // Decode topics
    $topics = json_decode($request->topics, true);

    foreach ($topics as $topic) {
      $topic_id = $topic['topic_id'];
      $percentage = $topic['percentage'];

      // Update or create the syllabus entry
      $upd_check = SyllabusUpdateModel::where([
        ['batch_id', $batch_id],
        ['chapter_id', $chapter_id],
        ['section_id', $section_id],
        ['topic_id', $topic_id],
      ])->first();

      if ($upd_check) {
        $upd_check->update([
          'date' => $date,
          'staff_id' => $user_id,
          'course_id' => $batch->course_id,
          'percentage' => $percentage,
          'reason' => $reason,
          'branch_id' => $branch_id,
          'updated_by' => $user_id,
        ]);
      } else {
        // Create new syllabus entry
        $latest = SyllabusUpdateModel::latest('sno')->first();
        $year = date("Y");
        $latest_id_parts = $latest ? explode("/", $latest->syllabus_update_id) : null;
        $latest_number = $latest_id_parts && isset($latest_id_parts[2])
          ? (int) preg_replace('/[^0-9]/', '', $latest_id_parts[2])
          : 0;

        $branch_code = BranchModel::where('sno', $branch_id)->value('city_short_code');
        $syllabus_update_id = $year . '/' . $branch_code . '/SU' . sprintf('%04d', $latest_number + 1);

        SyllabusUpdateModel::create([
          'syllabus_update_id' => $syllabus_update_id,
          'date' => $date,
          'staff_id' => $user_id,
          'course_id' => $batch->course_id,
          'batch_id' => $batch_id,
          'chapter_id' => $chapter_id,
          'section_id' => $section_id,
          'topic_id' => $topic_id,
          'percentage' => $percentage,
          'reason' => $reason ?? '',
          'branch_id' => $branch_id,
          'created_by' => $user_id,
          'updated_by' => $user_id,
        ]);
      }
    }

    return response([
      'status' => 200,
      'message' => 'Syllabus updated successfully!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function SyllabusEdit(Request $request)
  {
    // Combine the id and extra to form the complete section_id
    $sectionId = $_GET['id'] ?? '';
    $batch_id = $_GET['batch_id'] ?? '';
    $course_id = $_GET['course_id'] ?? '';
    $chapterId = $_GET['chapterId'] ?? '';

    // return $sectionId;

    // Fetch the syllabus data using the combined section_id
    $syllabus = SyllabusUpdateModel::where('section_id', $sectionId)->where('batch_id', $batch_id)
      ->where('course_id', $course_id)
      ->where('chapter_id', $chapterId)
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'data' => $syllabus,
    ]);
  }

  public function get_topics_data()
  {
    $sectId = $_GET['sectId'];
    $course_id = $_GET['course_id'] ?? '';
    $chapterId = $_GET['chapterId'] ?? '';
    $topics_data = ManageCoursesSyllabusModel::where('session_id', $sectId)
      ->where('course_id', $course_id)
      ->where('course_chapter_id', $chapterId)
      ->where('status', 0)
      ->orderBy('sno', 'ASC')
      ->select('*')
      ->get();

    if ($topics_data->isEmpty()) {
      return response()->json(['error' => 'No topics found'], 404);
    }
    // return $topics_data;
    return response()->json($topics_data);
  }


  public function BatchExtension(Request $request)
  {
    // return $request;
    $branch_id = $request->user()->branch_id;
    $validator = Validator::make($request->all(), [
      'batch_id_extension' => 'required', // Ensure batch_id is present for update
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $batch_id = $request->batch_id_extension;
      $reason = $request->batch_reason_extension;
      $end_date = date('Y-m-d', strtotime($request->batch_end_date_old_hidden));
      $change_date = date('Y-m-d', strtotime($request->end_date_extension));
      $user_id =  $request->user()->user_id;

      $add_category = new BatchExtensionModel();
      $add_category->batch_id = $batch_id;
      $add_category->end_date = $end_date;
      $add_category->change_date = $change_date;
      $add_category->branch_id = $branch_id;
      $add_category->reason = $reason;
      $add_category->created_by = $user_id;
      $add_category->updated_by = $user_id;

      $add_category->save();
      if ($add_category) {
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Batch updated Successfully!',
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not update the Batch!',
        ]);
      }

      return redirect()->back()->with('success', 'Batch updated successfully!');
    }
  }

  public function ExtendBatchEdit($id = '')
  {
    // return $id;

    // Check if decryption failed
    if ($id === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    // Find the course by decrypted ID
    $extend_batch = BatchModel::select(
      'za_batch.*',
      'za_batch.batch_name',
      'za_slot.slot_name',
      'za_course.course_name',
      'za_course_type.course_type_name',
      'za_slot.start_time',
      'za_slot.end_time',
      'za_staff.staff_name',
      'za_class_room.class_room_name',
      'za_batch_extension.sno as batch_extend_sno',
      'za_batch_extension.change_date',
      'za_batch_extension.reason'
    )
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_staff', 'za_batch.staff_id', '=', 'za_staff.sno')
      ->join('za_class_room', 'za_class_room.sno', '=', 'za_batch.classroom_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_batch.course_type_id')
      ->leftJoin('za_batch_extension', 'za_batch_extension.batch_id', '=', 'za_batch.sno') // Use leftJoin to include batches without extensions
      ->where('za_batch.status', '!=', 2)
      ->where('za_batch.sno', $id)
      ->first();


    // dd($extend_batch);

    // Check if the course is not found
    if (!$extend_batch) {
      return redirect()->back()->with('error', 'Batch View not found');
    }

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $extend_batch,
    ], 200);
  }

  public function ExtendBatchApprove(Request $request)
  {
    // dd($request);
    $id = $request->extend_sno;
    $batch_sno = $request->batch_id_approve;
    $status = 1;
    // return $status;
    $end_date = $request->batch_change_date_approve_hidden;
    // dd($end_date);
    $BatchModel = BatchExtensionModel::where('sno', $id)->first();
    $BatchModel->status = $status;
    $BatchModel->Update();

    // return $BatchModel;
    //update Batch
    $batch_upd = BatchModel::where('sno', $batch_sno)->first();
    if ($batch_upd) {
      $batch_upd->end_date = date('Y-m-d', strtotime($end_date));
      $batch_upd->Update();
    }
    // return $batch_upd;

    // return  $training_upd;
    if ($batch_upd) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Batch updated Successfully!',
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Batch!',
      ]);
    }

    return redirect()->back()->with('success', 'Batch updated successfully!');
  }

  public function Complete(Request $request)
  {
    $batch_id = $request->batch_id;
    $checklist = json_decode($request->checklist, true);
    $user_id = $request->user()->user_id;
    $branch_id = $request->user()->branch_id;

    $batch_check = BatchChecklistModel::select('*')->where('status', '=', 0)->get();

    // Create the checklist array in the desired format
    $checklistArray = [];
    foreach ($batch_check as $item) {
      $checklistArray[] = [
        'id' => $item->sno,
        'value' => 1,  // Assuming the value is always 1 as per your example
      ];
    }

    // Fetch the BatchModel and check if it exists
    $BatchModel = BatchModel::where('sno', $batch_id)->first();
    if (!$BatchModel) {
      return response([
        'status' => 404,
        'message' => 'Batch not found!',
        'error_msg' => null,
        'data' => null,
      ], 404);
    }

    // Update batch status
    $BatchModel->status = 3;
    $BatchModel->checklist = json_encode($checklistArray);  // Save the checklist as a JSON string
    if (!$BatchModel->update()) {
      return response([
        'status' => 500,
        'message' => 'Could not update batch status!',
        'error_msg' => null,
        'data' => null,
      ], 500);
    }

    // return $BatchModel;

    $EXTBatchModel = BatchExtensionModel::where('batch_id', $batch_id)->first();
    if (!$EXTBatchModel) {
      // Update Staff Faculity Points
      // Define point category:
      // 6 Attendence, 7 Full Attendence, 8 5 Star Review, 9 Course Complete On time, 10 Student Placed
      $helper = new \App\Helpers\Helpers();
      $pointsData = $helper->get_points_by_id(9);
      $point = $pointsData ? $pointsData->points : 0; // Default points to 0 if not found
      $reason = $pointsData ? $pointsData->points_name : ''; // Default reason to an empty string
      // Save new points for the staff
      $newPoints = new StaffpointsModel();
      $newPoints->branch_id = $branch_id;
      $newPoints->staff_id = $user_id;
      $newPoints->points_by = $batch_id;
      $newPoints->points_id = 9;
      $newPoints->points = $point;
      $newPoints->reason = $reason;
      $newPoints->save();
      // Update staff's available points
      $staff_points = StaffModel::where('sno', $user_id)->first();
      if ($staff_points) {
        $staff_points->avaiable_points += $point; // Increment the available points
        $staff_points->save();
      }
    }

    //update freeslot
    $freeSlot_upd = FreeSlotModel::where('batch_id', $batch_id)->first();
    if ($freeSlot_upd) {
      $freeSlot_upd->status = 3;
      $freeSlot_upd->Update();
    }

    // dd($BatchModel);

    // Fetch related customers
    $customers = TrainingModel::where('batch_id', $batch_id)->get();
    if ($customers->isEmpty()) {
      return response([
        'status' => 404,
        'message' => 'No customers found for this batch!',
        'error_msg' => null,
        'data' => null,
      ], 404);
    }
    // dd($customers);

    $student_ids = [];
    foreach ($customers as $customer) {
      if ($customer->branch_id == $branch_id && $customer->batch_id == $batch_id) {
        $student_ids[] = $customer->sno;
      }
    }
    // return $student_ids;

    // Create new certificate record
    $add_certificate = new ManageCertificateModel();
    $add_certificate->branch_id = $branch_id;
    $add_certificate->batch_id = $batch_id;
    $add_certificate->batch_cmpltd_date = date('Y-m-d', strtotime($BatchModel->updated_at));
    $add_certificate->cert_status_id = 1;
    $add_certificate->student_id = json_encode($student_ids);
    $studentIdsArray = json_decode($add_certificate->student_id, true);
    // return $add_certificate;
    if (is_array($studentIdsArray)) {
      $add_certificate->total_stud_count = count($studentIdsArray);
    } else {
      $add_certificate->total_stud_count = 0; // or handle it as needed
    }
    $add_certificate->created_by = $user_id;
    $add_certificate->updated_by = $user_id;




    if (!$add_certificate->save()) {
      return response([
        'status' => 500,
        'message' => 'Could not save certificate!',
        'error_msg' => null,
        'data' => null,
      ], 500);
    }


    $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)
      ->first();
    $batchData = BatchModel::where('za_batch.sno', $batch_id)->select(
      'za_batch.*',
      'za_course.course_name',
    )
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->first();

    $customerIds = TrainingModel::where('batch_id', $batch_id)->where('status', '!=', 2)
      ->distinct('customer_id')->pluck('customer_id');

    $customers = CustomerModel::whereIn('sno', $customerIds)->get();

    $branch_name = $branchData->branch_type == 1 ? $branchData->branch_name : $branchData->franchise_name;

    $helper = new \App\Helpers\Helpers();

    foreach ($customers as $customer) {
      $encrypted_values = $helper->encrypt_decrypt($customer->sno, 'encrypt');
      $encrypted_batch_id = $helper->encrypt_decrypt($batch_id, 'encrypt');
      $Link = url('student_feedback/' . $encrypted_values . '/' . $encrypted_batch_id);

      // Shorten the link if needed
      $channelId = 17;
      $shortUrlData = $this->shortenUrl($Link, $channelId);
      $shortUrl = $shortUrlData['shorturl'] ?? $Link; // fallback to full link





      // Save feedback link in DB
      DB::table('za_customer')->where('sno', $customer->sno)->update(['feedback_link' => $shortUrl]);

      $shortcustomer = DB::table('za_customer')->where('sno', $customer->sno)->first();
      $shortsendUrl = $shortcustomer->feedback_link;
      $feedback_key = basename($shortsendUrl);
      //  Mail
      if ($customer->cus_email_id) {
        try {
          $email_template_id = 20; // Feedback email template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $customer->cus_name, $content);
          $content = str_replace('#CourseName', $batchData->course_name ?? 'Course', $content);
          $content = str_replace('#BatchName', $batchData->batch_name ?? 'Batch', $content);
          $content = str_replace('#link', $shortUrl, $content);
          $content = str_replace('#CRENo', $branchData->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branchData->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchData->mobile,
            'branchemail' => $branchData->mail,
            'fbLink' => $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/',
            'instaLink' => $branchData->insta_link ?? 'https://www.instagram.com/elysiumacademy/',
            'salesMobile' => $branchData->sales_mobile,
          ];

          $to_address = $customer->cus_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium Academy ' . "\xC2\xAE";
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

          DB::table('za_customer')->where('sno', $customer->sno)->update(['email_send' => 1]);
        } catch (\Exception $e) {
          DB::table('za_customer')->where('sno', $customer->sno)->update(['email_send' => 2]);
        }
      }
      //  whatsapp
      if ($customer->cus_mobile) {


        // $templateName  = "hello_world";
        $templateName  = "send_feedback";

        $hasHeader  = false; // Example flag: set based on template
        $hasBody    = false; // Example flag: set based on template
        $hasFooter  = false; // Example flag: set based on template
        $hasButton  = false;
        $components = [];
        $couponCode = " ";
        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
        // $currentHour = date('H'); // Get current hour in 24-hour format
        if ($currentHour >= 5 && $currentHour < 12) {
          $greeting = 'Good Morning';
        } elseif ($currentHour >= 12 && $currentHour < 18) {
          $greeting = 'Good Afternoon';
        } else {
          $greeting = 'Good Evening';
        }

        if ($templateName == 'send_feedback') {
          $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/OnBoard.jpg';
          // $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
          $couponCode  = 'NOOFFER';
          $buttonIndex = 1;
          $bodyText    = [
            [
              'type'           => 'text',
              'text'           => $customer->cus_name ?? "student",
              'parameter_name' => 'stu_name',
            ],
            [
              'type'           => 'text',
              'text'           => $batchData->course_name ?? "Course",
              'parameter_name' => 'cour_name',
            ],
            [
              'type'           => 'text',
              'text'           => $shortUrl,
              'parameter_name' => 'feed_link',
            ]
          ];
          $hasHeader = true;
          $hasBody   = true;
          $hasButton = true;
        }

        // Add Header if required
        if ($hasHeader) {
          $components[] = [
            'type'       => 'header',
            'parameters' => [
              [
                'type'  => 'image',
                'image' => [
                  'link' => $headerImage, // Dynamically set header image
                ],
              ],
            ],
          ];
        }

        // Add Body if required
        if ($hasBody) {
          $components[] = [
            'type'       => 'body',
            'parameters' => $bodyText,
          ];
        }

        // Add Footer if required
        if ($hasButton) {
          $components[] = [
            'type'       => 'button',
            'sub_type'   => 'url',
            'index'      => 0,
            'parameters' => [
              [
                'type' => 'text',
                'text' => $feedback_key,
              ],
            ],
          ];
        }


        $dynamicParameters         = $templateParameters[$templateName] ?? [];
        $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
        $accessToken               = $this->accessData($request)->access_tokken;
        $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

        $mobile = preg_replace('/\D/', '', $customer->cus_mobile); // remove any non-digits
        if (strpos($customer->cus_mobile, '+') === 0) {
          $to = $customer->cus_mobile;
        } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
          $to = '+' . $mobile;
        } else {
          $to = '+91' . $mobile;
        }
        $languageCode = 'en';

        // if (strpos($to, $countryCode) !== 0) {
        //     $to = $countryCode . $to;
        // }

        $message = 'test~message';
        if (empty($components)) {
          $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
              'name'     => $templateName,
              'language' => [
                'code' => $languageCode,
              ],
            ],
          ];
        } else {
          $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
              'name'       => $templateName,
              'language'   => [
                'code' => $languageCode,
              ],
              'components' => $components,
            ],
          ];
        }

        $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        if ($response['status'] == 200) {
        } else {

          return response([
            'status' => 404,
            'message' => 'Failed to send message',
            'certificate_status' => 2,
            'error_msg' => $response['error'],
          ], 400);
        }
      } else {
        return response([
          'status' => 200,
          'message' => 'Mobile no not found',
          'error_msg' => 'mobile no not found',
          'certificate_status' => 0,
        ], 200);
      }
    }




    return response([
      'status' => 200,
      'message' => 'Batch Successfully Completed!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function accessData(Request $request)
  {

    $whatsappConfig = WhatsappApiConfigureModel::where('branch_id', 6)->first();
    return $whatsappConfig;
  }

  private function sendRequestToWhatsApp($url, $token, $data)
  {
    try {
      $client = new \GuzzleHttp\Client();
      $response = $client->post($url, [
        'headers' => [
          'Authorization' => 'Bearer ' . $token,
          'Content-Type' => 'application/json',
        ],
        'json' => $data,

      ]);

      return [
        'status' => $response->getStatusCode(),
        'data' => json_decode($response->getBody(), true),
      ];
    } catch (\Exception $e) {
      return [
        'status' => 400,
        'error' => $e->getMessage(),
      ];
    }
  }
  public function shortenUrl($longUrl, $channelId)
  {
    $response = Http::withToken('aFLQFlykraqpANsi')
      ->post('https://chotta.link/api/url/add', [
        'url' => $longUrl
      ]);

    if ($response->successful() && isset($response['shorturl'])) {

      $shortUrl = $response['shorturl'];
      $urlId = $response['id'];

      $assignUrl = "https://chotta.link/api/channel/{$channelId}/assign/links/{$urlId}";

      $assignResponse = Http::withToken('aFLQFlykraqpANsi')->post($assignUrl);

      if ($assignResponse->successful()) {
        return $response; // success
      }
    }


    return null;
  }

 
  public function studentFeedback(Request $request, $id, $batch_id)
  {
    $helper = new \App\Helpers\Helpers();
    $encrypted_values = $helper->encrypt_decrypt($id, 'decrypt');
    $encrypted_batch_id = $helper->encrypt_decrypt($batch_id, 'decrypt');

    $batch_id  = $encrypted_batch_id;
    $customers = CustomerModel::where('sno', $encrypted_values)
      ->select('cus_name', 'sno')
      ->first();

    if (!$customers) abort(404);

    // read last entry if exists
    $existing = DB::table('za_student_feedback_answer')
      ->where('student_id', $encrypted_values)
      ->where('batch_id', $encrypted_batch_id)
      ->latest()
      ->first();

    $feedback_submitted = !empty($existing);

    // default
    $coupon = '';
    $percentage = '';

    if ($existing) {
      $coupon     = $existing->student_coupon;
      $percentage = $existing->student_percentage;
    }

    $languages = FeedBackStudentQuestionModel::where('za_feedback_student_question.status', 0)
      ->join('za_languages', 'za_languages.sno', '=', 'za_feedback_student_question.language_id')
      ->select('za_languages.sno as language_id', 'za_languages.name', 'za_languages.native_name')
      ->distinct()
      ->get();
    // return $languages;

    return view('content.production.staff_board.feedback_student', compact(
      'customers',
      'batch_id',
      'feedback_submitted',
      'coupon',
      'percentage',
      'languages'
    ));
  }

  public function List(Request $request, $id)
  {
    $studentId = $request->input('student_id');
    $batchId   = $request->input('batch_id');

    // Check TESBO condition
    $tesboCheck = TrainingModel::where('customer_id', $studentId)
      ->where('batch_id', $batchId)
      ->where('tesbo_check', 2)
      ->exists(); // faster than first()

    $section_id = 6;

    // Base query
    $leadquestion = FeedBackStudentQuestionModel::select(
      'za_feedback_student_question.sno as sno',
      'za_feedback_student_question.category_question_name',
      'za_feedback_student_question.category_question_option',
      'za_feedback_student_question.category_question_type',
      'za_feedback_student_question.language_id',
      'za_feedback_student_question.section_id',
      'za_section.sno as section_sno',
      'za_section.section as section_name'
    )
      ->join('za_section', 'za_section.sno', '=', 'za_feedback_student_question.section_id')
      ->where('za_feedback_student_question.status', 0)
      ->where('za_feedback_student_question.language_id', $id);

    // ✅ CONDITIONAL FILTER
    if (!$tesboCheck) {
      $leadquestion->where('za_feedback_student_question.section_id', '!=', $section_id);
    }

    $leadquestion = $leadquestion
      ->orderBy('za_feedback_student_question.section_id')
      ->orderBy('za_feedback_student_question.sno')
      ->get();

    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $leadquestion
    ], 200);
  }


  // ALTER TABLE `za_student_feedback_answer` ADD `batch_id` INT NOT NULL AFTER `branch_id`;
  public function studentFeedbackSubmit(Request $request, $id)
  {
    try {
      $student_id = $id;

      // Get the student
      $customer = CustomerModel::where('sno', $student_id)->first();

      if (!$customer) {
        return response()->json([
          'status'  => 404,
          'message' => 'Student not found'
        ], 404);
      }

      // ---------------- CHECK ALREADY SUBMITTED ----------------
      $already = DB::table('za_student_feedback_answer')
        ->where('student_id', $student_id)
        ->exists();

      if ($already) {
        return response()->json([
          'status'  => 409,
          'message' => 'Feedback already submitted.'
        ], 409);
      }

      // Get all answers from request
      $answers = $request->input('answers', []);

      if (empty($answers)) {
        return response()->json([
          'status'  => 400,
          'message' => 'No answers provided.'
        ], 400);
      }

      // Prepare feedback array
      $feedback = [];

      foreach ($answers as $index => $answer) {
        if (!isset($answer['question_id']) || !isset($answer['score'])) {
          continue; // Skip invalid entries
        }

        $feedback[] = [
          'question_id' => $answer['question_id'],
          'answer_value' => $answer['score'],
          'answer_score' => is_numeric($answer['score']) ? (int) $answer['score'] : ($answer['score'] === 'yes' ? 1 : 0)
        ];
      }

      // ---- FORMAT COMPLETE JSON STRUCTURE ----
      $saveJson = [
        "student" => [
          "id"   => $student_id,
          "name" => $customer->cus_name
        ],
        "branch_id" => $customer->branch_id,
        "submitted_at" => now()->toISOString(),
        "answers" => $feedback
      ];


      // ----- RANDOM COUPON -----
      function generateCoupon($length = 9)
      {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = '';

        for ($i = 0; $i < $length; $i++) {
          $code .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $code;
      }

      // ----- HANDLE RANGE -------
      $range = $customer->range_percentage;  // "5-10"
      $min = 0;
      $max = 0;

      if ($range && strpos($range, '-') !== false) {
        [$min, $max] = explode('-', $range);
      }

      $min = intval($min);
      $max = intval($max);

      // fallback if data wrong
      if ($max <= $min) {
        $min = 5;
        $max = 10;
      }

      // random percentage between min and max
      $percentage = rand($min, $max);

      // random coupon
      $couponCode = generateCoupon();

      // ---------------- INSERT JSON ----------------
      DB::table('za_student_feedback_answer')->insert([
        'student_id'    => $student_id,
        'branch_id'     => $customer->branch_id,
        'batch_id'      => $request->batch_id,
        'language_id'      => $request->language_id,
        'feedback_json' => json_encode($saveJson, JSON_PRETTY_PRINT),
        'status' => 1,
        'student_coupon'     => $couponCode,
        'student_percentage' => $percentage,
        'created_at'    => now(),
        'updated_at'    => now(),
      ]);

      return response()->json([
        'status'  => 200,
        'coupon'  => $couponCode,
        'percentage' => $percentage,
        'message' => 'Thank you! Your feedback was submitted successfully.'
      ], 200);
    } catch (\Exception $e) {
      \Log::error('Feedback submission error: ' . $e->getMessage());

      return response()->json([
        'status'  => 500,
        'message' => 'An error occurred while submitting feedback. Please try again.'
      ], 500);
    }
  }

  public function batchFeedback(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $course_id   = $request->input('course_id', '');
    $batch_id = $request->input('batch_id', '');
    $date        = $request->input('date', ''); // today, week, month, custom

    // Get batch-level aggregates (unique payment_id counts per batch)
    $batchStats = DB::table('za_batch')
      ->select(
        'za_batch.sno',
        DB::raw('COUNT(DISTINCT za_training.payment_id) as total_cus'), // Total unique students per batch
        DB::raw('COUNT(DISTINCT CASE WHEN za_student_feedback_answer.sno IS NOT NULL THEN za_training.payment_id END) as total_feedback_cus') // Students who gave feedback
      )
      ->where('za_batch.branch_id', $branch_id)
      ->where('za_batch.status', 3)
      ->leftJoin('za_training', 'za_training.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_student_feedback_answer', function ($join) {
        $join->on('za_student_feedback_answer.student_id', '=', 'za_training.customer_id')
          ->whereNotNull('za_student_feedback_answer.sno');
      })
      ->groupBy('za_batch.sno')
      ->pluck('total_cus', 'sno')->toArray();

    $feedbackStats = DB::table('za_batch')
      ->select(
        'za_batch.sno',
        DB::raw('COUNT(DISTINCT za_training.payment_id) as total_feedback_cus')
      )
      ->where('za_batch.branch_id', $branch_id)
      ->where('za_batch.status', 3)
      ->join('za_student_feedback_answer', 'za_student_feedback_answer.batch_id', '=', 'za_batch.sno')
      ->join('za_training', function ($join) {
        $join->on('za_training.customer_id', '=', 'za_student_feedback_answer.student_id');
      })
      ->groupBy('za_batch.sno')
      ->pluck('total_feedback_cus', 'sno')->toArray();

    // return $feedbackStats;

    $query = DB::table('za_batch')
      ->leftJoin('za_student_feedback_answer', 'za_student_feedback_answer.batch_id', '=', 'za_batch.sno')
      ->leftJoin('za_customer', 'za_customer.sno', '=', 'za_student_feedback_answer.student_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->where('za_batch.status', 3)
      ->where('za_batch.branch_id', $branch_id)
      ->select(
        'za_student_feedback_answer.sno as answer_sno',
        'za_student_feedback_answer.feedback_json',
        'za_student_feedback_answer.created_at',
        'za_student_feedback_answer.branch_id',
        'za_course.course_name',
        'za_course_type.course_type_name',
        'za_course_type.sno as course_type_sno',
        'za_slot_type.slot_type_name',
        'za_batch.sno as batch_sno', // Add batch_sno for mapping
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_batch.branch_id as batch_branch_id',
        'za_staff.staff_name',
        'za_staff.nick_name as staff_nick_name',
        'za_staff.staff_image'
      );
    // return $query;

    // Course filter
    if ($course_id != '') {
      $query->where('za_course_type.sno', $course_id);
    }
    // batch filter
    if ($batch_id != '') {
      $query->where('za_batch.sno', $batch_id);
    }

    // Date filter
    if ($date != '' && $date != 'all') {
      if ($date == 'today') {
        $query->whereDate('za_batch.start_date', today());
      } elseif ($date == 'week') {
        $query->whereBetween('za_batch.start_date', [now()->startOfWeek(), now()->endOfWeek()]);
      } elseif ($date == 'monthly') {
        $query->whereMonth('za_batch.start_date', now()->month)
          ->whereYear('za_batch.start_date', now()->year);
      } elseif ($date == 'custom') {
        $from = $request->input('from_date');
        $to   = $request->input('to_date');
        if ($from && $to) {
          $query->whereBetween('za_batch.start_date', [$from, $to]);
        }
      }
    }

    // Finally execute the query
    $completeList = $query->get();
    // return $completeList;
    // Load all questions once to map section_id
    $questions = DB::table('za_feedback_student_question')
      ->select('sno', 'section_id', 'language_id')
      ->get()
      ->keyBy('sno');

    $result = $completeList->groupBy('batch_sno')->map(function ($batchFeedbacks, $batchSno) use ($questions, $batchStats, $feedbackStats) {
      // Aggregate ALL feedback scores for this batch
      $totalScore = 0;
      $staffScore = 0;
      $feedbackCount = 0;

      $totalQuestions = collect($questions)->filter(fn($o) => $o->language_id == 15)->count();
      $totalStaffQuestions = collect($questions)->filter(fn($q) => $q->section_id == 2)->count();

      // Process ALL feedbacks for this batch
      foreach ($batchFeedbacks as $item) {
        if (empty($item->feedback_json)) continue; // Skip null feedback

        $feedbackData = json_decode($item->feedback_json, true);
        $answers = $feedbackData['answers'] ?? [];

        foreach ($answers as $answer) {
          $qId = $answer['question_id'];
          $score = (int)($answer['answer_score'] ?? 0);

          $totalScore += $score;
          $feedbackCount++; // Count total answers processed

          if (isset($questions[$qId]) && in_array($questions[$qId]->section_id, [2, 8])) {
            $staffScore += $score;
          }
        }
      }

      // CORRECT formula: total answers score / (total questions * feedbacks * 5)
      $Batchtotalmark = $totalQuestions * 5 * $batchStats[$batchSno];
      // $Batchtotalmark = $totalQuestions * 5 * $batchStats[$batchSno];
      $overallScore = $Batchtotalmark > 0 ? ($totalScore / $Batchtotalmark) * 100 : 0;

      // Get first item for batch details
      $firstItem = $batchFeedbacks->first();

      $batchStartDate = Carbon::parse($firstItem->start_date)->format('d-M-Y');
      $batchEndDate = Carbon::parse($firstItem->end_date)->format('d-M-Y');

      return [
        'total_cus' => $batchStats[$batchSno] ?? 0,
        'total_feedback_cus' => $feedbackStats[$batchSno] ?? 0,
        'branch_id' => $firstItem->batch_branch_id,
        'batch_id' => $firstItem->batch_sno,
        'batch_name' => $firstItem->batch_name,
        'course_name' => $firstItem->course_name,
        'course_type_name' => $firstItem->course_type_name,
        'slot_type_name' => $firstItem->slot_type_name,
        'batch_start_date' => $batchStartDate,
        'batch_end_date' => $batchEndDate,
        'batch_percentage' => round($overallScore),
        'batch_totalmark' => $Batchtotalmark,
        'batchScore' => $totalScore,  // NOW HAS REAL TOTAL!
        'staffScore' => $staffScore,
        'staff_image' => $firstItem->staff_image,
        'staff_name' => $firstItem->staff_name,
        'staff_nick_name' => $firstItem->staff_nick_name,
      ];
    })->values(); // Convert back to indexed array

    // return $result;
    // Calculate dashboard stats
    $submittedCount = $completeList->whereNotNull('feedback_json')->count(); // Batches with feedback
    $pendingCount = $completeList->whereNull('feedback_json')->count();     // Batches without feedback
    $totalBatches = $completeList->count();

    return view('content.production.batch_feedback.batch_feedback_batch_wise', [
      'completeList' => $result,
      'submittedCount' => $submittedCount,
      'pendingCount' => $pendingCount,
      'totalBatches' => $totalBatches
    ]);
  }

  public function StudentWise(Request $request)
  {

    $branch_id = $request->user()->branch_id;
    $search = $request->search_data;
    $course_id   = $request->input('course_id', '');
    $batch_id = $request->input('batch_id', '');
    $date        = $request->input('date', ''); // today, week, month, custom

    $completeListQuery = DB::table('za_student_feedback_answer')
      ->where('za_student_feedback_answer.branch_id', $branch_id)
      ->join('za_batch', 'za_batch.sno', '=', 'za_student_feedback_answer.batch_id')
      ->join('za_customer', 'za_customer.sno', '=', 'za_student_feedback_answer.student_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->select(
        'za_student_feedback_answer.sno as answer_sno',
        'za_student_feedback_answer.feedback_json',
        'za_student_feedback_answer.created_at',
        'za_batch.sno as batch_id',
        'za_batch.batch_name',
        'za_batch.start_date',
        'za_batch.end_date',
        'za_customer.cus_name',
        'za_customer.customer_id',
        'za_customer.cus_pic',
        'za_customer.cus_gender',
        'za_customer.sno',
        'za_course.course_name',
        'za_course_type.course_type_name',
        'za_course_type.sno as course_type_sno',
        'za_slot_type.slot_type_name',
        'za_staff.staff_name',
        'za_staff.nick_name as staff_nick_name',
        'za_staff.staff_image'
      );

    // Course filter
    if ($course_id != '') {
      $completeListQuery->where('za_course_type.sno', $course_id);
    }
    // batch filter
    if ($batch_id != '') {
      $completeListQuery->where('za_batch.sno', $batch_id);
    }

    // Date filter
    if ($date != '' && $date != 'all') {
      if ($date == 'today') {
        $completeListQuery->whereDate('za_batch.start_date', today());
      } elseif ($date == 'week') {
        $completeListQuery->whereBetween('za_batch.start_date', [now()->startOfWeek(), now()->endOfWeek()]);
      } elseif ($date == 'monthly') {
        $completeListQuery->whereMonth('za_batch.start_date', now()->month)
          ->whereYear('za_batch.start_date', now()->year);
      } elseif ($date == 'custom') {
        $from = $request->input('from_date');
        $to   = $request->input('to_date');
        if ($from && $to) {
          $completeListQuery->whereBetween('za_batch.start_date', [$from, $to]);
        }
      }
    }

    // Finally execute the query

    // ------------------ SEARCH FILTER ---------------------
    if (!empty($search)) {
      $completeListQuery->where(function ($q) use ($search) {
        $q->where('za_batch.batch_name', 'LIKE', "%$search%")
          ->orWhere('za_customer.cus_name', 'LIKE', "%$search%")
          ->orWhere('za_slot_type.slot_type_name', 'LIKE', "%$search%")
          ->orWhere('za_course.course_name', 'LIKE', "%$search%")
          ->orWhere('za_course_type.course_type_name', 'LIKE', "%$search%");
      });
    }

    $completeList = $completeListQuery->get();

    // ------------------ LOAD QUESTIONS --------------------
    $questions = DB::table('za_feedback_student_question')
      ->select('sno', 'section_id', 'language_id')
      ->get()
      ->keyBy('sno'); // Map by question_id

    // total overall questions
    $totalQuestions = $questions->where('language_id', 15)->count();

    // Count staff questions (section_id = 2 only as per your request)
    $totalStaffQuestions = $questions->where('section_id', 2)->count();
    $totalInfraQuestions = $questions->where('section_id', 1)->count();
    $totalUnderQuestions = $questions->where('section_id', 3)->count();

    // ------------------ FORMAT OUTPUT --------------------
    $result = $completeList->map(function ($item) use ($questions, $totalQuestions, $totalStaffQuestions, $totalInfraQuestions, $totalUnderQuestions) {

      $answers = json_decode($item->feedback_json, true)['answers'] ?? [];

      $totalScore = 0;
      $totalScoreQuestion = 0;
      $staffScore = 0;
      $infraScore = 0;
      $underScore = 0;

      foreach ($answers as $answer) {
        $qId = $answer['question_id'];
        $score = $answer['answer_score'] ?? 0;
        $qust = $answer['question_id'] ?? 0;

        $totalScore += $score;
        $totalScoreQuestion = $qust;

        // staff-score: only section 2 questions
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 2 || $questions[$qId]->section_id == 8)) {
          $staffScore += $score;
        }
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 1 || $questions[$qId]->section_id == 7)) {
          $infraScore += $score;
        }
        if (isset($questions[$qId]) && ($questions[$qId]->section_id == 3 || $questions[$qId]->section_id == 9)) {
          $underScore += $score;
        }
      }

      // max marks
      $BatchTotalMark = 5 * $totalScoreQuestion;
      $StaffTotalMark = 5 * $totalStaffQuestions;
      $InfraTotalMark = 5 * $totalInfraQuestions;
      $UnderTotalMark = 5 * $totalUnderQuestions;

      // percentages
      $batchPercentage = ($BatchTotalMark > 0)
        ? round(($totalScore / $BatchTotalMark) * 100)
        : 0;

      $staffPercentage = ($StaffTotalMark > 0)
        ? round(($staffScore / $StaffTotalMark) * 100)
        : 0;

      $infraPercentage = ($InfraTotalMark > 0)
        ? round(($infraScore / $InfraTotalMark) * 100)
        : 0;

      $underPercentage = ($UnderTotalMark > 0)
        ? round(($underScore / $UnderTotalMark) * 100)
        : 0;

      // count unique students from za_training
      $studentCount = DB::table('za_training')
        ->where('batch_id', $item->batch_id)
        ->distinct('customer_id')
        ->count('customer_id');

      $studentCountFormatted = str_pad($studentCount, 2, '0', STR_PAD_LEFT);
      $batchEndDate   = Carbon::parse($item->end_date)->format('d-M-Y');
      return [
        "cus_name"         => $item->cus_name,
        "customer_id"         => $item->customer_id,
        "cus_pic"           => $item->cus_pic,
        "cus_gender"           => $item->cus_gender,
        "cus_sno"           => $item->sno,
        "batch_name"         => $item->batch_name,
        "course_name"        => $item->course_name,
        "course_type_name"   => $item->course_type_name,
        "slot_type_name"     => $item->slot_type_name,

        "batch_start_date"   => $item->start_date,
        "batch_end_date"     => $batchEndDate,

        "student_count"      => $studentCountFormatted,

        "batch_percentage"   => $batchPercentage,
        "batch_totalmark"    => $BatchTotalMark,
        "batchScore"         => $totalScore,

        "staff_percentage"   => $staffPercentage,
        "staff_totalmark"    => $StaffTotalMark,
        "staffScore"         => $staffScore,

        "infra_percentage"   => $infraPercentage,
        "infra_totalmark"    => $InfraTotalMark,
        "infraScore"         => $infraScore,

        "under_percentage"   => $underPercentage,
        "under_totalmark"    => $UnderTotalMark,
        "underScore"         => $underScore,

        "staff_image"        => $item->staff_image,
        "staff_name"         => $item->staff_name,
        "staff_nick_name"    => $item->staff_nick_name,
      ];
    });
    // Convert back to indexed array

    // return $result;

    return view('content.production.batch_feedback.batch_feedback_list', [
      'completeList' => $result
      // 'submittedCount' => $submittedCount,
      // 'pendingCount' => $pendingCount,
      // 'totalBatches' => $totalBatches
    ]);
  }


  public function batchFeedbackStudent(Request $request, $id)
  {
    $branch_id = $request->user()->branch_id;

    $completeListQuery = DB::table('za_student_feedback_answer')
      ->where('za_student_feedback_answer.branch_id', $branch_id)
      ->where('za_student_feedback_answer.student_id', $id)
      ->join('za_batch', 'za_batch.sno', '=', 'za_student_feedback_answer.batch_id')
      ->join('za_customer', 'za_customer.sno', '=', 'za_student_feedback_answer.student_id')
      ->join('za_staff', 'za_staff.sno', '=', 'za_batch.staff_id')
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->join('za_course_type', 'za_course_type.sno', '=', 'za_course.course_type_id')
      ->join('za_slot', 'za_slot.sno', '=', 'za_batch.slot_id')
      ->join('za_slot_type', 'za_slot_type.sno', '=', 'za_slot.slot_type_id')
      ->select(/* your existing select fields */);

    $completeList = $completeListQuery->get();

    // ✅ FIXED: Added language_id filter and select language_id
    $allQuestions = DB::table('za_feedback_student_question as q')
      ->join('za_section', 'za_section.sno', '=', 'q.section_id')
      ->select(
        'q.sno as question_id',
        'q.category_question_name',
        'q.category_question_option',
        'q.category_question_type',
        'q.section_id',
        'q.language_id',
        'za_section.section as section_name'
      )
      ->where('q.status', 0)
      ->where('q.language_id', 15) // ✅ CRITICAL: Add this filter
      ->orderBy('q.section_id')
      ->orderBy('q.sno')
      ->get();

    $questions = $allQuestions->groupBy('section_id');

    // ✅ FIXED: Correct count methods
    $totalQuestions = $allQuestions->count();
    $totalStaffQuestions = $questions[2]->count() ?? 0;
    $totalInfraQuestions = $questions[1]->count() ?? 0;
    $totalUnderQuestions = $questions[3]->count() ?? 0;

    $result = $completeList->map(function ($item) use ($questions, $allQuestions, $totalQuestions, $totalStaffQuestions, $totalInfraQuestions, $totalUnderQuestions) {
      $answers = json_decode($item->feedback_json, true)['answers'] ?? [];

      // ✅ FIXED: Calculate scores BEFORE section answers
      $totalScore = 0;
      $totalScoreQuestion = 0;
      $staffScore = 0;
      $infraScore = 0;
      $underScore = 0;

      foreach ($answers as $answer) {
        $qId = $answer['question_id'];
        $score = (int) $answer['answer_score'];
        $qust = (int) $answer['question_id'];

        $totalScore += $score;
        $totalScoreQuestion = $qust;

        $questionSection = $allQuestions->firstWhere('question_id', $qId)?->section_id;
        if (in_array($questionSection, [2, 8])) $staffScore += $score;
        if (in_array($questionSection, [1, 7])) $infraScore += $score;
        if (in_array($questionSection, [3, 9])) $underScore += $score;
      }

      // ✅ Build section-wise answers (only answered questions)
      $sectionAnswers = [];
      foreach ($questions as $sectionId => $sectionQuestions) {
        $answeredQuestions = [];

        foreach ($sectionQuestions as $question) {
          $answered = collect($answers)->firstWhere('question_id', (string) $question->question_id); // ✅ Cast to string

          if ($answered) {
            $answeredQuestions[] = [
              'question_id' => $question->question_id,
              'question_text' => $question->category_question_name,
              'question_type' => $question->category_question_type,
              'answer' => $answered['answer_value'],
              'score' => (int) $answered['answer_score'], // ✅ Cast to int
              'answered' => true
            ];
          }
        }

        if (!empty($answeredQuestions)) {
          $sectionAnswers[] = [
            'section_name' => $sectionQuestions->first()->section_name,
            'questions' => $answeredQuestions
          ];
        }
      }

      // Calculate percentages
      $BatchTotalMark = 5 * $totalScoreQuestion;
      $StaffTotalMark = 5 * $totalStaffQuestions;
      $InfraTotalMark = 5 * $totalInfraQuestions;
      $UnderTotalMark = 5 * $totalUnderQuestions;

      $batchPercentage = $BatchTotalMark > 0 ? round(($totalScore / $BatchTotalMark) * 100) : 0;
      $staffPercentage = $StaffTotalMark > 0 ? round(($staffScore / $StaffTotalMark) * 100) : 0;
      $infraPercentage = $InfraTotalMark > 0 ? round(($infraScore / $InfraTotalMark) * 100) : 0;
      $underPercentage = $UnderTotalMark > 0 ? round(($underScore / $UnderTotalMark) * 100) : 0;

      return [
        "cus_name" => $item->cus_name,
        "customer_id" => $item->customer_id,
        "cus_pic" => $item->cus_pic,
        "cus_gender" => $item->cus_gender,
        "batch_name" => $item->batch_name,
        "course_type_name" => $item->course_type_name,
        "slot_type_name" => $item->slot_type_name,

        "batch_percentage" => $batchPercentage,
        "batch_totalmark" => $BatchTotalMark,
        "batchScore" => $totalScore,

        "staff_percentage" => $staffPercentage,
        "staff_totalmark" => $StaffTotalMark,
        "staffScore" => $staffScore,

        "infra_percentage" => $infraPercentage,
        "infra_totalmark" => $InfraTotalMark,
        "infraScore" => $infraScore,

        "under_percentage" => $underPercentage,
        "under_totalmark" => $UnderTotalMark,
        "underScore" => $underScore,

        "section_answers" => $sectionAnswers,
      ];
    });

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $result
    ]);
  }

  public function CourseTypeList()
  {
    $Coursetype = CourseTypeModel::whereNotIn('sno', [7])->where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }
  public function BatchList(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $Coursetype = BatchModel::where('branch_id', $branch_id)->where('status', 3)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $Coursetype
    ], 200);
  }

  public function sendFeedbackBatch(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $batch_id = $request->input('batch_id');
    $branchData = BranchModel::where('status', 0)->where('sno', $branch_id)
      ->first();
    $batchData = BatchModel::where('za_batch.sno', $batch_id)->select(
      'za_batch.*',
      'za_course.course_name',
    )
      ->join('za_course', 'za_course.sno', '=', 'za_batch.course_id')
      ->first();

    $customerIds = TrainingModel::where('batch_id', $batch_id)->where('status', '!=', 2)
      ->distinct('customer_id')->pluck('customer_id');

    $customers = CustomerModel::whereIn('sno', $customerIds)->get();

    $branch_name = $branchData->branch_type == 1 ? $branchData->branch_name : $branchData->franchise_name;

    $helper = new \App\Helpers\Helpers();

    foreach ($customers as $customer) {
      $encrypted_values = $helper->encrypt_decrypt($customer->sno, 'encrypt');
      $encrypted_batch_id = $helper->encrypt_decrypt($batch_id, 'encrypt');
      $Link = url('student_feedback/' . $encrypted_values . '/' . $encrypted_batch_id);

      // Shorten the link if needed
      $channelId = 17;
      $shortUrlData = $this->shortenUrl($Link, $channelId);
      $shortUrl = $shortUrlData['shorturl'] ?? $Link; // fallback to full link

      // Save feedback link in DB
      DB::table('za_customer')->where('sno', $customer->sno)->update(['feedback_link' => $shortUrl]);

      $shortcustomer = DB::table('za_customer')->where('sno', $customer->sno)->first();
      $shortsendUrl = $shortcustomer->feedback_link;
      $feedback_key = basename($shortsendUrl);
      //  Mail
      if ($customer->cus_email_id) {
        try {
          $email_template_id = 20; // Feedback email template
          $emailTemplate = EmailTemplateModel::where('status', 0)->where('sno', $email_template_id)->first();

          $content = $emailTemplate->email_subject;
          $content = str_replace('#name', $customer->cus_name, $content);
          $content = str_replace('#CourseName', $batchData->course_name ?? 'Course', $content);
          $content = str_replace('#BatchName', $batchData->batch_name ?? 'Batch', $content);
          $content = str_replace('#link', $shortUrl, $content);
          $content = str_replace('#CRENo', $branchData->cre_mobile ?? '9677781155', $content);
          $content = str_replace('#BranchName', $branch_name ?? 'Elysium Academy', $content);
          $content = str_replace('#mail', $branchData->mail ?? 'info@elysiumacademy.org', $content);

          $mailData = [
            'url' => 'Eapl.com',
            'subject' => $emailTemplate->email_name,
            'content' => $content,
            'branchNo' => $branchData->mobile,
            'branchemail' => $branchData->mail,
            'fbLink' => $branchData->fb_link ?? 'https://www.facebook.com/elysiumacademy.org/',
            'instaLink' => $branchData->insta_link ?? 'https://www.instagram.com/elysiumacademy/',
            'salesMobile' => $branchData->sales_mobile,
          ];

          $to_address = $customer->cus_email_id;
          $from_address = 'elysiumacademy@elysium.community';
          $from_name = 'Elysium Academy ' . "\xC2\xAE";
          Mail::to($to_address)->send(new EAPLMail($mailData, $from_address, $from_name));

          DB::table('za_customer')->where('sno', $customer->sno)->update(['email_send' => 1]);
        } catch (\Exception $e) {
          DB::table('za_customer')->where('sno', $customer->sno)->update(['email_send' => 2]);
        }
      }
      //  whatsapp
      if ($customer->cus_mobile) {


        // $templateName  = "hello_world";
        $templateName  = "send_feedback";

        $hasHeader  = false; // Example flag: set based on template
        $hasBody    = false; // Example flag: set based on template
        $hasFooter  = false; // Example flag: set based on template
        $hasButton  = false;
        $components = [];
        $couponCode = " ";
        date_default_timezone_set('Asia/Kolkata'); // Set your timezone (e.g., 'Asia/Kolkata')
        $currentHour = (int) date('H');            // Get current hour in 24-hour format as an integer
        // $currentHour = date('H'); // Get current hour in 24-hour format
        if ($currentHour >= 5 && $currentHour < 12) {
          $greeting = 'Good Morning';
        } elseif ($currentHour >= 12 && $currentHour < 18) {
          $greeting = 'Good Afternoon';
        } else {
          $greeting = 'Good Evening';
        }

        if ($templateName == 'send_feedback') {
          $headerImage = 'https://erp.elysium.academy/public/assets/eapl_images/OnBoard.jpg';
          // $headerImage =  url('public/assets/eapl_images/event_certificate_image.jpg');
          $couponCode  = 'NOOFFER';
          $buttonIndex = 1;
          $bodyText    = [
            [
              'type'           => 'text',
              'text'           => $customer->cus_name ?? "student",
              'parameter_name' => 'stu_name',
            ],
            [
              'type'           => 'text',
              'text'           => $batchData->course_name ?? "Course",
              'parameter_name' => 'cour_name',
            ],
            [
              'type'           => 'text',
              'text'           => $shortUrl,
              'parameter_name' => 'feed_link',
            ]
          ];
          $hasHeader = true;
          $hasBody   = true;
          $hasButton = true;
        }

        // Add Header if required
        if ($hasHeader) {
          $components[] = [
            'type'       => 'header',
            'parameters' => [
              [
                'type'  => 'image',
                'image' => [
                  'link' => $headerImage, // Dynamically set header image
                ],
              ],
            ],
          ];
        }

        // Add Body if required
        if ($hasBody) {
          $components[] = [
            'type'       => 'body',
            'parameters' => $bodyText,
          ];
        }

        // Add Footer if required
        if ($hasButton) {
          $components[] = [
            'type'       => 'button',
            'sub_type'   => 'url',
            'index'      => 0,
            'parameters' => [
              [
                'type' => 'text',
                'text' => $feedback_key,
              ],
            ],
          ];
        }


        $dynamicParameters         = $templateParameters[$templateName] ?? [];
        $WhatsAppBusinessAccountId = $this->accessData($request)->waba_id;
        $accessToken               = $this->accessData($request)->access_tokken;
        $fromPhoneNumberId         = $this->accessData($request)->phonenumber_id;

        $apiUri = 'https://graph.facebook.com/v21.0/' . $fromPhoneNumberId . '/messages';

        $mobile = preg_replace('/\D/', '', $customer->cus_mobile); // remove any non-digits
        if (strpos($customer->cus_mobile, '+') === 0) {
          $to = $customer->cus_mobile;
        } elseif (strlen($mobile) === 12 && substr($mobile, 0, 2) === '91') {
          $to = '+' . $mobile;
        } else {
          $to = '+91' . $mobile;
        }
        $languageCode = 'en';

        // if (strpos($to, $countryCode) !== 0) {
        //     $to = $countryCode . $to;
        // }

        $message = 'test~message';
        if (empty($components)) {
          $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
              'name'     => $templateName,
              'language' => [
                'code' => $languageCode,
              ],
            ],
          ];
        } else {
          $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
              'name'       => $templateName,
              'language'   => [
                'code' => $languageCode,
              ],
              'components' => $components,
            ],
          ];
        }

        $response =  $this->sendRequestToWhatsApp($apiUri, $accessToken, $payload);
        if ($response['status'] == 200) {
        } else {

          return response([
            'status' => 404,
            'message' => 'Failed to send message',
            'certificate_status' => 2,
            'error_msg' => $response['error'],
          ], 400);
        }
      } else {
        return response([
          'status' => 200,
          'message' => 'Mobile no not found',
          'error_msg' => 'mobile no not found',
          'certificate_status' => 0,
        ], 200);
      }
    }

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $batchData
    ], 200);
  }
}
