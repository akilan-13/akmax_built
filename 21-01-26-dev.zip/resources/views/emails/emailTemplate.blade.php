<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Elysium Groups</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .email-container {
            width: 100%;
            background-color: #f4f4f4;
            padding: 0 20px;
        }
        .email-content {
            width: 100%;
            max-width: 720px; /* Limit width to 600px for better readability */
            margin: 0 auto;
            background-color: #fff;
            padding: 0;
            border: 2px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box; /* Ensures padding and borders don't affect width */
        }
        .email-header {
            width: 100%;
            margin: 0;
            padding: 0;
        }
        .email-header img {
            width: 100%; /* Make the image take full width */
            height: auto;
            display: block; /* Ensures the image is block level, removing any unwanted spacing */
        }
        .email-body {
            padding: 0 20px;
        }
        .email-body p {
            font-size: 16px;
            line-height: 1.5;
            color: #555;
            margin-top: 0;
        }
        .email-footer {
            margin-top: 0px;
            padding: 0px;
            text-align: center;
            font-size: 14px;
            color: #888;
        }
        .contact-info {
            font-weight: bold;
            color: #000;
        }

        .icon_hover {
            position: relative; /* Makes the container relative to its normal flow */
            display: inline-block; /* Keeps the image inline but allows block behavior */
        }

        .icon_hover img {
            display: block; /* Removes any extra space below the image */
            width: 100%; /* Makes sure the image scales properly if needed */
            transition: box-shadow 0.3s ease; /* Smooth transition for the shadow effect */
        }

        .icon_hover:hover img {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5); /* Apply shadow only to the image */
        }
       
        /* .social_icon{
          display:flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          height: 100%;
        } */

        /* Mobile responsive styles */
        @media (max-width: 600px) {
            .email-content {
                width: 100%; /* Full width on mobile */
                padding: 10px; /* Reduce padding on mobile */
            }
            .email-header img {
                max-width: 100%; /* Ensure the header image fits the mobile screen */
            }
            .email-footer {
                max-width: 100%;
            }
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css" rel="stylesheet">

</head>
@php
  $helper = new \App\Helpers\Helpers();
  $twitter_link=$helper->general_setting_data()->twitter_link ?? "https://x.com/phdizone1";
  $linkedin_link=$helper->general_setting_data()->linkedin_link ?? "https://www.linkedin.com/company/phdizone-research-division/";
  $pinterest_link =$helper->general_setting_data()->pinterest_link ?? "https://in.pinterest.com/phdizone/";
  $youtube_link =$helper->general_setting_data()->youtube_link  ?? "https://www.youtube.com/@PhDiZone";

@endphp
<body>
    <div class="email-container">
        <div class="email-content">
            <div class="email-header">
                <img src="{{ asset('assets/egc_images/email_template/header.jpg') }}" alt="Elysium Groups Logo">
            </div>
            <div class="email-body">
                <br>
                {!! $content !!}
            </div>
            <div class="email-footer">
              <div class="d-flex flex-column align-items-center">
                <hr>
                <div class="footer-content d-flex flex-column align-items-center">
                  <h5 style="color:black;">Any Queries ?</h5>
                  <p><span style="color:black; font-size:14px; font-weight:bold;">Mail us at : </span ><span style="color:red">{!! $branchemail ?? '' !!}</span></p>
                  <p><span style="color:black; font-size:14px; font-weight:bold;">call us on : </span><span style="color:red">{!! $branchNo ?? '' !!}</span></p>
                </div>

                <div class="vist_social" style="padding:10px 0; background-color:#ab2b22;">
                  <h5 style="text-align: center;margin: 0; padding: 0;color:rgb(255, 255, 255);">Visit us</h5>
                  <table class="social_icon" width="100%" height="100%" style="border-collapse: collapse; margin: 0; padding: 0; width: 100%; height: 100%; text-align: center; vertical-align: middle;">
                      <tr>
                        <td align="center" valign="middle">
                          <table style="border-collapse: collapse; margin: 0 auto; padding: 0;">
                            <tr>
                              <td style="padding: 5px; ">
                                <a class="icon_hover" href="{!! $fbLink ?? '#' !!}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/facebook.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="{!! $instaLink ?? '#' !!}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/instagram.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="{{ $twitter_link ?? '#'}}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/twitter.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="{{ $linkedin_link ?? '#' }}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/linkedin.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="{{ $youtube_link ?? '#' }}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/youtube.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="https://wa.me/91{{ $salesMobile ?? '#'}}" target="_blank" style="display: inline-block;padding:4px 6px; ">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/whatsapp.png') }}" alt="whatsapp" >
                                </a>
                              </td>
                              <td style="padding: 5px;">
                                <a class="icon_hover" href="{{ $pinterest_link ?? '#' }}" target="_blank" style="display: inline-block; padding:4px 6px;">
                                    <img width="25" height="25"  src="{{ asset('assets/egc_images/email_template/pinterest.png') }}" alt="whatsapp" >
                                </a>
                              </td>

                            </tr>
                          </table>
                      </td>
                    </tr>
                  </table>
                </div>

              </div>

            </div>
        </div>
    </div>
</body>
</html>
