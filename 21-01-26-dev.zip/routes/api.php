<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VideoSubmissionController;
use App\Http\Controllers\control_panel\user_management\UserRole;
use App\Http\Controllers\settings\business\BusinessDepartment;
use App\Http\Controllers\WebHookHandler\WebhookReceiverController;
use App\Http\Controllers\hr_management\hr_recruiter\JobController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('/upload-video', [VideoSubmissionController::class, 'upload']);

Route::post('/add_business_userrole', [UserRole::class, 'businessAdd']);
Route::post('/add_business_old_department', [BusinessDepartment::class, 'businessDepartmentAdd']);

Route::post('/webhooks/add_job_request', [WebhookReceiverController::class, 'AddJobRequestHook']);
Route::post('/webhooks/update_job_request', [WebhookReceiverController::class, 'UpdateJobRequestHook']);
Route::post('/webhooks/add_special_requirement', [WebhookReceiverController::class, 'AddSpecialRequirementHook']);

Route::get('google/auth-url', [JobController::class, 'getAuthUrl']);

Route::post('google/token', [JobController::class, 'getRefreshToken']);

Route::get('/google/callback', [JobController::class, 'handleCallback']);
Route::post('/google/create-folder', [JobController::class, 'createDriveFolder']);
Route::post('/google/upload_recruit_resume', [JobController::class, 'UploadRecruiterResume']);
Route::post('/google/folder/public-viewer', [JobController::class, 'makeFolderPublic']);
Route::post('/google/folder/public-restrict', [JobController::class, 'makeFolderRestricted']);
