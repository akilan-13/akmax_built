-- Elysium ERP - Tool Management / Productivity Suite
-- MySQL 8.0+ | Safe to run on an existing ERP where these tables do not yet exist.
-- Core ERP tables (users/company/entity/etc.) are intentionally not recreated here.

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS egpk_contact_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    category_name VARCHAR(120) NOT NULL,
    color VARCHAR(20) NULL DEFAULT '#C0392B',
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_contact_cat_company_status (company_id, status),
    KEY idx_contact_cat_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contacts (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    salutation VARCHAR(20) NULL,
    person_name VARCHAR(180) NOT NULL,
    designation VARCHAR(150) NULL,
    organisation VARCHAR(180) NULL,
    department VARCHAR(150) NULL,
    phone_primary VARCHAR(40) NULL,
    phone_alternate VARCHAR(40) NULL,
    email_primary VARCHAR(180) NULL,
    email_secondary VARCHAR(180) NULL,
    city VARCHAR(100) NULL,
    address TEXT NULL,
    website VARCHAR(255) NULL,
    category_id BIGINT UNSIGNED NOT NULL,
    tags_json JSON NULL,
    notes TEXT NULL,
    profile_photo VARCHAR(500) NULL,
    is_starred TINYINT(1) NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_contact_company_visibility (company_id, visibility),
    KEY idx_contact_owner (owner_user_id),
    KEY idx_contact_category (category_id),
    KEY idx_contact_phone (phone_primary),
    KEY idx_contact_email (email_primary),
    KEY idx_contact_name (person_name),
    KEY idx_contact_status_deleted (status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_imports (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    source VARCHAR(30) NOT NULL,
    file_name VARCHAR(255) NULL,
    total_rows INT UNSIGNED NOT NULL DEFAULT 0,
    imported_rows INT UNSIGNED NOT NULL DEFAULT 0,
    merged_rows INT UNSIGNED NOT NULL DEFAULT 0,
    skipped_rows INT UNSIGNED NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'completed',
    report_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_contact_import_owner (owner_user_id, created_at),
    KEY idx_contact_import_company (company_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_contact_merge_logs (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    surviving_contact_id BIGINT UNSIGNED NOT NULL,
    merged_contact_id BIGINT UNSIGNED NOT NULL,
    merged_by BIGINT UNSIGNED NULL,
    field_decisions JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_contact_merge_survivor (surviving_contact_id),
    KEY idx_contact_merge_merged (merged_contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_search_history (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    module_name VARCHAR(80) NOT NULL,
    search_text VARCHAR(500) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_egpk_search_user_module (user_id, module_name, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_boards (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    board_name VARCHAR(160) NOT NULL,
    icon VARCHAR(100) NULL,
    description TEXT NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    is_locked TINYINT(1) NOT NULL DEFAULT 0,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_board_company_visibility (company_id, visibility),
    KEY idx_board_owner (owner_user_id),
    KEY idx_board_sort (sort_order),
    KEY idx_board_archived (is_archived, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_board_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    board_id BIGINT UNSIGNED NOT NULL,
    category_name VARCHAR(160) NOT NULL,
    color VARCHAR(20) NOT NULL DEFAULT '#4A3E8E',
    sort_order INT NOT NULL DEFAULT 0,
    is_collapsed TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_board_category_board (board_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmarks (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    board_id BIGINT UNSIGNED NOT NULL,
    category_id BIGINT UNSIGNED NOT NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    bookmark_name VARCHAR(180) NOT NULL,
    url VARCHAR(2000) NOT NULL,
    description TEXT NULL,
    favicon_url VARCHAR(1000) NULL,
    manual_icon VARCHAR(500) NULL,
    tags_json JSON NULL,
    click_count INT UNSIGNED NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    health_status VARCHAR(30) NOT NULL DEFAULT 'unknown',
    last_checked_at DATETIME NULL,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_bookmark_board_category (board_id, category_id, sort_order),
    KEY idx_bookmark_owner (owner_user_id),
    KEY idx_bookmark_health (health_status),
    KEY idx_bookmark_status_deleted (status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_bookmark_clicks (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    bookmark_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    clicked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(1000) NULL,
    PRIMARY KEY (sno),
    KEY idx_bookmark_click_bookmark_date (bookmark_id, clicked_at),
    KEY idx_bookmark_click_user (user_id, clicked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_board_shares (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    board_id BIGINT UNSIGNED NOT NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NULL,
    grantee_type VARCHAR(20) NOT NULL DEFAULT 'user',
    grantee_id VARCHAR(120) NULL,
    permission VARCHAR(20) NOT NULL DEFAULT 'View',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    expires_at DATETIME NULL,
    requested_by BIGINT NULL,
    approved_by BIGINT NULL,
    approved_at DATETIME NULL,
    created_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_board_share_board (board_id, status),
    KEY idx_board_share_user (user_id, status),
    KEY idx_board_share_grantee (grantee_type, grantee_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    category_name VARCHAR(120) NOT NULL,
    color VARCHAR(20) NULL DEFAULT '#B02418',
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_vault_cat_company_status (company_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entries (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    entry_type ENUM('Website','System','Application','Mobile App') NOT NULL DEFAULT 'Website',
    category_id BIGINT UNSIGNED NULL,
    entry_name VARCHAR(180) NOT NULL,
    url VARCHAR(2000) NULL,
    username VARCHAR(255) NULL,
    password_cipher LONGTEXT NULL,
    password_key_ref VARCHAR(255) NULL,
    notes_cipher LONGTEXT NULL,
    email VARCHAR(180) NULL,
    mobile VARCHAR(40) NULL,
    icon_path VARCHAR(1000) NULL,
    icon_url VARCHAR(1000) NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    rotation_days INT UNSIGNED NULL DEFAULT 90,
    last_rotated_at DATETIME NULL,
    next_rotation_at DATETIME NULL,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_vault_owner_visibility (owner_user_id, visibility),
    KEY idx_vault_company (company_id),
    KEY idx_vault_category (category_id),
    KEY idx_vault_rotation (next_rotation_at),
    KEY idx_vault_status_deleted (status, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entry_history (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    vault_entry_id BIGINT UNSIGNED NOT NULL,
    password_cipher LONGTEXT NULL,
    password_key_ref VARCHAR(255) NULL,
    notes_cipher LONGTEXT NULL,
    changed_by BIGINT UNSIGNED NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_vault_hist_entry_date (vault_entry_id, changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_vault_entry_attachments (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    vault_entry_id BIGINT UNSIGNED NOT NULL,
    original_name VARCHAR(255) NULL,
    storage_path VARCHAR(1000) NOT NULL,
    mime_type VARCHAR(150) NULL,
    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_vault_attach_entry (vault_entry_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_stepup_sessions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    verified_until DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_stepup_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_share_grants (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    resource_type VARCHAR(60) NOT NULL,
    resource_id BIGINT UNSIGNED NOT NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    grantee_type ENUM('user','role','company','group') NOT NULL,
    grantee_id VARCHAR(120) NOT NULL,
    permission ENUM('View','Manage') NOT NULL DEFAULT 'View',
    status ENUM('pending','active','revoked','expired','rejected') NOT NULL DEFAULT 'pending',
    expires_at DATETIME NULL,
    requested_by BIGINT UNSIGNED NULL,
    approved_by BIGINT UNSIGNED NULL,
    approval_required TINYINT(1) NOT NULL DEFAULT 0,
    approved_at DATETIME NULL,
    revoked_by BIGINT UNSIGNED NULL,
    revoked_at DATETIME NULL,
    metadata_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_share_resource (resource_type, resource_id, status),
    KEY idx_share_grantee (grantee_type, grantee_id, status),
    KEY idx_share_owner (owner_user_id, status),
    KEY idx_share_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    category_name VARCHAR(160) NOT NULL,
    color VARCHAR(20) NULL DEFAULT '#00796B',
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_know_cat_company_status (company_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_subcategories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    category_id BIGINT UNSIGNED NOT NULL,
    subcategory_name VARCHAR(160) NOT NULL,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_know_sub_category (category_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_posts (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    author_user_id BIGINT UNSIGNED NOT NULL,
    category_id BIGINT UNSIGNED NOT NULL,
    subcategory_id BIGINT UNSIGNED NULL,
    title VARCHAR(240) NOT NULL,
    body_html LONGTEXT NULL,
    tags_json JSON NULL,
    audience_scope ENUM('Private','Company','Group') NOT NULL DEFAULT 'Company',
    status ENUM('draft','published','unpublished') NOT NULL DEFAULT 'draft',
    edit_version INT UNSIGNED NOT NULL DEFAULT 1,
    published_at DATETIME NULL,
    edited_at DATETIME NULL,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_know_post_author_status (author_user_id, status),
    KEY idx_know_post_company_status (company_id, status),
    KEY idx_know_post_category (category_id, subcategory_id),
    KEY idx_know_post_published (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_post_versions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    version_no INT UNSIGNED NOT NULL,
    title VARCHAR(240) NOT NULL,
    body_html LONGTEXT NULL,
    edited_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_know_post_version (post_id, version_no),
    KEY idx_know_post_ver_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_post_media (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    media_type ENUM('image','audio','video','file') NOT NULL,
    storage_path VARCHAR(1000) NOT NULL,
    original_name VARCHAR(255) NULL,
    mime_type VARCHAR(150) NULL,
    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    display_order INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'ready',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_know_media_post_order (post_id, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_replies (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    parent_reply_id BIGINT UNSIGNED NULL,
    author_user_id BIGINT UNSIGNED NOT NULL,
    body_html LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_know_reply_post_parent (post_id, parent_reply_id),
    KEY idx_know_reply_author (author_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_reactions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    reaction VARCHAR(30) NOT NULL DEFAULT 'like',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_know_reaction (post_id, user_id, reaction),
    KEY idx_know_reaction_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_saves (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_know_save (post_id, user_id),
    KEY idx_know_save_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_follows (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    category_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_know_follow (category_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_knowledge_reports (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id BIGINT UNSIGNED NOT NULL,
    reported_by BIGINT UNSIGNED NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'open',
    resolution_reason TEXT NULL,
    resolved_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_know_report_status (status, created_at),
    KEY idx_know_report_post (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_apps (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    app_name VARCHAR(180) NOT NULL,
    app_url VARCHAR(2000) NOT NULL,
    purpose TEXT NULL,
    platform ENUM('Web Portal','Mobile App','Desktop') NOT NULL DEFAULT 'Web Portal',
    environment ENUM('Production','Staging') NOT NULL DEFAULT 'Production',
    status ENUM('Live','Under Maintenance','Deprecated') NOT NULL DEFAULT 'Live',
    technical_owner_user_id BIGINT UNSIGNED NULL,
    icon_path VARCHAR(1000) NULL,
    passwallet_entry_id BIGINT UNSIGNED NULL,
    current_version VARCHAR(60) NULL,
    most_used_score INT UNSIGNED NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_portal_company_status (company_id, status),
    KEY idx_portal_environment (environment),
    KEY idx_portal_usage (most_used_score),
    KEY idx_portal_name (app_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_app_versions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    app_id BIGINT UNSIGNED NOT NULL,
    version_no VARCHAR(60) NOT NULL,
    update_details TEXT NULL,
    bug_fix_details TEXT NULL,
    updated_by BIGINT UNSIGNED NULL,
    update_date DATE NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_portal_ver_app_date (app_id, update_date, sno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_subscriptions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    app_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    company_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_portal_sub_user (app_id, user_id),
    KEY idx_portal_sub_company (company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_portal_launches (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    app_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    launched_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(1000) NULL,
    PRIMARY KEY (sno),
    KEY idx_portal_launch_app_date (app_id, launched_at),
    KEY idx_portal_launch_user_date (user_id, launched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meetings (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    title VARCHAR(240) NOT NULL,
    category VARCHAR(100) NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    venue VARCHAR(500) NULL,
    meeting_url VARCHAR(2000) NULL,
    agenda TEXT NULL,
    reminder_minutes INT NULL DEFAULT 15,
    status VARCHAR(30) NOT NULL DEFAULT 'scheduled',
    notes TEXT NULL,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_meeting_owner_start (owner_user_id, start_at),
    KEY idx_meeting_company_start (company_id, start_at),
    KEY idx_meeting_status (status),
    KEY idx_meeting_deleted (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meeting_participants (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    meeting_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    display_name VARCHAR(180) NULL,
    email VARCHAR(180) NULL,
    rsvp VARCHAR(30) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_meeting_participant_meeting (meeting_id),
    KEY idx_meeting_participant_user (user_id, rsvp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_meeting_reschedules (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    meeting_id BIGINT UNSIGNED NOT NULL,
    old_start_at DATETIME NOT NULL,
    old_end_at DATETIME NOT NULL,
    new_start_at DATETIME NOT NULL,
    new_end_at DATETIME NOT NULL,
    reason VARCHAR(500) NULL,
    changed_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_meeting_reschedule_meeting (meeting_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_tasks (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    title VARCHAR(240) NOT NULL,
    description TEXT NULL,
    category VARCHAR(100) NULL,
    due_at DATETIME NULL,
    priority ENUM('Urgent','High','Medium','Low') NOT NULL DEFAULT 'Medium',
    status ENUM('To Do','In Progress','On Hold','Pending Verification','Completed') NOT NULL DEFAULT 'To Do',
    supervisor_user_id BIGINT UNSIGNED NULL,
    verification_required TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_task_owner_status (owner_user_id, status),
    KEY idx_task_company_status (company_id, status),
    KEY idx_task_due (due_at),
    KEY idx_task_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_task_assignees (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_task_assignee (task_id, user_id),
    KEY idx_task_assignee_user (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_task_comments (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    comment_text TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_task_comment_task (task_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_sticky_notes (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    title VARCHAR(240) NOT NULL,
    body LONGTEXT NULL,
    color VARCHAR(20) NOT NULL DEFAULT '#FFF8C7',
    priority VARCHAR(20) NULL DEFAULT 'normal',
    reminder_at DATETIME NULL,
    checklist_json JSON NULL,
    label VARCHAR(100) NULL,
    status ENUM('active','archived','trashed') NOT NULL DEFAULT 'active',
    is_pinned TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_note_owner_status (owner_user_id, status),
    KEY idx_note_reminder (reminder_at),
    KEY idx_note_visibility (visibility)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_accounts (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    account_name VARCHAR(160) NOT NULL,
    account_type VARCHAR(80) NOT NULL,
    opening_balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    current_balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    status TINYINT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_money_account_owner_status (owner_user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_transactions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    account_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    transaction_date DATE NOT NULL,
    category VARCHAR(120) NOT NULL,
    mode VARCHAR(80) NULL,
    note VARCHAR(500) NULL,
    amount DECIMAL(15,2) NOT NULL,
    transaction_type ENUM('income','expense') NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_money_tx_account_date (account_id, transaction_date),
    KEY idx_money_tx_owner_date (created_by, transaction_date),
    KEY idx_money_tx_type (transaction_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_budgets (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    budget_month DATE NOT NULL,
    category VARCHAR(120) NOT NULL,
    budget_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_money_budget (owner_user_id, company_id, budget_month, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_money_commitments (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    commitment_name VARCHAR(180) NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    recurrence VARCHAR(40) NULL,
    status ENUM('pending','paid','cancelled') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_money_commit_owner_due (owner_user_id, due_date, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_events (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Company',
    event_name VARCHAR(240) NOT NULL,
    organisation VARCHAR(180) NULL,
    event_type VARCHAR(100) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NULL,
    venue VARCHAR(500) NULL,
    is_online TINYINT(1) NOT NULL DEFAULT 0,
    online_link VARCHAR(2000) NULL,
    registration_type VARCHAR(30) NULL DEFAULT 'Free',
    payment_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    reminder_stage VARCHAR(100) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Planned',
    description TEXT NULL,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_event_owner_date (owner_user_id, event_date),
    KEY idx_event_company_date (company_id, event_date),
    KEY idx_event_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_documents (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    visibility ENUM('Private','Company','Group') NOT NULL DEFAULT 'Private',
    scope ENUM('Personal','Official') NOT NULL DEFAULT 'Personal',
    category VARCHAR(100) NULL,
    document_name VARCHAR(255) NOT NULL,
    storage_path VARCHAR(1000) NOT NULL,
    mime_type VARCHAR(150) NULL,
    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    version_no INT UNSIGNED NOT NULL DEFAULT 1,
    expiry_date DATE NULL,
    is_pinned TINYINT(1) NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_doc_owner_scope (owner_user_id, scope, status),
    KEY idx_doc_company (company_id),
    KEY idx_doc_expiry (expiry_date),
    KEY idx_doc_pinned (is_pinned, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_document_versions (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    document_id BIGINT UNSIGNED NOT NULL,
    version_no INT UNSIGNED NOT NULL,
    storage_path VARCHAR(1000) NOT NULL,
    mime_type VARCHAR(150) NULL,
    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    uploaded_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_doc_version (document_id, version_no),
    KEY idx_doc_version_document (document_id, version_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_productivity_notifications (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    company_id BIGINT UNSIGNED NULL,
    module_name VARCHAR(80) NOT NULL,
    resource_type VARCHAR(80) NULL,
    resource_id BIGINT UNSIGNED NULL,
    notification_type VARCHAR(80) NULL,
    title VARCHAR(240) NULL,
    message TEXT NOT NULL,
    action_url VARCHAR(1000) NULL,
    icon VARCHAR(80) NULL,
    icon_color VARCHAR(20) NULL,
    expires_at DATETIME NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    read_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_prod_notif_user_read_date (user_id, is_read, created_at),
    KEY idx_prod_notif_company (company_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egpk_audit_logs (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_name VARCHAR(80) NOT NULL,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(80) NULL,
    resource_id BIGINT UNSIGNED NULL,
    actor_user_id BIGINT UNSIGNED NULL,
    actor_name VARCHAR(180) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(1000) NULL,
    before_json JSON NULL,
    after_json JSON NULL,
    meta_json JSON NULL,
    is_high_sensitivity TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_audit_module_date (module_name, created_at),
    KEY idx_audit_resource (resource_type, resource_id, created_at),
    KEY idx_audit_actor (actor_user_id, created_at),
    KEY idx_audit_sensitive (is_high_sensitivity, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Initial masters used by the UI. Existing values are preserved.
INSERT INTO egpk_contact_categories (category_name, color, status, created_at, updated_at)
SELECT 'Client', '#2E7D32', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Client' AND status=0);

INSERT INTO egpk_contact_categories (category_name, color, status, created_at, updated_at)
SELECT 'College', '#1F618D', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='College' AND status=0);

INSERT INTO egpk_contact_categories (category_name, color, status, created_at, updated_at)
SELECT 'Vendor', '#D35400', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Vendor' AND status=0);

INSERT INTO egpk_contact_categories (category_name, color, status, created_at, updated_at)
SELECT 'Government', '#7D3C98', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Government' AND status=0);

INSERT INTO egpk_contact_categories (category_name, color, status, created_at, updated_at)
SELECT 'Trainer', '#00796B', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_contact_categories WHERE category_name='Trainer' AND status=0);

INSERT INTO egpk_vault_categories (category_name, color, status, created_at, updated_at)
SELECT 'Internal Systems', '#B02418', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Internal Systems' AND status=0);

INSERT INTO egpk_vault_categories (category_name, color, status, created_at, updated_at)
SELECT 'Google Tools', '#1F618D', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Google Tools' AND status=0);

INSERT INTO egpk_vault_categories (category_name, color, status, created_at, updated_at)
SELECT 'Hosting', '#4A3E8E', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_vault_categories WHERE category_name='Hosting' AND status=0);

INSERT INTO egpk_knowledge_categories (category_name, color, status, created_at, updated_at)
SELECT 'HR & Admin', '#C0392B', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='HR & Admin' AND status=0);

INSERT INTO egpk_knowledge_categories (category_name, color, status, created_at, updated_at)
SELECT 'Development', '#0288D1', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='Development' AND status=0);

INSERT INTO egpk_knowledge_categories (category_name, color, status, created_at, updated_at)
SELECT 'SEO', '#2E7D32', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egpk_knowledge_categories WHERE category_name='SEO' AND status=0);
