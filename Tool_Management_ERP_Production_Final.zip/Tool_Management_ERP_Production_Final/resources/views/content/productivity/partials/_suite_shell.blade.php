@vite(['resources/assets/css/productivity/productivity-suite.css', 'resources/assets/js/productivity/productivity-suite.js'])
<div class="egpk-app" data-egpk-module="{{ $module }}" data-egpk-title="{{ $title }}">
    <div class="egpk-header">
        <div class="egpk-header-main">
            <div class="egpk-title-wrap">
                <span class="egpk-title-icon"><i class="mdi mdi-tools"></i></span>
                <div>
                    <div class="egpk-breadcrumb">Tool Management <span>/</span> Productivity Suite</div>
                    <h1 class="egpk-page-title">{{ $title }}</h1>
                </div>
            </div>
            <div class="egpk-header-actions">
                <button type="button" class="btn btn-light btn-sm egpk-header-btn" id="egpkGlobalSearchBtn">
                    <i class="mdi mdi-magnify"></i><span class="d-none d-md-inline">Search</span>
                </button>
                <button type="button" class="btn btn-light btn-sm egpk-header-btn" id="egpkToolLauncher">
                    <i class="mdi mdi-view-grid-outline"></i><span class="d-none d-md-inline">Tools</span>
                </button>
                <button type="button" class="btn btn-light btn-sm egpk-header-btn position-relative" id="egpkNotificationBtn">
                    <i class="mdi mdi-bell-outline"></i>
                    <span class="egpk-notification-badge d-none" id="egpkNotificationCount">0</span>
                </button>
            </div>
        </div>
    </div>

    <div class="egpk-tool-launcher d-none" id="egpkToolLauncherPanel">
        <div class="egpk-tool-launcher-head">
            <div>
                <div class="egpk-section-kicker">TOOL MANAGEMENT</div>
                <div class="fw-bold">Elysium Productivity Tools</div>
            </div>
            <button type="button" class="btn-close" id="egpkToolLauncherClose"></button>
        </div>
        <div class="egpk-tool-launcher-grid" id="egpkToolLauncherGrid"></div>
    </div>

    <div class="egpk-notification-panel d-none" id="egpkNotificationPanel">
        <div class="egpk-panel-head">
            <div class="fw-bold">Notifications</div>
            <button class="btn btn-link btn-sm p-0" id="egpkNotificationsRead">Mark all read</button>
        </div>
        <div id="egpkNotificationList" class="egpk-notification-list"></div>
    </div>

    <div class="egpk-global-search d-none" id="egpkGlobalSearchPanel">
        <div class="egpk-global-search-inner">
            <div class="input-group">
                <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                <input type="text" id="egpkGlobalSearchInput" class="form-control" placeholder="Search contacts, bookmarks, knowledge, portals...">
                <button type="button" class="btn btn-light" id="egpkGlobalSearchClose"><i class="mdi mdi-close"></i></button>
            </div>
            <div id="egpkGlobalSearchResults" class="egpk-global-results"></div>
        </div>
    </div>

    <div class="egpk-tool-nav-wrap">
        <div class="egpk-tool-nav" id="egpkToolNav"></div>
    </div>

    <div class="egpk-content-shell">
        <div class="egpk-hero">
            <div>
                <div class="egpk-section-kicker">ELYSIUM ERP · TOOL MANAGEMENT</div>
                <h2 id="egpkHeroTitle">{{ $title }}</h2>
                <p id="egpkHeroSubtitle">Shared productivity workspace with company-aware access, global search and governed sharing.</p>
            </div>
            <div id="egpkHeroActions" class="d-flex flex-wrap gap-2"></div>
        </div>

        <div id="egpkStats" class="row g-3 mb-3"></div>

        <div class="egpk-toolbar-card mb-3">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg-5">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                        <input type="search" id="egpkSearch" class="form-control" placeholder="Search this tool...">
                        <button type="button" class="btn btn-light" id="egpkSearchClear"><i class="mdi mdi-close"></i></button>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <select id="egpkCompany" class="form-select form-select-sm"><option value="all">All Companies</option></select>
                </div>
                <div class="col-6 col-lg-2" id="egpkFilterSlot"></div>
                <div class="col-12 col-lg-3 d-flex justify-content-lg-end gap-2">
                    <button class="btn btn-outline-secondary btn-sm" id="egpkRefresh"><i class="mdi mdi-refresh"></i> Refresh</button>
                    <div class="btn-group btn-group-sm" id="egpkViewSwitcher"></div>
                </div>
            </div>
        </div>

        <div id="egpkFlash" class="alert d-none mb-3"></div>
        <div id="egpkWorkspace" class="position-relative"></div>
    </div>

    <div class="modal fade" id="egpkFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="egpkFormTitle">Create</h5>
                        <div class="small text-muted" id="egpkFormSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="egpkForm">
                    <div class="modal-body" id="egpkFormBody"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="egpkFormSubmit"><i class="mdi mdi-content-save-outline"></i> Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="egpkViewTitle">Details</h5>
                        <div class="small text-muted" id="egpkViewSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="egpkViewBody"></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkShareModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title">Share</h5>
                        <div class="small text-muted">Share with a user, role, company or the whole group.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="egpkShareForm">
                        <input type="hidden" id="egpkShareType">
                        <input type="hidden" id="egpkShareId">
                        <div class="row g-3">
                            <div class="col-md-4"><label class="form-label">Share With</label><select class="form-select" id="egpkShareGranteeType"><option value="user">User</option><option value="role">Role</option><option value="company">Company</option><option value="group">Group</option></select></div>
                            <div class="col-md-4"><label class="form-label">Recipient</label><select class="form-select" id="egpkShareGranteeId"></select></div>
                            <div class="col-md-4"><label class="form-label">Permission</label><select class="form-select" id="egpkSharePermission"><option value="View">View</option><option value="Manage">Manage</option></select></div>
                            <div class="col-md-6"><label class="form-label">Expiry</label><input type="datetime-local" class="form-control" id="egpkShareExpiry"></div>
                        </div>
                    </form>
                    <div class="mt-4"><div class="egpk-section-title">Active / Pending Shares</div><div id="egpkShareList"></div></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button><button type="button" class="btn btn-primary btn-sm" id="egpkShareSave">Share</button></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="egpkConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="egpkConfirmBody"></div>
            <div class="modal-footer"><button class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger btn-sm" id="egpkConfirmYes">Confirm</button></div>
        </div></div>
    </div>

    <div class="modal fade" id="egpkStepupModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Security Verification</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><div class="alert alert-warning py-2 small">Sensitive PassWallet actions require fresh ERP verification.</div><label class="form-label">ERP Password</label><input id="egpkStepupPassword" type="password" autocomplete="current-password" class="form-control"></div>
            <div class="modal-footer"><button class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary btn-sm" id="egpkStepupConfirm">Verify</button></div>
        </div></div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:1085">
        <div class="toast" id="egpkToast" role="alert"><div class="toast-body"></div></div>
    </div>
</div>

<script type="application/json" id="egpkRouteConfig">{!! json_encode([
    'module' => $module,
    'csrf' => csrf_token(),
    'routes' => [
        'dashboard' => route('productivity.dashboard.data'),
        'companies' => route('productivity.companies'),
        'users' => route('productivity.users'),
        'global' => route('productivity.global.search'),
        'notifications' => route('productivity.notifications'),
        'notificationsRead' => route('productivity.notifications.read'),
        'contacts' => [
            'data'=>route('productivity.contacts.data'),'categories'=>route('productivity.contacts.categories'),'store'=>route('productivity.contacts.store'),'show'=>url('/productivity/contactbook'),'update'=>url('/productivity/contactbook'),'bulk'=>route('productivity.contacts.bulk'),'star'=>url('/productivity/contactbook'),'exportCsv'=>route('productivity.contacts.export.csv'),'exportXlsx'=>route('productivity.contacts.export.xlsx'),'vcard'=>route('productivity.contacts.export.vcard'),'import'=>route('productivity.contacts.import'),'googleImport'=>route('productivity.contacts.google.import'),'googleConnect'=>route('productivity.contacts.google.connect'),'googleCallback'=>route('productivity.contacts.google.callback')
        ],
        'bookmarks' => [
            'data'=>route('productivity.bookmarks.data'),'boards'=>route('productivity.bookmarks.boards'),'board'=>url('/productivity/bookmarks/board'),'boardStore'=>route('productivity.bookmarks.board.store'),'boardUpdate'=>url('/productivity/bookmarks/boards'),'boardDelete'=>url('/productivity/bookmarks/boards'),'categoryStore'=>url('/productivity/bookmarks/boards'),'categoryUpdate'=>url('/productivity/bookmarks/categories'),'categoryDelete'=>url('/productivity/bookmarks/categories'),'store'=>route('productivity.bookmarks.store'),'quick'=>route('productivity.bookmarks.quick'),'update'=>url('/productivity/bookmarks'),'importHtml'=>route('productivity.bookmarks.import.html'),'open'=>url('/productivity/bookmarks'),'health'=>url('/productivity/bookmarks'),'delete'=>url('/productivity/bookmarks'),'moveCopy'=>url('/productivity/bookmarks')
        ],
        'passwallet' => ['data'=>route('productivity.passwallet.data'),'categories'=>route('productivity.passwallet.categories'),'store'=>route('productivity.passwallet.store'),'show'=>url('/productivity/passwallet'),'update'=>url('/productivity/passwallet'),'reveal'=>url('/productivity/passwallet'),'history'=>url('/productivity/passwallet'),'shares'=>url('/productivity/passwallet'),'delete'=>url('/productivity/passwallet'),'generator'=>route('productivity.passwallet.generator'),'attachment'=>url('/productivity/passwallet'),'stepup'=>route('productivity.passwallet.stepup'),'lockdown'=>url('/productivity/passwallet/lockdown')],
        'knowledge' => ['data'=>route('productivity.knowledge.data'),'categories'=>route('productivity.knowledge.categories'),'store'=>route('productivity.knowledge.store'),'show'=>url('/productivity/knowledge'),'update'=>url('/productivity/knowledge'),'like'=>url('/productivity/knowledge'),'save'=>url('/productivity/knowledge'),'reply'=>url('/productivity/knowledge'),'report'=>url('/productivity/knowledge'),'follow'=>url('/productivity/knowledge/categories'),'media'=>url('/productivity/knowledge'),'moderate'=>url('/productivity/knowledge')],
        'portals' => ['data'=>route('productivity.portals.data'),'store'=>route('productivity.portals.store'),'show'=>url('/productivity/portals'),'update'=>url('/productivity/portals'),'version'=>url('/productivity/portals'),'launch'=>url('/productivity/portals'),'subscribe'=>url('/productivity/portals'),'exportXlsx'=>route('productivity.portals.export.xlsx')],
        'meetings' => ['data'=>route('productivity.meetings.data'),'calendar'=>route('productivity.meetings.calendar'),'store'=>route('productivity.meetings.store'),'show'=>url('/productivity/meetings'),'update'=>url('/productivity/meetings'),'reschedule'=>url('/productivity/meetings'),'rsvp'=>url('/productivity/meetings'),'delete'=>url('/productivity/meetings')],
        'tasks' => ['data'=>route('productivity.tasks.data'),'store'=>route('productivity.tasks.store'),'show'=>url('/productivity/tasks'),'update'=>url('/productivity/tasks'),'status'=>url('/productivity/tasks'),'comment'=>url('/productivity/tasks'),'verify'=>url('/productivity/tasks'),'delete'=>url('/productivity/tasks')],
        'notes' => ['data'=>route('productivity.notes.data'),'store'=>route('productivity.notes.store'),'update'=>url('/productivity/notes'),'action'=>url('/productivity/notes')],
        'money' => ['data'=>route('productivity.money.data'),'account'=>route('productivity.money.account'),'transaction'=>route('productivity.money.transaction'),'budget'=>route('productivity.money.budget'),'commitment'=>route('productivity.money.commitment')],
        'events' => ['data'=>route('productivity.events.data'),'calendar'=>route('productivity.events.calendar'),'store'=>route('productivity.events.store'),'show'=>url('/productivity/events'),'update'=>url('/productivity/events'),'delete'=>url('/productivity/events')],
        'documents' => ['data'=>route('productivity.documents.data'),'upload'=>route('productivity.documents.upload'),'version'=>url('/productivity/documents'),'versions'=>url('/productivity/documents'),'url'=>url('/productivity/documents'),'pin'=>url('/productivity/documents'),'delete'=>url('/productivity/documents')],
        'shares' => ['data'=>route('productivity.shares.data'),'store'=>route('productivity.shares.store'),'approve'=>url('/productivity/shares'),'revoke'=>url('/productivity/shares')],
        'reports' => ['data'=>route('productivity.reports.data'),'csv'=>route('productivity.reports.csv'),'xlsx'=>route('productivity.reports.xlsx')],
        'admin' => ['data'=>route('productivity.admin.data'),'category'=>route('productivity.admin.category')]
    ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
