<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\productivity\{
    DashboardController,
    SuiteController,
    ContactBookController,
    BookmarksController,
    PassWalletController,
    KnowledgePanelController,
    PortalAppController,
    MeetingController,
    TaskController,
    NotesController,
    MoneyController,
    EventController,
    DocumentController,
    ShareController,
    ReportController,
    AdminController
};

/*
 |--------------------------------------------------------------------------
 | Tool Management / Productivity Suite
 |--------------------------------------------------------------------------
 | Keep this route file independent from unrelated ERP modules. The menu uses
 | /productivity/* URLs so existing deep links remain stable.
 */
Route::middleware(['auth:web', 'timezone', 'throttle:180,1'])
    ->prefix('productivity')
    ->name('productivity.')
    ->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/dashboard/data', [DashboardController::class, 'data'])->name('dashboard.data');

        Route::get('/notifications', [SuiteController::class, 'notifications'])->name('notifications');
        Route::post('/notifications/read', [SuiteController::class, 'markNotificationsRead'])->name('notifications.read');
        Route::get('/menu', [SuiteController::class, 'menu'])->name('menu');
        Route::get('/companies', [SuiteController::class, 'companies'])->name('companies');
        Route::get('/users', [SuiteController::class, 'users'])->name('users');
        Route::get('/global-search', [SuiteController::class, 'globalSearch'])->name('global.search');

        // ContactBook
        Route::get('/contactbook', [ContactBookController::class, 'index'])->name('contacts');
        Route::get('/contactbook/data', [ContactBookController::class, 'data'])->name('contacts.data');
        Route::get('/contactbook/categories', [ContactBookController::class, 'categories'])->name('contacts.categories');
        Route::get('/contactbook/export/csv', [ContactBookController::class, 'exportCsv'])->name('contacts.export.csv');
        Route::get('/contactbook/export/xlsx', [ContactBookController::class, 'exportXlsx'])->name('contacts.export.xlsx');
        Route::get('/contactbook/export/vcard', [ContactBookController::class, 'exportVcard'])->name('contacts.export.vcard');
        Route::get('/contactbook/search/history', [ContactBookController::class, 'searchHistory'])->name('contacts.search.history');
        Route::post('/contactbook/search/history', [ContactBookController::class, 'saveSearch'])->name('contacts.search.save');
        Route::post('/contactbook/bulk', [ContactBookController::class, 'bulk'])->name('contacts.bulk');
        Route::post('/contactbook/import', [ContactBookController::class, 'import'])->name('contacts.import');
        Route::post('/contactbook/google-import', [ContactBookController::class, 'googleImport'])->name('contacts.google.import');
        Route::get('/contactbook/google/connect', [ContactBookController::class, 'googleConnect'])->name('contacts.google.connect');
        Route::get('/contactbook/google/callback', [ContactBookController::class, 'googleCallback'])->name('contacts.google.callback');
        Route::post('/contactbook/merge', [ContactBookController::class, 'merge'])->name('contacts.merge');
        Route::post('/contactbook', [ContactBookController::class, 'store'])->name('contacts.store');
        Route::get('/contactbook/{id}', [ContactBookController::class, 'show'])->whereNumber('id')->name('contacts.show');
        Route::put('/contactbook/{id}', [ContactBookController::class, 'update'])->whereNumber('id')->name('contacts.update');
        Route::delete('/contactbook/{id}', [ContactBookController::class, 'delete'])->whereNumber('id')->name('contacts.delete');
        Route::post('/contactbook/{id}/restore', [ContactBookController::class, 'restore'])->whereNumber('id')->name('contacts.restore');
        Route::post('/contactbook/{id}/star', [ContactBookController::class, 'star'])->whereNumber('id')->name('contacts.star');

        // BookMarks
        Route::get('/bookmarks', [BookmarksController::class, 'index'])->name('bookmarks');
        Route::get('/bookmarks/boards', [BookmarksController::class, 'boards'])->name('bookmarks.boards');
        Route::get('/bookmarks/data', [BookmarksController::class, 'data'])->name('bookmarks.data');
        Route::get('/bookmarks/board/{id}', [BookmarksController::class, 'board'])->whereNumber('id')->name('bookmarks.board');
        Route::post('/bookmarks/boards', [BookmarksController::class, 'storeBoard'])->name('bookmarks.board.store');
        Route::put('/bookmarks/boards/{id}', [BookmarksController::class, 'updateBoard'])->whereNumber('id')->name('bookmarks.board.update');
        Route::delete('/bookmarks/boards/{id}', [BookmarksController::class, 'deleteBoard'])->whereNumber('id')->name('bookmarks.board.delete');
        Route::post('/bookmarks/boards/{boardId}/categories', [BookmarksController::class, 'storeCategory'])->whereNumber('boardId')->name('bookmarks.category.store');
        Route::put('/bookmarks/categories/{id}', [BookmarksController::class, 'updateCategory'])->whereNumber('id')->name('bookmarks.category.update');
        Route::delete('/bookmarks/categories/{id}', [BookmarksController::class, 'deleteCategory'])->whereNumber('id')->name('bookmarks.category.delete');
        Route::post('/bookmarks/quick-add', [BookmarksController::class, 'quickAdd'])->name('bookmarks.quick');
        Route::post('/bookmarks', [BookmarksController::class, 'storeBookmark'])->name('bookmarks.store');
        Route::put('/bookmarks/{id}', [BookmarksController::class, 'updateBookmark'])->whereNumber('id')->name('bookmarks.update');
        Route::delete('/bookmarks/{id}', [BookmarksController::class, 'deleteBookmark'])->whereNumber('id')->name('bookmarks.delete');
        Route::post('/bookmarks/{id}/open', [BookmarksController::class, 'open'])->whereNumber('id')->name('bookmarks.open');
        Route::post('/bookmarks/{id}/health', [BookmarksController::class, 'health'])->whereNumber('id')->name('bookmarks.health');
        Route::post('/bookmarks/import-html', [BookmarksController::class, 'importHtml'])->name('bookmarks.import.html');
        Route::post('/bookmarks/{id}/move-copy', [BookmarksController::class, 'moveCopy'])->whereNumber('id')->name('bookmarks.move-copy');

        // PassWallet
        Route::get('/passwallet', [PassWalletController::class, 'index'])->name('passwallet');
        Route::get('/passwallet/data', [PassWalletController::class, 'data'])->name('passwallet.data');
        Route::get('/passwallet/categories', [PassWalletController::class, 'categories'])->name('passwallet.categories');
        Route::post('/passwallet/generator', [PassWalletController::class, 'generator'])->name('passwallet.generator');
        Route::post('/passwallet/step-up', [PassWalletController::class, 'stepUp'])->name('passwallet.stepup');
        Route::post('/passwallet/lockdown/{userId}', [PassWalletController::class, 'lockdown'])->whereNumber('userId')->name('passwallet.lockdown');
        Route::post('/passwallet', [PassWalletController::class, 'store'])->name('passwallet.store');
        Route::get('/passwallet/{id}', [PassWalletController::class, 'show'])->whereNumber('id')->name('passwallet.show');
        Route::put('/passwallet/{id}', [PassWalletController::class, 'update'])->whereNumber('id')->name('passwallet.update');
        Route::post('/passwallet/{id}/reveal', [PassWalletController::class, 'reveal'])->whereNumber('id')->name('passwallet.reveal');
        Route::get('/passwallet/{id}/history', [PassWalletController::class, 'history'])->whereNumber('id')->name('passwallet.history');
        Route::get('/passwallet/{id}/shares', [PassWalletController::class, 'shares'])->whereNumber('id')->name('passwallet.shares');
        Route::post('/passwallet/{id}/attachment', [PassWalletController::class, 'attachment'])->whereNumber('id')->name('passwallet.attachment');
        Route::get('/passwallet/{id}/attachments', [PassWalletController::class, 'attachments'])->whereNumber('id')->name('passwallet.attachments');
        Route::delete('/passwallet/{id}', [PassWalletController::class, 'delete'])->whereNumber('id')->name('passwallet.delete');

        // Knowledge Panel
        Route::get('/knowledge', [KnowledgePanelController::class, 'index'])->name('knowledge');
        Route::get('/knowledge/categories', [KnowledgePanelController::class, 'categories'])->name('knowledge.categories');
        Route::get('/knowledge/data', [KnowledgePanelController::class, 'data'])->name('knowledge.data');
        Route::post('/knowledge', [KnowledgePanelController::class, 'store'])->name('knowledge.store');
        Route::get('/knowledge/{id}', [KnowledgePanelController::class, 'show'])->whereNumber('id')->name('knowledge.show');
        Route::put('/knowledge/{id}', [KnowledgePanelController::class, 'update'])->whereNumber('id')->name('knowledge.update');
        Route::post('/knowledge/{id}/like', [KnowledgePanelController::class, 'react'])->whereNumber('id')->name('knowledge.like');
        Route::post('/knowledge/{id}/save', [KnowledgePanelController::class, 'save'])->whereNumber('id')->name('knowledge.save');
        Route::post('/knowledge/{id}/reply', [KnowledgePanelController::class, 'reply'])->whereNumber('id')->name('knowledge.reply');
        Route::post('/knowledge/{id}/report', [KnowledgePanelController::class, 'report'])->whereNumber('id')->name('knowledge.report');
        Route::post('/knowledge/categories/{categoryId}/follow', [KnowledgePanelController::class, 'follow'])->whereNumber('categoryId')->name('knowledge.follow');
        Route::post('/knowledge/{id}/media', [KnowledgePanelController::class, 'mediaUpload'])->whereNumber('id')->name('knowledge.media');
        Route::post('/knowledge/{id}/moderate', [KnowledgePanelController::class, 'moderate'])->whereNumber('id')->name('knowledge.moderate');

        // Portals & Apps
        Route::get('/portals', [PortalAppController::class, 'index'])->name('portals');
        Route::get('/portals/data', [PortalAppController::class, 'data'])->name('portals.data');
        Route::get('/portals/export/xlsx', [PortalAppController::class, 'exportXlsx'])->name('portals.export.xlsx');
        Route::post('/portals', [PortalAppController::class, 'store'])->name('portals.store');
        Route::get('/portals/{id}', [PortalAppController::class, 'show'])->whereNumber('id')->name('portals.show');
        Route::put('/portals/{id}', [PortalAppController::class, 'update'])->whereNumber('id')->name('portals.update');
        Route::post('/portals/{id}/version', [PortalAppController::class, 'version'])->whereNumber('id')->name('portals.version');
        Route::post('/portals/{id}/launch', [PortalAppController::class, 'launch'])->whereNumber('id')->name('portals.launch');
        Route::post('/portals/{id}/subscribe', [PortalAppController::class, 'subscribe'])->whereNumber('id')->name('portals.subscribe');

        // Meetings
        Route::get('/meetings', [MeetingController::class, 'index'])->name('meetings');
        Route::get('/meetings/data', [MeetingController::class, 'data'])->name('meetings.data');
        Route::get('/meetings/calendar', [MeetingController::class, 'calendar'])->name('meetings.calendar');
        Route::post('/meetings', [MeetingController::class, 'store'])->name('meetings.store');
        Route::get('/meetings/{id}', [MeetingController::class, 'show'])->whereNumber('id')->name('meetings.show');
        Route::put('/meetings/{id}', [MeetingController::class, 'update'])->whereNumber('id')->name('meetings.update');
        Route::post('/meetings/{id}/reschedule', [MeetingController::class, 'reschedule'])->whereNumber('id')->name('meetings.reschedule');
        Route::post('/meetings/{id}/rsvp', [MeetingController::class, 'rsvp'])->whereNumber('id')->name('meetings.rsvp');
        Route::delete('/meetings/{id}', [MeetingController::class, 'delete'])->whereNumber('id')->name('meetings.delete');

        // Tasks
        Route::get('/tasks', [TaskController::class, 'index'])->name('tasks');
        Route::get('/tasks/data', [TaskController::class, 'data'])->name('tasks.data');
        Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
        Route::get('/tasks/{id}', [TaskController::class, 'show'])->whereNumber('id')->name('tasks.show');
        Route::put('/tasks/{id}', [TaskController::class, 'update'])->whereNumber('id')->name('tasks.update');
        Route::post('/tasks/{id}/status', [TaskController::class, 'status'])->whereNumber('id')->name('tasks.status');
        Route::post('/tasks/{id}/comment', [TaskController::class, 'comment'])->whereNumber('id')->name('tasks.comment');
        Route::post('/tasks/{id}/verify', [TaskController::class, 'verify'])->whereNumber('id')->name('tasks.verify');
        Route::delete('/tasks/{id}', [TaskController::class, 'delete'])->whereNumber('id')->name('tasks.delete');

        // Sticky Notes
        Route::get('/notes', [NotesController::class, 'index'])->name('notes');
        Route::get('/notes/data', [NotesController::class, 'data'])->name('notes.data');
        Route::post('/notes', [NotesController::class, 'store'])->name('notes.store');
        Route::put('/notes/{id}', [NotesController::class, 'update'])->whereNumber('id')->name('notes.update');
        Route::post('/notes/{id}/action', [NotesController::class, 'action'])->whereNumber('id')->name('notes.action');

        // My Money
        Route::get('/money', [MoneyController::class, 'index'])->name('money');
        Route::get('/money/data', [MoneyController::class, 'data'])->name('money.data');
        Route::post('/money/accounts', [MoneyController::class, 'account'])->name('money.account');
        Route::post('/money/transactions', [MoneyController::class, 'transaction'])->name('money.transaction');
        Route::post('/money/budgets', [MoneyController::class, 'budget'])->name('money.budget');
        Route::post('/money/commitments', [MoneyController::class, 'commitment'])->name('money.commitment');

        // Events
        Route::get('/events', [EventController::class, 'index'])->name('events');
        Route::get('/events/data', [EventController::class, 'data'])->name('events.data');
        Route::get('/events/calendar', [EventController::class, 'calendar'])->name('events.calendar');
        Route::post('/events', [EventController::class, 'store'])->name('events.store');
        Route::get('/events/{id}', [EventController::class, 'show'])->whereNumber('id')->name('events.show');
        Route::put('/events/{id}', [EventController::class, 'update'])->whereNumber('id')->name('events.update');
        Route::delete('/events/{id}', [EventController::class, 'delete'])->whereNumber('id')->name('events.delete');

        // Documents
        Route::get('/documents', [DocumentController::class, 'index'])->name('documents');
        Route::get('/documents/data', [DocumentController::class, 'data'])->name('documents.data');
        Route::post('/documents/upload', [DocumentController::class, 'upload'])->name('documents.upload');
        Route::post('/documents/{id}/version', [DocumentController::class, 'version'])->whereNumber('id')->name('documents.version');
        Route::get('/documents/{id}/versions', [DocumentController::class, 'versions'])->whereNumber('id')->name('documents.versions');
        Route::get('/documents/{id}/url', [DocumentController::class, 'url'])->whereNumber('id')->name('documents.url');
        Route::post('/documents/{id}/pin', [DocumentController::class, 'pin'])->whereNumber('id')->name('documents.pin');
        Route::delete('/documents/{id}', [DocumentController::class, 'delete'])->whereNumber('id')->name('documents.delete');

        // Shared governance
        Route::get('/shares', [ShareController::class, 'data'])->name('shares.data');
        Route::post('/shares', [ShareController::class, 'store'])->name('shares.store');
        Route::post('/shares/{id}/approve', [ShareController::class, 'approve'])->whereNumber('id')->name('shares.approve');
        Route::post('/shares/{id}/revoke', [ShareController::class, 'revoke'])->whereNumber('id')->name('shares.revoke');

        // Reports
        Route::get('/reports', [ReportController::class, 'index'])->name('reports');
        Route::get('/reports/data', [ReportController::class, 'data'])->name('reports.data');
        Route::get('/reports/csv', [ReportController::class, 'csv'])->name('reports.csv');
        Route::get('/reports/xlsx', [ReportController::class, 'xlsx'])->name('reports.xlsx');

        // Admin
        Route::get('/admin', [AdminController::class, 'index'])->name('admin');
        Route::get('/admin/data', [AdminController::class, 'data'])->name('admin.data');
        Route::post('/admin/category', [AdminController::class, 'category'])->name('admin.category');
    });
