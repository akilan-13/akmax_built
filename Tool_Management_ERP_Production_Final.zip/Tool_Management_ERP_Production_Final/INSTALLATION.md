# Installation / Deployment Checklist — Tool Management

## Files to copy

Copy the supplied folders into the existing ERP project while preserving their relative paths:

- `app/Http/Controllers/productivity/*`
- `app/Models/Productivity/*`
- `app/Services/Productivity/*`
- `resources/views/content/productivity/*`
- `resources/assets/js/productivity/productivity-suite.js`
- `resources/assets/css/productivity/productivity-suite.css`
- `public/assets/js/productivity/productivity-suite.js` (fallback/static copy)
- `public/assets/css/productivity/productivity-suite.css` (fallback/static copy)
- `resources/menu/verticalMenu.json`
- `resources/menu/verticalMenu copy.json`
- `routes/tool_management.php`
- `routes/web.php` (integration version)
- `database/sql/2026_09_17_create_egpk_tool_management.sql`

## Database

Run the SQL file against the same MySQL database used by the ERP. The script creates only the `egpk_*` Tool Management tables and does not recreate the ERP core identity/company tables.

Take a database backup before running the SQL in production.

## Menu

The final `verticalMenu.json` adds one top-level item:

`Tool Management`

It is inserted immediately after `Control Panel` and contains the 14 requested tools.

## Routes

The final `routes/web.php` ends by loading:

`require base_path('routes/tool_management.php');`

The dedicated route file contains the `/productivity/*` endpoints and uses the ERP authentication session.

## Frontend

Blade views are server-rendered wrappers plus route/config JSON. They contain no `fetch()`, `$.ajax()`, or XMLHttpRequest calls.

All AJAX is contained in:

`resources/assets/js/productivity/productivity-suite.js`

The script uses jQuery AJAX, CSRF headers, JSON responses, loading/error/empty states, and Bootstrap modal/toast interactions.

## Vite

The module shell loads the productivity CSS and JS through the ERP Vite pipeline. Use the project's normal asset build command before production deployment.

## Google Contacts

For ContactBook Gmail import, set:

- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI`

The callback path used by the module is:

`/productivity/contactbook/google/callback`

The implementation uses user-initiated Google People API read-only contact access.

## PassWallet

Do not enable PassWallet in production until the application's encryption/KMS configuration, session security, CSP, secure cookies, rate limiting, and step-up authentication are reviewed in the real environment.

The module does not return plaintext credentials from list/report endpoints.

## Export dependencies

XLSX features require `phpoffice/phpspreadsheet`, which should already be part of the ERP dependency set before enabling XLSX exports.

## Cache / deployment

After copying files and running SQL, use the ERP's normal deployment sequence. A typical Laravel deployment includes clearing and rebuilding config/route/view caches, then rebuilding Vite assets.

## Scope safety

This drop-in changes the Productivity/Tool Management module, the Tool Management menu entry, and the route integration only. Existing unrelated ERP module logic should not be overwritten.
