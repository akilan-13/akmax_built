# Elysium ERP — Tool Management / Productivity Suite

This package is a drop-in Laravel MVC implementation for the Productivity & Knowledge tools integrated into the existing Elysium ERP.

## Menu integration

`resources/menu/verticalMenu.json` places **Tool Management** immediately after **Control Panel**. It contains 14 tools:

1. Dashboard
2. ContactBook
3. BookMarks
4. PassWallet
5. Knowledge Panel
6. Portals & Apps
7. Meetings
8. Tasks
9. Sticky Notes
10. My Money
11. Events
12. Documents
13. Reports
14. Admin

The menu is intentionally added as a new top-level menu and does not replace existing ERP modules.

## MVC layout

- Controllers: `app/Http/Controllers/productivity/`
- Models: `app/Models/Productivity/`
- Services: `app/Services/Productivity/`
- Routes: `routes/tool_management.php`
- Integrated `routes/web.php` loads the dedicated route file at the end.
- Views: `resources/views/content/productivity/`
- JS: `resources/assets/js/productivity/productivity-suite.js`
- CSS: `resources/assets/css/productivity/productivity-suite.css`
- Optional public fallback copies are also provided under `public/assets/`.
- SQL: `database/sql/2026_09_17_create_egpk_tool_management.sql`

## Frontend/AJAX policy

Blade contains server-rendered HTML, Bootstrap markup, route/config JSON, and the Vite asset include only. AJAX is implemented in the external productivity JavaScript using jQuery `$.ajax` with CSRF headers and JSON responses.

## Install

1. Back up the production database and the existing `routes/web.php` and `resources/menu/verticalMenu.json`.
2. Copy the package's `app/`, `resources/`, `public/`, and `routes/` files into the ERP using the same paths.
3. Execute `database/sql/2026_09_17_create_egpk_tool_management.sql` once against the ERP MySQL database.
4. Make sure the ERP already provides the referenced core tables such as `egc_staff` and `egc_company`.
5. If Gmail import is enabled, configure `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, and `GOOGLE_REDIRECT_URI` in the application environment. The OAuth callback route is `/productivity/contactbook/google/callback`.
6. If XLSX export is required, confirm `phpoffice/phpspreadsheet` is installed.
7. Build frontend assets with the project's normal Vite command.
8. Run `php artisan optimize:clear` and then the normal deployment cache/build steps used by the ERP.

## Security

The module uses the existing ERP session identity and ProductivityAccessService for company and resource scope. Sensitive PassWallet actions require a separate step-up verification session. Secrets are never rendered in lists, reports or ordinary responses.

Review the production environment for TLS, secure cookies, CSP, rate limiting, S3 permissions, queue workers, backups and KMS configuration before enabling PassWallet in production.

## SQL / data

All module tables use the `egpk_` namespace so the new suite remains isolated from existing ERP schemas. Existing ERP identity, company and staff tables are consumed rather than replaced.

## Scope

The package changes only the Tool Management navigation and the dedicated productivity module. Existing ERP modules remain outside the package except for the route-file include and menu addition required to expose the tools.
