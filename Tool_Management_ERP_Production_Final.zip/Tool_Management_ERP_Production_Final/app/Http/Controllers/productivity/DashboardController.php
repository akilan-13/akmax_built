<?php
namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class DashboardController extends ProductivityBaseController
{
    public function index(){ return view('content.productivity.dashboard.index'); }

    public function data(Request $request){
        $c = $this->access->companyScope($request);
        $scope = fn($q) => $c ? $q->whereIn('company_id',$c) : $q;
        $uid=$this->uid();
        $contacts=DB::table('egpk_contacts')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($contacts,$request,'contact');
        $boards=DB::table('egpk_boards')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($boards,$request,'board');
        $vault=DB::table('egpk_vault_entries')->whereNull('deleted_at')->where('status',0); $this->applyReadableScope($vault,$request,'vault');
        $knowledge=DB::table('egpk_knowledge_posts')->whereNull('deleted_at')->where('status','published'); $this->applyReadableScope($knowledge,$request,'knowledge','author_user_id','audience_scope');
        $apps=DB::table('egpk_portal_apps')->whereNull('deleted_at'); $this->applyCompanyScope($apps,$request);
        $bookmarks = DB::table('egpk_bookmarks')->whereNull('deleted_at')->where('status', 0);
        $this->applyCompanyScope($bookmarks, $request, 'egpk_boards.company_id');
        $bookmarks->join('egpk_boards','egpk_boards.sno','=','egpk_bookmarks.board_id')->whereNull('egpk_boards.deleted_at');

        $reports = DB::table('egpk_knowledge_reports as kr')
            ->join('egpk_knowledge_posts as kp','kp.sno','=','kr.post_id')
            ->whereIn('kr.status',['open','pending'])->whereNull('kp.deleted_at');
        $this->applyCompanyScope($reports, $request, 'kp.company_id');

        $attention=[
            'vault_rotation_overdue'=>$vault->clone()->whereNotNull('next_rotation_at')->where('next_rotation_at','<',now())->count(),
            'broken_bookmarks'=>$bookmarks->where('egpk_bookmarks.health_status','broken')->count(),
            'reported_posts'=>$reports->count(),
            'apps_maintenance'=>$apps->clone()->where('status','Under Maintenance')->count(),
        ];
        $series=[]; for($i=11;$i>=0;$i--){$m=now()->subWeeks($i);$series[]= ['label'=>$m->format('d M'),'contacts'=>$scope(DB::table('egpk_contacts'))->where('created_at','>=',$m->copy()->startOfWeek())->where('created_at','<=',$m->copy()->endOfWeek())->count(),'knowledge'=>$scope(DB::table('egpk_knowledge_posts'))->where('created_at','>=',$m->copy()->startOfWeek())->where('created_at','<=',$m->copy()->endOfWeek())->count()];}
        return $this->ok(['kpis'=>['contacts'=>$contacts->count(),'boards'=>$boards->count(),'bookmarks'=>(clone $bookmarks)->count(),'vault_entries'=>$vault->count(),'knowledge_posts'=>$knowledge->count(),'apps'=>$apps->count()], 'attention'=>$attention,'adoption'=>$series,'role'=>$this->access->role()]);
    }
}
