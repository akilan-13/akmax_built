<?php
namespace App\Http\Controllers\productivity;
use App\Models\Productivity\{PortalApp,PortalAppVersion};use Illuminate\Http\Request;use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class PortalAppController extends ProductivityBaseController
{
 public function index(){return view('content.productivity.portals.index');}
 public function data(Request $r){$q=PortalApp::whereNull('deleted_at');$this->applyScope($q,$r);$q->when($r->filled('status'),fn($x)=>$x->where('status',$r->status))->when($r->filled('environment'),fn($x)=>$x->where('environment',$r->environment));if($r->filled('search')){$s=trim($r->search);$q->where(fn($x)=>$x->where('app_name','like',"%$s%")->orWhere('purpose','like',"%$s%"));}return $this->ok(['rows'=>$q->orderByDesc('most_used_score')->paginate(min(max((int)$r->get('per_page',25),10),100))]);}
 public function show($id){$a=PortalApp::findOrFail($id);abort_unless($this->access->canReadResource('portal',$id,$a->created_by,$a->company_id,'Company'),403);return $this->ok(['app'=>$a,'versions'=>PortalAppVersion::where('app_id',$id)->orderByDesc('update_date')->orderByDesc('sno')->get()]);}
 public function store(Request $r){abort_unless($this->access->canWrite(),403);$d=$r->validate(['company_id'=>'nullable|integer','app_name'=>'required|string|max:180','app_url'=>'required|url|max:2000','purpose'=>'nullable|string|max:5000','platform'=>'required|in:Web Portal,Mobile App,Desktop','environment'=>'required|in:Production,Staging','status'=>'required|in:Live,Under Maintenance,Deprecated','technical_owner_user_id'=>'nullable|integer','icon_path'=>'nullable|string|max:1000','passwallet_entry_id'=>'nullable|integer']);$d['created_by']=$d['updated_by']=$this->uid();$d['company_id']=$d['company_id']??$this->cid();$a=PortalApp::create($d);return $this->ok($a,'Portal/App registered successfully.');}
 public function update(Request $r,$id){$a=PortalApp::findOrFail($id);abort_unless($this->access->isCompanyAdmin()||$a->company_id===$this->cid()&&$this->access->canWrite(),403);$d=$r->validate(['company_id'=>'nullable|integer','app_name'=>'required|string|max:180','app_url'=>'required|url|max:2000','purpose'=>'nullable|string|max:5000','platform'=>'required|in:Web Portal,Mobile App,Desktop','environment'=>'required|in:Production,Staging','status'=>'required|in:Live,Under Maintenance,Deprecated','technical_owner_user_id'=>'nullable|integer','icon_path'=>'nullable|string|max:1000','passwallet_entry_id'=>'nullable|integer']);$d['updated_by']=$this->uid();$a->update($d);return $this->ok($a->fresh(),'Portal/App updated.');}
 public function version(Request $r,$id){$a=PortalApp::findOrFail($id);abort_unless($this->access->isCompanyAdmin()||$a->company_id===$this->cid(),403);$d=$r->validate(['version_no'=>'required|string|max:60','update_details'=>'nullable|string|max:10000','bug_fix_details'=>'nullable|string|max:10000','update_date'=>'required|date']);$v=PortalAppVersion::create(['app_id'=>$id,'version_no'=>$d['version_no'],'update_details'=>$d['update_details']??null,'bug_fix_details'=>$d['bug_fix_details']??null,'updated_by'=>$this->uid(),'update_date'=>$d['update_date']]);$a->update(['current_version'=>$v->version_no,'updated_by'=>$this->uid()]);return $this->ok($v,'Version history recorded.');}
 public function launch(Request $r,$id){
  $a=PortalApp::findOrFail($id);
  abort_unless($this->access->canReadResource('portal',$id,$a->created_by,$a->company_id,'Company'),403);
  DB::table('egpk_portal_launches')->insert([
    'app_id'=>$id,
    'user_id'=>$this->uid(),
    'launched_at'=>now(),
    'created_at'=>now(),
  ]);
  $a->increment('most_used_score');
  return response()->json(['status'=>302,'url'=>$a->app_url]);
 }
   
 public function exportXlsx(Request $r)
 {
  abort_unless($this->access->canExport(),403);
  abort_unless(class_exists(Spreadsheet::class) && class_exists(Xlsx::class),503,'XLSX support is not installed. Run composer require phpoffice/phpspreadsheet.');
  $q=PortalApp::whereNull('deleted_at'); $this->applyScope($q,$r);
  $rows=$q->orderBy('app_name')->get();
  $this->audit($r,'Portals & Apps','export','portal',null,null,null,['format'=>'xlsx','row_count'=>$rows->count()]);
  $ss=new Spreadsheet(); $sh=$ss->getActiveSheet();
  $headers=['Application','URL','Platform','Environment','Status','Version','Purpose','Technical Owner','PassWallet Link'];
  $sh->fromArray($headers,null,'A1'); $i=2;
  foreach($rows as $a){ $sh->fromArray([$a->app_name,$a->app_url,$a->platform,$a->environment,$a->status,$a->current_version,$a->purpose,$a->technical_owner_user_id,$a->passwallet_entry_id],null,'A'.$i++); }
  $sh->getStyle('A1:I1')->getFont()->setBold(true); foreach(range('A','I') as $c)$sh->getColumnDimension($c)->setAutoSize(true);
  $writer=new Xlsx($ss);
  return response()->streamDownload(function() use($writer){$writer->save('php://output');},'portal_apps_'.now()->format('Ymd_His').'.xlsx',['Content-Type'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
 }

 public function subscribe(Request $r,$id)
    {
        $a=PortalApp::findOrFail($id); abort_unless($this->access->canReadResource('portal',$id,$a->created_by,$a->company_id,'Company'),403); $exists=DB::table('egpk_portal_subscriptions')->where('app_id',$id)->where('user_id',$this->uid())->exists(); if($exists)DB::table('egpk_portal_subscriptions')->where('app_id',$id)->where('user_id',$this->uid())->delete();else DB::table('egpk_portal_subscriptions')->insert(['app_id'=>$id,'user_id'=>$this->uid(),'created_at'=>now()]); return $this->ok(['subscribed'=>!$exists]);
    }
}
