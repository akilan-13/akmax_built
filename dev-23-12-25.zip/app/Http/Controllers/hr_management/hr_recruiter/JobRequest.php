<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobRequestModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Models\InterviewScheduleModel;
use App\Models\InterviewScheduleStageModel;
use App\Models\InterviewScheduleQuestionModel;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class JobRequest extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
      $perpage = (int) $request->input('sorting_filter', 25);
      $offset = ($page - 1) * $perpage;
      $search_filter = $request->search_filter ?? '';
      $job_role_fill = $request->job_role_fill ?? '';
      $closing_date_filt = $request->closing_date_filt ?? '';
      $exp_type_filt = $request->exp_type_filt ?? '';
      $date_filter = $request->dt_fill_issue_rpt ?? '';
      $from_date_filter = $request->to_dt_iss_rpt ?? '';
      $to_date_filter = $request->to_date_fillter_textbox ?? '';
      $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
      ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
      ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
      ->select('egc_job_request.*','egc_entity.entity_name',
      'egc_entity.entity_short_name',
      'egc_job_role.job_position_name as job_role_name',
      'egc_company.company_name',
      'egc_company.company_base_color',);
      if($search_filter != '') {
          $jobRequest->where(function ($subquery) use ($search_filter) {
              $subquery->where('egc_job_request.job_role_name', 'LIKE', "%{$search_filter}%")
                  ->orWhere('egc_job_request.skill_required', 'LIKE', "%{$search_filter}%");
          });
      }

        if ($job_role_fill) {
          $jobRequest->where('egc_job_request.job_role_name', $job_role_fill);
        }
        if ($closing_date_filt) {
          $jobRequest->where('egc_job_request.closing_date', $closing_date_filt);
        }
        if ($exp_type_filt) {
          $jobRequest->whereJsonContains('egc_job_request.exp_type_ids', $exp_type_filt);
        }

         if ($date_filter == "today") {
            $todayDate = date("Y-m-d");
            $jobRequest->whereDate('egc_job_request.created_at', $todayDate);
          } elseif ($date_filter == "week") {
            $today = date('l');
            if ($today == "Sunday") {
              $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
            } else {
              $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
              $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
            }
            $jobRequest->whereBetween('egc_job_request.created_at', [$weekFromDate, $weekToDate]);
          } elseif ($date_filter == "monthly") {
            $firstDayOfMonth = date('Y-m-01');
            $lastDayOfMonth = date('Y-m-t');
            $jobRequest->whereBetween('egc_job_request.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
          } elseif ($date_filter == "custom_date") {
            if ($from_date_filter && $to_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->whereBetween('egc_job_request.created_at', [$fromDate, $toDate]);
            } elseif ($from_date_filter) {
              $fromDate = date('Y-m-d', strtotime($from_date_filter));
              $jobRequest->where('egc_job_request.created_at', '>=', $fromDate);
            } elseif ($to_date_filter) {
              $toDate = date('Y-m-d', strtotime($to_date_filter));
              $jobRequest->where('egc_job_request.created_at', '<=', $toDate);
            }
          }
        $jobRequest=$jobRequest->orderBy('created_at', 'desc')
                ->paginate($perpage);

      $helper = new \App\Helpers\Helpers();

      if ($request->ajax()) {
          $data = $jobRequest->map(function ($item) use ($helper) {
       
              return [
                  'sno' => $item->sno,
                  'status' => $item->status,
                  'job_role_name' => $item->job_role_name ?? '-',
                  'min_salary' => $item->min_salary,
                  'max_salary' => $item->max_salary,
                  'vacancy_count' => $item->vacancy_count,
                  'experience' => $item->experience,
                  'experience' => $item->experience,
                  'closing_date' => $item->closing_date,
                   'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                  'skill_required' => $item->skill_required,
                  'exp_type_ids' => $item->exp_type_ids,
                  'item' => $item,
                  'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                  'short_encrypt_id' => base64_encode($item->sno),
              ];
          });

          return response()->json([
              'data' => $data,
              'current_page' => $jobRequest->currentPage(),
              'last_page' => $jobRequest->lastPage(),
              'total' => $jobRequest->total(),
          ]);
      }
     
      return view('content.hr_management.hr_recruiter.job_request.job_request', [
          'jobRequest' => $jobRequest,
          'perpage' => $perpage,
          'search_filter' => $search_filter,
      ]);
  }

  public function InterviewSchedule($id, Request $request){
        $decodeId = base64_decode($id);

        $interviewCategoryType = DB::table('egc_interview_category')->where('status', '!=', 2)->get();
        $interviewModeList = DB::table('egc_interview_mode')->where('status', '!=', 2)->get();

        $jobRequest = JobRequestModel::where('egc_job_request.status','!=',2)
        ->join('egc_job_role', 'egc_job_request.job_role_id', 'egc_job_role.sno')
        ->leftJoin('egc_company', 'egc_job_request.company_id', 'egc_company.sno')
        ->leftJoin('egc_entity', 'egc_job_request.entity_id', 'egc_entity.sno')
        ->select('egc_job_request.*','egc_entity.entity_name',
        'egc_entity.entity_short_name',
        'egc_job_role.job_position_name as job_role_name',
        'egc_company.company_name',
        'egc_entity.entity_base_color',
        'egc_company.company_base_color',)->where('egc_job_request.sno', $decodeId)->first();

        return view('content.hr_management.hr_recruiter.job_request.interview_schedule', [
          'interviewCategoryType' => $interviewCategoryType,
          'interviewModeList' => $interviewModeList,
          'jobRequest' => $jobRequest,
          'encoded' => $id,
          
      ]);
  }

 public function createInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id;
    $request->validate([
        'job_request_id' => 'required|integer',
        'entity_id'   => 'required|integer',
        'interview_stages' => 'required|array|min:1'
    ]);

    DB::beginTransaction();

    try {
        $schedule = InterviewScheduleModel::create([
            'job_request_id' => $request->job_request_id,
            'entity_id' => is_array($request->entity_id)
                          ? ($request->entity_id[0] ?? null)
                          : $request->entity_id,
            'status'      => 0,
            'created_at'  => now(),
            'created_by'  => $userId ?? 0
        ]);

        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id'  => $stage['interview_category_id'],
                'stage_order'            => $order + 1,
                'duration_value'         => $stage['config']['duration_value'],
                'duration_unit'          => $stage['config']['duration_unit'],
                'mode'                   => $stage['config']['mode'],
                'call_confirmation'      => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'       => $stage['config']['immediate_notify'] ?? 0,
                'status'                 => 0,
                'created_at'             => now(),
                'created_by'             => $userId ?? 0
            ]);

            foreach ($stage['questions'] as $qid) {
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $qid,
                    'thinking_time'                => 0,
                    'allowed_time'                 => 0,
                    'retakes'                      => 0,
                    'status'                       => 0,
                    'created_at'                   => now(),
                    'created_by'                   => $userId ?? 0
                ]);
            }
        }

        $shareCode = base64_encode($schedule->sno . '|' . time());

        $schedule->update([
            'share_code' => $shareCode,
            'updated_at' => now(),
            'updated_by' => $userId ?? 0
        ]);

        DB::commit();

        return response()->json([
            'status'     => true,
            'share_code' => $shareCode
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to create interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function editInterviewSchedule($encoded)
  {
      [$scheduleSno] = explode('|', base64_decode($encoded));

      $schedule = InterviewScheduleModel::where('sno', $scheduleSno)
          ->where('status', 0)
          ->firstOrFail();

      $stages = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
          ->where('status', 0)
          ->orderBy('stage_order')
          ->get();

      $questions = InterviewScheduleQuestionModel::whereIn(
          'interview_schedule_stage_id',
          $stages->pluck('sno')
      )->where('status', 0)->get();

      return view('content.hr_management.hr_recruiter.job_request.interview_schedule_edit', [
          'schedule' => $schedule,
          'stages'   => $stages,
          'questions'=> $questions,
          'encoded'  => $encoded
      ]);
  }


  public function updateInterviewSchedule(Request $request)
{
    $userId = auth()->user()->user_id ?? 0;

    $request->validate([
        'schedule_id'    => 'required|integer',
        'job_request_id'     => 'required|integer',
        'entity_id'       => 'required|integer',
        'interview_stages'=> 'required|array|min:1'
    ]);

    DB::beginTransaction();

    try {
        $schedule = InterviewScheduleModel::where('sno', $request->schedule_id)
            ->where('status', 0)
            ->firstOrFail();

        // 🔹 Update main schedule
        $schedule->update([
            'job_request_id' => $request->job_request_id,
            'entity_id'   => $request->entity_id,
            'updated_at'  => now(),
            'updated_by'  => $userId
        ]);

        // 🔥 DELETE OLD DATA (SAFE)
        $oldStageIds = InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)
            ->pluck('sno');

        InterviewScheduleQuestionModel::whereIn(
            'interview_schedule_stage_id',
            $oldStageIds
        )->update(['status' => 2 ]);

        InterviewScheduleStageModel::where('interview_schedule_id', $schedule->sno)->update(['status' => 2 ]);

        // 🔁 REINSERT UPDATED DATA
        foreach ($request->interview_stages as $order => $stage) {

            $stageModel = InterviewScheduleStageModel::create([
                'interview_schedule_id' => $schedule->sno,
                'interview_category_id' => $stage['interview_category_id'],
                'stage_order'           => $order + 1,
                'duration_value'        => $stage['config']['duration_value'],
                'duration_unit'         => $stage['config']['duration_unit'],
                'mode'                  => $stage['config']['mode'],
                'call_confirmation'     => $stage['config']['call_confirmation'] ?? 0,
                'immediate_notify'      => $stage['config']['immediate_notify'] ?? 0,
                'status'                => 0,
                'created_at'            => now(),
                'created_by'            => $userId
            ]);

            foreach ($stage['questions'] as $qid) {
                InterviewScheduleQuestionModel::create([
                    'interview_schedule_stage_id' => $stageModel->sno,
                    'interview_question_id'       => $qid,
                    'status'                      => 0,
                    'created_at'                  => now(),
                    'created_by'                  => $userId
                ]);
            }
        }

        DB::commit();

        return response()->json([
            'status'  => true,
            'message' => 'Interview schedule updated successfully'
        ]);

    } catch (\Throwable $e) {
        DB::rollBack();

        return response()->json([
            'status'  => false,
            'message' => 'Failed to update interview schedule',
            'error'   => $e->getMessage()
        ], 500);
    }
}

  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  JobRequestModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  
    // dispatch webhook
  protected function dispatchWebhooks($broadcast, $userId = 1,$dispatchHook)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module',$dispatchHook)->where('entity_id',1)->first();
        if($webhook){
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => 'App\Models\JobRequestModel',
              'dispatchable_id' => $broadcast['sno'],
              'message_uuid' =>$broadcast['sno'],
              'payload' => json_encode($broadcast),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);
          // enqueue the job
             $result = $this->sendWebhookNow($dispatch, $webhook);
            // try {
            //   $result = $this->sendWebhookNow($dispatch, $webhook);
            //     \Log::info("send result : " . json_encode($result));

            //     if (!$result['success']) {
            //         // If fails, dispatch to queue
            //         SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     }
            // } catch (\Throwable $e) {
            //     // On any exception, fallback to queue
            //     SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            //     \Log::error("Webhook fallback to queue: " . $e->getMessage());
            // }
        }
          
  }


  protected function sendWebhookNow($dispatch, $hook)
  {
      $payload = $dispatch->payload ?? [];
      $bodyString = json_encode($payload);

      $dispatch->increment('attempts');
      $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

      $timestamp = now()->getTimestamp();
      $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

      $headers = array_merge(
          is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
          [
              'X-WEBHOOK-TIMESTAMP' => $timestamp,
              'X-WEBHOOK-SIGNATURE' => $signature,
              'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
              'Accept' => 'application/json',
          ]
      );

      try {
          $response = Http::withHeaders($headers)
              ->timeout(15)
              ->post($hook->url, $payload);

          WebhookDispatchAttemptModel::create([
              'webhook_dispatch_sno' => $dispatch->sno,
              'http_status' => $response->status(),
              'request_headers' => json_encode($headers),
              'request_body' => $bodyString,
              'response_body' => $response->body(),
          ]);

          if ($response->successful()) {
              $dispatch->update([
                  'status' => 2,
                  'http_status' => $response->status(),
                  'last_response' => $response->body(),
                  'next_attempt_at' => null
              ]);
              
              return ['success' => true];
          } else {
              $dispatch->update([
                  'status' => 3,
                  'last_response' => 'Webhook failed. Will retry automatically.'
              ]);
              
              return ['success' => false];
          }
      } catch (\Throwable $e) {
          \Log::error("Immediate webhook send failed: " . $e->getMessage());
          $dispatch->update([
              'status' => 3,
              'last_response' => 'Webhook failed. Will retry automatically.'
          ]);
          return ['success' => false];
      }
  }

  public function interviewQuestionsByRole(Request $request)
  {
      $job_role_id = $request->input('job_role_id');
      $interview_category_id = $request->input('interview_category_id');

      $questions = DB::table('egc_interview_question')
          ->where('job_role_id', $job_role_id)
          ->where('interview_category_id', $interview_category_id)
          ->where('status', 0)
          ->get();

      return response()->json([
          'status' => 200,
          'message' => null,
          'error_msg' => null,
          'data' => $questions
      ], 200);
  }
      
}
