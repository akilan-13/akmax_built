<?php

namespace App\Http\Controllers\settings\interview;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InteviewModeModel;
use Illuminate\Support\Facades\Validator;

class InterviewMode extends Controller
{
    public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $Document = InteviewModeModel::where( 'status', '!=', 2 );
        if ($search_filter != '') {
            $Document->where(function ($subquery) use ($search_filter) {
                $subquery->where('interview_mode_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('interview_mode_desc', 'LIKE', "%{$search_filter}%");
                    
            });
        }
        $Document=$Document->orderBy( 'sno', 'desc' )->paginate($perpage);

        if ($request->ajax()) {
            $data = $Document->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'interview_mode_name' => $item->interview_mode_name,
                    'mode_icon' => $item->mode_icon,
                    'interview_mode_desc' => $item->interview_mode_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Document->currentPage(),
                'last_page' => $Document->lastPage(),
                'total' => $Document->total(),
            ]);
        }

        return view('content.settings.interview.interview_mode.interview_mode_list',[
            'Document' => $Document,
            'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function List() {
        $Branchtype = InteviewModeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->get();

        return  response( [
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $Branchtype
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'interview_mode_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return  response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {

            $interview_mode_name       = $request->interview_mode_name;
            $mode_icon       = $request->mode_icon;
            $interview_mode_desc          = $request->interview_mode_desc;
            $user_id                    = 1;
            $chk = InteviewModeModel::where( 'interview_mode_name', $interview_mode_name )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Interview Mode is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = InteviewModeModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                

                $add_branchtype = new InteviewModeModel();
                $add_branchtype->interview_mode_name       = $interview_mode_name;
                $add_branchtype->mode_icon       = $mode_icon;
                $add_branchtype->interview_mode_desc       = $interview_mode_desc;
                $add_branchtype->created_by                 = $user_id;
                $add_branchtype->updated_by                 = $user_id;

                $add_branchtype->save();

                if ( $add_branchtype ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Interview Mode added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Interview Mode!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }


    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'interview_mode_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return   response( [
                'status'    => 401,
                'message'   => 'Incorrect format input feilds',
                'error_msg'     => $validator->messages()->get( '*' ),
                'data'      => null,
            ], 200 );
        } else {


            $interview_mode_name       = $request->interview_mode_name;
            $mode_icon       = $request->mode_icon;
            $interview_mode_desc       = $request->interview_mode_desc;
            $document_id       = $request->edit_id;

            $upd_InteviewModeModel =  InteviewModeModel::where( 'sno', $document_id )->first();

            $chk = InteviewModeModel::where( 'interview_mode_name', $interview_mode_name )->where( 'sno', '!=', $document_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already  Interview Mode is exist!'
                ] );
                return redirect()->back();
            }

            $upd_InteviewModeModel->interview_mode_name  = $interview_mode_name;
            $upd_InteviewModeModel->mode_icon  = $mode_icon;
            $upd_InteviewModeModel->interview_mode_desc  = $interview_mode_desc;
            $upd_InteviewModeModel->update();

            if ( $upd_InteviewModeModel ) {
                // If category added successfully, return success response and display Toastr message
                session()->flash( 'toastr', [
                    'type' => 'success',
                    'message' => 'Interview Mode Update Successfully!'
                ] );
            } else {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Could not Update the Interview Mode!'
                ] );
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_InteviewModeModel = InteviewModeModel::where( 'sno', $id )->first();
        $upd_InteviewModeModel->status  = 2;
        $upd_InteviewModeModel->Update();

        return response( [
            'status'    => 200,
            'message'   => 'Interview Mode Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_InteviewModeModel =  InteviewModeModel::where( 'sno', $id )->first();
        $upd_InteviewModeModel->status = $request->input( 'status', 0 );
        $upd_InteviewModeModel->update();

        return response( [
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200 );
    }
}
