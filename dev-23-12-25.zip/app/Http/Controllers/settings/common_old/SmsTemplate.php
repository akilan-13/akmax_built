<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SmsTemplateModel;
use Illuminate\Support\Facades\Validator;

class SmsTemplate extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    return view('content.settings.common.sms_template.sms_template_list');
  }

  public function List()
  {
    $sms_template = SmsTemplateModel::where('status', 0)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'template_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $authkey                     = $request->auth_key_add;
      $sender_id                   = $request->sender_id_add;
      $template_id                 = $request->template_id_add;
      $country_code                = $request->country_code_add;
      $template_name               = $request->template_name;
      $sms_template_messagecontent = $request->sms_template_messagecontent;


      $user_id                    = $request->user()->user_id;
      $chk = SmsTemplateModel::where('template_name', ucwords($template_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
      } else {
        $category_check = SmsTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $sms_template_id = 'ST-0001/' . $year;
        } else {

          $data = $category_check->sms_template_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf('ST-%04d', $next_number);

          $year = substr(date('y'), -2);
          $sms_template_id = $request . '/' . $year;
        }

        $add_category = new SmsTemplateModel();
        $add_category->sms_template_id  = $sms_template_id;
        $add_category->template_name = Ucfirst($template_name);
        $add_category->sms_template_messagecontent = $sms_template_messagecontent;
        $add_category->authkey = $authkey;
        $add_category->sender_id = $sender_id;
        $add_category->template_id = $template_id;
        $add_category->country_code = $country_code;
        $add_category->branch_id = self::$branch_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'sms template added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the sms template!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'template Created successfully!');
    }
  }

  public function Edit($id)
  {
    $editcategory = SmsTemplateModel::where('sno', $id)->first();

    return view('content.settings.common_setting.sms_template', [
      'editcategory' => $editcategory,
      'id' => $id,
    ]);
  }

  public function Update(Request $request)
  {
// return $request;
    $validator = Validator::make($request->all(), [
      'template_name_edit' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $authkey                     = $request->auth_key_edit;
      $sender_id                   = $request->sender_id_edit;
      $template_id                 = $request->template_id_edit;
      $country_code                = $request->country_code_edit;
      $template_name               = $request->template_name_edit;
      $sms_template_messagecontent = $request->sms_template_messagecontent_edit;

      $upd_CourseCategoryModel =  SmsTemplateModel::where('sno', $id)->first();

      $chk = SmsTemplateModel::where('template_name', ucwords($template_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'sms template has been  already assigned!'
        ]);
        return redirect()->back();
      } else {

        $upd_CourseCategoryModel->template_name  = Ucfirst($template_name);
        $upd_CourseCategoryModel->authkey  = $authkey;
        $upd_CourseCategoryModel->sender_id  = $sender_id;
        $upd_CourseCategoryModel->template_id  = $template_id;
        $upd_CourseCategoryModel->country_code  = $country_code;
        $upd_CourseCategoryModel->sms_template_messagecontent  = $sms_template_messagecontent;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'sms template updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the sms template !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  SmsTemplateModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  SmsTemplateModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
