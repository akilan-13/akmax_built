<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;


class State extends Controller
{
  protected static $branch_id = 1;
  public function index()
{
    return view('content.settings.common.state.state_list');
}

  public function List()
  {
    // Retrieve the category ID from the POST request
    $cat_id = $_GET['id'] ?? '';

    $State = StateModel::where('status', 0)
      ->where('country_id', $cat_id)
      ->orderBy('id', 'desc')
      ->paginate(10);
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $State
    ], 200);
  }

  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'state_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      
      $state_name       = $request->state_name;
      // $marketing_subcategory_descr        = $request->marketing_subcategory_descr;
      $country_id           = $request->country_id;
      // $user_id                    = $request->user()->user_id;
      $chk = StateModel::where('name', ucwords($state_name))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        $category_check = StateModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();


        // if (!$category_check) {

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = "CS-0001/" . $year;
        // } else {

        //   $data = $category_check->job_subcategory_id;
        //   $slice = explode("/", $data);
        //   $result = preg_replace('/[^0-9]/', '', $slice[0]);

        //   $next_number = (int)$result + 1;
        //   $request = sprintf("CS-%04d", $next_number);

        //   $year = substr(date("y"), -2);
        //   $job_subcategory_id = $request . '/' . $year;
        // }


        $add_category = new StateModel();
        $add_category->country_id         = $country_id;
        // $add_category->job_subcategory_id         = $job_subcategory_id;
        $add_category->name       = Ucfirst($state_name);
        // $add_category->markeing_subcategory_descr       = $marketing_subcategory_descr;
        // $add_category->branch_id                 = self::$branch_id;
        // $add_category->created_by                 = $user_id;
        // $add_category->updated_by                 = $user_id;

        $add_category->save();

        if ($add_category) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'state added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the state!'
          ]);
        }
      }
      return redirect()->back();
    }
  }


  public function edit($id)
  {
    $editCategory = StateModel::select(
      'eibs_states.*',
      'eibs_countries.name as country_name',
      'eibs_countries.id as country_id'
    )
      ->join('eibs_countries', 'eibs_states.country_id', '=', 'eibs_countries.id')
      ->where('eibs_states.id', $id)
      ->first();

    return response()->json([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $editCategory
    ], 200);
  }

  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'state_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $marketing_category_id            = $request->marketing_category_id_edit;
      $marketing_subcategory_name       = $request->marketing_subcategory_name;
      $marketing_subcategory_descr       = $request->marketing_subcategory_descr;
      $marketing_category_idd         = $request->marketing_category_id;
      $marketing_subcategory_id         = $request->marketing_subcategory_id;

      $upd_CategoryModel =  StateModel::where('sno', $marketing_subcategory_id)->first();
      // return $upd_JobCategoryModel;

      $chk = StateModel::where('marketing_subcategory_name', ucwords($marketing_subcategory_name))->where('status', '!=', 2)->where('sno', '!=', $marketing_subcategory_id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'status'    => 401,
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
      } else {
        // return $job_category_id;
        $upd_CategoryModel->marketing_category_id    = $marketing_category_id;
        $upd_CategoryModel->marketing_subcategory_name  = Ucfirst($marketing_subcategory_name);
        $upd_CategoryModel->markeing_subcategory_descr  = $marketing_subcategory_descr;
        $upd_CategoryModel->update();
      }
      if ($upd_CategoryModel) {
        // If category added successfully, return success response and display Toastr message
        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'state Successfully Upadted!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not Update the state!'
        ]);
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CategoryModel =  StateModel::where('id', $id)->first();
    $upd_CategoryModel->status  = 2;
    $upd_CategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CategoryModel =  StateModel::where('id', $id)->first();
    $upd_CategoryModel->status = $request->input('status', 0);
    $upd_CategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}