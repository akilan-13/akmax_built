<?php

namespace App\Http\Controllers\control_panel\entity_hub;

use App\Http\Controllers\Controller;
use App\Models\BranchModel;
use App\Models\CourseAssigne_model;
use App\Models\CugManagementModel;
use App\Models\FranchiseDocumentModel;
use App\Models\SocialMediaModel;
use App\Models\JobRoleModel;
use App\Models\StaffModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ManageBranch extends Controller
{
 
  public function addPage(Request $request)
  {
      $company_id =$request->company_id ?  base64_decode($request->company_id) : '';
      $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.control_panel.entity_hub.manage_branch.add',[
        'social_media_list'=>$social_media_list,
        'company_id'=>$company_id,
        ]);
  }
  public function editUI()
  {
    return view('content.control_panel.entity_hub.manage_branch.edit');
  }

  
  public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;

    $country_fill = $request->country_fill ?? '';
    $state_fill = $request->state_fill ?? '';
    $city_fill = $request->city_fill ?? '';
    $branch_type_fill = $request->branch_type_fill ?? '';
    // $branch_cate_fill = $request->branch_cate_fill ?? '';
    $date_filter = $request->dt_fill_issue_rpt ?? '';
    $from_date_filter = $request->from_date_fillter_textbox ?? '';
    $to_date_filter = $request->to_date_fillter_textbox ?? '';
    $search_filter = $request->search_filter ?? '';

     $query = BranchModel::where('egc_branch.status', '!=', 2)->select('egc_branch.*','egc_company.company_base_color', 'egc_countries.name', 'egc_states.name as statename', 'egc_cities.name as citiesname', 'egc_staff.staff_name as centerHead_name', 'egc_staff.mobile_no as centerHead_mobile', 'egc_staff.email_id as centerHead_email', 'egc_company.company_name', 'egc_entity.entity_name')
      ->join('egc_entity', 'egc_entity.sno', '=', 'egc_branch.entity_id')
      ->join('egc_company', 'egc_company.sno', '=', 'egc_branch.company_id')
       ->leftJoin('egc_countries', 'egc_branch.country_id', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_branch.state_id', 'egc_states.id')
        ->leftJoin('egc_cities', 'egc_branch.city_id', 'egc_cities.id')
      ->leftJoin('egc_staff', 'egc_staff.sno', '=', 'egc_branch.authority_id');

    if ($date_filter == "today") {
      $todayDate = date("Y-m-d");
      $query->whereDate('egc_branch.created_at', $todayDate);
    } elseif ($date_filter == "week") {
      $today = date('l');
      if ($today == "Sunday") {
        $weekFromDate = date('Y-m-d', strtotime("sunday 0 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 1 week"));
      } else {
        $weekFromDate = date('Y-m-d', strtotime("sunday -1 week"));
        $weekToDate = date('Y-m-d', strtotime("saturday 0 week"));
      }
      $query->whereBetween('egc_branch.created_at', [$weekFromDate, $weekToDate]);
    } elseif ($date_filter == "monthly") {
      $firstDayOfMonth = date('Y-m-01');
      $lastDayOfMonth = date('Y-m-t');
      $query->whereBetween('egc_branch.created_at', [$firstDayOfMonth, $lastDayOfMonth]);
    } elseif ($date_filter == "custom_date") {
      if ($from_date_filter && $to_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->whereBetween('egc_branch.created_at', [$fromDate, $toDate]);
      } elseif ($from_date_filter) {
        $fromDate = date('Y-m-d', strtotime($from_date_filter));
        $query->where('egc_branch.created_at', '>=', $fromDate);
      } elseif ($to_date_filter) {
        $toDate = date('Y-m-d', strtotime($to_date_filter));
        $query->where('egc_branch.created_at', '<=', $toDate);
      }
    }

    if ($country_fill) {
      $query->where('egc_branch.country_id', $country_fill);
    }
    if ($state_fill) {
      $query->where('egc_branch.state_id', $state_fill);
    }
    if ($city_fill) {
      $query->where('egc_branch.city_id', $city_fill);
    }
    if ($branch_type_fill) {
      $query->where('egc_branch.branch_type', $branch_type_fill);
    }

    if ($search_filter != '') {
      $query->where(function ($subquery) use ($search_filter) {
        $subquery->where('egc_branch.branch_name', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
          ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%");
      });
    }

    // Fetch Branch list ordered by sno in descending order
    $Branch_list = $query->orderBy('egc_branch.sno', 'desc')->paginate($perpage);
    
     $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Branch_list->map(function ($item) use ($helper) {
            $branch_address = $item->door_no . ' ' . $item->area_street . ', ' . $item->citiesname . ', ' . $item->statename . ' - ' . $item->pincode;
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'company_name' => $item->company_name,
                'entity_name' => $item->entity_name,
                'branch_name' => $item->branch_name,
                'mail' => $item->mail,
                'branch_address' => $branch_address,
                'mobile' => $item->mobile,
                'data' => $item,
                'centerHead_email' => $item->centerHead_email,
                'centerHead_mobile' => $item->centerHead_mobile,
                'centerHead_name' => $item->centerHead_name,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $Branch_list->currentPage(),
            'last_page' => $Branch_list->lastPage(),
            'total' => $Branch_list->total(),
        ]);
    }

    // $Branch_list = BranchModel::where('egc_branch.status', '!=', 2)->orderBy('egc_branch.sno', 'desc')->paginate($perpage);
    // return $Branch_list;
    return view('content.control_panel.entity_hub.manage_branch.branch', [
      'Branch_list' => $Branch_list,
      'country_fill' => $country_fill,
      'state_fill' => $state_fill,
      'city_fill' => $city_fill,
      'perpage' => $perpage,
      'branch_type_fill' => $branch_type_fill,
      // 'branch_cate_fill' => $branch_cate_fill,
      'date_filter' => $date_filter,
      'search_filter' => $search_filter,
    ]);
  }


  public function list(Request $request)
  {
    $branch_id = $request->user()->branch_id;
    $branch_data = BranchModel::where('status', 0)->orderBy('sno', 'desc')->get();
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $branch_data,
    ], 200);
  }

  public function Entity_branch_dropdown_list(Request $request)
  {
    $entity_id = $request->entity_id;
    $branch_data = BranchModel::where('status', 0)->where('entity_id', $entity_id)->orderBy('sno', 'desc')->get();
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $branch_data,
    ], 200);
  }


  public function Status($id, Request $request)
  {

    $staff =  BranchModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Branch / Franchise  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Branch / Franchise  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Branch / Franchise  Status!',
        'error_msg' => 'Could not, update  Branch / Franchise  Status!',
        'data'      => null,
      ], 200);
    }
  }

  public function Delete($id)
  {
    // Fetch the branch by ID
    $upd_StaffModel = BranchModel::where('sno', $id)->first();

    // If branch not found, return error
    if (!$upd_StaffModel) {
      return response([
        'status'    => 404,
        'message'   => 'Branch not found.',
        'error_msg' => 'Invalid ID',
        'data'      => null,
      ], 404);
    }

    $branchType = $upd_StaffModel->branch_type;

    $upd_StaffModel->status = 2;
    $upd_StaffModel->update();

    $message = $branchType == 1 ? 'Branch Deleted Successfully..!' : ($branchType == 2 ? 'Franchise Deleted Successfully..!' : 'Deleted Successfully..!'); // fallback for unexpected types

    return response([
      'status'    => 200,
      'message'   => $message,
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


  public function View($id)
  {
    $data = BranchModel::select(
      'egc_branch.*',
      'egc_countries.name as country_name',
      'egc_states.name as statename',
      'egc_cities.name as citiesname',
      'egc_company.company_name',
      'egc_entity.entity_name',
      'timezone_country.name as time_zone_country',
      'egc_countrytimezones.time_zone',
      'egc_countrytimezones.utc_offset',
      'egc_country_currencies.currency_code',
      'egc_country_currencies.currency_symbol'
    )
      ->leftJoin('egc_countries', 'egc_branch.country_id', '=', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_branch.state_id', '=', 'egc_states.id')
      ->leftJoin('egc_cities', 'egc_branch.city_id', '=', 'egc_cities.id')
      ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_branch.company_id')
      ->leftJoin('egc_entity', 'egc_entity.sno', '=', 'egc_branch.entity_id')
      ->leftJoin('egc_countrytimezones', 'egc_branch.time_zone_id', '=', 'egc_countrytimezones.sno')
      ->leftJoin('egc_countries as timezone_country', 'egc_countrytimezones.country_id', '=', 'timezone_country.id')
      ->leftJoin('egc_country_currencies', 'egc_branch.currency_id', '=', 'egc_country_currencies.sno')
      ->where('egc_branch.sno', $id)
      ->orderBy('egc_branch.sno', 'desc')
      ->first();

    $centerHead = DB::table('egc_staff')->where('sno', $data->authority_id)->first();
    $data->center_head_name = $centerHead ? $centerHead->staff_name : '';
    $data->center_head_mobile = $centerHead ? $centerHead->mobile_no : '';
    $data->center_head_image = $centerHead ? $centerHead->staff_image : '';


    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Branch not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Branch fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

 
  public function Add(Request $request)
  {
    // return $request;
    // Validate input data
    $validator = Validator::make($request->all(), [
      'branch_name' => 'required|max:255',
      'branch_category' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }
    $old_chk = BranchModel::where('status', 0)
      ->where('city_short_code', 'like', $request->input('city_short_code', '') . '%')
      ->orderBy('sno', 'desc')
      ->first();

    if ($old_chk) {
      $last_code_number = intval(substr($old_chk->city_short_code, -2));
      $city_short_code = $request->input('city_short_code', '') . str_pad($last_code_number + 1, 2, '0', STR_PAD_LEFT);
    } else {
      $city_short_code = $request->input('city_short_code', '') . '01';
    }
    
      $socialMediaData = request()->input('social_media');
         $socialMediaData = array_filter($socialMediaData, function($value) {
            return !is_null($value) && $value !== '';
        });

    // Determine branch type and set relevant fields
    $branch = new BranchModel();
    $user_id = 1;
    $branch->branch_type = 1;
    if ($request->input('branch_franc') == 2) {
      $branch->branch_name = '';
      $branch->business_name = $request->input('business_name', '');
      $branch->franchise_name = $request->input('franchise_name', '');
      $type_name = 'Franchise';
    } else {
      // Default values if not a franchise
      $branch->branch_name = $request->input('branch_name', '');
      $type_name = 'Branch';
      $branch->business_name = '';
      $branch->franchise_name = '';
    }

    // Generate branch ID
    $branch_check = BranchModel::where('status', ' != ', 2)->orderBy('sno', 'desc')->first();
    $sno = $branch_check ? $branch_check->sno + 1 : 1;
    $year = date('y');
    $branch_code = sprintf('BR-%04d/%s', $sno, $year);
    $branch->branch_id = $branch_code;
    $branch->business_person_name = $request->input('business_person_name', '');
    // Set other fields
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->time_zone_id = $request->input('time_zone', '');
    $branch->currency_id = $request->input('currency_format', '');
    $branch->gst_check = $request->input('gst_check', 0);
    $branch->gst_percentage = $request->input('gst_percentage', 0);
    $branch->call_tracker_branch_id = $request->input('call_tracker_id', 0);
    $branch->entity_id = $request->input('entity_id', 0);
    $branch->company_id = $request->input('company_id', 0);

    $branch->bus_closing_day_count    = $request->input('bus_closing_day_count', 0) ?? 0;
    $branch->bus_closing_month_end = $request->input('bus_closing_chk_month', 0) ?? 0;
    $branch->task_working_hours = $request->task_working_hours ?? 7;
    $branch->task_working_hours = $request->task_working_hours ?? 7;
    $branch->social_media_details = json_encode($socialMediaData);

    $branch->gst_no = $request->input('gst_no', '');
    $branch->pan_no = $request->input('pan_no', '');
    $branch->tax_no = $request->input('tax_no', '');
    $branch->fb_link = $request->input('fb_link', '');
    $branch->insta_link = $request->input('insta_link', '');
    $branch->just_dial_id = $request->input('just_dial_id', '');
    $branch->cloud_call_api_key = $request->input('cloud_call_api_key', '');
    $branch->other_src_staff_id = $request->input('other_src_staff_id') ?? 0;

    $branch->share_percentage = $request->input('share_percentage');
    $branch->share_start_date = date('Y-m-d', strtotime($request->input('share_start_date')));
    $branch->share_end_date = date('Y-m-d', strtotime($request->input('share_end_date')));
    // $branch->cre_mobile = $request->input('cre_mobile_no', '');
    // $branch->sales_mobile = $request->input('sales_mobile_no', '');
    $branch->comm_email_id = $request->input('comm_email_id', '');
    $branch->min_amnt_receive = $request->input('min_amnt_receive', '');
    $branch->collection_close = date('Y-m-d', strtotime($request->input('collection_close')));
    $branch->registeration_close = date('Y-m-d', strtotime($request->input('registeration_close')));
    $branch->branch_category = $request->input('branch_category', '');
    $branch->branch_department = json_encode($request->input('branch_dept'));
    $branch->country_id = $request->input('country', '');
    $branch->state_id = $request->input('state', '');
    $branch->city_id = $request->input('city', '');
    $branch->area_street = $request->input('area_street', '');
    $branch->door_no = $request->input('door_flat_no', '');
    $branch->pincode = $request->input('pincode', '');
    $branch->city_short_code = $city_short_code;
    $branch->mobile = $request->input('business_mobile_no', '');
    $branch->mail = $request->input('business_email_id', '');
    $branch->location = $request->input('location_url', '');
    $branch->website = $request->input('website_url', '');
    $branch->latitude = $request->input('latitude', '');
    $branch->longitude = $request->input('longitude', '');
    $branch->bank_name = $request->input('bank_name', '');
    $branch->bank_branch = $request->input('bank_branch', '');
    $branch->bank_holder = $request->input('bank_holder', '');
    $branch->bank_account_no = $request->input('bank_account_no', '');
    $branch->bank_ifsc = $request->input('bank_ifsc', '');
    $branch->bank_desc = $request->input('bank_desc', '');
    $branch->branch_desc = $request->input('branch_desc', '');
    $branch->cert_auth_name = $request->input('cert_auth_name');
    $branch->branch_head_name = $request->input('branch_head_name');
    $branch->min_prd_cost = $request->min_product_cost;
    $branch->min_prd_days = $request->mpc_validity;
    $branch->last_payment = $request->last_payment;

    //  $branch->bank_swift_code = $request->swift_code;
    // $branch->bank_upi_id = $request->upi_id;


    $branch->created_by = $request->user()->user_id ?? 1;
    $branch->updated_by = $request->user()->user_id ?? 1;


    // Save the branch to the database
    $branch->save();
    // Flash message based on save result
    if ($branch->sno) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => $type_name . ' added Successfully!'
      ]);
      // session()->flash('toastr', [
      //   'type' => 'info',
      //   'message' => 'Create Branch Head..!'
      // ]);
      session(['branch_type_ses' => $branch->branch_type]);
      session(['branch_id_ses' => $branch->sno]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the ' . $type_name,
      ]);
    }
    // return $branch;
    return redirect('entity_hub/manage_branch');
  }

  public function Edit($id = '')
  {

    $helper = new \App\Helpers\Helpers();
    $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');

    // return $decryptedValue;
    // Check if decryption failed
    if ($decryptedValue === false) {
      return redirect()->back()->with('error', 'Invalid Entry');
    }
    $id = $decryptedValue;
    $edit = BranchModel::where('sno', $decryptedValue)->first();
    $frattachment_data = FranchiseDocumentModel::where('franchise_id', $decryptedValue)
      ->where('status', ' != ', 2)
      ->get();
    return view('content.control_panel.entity_hub.manage_branch.edit', [
      'edit' => $edit,
      'fra_attach_data' => $frattachment_data,
      'id' => $decryptedValue,
    ]);
    // return view( 'content.settings.branch.branch.edit' );
  }
  public function update(Request $request)
  {
    //
    //   return $request;
    // Validate input data
    $validator = Validator::make($request->all(), [
      'branch_franc' => 'required|numeric', // Assuming branch_franc is numeric
      'branch_category' => 'required',
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    // Retrieve branch by sno ( assuming sno is the primary key )
    $edit_sno = $request->input('edit_sno');
    $branch = BranchModel::find($edit_sno);
    if (!$branch) {
      return response()->json([
        'status' => 404,
        'message' => 'Branch not found',
        'data' => null,
      ], 404);
    }

    // Update branch fields based on branch_franc value
    $branch->branch_type = $request->input('branch_franc');
    if ($request->input('branch_franc') == 2) {
      $branch->branch_name = '';
      $branch->business_name = $request->input('business_name', '');
      $branch->franchise_name = $request->input('franchise_name', '');
      $type_name = 'Franchise';
    } else {
      // Default values if not a franchise
      $branch->branch_name = $request->input('branch_name', '');
      $type_name = 'Branch';
      $branch->business_name = '';
      $branch->franchise_name = '';
    }

    // Set common fields
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->time_zone_id = $request->input('time_zone', '');
    $branch->currency_id = $request->input('currency_format', '');
    $branch->gst_check = $request->input('gst_check', 0);
    $branch->business_person_name = $request->input('business_person_name', '');
    $branch->gst_percentage = $request->input('gst_percentage', 0);
    $branch->task_working_hours = $request->task_working_hours ?? 7;

    $branch->gst_no = $request->input('gst_no', '');
    $branch->pan_no = $request->input('pan_no', '');
    $branch->tax_no = $request->input('tax_no', '');
    $branch->fb_link = $request->input('fb_link', '');
    $branch->insta_link = $request->input('insta_link', '');
    $branch->just_dial_id = $request->input('just_dial_id', '');
    $branch->other_src_staff_id = $request->input('other_src_staff_id') ?? 0;
    $branch->call_tracker_branch_id = $request->input('call_tracker_id', 0);
    $branch->share_percentage = $request->input('share_percentage', '');
    $branch->share_start_date = date('Y-m-d', strtotime($request->input('share_start_date')));
    $branch->share_end_date = date('Y-m-d', strtotime($request->input('share_end_date')));
    // $branch->cre_mobile = $request->input('cre_mobile_no', '');
    // $branch->sales_mobile = $request->input('sales_mobile_no', '');
    $branch->comm_email_id = $request->input('comm_email_id', '');
    $branch->min_amnt_receive = $request->input('min_amnt_receive', '');
    $branch->collection_close = date('Y-m-d', strtotime($request->input('collection_close')));
    $branch->registeration_close = date('Y-m-d', strtotime($request->input('registeration_close')));
    $branch->opening_date = date('Y-m-d', strtotime($request->input('opening_date')));
    $branch->branch_category = $request->input('branch_category', '');
    $branch->branch_department = json_encode($request->input('branch_dept'));
    $branch->country_id = $request->input('country', '');
    $branch->state_id = $request->input('state', '');
    $branch->city_id = $request->input('city', '');
    $branch->area_street = $request->input('area_street', '');
    $branch->door_no = $request->input('door_flat_no', '');
    $branch->pincode = $request->input('pincode', '');
    // $branch->city_short_code = $request->input( 'city_short_code', '' ) . str_pad( $edit_sno, 2, '0', STR_PAD_LEFT );
    $branch->mobile = $request->input('business_mobile_no', '');
    $branch->mail = $request->input('business_email_id', '');
    $branch->location = $request->input('location_url', '');
    $branch->website = $request->input('website_url', '');
    $branch->latitude = $request->input('latitude', '');
    $branch->longitude = $request->input('longitude', '');
    $branch->bank_name = $request->input('bank_name', '');
    $branch->bank_branch = $request->input('bank_branch', '');
    $branch->bank_holder = $request->input('bank_holder', '');
    $branch->bank_account_no = $request->input('bank_account_no', '');
    $branch->bank_ifsc = $request->input('bank_ifsc', '');
    $branch->bank_desc = $request->input('bank_desc', '');
    $branch->branch_desc = $request->input('api_desc', '');
    $branch->bus_closing_day_count    = $request->input('bus_closing_day_count') ?? 0;
    $branch->bus_closing_month_end = $request->input('bus_closing_chk_month') ?? 0;
    $branch->cloud_call_api_key = $request->input('cloud_call_api_key');
    $branch->min_prd_cost = $request->min_product_cost;
    $branch->min_prd_days = $request->mpc_validity;
    $branch->last_payment = $request->last_payment;

     $branch->bank_swift_code = $request->swift_code;
    $branch->bank_upi_id = $request->upi_id;


    // Set audit fields
    $user_id = 1;
    // Replace with actual authenticated user ID
    $branch->updated_by = $request->user()->user_id;

    // Handle file uploads

    // Save updated branch details
    $branch->update();
    // return $request;

    $edit_atch = $request->input('edit_atch', []);
    $i = 0;



    // Flash message based on save result
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => $type_name . ' updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the ' . $type_name,
      ]);
    }
    // return $request;
    // Redirect to branch list page
    return redirect('/branch');
  }

  public function AssignCenterHead(Request $request)
  {

    // return $request;
    $edit_sno = $request->input('center_head_branch_id');
    $branch = BranchModel::find($edit_sno);
    $branch->authority_id = $request->input('center_head_staff_assign', '');
    $branch->update();
    // Flash message based on save result
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Center Head Assigned Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Center Head Assignee!'
      ]);
    }

    // return $request;
    return redirect('/branch');
  }

  public function Add_staff_branch(Request $request)
  {
    $id = $request->input('id');
    $type = $request->input('type');
    session()->forget('branch_id_ses');
    session()->forget('branch_type_ses');

    session(['branch_type_ses' => $type]);
    session(['branch_id_ses' => $id]);
    
    return response()->json(['id' => $id, 'type' => $type]);
    // return redirect( '/hr_management/staff/staff_add' );
  }

  public function Edit_staff_Cug_modal(Request $request)
  {
    // return $request;
    $edit_sno = $request->input('edit_sno_cug');
    $job_position_ids = $request->input('job_position_cug_edit');
    $staff_ids = $request->input('staff_cug_edit');
    $mobile_no = $request->input('mobile_no_cug_edit');

    // return $job_position_id;
    $cug_array = [];
    foreach ($job_position_ids as $index => $value) {
      if (isset($staff_ids[$index]) && isset($mobile_no[$index]) && $value !== '') {
        $cug_array[] = [
          'job_position' => $value,
          'staff_id' => $staff_ids[$index],
          'mobile_no' => $mobile_no[$index],
        ];
      }
    }
    // return $cug_array;
    $cug_datas = json_encode($cug_array);
    $branch = BranchModel::find($edit_sno);

    $branch->staff_cug = $cug_datas;
    $branch->update();
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the CUG to Staff Assignee!'
      ]);
    }
    return redirect('/branch');
  }

  public function Add_staff_Cug_modal(Request $request)
  {

    $edit_sno = $request->input('add_sno_cug');
    $cre_cug_add = $request->input('cre_cug_add');
    $cre_mobile_no_cug_add = $request->input('cre_mobile_no_cug_add');
    $job_position_ids = $request->input('job_position_cug_add');
    $staff_ids = $request->input('staff_cug_add');
    $mobile_no = $request->input('mobile_no_cug_add');


    foreach ($job_position_ids as $index => $value) {
      $cug_manage_add = new CugManagementModel();
      $cug_manage_add->branch_id = $edit_sno;
      $cug_manage_add->job_position_id = $value;
      $cug_manage_add->cre_id = $cre_cug_add;
      $cug_manage_add->cre_mobile = $cre_mobile_no_cug_add;
      $cug_manage_add->staff_id = $staff_ids[$index];
      $cug_manage_add->staff_mobile = $mobile_no[$index];
      $cug_manage_add->created_by = $request->user()->user_id;
      $cug_manage_add->updated_by = $request->user()->user_id;
      // dd($cug_manage_add);
      $cug_manage_add->save();
    }
    // dd($cug_manage_add);


    $branch = BranchModel::find($edit_sno);
    if ($branch) {
      $branch->cre_id = $cre_cug_add;
      $branch->cre_mobile = $cre_mobile_no_cug_add;
      $branch->save();
    }

    // Return success or error message
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Add Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the CUG to Staff Assignee!'
      ]);
    }

    return redirect('/branch');
  }

  public function Job_postion_to_Cug(Request $request)
  {

    $branch_id = $request->user()->branch_id;


    $job_position = JobRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();
    // dd($job_position);
    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $job_position,

    ], 200);
  }

  public function Staff_based_on_role($id, Request $request)
  {

    $branchId = $request->query('branchId');
    $roleId = $id;


    $staff_data = StaffModel::where('branch_id', $branchId)->where('position_role', $roleId)->where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $staff_data,

    ], 200);
  }

  public function Update_staff_Cug_modal(Request $request)
  {
    // return $request;
    $branch_id = $request->input('edit_sno_cug');
    $cre_cug_edit = $request->input('cre_cug_edit');
    $cre_mobile_no_cug_edit = $request->input('cre_mobile_no_cug_edit');
    $edit_sno = $request->input('edit_sno_cug_management');
    $job_position_ids = $request->input('job_position_cug_edit');
    $staff_ids = $request->input('staff_cug_edit');
    $mobile_no = $request->input('mobile_no_cug_edit');
    foreach ($job_position_ids as $index => $value) {

      if (isset($edit_sno[$index])) {
        $edit = CugManagementModel::find($edit_sno[$index]);
        if ($edit) {
          $edit->branch_id = $branch_id;
          $edit->job_position_id = $value;
          $edit->cre_id = $cre_cug_edit;
          $edit->cre_mobile = $cre_mobile_no_cug_edit;
          $edit->staff_id = $staff_ids[$index];
          $edit->staff_mobile = $mobile_no[$index];
          $edit->updated_by = $request->user()->user_id;  // For update user              
          $edit->update();
        }
      } else {
        $update = new CugManagementModel();
        $update->branch_id = $branch_id;
        $update->job_position_id = $value;
        $update->cre_id = $cre_cug_edit;
        $update->cre_mobile = $cre_mobile_no_cug_edit;
        $update->staff_id = $staff_ids[$index];
        $update->staff_mobile = $mobile_no[$index];
        $update->created_by = $request->user()->user_id;  // For create user
        $update->updated_by = $request->user()->user_id;  // For update user
        $update->save();
      }
    }

    $branch = BranchModel::find($branch_id);
    if ($branch) {
      $branch->cre_id = $cre_cug_edit;
      $branch->cre_mobile = $cre_mobile_no_cug_edit;
      $branch->update();
    }


    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the CUG to Staff Assignee!'
      ]);
    }

    // Redirect back to the branch page
    return redirect('/branch');
  }

  public function Cre_Dropdown(Request $request)
  {

    $branchId = $request->query('branchId');

    $cre_role = StaffModel::select('egc_staff.*', 'egc_user_role.role_name')
      ->leftJoin('egc_user_role', 'egc_user_role.sno', '=', 'egc_staff.role_id')
      //   ->where('egc_staff.role_id', 16)
      ->where('egc_staff.branch_id', $branchId)
      ->where('egc_staff.status', 0)
      ->where('egc_staff.sno', '>', 1)
      ->get();

    // return  $cre_role;

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $cre_role,

    ], 200);
  }

  public function Cug_Edit_Fetch(Request $request)
  {
    $branchId = $request->input('branch_id');
    $branch_data = DB::table('egc_branch')->where('sno', $branchId)->first();
    $edit = CugManagementModel::where('egc_cug_management.branch_id', $branchId)
      ->where('egc_cug_management.status', 0)
      ->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $edit,
      'branch' => $branch_data,

    ], 200);
  }

  public function Cug_delete(Request $request)
  {
    $sno = $request->input('sno');

    $delete =  CugManagementModel::where('sno', $sno)->first();
    $delete->status  = 2;
    $delete->Update();
    if ($delete) {
      return response([
        'status'    => 200,
        'message'   => 'CUG Deleted Successfully!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete CUG!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }

  public function checkUniqueMobileNumber(Request $request)
  {
    $mobile = $request->query('mobile');

    $exists = CugManagementModel::where('staff_mobile', $mobile)->exists();

    if ($exists) {
      return response()->json(1);  // Mobile number is already taken
    } else {
      return response()->json(0);  // Mobile number is unique
    }
  }

  public function AssignCugDetails(Request $request)
  {

    // return $request;
    $edit_sno = $request->input('add_sno_cug');
    $cre_cug_add = $request->input('cre_cug_add');
    $cre_mobile_no_cug_add = $request->input('cre_mobile_no_cug_add');
    $job_position_ids = $request->input('job_position_cug_add');
    $staff_ids = $request->input('staff_cug_add');
    $mobile_no = $request->input('mobile_no_cug_add');
    $email = $request->input('email_cug_add');
    $cug_assign_status = $request->input('cug_assign_status');

    if ($cug_assign_status == 'update') {

      $cugOld = CugManagementModel::where('branch_id', $edit_sno)
        ->where('status', '!=', 2)
        ->get();
      $existingOldIds = $cugOld->pluck('sno')->toArray();

      $updateIds = $request->cug_edit_sno;
      $oldIdsToDelete = array_diff($existingOldIds, $updateIds);
      $oldIdsToDelete = array_values($oldIdsToDelete);

      if (!empty($oldIdsToDelete)) {
        $deleteDoc = CugManagementModel::whereIn('sno', $oldIdsToDelete)
          ->update(['status' => 2]);
      }

      foreach ($updateIds as $index => $id) {
        $cugId = $id ?? null;
        if ($cugId) {
          $existingCugData = CugManagementModel::find($cugId);

          if ($existingCugData) {
            $cugStaff_key = "staff_cug_add_" . $cugId;
            $cugStaffMobile = "mobile_no_cug_add_" . $cugId;
            $cugStaffEmail = "email_cug_add_" . $cugId;

            // return $cugStaff_key;

            if (isset($request->$cugStaff_key)) {
              $cugStaffId = $request->$cugStaff_key[0] ?? null; // e.g., "Test2"
              $StaffMobile = $request->$cugStaffMobile[0] ?? null; // e.g., "Test2"
              $StaffEmail = $request->$cugStaffEmail[0] ?? null; // e.g., "Test2"
              if ($cugStaffId) {
                $existingCugData->cre_id = $cre_cug_add;
                $existingCugData->cre_mobile = $cre_mobile_no_cug_add;
                $existingCugData->staff_id = $cugStaffId;
                $existingCugData->staff_mobile = $StaffMobile;
                $existingCugData->staff_email = $StaffEmail ?? null;
              }
            }

            $existingCugData->updated_by = $request->user()->user_id ?? 1;
            $existingCugData->update();
          }
        }
      }
      if ($staff_ids) {

        foreach ($staff_ids as $index => $staff_id_new) {
          if ($staff_id_new != null) {
            $cug_manage_add = new CugManagementModel();
            $cug_manage_add->branch_id = $edit_sno;
            $cug_manage_add->cre_id = $cre_cug_add;
            $cug_manage_add->cre_mobile = $cre_mobile_no_cug_add;
            $cug_manage_add->staff_id = $staff_ids[$index];
            $cug_manage_add->staff_mobile = $mobile_no[$index];
            $cug_manage_add->staff_email = $email[$index];
            $cug_manage_add->created_by = $request->user()->user_id ?? 1;
            $cug_manage_add->updated_by = $request->user()->user_id ?? 1;
            // dd($cug_manage_add);
            $cug_manage_add->save();
          }
        }
      }
    } else {
      foreach ($staff_ids as $index => $value) {
        $cug_manage_add = new CugManagementModel();
        $cug_manage_add->branch_id = $edit_sno;
        $cug_manage_add->cre_id = $cre_cug_add;
        $cug_manage_add->cre_mobile = $cre_mobile_no_cug_add;
        $cug_manage_add->staff_id = $staff_ids[$index];
        $cug_manage_add->staff_mobile = $mobile_no[$index];
        $cug_manage_add->staff_email = $email[$index];
        $cug_manage_add->created_by = $request->user()->user_id ?? 1;
        $cug_manage_add->updated_by = $request->user()->user_id ?? 1;
        // dd($cug_manage_add);
        $cug_manage_add->save();
      }
    }

    // dd($cug_manage_add);
    $branch = BranchModel::find($edit_sno);
    if ($branch) {
      $branch->cre_id = $cre_cug_add;
      $branch->cre_mobile = $cre_mobile_no_cug_add;
      $branch->save();
    }



    // Return success or error message
    if ($branch) {
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'CUG Assigned to Staff Add Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the CUG to Staff Assignee!'
      ]);
    }

    return redirect('/branch');
  }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno; 

    $query = DB::table('egc_branch')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }
}
