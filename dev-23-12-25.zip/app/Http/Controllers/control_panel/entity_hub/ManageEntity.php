<?php

namespace App\Http\Controllers\control_panel\entity_hub;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManageEntity extends Controller
{
  public function index(Request $request)
  {
      $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        
      $Entity = ManageEntityModel::where('egc_entity.status', '!=', 2)
      ->select('egc_entity.*', 'egc_countries.name', 'egc_states.name as statename', 'egc_cities.name as citiesname', 'egc_company.company_name','egc_company_type.company_type_name', 'egc_company_type.slug_name')
      ->leftJoin('egc_countries', 'egc_entity.entity_country', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_entity.entity_state', 'egc_states.id')
      ->leftJoin('egc_cities', 'egc_entity.entity_city', 'egc_cities.id')
      ->leftJoin('egc_company', 'egc_company.sno', 'egc_entity.company_id')
      ->leftJoin('egc_company_type', 'egc_company.company_type', 'egc_company_type.sno');
    
      
        if($search_filter != '') {
            $Entity->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_ct_person', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_ct_number', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_mail', 'LIKE', "%{$search_filter}%");
            });
        }
        
    $Entity = $Entity->orderBy('egc_entity.sno', 'asc')->paginate($perpage);
     $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $Entity->map(function ($item) use ($helper) {
            $company_address = $item->entity_door_no . ' ' . $item->entity_area . ', ' . $item->citiesname . ', ' . $item->statename . ' - ' . $item->entity_pincode;
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'company_name' => $item->company_name,
                'entity_name' => $item->entity_name,
                'entity_mail' => $item->entity_mail,
                'company_type_name' => $item->company_type_name,
                 'slug_name' => $item->slug_name,
                'company_mail' => $item->company_mail,
                'company_address' => $company_address,
                'entity_website' => $item->entity_website,
                'entity_ct_person' => $item->entity_ct_person,
                'entity_ct_number' => $item->entity_ct_number,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $Entity->currentPage(),
            'last_page' => $Entity->lastPage(),
            'total' => $Entity->total(),
        ]);
    }

    $Company = CompanyModel::where('status', 0)->orderBy('company_name', 'ASC')->get();
    $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    
    return view('content.control_panel.entity_hub.manage_entity.entity_list',[
        'ListTable' => $Entity,
          'Company' => $Company,
          'social_media_list' => $social_media_list,
          'perpage' => $perpage,
            'search_filter' => $search_filter,
      ]);
  }
  
    public function List(Request $request)
  {

      $company_id = $request->input('company_id');
      $entity = ManageEntityModel::where('status', 0)->where('company_id', $company_id)->orderBy('sno', 'asc')->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $entity
      ], 200);
  }
   public function DropdownList(Request $request)
  {

    $entity = ManageEntityModel::where('status', 0)->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $entity
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $staff =  ManageEntityModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Entity  Status Successfully Updated!',
        'error_msg' => 'Could not, update  Entity  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Entity  Status!',
        'error_msg' => 'Could not, update  Entity  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_StaffModel = ManageEntityModel::where('sno', $id)->first();
    $upd_StaffModel->status = 2;
    $upd_StaffModel->Update();

    if ($upd_StaffModel) {
      return response([
        'status'    => 200,
        'message'   => 'Entity Deleted Successfully..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not delete Entity ..!',
        'error_msg' => null,
        'data'      => null,
      ], 200);
    }
  }
  public function View($id)
  {
    $data = ManageEntityModel::select('egc_entity.*', 'egc_countries.name', 'egc_states.name as statename', 'egc_cities.name as citiesname', 'egc_company.company_name')
      ->leftJoin('egc_countries', 'egc_entity.entity_country', 'egc_countries.id')
      ->leftJoin('egc_states', 'egc_entity.entity_state', 'egc_states.id')
      ->leftJoin('egc_cities', 'egc_entity.entity_city', 'egc_cities.id')
      ->leftJoin('egc_company', 'egc_company.sno', 'egc_entity.company_id')
      ->where('egc_entity.sno', $id)
      ->orderBy('egc_entity.sno', 'desc')->first();


    if (!$data) {
      return response([
        'status' => 404,
        'message' => 'Entity not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Entity fetched successfully',
      'error_msg' => null,
      'data' => $data,
    ], 200);
  }

  public function Add(Request $request)
  {
    //   return $request;
     $chk = ManageEntityModel::where('entity_name', $request->entity_name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Entity Name has been already created!'
        ]);
        return redirect()->back();
      }
    $category_check = ManageEntityModel::orderBy('sno', 'desc')->first();

    if (!$category_check) {

      $year = substr(date('y'), -2);
      $entity_id = 'EGCE-0001/' . $year;
    } else {

      $data = $category_check->entity_id;
      $slice = explode('/', $data);
      $result = preg_replace('/[^0-9]/', '', $slice[0]);

      $next_number = (int) $result + 1;
      $request_id = sprintf('EGCE-%04d', $next_number);

      $year = substr(date('y'), -2);
      $entity_id = $request_id . '/' . $year;
    }
    $user_id = $request->user()->user_id ?? 1;
     $socialMediaData = request()->input('social_media');
     $socialMediaData = array_filter($socialMediaData, function($value) {
        return !is_null($value) && $value !== '';
    });
     $company_short_name=$request->company_short_name;
   $company_id=  $request->company_id;
    $entity_logo = '';
     $request = request(); // Assuming the request object is available.

        if ($request->hasFile('entity_logo')) {
            // Define the base directory for logos
            $entity_logos_base_path = public_path('Entity_logos');
            $company_directory = $entity_logos_base_path . DIRECTORY_SEPARATOR . $company_id;
        
            // Ensure the directory for the company exists, or create it
            if (!is_dir($company_directory)) {
                mkdir($company_directory, 0777, true);
            }
        
            // Define the base filename
            $base_name = 'entity_';
            $extension = $request->file('entity_logo')->extension();
        
            // Start by checking for the first available file name (entity_1.png, entity_2.jpg, etc.)
            $i = 1;
            do {
                $entity_logo_name = $base_name . $i . '.' . $extension;
                $file_path = $company_directory . DIRECTORY_SEPARATOR . $entity_logo_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path)); // Check if the file already exists
        
            // Move the uploaded file to the company directory
            $request->file('entity_logo')->move($company_directory, $entity_logo_name);
            $entity_logo = $entity_logo_name; // Assign the filename to the entity_logo variable
        }
    $Add = new ManageEntityModel();

    $Add->entity_id = $entity_id;
    $Add->company_id = $request->company_id;
    $Add->entity_name = $request->entity_name;
    $Add->entity_mail = $request->entity_mail;
    $Add->entity_website = $request->website_url;
    $Add->entity_logo = $entity_logo;
    $Add->entity_base_url = $request->entity_base_url;
    $Add->entity_short_name = $request->entity_short_name;
    $Add->social_media_details = json_encode($socialMediaData);
    $Add->entity_in_menu = $request->entity_in_menu ? $request->entity_in_menu : 0;
    $Add->entity_location_url = $request->location_url;
    $Add->entity_ct_person = $request->ct_person;
    $Add->entity_ct_number = $request->ct_per_mobile_no;
    $Add->entity_country = $request->country;
    $Add->entity_state = $request->state;
    $Add->entity_city = $request->city;
    $Add->entity_area = $request->area_street;
    $Add->entity_door_no = $request->door_flat_no;
    $Add->entity_pincode = $request->pincode;
    $Add->entity_gst = $request->gst_no;
    $Add->entity_cin = $request->cin_no;
    $Add->entity_pan = $request->pan_no;
    $Add->entity_desc = $request->entity_desc;
    $Add->entity_bank_name = $request->comapny_bank_name;
    $Add->entity_bank_branch = $request->comapny_bank_branch;
    $Add->entity_acc_holder = $request->comapny_acc_holder;
    $Add->entity_acc_no = $request->comapny_acc_no;
    $Add->entity_ifsc = $request->comapny_bank_ifsc;
    $Add->created_by = $user_id;
    $Add->updated_by = $user_id;

    $Add->save();

    if ($Add) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Entity added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Entity!'
      ]);
    }

    return redirect()->back();
  }
  public function Update(Request $request)
  {
   
      $user_id = $request->user()->user_id ?? 1;
      $id = $request->edit_id;
    
    $chk = ManageEntityModel::where('entity_name', $request->entity_name)->where('sno', '!=', $id)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Entity Name has been already created!'
        ]);
        return redirect()->back();
      }
      
    $entity_short_name=$request->entity_short_name;
     $company_id=  $request->company_id;
          $socialMediaData = request()->input('social_media');
         $socialMediaData = array_filter($socialMediaData, function($value) {
            return !is_null($value) && $value !== '';
        });
    
    $entity_logo = '';
    $request = request(); // Assuming the request object is available.

        if ($request->hasFile('fav_icon')) {
             // Define the base directory for logos
            $entity_logos_base_path = public_path('Entity_logos');
            $company_directory = $entity_logos_base_path . DIRECTORY_SEPARATOR . $company_id;
        
            // Ensure the directory for the company exists, or create it
            if (!is_dir($company_directory)) {
                mkdir($company_directory, 0777, true);
            }
        
            // Define the base filename
            $base_name = 'entity_';
            $extension = $request->file('entity_logo')->extension();
        
            // Start by checking for the first available file name (entity_1.png, entity_2.jpg, etc.)
            $i = 1;
            do {
                $entity_logo_name = $base_name . $i . '.' . $extension;
                $file_path = $company_directory . DIRECTORY_SEPARATOR . $entity_logo_name;
                $i++; // Increment the number for the next iteration
            } while (file_exists($file_path)); // Check if the file already exists
        
            // Move the uploaded file to the company directory
            $request->file('entity_logo')->move($company_directory, $entity_logo_name);
            $entity_logo = $entity_logo_name; // Assign the filename to the entity_logo variable
        }else{
             $entity_logo =$request->old_entity_image;
        }
      
    
    $update = ManageEntityModel::where('sno', $id)->first();
    $update->company_id = $request->company_id;
    $update->entity_name = $request->entity_name;
    $update->entity_mail = $request->entity_mail;
     $update->entity_logo = $entity_logo;
    $update->entity_short_name = $request->entity_short_name;
      $update->social_media_details = json_encode($socialMediaData);
    $update->entity_in_menu = $request->entity_in_menu ? $request->entity_in_menu : 0;
    $update->entity_base_url = $request->entity_base_url;
    $update->entity_location_url = $request->location_url;
    $update->entity_website = $request->website_url;
    $update->entity_ct_person = $request->ct_person;
    $update->entity_ct_number = $request->ct_per_mobile_no;
    $update->entity_country = $request->country;
    $update->entity_state = $request->state;
    $update->entity_city = $request->city;
    $update->entity_area = $request->area_street;
    $update->entity_door_no = $request->door_flat_no;
    $update->entity_pincode = $request->pincode;
    $update->entity_gst = $request->gst_no;
    $update->entity_cin = $request->cin_no;
    $update->entity_pan = $request->pan_no;
    $update->entity_desc = $request->entity_desc;
    $update->entity_bank_name = $request->comapny_bank_name;
    $update->entity_bank_branch = $request->comapny_bank_branch;
    $update->entity_acc_holder = $request->comapny_acc_holder;
    $update->entity_acc_no = $request->comapny_acc_no;
    $update->entity_ifsc = $request->comapny_bank_ifsc;
    $update->created_by = $user_id;
    $update->updated_by = $user_id;

    $update->update();

    if ($update) {
      // If category added successfully, return success response and display Toastr message
      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Entity Updated Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not update the Entity!'
      ]);
    }

    return redirect()->back();
  }

  public function checkDuplicates(Request $request)
  {
    $field = $request->field;
    $value = $request->value;
    $currentSno = $request->sno;

    $query = DB::table('egc_entity')->where($field, $value);

    if (!empty($currentSno)) {
      $query->where('sno', '!=', $currentSno);
    }

    $exists = $query->exists();

    return response()->json([
      'exists' => $exists,
      'message' => $exists ? ucfirst(str_replace('_', ' ', $field)) . ' already exists.' : ''
    ]);
  }
}
