<?php

namespace App\Http\Controllers\authentications;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Http;
class NetworkHandle extends Controller
{
  public function networkCheck(Request $request)
{
    $url = "https://erp.elysium.community";
    $start = microtime(true);

    try {
        // Attempt to fetch the URL with a timeout of 3 seconds
        $response = Http::timeout(3)->get($url);
    } catch (\Exception $e) {
        // If there's an exception (network error, timeout, etc.)
        return [
            'status' => 'server_down',
            'message' => 'Server is down or unreachable, please try again later',
            'error' => $e->getMessage()
        ];
    }

    // Calculate the latency
    $latency = (microtime(true) - $start) * 1000;

    // Check if the status code is successful (200-299)
    if ($response->successful()) {
        if ($latency < 300) {  // Stable if under 300ms
            return [
                'status' => 'stable',
                'latency' => round($latency),
                'message' => 'Network is stable'
            ];
        } elseif ($latency < 800) {  // Slow if between 300ms and 800ms
            return [
                'status' => 'slow',
                'latency' => round($latency),
                'message' => 'Network is slow, but functional'
            ];
        } else {
            return [
                'status' => 'unstable',
                'latency' => round($latency),
                'message' => 'Network is unstable, please check your connection'
            ];
        }
    } else {
        // If the server returns a non-2xx status code
        return [
            'status' => 'server_error',
            'message' => 'The server returned an error, please try again later',
            'http_status_code' => $response->status()
        ];
    }
}

public function ping(Request $request)
{
    // Respond immediately to the ping request
    return response()->json([
        'status' => 'success',
        'message' => 'Server is responsive'
    ]);
}

}
