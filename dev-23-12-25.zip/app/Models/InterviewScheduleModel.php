<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewScheduleModel extends Model
{
  use HasFactory;
  public $table      = 'egc_interview_schedule';
  public $primaryKey = 'sno';
  // public $timestamps = false;

  protected $fillable = [
        'job_request_id',
        'entity_id',
        'share_code',
        'share_link',
        'status',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by'
    ];
}