<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewAnswerModel extends Model
{
  use HasFactory;
  protected $table = 'egc_interview_answers';
    protected $primaryKey = 'sno';
    public $timestamps = false;

    protected $fillable = [
        'interview_session_id',
        'interview_schedule_stage_id',
        'interview_question_id',
        'answer_type',
        'answer_text',
        'answer_file',
        'answer_option',
        'time_taken',
        'retake_count',
        'status',
        'created_at', 
        'created_by',
        'updated_at',
        'updated_by'
    ];
}