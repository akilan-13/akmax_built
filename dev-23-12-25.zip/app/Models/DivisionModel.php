<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DivisionModel extends Model
{
    use HasFactory;
    public $table      = 'egc_division';
    public $primaryKey = 'sno';

    protected $fillable = [
        'erp_division_id',
        'erp_department_id',
        'company_type',
        'company_id',
        'entity_id',
        'branch_id',
        'department_id',
        'entity_id',
        'division_name',
        'division_desc',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}
