<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InterviewOtpModel extends Model
{
  use HasFactory;
   protected $table = 'egc_interview_otp';
    protected $primaryKey = 'sno';
    public $timestamps = true;

    protected $fillable = [
        'candidate_id',
        'otp',
        'interview_schedule_id',
        'job_request_id',
        'expires_at',
        'updated_at',
        'created_at',
        'is_used'
    ];
}