<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CountryModel extends Model
{
    use HasFactory;
    public $table      = "egc_countries";
    public $primaryKey = 'id';


    protected $fillable = [
        'sortname',
        'name',
        'phonecode',
        'created_by',
        'created_at',
        'status'
    ];
}