@extends('layouts/blankLayout')

@section('title', 'Interview Completed')

<style>
body {
    background: radial-gradient(circle at top, #ff8c00 0%, #ab2b22 45%, #8f1f18 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Inter', system-ui, sans-serif;
}

.thankyou-card {
    background: #ffffff;
    padding: 50px 45px;
    border-radius: 22px;
    text-align: center;
    max-width: 520px;
    width: 100%;
    box-shadow: 0 40px 80px rgba(0,0,0,.3);
}

.thankyou-icon {
    font-size: 56px;
    margin-bottom: 15px;
}

.thankyou-card h2 {
    font-weight: 700;
    margin-bottom: 10px;
}

.thankyou-card p {
    color: #555;
    font-size: 15px;
    line-height: 1.6;
}

.footer-note {
    font-size: 13px;
    color: #888;
    margin-top: 25px;
}

@media (max-width: 576px) {
    .thankyou-card {
        padding: 35px 25px;
        border-radius: 16px;
    }
}
</style>

@section('content')
<div class="thankyou-card">
    <div class="thankyou-icon">🎉</div>

    <h2>Interview Submitted</h2>

    <p>
        Thank you for completing your interview.<br>
        Your responses have been recorded successfully.
    </p>

    <p class="mt-3">
        Our team will review your submission and contact you if you are shortlisted.
    </p>

    <div class="footer-note">
        You may now safely close this window.
    </div>
</div>
@endsection
