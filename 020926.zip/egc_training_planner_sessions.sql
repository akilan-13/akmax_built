-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2026 at 08:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `updated_egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_training_planner_sessions`
--

CREATE TABLE `egc_training_planner_sessions` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `training_planner_id` bigint(20) UNSIGNED NOT NULL,
  `session_no` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `session_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `session_title` varchar(255) DEFAULT NULL,
  `syllabus_details` longtext DEFAULT NULL,
  `syllabus_completed` tinyint(1) NOT NULL DEFAULT 0,
  `syllabus_completed_at` datetime DEFAULT NULL,
  `trainer_notes` longtext DEFAULT NULL,
  `session_status` varchar(30) NOT NULL DEFAULT 'scheduled',
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `egc_training_planner_sessions`
--

INSERT INTO `egc_training_planner_sessions` (`sno`, `training_planner_id`, `session_no`, `session_date`, `start_time`, `end_time`, `session_title`, `syllabus_details`, `syllabus_completed`, `syllabus_completed_at`, `trainer_notes`, `session_status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-03-04', '12:00:00', '14:00:00', 'Session 1', NULL, 1, NULL, NULL, 'completed', 0, 0, '2026-03-04 22:24:42', '2026-03-04 22:42:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_training_planner_sessions`
--
ALTER TABLE `egc_training_planner_sessions`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uq_training_session_slot` (`training_planner_id`,`session_date`,`start_time`,`end_time`),
  ADD KEY `idx_training_sessions_planner` (`training_planner_id`),
  ADD KEY `idx_training_sessions_date` (`session_date`),
  ADD KEY `idx_training_sessions_status` (`session_status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_training_planner_sessions`
--
ALTER TABLE `egc_training_planner_sessions`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
