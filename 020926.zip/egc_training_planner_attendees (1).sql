-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2026 at 08:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `updated_egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_training_planner_attendees`
--

CREATE TABLE `egc_training_planner_attendees` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `training_planner_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `attendance_status` tinyint(4) DEFAULT NULL,
  `attendance_marked_at` datetime DEFAULT NULL,
  `certificate_issued` tinyint(1) NOT NULL DEFAULT 0,
  `assessment_status` tinyint(4) DEFAULT NULL,
  `assessment_score` decimal(5,2) DEFAULT NULL,
  `assessment_passed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `egc_training_planner_attendees`
--

INSERT INTO `egc_training_planner_attendees` (`sno`, `training_planner_id`, `staff_id`, `attendance_status`, `attendance_marked_at`, `certificate_issued`, `assessment_status`, `assessment_score`, `assessment_passed_at`, `created_at`, `updated_at`) VALUES
(1, 1, 261, 1, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(2, 1, 262, 1, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(3, 1, 315, 0, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(4, 1, 316, 0, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(5, 1, 317, 0, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(6, 1, 318, 0, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44'),
(7, 1, 319, 0, '2026-08-31 18:55:44', 0, NULL, NULL, NULL, '2026-08-31 13:25:44', '2026-08-31 13:25:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_training_planner_attendees`
--
ALTER TABLE `egc_training_planner_attendees`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uq_training_attendee` (`training_planner_id`,`staff_id`),
  ADD KEY `idx_training_attendee_staff` (`staff_id`),
  ADD KEY `idx_training_attendee_training` (`training_planner_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_training_planner_attendees`
--
ALTER TABLE `egc_training_planner_attendees`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
