-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2026 at 08:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `updated_egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_training_planner`
--

CREATE TABLE `egc_training_planner` (
  `sno` int(11) NOT NULL,
  `training_planner_id` varchar(11) NOT NULL,
  `company_ids` text DEFAULT NULL,
  `entity_ids` text DEFAULT NULL,
  `branch_ids` tinytext DEFAULT NULL,
  `training_planner_name` text NOT NULL,
  `training_mode` int(11) NOT NULL,
  `trainer` int(11) NOT NULL,
  `trainer_name` varchar(11) DEFAULT NULL,
  `training_duration` int(11) NOT NULL,
  `schedule_date` date NOT NULL,
  `schedule_from_date` date DEFAULT NULL,
  `schedule_to_date` date DEFAULT NULL,
  `schedule_time` time NOT NULL,
  `schedule_from_time` time DEFAULT NULL,
  `schedule_to_time` time DEFAULT NULL,
  `training_desc` text DEFAULT NULL,
  `all_check` int(11) NOT NULL DEFAULT 0,
  `staff_check` text NOT NULL DEFAULT '0',
  `attendance_status` text DEFAULT NULL,
  `certificate_available` tinyint(1) NOT NULL DEFAULT 0,
  `assessment_required` tinyint(1) NOT NULL DEFAULT 0,
  `certificate_name` varchar(255) DEFAULT NULL,
  `assessment_pass_percentage` decimal(5,2) DEFAULT NULL,
  `planner_status` varchar(20) NOT NULL DEFAULT 'scheduled',
  `cancelled_reason` text DEFAULT NULL,
  `reschedule_reason` text DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `egc_training_planner`
--

INSERT INTO `egc_training_planner` (`sno`, `training_planner_id`, `company_ids`, `entity_ids`, `branch_ids`, `training_planner_name`, `training_mode`, `trainer`, `trainer_name`, `training_duration`, `schedule_date`, `schedule_from_date`, `schedule_to_date`, `schedule_time`, `schedule_from_time`, `schedule_to_time`, `training_desc`, `all_check`, `staff_check`, `attendance_status`, `certificate_available`, `assessment_required`, `certificate_name`, `assessment_pass_percentage`, `planner_status`, `cancelled_reason`, `reschedule_reason`, `completed_at`, `cancelled_at`, `created_at`, `created_by`, `updated_at`, `updated_by`, `status`) VALUES
(1, 'TP-0001/26', '[\"0\"]', NULL, NULL, 'New', 1, 2, NULL, 2, '2026-03-04', '2026-03-04', '2026-03-04', '12:00:00', '12:00:00', '14:00:00', NULL, 0, '[\"261\",\"262\",\"315\",\"316\",\"317\",\"318\",\"319\"]', '[{\"staff_id\":\"261\",\"attendance\":0},{\"staff_id\":\"262\",\"attendance\":0},{\"staff_id\":\"315\",\"attendance\":1},{\"staff_id\":\"316\",\"attendance\":1},{\"staff_id\":\"317\",\"attendance\":1},{\"staff_id\":\"318\",\"attendance\":1},{\"staff_id\":\"319\",\"attendance\":1}]', 0, 0, NULL, NULL, 'completed', NULL, NULL, NULL, NULL, '2026-03-04 22:24:42', 0, '2026-03-04 22:42:09', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_training_planner`
--
ALTER TABLE `egc_training_planner`
  ADD PRIMARY KEY (`sno`),
  ADD KEY `idx_training_schedule_range` (`schedule_from_date`,`schedule_to_date`),
  ADD KEY `idx_training_trainer_schedule` (`trainer`,`schedule_from_date`,`schedule_to_date`),
  ADD KEY `idx_training_planner_status` (`planner_status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_training_planner`
--
ALTER TABLE `egc_training_planner`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
