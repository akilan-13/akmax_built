<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('egc_training_planner_sessions')) {
            Schema::create('egc_training_planner_sessions', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('training_planner_id');
                $table->unsignedInteger('session_no')->default(1);
                $table->date('session_date');
                $table->time('start_time');
                $table->time('end_time');
                $table->string('session_title', 255)->nullable();
                $table->longText('syllabus_details')->nullable();
                $table->boolean('syllabus_completed')->default(false);
                $table->dateTime('syllabus_completed_at')->nullable();
                $table->longText('trainer_notes')->nullable();
                $table->string('session_status', 30)->default('scheduled');
                $table->unsignedInteger('created_by')->default(0);
                $table->unsignedInteger('updated_by')->default(0);
                $table->dateTime('created_at')->useCurrent();
                $table->dateTime('updated_at')->useCurrent()->useCurrentOnUpdate();

                $table->unique(['training_planner_id', 'session_date', 'start_time', 'end_time'], 'uq_training_session_slot');
                $table->index('training_planner_id', 'idx_training_sessions_planner');
                $table->index('session_date', 'idx_training_sessions_date');
                $table->index('session_status', 'idx_training_sessions_status');
            });
        }

        if (!Schema::hasTable('egc_training_planner_session_attendance')) {
            Schema::create('egc_training_planner_session_attendance', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('training_session_id');
                $table->unsignedInteger('training_planner_id');
                $table->unsignedInteger('staff_id');
                $table->unsignedTinyInteger('attendance_status')->nullable();
                $table->dateTime('attendance_marked_at')->nullable();
                $table->unsignedInteger('created_by')->default(0);
                $table->unsignedInteger('updated_by')->default(0);
                $table->dateTime('created_at')->useCurrent();
                $table->dateTime('updated_at')->useCurrent()->useCurrentOnUpdate();

                $table->unique(['training_session_id', 'staff_id'], 'uq_training_session_staff');
                $table->index(['training_planner_id', 'staff_id'], 'idx_session_attendance_planner_staff');
                $table->foreign('training_session_id', 'fk_session_attendance_session')
                    ->references('sno')->on('egc_training_planner_sessions')
                    ->cascadeOnDelete();
            });
        }

        // Backfill sessions from the upgraded planner's existing schedule data.
        $trainings = DB::table('egc_training_planner')
            ->where('status', '!=', 2)
            ->get();

        foreach ($trainings as $training) {
            if (DB::table('egc_training_planner_sessions')->where('training_planner_id', $training->sno)->exists()) {
                continue;
            }

            $sessions = [];
            $scheduleSessions = json_decode((string) ($training->schedule_sessions ?? ''), true);

            if (($training->schedule_type ?? 'range') === 'custom' && is_array($scheduleSessions) && $scheduleSessions) {
                foreach ($scheduleSessions as $session) {
                    if (empty($session['date']) || empty($session['from_time']) || empty($session['to_time'])) continue;
                    $sessions[] = [
                        'date' => Carbon::parse($session['date'])->toDateString(),
                        'from' => substr($session['from_time'], 0, 8),
                        'to' => substr($session['to_time'], 0, 8),
                    ];
                }
            } else {
                $fromDate = $training->schedule_from_date ?: $training->schedule_date;
                $toDate = $training->schedule_to_date ?: $training->schedule_date;
                $fromTime = $training->schedule_from_time ?: $training->schedule_time;
                $toTime = $training->schedule_to_time;

                if (!$toTime && $fromTime) {
                    $toTime = Carbon::createFromFormat('H:i:s', $fromTime)->addHours(max(1, (int) ($training->training_duration ?: 1)))->format('H:i:s');
                }

                if ($fromDate && $toDate && $fromTime && $toTime) {
                    $cursor = Carbon::parse($fromDate);
                    $last = Carbon::parse($toDate);
                    while ($cursor->lte($last)) {
                        $sessions[] = [
                            'date' => $cursor->toDateString(),
                            'from' => substr($fromTime, 0, 8),
                            'to' => substr($toTime, 0, 8),
                        ];
                        $cursor->addDay();
                    }
                }
            }

            foreach ($sessions as $index => $session) {
                DB::table('egc_training_planner_sessions')->insert([
                    'training_planner_id' => $training->sno,
                    'session_no' => $index + 1,
                    'session_date' => $session['date'],
                    'start_time' => $session['from'],
                    'end_time' => $session['to'],
                    'session_title' => 'Session ' . ($index + 1),
                    'session_status' => $training->planner_status === 'completed' ? 'completed' : ($training->planner_status === 'cancelled' ? 'cancelled' : 'scheduled'),
                    'syllabus_completed' => $training->planner_status === 'completed' ? 1 : 0,
                    'syllabus_completed_at' => $training->planner_status === 'completed' ? ($training->completed_at ?: null) : null,
                    'created_by' => $training->created_by ?? 0,
                    'updated_by' => $training->updated_by ?? 0,
                    'created_at' => $training->created_at ?: now(),
                    'updated_at' => $training->updated_at ?: now(),
                ]);
            }
        }

        // Backfill session attendance rows for all current attendees.
        $sessions = DB::table('egc_training_planner_sessions')->get();
        foreach ($sessions as $session) {
            $attendeeIds = [];
            $planner = DB::table('egc_training_planner')->where('sno', $session->training_planner_id)->first();
            if ($planner) {
                $attendeeIds = json_decode((string) ($planner->staff_check ?? ''), true);
                if (!is_array($attendeeIds)) $attendeeIds = [];
            }

            foreach (array_unique(array_map('intval', $attendeeIds)) as $staffId) {
                if ($staffId <= 0) continue;
                DB::table('egc_training_planner_session_attendance')->insertOrIgnore([
                    'training_session_id' => $session->sno,
                    'training_planner_id' => $session->training_planner_id,
                    'staff_id' => $staffId,
                    'attendance_status' => null,
                    'created_by' => $planner->created_by ?? 0,
                    'updated_by' => $planner->updated_by ?? 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_training_planner_session_attendance');
        Schema::dropIfExists('egc_training_planner_sessions');
    }
};
