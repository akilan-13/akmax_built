-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2026 at 08:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `updated_egc`
--

-- --------------------------------------------------------

--
-- Table structure for table `egc_training_planner_session_attendance`
--

CREATE TABLE `egc_training_planner_session_attendance` (
  `sno` bigint(20) UNSIGNED NOT NULL,
  `training_session_id` bigint(20) UNSIGNED NOT NULL,
  `training_planner_id` int(10) UNSIGNED NOT NULL,
  `staff_id` int(10) UNSIGNED NOT NULL,
  `attendance_status` tinyint(3) UNSIGNED DEFAULT NULL,
  `attendance_marked_at` datetime DEFAULT NULL,
  `created_by` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `egc_training_planner_session_attendance`
--

INSERT INTO `egc_training_planner_session_attendance` (`sno`, `training_session_id`, `training_planner_id`, `staff_id`, `attendance_status`, `attendance_marked_at`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 261, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(2, 1, 1, 262, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(3, 1, 1, 315, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(4, 1, 1, 316, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(5, 1, 1, 317, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(6, 1, 1, 318, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42'),
(7, 1, 1, 319, NULL, NULL, 0, 0, '2026-09-01 18:40:42', '2026-09-01 18:40:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `egc_training_planner_session_attendance`
--
ALTER TABLE `egc_training_planner_session_attendance`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `uq_training_session_staff` (`training_session_id`,`staff_id`),
  ADD KEY `idx_session_attendance_planner_staff` (`training_planner_id`,`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `egc_training_planner_session_attendance`
--
ALTER TABLE `egc_training_planner_session_attendance`
  MODIFY `sno` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `egc_training_planner_session_attendance`
--
ALTER TABLE `egc_training_planner_session_attendance`
  ADD CONSTRAINT `fk_session_attendance_session` FOREIGN KEY (`training_session_id`) REFERENCES `egc_training_planner_sessions` (`sno`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
