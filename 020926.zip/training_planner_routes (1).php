use App\Http\Controllers\hr_management\hr_training\ManageTraining;

Route::get('/hr_training/manage_training', [ManageTraining::class, 'index'])
    ->name('hrm-hr-management-operation-manage-training');

Route::get('/training-planner/data', [ManageTraining::class, 'data'])->name('training_planner.data');
Route::get('/training-planner/lookups', [ManageTraining::class, 'lookups'])->name('training_planner.lookups');
Route::get('/training-planner/entities', [ManageTraining::class, 'entities'])->name('training_planner.entities');
Route::get('/training-planner/branches', [ManageTraining::class, 'branches'])->name('training_planner.branches');
Route::get('/training-planner/staff', [ManageTraining::class, 'staffAvailability'])->name('training_planner.staff');

Route::get('/training-planner/{id}', [ManageTraining::class, 'show'])->name('training_planner.show');
Route::post('/training-planner', [ManageTraining::class, 'store'])->name('training_planner.store');
Route::put('/training-planner/{id}', [ManageTraining::class, 'update'])->name('training_planner.update');
Route::post('/training-planner/conflicts', [ManageTraining::class, 'checkConflicts'])->name('training_planner.conflicts');
Route::post('/training-planner/{id}/status', [ManageTraining::class, 'changeStatus'])->name('training_planner.status');
Route::post('/training-planner/{id}/complete', [ManageTraining::class, 'complete'])->name('training_planner.complete');
Route::delete('/training-planner/{id}', [ManageTraining::class, 'destroy'])->name('training_planner.delete');
Route::post('/training-planner/save-image', [ManageTraining::class, 'storeImage'])->name('training_planner.image.save');

// Attendee management
Route::get('/training-planner/{id}/attendees', [ManageTraining::class, 'showAttendees'])->name('training_planner.attendees');
Route::post('/training-planner/{id}/attendees', [ManageTraining::class, 'addAttendees'])->name('training_planner.attendees.add');
Route::delete('/training-planner/{id}/attendees/{staffId}', [ManageTraining::class, 'removeAttendee'])->name('training_planner.attendees.remove');

// Session / syllabus management
Route::get('/training-planner/{id}/sessions', [ManageTraining::class, 'sessions'])->name('training_planner.sessions');
Route::put('/training-planner/{id}/sessions/{sessionId}', [ManageTraining::class, 'updateSession'])->name('training_planner.session.update');
Route::get('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'sessionAttendance'])->name('training_planner.session.attendance');
Route::post('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'updateSessionAttendance'])->name('training_planner.session.attendance.update');
