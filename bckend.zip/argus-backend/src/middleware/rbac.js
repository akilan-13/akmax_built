// src/middleware/rbac.js

import mongoose from 'mongoose';

import {
  AuthenticationError,
} from './auth.js';


/* -------------------------------------------------------------------------- */
/* Permission constants                                                       */
/* -------------------------------------------------------------------------- */

export const RBAC_ACTIONS = Object.freeze([
  'view',
  'add',
  'edit',
  'delete',
  'all',
]);


/**
 * Permission aliases.
 *
 * The frontend can ultimately display:
 *
 * VIEW / ADD / EDIT / DELETE / ALL
 *
 * while API routes use lowercase action names.
 */
const ACTION_ALIASES = Object.freeze({
  VIEW: 'view',
  ADD: 'add',
  CREATE: 'add',
  EDIT: 'edit',
  UPDATE: 'edit',
  DELETE: 'delete',
  ALL: 'all',
});


/**
 * Internal/system roles.
 *
 * These are identifiers only.
 *
 * The authoritative role definition will live in MongoDB.
 */
export const SYSTEM_ROLES = Object.freeze({
  WORKSPACE_OWNER:
    'workspace_owner',

  NETWORK_ADMIN:
    'network_admin',

  FIELD_TECHNICIAN:
    'field_technician',

  BILLING_MANAGER:
    'billing_manager',

  VENDOR_ADMIN:
    'vendor_admin',

  VENDOR_USER:
    'vendor_user',
});


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class AuthorizationError extends Error {
  constructor(
    message = 'You are not authorized to perform this action.',
    {
      code =
        'FORBIDDEN',
      statusCode =
        403,
      details =
        undefined,
    } = {},
  ) {
    super(message);

    this.name =
      'AuthorizationError';

    this.code =
      code;

    this.statusCode =
      statusCode;

    this.details =
      details;

    Error.captureStackTrace?.(
      this,
      AuthorizationError,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Permission normalization                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Normalize an action supplied by a route.
 */
export function normalizeAction(
  action,
) {
  if (
    typeof action !==
    'string'
  ) {
    throw new TypeError(
      'RBAC action must be a string.',
    );
  }


  const normalized =
    action
      .trim()
      .toLowerCase();


  if (
    ACTION_ALIASES[
      action
        .trim()
        .toUpperCase()
    ]
  ) {
    return ACTION_ALIASES[
      action
        .trim()
        .toUpperCase()
    ];
  }


  if (
    !RBAC_ACTIONS.includes(
      normalized,
    )
  ) {
    throw new TypeError(
      `Unsupported RBAC action "${action}". ` +
        `Allowed actions: ${RBAC_ACTIONS.join(', ')}`,
    );
  }


  return normalized;
}


/**
 * Normalize module identifier.
 */
export function normalizeModule(
  module,
) {
  if (
    typeof module !==
    'string'
  ) {
    throw new TypeError(
      'RBAC module must be a string.',
    );
  }


  const normalized =
    module
      .trim()
      .toLowerCase()
      .replace(
        /\s+/g,
        '_',
      )
      .replace(
        /[^a-z0-9_.-]/g,
        '_',
      );


  if (
    !normalized
  ) {
    throw new TypeError(
      'RBAC module cannot be empty.',
    );
  }


  return normalized;
}


/* -------------------------------------------------------------------------- */
/* Permission shapes                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Determine whether a value represents a truthy permission.
 */
function isPermissionEnabled(
  value,
) {
  return (
    value === true ||
    value === 1 ||
    value === '1' ||
    value === 'true' ||
    value === 'TRUE'
  );
}


/**
 * Normalize a permission object.
 *
 * Supported database forms:
 *
 * {
 *   canView: true,
 *   canAdd: true,
 *   canEdit: true,
 *   canDelete: false,
 *   canAll: false
 * }
 *
 * Or:
 *
 * {
 *   view: true,
 *   add: true,
 *   edit: true,
 *   delete: false,
 *   all: false
 * }
 */
export function normalizePermission(
  permission,
) {
  if (
    permission === null ||
    typeof permission !==
      'object'
  ) {
    return {
      view: false,
      add: false,
      edit: false,
      delete: false,
      all: false,
    };
  }


  const normalized = {
    view:
      isPermissionEnabled(
        permission.view ??
          permission.canView ??
          permission.VIEW,
      ),

    add:
      isPermissionEnabled(
        permission.add ??
          permission.canAdd ??
          permission.ADD,
      ),

    edit:
      isPermissionEnabled(
        permission.edit ??
          permission.canEdit ??
          permission.EDIT,
      ),

    delete:
      isPermissionEnabled(
        permission.delete ??
          permission.canDelete ??
          permission.DELETE,
      ),

    all:
      isPermissionEnabled(
        permission.all ??
          permission.canAll ??
          permission.ALL,
      ),
  };


  /**
   * ALL implies every CRUD capability.
   */
  if (
    normalized.all
  ) {
    normalized.view =
      true;

    normalized.add =
      true;

    normalized.edit =
      true;

    normalized.delete =
      true;
  }


  return normalized;
}


/* -------------------------------------------------------------------------- */
/* Permission collection                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Convert possible user permission structures into:
 *
 * Map<module, permissionObject>
 *
 * Supported shapes:
 *
 * 1. req.user.permissions = {
 *      company_settings: {
 *        view: true,
 *        edit: true
 *      }
 *    }
 *
 * 2. req.user.permissions = [
 *      {
 *        module: 'company_settings',
 *        canView: true,
 *        canEdit: true
 *      }
 *    ]
 *
 * 3. req.user.permissions = [
 *      {
 *        module: 'company_settings',
 *        permissions: {
 *          view: true
 *        }
 *      }
 *    ]
 */
export function normalizePermissionMap(
  permissions,
) {
  const map =
    new Map();


  if (
    !permissions
  ) {
    return map;
  }


  /* ------------------------------------------------------------------------ */
  /* Object form                                                              */
  /* ------------------------------------------------------------------------ */

  if (
    typeof permissions ===
      'object' &&
    !Array.isArray(
      permissions,
    )
  ) {
    for (
      const [
        module,
        permission,
      ] of Object.entries(
        permissions,
      )
    ) {
      map.set(
        normalizeModule(
          module,
        ),
        normalizePermission(
          permission,
        ),
      );
    }


    return map;
  }


  /* ------------------------------------------------------------------------ */
  /* Array form                                                               */
  /* ------------------------------------------------------------------------ */

  if (
    Array.isArray(
      permissions,
    )
  ) {
    for (
      const permissionEntry of permissions
    ) {
      if (
        !permissionEntry ||
        typeof permissionEntry !==
          'object'
      ) {
        continue;
      }


      const module =
        permissionEntry.module ||
        permissionEntry.moduleKey ||
        permissionEntry.moduleName ||
        permissionEntry.slug;


      if (
        !module
      ) {
        continue;
      }


      const actualPermission =
        permissionEntry.permissions ||
        permissionEntry;


      map.set(
        normalizeModule(
          module,
        ),
        normalizePermission(
          actualPermission,
        ),
      );
    }
  }


  return map;
}


/* -------------------------------------------------------------------------- */
/* User permission access                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Get a permission from the authenticated request user.
 *
 * Important:
 *
 * This first checks the authenticated context populated by auth.js.
 *
 * Later, when Role/Permission models are implemented, this middleware
 * can be changed to resolve permissions from MongoDB/cache without
 * changing route definitions.
 */
export function getUserPermission(
  req,
  module,
) {
  const normalizedModule =
    normalizeModule(
      module,
    );


  if (
    !req.user
  ) {
    return {
      view: false,
      add: false,
      edit: false,
      delete: false,
      all: false,
    };
  }


  const permissionMap =
    normalizePermissionMap(
      req.user.permissions,
    );


  return (
    permissionMap.get(
      normalizedModule,
    ) || {
      view: false,
      add: false,
      edit: false,
      delete: false,
      all: false,
    }
  );
}


/* -------------------------------------------------------------------------- */
/* Permission check                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Check whether the authenticated user can perform an action.
 */
export function hasPermission(
  req,
  {
    module,
    action,
  },
) {
  const normalizedModule =
    normalizeModule(
      module,
    );

  const normalizedAction =
    normalizeAction(
      action,
    );


  const permission =
    getUserPermission(
      req,
      normalizedModule,
    );


  if (
    permission.all
  ) {
    return true;
  }


  return (
    permission[
      normalizedAction
    ] === true
  );
}


/* -------------------------------------------------------------------------- */
/* Internal/system role helpers                                               */
/* -------------------------------------------------------------------------- */

/**
 * Normalize role identifier.
 */
export function normalizeRole(
  role,
) {
  if (
    typeof role !==
    'string'
  ) {
    return null;
  }


  return role
    .trim()
    .toLowerCase()
    .replace(
      /\s+/g,
      '_',
    );
}


/**
 * Get authenticated role identifier.
 */
export function getAuthenticatedRole(
  req,
) {
  return normalizeRole(
    req.user?.role,
  );
}


/**
 * Check role.
 */
export function hasRole(
  req,
  ...roles
) {
  const userRole =
    getAuthenticatedRole(
      req,
    );


  if (
    !userRole
  ) {
    return false;
  }


  const normalizedRoles =
    roles
      .map(
        normalizeRole,
      )
      .filter(Boolean);


  return normalizedRoles.includes(
    userRole,
  );
}


/* -------------------------------------------------------------------------- */
/* Realm protection                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Check whether the authenticated user belongs to an internal realm.
 */
export function isInternalRealm(
  req,
) {
  return (
    req.authRealm ===
      'admin' ||
    req.authRealm ===
      'internal'
  );
}


/**
 * Check whether the authenticated user belongs to vendor realm.
 */
export function isVendorRealm(
  req,
) {
  return (
    req.authRealm ===
    'vendor'
  );
}


/* -------------------------------------------------------------------------- */
/* Main RBAC middleware                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Create an RBAC middleware.
 *
 * Usage:
 *
 * router.patch(
 *   '/company',
 *
 *   authMiddleware,
 *
 *   rbacMiddleware({
 *     module: 'company_settings',
 *     action: 'edit'
 *   }),
 *
 *   controller
 * );
 *
 * Supported:
 *
 * view
 * add
 * edit
 * delete
 * all
 */
export function authorize({
  module,
  action,
  roles = [],
  realms = [],
  userTypes = [],
  allowSuperAdmin = true,
}) {
  const normalizedModule =
    normalizeModule(
      module,
    );


  const normalizedAction =
    normalizeAction(
      action,
    );


  const normalizedRoles =
    roles
      .map(
        normalizeRole,
      )
      .filter(Boolean);


  const normalizedRealms =
    realms
      .map(
        (realm) =>
          String(
            realm,
          )
            .trim()
            .toLowerCase(),
      )
      .filter(Boolean);


  const normalizedUserTypes =
    userTypes
      .map(
        (type) =>
          String(
            type,
          )
            .trim()
            .toLowerCase(),
      )
      .filter(Boolean);


  return (
    req,
    res,
    next,
  ) => {
    try {
      /* -------------------------------------------------------------------- */
      /* Authentication                                                       */
      /* -------------------------------------------------------------------- */

      if (
        !req.authenticated ||
        !req.user
      ) {
        throw new AuthenticationError(
          'Authentication is required.',
          {
            code:
              'AUTHENTICATION_REQUIRED',
            statusCode:
              401,
          },
        );
      }


      /* -------------------------------------------------------------------- */
      /* User type                                                             */
      /* -------------------------------------------------------------------- */

      if (
        normalizedUserTypes.length >
        0
      ) {
        const actualUserType =
          String(
            req.user.userType ||
              '',
          ).toLowerCase();


        if (
          !normalizedUserTypes.includes(
            actualUserType,
          )
        ) {
          throw new AuthorizationError(
            'Your account type cannot access this resource.',
            {
              code:
                'USER_TYPE_FORBIDDEN',
              statusCode:
                403,
            },
          );
        }
      }


      /* -------------------------------------------------------------------- */
      /* Realm                                                                 */
      /* -------------------------------------------------------------------- */

      if (
        normalizedRealms.length >
        0
      ) {
        const actualRealm =
          String(
            req.authRealm ||
              '',
          ).toLowerCase();


        if (
          !normalizedRealms.includes(
            actualRealm,
          )
        ) {
          throw new AuthorizationError(
            'Your application access level cannot access this resource.',
            {
              code:
                'AUTH_REALM_FORBIDDEN',
              statusCode:
                403,
            },
          );
        }
      }


      /* -------------------------------------------------------------------- */
      /* Explicit role allow-list                                              */
      /* -------------------------------------------------------------------- */

      if (
        normalizedRoles.length >
        0
      ) {
        const role =
          getAuthenticatedRole(
            req,
          );


        if (
          !normalizedRoles.includes(
            role,
          )
        ) {
          throw new AuthorizationError(
            'Your role cannot access this resource.',
            {
              code:
                'ROLE_FORBIDDEN',
              statusCode:
                403,
            },
          );
        }
      }


      /* -------------------------------------------------------------------- */
      /* Super-admin bypass                                                    */
      /* -------------------------------------------------------------------- */

      if (
        allowSuperAdmin &&
        isSuperAdmin(
          req,
        )
      ) {
        return next();
      }


      /* -------------------------------------------------------------------- */
      /* Permission                                                            */
      /* -------------------------------------------------------------------- */

      if (
        !hasPermission(
          req,
          {
            module:
              normalizedModule,

            action:
              normalizedAction,
          },
        )
      ) {
        throw new AuthorizationError(
          'You do not have permission to perform this action.',
          {
            code:
              'PERMISSION_DENIED',

            statusCode:
              403,

            details: {
              module:
                normalizedModule,

              action:
                normalizedAction,
            },
          },
        );
      }


      /* -------------------------------------------------------------------- */
      /* Successful authorization                                              */
      /* -------------------------------------------------------------------- */

      /**
       * Make the authorization decision available to audit
       * middleware/services without exposing permission maps.
       */
      req.authorization =
        Object.freeze({
          module:
            normalizedModule,

          action:
            normalizedAction,

          granted:
            true,
        });


      return next();
    } catch (error) {
      return handleAuthorizationError(
        error,
        req,
        res,
      );
    }
  };
}


/* -------------------------------------------------------------------------- */
/* Super admin                                                                */
/* -------------------------------------------------------------------------- */

/**
 * System-level override.
 *
 * This is intentionally narrow.
 *
 * "workspace_owner" is treated as the application owner.
 *
 * Actual role definition can later be made database-controlled,
 * but the system role remains available for emergency/bootstrap
 * access.
 */
export function isSuperAdmin(
  req,
) {
  const role =
    getAuthenticatedRole(
      req,
    );


  return (
    role ===
      SYSTEM_ROLES
        .WORKSPACE_OWNER ||
    role ===
      'super_admin' ||
    role ===
      'superadmin'
  );
}


/**
 * Middleware requiring super-admin privileges.
 */
export function requireSuperAdmin(
  req,
  res,
  next,
) {
  if (
    !req.authenticated ||
    !req.user
  ) {
    return res
      .status(401)
      .json({
        success:
          false,

        message:
          'Authentication is required.',

        code:
          'AUTHENTICATION_REQUIRED',

        requestId:
          req.requestId,
      });
  }


  if (
    !isSuperAdmin(
      req,
    )
  ) {
    return res
      .status(403)
      .json({
        success:
          false,

        message:
          'Workspace owner access is required.',

        code:
          'SUPER_ADMIN_REQUIRED',

        requestId:
          req.requestId,
      });
  }


  next();
}


/* -------------------------------------------------------------------------- */
/* Convenience middleware                                                     */
/* -------------------------------------------------------------------------- */

/**
 * VIEW
 */
export function canView(
  module,
) {
  return authorize({
    module,
    action:
      'view',
  });
}


/**
 * ADD
 */
export function canAdd(
  module,
) {
  return authorize({
    module,
    action:
      'add',
  });
}


/**
 * EDIT
 */
export function canEdit(
  module,
) {
  return authorize({
    module,
    action:
      'edit',
  });
}


/**
 * DELETE
 */
export function canDelete(
  module,
) {
  return authorize({
    module,
    action:
      'delete',
  });
}


/**
 * ALL
 */
export function canManage(
  module,
) {
  return authorize({
    module,
    action:
      'all',
  });
}


/**
 * Internal-only VIEW.
 */
export function internalCanView(
  module,
) {
  return authorize({
    module,

    action:
      'view',

    realms: [
      'admin',
      'internal',
    ],
  });
}


/**
 * Internal-only EDIT.
 */
export function internalCanEdit(
  module,
) {
  return authorize({
    module,

    action:
      'edit',

    realms: [
      'admin',
      'internal',
    ],
  });
}


/**
 * Vendor-only VIEW.
 */
export function vendorCanView(
  module,
) {
  return authorize({
    module,

    action:
      'view',

    realms: [
      'vendor',
    ],

    userTypes: [
      'vendor',
    ],

    allowSuperAdmin:
      false,
  });
}


/**
 * Vendor-only EDIT.
 */
export function vendorCanEdit(
  module,
) {
  return authorize({
    module,

    action:
      'edit',

    realms: [
      'vendor',
    ],

    userTypes: [
      'vendor',
    ],

    allowSuperAdmin:
      false,
  });
}


/* -------------------------------------------------------------------------- */
/* Ownership helpers                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Require the request to belong to the authenticated vendor.
 *
 * This prevents a vendor from changing:
 *
 * ?vendorId=anotherVendor
 *
 * or:
 *
 * {
 *   vendorId: anotherVendor
 * }
 *
 * Vendor identity comes only from the JWT.
 */
export function requireVendorOwnership(
  getVendorId,
) {
  if (
    typeof getVendorId !==
    'function'
  ) {
    throw new TypeError(
      'requireVendorOwnership requires a vendor ID resolver function.',
    );
  }


  return (
    req,
    res,
    next,
  ) => {
    if (
      !req.authenticated ||
      !req.user
    ) {
      return res
        .status(401)
        .json({
          success:
            false,

          message:
            'Authentication is required.',

          code:
            'AUTHENTICATION_REQUIRED',

          requestId:
            req.requestId,
        });
    }


    if (
      !isVendorRealm(
        req,
      )
    ) {
      return next();
    }


    const authenticatedVendorId =
      req.user.vendorId;


    if (
      !authenticatedVendorId
    ) {
      return res
        .status(403)
        .json({
          success:
            false,

          message:
            'Vendor account is not linked to a vendor profile.',

          code:
            'VENDOR_PROFILE_NOT_LINKED',

          requestId:
            req.requestId,
        });
    }


    const requestedVendorId =
      getVendorId(
        req,
      );


    if (
      !requestedVendorId
    ) {
      return res
        .status(400)
        .json({
          success:
            false,

          message:
            'Vendor context could not be determined.',

          code:
            'VENDOR_CONTEXT_MISSING',

          requestId:
            req.requestId,
        });
    }


    if (
      String(
        authenticatedVendorId,
      ) !==
      String(
        requestedVendorId,
      )
    ) {
      return res
        .status(403)
        .json({
          success:
            false,

          message:
            'You cannot access another vendor account.',

          code:
            'VENDOR_SCOPE_FORBIDDEN',

          requestId:
            req.requestId,
        });
    }


    next();
  };
}


/* -------------------------------------------------------------------------- */
/* Mongo ObjectId helper                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Validate a route MongoDB ID before it reaches a model query.
 */
export function requireValidObjectId(
  parameterName,
) {
  if (
    typeof parameterName !==
    'string' ||
    !parameterName.trim()
  ) {
    throw new TypeError(
      'MongoDB parameter name is required.',
    );
  }


  return (
    req,
    res,
    next,
  ) => {
    const value =
      req.params[
        parameterName
      ];


    if (
      !value ||
      !mongoose.isValidObjectId(
        value,
      )
    ) {
      return res
        .status(400)
        .json({
          success:
            false,

          message:
            `Invalid ${parameterName}.`,

          code:
            'INVALID_RESOURCE_ID',

          requestId:
            req.requestId,
        });
    }


    next();
  };
}


/* -------------------------------------------------------------------------- */
/* Authorization error handler                                                */
/* -------------------------------------------------------------------------- */

function handleAuthorizationError(
  error,
  req,
  res,
) {
  if (
    error instanceof
    AuthenticationError
  ) {
    return res
      .status(
        error.statusCode ||
          401,
      )
      .json({
        success:
          false,

        message:
          error.message,

        code:
          error.code,

        requestId:
          req.requestId,
      });
  }


  if (
    error instanceof
    AuthorizationError
  ) {
    /**
     * Do not expose permission matrices to the client.
     *
     * The UI only needs to know that the action is forbidden.
     */
    return res
      .status(
        error.statusCode ||
          403,
      )
      .json({
        success:
          false,

        message:
          error.message,

        code:
          error.code,

        requestId:
          req.requestId,
      });
  }


  console.error(
    '[RBAC] Unexpected authorization error:',
    error,
  );


  return res
    .status(500)
    .json({
      success:
        false,

      message:
        'Authorization service temporarily unavailable.',

      code:
        'AUTHORIZATION_INTERNAL_ERROR',

      requestId:
        req.requestId,
    });
}


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Default export intentionally represents the generic
 * authorize factory rather than a fixed permission.
 */
export default authorize;