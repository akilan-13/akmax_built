// src/middleware/auth.js

import jwt from 'jsonwebtoken';

import env from '../config/env.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const ACCESS_TOKEN_TYPE =
  'access';


const AUTH_HEADER_PREFIX =
  'Bearer';


const TOKEN_SOURCES =
  Object.freeze({
    HEADER:
      'header',

    COOKIE:
      'cookie',
  });


const USER_TYPES =
  Object.freeze({
    ADMIN:
      'admin',

    INTERNAL:
      'internal',

    VENDOR:
      'vendor',
  });


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class AuthenticationError extends Error {
  constructor(
    message = 'Authentication required.',
    {
      code =
        'AUTHENTICATION_REQUIRED',
      statusCode =
        401,
    } = {},
  ) {
    super(message);

    this.name =
      'AuthenticationError';

    this.code =
      code;

    this.statusCode =
      statusCode;

    Error.captureStackTrace?.(
      this,
      AuthenticationError,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Token extraction                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Extract Bearer token from Authorization header.
 */
function getBearerToken(
  req,
) {
  const authorization =
    req.get(
      'authorization',
    );


  if (
    !authorization
  ) {
    return null;
  }


  const parts =
    authorization.trim()
      .split(/\s+/);


  if (
    parts.length !==
    2
  ) {
    throw new AuthenticationError(
      'Invalid Authorization header.',
      {
        code:
          'INVALID_AUTHORIZATION_HEADER',
      },
    );
  }


  if (
    parts[0] !==
    AUTH_HEADER_PREFIX
  ) {
    throw new AuthenticationError(
      'Authorization header must use Bearer authentication.',
      {
        code:
          'INVALID_AUTHORIZATION_SCHEME',
      },
    );
  }


  const token =
    parts[1].trim();


  if (
    !token
  ) {
    throw new AuthenticationError(
      'Authentication token is missing.',
      {
        code:
          'AUTHENTICATION_TOKEN_MISSING',
      },
    );
  }


  return {
    token,

    source:
      TOKEN_SOURCES.HEADER,
  };
}


/**
 * Extract access token from the secure cookie.
 *
 * Cookie name can be changed later without changing the
 * rest of the authentication system.
 */
function getCookieToken(
  req,
) {
  if (
    !req.cookies
  ) {
    return null;
  }


  const token =
    req.cookies.argus_access_token;


  if (
    !token ||
    typeof token !==
      'string'
  ) {
    return null;
  }


  return {
    token:
      token.trim(),

    source:
      TOKEN_SOURCES.COOKIE,
  };
}


/**
 * Resolve the token source.
 *
 * Authorization header takes precedence over cookie.
 */
function extractAccessToken(
  req,
) {
  const headerToken =
    getBearerToken(
      req,
    );


  if (
    headerToken
  ) {
    return headerToken;
  }


  const cookieToken =
    getCookieToken(
      req,
    );


  if (
    cookieToken
  ) {
    return cookieToken;
  }


  throw new AuthenticationError(
    'Authentication token is required.',
    {
      code:
        'AUTHENTICATION_TOKEN_REQUIRED',
    },
  );
}


/* -------------------------------------------------------------------------- */
/* JWT validation                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Verify the access JWT.
 *
 * Important:
 * - Only access tokens are accepted.
 * - Issuer and audience are verified.
 * - Algorithm is explicitly restricted.
 */
function verifyAccessToken(
  token,
) {
  try {
    const payload =
      jwt.verify(
        token,
        env.jwt.access.secret,
        {
          algorithms: [
            'HS256',
          ],

          issuer:
            env.jwt.issuer,

          audience:
            env.jwt.audience,

          clockTolerance:
            5,
        },
      );


    if (
      !payload ||
      typeof payload !==
        'object'
    ) {
      throw new AuthenticationError(
        'Invalid authentication token.',
        {
          code:
            'INVALID_ACCESS_TOKEN',
        },
      );
    }


    /**
     * Access-token type check.
     *
     * Our login service will issue:
     *
     * type: "access"
     */
    if (
      payload.type !==
      ACCESS_TOKEN_TYPE
    ) {
      throw new AuthenticationError(
        'Invalid access token type.',
        {
          code:
            'INVALID_ACCESS_TOKEN_TYPE',
        },
      );
    }


    /**
     * Subject must exist.
     */
    if (
      !payload.sub
    ) {
      throw new AuthenticationError(
        'Authentication token does not identify a user.',
        {
          code:
            'INVALID_ACCESS_TOKEN_SUBJECT',
        },
      );
    }


    /**
     * User type must exist.
     */
    if (
      !payload.userType
    ) {
      throw new AuthenticationError(
        'Authentication token does not contain a valid user type.',
        {
          code:
            'INVALID_ACCESS_TOKEN_USER_TYPE',
        },
      );
    }


    if (
      !Object.values(
        USER_TYPES,
      ).includes(
        payload.userType,
      )
    ) {
      throw new AuthenticationError(
        'Authentication token contains an invalid user type.',
        {
          code:
            'INVALID_ACCESS_TOKEN_USER_TYPE',
        },
      );
    }


    return payload;
  } catch (error) {
    /**
     * Preserve our own authentication errors.
     */
    if (
      error instanceof
      AuthenticationError
    ) {
      throw error;
    }


    /**
     * JWT expiration.
     */
    if (
      error?.name ===
      'TokenExpiredError'
    ) {
      throw new AuthenticationError(
        'Your session has expired. Please sign in again.',
        {
          code:
            'ACCESS_TOKEN_EXPIRED',
        },
      );
    }


    /**
     * Invalid token.
     */
    if (
      error?.name ===
        'JsonWebTokenError' ||
      error?.name ===
        'NotBeforeError'
    ) {
      throw new AuthenticationError(
        'Invalid authentication token.',
        {
          code:
            'INVALID_ACCESS_TOKEN',
        },
      );
    }


    throw new AuthenticationError(
      'Authentication failed.',
      {
        code:
          'AUTHENTICATION_FAILED',
      },
    );
  }
}


/* -------------------------------------------------------------------------- */
/* User context                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Build the trusted request user object.
 *
 * IMPORTANT:
 * Do not copy arbitrary JWT fields into req.user.
 *
 * Only known fields are propagated.
 */
function buildUserContext(
  payload,
  {
    tokenSource,
  },
) {
  const user = {
    id:
      String(
        payload.sub,
      ),

    userType:
      payload.userType,

    roleId:
      payload.roleId
        ? String(
            payload.roleId,
          )
        : null,

    role:
      payload.role ||
      null,

    vendorId:
      payload.vendorId
        ? String(
            payload.vendorId,
          )
        : null,

    sessionId:
      payload.sessionId
        ? String(
            payload.sessionId,
          )
        : null,

    tokenType:
      payload.type,

    tokenSource,

    authenticatedAt:
      payload.iat
        ? new Date(
            payload.iat *
              1000,
          )
        : null,

    expiresAt:
      payload.exp
        ? new Date(
            payload.exp *
              1000,
          )
        : null,
  };


  /**
   * Freeze the identity context so downstream middleware
   * cannot accidentally mutate authentication claims.
   */
  return Object.freeze(
    user,
  );
}


/* -------------------------------------------------------------------------- */
/* Realm detection                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Determine which application realm authenticated the user.
 *
 * Admin/internal:
 * - admin
 * - internal
 *
 * Vendor:
 * - vendor
 */
function resolveRealm(
  userType,
) {
  switch (
    userType
  ) {
    case USER_TYPES.ADMIN:
    case USER_TYPES.INTERNAL:
      return env.auth.realms.admin;


    case USER_TYPES.VENDOR:
      return env.auth.realms.vendor;


    default:
      throw new AuthenticationError(
        'Invalid authentication realm.',
        {
          code:
            'INVALID_AUTH_REALM',
        },
      );
  }
}


/* -------------------------------------------------------------------------- */
/* Main authentication middleware                                             */
/* -------------------------------------------------------------------------- */

/**
 * Authenticate an incoming API request.
 *
 * Usage:
 *
 * router.get(
 *   '/company',
 *   authMiddleware,
 *   ...
 * );
 */
export async function authenticate(
  req,
  res,
  next,
) {
  try {
    const tokenInfo =
      extractAccessToken(
        req,
      );


    const payload =
      verifyAccessToken(
        tokenInfo.token,
      );


    const user =
      buildUserContext(
        payload,
        {
          tokenSource:
            tokenInfo.source,
        },
      );


    /**
     * Attach trusted authentication context.
     */
    req.user =
      user;


    /**
     * Attach realm for easy downstream checks.
     */
    req.authRealm =
      resolveRealm(
        user.userType,
      );


    /**
     * Expose only whether authentication exists.
     *
     * Never expose the raw access token.
     */
    req.authenticated =
      true;


    next();
  } catch (error) {
    return handleAuthenticationError(
      error,
      req,
      res,
    );
  }
}


/* -------------------------------------------------------------------------- */
/* Authentication error handler                                               */
/* -------------------------------------------------------------------------- */

function handleAuthenticationError(
  error,
  req,
  res,
) {
  if (
    error instanceof
    AuthenticationError
  ) {
    /**
     * 401 responses should not reveal whether:
     * - email exists
     * - user exists
     * - account is active
     * - token exists in database
     *
     * Those details stay inside authentication services.
     */
    return res
      .status(
        error.statusCode ||
          401,
      )
      .json({
        success:
          false,

        message:
          error.message,

        code:
          error.code,

        requestId:
          req.requestId,
      });
  }


  console.error(
    '[AUTH] Unexpected authentication middleware error:',
    error,
  );


  return res
    .status(500)
    .json({
      success:
        false,

      message:
        'Authentication service temporarily unavailable.',

      code:
        'AUTHENTICATION_INTERNAL_ERROR',

      requestId:
        req.requestId,
    });
}


/* -------------------------------------------------------------------------- */
/* Optional authentication                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Attempt authentication without requiring it.
 *
 * Useful later for:
 * - public health/resource metadata
 * - mixed public/private routes
 * - invitation flows
 *
 * It never throws just because a token is absent.
 */
export async function optionalAuthenticate(
  req,
  res,
  next,
) {
  try {
    let tokenInfo;


    try {
      tokenInfo =
        extractAccessToken(
          req,
        );
    } catch {
      req.user =
        null;

      req.authenticated =
        false;

      return next();
    }


    const payload =
      verifyAccessToken(
        tokenInfo.token,
      );


    const user =
      buildUserContext(
        payload,
        {
          tokenSource:
            tokenInfo.source,
        },
      );


    req.user =
      user;

    req.authRealm =
      resolveRealm(
        user.userType,
      );

    req.authenticated =
      true;


    next();
  } catch {
    /**
     * For optional authentication, an invalid token is still
     * treated as unauthenticated rather than exposing token
     * parsing details to the caller.
     */
    req.user =
      null;

    req.authenticated =
      false;

    next();
  }
}


/* -------------------------------------------------------------------------- */
/* Realm middleware                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Require one of the specified authentication realms.
 *
 * Example:
 *
 * requireRealm('admin')
 *
 * or:
 *
 * requireRealm('admin', 'internal')
 */
export function requireRealm(
  ...allowedRealms
) {
  const allowed =
    new Set(
      allowedRealms,
    );


  return (
    req,
    res,
    next,
  ) => {
    if (
      !req.authenticated ||
      !req.user
    ) {
      return res
        .status(401)
        .json({
          success:
            false,

          message:
            'Authentication is required.',

          code:
            'AUTHENTICATION_REQUIRED',

          requestId:
            req.requestId,
        });
    }


    if (
      !allowed.has(
        req.authRealm,
      )
    ) {
      return res
        .status(403)
        .json({
          success:
            false,

          message:
            'You do not have access to this application area.',

          code:
            'AUTH_REALM_FORBIDDEN',

          requestId:
            req.requestId,
        });
    }


    next();
  };
}


/* -------------------------------------------------------------------------- */
/* User-type middleware                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Require a specific user type.
 *
 * Example:
 *
 * requireUserType('vendor')
 */
export function requireUserType(
  ...allowedUserTypes
) {
  const allowed =
    new Set(
      allowedUserTypes,
    );


  return (
    req,
    res,
    next,
  ) => {
    if (
      !req.authenticated ||
      !req.user
    ) {
      return res
        .status(401)
        .json({
          success:
            false,

          message:
            'Authentication is required.',

          code:
            'AUTHENTICATION_REQUIRED',

          requestId:
            req.requestId,
        });
    }


    if (
      !allowed.has(
        req.user.userType,
      )
    ) {
      return res
        .status(403)
        .json({
          success:
            false,

          message:
            'Your account type cannot access this resource.',

          code:
            'USER_TYPE_FORBIDDEN',

          requestId:
            req.requestId,
        });
    }


    next();
  };
}


/* -------------------------------------------------------------------------- */
/* Admin/internal helpers                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Require admin/internal authentication.
 */
export const requireInternalUser =
  requireRealm(
    env.auth.realms.admin,
  );


/**
 * Require vendor authentication.
 */
export const requireVendorUser =
  requireRealm(
    env.auth.realms.vendor,
  );


/* -------------------------------------------------------------------------- */
/* Authentication utilities                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Extract the authenticated user's ID.
 */
export function getAuthenticatedUserId(
  req,
) {
  return (
    req.user?.id ||
    null
  );
}


/**
 * Extract vendor ID from authenticated context.
 *
 * Never accept vendorId from request body for identity/scoping.
 */
export function getAuthenticatedVendorId(
  req,
) {
  return (
    req.user?.vendorId ||
    null
  );
}


/**
 * Check whether request is authenticated.
 */
export function isAuthenticated(
  req,
) {
  return (
    req.authenticated === true &&
    Boolean(
      req.user,
    )
  );
}


/**
 * Check whether authenticated user belongs to the vendor realm.
 */
export function isVendorUser(
  req,
) {
  return (
    req.user?.userType ===
    USER_TYPES.VENDOR
  );
}


/**
 * Check whether authenticated user belongs to the internal realm.
 */
export function isInternalUser(
  req,
) {
  return (
    req.user?.userType ===
      USER_TYPES.ADMIN ||
    req.user?.userType ===
      USER_TYPES.INTERNAL
  );
}


/* -------------------------------------------------------------------------- */
/* Token utility                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Verify an access token without requiring an Express request.
 *
 * Useful later for:
 * - websocket authentication
 * - background workers
 * - download URLs
 * - tests
 */
export function verifyToken(
  token,
) {
  return verifyAccessToken(
    token,
  );
}


/* -------------------------------------------------------------------------- */
/* Export constants                                                           */
/* -------------------------------------------------------------------------- */

export {
  USER_TYPES,
  TOKEN_SOURCES,
};


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

export default authenticate;