import { AppError } from '../utils/AppError.js';
export const requireVendorScope = (vendorIdFromParam = 'vendorId') => (req, _res, next) => {
  if (req.user?.userType !== 'vendor') return next();
  if (String(req.user.vendorId) !== String(req.params[vendorIdFromParam])) return next(new AppError('Vendor resource is outside your scope', 403, 'VENDOR_SCOPE_DENIED'));
  next();
};
