// ARGUS data model contract for AuditLog.
// SQL is authoritative; service layer owns transaction/query rules.
export const AuditLog = Object.freeze({ table: 'AuditLog' });
