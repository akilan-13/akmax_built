// ARGUS data model contract for Invoice.
// SQL is authoritative; service layer owns transaction/query rules.
export const Invoice = Object.freeze({ table: 'Invoice' });
