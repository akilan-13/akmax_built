// ARGUS data model contract for Role.
// SQL is authoritative; service layer owns transaction/query rules.
export const Role = Object.freeze({ table: 'Role' });
