// ARGUS data model contract for VendorCurrency.
// SQL is authoritative; service layer owns transaction/query rules.
export const VendorCurrency = Object.freeze({ table: 'VendorCurrency' });
