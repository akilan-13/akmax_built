// ARGUS data model contract for Award.
// SQL is authoritative; service layer owns transaction/query rules.
export const Award = Object.freeze({ table: 'Award' });
