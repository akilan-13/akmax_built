// ARGUS data model contract for VendorCategory.
// SQL is authoritative; service layer owns transaction/query rules.
export const VendorCategory = Object.freeze({ table: 'VendorCategory' });
