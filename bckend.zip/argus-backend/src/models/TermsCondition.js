// ARGUS data model contract for TermsCondition.
// SQL is authoritative; service layer owns transaction/query rules.
export const TermsCondition = Object.freeze({ table: 'TermsCondition' });
