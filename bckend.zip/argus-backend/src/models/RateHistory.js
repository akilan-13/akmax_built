// ARGUS data model contract for RateHistory.
// SQL is authoritative; service layer owns transaction/query rules.
export const RateHistory = Object.freeze({ table: 'RateHistory' });
