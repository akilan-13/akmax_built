// ARGUS data model contract for VendorPaymentTerm.
// SQL is authoritative; service layer owns transaction/query rules.
export const VendorPaymentTerm = Object.freeze({ table: 'VendorPaymentTerm' });
