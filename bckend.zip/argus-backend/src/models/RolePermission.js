// ARGUS data model contract for RolePermission.
// SQL is authoritative; service layer owns transaction/query rules.
export const RolePermission = Object.freeze({ table: 'RolePermission' });
