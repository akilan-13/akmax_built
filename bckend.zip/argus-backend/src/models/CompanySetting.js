// src/models/CompanySetting.js

import mongoose from 'mongoose';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * ARGUS currently operates as a single company profile.
 *
 * Using a deterministic key makes the document a singleton
 * without relying on "find the first document" logic.
 */
export const COMPANY_SETTING_KEY =
  'ARGUS_PRIMARY_COMPANY_PROFILE';


/**
 * Allowed company logo formats.
 *
 * Actual MIME/file validation will also happen inside
 * the upload middleware/service layer.
 */
const LOGO_MIME_TYPES = Object.freeze([
  'image/png',
  'image/jpeg',
  'image/webp',
]);


/**
 * Allowed favicon formats.
 */
const FAVICON_MIME_TYPES = Object.freeze([
  'image/png',
  'image/x-icon',
  'image/vnd.microsoft.icon',
  'image/svg+xml',
]);


/* -------------------------------------------------------------------------- */
/* Reusable file metadata schema                                               */
/* -------------------------------------------------------------------------- */

/**
 * Metadata is stored in MongoDB.
 *
 * The actual file bytes are stored on the local filesystem.
 *
 * Example:
 *
 * storage/private/company/logo/...
 *
 * MongoDB stores only metadata and the protected storage key.
 */
const fileMetadataSchema =
  new mongoose.Schema(
    {
      originalName: {
        type: String,
        trim: true,
        maxlength: 255,
      },

      storageKey: {
        type: String,
        required: true,
        trim: true,
        maxlength: 500,
      },

      relativePath: {
        type: String,
        required: true,
        trim: true,
        maxlength: 1000,
      },

      mimeType: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        maxlength: 150,
      },

      extension: {
        type: String,
        trim: true,
        lowercase: true,
        maxlength: 20,
      },

      size: {
        type: Number,
        required: true,
        min: 0,
        max: 104857600,
      },

      checksum: {
        type: String,
        trim: true,
        maxlength: 128,
      },

      uploadedAt: {
        type: Date,
        default: Date.now,
      },

      uploadedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },
    },

    {
      _id: false,
      id: false,
      versionKey: false,
    },
  );


/* -------------------------------------------------------------------------- */
/* Company Settings Schema                                                    */
/* -------------------------------------------------------------------------- */

const companySettingSchema =
  new mongoose.Schema(
    {
      /**
       * Deterministic singleton identifier.
       */
      settingKey: {
        type: String,
        required: true,
        unique: true,
        immutable: true,
        default:
          COMPANY_SETTING_KEY,
        trim: true,
        index: true,
      },


      /* -------------------------------------------------------------------- */
      /* Company identity                                                     */
      /* -------------------------------------------------------------------- */

      legalName: {
        type: String,
        required: true,
        trim: true,
        minlength: 2,
        maxlength: 200,
      },


      /**
       * Tax ID / VAT number from the UI.
       */
      taxId: {
        type: String,
        required: true,
        trim: true,
        maxlength: 100,
      },


      /* -------------------------------------------------------------------- */
      /* Contact information                                                  */
      /* -------------------------------------------------------------------- */

      contactEmail: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        maxlength: 254,
      },


      supportPhone: {
        type: String,
        trim: true,
        maxlength: 50,
        default: '',
      },


      /* -------------------------------------------------------------------- */
      /* Address                                                              */
      /* -------------------------------------------------------------------- */

      headquartersAddress: {
        type: String,
        required: true,
        trim: true,
        maxlength: 2000,
      },


      /* -------------------------------------------------------------------- */
      /* Branding                                                             */
      /* -------------------------------------------------------------------- */

      logo: {
        type: fileMetadataSchema,
        default: null,
      },


      favicon: {
        type: fileMetadataSchema,
        default: null,
      },


      /* -------------------------------------------------------------------- */
      /* Status                                                               */
      /* -------------------------------------------------------------------- */

      active: {
        type: Boolean,
        default: true,
        index: true,
      },


      /* -------------------------------------------------------------------- */
      /* Auditing                                                             */
      /* -------------------------------------------------------------------- */

      createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },


      updatedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },
    },

    {
      timestamps: true,

      collection:
        'company_settings',

      versionKey: true,

      strict: 'throw',
    },
  );


/* -------------------------------------------------------------------------- */
/* Schema indexes                                                             */
/* -------------------------------------------------------------------------- */

/**
 * The singleton key is unique.
 */
companySettingSchema.index(
  {
    settingKey: 1,
  },
  {
    unique: true,
    name:
      'uq_company_settings_setting_key',
  },
);


/**
 * Useful for health/readiness/configuration queries.
 */
companySettingSchema.index(
  {
    active: 1,
  },
  {
    name:
      'idx_company_settings_active',
  },
);


/* -------------------------------------------------------------------------- */
/* Normalization                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Normalize email before validation/storage.
 */
companySettingSchema.pre(
  'validate',
  function normalizeCompanySettings(next) {
    if (this.contactEmail) {
      this.contactEmail =
        this.contactEmail
          .trim()
          .toLowerCase();
    }

    if (this.legalName) {
      this.legalName =
        this.legalName.trim();
    }

    if (this.taxId) {
      this.taxId =
        this.taxId.trim();
    }

    if (this.supportPhone) {
      this.supportPhone =
        this.supportPhone.trim();
    }

    if (this.headquartersAddress) {
      this.headquartersAddress =
        this.headquartersAddress.trim();
    }

    next();
  },
);


/* -------------------------------------------------------------------------- */
/* JSON transformation                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Never expose internal Mongoose implementation details.
 *
 * File metadata is returned, but the actual local filesystem path
 * is NOT intended to be directly used by the browser.
 *
 * The API controller will later convert storageKey into a
 * protected download URL.
 */
companySettingSchema.set(
  'toJSON',
  {
    virtuals: true,

    transform(_document, returnedObject) {
      delete returnedObject._id;
      delete returnedObject.__v;

      /**
       * Do not expose local filesystem internals.
       */
      if (returnedObject.logo) {
        delete returnedObject.logo.relativePath;
        delete returnedObject.logo.storageKey;
      }

      if (returnedObject.favicon) {
        delete returnedObject.favicon.relativePath;
        delete returnedObject.favicon.storageKey;
      }

      return returnedObject;
    },
  },
);


/* -------------------------------------------------------------------------- */
/* Static helpers                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Get the singleton Company Settings document.
 *
 * Creates it only when explicitly requested.
 */
companySettingSchema.statics.getSingleton =
  async function getSingleton() {
    return this.findOne({
      settingKey:
        COMPANY_SETTING_KEY,
    });
  };


/**
 * Get or create the singleton company profile.
 *
 * This method should normally be called by the
 * Company Settings service rather than controllers.
 */
companySettingSchema.statics.getOrCreateSingleton =
  async function getOrCreateSingleton({
    createdBy = null,
  } = {}) {
    const existing =
      await this.findOne({
        settingKey:
          COMPANY_SETTING_KEY,
      });


    if (existing) {
      return existing;
    }


    /**
     * The actual business-required company values should
     * normally be provided during first setup.
     *
     * These placeholders are deliberately not returned
     * to users as a completed production profile.
     */
    const company =
      new this({
        settingKey:
          COMPANY_SETTING_KEY,

        legalName:
          'ARGUS',

        taxId:
          'NOT_CONFIGURED',

        contactEmail:
          'not-configured@example.invalid',

        supportPhone:
          '',

        headquartersAddress:
          'Not configured',

        active:
          true,

        createdBy:
          createdBy || null,

        updatedBy:
          createdBy || null,
      });


    await company.save();

    return company;
  };


/**
 * Update the audit user without modifying the profile data.
 */
companySettingSchema.methods.setUpdatedBy =
  function setUpdatedBy(userId) {
    this.updatedBy =
      userId || null;

    return this;
  };


/* -------------------------------------------------------------------------- */
/* Model                                                                     */
/* -------------------------------------------------------------------------- */

const CompanySetting =
  mongoose.model(
    'CompanySetting',
    companySettingSchema,
  );


export {
  LOGO_MIME_TYPES,
  FAVICON_MIME_TYPES,
};


export default CompanySetting;