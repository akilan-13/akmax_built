// ARGUS data model contract for Permission.
// SQL is authoritative; service layer owns transaction/query rules.
export const Permission = Object.freeze({ table: 'Permission' });
