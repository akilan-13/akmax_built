// ARGUS data model contract for MarketRateItem.
// SQL is authoritative; service layer owns transaction/query rules.
export const MarketRateItem = Object.freeze({ table: 'MarketRateItem' });
