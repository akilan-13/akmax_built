// ARGUS data model contract for User.
// SQL is authoritative; service layer owns transaction/query rules.
export const User = Object.freeze({ table: 'User' });
