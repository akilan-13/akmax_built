// ARGUS data model contract for SurveyTemplate.
// SQL is authoritative; service layer owns transaction/query rules.
export const SurveyTemplate = Object.freeze({ table: 'SurveyTemplate' });
