// src/services/settingsService.js

import api from './api';

/**
 * ARGUS Settings Service
 *
 * Backend base:
 *   /api/v1/settings
 *
 * Company Profile:
 *   GET    /company
 *   PATCH  /company
 *
 * Company Logo:
 *   POST   /company/logo
 *   DELETE /company/logo
 *   GET    /company/logo
 *   GET    /company/logo/download
 *
 * Company Favicon:
 *   POST   /company/favicon
 *   DELETE /company/favicon
 *   GET    /company/favicon
 *   GET    /company/favicon/download
 *
 * Company Status:
 *   PATCH  /company/status
 *
 * IMPORTANT:
 * - Do not expose local storage paths to React.
 * - Files are accessed through protected backend routes.
 * - Uploads use multipart/form-data.
 * - Do not manually set Content-Type for FormData when using Axios;
 *   the browser/Axios adapter will add the correct multipart boundary.
 */

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Extract a useful message from a backend Axios error.
 */
function getErrorMessage(error, fallback = 'Something went wrong.') {
  const responseData = error?.response?.data;

  return (
    responseData?.message ||
    responseData?.error?.message ||
    error?.message ||
    fallback
  );
}

/**
 * Normalize backend API response.
 *
 * Supports:
 *   { success, data }
 *   { status, data }
 *   raw data
 */
function getResponseData(response) {
  const payload = response?.data;

  if (
    payload &&
    typeof payload === 'object' &&
    Object.prototype.hasOwnProperty.call(payload, 'data')
  ) {
    return payload.data;
  }

  return payload;
}

/**
 * Convert any thrown error into a consistent Error object.
 */
function normalizeError(error, fallbackMessage) {
  const normalized = new Error(
    getErrorMessage(error, fallbackMessage),
  );

  normalized.status = error?.response?.status;
  normalized.code =
    error?.response?.data?.code ||
    error?.response?.data?.error?.code ||
    error?.code;

  normalized.response = error?.response;

  return normalized;
}

/**
 * Ensure a file is actually provided.
 */
function assertFile(file, fieldName = 'file') {
  if (!(file instanceof File)) {
    throw new Error(`Please select a valid ${fieldName}.`);
  }
}

/**
 * Build multipart payload.
 *
 * The backend receives the actual binary file under `file`.
 */
function buildFileFormData(file) {
  const formData = new FormData();

  formData.append('file', file);

  return formData;
}

/**
 * Prevent accidental method misuse.
 */
function assertBoolean(value, fieldName) {
  if (typeof value !== 'boolean') {
    throw new Error(`${fieldName} must be true or false.`);
  }
}

/* -------------------------------------------------------------------------- */
/* Company Profile                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Fetch Company Information.
 *
 * GET /settings/company
 */
export async function getCompanyProfile() {
  try {
    const response = await api.get('/settings/company');

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to load company information.',
    );
  }
}

/**
 * Update Company Information.
 *
 * PATCH /settings/company
 *
 * Backend accepts the frontend-friendly field names too:
 *   companyName
 *   taxNumber
 *   email
 *   phone
 *   address
 *
 * It also supports backend names:
 *   legalName
 *   taxId
 *   contactEmail
 *   supportPhone
 *   headquartersAddress
 *
 * We keep the frontend contract consistent with the existing
 * Company Information form.
 */
export async function updateCompanyProfile(values) {
  if (!values || typeof values !== 'object') {
    throw new Error('Company information is required.');
  }

  const payload = {
    companyName:
      values.companyName ??
      values.legalName ??
      '',

    taxNumber:
      values.taxNumber ??
      values.taxId ??
      '',

    email:
      values.email ??
      values.contactEmail ??
      '',

    phone:
      values.phone ??
      values.supportPhone ??
      '',

    address:
      values.address ??
      values.headquartersAddress ??
      '',
  };

  try {
    const response = await api.patch(
      '/settings/company',
      payload,
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to save company information.',
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Company Logo                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Upload company logo.
 *
 * POST /settings/company/logo
 */
export async function uploadCompanyLogo(file) {
  assertFile(file, 'company logo');

  const formData = buildFileFormData(file);

  try {
    const response = await api.post(
      '/settings/company/logo',
      formData,
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to upload company logo.',
    );
  }
}

/**
 * Delete company logo.
 *
 * DELETE /settings/company/logo
 */
export async function deleteCompanyLogo() {
  try {
    const response = await api.delete(
      '/settings/company/logo',
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to remove company logo.',
    );
  }
}

/**
 * Get the protected company logo URL.
 *
 * IMPORTANT:
 * This is intentionally the backend endpoint, NOT a
 * filesystem/storage URL.
 */
export function getCompanyLogoUrl() {
  return api.getUri({
    url: '/settings/company/logo',
  });
}

/**
 * Get company logo download endpoint.
 */
export function getCompanyLogoDownloadUrl() {
  return api.getUri({
    url: '/settings/company/logo/download',
  });
}

/**
 * Fetch company logo as a Blob.
 *
 * Useful when the Axios instance uses Bearer authentication
 * and the browser <img src=""> cannot automatically attach
 * the Authorization header.
 */
export async function fetchCompanyLogoBlob() {
  try {
    const response = await api.get(
      '/settings/company/logo',
      {
        responseType: 'blob',
      },
    );

    return response.data;
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to load company logo.',
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Company Favicon                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Upload company favicon.
 *
 * POST /settings/company/favicon
 */
export async function uploadCompanyFavicon(file) {
  assertFile(file, 'company favicon');

  const formData = buildFileFormData(file);

  try {
    const response = await api.post(
      '/settings/company/favicon',
      formData,
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to upload company favicon.',
    );
  }
}

/**
 * Delete company favicon.
 *
 * DELETE /settings/company/favicon
 */
export async function deleteCompanyFavicon() {
  try {
    const response = await api.delete(
      '/settings/company/favicon',
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to remove company favicon.',
    );
  }
}

/**
 * Get protected favicon URL.
 */
export function getCompanyFaviconUrl() {
  return api.getUri({
    url: '/settings/company/favicon',
  });
}

/**
 * Get favicon download endpoint.
 */
export function getCompanyFaviconDownloadUrl() {
  return api.getUri({
    url: '/settings/company/favicon/download',
  });
}

/**
 * Fetch favicon as Blob.
 */
export async function fetchCompanyFaviconBlob() {
  try {
    const response = await api.get(
      '/settings/company/favicon',
      {
        responseType: 'blob',
      },
    );

    return response.data;
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to load company favicon.',
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Company Status                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Change Company Profile active state.
 *
 * PATCH /settings/company/status
 */
export async function updateCompanyStatus(active) {
  assertBoolean(active, 'Company status');

  try {
    const response = await api.patch(
      '/settings/company/status',
      {
        active,
      },
    );

    return getResponseData(response);
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to update company status.',
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Convenience Methods                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Save company profile + optionally upload logo/favicon.
 *
 * This is useful from the CompanyInformation screen because
 * the user can click a single Save button after editing the
 * entire company profile.
 *
 * Files are uploaded only when they are actually provided.
 */
export async function saveCompanyInformation({
  values,
  logoFile = null,
  faviconFile = null,
}) {
  try {
    const profile = await updateCompanyProfile(values);

    let logo = null;
    let favicon = null;

    if (logoFile) {
      logo = await uploadCompanyLogo(logoFile);
    }

    if (faviconFile) {
      favicon = await uploadCompanyFavicon(faviconFile);
    }

    return {
      profile,
      logo,
      favicon,
    };
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to save company information.',
    );
  }
}

/**
 * Remove selected company assets.
 *
 * Example:
 *   removeCompanyAssets({
 *     logo: true,
 *     favicon: false,
 *   })
 */
export async function removeCompanyAssets({
  logo = false,
  favicon = false,
} = {}) {
  const operations = [];

  if (logo === true) {
    operations.push(deleteCompanyLogo());
  }

  if (favicon === true) {
    operations.push(deleteCompanyFavicon());
  }

  if (!operations.length) {
    return {
      logo: null,
      favicon: null,
    };
  }

  try {
    const results = await Promise.all(operations);

    let index = 0;

    return {
      logo:
        logo === true
          ? results[index++]
          : null,

      favicon:
        favicon === true
          ? results[index]
          : null,
    };
  } catch (error) {
    throw normalizeError(
      error,
      'Unable to remove company assets.',
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Default Service Object                                                     */
/* -------------------------------------------------------------------------- */

const settingsService = {
  getCompanyProfile,
  updateCompanyProfile,

  uploadCompanyLogo,
  deleteCompanyLogo,
  getCompanyLogoUrl,
  getCompanyLogoDownloadUrl,
  fetchCompanyLogoBlob,

  uploadCompanyFavicon,
  deleteCompanyFavicon,
  getCompanyFaviconUrl,
  getCompanyFaviconDownloadUrl,
  fetchCompanyFaviconBlob,

  updateCompanyStatus,

  saveCompanyInformation,
  removeCompanyAssets,
};

export default settingsService;