// Business-logic boundary: authService.js
// Keep HTTP concerns in controllers and perform multi-step writes in PostgreSQL transactions.
export const serviceName = 'authService';
