export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
export const lineTotal = (qty, rate) => round2(Number(qty) * Number(rate));
export const total = (values) => round2(values.reduce((s, v) => s + Number(v || 0), 0));
export const variance = (vendorRate, masterRate) => ({ difference: round2(Number(vendorRate) - Number(masterRate)), percentage: Number(masterRate) === 0 ? null : round2(((Number(vendorRate) - Number(masterRate)) / Number(masterRate)) * 100) });
export const utilization = (used, allocation) => allocation === 0 ? 0 : round2((used / allocation) * 100);
