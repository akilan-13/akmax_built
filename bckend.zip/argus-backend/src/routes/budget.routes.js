import { Router } from 'express';
const router = Router();
// TODO: register budget controllers with auth, RBAC, validation and service calls.
export default router;
