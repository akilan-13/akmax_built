// src/routes/settings/companySettings.routes.js

import { Router } from 'express';

import companySettingsController from '../../controllers/settings/companySettingsController.js';

import authMiddleware from '../../middleware/auth.js';
import rbacMiddleware from '../../middleware/rbac.js';
import uploadMiddleware from '../../middleware/upload.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Route middleware                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Company Profile belongs to the internal/admin settings area.
 *
 * Authentication:
 * - Required for every endpoint.
 *
 * Authorization:
 * - Enforced by the RBAC middleware.
 *
 * NOTE:
 * auth.js, rbac.js and upload.js are part of the next foundation
 * files in this backend build.
 */


/* -------------------------------------------------------------------------- */
/* GET Company Profile                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/company
 *
 * Returns:
 * - legal name
 * - tax ID
 * - contact email
 * - support phone
 * - headquarters address
 * - logo metadata
 * - favicon metadata
 *
 * Permission:
 * SETTINGS.COMPANY.VIEW
 */
router.get(
  '/company',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'view',
  }),

  companySettingsController.getCompanyProfile,
);


/* -------------------------------------------------------------------------- */
/* PATCH Company Profile                                                      */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/company
 *
 * Text/settings update.
 *
 * Existing React field names are supported by the controller:
 *
 * companyName
 * taxNumber
 * email
 * phone
 * address
 *
 * and the canonical backend names:
 *
 * legalName
 * taxId
 * contactEmail
 * supportPhone
 * headquartersAddress
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.patch(
  '/company',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  companySettingsController.updateCompanyProfile,
);


/* -------------------------------------------------------------------------- */
/* POST Company Logo                                                          */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/settings/company/logo
 *
 * Multipart field:
 *
 * logo
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.post(
  '/company/logo',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  uploadMiddleware.single('logo'),

  companySettingsController.uploadCompanyLogo,
);


/* -------------------------------------------------------------------------- */
/* DELETE Company Logo                                                        */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /api/v1/settings/company/logo
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.delete(
  '/company/logo',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  companySettingsController.deleteCompanyLogo,
);


/* -------------------------------------------------------------------------- */
/* POST Company Favicon                                                       */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/settings/company/favicon
 *
 * Multipart field:
 *
 * favicon
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.post(
  '/company/favicon',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  uploadMiddleware.single('favicon'),

  companySettingsController.uploadCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* DELETE Company Favicon                                                     */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /api/v1/settings/company/favicon
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.delete(
  '/company/favicon',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  companySettingsController.deleteCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* PATCH Company Status                                                       */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/company/status
 *
 * Body:
 *
 * {
 *   "active": true
 * }
 *
 * Permission:
 * SETTINGS.COMPANY.EDIT
 */
router.patch(
  '/company/status',

  authMiddleware,

  rbacMiddleware({
    module: 'company_settings',
    action: 'edit',
  }),

  companySettingsController.updateCompanyStatus,
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;