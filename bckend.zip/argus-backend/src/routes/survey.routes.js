import { Router } from 'express';
const router = Router();
// TODO: register survey controllers with auth, RBAC, validation and service calls.
export default router;
