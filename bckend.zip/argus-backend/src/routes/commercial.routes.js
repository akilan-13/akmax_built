import { Router } from 'express';
const router = Router();
// TODO: register commercial controllers with auth, RBAC, validation and service calls.
export default router;
