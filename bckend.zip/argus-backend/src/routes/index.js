// import { Router } from 'express';
// import authRoutes from './auth.routes.js';
// import vendorRoutes from './vendor.routes.js';
// import masterRateRoutes from './masterRate.routes.js';
// import boqRoutes from './boq.routes.js';
// import rfqRoutes from './rfq.routes.js';
// import quotationRoutes from './quotation.routes.js';
// import commercialRoutes from './commercial.routes.js';
// import projectRoutes from './project.routes.js';
// import taskRoutes from './task.routes.js';
// import budgetRoutes from './budget.routes.js';
// import invoiceRoutes from './invoice.routes.js';
// import paymentRoutes from './payment.routes.js';
// import dashboardRoutes from './dashboard.routes.js';
// import reportsRoutes from './reports.routes.js';
// import settingsRoutes from './settings.routes.js';
// import userRoutes from './user.routes.js';
// import auditRoutes from './audit.routes.js';
// import surveyRoutes from './survey.routes.js';
// const router = Router();
// router.use('/auth', authRoutes);
// router.use('/vendors', vendorRoutes);
// router.use('/master-rates', masterRateRoutes);
// router.use('/boqs', boqRoutes);
// router.use('/rfqs', rfqRoutes);
// router.use('/quotations', quotationRoutes);
// router.use('/commercial', commercialRoutes);
// router.use('/projects', projectRoutes);
// router.use('/tasks', taskRoutes);
// router.use('/budgets', budgetRoutes);
// router.use('/invoices', invoiceRoutes);
// router.use('/payments', paymentRoutes);
// router.use('/dashboard', dashboardRoutes);
// router.use('/reports', reportsRoutes);
// router.use('/settings', settingsRoutes);
// router.use('/users', userRoutes);
// router.use('/audit', auditRoutes);
// router.use('/surveys', surveyRoutes);
// export default router;



// src/routes/settings/index.js

import { Router } from 'express';

import companySettingsRoutes from './companySettings.routes.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Company Information                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Company Information
 *
 * Routes:
 *
 * GET    /company
 * PATCH  /company
 * POST   /company/logo
 * DELETE /company/logo
 * POST   /company/favicon
 * DELETE /company/favicon
 * PATCH  /company/status
 *
 * Full endpoint becomes:
 *
 * /api/v1/settings/company
 */
router.use(
  '/',
  companySettingsRoutes,
);


/* -------------------------------------------------------------------------- */
/* Future Settings Modules                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Roles & Permissions
 *
 * Will be added after the authentication/RBAC foundation:
 *
 * import rolesPermissionsRoutes
 *   from './rolesPermissions.routes.js';
 *
 * router.use(
 *   '/roles-permissions',
 *   rolesPermissionsRoutes,
 * );
 */


/**
 * API Configuration
 *
 * Will contain the configuration UI currently present
 * in the ARGUS frontend.
 */


/**
 * Vendor Settings
 *
 * UI-derived settings include:
 *
 * - Vendor Category
 * - Currency Format
 * - Payment Terms
 * - Industry Sector
 * - Status
 *
 * These belong to Settings and are separate from the
 * Vendor transaction module.
 */


/**
 * Common Settings
 *
 * UI-derived settings include:
 *
 * - Units
 * - Validity Period
 * - Terms and Conditions
 */


/**
 * Master Rate Settings
 *
 * UI-derived settings include rate category management
 * and category type configuration.
 *
 * The rate schedule itself will remain under the
 * Master Rate module.
 */


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;



// src/routes/settings/index.js

import { Router } from 'express';

import companySettingsRoutes from './companySettings.routes.js';
import fileController from '../../controllers/storage/fileController.js';

import authMiddleware, {
  requireInternalUser,
} from '../../middleware/auth.js';

import {
  internalCanView,
} from '../../middleware/rbac.js';

const router = Router();

/**
 * ============================================================
 * COMPANY SETTINGS
 * ============================================================
 *
 * Mounted under:
 *   /api/v1/settings
 *
 * Existing endpoints:
 *   GET    /company
 *   PATCH  /company
 *   POST   /company/logo
 *   DELETE /company/logo
 *   POST   /company/favicon
 *   DELETE /company/favicon
 *   PATCH  /company/status
 */
router.use('/', companySettingsRoutes);

/**
 * ============================================================
 * PROTECTED COMPANY ASSETS
 * ============================================================
 *
 * These endpoints intentionally do NOT use express.static().
 *
 * The storage directory remains private.
 * Every request must pass:
 *
 *   1. JWT authentication
 *   2. Internal-user validation
 *   3. Company-settings VIEW permission
 *
 * The controller resolves the actual file from the stored
 * CompanySetting document. The client cannot submit an arbitrary
 * filesystem path or storageKey.
 */

/**
 * Display company logo.
 *
 * GET /api/v1/settings/company/logo
 */
router.get(
  '/company/logo',
  authMiddleware,
  requireInternalUser,
  internalCanView('company_settings'),
  fileController.getCompanyLogo,
);

/**
 * Download company logo.
 *
 * GET /api/v1/settings/company/logo/download
 */
router.get(
  '/company/logo/download',
  authMiddleware,
  requireInternalUser,
  internalCanView('company_settings'),
  fileController.downloadCompanyLogo,
);

/**
 * Display company favicon.
 *
 * GET /api/v1/settings/company/favicon
 */
router.get(
  '/company/favicon',
  authMiddleware,
  requireInternalUser,
  internalCanView('company_settings'),
  fileController.getCompanyFavicon,
);

/**
 * Download company favicon.
 *
 * GET /api/v1/settings/company/favicon/download
 */
router.get(
  '/company/favicon/download',
  authMiddleware,
  requireInternalUser,
  internalCanView('company_settings'),
  fileController.downloadCompanyFavicon,
);

/**
 * ============================================================
 * FUTURE SETTINGS MODULES
 * ============================================================
 *
 * Keep every Settings module isolated so routes can be added
 * without turning this file into a large controller/router.
 *
 * Planned:
 *
 *   /roles-permissions
 *   /api-configuration
 *   /vendor-settings
 *   /common-settings
 *   /master-rate-settings
 *
 * Example:
 *
 * import rolesPermissionRoutes
 *   from './rolesPermission.routes.js';
 *
 * router.use('/roles-permissions', rolesPermissionRoutes);
 */

/**
 * ============================================================
 * ROUTER EXPORT
 * ============================================================
 */
export default router;