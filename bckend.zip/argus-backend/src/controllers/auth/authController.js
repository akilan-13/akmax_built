export const adminLogin = async (_req, res) => res.status(501).json({ success:false, message:'Implementation pending in backend coding phase' });
export const vendorLogin = async (_req, res) => res.status(501).json({ success:false, message:'Implementation pending in backend coding phase' });
export const refresh = async (_req, res) => res.status(501).json({ success:false, message:'Implementation pending in backend coding phase' });
export const logout = async (_req, res) => res.status(501).json({ success:false, message:'Implementation pending in backend coding phase' });
export const me = async (_req, res) => res.status(501).json({ success:false, message:'Implementation pending in backend coding phase' });
