// Controller contract for invoiceController.js. Full implementation is the next coding phase.
export const list = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const get = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const create = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const update = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
export const remove = async (_req,res)=>res.status(501).json({success:false,message:'Implementation pending'});
