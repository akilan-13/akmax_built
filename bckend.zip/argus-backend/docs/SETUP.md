# Setup

Create PostgreSQL database `argus`, copy `.env.example` to `.env`, install packages, run `npm run db:init`, then `npm run db:seed`, then `npm run dev`.
