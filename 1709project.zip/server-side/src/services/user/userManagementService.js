// src/services/user/userManagementService.js

import bcrypt from 'bcrypt';
import mongoose from 'mongoose';

import User from '../../models/User.js';
import Role from '../../models/Role.js';
import Vendor from '../../models/Vendor.js';
import env from '../../config/env.js';


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const USER_TYPES = Object.freeze([
    'admin',
    'vendor',
]);

const USER_STATUSES = Object.freeze([
    'active',
    'inactive',
]);

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class UserManagementServiceError extends Error {
    constructor(
        message,
        {
            code = 'USER_MANAGEMENT_ERROR',
            statusCode = 400,
            details = null,
        } = {},
    ) {
        super(message);

        this.name =
            'UserManagementServiceError';

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        Error.captureStackTrace?.(
            this,
            UserManagementServiceError,
        );
    }
}


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeString(
    value,
) {
    return typeof value === 'string'
        ? value.trim()
        : '';
}


function normalizeEmail(
    value,
) {
    return normalizeString(
        value,
    ).toLowerCase();
}


function normalizeUserType(
    value,
) {
    return normalizeString(
        value,
    ).toLowerCase();
}


function normalizeStatus(
    value,
) {
    return normalizeString(
        value,
    ).toLowerCase();
}


function normalizeRoleKey(
    value,
) {
    return normalizeString(
        value,
    )
        .toLowerCase()
        .replace(/\s+/g, '_')
        .replace(
            /[^a-z0-9_-]/g,
            '',
        );
}


function isValidObjectId(
    value,
) {
    return Boolean(
        value &&
        mongoose.isValidObjectId(
            value,
        ),
    );
}


function toObjectId(
    value,
) {
    return new mongoose.Types.ObjectId(
        value,
    );
}


function parsePage(
    value,
) {
    const page =
        Number.parseInt(
            String(value ?? ''),
            10,
        );

    return Number.isFinite(
        page,
    ) && page > 0
        ? page
        : DEFAULT_PAGE;
}


function parseLimit(
    value,
) {
    const limit =
        Number.parseInt(
            String(value ?? ''),
            10,
        );

    if (
        !Number.isFinite(
            limit,
        ) ||
        limit <= 0
    ) {
        return DEFAULT_LIMIT;
    }

    return Math.min(
        MAX_LIMIT,
        limit,
    );
}


function assertObjectId(
    value,
    fieldName,
) {
    if (
        !isValidObjectId(
            value,
        )
    ) {
        throw new UserManagementServiceError(
            `Invalid ${fieldName}.`,
            {
                code:
                    'INVALID_OBJECT_ID',

                statusCode:
                    422,

                details: {
                    field:
                        fieldName,
                },
            },
        );
    }
}


function escapeRegex(
    value,
) {
    return String(value)
        .replace(
            /[.*+?^${}()|[\]\\]/g,
            '\\$&',
        );
}


function normalizeRoleId(
    value,
) {
    if (
        value === null ||
        value === undefined ||
        value === ''
    ) {
        return null;
    }

    if (
        isValidObjectId(
            value,
        )
    ) {
        return toObjectId(
            value,
        );
    }

    return null;
}


function getPasswordMinLength() {
    const configured =
        Number(
            env?.auth
                ?.passwordMinLength,
        );

    return Number.isFinite(
        configured,
    ) && configured > 0
        ? configured
        : 8;
}


function validatePassword(
    password,
) {
    const value =
        normalizeString(
            password,
        );

    if (!value) {
        throw new UserManagementServiceError(
            'Password is required.',
            {
                code:
                    'PASSWORD_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    const minimumLength =
        getPasswordMinLength();

    if (
        value.length <
        minimumLength
    ) {
        throw new UserManagementServiceError(
            `Password must contain at least ${minimumLength} characters.`,
            {
                code:
                    'PASSWORD_TOO_SHORT',

                statusCode:
                    422,
            },
        );
    }

    /*
     * Do not impose a frontend-specific complexity policy here.
     * Authentication/environment configuration remains the source
     * of the application password policy.
     */

    return value;
}


function getBcryptRounds() {
    const configured =
        Number(
            env?.auth
                ?.bcryptSaltRounds,
        );

    return Number.isFinite(
        configured,
    )
        ? Math.min(
              Math.max(
                  configured,
                  8,
              ),
              15,
          )
        : 12;
}


async function hashPassword(
    password,
) {
    const validPassword =
        validatePassword(
            password,
        );

    return bcrypt.hash(
        validPassword,
        getBcryptRounds(),
    );
}


/* -------------------------------------------------------------------------- */
/* Serialization                                                              */
/* -------------------------------------------------------------------------- */

function serializeRole(
    role,
) {
    if (!role) {
        return null;
    }

    return {
        id:
            String(
                role._id,
            ),

        code:
            role.code ??
            role.key ??
            '',

        name:
            role.name ??
            '',

        userType:
            role.userType ??
            role.realm ??
            null,

        status:
            role.status ??
            (
                role.active === false
                    ? 'inactive'
                    : 'active'
            ),

        system:
            role.isSystem === true ||
            role.system === true,
    };
}


function serializeVendor(
    vendor,
) {
    if (!vendor) {
        return null;
    }

    return {
        id:
            String(
                vendor._id,
            ),

        companyName:
            vendor.companyName ??
            vendor.company_name ??
            '',

        email:
            vendor.email ??
            '',

        status:
            vendor.status ??
            null,
    };
}


function serializeUser(
    user,
) {
    if (!user) {
        return null;
    }

    return {
        id:
            String(
                user._id,
            ),

        email:
            user.email,

        name:
            user.displayName ||
            user.name ||
            '',

        displayName:
            user.displayName ||
            user.name ||
            '',

        userType:
            user.userType,

        role:
            serializeRole(
                user.roleId,
            ),

        roleId:
            user.roleId
                ? String(
                      user.roleId
                          ?._id ??
                          user.roleId,
                  )
                : null,

        vendor:
            serializeVendor(
                user.vendorId,
            ),

        vendorId:
            user.vendorId
                ? String(
                      user.vendorId
                          ?._id ??
                          user.vendorId,
                  )
                : null,

        status:
            user.status,

        lastLoginAt:
            user.lastLoginAt ??
            null,

        createdAt:
            user.createdAt ??
            null,

        updatedAt:
            user.updatedAt ??
            null,
    };
}


/* -------------------------------------------------------------------------- */
/* Query builder                                                              */
/* -------------------------------------------------------------------------- */

function buildUserFilter({
    search = '',
    roleId = '',
    status = '',
    userType = '',
    vendorId = '',
} = {}) {
    const filter = {};

    const normalizedSearch =
        normalizeString(
            search,
        );

    if (normalizedSearch) {
        const expression =
            new RegExp(
                escapeRegex(
                    normalizedSearch,
                ),
                'i',
            );

        filter.$or = [
            {
                displayName:
                    expression,
            },

            {
                email:
                    expression,
            },
        ];
    }

    if (
        roleId &&
        isValidObjectId(
            roleId,
        )
    ) {
        filter.roleId =
            toObjectId(
                roleId,
            );
    }

    const normalizedStatus =
        normalizeStatus(
            status,
        );

    if (
        USER_STATUSES.includes(
            normalizedStatus,
        )
    ) {
        filter.status =
            normalizedStatus;
    }

    const normalizedType =
        normalizeUserType(
            userType,
        );

    if (
        USER_TYPES.includes(
            normalizedType,
        )
    ) {
        filter.userType =
            normalizedType;
    }

    if (
        vendorId &&
        isValidObjectId(
            vendorId,
        )
    ) {
        filter.vendorId =
            toObjectId(
                vendorId,
            );
    }

    return filter;
}


/* -------------------------------------------------------------------------- */
/* Role resolution                                                            */
/* -------------------------------------------------------------------------- */

async function findRoleOrThrow(
    roleId,
    userType,
) {
    if (
        !roleId
    ) {
        throw new UserManagementServiceError(
            'Role is required.',
            {
                code:
                    'ROLE_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    let role = null;

    if (
        isValidObjectId(
            roleId,
        )
    ) {
        role =
            await Role.findById(
                roleId,
            );
    } else {
        const roleKey =
            normalizeRoleKey(
                roleId,
            );

        if (roleKey) {
            role =
                await Role.findOne({
                    $or: [
                        {
                            code:
                                roleKey,
                        },

                        {
                            key:
                                roleKey,
                        },
                    ],
                });
        }
    }

    if (!role) {
        throw new UserManagementServiceError(
            'Selected role was not found.',
            {
                code:
                    'ROLE_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    const roleStatus =
        role.status ??
        (
            role.active === false
                ? 'inactive'
                : 'active'
        );

    if (
        roleStatus !==
        'active'
    ) {
        throw new UserManagementServiceError(
            'The selected role is inactive.',
            {
                code:
                    'ROLE_INACTIVE',

                statusCode:
                    409,
            },
        );
    }

    const normalizedType =
        normalizeUserType(
            userType,
        );

    /*
     * Current source supports admin/vendor user types.
     * A role may expose either userType or the newer realm /
     * allowedUserTypes structure depending on the active model.
     */

    const roleUserType =
        normalizeUserType(
            role.userType ??
            role.realm,
        );

    if (
        roleUserType &&
        roleUserType !==
            'both' &&
        roleUserType !==
            normalizedType
    ) {
        throw new UserManagementServiceError(
            'The selected role is not valid for this user type.',
            {
                code:
                    'ROLE_USER_TYPE_MISMATCH',

                statusCode:
                    422,
            },
        );
    }

    if (
        Array.isArray(
            role.allowedUserTypes,
        ) &&
        role.allowedUserTypes.length &&
        !role.allowedUserTypes.includes(
            normalizedType,
        )
    ) {
        throw new UserManagementServiceError(
            'The selected role is not valid for this user type.',
            {
                code:
                    'ROLE_USER_TYPE_MISMATCH',

                statusCode:
                    422,
            },
        );
    }

    return role;
}


/* -------------------------------------------------------------------------- */
/* Vendor resolution                                                          */
/* -------------------------------------------------------------------------- */

async function findVendorOrThrow(
    vendorId,
) {
    assertObjectId(
        vendorId,
        'vendorId',
    );

    const vendor =
        await Vendor.findById(
            vendorId,
        );

    if (!vendor) {
        throw new UserManagementServiceError(
            'Vendor was not found.',
            {
                code:
                    'VENDOR_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    const status =
        normalizeStatus(
            vendor.status,
        );

    /*
     * The vendor lifecycle in ARGUS includes pending/approved/
     * rejected. A portal user should only be attached to a
     * vendor that is not rejected.
     */

    if (
        status ===
        'rejected'
    ) {
        throw new UserManagementServiceError(
            'A user cannot be associated with a rejected vendor.',
            {
                code:
                    'VENDOR_REJECTED',

                statusCode:
                    409,
            },
        );
    }

    return vendor;
}


/* -------------------------------------------------------------------------- */
/* List Users                                                                 */
/* -------------------------------------------------------------------------- */

export async function listUsers({
    search = '',
    roleId = '',
    status = '',
    userType = '',
    vendorId = '',
    page = DEFAULT_PAGE,
    limit = DEFAULT_LIMIT,
} = {}) {
    const normalizedPage =
        parsePage(
            page,
        );

    const normalizedLimit =
        parseLimit(
            limit,
        );

    const filter =
        buildUserFilter({
            search,
            roleId,
            status,
            userType,
            vendorId,
        });

    const total =
        await User.countDocuments(
            filter,
        );

    const users =
        await User.find(
            filter,
        )
            .populate({
                path:
                    'roleId',

                select:
                    'code key name userType realm status active isSystem system allowedUserTypes',
            })
            .populate({
                path:
                    'vendorId',

                select:
                    'companyName company_name email status',
            })
            .sort({
                displayName:
                    1,

                email:
                    1,
            })
            .skip(
                (
                    normalizedPage -
                    1
                ) *
                    normalizedLimit,
            )
            .limit(
                normalizedLimit,
            )
            .lean();

    const activeCount =
        await User.countDocuments({
            ...filter,
            status:
                'active',
        });

    const inactiveCount =
        await User.countDocuments({
            ...filter,
            status:
                'inactive',
        });

    return {
        data:
            users.map(
                serializeUser,
            ),

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            pages:
                Math.ceil(
                    total /
                        normalizedLimit,
                ),
        },

        summary: {
            active:
                activeCount,

            inactive:
                inactiveCount,

            total,
        },
    };
}


/* -------------------------------------------------------------------------- */
/* Get User                                                                  */
/* -------------------------------------------------------------------------- */

export async function getUser(
    userId,
) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        )
            .populate({
                path:
                    'roleId',

                select:
                    'code key name userType realm status active isSystem system allowedUserTypes',
            })
            .populate({
                path:
                    'vendorId',

                select:
                    'companyName company_name email status',
            });

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    return serializeUser(
        user,
    );
}


/* -------------------------------------------------------------------------- */
/* Create User                                                                */
/* -------------------------------------------------------------------------- */

export async function createUser({
    email,
    displayName,
    password,
    userType = 'admin',
    roleId,
    vendorId = null,
    status = 'active',
    createdBy = null,
} = {}) {
    const normalizedEmail =
        normalizeEmail(
            email,
        );

    const normalizedName =
        normalizeString(
            displayName,
        );

    const normalizedType =
        normalizeUserType(
            userType,
        );

    const normalizedStatus =
        normalizeStatus(
            status ||
                'active',
        );

    if (!normalizedEmail) {
        throw new UserManagementServiceError(
            'Email is required.',
            {
                code:
                    'EMAIL_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        normalizedEmail,
    )) {
        throw new UserManagementServiceError(
            'Enter a valid email address.',
            {
                code:
                    'INVALID_EMAIL',

                statusCode:
                    422,
            },
        );
    }

    if (!normalizedName) {
        throw new UserManagementServiceError(
            'Display name is required.',
            {
                code:
                    'DISPLAY_NAME_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    if (
        !USER_TYPES.includes(
            normalizedType,
        )
    ) {
        throw new UserManagementServiceError(
            'Invalid user type.',
            {
                code:
                    'INVALID_USER_TYPE',

                statusCode:
                    422,
            },
        );
    }

    if (
        !USER_STATUSES.includes(
            normalizedStatus,
        )
    ) {
        throw new UserManagementServiceError(
            'Invalid user status.',
            {
                code:
                    'INVALID_USER_STATUS',

                statusCode:
                    422,
            },
        );
    }

    /*
     * Check duplicate email before attempting insert.
     */
    const existingUser =
        await User.findOne({
            email:
                normalizedEmail,
        });

    if (existingUser) {
        throw new UserManagementServiceError(
            'A user with this email address already exists.',
            {
                code:
                    'EMAIL_ALREADY_EXISTS',

                statusCode:
                    409,
            },
        );
    }

    const role =
        await findRoleOrThrow(
            roleId,
            normalizedType,
        );

    let resolvedVendorId =
        null;

    if (
        normalizedType ===
        'vendor'
    ) {
        if (!vendorId) {
            throw new UserManagementServiceError(
                'Vendor is required for a vendor user.',
                {
                    code:
                        'VENDOR_REQUIRED',

                    statusCode:
                        422,
                },
            );
        }

        await findVendorOrThrow(
            vendorId,
        );

        resolvedVendorId =
            toObjectId(
                vendorId,
            );
    }

    if (
        normalizedType ===
        'admin' &&
        vendorId
    ) {
        throw new UserManagementServiceError(
            'Admin users cannot be associated with a vendor.',
            {
                code:
                    'ADMIN_VENDOR_SCOPE_INVALID',

                statusCode:
                    422,
            },
        );
    }

    if (createdBy) {
        assertObjectId(
            createdBy,
            'createdBy',
        );
    }

    const passwordHash =
        await hashPassword(
            password,
        );

    try {
        const user =
            await User.create({
                email:
                    normalizedEmail,

                displayName:
                    normalizedName,

                passwordHash,

                userType:
                    normalizedType,

                roleId:
                    role._id,

                vendorId:
                    resolvedVendorId,

                status:
                    normalizedStatus,

                createdBy:
                    createdBy
                        ? toObjectId(
                              createdBy,
                          )
                        : null,

                updatedBy:
                    createdBy
                        ? toObjectId(
                              createdBy,
                          )
                        : null,
            });

        const populated =
            await User.findById(
                user._id,
            )
                .populate({
                    path:
                        'roleId',

                    select:
                        'code key name userType realm status active isSystem system allowedUserTypes',
                })
                .populate({
                    path:
                        'vendorId',

                    select:
                        'companyName company_name email status',
                });

        return serializeUser(
            populated,
        );
    } catch (error) {
        if (
            error?.code ===
            11000
        ) {
            throw new UserManagementServiceError(
                'A user with this email address already exists.',
                {
                    code:
                        'EMAIL_ALREADY_EXISTS',

                    statusCode:
                        409,
                },
            );
        }

        throw error;
    }
}


/* -------------------------------------------------------------------------- */
/* Update User                                                                */
/* -------------------------------------------------------------------------- */

export async function updateUser({
    userId,
    email,
    displayName,
    password,
    userType,
    roleId,
    vendorId,
    status,
    updatedBy = null,
} = {}) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        ).select(
            '+passwordHash',
        );

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    /*
     * Never permit an already soft-deleted/nonexistent account
     * to be silently restored by a normal update.
     */
    if (
        user.deletedAt
    ) {
        throw new UserManagementServiceError(
            'Deleted users cannot be updated.',
            {
                code:
                    'USER_DELETED',

                statusCode:
                    409,
            },
        );
    }

    const effectiveType =
        userType !==
        undefined
            ? normalizeUserType(
                  userType,
              )
            : normalizeUserType(
                  user.userType,
              );

    if (
        !USER_TYPES.includes(
            effectiveType,
        )
    ) {
        throw new UserManagementServiceError(
            'Invalid user type.',
            {
                code:
                    'INVALID_USER_TYPE',

                statusCode:
                    422,
            },
        );
    }

    if (
        email !==
        undefined
    ) {
        const normalizedEmail =
            normalizeEmail(
                email,
            );

        if (
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                normalizedEmail,
            )
        ) {
            throw new UserManagementServiceError(
                'Enter a valid email address.',
                {
                    code:
                        'INVALID_EMAIL',

                    statusCode:
                        422,
                },
            );
        }

        const duplicate =
            await User.findOne({
                email:
                    normalizedEmail,

                _id: {
                    $ne:
                        user._id,
                },
            });

        if (duplicate) {
            throw new UserManagementServiceError(
                'A user with this email address already exists.',
                {
                    code:
                        'EMAIL_ALREADY_EXISTS',

                    statusCode:
                        409,
                },
            );
        }

        user.email =
            normalizedEmail;
    }

    if (
        displayName !==
        undefined
    ) {
        const normalizedName =
            normalizeString(
                displayName,
            );

        if (
            !normalizedName
        ) {
            throw new UserManagementServiceError(
                'Display name cannot be empty.',
                {
                    code:
                        'DISPLAY_NAME_REQUIRED',

                    statusCode:
                        422,
                },
            );
        }

        user.displayName =
            normalizedName;
    }

    if (
        roleId !==
        undefined
    ) {
        const role =
            await findRoleOrThrow(
                roleId,
                effectiveType,
            );

        user.roleId =
            role._id;
    } else {
        /*
         * Re-check the existing role against a changed user type.
         */
        await findRoleOrThrow(
            user.roleId,
            effectiveType,
        );
    }

    if (
        userType !==
        undefined
    ) {
        user.userType =
            effectiveType;
    }

    if (
        vendorId !==
        undefined
    ) {
        if (
            effectiveType ===
            'vendor'
        ) {
            if (!vendorId) {
                throw new UserManagementServiceError(
                    'Vendor is required for a vendor user.',
                    {
                        code:
                            'VENDOR_REQUIRED',

                        statusCode:
                            422,
                    },
                );
            }

            await findVendorOrThrow(
                vendorId,
            );

            user.vendorId =
                toObjectId(
                    vendorId,
                );
        } else {
            if (vendorId) {
                throw new UserManagementServiceError(
                    'Admin users cannot be associated with a vendor.',
                    {
                        code:
                            'ADMIN_VENDOR_SCOPE_INVALID',

                        statusCode:
                            422,
                    },
                );
            }

            user.vendorId =
                null;
        }
    } else if (
        effectiveType ===
        'admin'
    ) {
        user.vendorId =
            null;
    } else if (
        effectiveType ===
        'vendor' &&
        !user.vendorId
    ) {
        throw new UserManagementServiceError(
            'Vendor is required for a vendor user.',
            {
                code:
                    'VENDOR_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    if (
        status !==
        undefined
    ) {
        const normalizedStatus =
            normalizeStatus(
                status,
            );

        if (
            !USER_STATUSES.includes(
                normalizedStatus,
            )
        ) {
            throw new UserManagementServiceError(
                'Invalid user status.',
                {
                    code:
                        'INVALID_USER_STATUS',

                    statusCode:
                        422,
                },
            );
        }

        user.status =
            normalizedStatus;
    }

    if (
        password !==
            undefined &&
        normalizeString(
            password,
        )
    ) {
        user.passwordHash =
            await hashPassword(
                password,
            );
    }

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );

        user.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    await user.save();

    const populated =
        await User.findById(
            user._id,
        )
            .populate({
                path:
                    'roleId',

                select:
                    'code key name userType realm status active isSystem system allowedUserTypes',
            })
            .populate({
                path:
                    'vendorId',

                select:
                    'companyName company_name email status',
            });

    return serializeUser(
        populated,
    );
}


/* -------------------------------------------------------------------------- */
/* Deactivate User                                                            */
/* -------------------------------------------------------------------------- */

export async function deactivateUser({
    userId,
    updatedBy = null,
} = {}) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        );

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    if (
        user.status ===
        'inactive'
    ) {
        return serializeUser(
            await User.findById(
                user._id,
            )
                .populate(
                    'roleId',
                )
                .populate(
                    'vendorId',
                ),
        );
    }

    /*
     * Prevent accidental self-deactivation from the service layer
     * only when caller explicitly supplies the same account.
     */
    if (
        updatedBy &&
        String(
            updatedBy,
        ) ===
            String(
                user._id,
            )
    ) {
        throw new UserManagementServiceError(
            'You cannot deactivate your own user account.',
            {
                code:
                    'SELF_DEACTIVATION_NOT_ALLOWED',

                statusCode:
                    409,
            },
        );
    }

    user.status =
        'inactive';

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );

        user.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    await user.save();

    const populated =
        await User.findById(
            user._id,
        )
            .populate(
                'roleId',
            )
            .populate(
                'vendorId',
            );

    return serializeUser(
        populated,
    );
}


/* -------------------------------------------------------------------------- */
/* Activate User                                                              */
/* -------------------------------------------------------------------------- */

export async function activateUser({
    userId,
    updatedBy = null,
} = {}) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        );

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    user.status =
        'active';

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );

        user.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    await user.save();

    const populated =
        await User.findById(
            user._id,
        )
            .populate(
                'roleId',
            )
            .populate(
                'vendorId',
            );

    return serializeUser(
        populated,
    );
}


/* -------------------------------------------------------------------------- */
/* Reset Password                                                             */
/* -------------------------------------------------------------------------- */

export async function resetPassword({
    userId,
    password,
    updatedBy = null,
} = {}) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        ).select(
            '+passwordHash',
        );

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    const passwordHash =
        await hashPassword(
            password,
        );

    user.passwordHash =
        passwordHash;

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );

        user.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    await user.save();

    return {
        id:
            String(
                user._id,
            ),

        passwordReset:
            true,
    };
}


/* -------------------------------------------------------------------------- */
/* User Role Assignment                                                       */
/* -------------------------------------------------------------------------- */

export async function assignRole({
    userId,
    roleId,
    updatedBy = null,
} = {}) {
    assertObjectId(
        userId,
        'userId',
    );

    const user =
        await User.findById(
            userId,
        );

    if (!user) {
        throw new UserManagementServiceError(
            'User was not found.',
            {
                code:
                    'USER_NOT_FOUND',

                statusCode:
                    404,
            },
        );
    }

    const role =
        await findRoleOrThrow(
            roleId,
            user.userType,
        );

    user.roleId =
        role._id;

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );

        user.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    await user.save();

    const populated =
        await User.findById(
            user._id,
        )
            .populate(
                'roleId',
            )
            .populate(
                'vendorId',
            );

    return serializeUser(
        populated,
    );
}


/* -------------------------------------------------------------------------- */
/* User Lookup / Email Availability                                           */
/* -------------------------------------------------------------------------- */

export async function checkEmailAvailability({
    email,
    excludeUserId = null,
} = {}) {
    const normalizedEmail =
        normalizeEmail(
            email,
        );

    if (
        !normalizedEmail
    ) {
        throw new UserManagementServiceError(
            'Email is required.',
            {
                code:
                    'EMAIL_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    const filter = {
        email:
            normalizedEmail,
    };

    if (
        excludeUserId
    ) {
        assertObjectId(
            excludeUserId,
            'excludeUserId',
        );

        filter._id = {
            $ne:
                toObjectId(
                    excludeUserId,
                ),
        };
    }

    const existing =
        await User.findOne(
            filter,
        ).select(
            '_id',
        );

    return {
        available:
            !existing,
    };
}


/* -------------------------------------------------------------------------- */
/* Bulk Status                                                                 */
/* -------------------------------------------------------------------------- */

export async function bulkUpdateStatus({
    userIds = [],
    status,
    updatedBy = null,
} = {}) {
    if (
        !Array.isArray(
            userIds,
        ) ||
        !userIds.length
    ) {
        throw new UserManagementServiceError(
            'At least one user must be selected.',
            {
                code:
                    'USER_IDS_REQUIRED',

                statusCode:
                    422,
            },
        );
    }

    const normalizedStatus =
        normalizeStatus(
            status,
        );

    if (
        !USER_STATUSES.includes(
            normalizedStatus,
        )
    ) {
        throw new UserManagementServiceError(
            'Invalid user status.',
            {
                code:
                    'INVALID_USER_STATUS',

                statusCode:
                    422,
            },
        );
    }

    const ids =
        userIds.map(
            (userId) => {
                assertObjectId(
                    userId,
                    'userId',
                );

                return toObjectId(
                    userId,
                );
            },
        );

    if (
        updatedBy &&
        ids.some(
            (id) =>
                String(id) ===
                String(
                    updatedBy,
                ),
        ) &&
        normalizedStatus ===
            'inactive'
    ) {
        throw new UserManagementServiceError(
            'You cannot deactivate your own user account.',
            {
                code:
                    'SELF_DEACTIVATION_NOT_ALLOWED',

                statusCode:
                    409,
            },
        );
    }

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            'updatedBy',
        );
    }

    const result =
        await User.updateMany(
            {
                _id: {
                    $in:
                        ids,
                },
            },
            {
                $set: {
                    status:
                        normalizedStatus,

                    ...(updatedBy
                        ? {
                              updatedBy:
                                  toObjectId(
                                      updatedBy,
                                  ),
                          }
                        : {}),
                },
            },
        );

    return {
        matched:
            Number(
                result.matchedCount ||
                    result.n ||
                    0,
            ),

        modified:
            Number(
                result.modifiedCount ||
                    result.nModified ||
                    0,
            ),

        status:
            normalizedStatus,
    };
}


/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

const userManagementService =
    Object.freeze({
        listUsers,
        getUser,
        createUser,
        updateUser,
        deactivateUser,
        activateUser,
        resetPassword,
        assignRole,
        checkEmailAvailability,
        bulkUpdateStatus,
    });


export default userManagementService;