
import bcrypt from "bcrypt";
import crypto from "node:crypto";
import jwt from "jsonwebtoken";

import env from "../../config/env.js";
import User from "../../models/User.js";
import Role from "../../models/Role.js";
import RolePermission from "../../models/RolePermission.js";
import RefreshToken from "../../models/RefreshToken.js";

/*
|--------------------------------------------------------------------------
| Authentication Service
|--------------------------------------------------------------------------
|
| HTTP concerns remain in controllers.
|
| This service handles:
|
| - login
| - access token creation
| - refresh token creation
| - refresh token rotation
| - refresh token revocation
| - logout
| - logout-all
| - authenticated user context
|
|--------------------------------------------------------------------------
*/

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const ACCESS_TOKEN_TYPE =
    "access";

const REFRESH_TOKEN_TYPE =
    "refresh";

const REALMS =
    Object.freeze({
        ADMIN:
            "admin",

        INTERNAL:
            "internal",

        VENDOR:
            "vendor",
    });

const USER_TYPES =
    Object.freeze({
        ADMIN:
            "admin",

        INTERNAL:
            "internal",

        VENDOR:
            "vendor",
    });

const USER_TYPE_TO_REALM =
    Object.freeze({
        admin:
            REALMS.ADMIN,

        internal:
            REALMS.INTERNAL,

        vendor:
            REALMS.VENDOR,
    });

/* -------------------------------------------------------------------------- */
/* Errors                                                                     */
/* -------------------------------------------------------------------------- */

export class AuthenticationServiceError
    extends Error {
    constructor(
        message,
        {
            code =
                "AUTHENTICATION_ERROR",
            statusCode =
                401,
            details = null,
        } = {},
    ) {
        super(message);

        this.name =
            "AuthenticationServiceError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        Error.captureStackTrace?.(
            this,
            AuthenticationServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeEmail(
    email,
) {
    return String(
        email || "",
    )
        .trim()
        .toLowerCase();
}

function normalizeUserType(
    userType,
) {
    return String(
        userType || "",
    )
        .trim()
        .toLowerCase();
}

function assertUserType(
    userType,
) {
    const normalized =
        normalizeUserType(
            userType,
        );

    if (
        !Object.values(
            USER_TYPES,
        ).includes(
            normalized,
        )
    ) {
        throw new AuthenticationServiceError(
            "Invalid authentication user type.",
            {
                code:
                    "INVALID_USER_TYPE",
                statusCode:
                    400,
            },
        );
    }

    return normalized;
}

function getRealmForUserType(
    userType,
) {
    return (
        USER_TYPE_TO_REALM[
            assertUserType(
                userType,
            )
        ]
    );
}

function isUserActive(
    user,
) {
    return (
        user &&
        user.status ===
            "active"
    );
}

function isUserLocked(
    user,
) {
    if (
        !user
    ) {
        return false;
    }

    if (
        user.status ===
        "locked"
    ) {
        return true;
    }

    if (
        !user.lockedUntil
    ) {
        return false;
    }

    return (
        new Date(
            user.lockedUntil,
        ).getTime() >
        Date.now()
    );
}

/**
 * Parse the JWT expiry configuration into seconds so the MongoDB
 * RefreshToken expiresAt field can be calculated.
 *
 * Supported examples:
 *
 * 900
 * "900"
 * "15m"
 * "1h"
 * "7d"
 */
function parseDurationToSeconds(
    value,
) {
    if (
        typeof value ===
            "number" &&
        Number.isFinite(value) &&
        value > 0
    ) {
        return Math.floor(
            value,
        );
    }

    const source =
        String(
            value || "",
        )
            .trim()
            .toLowerCase();

    if (!source) {
        throw new Error(
            "JWT expiry configuration is missing.",
        );
    }

    if (
        /^\d+$/.test(
            source,
        )
    ) {
        return Number(
            source,
        );
    }

    const match =
        source.match(
            /^(\d+(?:\.\d+)?)\s*(s|m|h|d|w)$/,
        );

    if (!match) {
        throw new Error(
            `Unsupported JWT duration: ${source}`,
        );
    }

    const amount =
        Number(
            match[1],
        );

    const unit =
        match[2];

    const multiplier =
        {
            s: 1,
            m: 60,
            h: 60 * 60,
            d: 24 * 60 * 60,
            w: 7 * 24 * 60 * 60,
        }[unit];

    return Math.floor(
        amount *
            multiplier,
    );
}

function createOpaqueToken() {
    return crypto
        .randomBytes(
            48,
        )
        .toString(
            "base64url",
        );
}

function hashToken(
    token,
) {
    return crypto
        .createHash(
            "sha256",
        )
        .update(
            token,
            "utf8",
        )
        .digest(
            "hex",
        );
}

function createSessionId() {
    return crypto
        .randomUUID();
}

function createTokenFamilyId() {
    return crypto
        .randomUUID();
}

function sanitizeUser(
    user,
) {
    if (
        !user
    ) {
        return null;
    }

    if (
        typeof user.toSafeJSON ===
        "function"
    ) {
        return user.toSafeJSON();
    }

    return {
        id:
            String(
                user._id,
            ),

        email:
            user.email,

        displayName:
            user.displayName,

        userType:
            user.userType,

        roleId:
            user.roleId
                ? String(
                      user.roleId,
                  )
                : null,

        vendorId:
            user.vendorId
                ? String(
                      user.vendorId,
                  )
                : null,

        status:
            user.status,
    };
}

async function loadRole(
    roleId,
) {
    if (
        !roleId
    ) {
        throw new AuthenticationServiceError(
            "User role is not configured.",
            {
                code:
                    "ROLE_NOT_CONFIGURED",
                statusCode:
                    403,
            },
        );
    }

    const role =
        await Role.findOne({
            _id:
                roleId,

            active:
                true,
        });

    if (
        !role
    ) {
        throw new AuthenticationServiceError(
            "Assigned user role is inactive or unavailable.",
            {
                code:
                    "ROLE_UNAVAILABLE",
                statusCode:
                    403,
            },
        );
    }

    return role;
}

async function loadPermissions(
    roleId,
) {
    return RolePermission.getRBACMapForRole(
        roleId,
    );
}

function assertRoleCompatibility(
    user,
    role,
) {
    if (
        !role.allowsUserType(
            user.userType,
        )
    ) {
        throw new AuthenticationServiceError(
            "The assigned role is not valid for this user type.",
            {
                code:
                    "ROLE_USER_TYPE_MISMATCH",
                statusCode:
                    403,
            },
        );
    }

    const realm =
        getRealmForUserType(
            user.userType,
        );

    if (
        !role.allowsRealm(
            realm,
        )
    ) {
        throw new AuthenticationServiceError(
            "The assigned role is not valid for this authentication realm.",
            {
                code:
                    "ROLE_REALM_MISMATCH",
                statusCode:
                    403,
            },
        );
    }
}

function buildAccessClaims({
    user,
    role,
    sessionId,
}) {
    return {
        sub:
            String(
                user._id,
            ),

        userType:
            user.userType,

        roleId:
            String(
                role._id,
            ),

        role:
            role.key,

        vendorId:
            user.vendorId
                ? String(
                      user.vendorId,
                  )
                : null,

        sessionId:

            String(
                sessionId,
            ),

        type:
            ACCESS_TOKEN_TYPE,
    };
}

function buildRefreshClaims({
    user,
    role,
    sessionId,
}) {
    return {
        sub:
            String(
                user._id,
            ),

        userType:
            user.userType,

        roleId:
            String(
                role._id,
            ),

        role:
            role.key,

        vendorId:
            user.vendorId
                ? String(
                      user.vendorId,
                  )
                : null,

        sessionId:
            String(
                sessionId,
            ),

        type:
            REFRESH_TOKEN_TYPE,
    };
}

function signAccessToken(
    claims,
) {
    return jwt.sign(
        claims,
        env.jwt.access.secret,
        {
            algorithm:
                "HS256",

            expiresIn:
                env.jwt.access
                    .expiresIn,

            issuer:
                env.jwt.issuer,

            audience:
                env.jwt.audience,
        },
    );
}

function signRefreshToken(
    claims,
) {
    return jwt.sign(
        claims,
        env.jwt.refresh.secret,
        {
            algorithm:
                "HS256",

            expiresIn:
                env.jwt.refresh
                    .expiresIn,

            issuer:
                env.jwt.issuer,

            audience:
                env.jwt.audience,
        },
    );
}

function verifyRefreshToken(
    token,
) {
    try {
        const payload =
            jwt.verify(
                token,
                env.jwt.refresh
                    .secret,
                {
                    algorithms: [
                        "HS256",
                    ],

                    issuer:
                        env.jwt.issuer,

                    audience:
                        env.jwt.audience,

                    clockTolerance:
                        5,
                },
            );

        if (
            !payload ||
            typeof payload !==
                "object" ||
            payload.type !==
                REFRESH_TOKEN_TYPE ||
            !payload.sub ||
            !payload.sessionId
        ) {
            throw new AuthenticationServiceError(
                "Invalid refresh token.",
                {
                    code:
                        "INVALID_REFRESH_TOKEN",
                    statusCode:
                        401,
                },
            );
        }

        return payload;
    } catch (
        error
    ) {
        if (
            error instanceof
            AuthenticationServiceError
        ) {
            throw error;
        }

        if (
            error?.name ===
            "TokenExpiredError"
        ) {
            throw new AuthenticationServiceError(
                "Your refresh session has expired. Please sign in again.",
                {
                    code:
                        "REFRESH_TOKEN_EXPIRED",
                    statusCode:
                        401,
                },
            );
        }

        throw new AuthenticationServiceError(
            "Invalid refresh token.",
            {
                code:
                    "INVALID_REFRESH_TOKEN",
                statusCode:
                    401,
            },
        );
    }
}

async function persistRefreshToken({
    rawRefreshToken,
    user,
    sessionId,
    tokenFamilyId,
    role,
    requestContext = {},
}) {
    const refreshLifetimeSeconds =
        parseDurationToSeconds(
            env.jwt.refresh
                .expiresIn,
        );

    const expiresAt =
        new Date(
            Date.now() +
                refreshLifetimeSeconds *
                    1000,
        );

    const token =
        await RefreshToken.create({
            userId:
                user._id,

            tokenHash:
                hashToken(
                    rawRefreshToken,
                ),

            expiresAt,

            sessionId,

            realm:
                getRealmForUserType(
                    user.userType,
                ),

            ipAddress:
                requestContext
                    .ipAddress ??
                null,

            userAgent:
                requestContext
                    .userAgent ??
                null,

            tokenFamilyId,

            createdBy:
                user._id,
        });

    /*
     * role is intentionally referenced here to ensure the
     * authentication chain has loaded and validated the role
     * before creating the persistent session.
     */
    void role;

    return token;
}

async function createAuthenticationTokens({
    user,
    role,
    requestContext = {},
    existingSessionId = null,
    tokenFamilyId = null,
}) {
    const sessionId =
        existingSessionId ||
        createSessionId();

    const familyId =
        tokenFamilyId ||
        createTokenFamilyId();

    const accessClaims =
        buildAccessClaims({
            user,
            role,
            sessionId,
        });

    const refreshClaims =
        buildRefreshClaims({
            user,
            role,
            sessionId,
        });

    const accessToken =
        signAccessToken(
            accessClaims,
        );

    const refreshToken =
        signRefreshToken(
            refreshClaims,
        );

    await persistRefreshToken({
        rawRefreshToken:
            refreshToken,

        user,
        sessionId,

        tokenFamilyId:
            familyId,

        role,

        requestContext,
    });

    return {
        accessToken,

        refreshToken,

        sessionId,

        tokenFamilyId:
            familyId,
    };
}

/* -------------------------------------------------------------------------- */
/* Login                                                                      */
/* -------------------------------------------------------------------------- */

async function login({
    email,
    password,
    userType,
    requestContext = {},
}) {
    const normalizedEmail =
        normalizeEmail(
            email,
        );

    const normalizedUserType =
        assertUserType(
            userType,
        );

    if (
        !normalizedEmail ||
        !password
    ) {
        throw new AuthenticationServiceError(
            "Email and password are required.",
            {
                code:
                    "INVALID_LOGIN_INPUT",
                statusCode:
                    400,
            },
        );
    }

    const user =
        await User.findOne({
            email:
                normalizedEmail,

            userType:
                normalizedUserType,
        }).select(
            "+passwordHash",
        );

    /*
     * Do not reveal whether the email or password was incorrect.
     */
    if (
        !user
    ) {
        throw new AuthenticationServiceError(
            "Invalid email or password.",
            {
                code:
                    "INVALID_CREDENTIALS",
                statusCode:
                    401,
            },
        );
    }

    if (
        isUserLocked(
            user,
        )
    ) {
        throw new AuthenticationServiceError(
            "This account is temporarily locked.",
            {
                code:
                    "ACCOUNT_LOCKED",
                statusCode:
                    423,
            },
        );
    }

    if (
        !isUserActive(
            user,
        )
    ) {
        if (
            env.auth
                .rejectInactiveUsers
        ) {
            throw new AuthenticationServiceError(
                "This account is not active.",
                {
                    code:
                        "ACCOUNT_INACTIVE",
                    statusCode:
                        403,
                },
            );
        }
    }

    const passwordMatches =
        await bcrypt.compare(
            password,
            user.passwordHash,
        );

    if (
        !passwordMatches
    ) {
        user.recordLoginFailure({
            maxAttempts:
                env.auth
                    .maxLoginAttempts,

            lockoutMinutes:
                env.auth
                    .lockoutMinutes,
        });

        await user.save();

        throw new AuthenticationServiceError(
            "Invalid email or password.",
            {
                code:
                    "INVALID_CREDENTIALS",
                statusCode:
                    401,
            },
        );
    }

    const role =
        await loadRole(
            user.roleId,
        );

    assertRoleCompatibility(
        user,
        role,
    );

    /*
     * Load permissions now so the login response can expose the
     * effective authorization state to trusted frontend code.
     *
     * The backend remains authoritative; frontend permissions are
     * convenience/UI state and must never replace API enforcement.
     */
    const permissions =
        await loadPermissions(
            role._id,
        );

    user.recordSuccessfulLogin();

    await user.save();

    const tokens =
        await createAuthenticationTokens(
            {
                user,
                role,
                requestContext,
            },
        );

    return {
        user:
            sanitizeUser(
                user,
            ),

        role: {
            id:
                String(
                    role._id,
                ),

            key:
                role.key,

            name:
                role.name,

            system:
                role.system ===
                true,

            ownerRole:
                role.ownerRole ===
                true,
        },

        permissions,

        accessToken:
            tokens.accessToken,

        refreshToken:
            tokens.refreshToken,

        sessionId:
            tokens.sessionId,
    };
}

/* -------------------------------------------------------------------------- */
/* Admin / Vendor Login                                                       */
/* -------------------------------------------------------------------------- */

export async function adminLogin(
    {
        email,
        password,
        requestContext = {},
    },
) {
    const normalizedUserType =
        "admin";

    return login({
        email,
        password,

        userType:
            normalizedUserType,

        requestContext,
    });
}

export async function vendorLogin(
    {
        email,
        password,
        requestContext = {},
    },
) {
    return login({
        email,
        password,

        userType:
            USER_TYPES.VENDOR,

        requestContext,
    });
}

export async function internalLogin(
    {
        email,
        password,
        requestContext = {},
    },
) {
    return login({
        email,
        password,

        userType:
            USER_TYPES.INTERNAL,

        requestContext,
    });
}

/* -------------------------------------------------------------------------- */
/* Refresh                                                                    */
/* -------------------------------------------------------------------------- */

export async function refresh(
    {
        refreshToken,
        requestContext = {},
    },
) {
    if (
        typeof refreshToken !==
            "string" ||
        !refreshToken.trim()
    ) {
        throw new AuthenticationServiceError(
            "Refresh token is required.",
            {
                code:
                    "REFRESH_TOKEN_REQUIRED",
                statusCode:
                    401,
            },
        );
    }

    const rawRefreshToken =
        refreshToken.trim();

    const payload =
        verifyRefreshToken(
            rawRefreshToken,
        );

    const tokenHash =
        hashToken(
            rawRefreshToken,
        );

    const storedToken =
        await RefreshToken.findByHash(
            tokenHash,
        );

    if (
        !storedToken
    ) {
        throw new AuthenticationServiceError(
            "Refresh session is no longer valid.",
            {
                code:
                    "REFRESH_SESSION_NOT_FOUND",
                statusCode:
                    401,
            },
        );
    }

    /*
     * Token reuse detection.
     */
    if (
        storedToken.revokedAt ||
        storedToken.reusedAt
    ) {
        await RefreshToken.revokeTokenFamily(
            storedToken.tokenFamilyId,
        );

        throw new AuthenticationServiceError(
            "Refresh token reuse was detected. Please sign in again.",
            {
                code:
                    "REFRESH_TOKEN_REUSE_DETECTED",
                statusCode:
                    401,
            },
        );
    }

    if (
        storedToken.expiresAt.getTime() <=
        Date.now()
    ) {
        await RefreshToken.revokeByHash(
            tokenHash,
        );

        throw new AuthenticationServiceError(
            "Refresh session has expired. Please sign in again.",
            {
                code:
                    "REFRESH_SESSION_EXPIRED",
                statusCode:
                    401,
            },
        );
    }

    /*
     * The JWT and persisted token must refer to the same session.
     */
    if (
        String(
            storedToken.userId,
        ) !==
            String(
                payload.sub,
            ) ||
        String(
            storedToken.sessionId,
        ) !==
            String(
                payload.sessionId,
            )
    ) {
        await RefreshToken.revokeTokenFamily(
            storedToken.tokenFamilyId,
        );

        throw new AuthenticationServiceError(
            "Invalid refresh session.",
            {
                code:
                    "REFRESH_SESSION_MISMATCH",
                statusCode:
                    401,
            },
        );
    }

    const user =
        await User.findById(
            payload.sub,
        );

    if (
        !user
    ) {
        await RefreshToken.revokeTokenFamily(
            storedToken.tokenFamilyId,
        );

        throw new AuthenticationServiceError(
            "User account could not be found.",
            {
                code:
                    "USER_NOT_FOUND",
                statusCode:
                    401,
            },
        );
    }

    if (
        isUserLocked(
            user,
        ) ||
        !isUserActive(
            user,
        )
    ) {
        await RefreshToken.revokeTokenFamily(
            storedToken.tokenFamilyId,
        );

        throw new AuthenticationServiceError(
            "This account can no longer use this session.",
            {
                code:
                    "ACCOUNT_UNAVAILABLE",
                statusCode:
                    403,
            },
        );
    }

    const role =
        await loadRole(
            user.roleId,
        );

    assertRoleCompatibility(
        user,
        role,
    );

    const permissions =
        await loadPermissions(
            role._id,
        );

    /*
     * Rotate the existing refresh token.
     */
    if (
        env.auth
            .refreshTokenRotation
    ) {
        storedToken.revokedAt =
            new Date();

        await storedToken.save();
    }

    const tokens =
        await createAuthenticationTokens(
            {
                user,
                role,
                requestContext,

                existingSessionId:
                    String(
                        storedToken.sessionId,
                    ),

                tokenFamilyId:
                    String(
                        storedToken.tokenFamilyId,
                    ),
            },
        );

    return {
        user:
            sanitizeUser(
                user,
            ),

        role: {
            id:
                String(
                    role._id,
                ),

            key:
                role.key,

            name:
                role.name,

            system:
                role.system ===
                true,

            ownerRole:
                role.ownerRole ===
                true,
        },

        permissions,

        accessToken:
            tokens.accessToken,

        refreshToken:
            tokens.refreshToken,

        sessionId:
            tokens.sessionId,
    };
}

/* -------------------------------------------------------------------------- */
/* Logout                                                                     */
/* -------------------------------------------------------------------------- */

export async function logout({
    refreshToken,
    sessionId = null,
}) {
    if (
        refreshToken
    ) {
        const tokenHash =
            hashToken(
                refreshToken,
            );

        await RefreshToken.revokeByHash(
            tokenHash,
        );

        return {
            success:
                true,
        };
    }

    if (
        sessionId
    ) {
        await RefreshToken.revokeSession(
            sessionId,
        );

        return {
            success:
                true,
        };
    }

    return {
        success:
            true,
    };
}

export async function logoutAll(
    {
        userId,
    },
) {
    if (
        !userId
    ) {
        throw new AuthenticationServiceError(
            "User ID is required.",
            {
                code:
                    "USER_ID_REQUIRED",
                statusCode:
                    400,
            },
        );
    }

    await RefreshToken.revokeAllForUser(
        userId,
    );

    return {
        success:
            true,
    };
}

/* -------------------------------------------------------------------------- */
/* Authenticated User                                                         */
/* -------------------------------------------------------------------------- */

export async function me(
    {
        userId,
    },
) {
    if (
        !userId
    ) {
        throw new AuthenticationServiceError(
            "Authenticated user is required.",
            {
                code:
                    "AUTHENTICATED_USER_REQUIRED",
                statusCode:
                    401,
            },
        );
    }

    const user =
        await User.findById(
            userId,
        );

    if (
        !user
    ) {
        throw new AuthenticationServiceError(
            "User account could not be found.",
            {
                code:
                    "USER_NOT_FOUND",
                statusCode:
                    401,
            },
        );
    }

    if (
        !isUserActive(
            user,
        )
    ) {
        throw new AuthenticationServiceError(
            "This account is not active.",
            {
                code:
                    "ACCOUNT_INACTIVE",
                statusCode:
                    403,
            },
        );
    }

    const role =
        await loadRole(
            user.roleId,
        );

    assertRoleCompatibility(
        user,
        role,
    );

    const permissions =
        await loadPermissions(
            role._id,
        );

    return {
        user:
            sanitizeUser(
                user,
            ),

        role: {
            id:
                String(
                    role._id,
                ),

            key:
                role.key,

            name:
                role.name,

            system:
                role.system ===
                true,

            ownerRole:
                role.ownerRole ===
                true,
        },

        permissions,
    };
}

/* -------------------------------------------------------------------------- */
/* Password                                                                   */
/* -------------------------------------------------------------------------- */

export async function verifyPassword(
    {
        user,
        password,
    },
) {
    if (
        !user ||
        !password
    ) {
        return false;
    }

    let passwordHash =
        user.passwordHash;

    /*
     * If the document was loaded with select:false, explicitly
     * load the hash here.
     */
    if (
        !passwordHash &&
        user._id
    ) {
        const storedUser =
            await User.findById(
                user._id,
            ).select(
                "+passwordHash",
            );

        passwordHash =
            storedUser?.passwordHash;
    }

    if (
        !passwordHash
    ) {
        return false;
    }

    return bcrypt.compare(
        password,
        passwordHash,
    );
}

export async function hashPassword(
    password,
) {
    if (
        typeof password !==
            "string" ||
        password.length <
            env.auth
                .passwordMinLength
    ) {
        throw new AuthenticationServiceError(
            `Password must contain at least ${env.auth.passwordMinLength} characters.`,
            {
                code:
                    "INVALID_PASSWORD",
                statusCode:
                    400,
            },
        );
    }

    return bcrypt.hash(
        password,
        env.auth
            .bcryptSaltRounds,
    );
}

/* -------------------------------------------------------------------------- */
/* Exports                                                                    */
/* -------------------------------------------------------------------------- */

export const authService =
    Object.freeze({
        login,
        adminLogin,
        vendorLogin,
        internalLogin,
        refresh,
        logout,
        logoutAll,
        me,
        verifyPassword,
        hashPassword,
    });

export default authService;