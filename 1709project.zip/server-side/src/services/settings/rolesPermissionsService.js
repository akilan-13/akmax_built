// src/services/settings/rolesPermissionsService.js

import mongoose from "mongoose";

import Role from "../../models/Role.js";
import Permission from "../../models/Permission.js";
import RolePermission from "../../models/RolePermission.js";
import User from "../../models/User.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const ACTIONS = Object.freeze([
    "view",
    "add",
    "edit",
    "delete",
]);

const USER_TYPES = Object.freeze([
    "admin",
    "internal",
    "vendor",
]);

/* -------------------------------------------------------------------------- */
/* Errors                                                                     */
/* -------------------------------------------------------------------------- */

export class RolesPermissionsServiceError extends Error {
    constructor(
        message,
        {
            code = "ROLES_PERMISSIONS_ERROR",
            statusCode = 400,
            details = null,
        } = {},
    ) {
        super(message);

        this.name =
            "RolesPermissionsServiceError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        Error.captureStackTrace?.(
            this,
            RolesPermissionsServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeString(value) {
    return typeof value === "string"
        ? value.trim()
        : "";
}

function normalizeKey(value) {
    return normalizeString(value)
        .toLowerCase()
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_.-]/g, "_")
        .replace(/_+/g, "_")
        .replace(/^[_-]+|[_-]+$/g, "");
}

function normalizeBoolean(value) {
    return (
        value === true ||
        value === 1 ||
        value === "1" ||
        value === "true" ||
        value === "TRUE"
    );
}

function normalizeActions(value = {}) {
    const actions = {
        view: normalizeBoolean(
            value.view,
        ),

        add: normalizeBoolean(
            value.add,
        ),

        edit: normalizeBoolean(
            value.edit,
        ),

        delete: normalizeBoolean(
            value.delete,
        ),
    };

    if (
        normalizeBoolean(
            value.all,
        ) ||
        normalizeBoolean(
            value.ALL,
        )
    ) {
        actions.view = true;
        actions.add = true;
        actions.edit = true;
        actions.delete = true;
    }

    return actions;
}

function hasAnyAction(actions) {
    return ACTIONS.some(
        (action) =>
            actions[action] === true,
    );
}

function buildAll(actions) {
    return ACTIONS.every(
        (action) =>
            actions[action] === true,
    );
}

function assertObjectId(
    value,
    fieldName,
) {
    if (
        !value ||
        !mongoose.isValidObjectId(
            value,
        )
    ) {
        throw new RolesPermissionsServiceError(
            `Invalid ${fieldName}.`,
            {
                code:
                    "INVALID_OBJECT_ID",

                statusCode:
                    422,

                details: {
                    field:
                        fieldName,
                },
            },
        );
    }
}

function toObjectId(value) {
    return new mongoose.Types.ObjectId(
        value,
    );
}

function normalizeAllowedUserTypes(
    value,
) {
    if (!Array.isArray(value)) {
        return ["internal"];
    }

    const normalized = [
        ...new Set(
            value
                .map((item) =>
                    normalizeString(
                        item,
                    ).toLowerCase(),
                )
                .filter((item) =>
                    USER_TYPES.includes(
                        item,
                    ),
                ),
        ),
    ];

    return normalized.length
        ? normalized
        : ["internal"];
}

function serializePermission(
    permission,
) {
    if (!permission) {
        return null;
    }

    const actions =
        permission.actions || {};

    return {
        id: String(
            permission._id,
        ),

        key:
            permission.key,

        name:
            permission.name,

        description:
            permission.description ||
            "",

        category:
            permission.category ||
            "general",

        system:
            permission.system ===
            true,

        active:
            permission.active !==
            false,

        sortOrder:
            Number(
                permission.sortOrder ||
                    0,
            ),

        supportedActions: {
            view:
                actions.view === true,

            add:
                actions.add === true,

            edit:
                actions.edit === true,

            delete:
                actions.delete ===
                true,
        },
    };
}

function serializeRole(
    role,
    memberCount = 0,
) {
    if (!role) {
        return null;
    }

    return {
        id: String(
            role._id,
        ),

        key:
            role.key,

        name:
            role.name,

        description:
            role.description ||
            "",

        active:
            role.active !==
            false,

        system:
            role.system === true,

        ownerRole:
            role.ownerRole === true,

        realm:
            role.realm,

        allowedUserTypes:
            Array.isArray(
                role.allowedUserTypes,
            )
                ? role.allowedUserTypes
                : [],

        sortOrder:
            Number(
                role.sortOrder ||
                    0,
            ),

        members:
            Number(
                memberCount ||
                    0,
            ),

        createdAt:
            role.createdAt ||
            null,

        updatedAt:
            role.updatedAt ||
            null,
    };
}

function serializeAssignment(
    assignment,
) {
    const permission =
        assignment?.permissionId;

    if (!permission) {
        return null;
    }

    const actions =
        normalizeActions(
            assignment.actions,
        );

    return {
        permissionId:
            String(
                permission._id,
            ),

        key:
            permission.key,

        name:
            permission.name,

        description:
            permission.description ||
            "",

        category:
            permission.category ||
            "general",

        system:
            permission.system ===
            true,

        sortOrder:
            Number(
                permission.sortOrder ||
                    0,
            ),

        actions,

        all:
            buildAll(actions),

        active:
            assignment.active !==
            false,
    };
}

async function countMembersByRole(
    roleId,
) {
    return User.countDocuments({
        roleId,

        status: {
            $ne: "pending",
        },
    });
}

async function findRoleOrThrow(
    roleId,
) {
    assertObjectId(
        roleId,
        "roleId",
    );

    const role =
        await Role.findById(
            roleId,
        );

    if (!role) {
        throw new RolesPermissionsServiceError(
            "Role was not found.",
            {
                code:
                    "ROLE_NOT_FOUND",

                statusCode:
                    404,
            },
        );
    }

    return role;
}

/* -------------------------------------------------------------------------- */
/* Role List                                                                  */
/* -------------------------------------------------------------------------- */

export async function listRoles({
    search = "",
    active,
    realm,
    userType,
    page = 1,
    limit = 50,
} = {}) {
    const normalizedPage =
        Math.max(
            1,
            Number(page) || 1,
        );

    const normalizedLimit =
        Math.min(
            100,
            Math.max(
                1,
                Number(limit) ||
                    50,
            ),
        );

    const filter = {};

    const normalizedSearch =
        normalizeString(
            search,
        );

    if (normalizedSearch) {
        filter.$or = [
            {
                name: {
                    $regex:
                        normalizedSearch,

                    $options:
                        "i",
                },
            },

            {
                key: {
                    $regex:
                        normalizeKey(
                            normalizedSearch,
                        ),

                    $options:
                        "i",
                },
            },

            {
                description: {
                    $regex:
                        normalizedSearch,

                    $options:
                        "i",
                },
            },
        ];
    }

    if (
        typeof active ===
        "boolean"
    ) {
        filter.active =
            active;
    }

    if (
        typeof active ===
            "string" &&
        [
            "true",
            "false",
        ].includes(
            active.toLowerCase(),
        )
    ) {
        filter.active =
            active.toLowerCase() ===
            "true";
    }

    if (
        realm &&
        [
            "internal",
            "vendor",
            "both",
        ].includes(
            normalizeString(
                realm,
            ).toLowerCase(),
        )
    ) {
        filter.realm =
            normalizeString(
                realm,
            ).toLowerCase();
    }

    const normalizedUserType =
        normalizeString(
            userType,
        ).toLowerCase();

    if (
        USER_TYPES.includes(
            normalizedUserType,
        )
    ) {
        filter.allowedUserTypes =
            normalizedUserType;
    }

    const total =
        await Role.countDocuments(
            filter,
        );

    const roles =
        await Role.find(
            filter,
        )
            .sort({
                sortOrder:
                    1,

                name:
                    1,
            })

            .skip(
                (normalizedPage - 1) *
                    normalizedLimit,
            )

            .limit(
                normalizedLimit,
            )

            .lean();

    const roleIds =
        roles.map(
            (role) =>
                role._id,
        );

    const memberCounts =
        new Map();

    if (roleIds.length) {
        const grouped =
            await User.aggregate([
                {
                    $match: {
                        roleId: {
                            $in:
                                roleIds,
                        },

                        status: {
                            $ne:
                                "pending",
                        },
                    },
                },

                {
                    $group: {
                        _id:
                            "$roleId",

                        count: {
                            $sum:
                                1,
                        },
                    },
                },
            ]);

        for (const row of
            grouped) {
            memberCounts.set(
                String(
                    row._id,
                ),
                Number(
                    row.count ||
                        0,
                ),
            );
        }
    }

    const serializedRoles =
        roles.map(
            (role) =>
                serializeRole(
                    role,

                    memberCounts.get(
                        String(
                            role._id,
                        ),
                    ) || 0,
                ),
        );

    return {
        data:
            serializedRoles,

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            pages:
                Math.ceil(
                    total /
                        normalizedLimit,
                ),
        },
    };
}

/* -------------------------------------------------------------------------- */
/* Single Role                                                                */
/* -------------------------------------------------------------------------- */

export async function getRole(
    roleId,
) {
    const role =
        await findRoleOrThrow(
            roleId,
        );

    const memberCount =
        await countMembersByRole(
            role._id,
        );

    const assignments =
        await RolePermission.find(
            {
                roleId:
                    role._id,

                active:
                    true,
            },
        )
            .populate({
                path:
                    "permissionId",

                select:
                    "key name description category sortOrder active system actions",
            })
            .sort({
                "permissionId.sortOrder":
                    1,
            });

    return {
        role:
            serializeRole(
                role,
                memberCount,
            ),

        permissions:
            assignments
                .map(
                    serializeAssignment,
                )
                .filter(Boolean),
    };
}

/* -------------------------------------------------------------------------- */
/* Permission Catalog                                                         */
/* -------------------------------------------------------------------------- */

export async function listPermissions({
    search = "",
    category,
    active = true,
} = {}) {
    const filter = {};

    if (
        typeof active ===
        "boolean"
    ) {
        filter.active =
            active;
    }

    if (
        typeof active ===
        "string"
    ) {
        filter.active =
            active.toLowerCase() ===
            "true";
    }

    const normalizedCategory =
        normalizeString(
            category,
        ).toLowerCase();

    if (normalizedCategory) {
        filter.category =
            normalizedCategory;
    }

    const normalizedSearch =
        normalizeString(
            search,
        );

    if (normalizedSearch) {
        filter.$or = [
            {
                key: {
                    $regex:
                        normalizeKey(
                            normalizedSearch,
                        ),

                    $options:
                        "i",
                },
            },

            {
                name: {
                    $regex:
                        normalizedSearch,

                    $options:
                        "i",
                },
            },

            {
                description: {
                    $regex:
                        normalizedSearch,

                    $options:
                        "i",
                },
            },
        ];
    }

    const permissions =
        await Permission.find(
            filter,
        )
            .sort({
                sortOrder:
                    1,

                name:
                    1,
            })
            .lean();

    return permissions.map(
        serializePermission,
    );
}

/* -------------------------------------------------------------------------- */
/* Create Role                                                                */
/* -------------------------------------------------------------------------- */

export async function createRole({
    name,
    key,
    description = "",
    realm = "internal",
    allowedUserTypes = [
        "internal",
    ],
    sortOrder = 0,
    createdBy = null,
}) {
    const normalizedName =
        normalizeString(
            name,
        );

    if (!normalizedName) {
        throw new RolesPermissionsServiceError(
            "Role name is required.",
            {
                code:
                    "ROLE_NAME_REQUIRED",

                statusCode:
                    422,
            },
        );
    }

    if (
        normalizedName.length >
        150
    ) {
        throw new RolesPermissionsServiceError(
            "Role name cannot exceed 150 characters.",
            {
                code:
                    "ROLE_NAME_TOO_LONG",

                statusCode:
                    422,
            },
        );
    }

    const normalizedKey =
        normalizeKey(
            key ||
                normalizedName,
        );

    if (
        !normalizedKey ||
        normalizedKey.length >
            100
    ) {
        throw new RolesPermissionsServiceError(
            "A valid role key is required.",
            {
                code:
                    "INVALID_ROLE_KEY",

                statusCode:
                    422,
            },
        );
    }

    const normalizedRealm =
        normalizeString(
            realm,
        ).toLowerCase();

    if (
        ![
            "internal",
            "vendor",
            "both",
        ].includes(
            normalizedRealm,
        )
    ) {
        throw new RolesPermissionsServiceError(
            "Invalid role realm.",
            {
                code:
                    "INVALID_ROLE_REALM",

                statusCode:
                    422,
            },
        );
    }

    const normalizedUserTypes =
        normalizeAllowedUserTypes(
            allowedUserTypes,
        );

    for (const userType of
        normalizedUserTypes) {
        const compatible =
            normalizedRealm ===
                "both" ||
            (normalizedRealm ===
                "internal" &&
                [
                    "admin",
                    "internal",
                ].includes(
                    userType,
                )) ||
            (normalizedRealm ===
                "vendor" &&
                userType ===
                    "vendor");

        if (!compatible) {
            throw new RolesPermissionsServiceError(
                `User type "${userType}" is incompatible with realm "${normalizedRealm}".`,
                {
                    code:
                        "ROLE_REALM_USER_TYPE_MISMATCH",

                    statusCode:
                        422,
                },
            );
        }
    }

    if (createdBy) {
        assertObjectId(
            createdBy,
            "createdBy",
        );
    }

    const role =
        await Role.create({
            key:
                normalizedKey,

            name:
                normalizedName,

            description:
                normalizeString(
                    description,
                ),

            realm:
                normalizedRealm,

            allowedUserTypes:
                normalizedUserTypes,

            sortOrder:
                Math.max(
                    0,
                    Number(
                        sortOrder,
                    ) || 0,
                ),

            active:
                true,

            system:
                false,

            ownerRole:
                false,

            createdBy:
                createdBy
                    ? toObjectId(
                          createdBy,
                      )
                    : null,

            updatedBy:
                createdBy
                    ? toObjectId(
                          createdBy,
                      )
                    : null,
        });

    return serializeRole(
        role,
        0,
    );
}

/* -------------------------------------------------------------------------- */
/* Update Role                                                                */
/* -------------------------------------------------------------------------- */

export async function updateRole({
    roleId,
    name,
    key,
    description,
    realm,
    allowedUserTypes,
    sortOrder,
    active,
    updatedBy = null,
}) {
    const role =
        await findRoleOrThrow(
            roleId,
        );

    if (role.ownerRole) {
        if (
            key !== undefined ||
            realm !== undefined ||
            allowedUserTypes !==
                undefined ||
            active === false
        ) {
            throw new RolesPermissionsServiceError(
                "The workspace owner role is protected.",
                {
                    code:
                        "OWNER_ROLE_PROTECTED",

                    statusCode:
                        403,
                },
            );
        }
    }

    if (role.system) {
        if (
            key !== undefined &&
            normalizeKey(
                key,
            ) !== role.key
        ) {
            throw new RolesPermissionsServiceError(
                "System role keys cannot be changed.",
                {
                    code:
                        "SYSTEM_ROLE_KEY_PROTECTED",

                    statusCode:
                        403,
                },
            );
        }
    }

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            "updatedBy",
        );
    }

    const update = {};

    if (name !== undefined) {
        const normalizedName =
            normalizeString(
                name,
            );

        if (!normalizedName) {
            throw new RolesPermissionsServiceError(
                "Role name cannot be empty.",
                {
                    code:
                        "ROLE_NAME_REQUIRED",

                    statusCode:
                        422,
                },
            );
        }

        update.name =
            normalizedName;
    }

    if (key !== undefined) {
        const normalizedKey =
            normalizeKey(
                key,
            );

        if (!normalizedKey) {
            throw new RolesPermissionsServiceError(
                "Role key cannot be empty.",
                {
                    code:
                        "INVALID_ROLE_KEY",

                    statusCode:
                        422,
                },
            );
        }

        update.key =
            normalizedKey;
    }

    if (
        description !==
        undefined
    ) {
        update.description =
            normalizeString(
                description,
            );
    }

    if (realm !== undefined) {
        const normalizedRealm =
            normalizeString(
                realm,
            ).toLowerCase();

        if (
            ![
                "internal",
                "vendor",
                "both",
            ].includes(
                normalizedRealm,
            )
        ) {
            throw new RolesPermissionsServiceError(
                "Invalid role realm.",
                {
                    code:
                        "INVALID_ROLE_REALM",

                    statusCode:
                        422,
                },
            );
        }

        update.realm =
            normalizedRealm;
    }

    if (
        allowedUserTypes !==
        undefined
    ) {
        update.allowedUserTypes =
            normalizeAllowedUserTypes(
                allowedUserTypes,
            );
    }

    if (sortOrder !== undefined) {
        update.sortOrder =
            Math.max(
                0,
                Number(
                    sortOrder,
                ) || 0,
            );
    }

    if (active !== undefined) {
        update.active =
            normalizeBoolean(
                active,
            );
    }

    const effectiveRealm =
        update.realm ??
        role.realm;

    const effectiveUserTypes =
        update.allowedUserTypes ??
        role.allowedUserTypes;

    for (const userType of
        effectiveUserTypes) {
        const compatible =
            effectiveRealm ===
                "both" ||
            (effectiveRealm ===
                "internal" &&
                [
                    "admin",
                    "internal",
                ].includes(
                    userType,
                )) ||
            (effectiveRealm ===
                "vendor" &&
                userType ===
                    "vendor");

        if (!compatible) {
            throw new RolesPermissionsServiceError(
                `User type "${userType}" is incompatible with realm "${effectiveRealm}".`,
                {
                    code:
                        "ROLE_REALM_USER_TYPE_MISMATCH",

                    statusCode:
                        422,
                },
            );
        }
    }

    if (
        update.active ===
        false
    ) {
        const assignedUserCount =
            await User.countDocuments(
                {
                    roleId:
                        role._id,

                    status: {
                        $nin: [
                            "inactive",
                        ],
                    },
                },
            );

        if (
            assignedUserCount >
            0
        ) {
            throw new RolesPermissionsServiceError(
                "This role cannot be deactivated while active users are assigned to it.",
                {
                    code:
                        "ROLE_HAS_ACTIVE_USERS",

                    statusCode:
                        409,

                    details: {
                        assignedUserCount,
                    },
                },
            );
        }
    }

    if (updatedBy) {
        update.updatedBy =
            toObjectId(
                updatedBy,
            );
    }

    if (
        !Object.keys(
            update,
        ).length
    ) {
        return serializeRole(
            role,
            await countMembersByRole(
                role._id,
            ),
        );
    }

    const updatedRole =
        await Role.findByIdAndUpdate(
            role._id,
            {
                $set:
                    update,
            },
            {
                new: true,
                runValidators:
                    true,
            },
        );

    return serializeRole(
        updatedRole,
        await countMembersByRole(
            updatedRole._id,
        ),
    );
}

/* -------------------------------------------------------------------------- */
/* Delete Role                                                                */
/* -------------------------------------------------------------------------- */

export async function deleteRole({
    roleId,
}) {
    const role =
        await findRoleOrThrow(
            roleId,
        );

    if (
        role.system ||
        role.ownerRole
    ) {
        throw new RolesPermissionsServiceError(
            "System roles cannot be deleted.",
            {
                code:
                    "SYSTEM_ROLE_PROTECTED",

                statusCode:
                    403,
            },
        );
    }

    const assignedUserCount =
        await User.countDocuments(
            {
                roleId:
                    role._id,

                status: {
                    $nin: [
                        "inactive",
                    ],
                },
            },
        );

    if (
        assignedUserCount >
        0
    ) {
        throw new RolesPermissionsServiceError(
            "This role cannot be deleted while users are assigned to it.",
            {
                code:
                    "ROLE_HAS_ASSIGNED_USERS",

                statusCode:
                    409,

                details: {
                    assignedUserCount,
                },
            },
        );
    }

    const session =
        await mongoose.startSession();

    try {
        session.startTransaction();

        await RolePermission.updateMany(
            {
                roleId:
                    role._id,
            },
            {
                $set: {
                    active:
                        false,
                },
            },
            {
                session,
            },
        );

        await Role.findByIdAndUpdate(
            role._id,
            {
                $set: {
                    active:
                        false,
                },
            },
            {
                session,
                new: true,
            },
        );

        await session.commitTransaction();
    } catch (error) {
        await session.abortTransaction();

        throw error;
    } finally {
        await session.endSession();
    }

    return {
        id:
            String(
                role._id,
            ),

        key:
            role.key,

        deleted:
            true,
    };
}

/* -------------------------------------------------------------------------- */
/* Role Permission Matrix                                                     */
/* -------------------------------------------------------------------------- */

export async function getRolePermissionMatrix(
    roleId,
) {
    const roleData =
        await getRole(
            roleId,
        );

    const permissions =
        await Permission.find(
            {
                active:
                    true,
            },
        )
            .sort({
                sortOrder:
                    1,

                name:
                    1,
            })
            .lean();

    const assignments =
        new Map();

    for (const item of
        roleData.permissions) {
        assignments.set(
            item.key,
            item,
        );
    }

    return {
        role:
            roleData.role,

        permissions:
            permissions.map(
                (permission) => {
                    const current =
                        assignments.get(
                            permission.key,
                        );

                    const supported =
                        normalizeActions(
                            permission.actions,
                        );

                    const assigned =
                        normalizeActions(
                            current?.actions,
                        );

                    const actions = {
                        view:
                            supported.view &&
                            assigned.view,

                        add:
                            supported.add &&
                            assigned.add,

                        edit:
                            supported.edit &&
                            assigned.edit,

                        delete:
                            supported.delete &&
                            assigned.delete,
                    };

                    return {
                        id:
                            String(
                                permission._id,
                            ),

                        key:
                            permission.key,

                        name:
                            permission.name,

                        description:
                            permission.description ||
                            "",

                        category:
                            permission.category ||
                            "general",

                        sortOrder:
                            Number(
                                permission.sortOrder ||
                                    0,
                            ),

                        system:
                            permission.system ===
                            true,

                        active:
                            permission.active !==
                            false,

                        supportedActions:
                            supported,

                        actions,

                        all:
                            buildAll(
                                actions,
                            ),
                    };
                },
            ),
    };
}

/* -------------------------------------------------------------------------- */
/* Replace Role Permission Matrix                                             */
/* -------------------------------------------------------------------------- */

export async function replaceRolePermissions({
    roleId,
    assignments = [],
    updatedBy = null,
}) {
    const role =
        await findRoleOrThrow(
            roleId,
        );

    if (role.ownerRole) {
        throw new RolesPermissionsServiceError(
            "The workspace owner permissions are protected.",
            {
                code:
                    "OWNER_ROLE_PERMISSIONS_PROTECTED",

                statusCode:
                    403,
            },
        );
    }

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            "updatedBy",
        );
    }

    if (!Array.isArray(assignments)) {
        throw new RolesPermissionsServiceError(
            "Permission assignments must be an array.",
            {
                code:
                    "INVALID_PERMISSION_ASSIGNMENTS",

                statusCode:
                    422,
            },
        );
    }

    const permissionIds =
        new Set();

    const normalizedAssignments =
        [];

    for (const item of
        assignments) {
        const permissionId =
            item?.permissionId ||
            item?.id;

        if (
            !permissionId ||
            !mongoose.isValidObjectId(
                permissionId,
            )
        ) {
            continue;
        }

        const actions =
            normalizeActions(
                item?.actions ||
                    item,
            );

        const id =
            String(
                permissionId,
            );

        if (
            permissionIds.has(
                id,
            )
        ) {
            throw new RolesPermissionsServiceError(
                "A permission cannot be assigned more than once to the same role.",
                {
                    code:
                        "DUPLICATE_PERMISSION_ASSIGNMENT",

                    statusCode:
                        422,
                },
            );
        }

        permissionIds.add(
            id,
        );

        if (
            !hasAnyAction(
                actions,
            )
        ) {
            continue;
        }

        normalizedAssignments.push(
            {
                permissionId:
                    toObjectId(
                        permissionId,
                    ),

                actions,
            },
        );
    }

    const existingPermissions =
        normalizedAssignments.length
            ? await Permission.find(
                  {
                      _id: {
                          $in:
                              normalizedAssignments.map(
                                  (
                                      item,
                                  ) =>
                                      item.permissionId,
                              ),
                      },

                      active:
                          true,
                  },
              ).lean()
            : [];

    if (
        existingPermissions.length !==
        normalizedAssignments.length
    ) {
        const validIds =
            new Set(
                existingPermissions.map(
                    (
                        item,
                    ) =>
                        String(
                            item._id,
                        ),
                ),
            );

        const invalid =
            normalizedAssignments.find(
                (
                    item,
                ) =>
                    !validIds.has(
                        String(
                            item.permissionId,
                        ),
                    ),
            );

        throw new RolesPermissionsServiceError(
            "One or more selected permissions do not exist or are inactive.",
            {
                code:
                    "INVALID_PERMISSION_REFERENCE",

                statusCode:
                    422,

                details: {
                    permissionId:
                        invalid
                            ? String(
                                  invalid.permissionId,
                              )
                            : null,
                },
            },
        );
    }

    const session =
        await mongoose.startSession();

    try {
        session.startTransaction();

        await RolePermission.updateMany(
            {
                roleId:
                    role._id,
            },
            {
                $set: {
                    active:
                        false,

                    ...(updatedBy
                        ? {
                              updatedBy:
                                  toObjectId(
                                      updatedBy,
                                  ),
                          }
                        : {}),
                },
            },
            {
                session,
            },
        );

        for (const item of
            normalizedAssignments) {
            await RolePermission.updateOne(
                {
                    roleId:
                        role._id,

                    permissionId:
                        item.permissionId,
                },
                {
                    $set: {
                        actions:
                            item.actions,

                        active:
                            true,

                        ...(updatedBy
                            ? {
                                  updatedBy:
                                      toObjectId(
                                          updatedBy,
                                      ),
                              }
                            : {}),
                    },

                    $setOnInsert: {
                        roleId:
                            role._id,

                        permissionId:
                            item.permissionId,

                        ...(updatedBy
                            ? {
                                  createdBy:
                                      toObjectId(
                                          updatedBy,
                                      ),
                              }
                            : {}),
                    },
                },
                {
                    upsert:
                        true,

                    session,
                },
            );
        }

        await session.commitTransaction();
    } catch (error) {
        await session.abortTransaction();

        throw error;
    } finally {
        await session.endSession();
    }

    return getRolePermissionMatrix(
        role._id,
    );
}

/* -------------------------------------------------------------------------- */
/* Update Single Permission                                                   */
/* -------------------------------------------------------------------------- */

export async function updateRolePermission({
    roleId,
    permissionId,
    actions = {},
    updatedBy = null,
}) {
    assertObjectId(
        roleId,
        "roleId",
    );

    assertObjectId(
        permissionId,
        "permissionId",
    );

    const role =
        await findRoleOrThrow(
            roleId,
        );

    if (role.ownerRole) {
        throw new RolesPermissionsServiceError(
            "The workspace owner permissions are protected.",
            {
                code:
                    "OWNER_ROLE_PERMISSIONS_PROTECTED",

                statusCode:
                    403,
            },
        );
    }

    const permission =
        await Permission.findOne(
            {
                _id:
                    permissionId,

                active:
                    true,
            },
        );

    if (!permission) {
        throw new RolesPermissionsServiceError(
            "Permission was not found or is inactive.",
            {
                code:
                    "PERMISSION_NOT_FOUND",

                statusCode:
                    404,
            },
        );
    }

    const requested =
        normalizeActions(
            actions,
        );

    const supported =
        normalizeActions(
            permission.actions,
        );

    const effectiveActions =
        {
            view:
                supported.view &&
                requested.view,

            add:
                supported.add &&
                requested.add,

            edit:
                supported.edit &&
                requested.edit,

            delete:
                supported.delete &&
                requested.delete,
        };

    if (updatedBy) {
        assertObjectId(
            updatedBy,
            "updatedBy",
        );
    }

    const assignment =
        await RolePermission.findOneAndUpdate(
            {
                roleId:
                    role._id,

                permissionId:
                    permission._id,
            },
            {
                $set: {
                    actions:
                        effectiveActions,

                    active:
                        hasAnyAction(
                            effectiveActions,
                        ),

                    ...(updatedBy
                        ? {
                              updatedBy:
                                  toObjectId(
                                      updatedBy,
                                  ),
                          }
                        : {}),
                },

                $setOnInsert: {
                    roleId:
                        role._id,

                    permissionId:
                        permission._id,

                    ...(updatedBy
                        ? {
                              createdBy:
                                  toObjectId(
                                      updatedBy,
                                  ),
                          }
                        : {}),
                },
            },
            {
                upsert:
                    true,

                new:
                    true,

                runValidators:
                    true,
            },
        );

    return {
        role:
            serializeRole(
                role,
                await countMembersByRole(
                    role._id,
                ),
            ),

        assignment: {
            permissionId:
                String(
                    permission._id,
                ),

            key:
                permission.key,

            name:
                permission.name,

            actions:
                effectiveActions,

            all:
                buildAll(
                    effectiveActions,
                ),

            active:
                assignment.active ===
                true,
        },
    };
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

export default Object.freeze({
    listRoles,
    getRole,
    listPermissions,
    createRole,
    updateRole,
    deleteRole,
    getRolePermissionMatrix,
    replaceRolePermissions,
    updateRolePermission,
});