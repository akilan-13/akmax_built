// src/routes/settings/companySettings.routes.js

import { Router } from 'express';

import companySettingsController from '../../controllers/settings/companySettingsController.js';

import authMiddleware, {
  requireInternalUser,
} from '../../middleware/auth.js';

import {
  internalCanView,
  internalCanEdit,
} from '../../middleware/rbac.js';

import {
  companyLogoUpload,
  companyFaviconUpload,
} from '../../middleware/upload.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Authentication + authorization                                             */
/* -------------------------------------------------------------------------- */

/**
 * Company Information is an internal/admin Settings module.
 *
 * Every route below requires:
 *
 * 1. Valid access token
 * 2. Internal/admin authentication realm
 * 3. Corresponding company_settings permission
 *
 * Vendor users are explicitly rejected.
 */


/* -------------------------------------------------------------------------- */
/* GET /company                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Get current company profile.
 *
 * Frontend:
 *
 * GET /api/v1/settings/company
 *
 * Permission:
 *
 * company_settings → VIEW
 */
router.get(
  '/company',
  authMiddleware,
  requireInternalUser,
  internalCanView('company_settings',),
  companySettingsController.getCompanyProfile,
);


/* -------------------------------------------------------------------------- */
/* PATCH /company                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Update company profile text fields.
 *
 * Supports both:
 *
 * Frontend fields:
 * - companyName
 * - taxNumber
 * - email
 * - phone
 * - address
 *
 * Backend fields:
 * - legalName
 * - taxId
 * - contactEmail
 * - supportPhone
 * - headquartersAddress
 *
 * Permission:
 *
 * company_settings → EDIT
 */
router.patch(
  '/company',

  authMiddleware,
  requireInternalUser,
  internalCanEdit('company_settings',),
  companySettingsController.updateCompanyProfile,
);


/* -------------------------------------------------------------------------- */
/* POST /company/logo                                                         */
/* -------------------------------------------------------------------------- */

/**
 * Upload/replace company logo.
 *
 * Multipart field:
 *
 * logo
 *
 * Accepted by upload middleware:
 *
 * - PNG
 * - JPEG/JPG
 * - WEBP
 *
 * Storage:
 *
 * storage/private/company/
 */
router.post(
  '/company/logo',

  authMiddleware,

  requireInternalUser,

  internalCanEdit('company_settings',),

  companyLogoUpload,

  companySettingsController.uploadCompanyLogo,
);


/* -------------------------------------------------------------------------- */
/* DELETE /company/logo                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Remove company logo.
 */
router.delete(
  '/company/logo',

  authMiddleware,

  requireInternalUser,

  internalCanEdit(
    'company_settings',
  ),

  companySettingsController.deleteCompanyLogo,
);


/* -------------------------------------------------------------------------- */
/* POST /company/favicon                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Upload/replace company favicon.
 *
 * Multipart field:
 *
 * favicon
 *
 * Accepted types:
 *
 * - PNG
 * - JPEG/JPG
 * - WEBP
 * - ICO
 * - SVG
 */
router.post(
  '/company/favicon',

  authMiddleware,

  requireInternalUser,

  internalCanEdit(
    'company_settings',
  ),

  companyFaviconUpload,

  companySettingsController.uploadCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* DELETE /company/favicon                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Remove company favicon.
 */
router.delete(
  '/company/favicon',

  authMiddleware,

  requireInternalUser,

  internalCanEdit(
    'company_settings',
  ),

  companySettingsController.deleteCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* PATCH /company/status                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Activate/deactivate company profile.
 *
 * Body:
 *
 * {
 *   "active": true
 * }
 *
 * Permission:
 *
 * company_settings → EDIT
 */
router.patch(
  '/company/status',

  authMiddleware,

  requireInternalUser,

  internalCanEdit(
    'company_settings',
  ),

  companySettingsController.updateCompanyStatus,
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;