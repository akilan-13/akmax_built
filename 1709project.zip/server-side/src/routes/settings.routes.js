// src/routes/settings.routes.js

import { Router } from 'express';

import companySettingsController from '../controllers/settings/companySettingsController.js';
import rolesPermissionsController from '../controllers/settings/rolesPermissionsController.js';
import apiConfigController from '../controllers/settings/apiConfigController.js';
import commonSettingsController from '../controllers/settings/commonSettingsController.js';
import fileController from '../controllers/storage/fileController.js';

import authMiddleware, {
  requireInternalUser,
} from '../middleware/auth.js';

import rbacMiddleware from '../middleware/rbac.js';

import uploadMiddleware from '../middleware/upload.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router =
  Router();


/* -------------------------------------------------------------------------- */
/* COMPANY INFORMATION                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/company
 */
router.get(
  '/company',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'view',
  }),

  companySettingsController.getCompanyProfile,
);


/**
 * PATCH /api/v1/settings/company
 */
router.patch(
  '/company',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  companySettingsController.updateCompanyProfile,
);


/**
 * POST /api/v1/settings/company/logo
 *
 * multipart/form-data
 * field: logo
 */
router.post(
  '/company/logo',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  uploadMiddleware.single(
    'logo',
  ),

  companySettingsController.uploadCompanyLogo,
);


/**
 * DELETE /api/v1/settings/company/logo
 */
router.delete(
  '/company/logo',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  companySettingsController.deleteCompanyLogo,
);


/**
 * POST /api/v1/settings/company/favicon
 *
 * multipart/form-data
 * field: favicon
 */
router.post(
  '/company/favicon',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  uploadMiddleware.single(
    'favicon',
  ),

  companySettingsController.uploadCompanyFavicon,
);


/**
 * DELETE /api/v1/settings/company/favicon
 */
router.delete(
  '/company/favicon',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  companySettingsController.deleteCompanyFavicon,
);


/**
 * PATCH /api/v1/settings/company/status
 */
router.patch(
  '/company/status',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'edit',
  }),

  companySettingsController.updateCompanyStatus,
);


/* -------------------------------------------------------------------------- */
/* PROTECTED COMPANY FILE ACCESS                                              */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/company/logo
 *
 * Protected inline logo access.
 *
 * IMPORTANT:
 * No express.static() is used.
 */
router.get(
  '/company/logo',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'view',
  }),

  fileController.getCompanyLogo,
);


/**
 * GET /api/v1/settings/company/logo/download
 */
router.get(
  '/company/logo/download',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'view',
  }),

  fileController.downloadCompanyLogo,
);


/**
 * GET /api/v1/settings/company/favicon
 */
router.get(
  '/company/favicon',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'view',
  }),

  fileController.getCompanyFavicon,
);


/**
 * GET /api/v1/settings/company/favicon/download
 */
router.get(
  '/company/favicon/download',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'company_settings',

    action:
      'view',
  }),

  fileController.downloadCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* ROLES & PERMISSIONS                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/roles
 *
 * List roles.
 */
router.get(
  '/roles',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'user_role',

    action:
      'view',
  }),

  rolesPermissionsController.list,
);


/**
 * GET /api/v1/settings/roles/:roleId
 *
 * Get one role.
 */
router.get(
  '/roles/:roleId',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'user_role',

    action:
      'view',
  }),

  rolesPermissionsController.get,
);


/**
 * POST /api/v1/settings/roles
 *
 * Create role.
 */
router.post(
  '/roles',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'user_role',

    action:
      'add',
  }),

  rolesPermissionsController.create,
);


/**
 * PATCH /api/v1/settings/roles/:roleId
 *
 * Update role.
 */
router.patch(
  '/roles/:roleId',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'user_role',

    action:
      'edit',
  }),

  rolesPermissionsController.update,
);


/**
 * DELETE /api/v1/settings/roles/:roleId
 *
 * Delete/deactivate role.
 */
router.delete(
  '/roles/:roleId',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'user_role',

    action:
      'delete',
  }),

  rolesPermissionsController.remove,
);


/* -------------------------------------------------------------------------- */
/* API CONFIGURATION                                                          */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/api-configurations
 */
router.get(
  '/api-configurations',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'api_config',

    action:
      'view',
  }),

  apiConfigController.list,
);


/**
 * GET /api/v1/settings/api-configurations/:id
 */
router.get(
  '/api-configurations/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'api_config',

    action:
      'view',
  }),

  apiConfigController.get,
);


/**
 * POST /api/v1/settings/api-configurations
 */
router.post(
  '/api-configurations',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'api_config',

    action:
      'add',
  }),

  apiConfigController.create,
);


/**
 * PATCH /api/v1/settings/api-configurations/:id
 */
router.patch(
  '/api-configurations/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'api_config',

    action:
      'edit',
  }),

  apiConfigController.update,
);


/**
 * DELETE /api/v1/settings/api-configurations/:id
 */
router.delete(
  '/api-configurations/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'api_config',

    action:
      'delete',
  }),

  apiConfigController.remove,
);


/* -------------------------------------------------------------------------- */
/* COMMON SETTINGS                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Common Settings currently cover UI-defined configuration such as:
 *
 * - Units
 * - Validity Period
 * - Terms & Conditions
 *
 * The setting type can be supplied as a query parameter:
 *
 * ?type=unit
 * ?type=validity_period
 * ?type=terms_condition
 */


/**
 * GET /api/v1/settings/common
 */
router.get(
  '/common',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'platform_settings',

    action:
      'view',
  }),

  commonSettingsController.list,
);


/**
 * GET /api/v1/settings/common/:id
 */
router.get(
  '/common/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'platform_settings',

    action:
      'view',
  }),

  commonSettingsController.get,
);


/**
 * POST /api/v1/settings/common
 */
router.post(
  '/common',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'platform_settings',

    action:
      'add',
  }),

  commonSettingsController.create,
);


/**
 * PATCH /api/v1/settings/common/:id
 */
router.patch(
  '/common/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'platform_settings',

    action:
      'edit',
  }),

  commonSettingsController.update,
);


/**
 * DELETE /api/v1/settings/common/:id
 */
router.delete(
  '/common/:id',

  authMiddleware,

  requireInternalUser,

  rbacMiddleware({
    module:
      'platform_settings',

    action:
      'delete',
  }),

  commonSettingsController.remove,
);


/* -------------------------------------------------------------------------- */
/* FUTURE / DOMAIN-SPECIFIC SETTINGS                                          */
/* -------------------------------------------------------------------------- */

/**
 * Vendor Settings
 *
 * Planned domains:
 *
 * - Vendor Category
 * - Currency
 * - Payment Terms
 * - Industry Sector
 * - Vendor Status
 *
 * These will be attached here once their dedicated service/model
 * implementations are completed.
 *
 * They should NOT be mixed into vendor transaction routes.
 */


/**
 * Master Rate Settings
 *
 * Category management remains a settings concern while the actual
 * Master Rate Schedule remains under /master-rate routes.
 */


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;