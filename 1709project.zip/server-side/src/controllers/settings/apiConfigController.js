import {
  listApiConfigurations,
  getApiConfiguration,
  createApiConfiguration,
  updateApiConfiguration,
  setApiConfigurationStatus,
  deleteApiConfiguration,
  bulkUpdateStatus,
  ApiConfigServiceError,
} from "../../services/settings/apiConfigService.js";

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Resolve the authenticated user ID from the authentication middleware.
 *
 * Supports both:
 *   req.user.id
 *   req.user._id
 */
function getAuthenticatedUserId(req) {
  return (
    req.user?.id ||
    req.user?._id ||
    null
  );
}

/**
 * Authentication is already enforced by the route middleware, but keep
 * the controller boundary defensive as well.
 */
function requireAuthenticatedUser(req) {
  const userId =
    getAuthenticatedUserId(req);

  if (!userId) {
    throw new ApiConfigServiceError(
      "Authentication is required.",
      {
        code:
          "AUTHENTICATION_REQUIRED",
        statusCode: 401,
      },
    );
  }

  return userId;
}

/**
 * Convert query values safely.
 */
function getQueryString(
  value,
  fallback = "",
) {
  if (
    value === undefined ||
    value === null
  ) {
    return fallback;
  }

  if (Array.isArray(value)) {
    return String(
      value[0] ?? fallback,
    ).trim();
  }

  return String(value).trim();
}

/**
 * Convert common boolean query values.
 */
function parseBooleanQuery(
  value,
) {
  if (
    value === undefined ||
    value === null ||
    value === ""
  ) {
    return undefined;
  }

  if (
    typeof value === "boolean"
  ) {
    return value;
  }

  const normalized =
    String(value)
      .trim()
      .toLowerCase();

  if (
    normalized === "true" ||
    normalized === "1"
  ) {
    return true;
  }

  if (
    normalized === "false" ||
    normalized === "0"
  ) {
    return false;
  }

  /*
   * Leave validation of an invalid value to the service layer
   * by returning the original value.
   */
  return value;
}

/**
 * Extract a usable ID array from a request body.
 *
 * Supports:
 *
 * {
 *   ids: ["...", "..."]
 * }
 *
 * and:
 *
 * {
 *   ids: "id1,id2"
 * }
 */
function parseIds(
  value,
) {
  if (
    Array.isArray(value)
  ) {
    return value
      .map((id) =>
        String(id).trim(),
      )
      .filter(Boolean);
  }

  if (
    typeof value === "string"
  ) {
    return value
      .split(",")
      .map((id) => id.trim())
      .filter(Boolean);
  }

  return [];
}

/* -------------------------------------------------------------------------- */
/* Error Handling                                                             */
/* -------------------------------------------------------------------------- */

function sendError(
  res,
  error,
) {
  if (
    error instanceof
    ApiConfigServiceError
  ) {
    return res
      .status(
        error.statusCode || 400,
      )
      .json({
        success: false,

        message:
          error.message,

        code:
          error.code,

        ...(error.details
          ? {
              details:
                error.details,
            }
          : {}),
      });
  }

  /*
   * Mongoose validation errors.
   */
  if (
    error?.name ===
    "ValidationError"
  ) {
    const fields = {};

    for (
      const [
        field,
        fieldError,
      ] of Object.entries(
        error.errors || {},
      )
    ) {
      fields[field] =
        fieldError.message;
    }

    return res
      .status(422)
      .json({
        success: false,

        message:
          "API configuration validation failed.",

        code:
          "VALIDATION_ERROR",

        fields,
      });
  }

  /*
   * Invalid ObjectId.
   */
  if (
    error?.name ===
      "CastError" &&
    error?.kind === "ObjectId"
  ) {
    return res
      .status(400)
      .json({
        success: false,

        message:
          "Invalid API configuration ID.",

        code:
          "INVALID_API_CONFIGURATION_ID",
      });
  }

  /*
   * Mongo duplicate-key error.
   */
  if (
    error?.code === 11000
  ) {
    return res
      .status(409)
      .json({
        success: false,

        message:
          "An API configuration with the same identifier already exists.",

        code:
          "API_CONFIGURATION_DUPLICATE",

        ...(error.keyValue
          ? {
              details: {
                duplicate:
                  Object.keys(
                    error.keyValue,
                  ),
              },
            }
          : {}),
      });
  }

  /*
   * Never return raw database errors to the browser.
   */
  console.error(
    "[apiConfigController]",
    error,
  );

  return res
    .status(500)
    .json({
      success: false,

      message:
        "An unexpected error occurred while processing the API configuration request.",

      code:
        "INTERNAL_SERVER_ERROR",
    });
}

/* -------------------------------------------------------------------------- */
/* LIST                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/api-configurations
 */
export async function list(
  req,
  res,
) {
  try {
    requireAuthenticatedUser(
      req,
    );

    const result =
      await listApiConfigurations(
        {
          page:
            getQueryString(
              req.query?.page,
              "1",
            ),

          limit:
            getQueryString(
              req.query?.limit,
              "25",
            ),

          search:
            getQueryString(
              req.query?.search,
              "",
            ),

          active:
            parseBooleanQuery(
              req.query?.active,
            ),

          sort:
            getQueryString(
              req.query?.sort,
              "sortOrder",
            ),

          sortOrder:
            getQueryString(
              req.query
                ?.sortOrder,
              "asc",
            ),
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "API configurations retrieved successfully.",

        data:
          result.items,

        /*
         * Keep pagination separately available for the existing UI
         * and future consumers.
         */
        pagination:
          result.pagination,

        filters:
          result.filters,

        sort:
          result.sort,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* GET                                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/api-configurations/:id
 */
export async function get(
  req,
  res,
) {
  try {
    requireAuthenticatedUser(
      req,
    );

    const result =
      await getApiConfiguration(
        req.params?.id,
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "API configuration retrieved successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* CREATE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/settings/api-configurations
 */
export async function create(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const result =
      await createApiConfiguration(
        req.body || {},
        {
          userId,
        },
      );

    return res
      .status(201)
      .json({
        success: true,

        message:
          "API configuration created successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* UPDATE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/api-configurations/:id
 */
export async function update(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const result =
      await updateApiConfiguration(
        req.params?.id,
        req.body || {},
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "API configuration updated successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* STATUS                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/api-configurations/:id/status
 *
 * Supported body:
 *
 * {
 *   "active": true
 * }
 *
 * Also accepts:
 *
 * {
 *   "status": "active"
 * }
 *
 * for compatibility with possible frontend callers.
 */
export async function setStatus(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    let active =
      req.body?.active;

    /*
     * Backward-compatible status support.
     */
    if (
      active === undefined &&
      req.body?.status !==
        undefined
    ) {
      const status =
        String(
          req.body.status,
        )
          .trim()
          .toLowerCase();

      if (
        status === "active"
      ) {
        active = true;
      } else if (
        status === "inactive"
      ) {
        active = false;
      }
    }

    const result =
      await setApiConfigurationStatus(
        req.params?.id,
        active,
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          active === true ||
          active === "true" ||
          active === 1 ||
          active === "1"
            ? "API configuration enabled successfully."
            : "API configuration disabled successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* DELETE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /api/v1/settings/api-configurations/:id
 */
export async function remove(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    /*
     * The normal UI delete operation physically removes a
     * non-system API configuration.
     */
    const result =
      await deleteApiConfiguration(
        req.params?.id,
        {
          userId,
          hardDelete: true,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "API configuration deleted successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* BULK STATUS                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/api-configurations/bulk-status
 *
 * Body:
 *
 * {
 *   "ids": ["...", "..."],
 *   "active": true
 * }
 */
export async function bulkStatus(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const ids =
      parseIds(
        req.body?.ids,
      );

    const result =
      await bulkUpdateStatus(
        ids,
        req.body?.active,
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "API configuration statuses updated successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

const apiConfigController = {
  list,

  get,

  create,

  update,

  setStatus,

  remove,

  bulkStatus,
};

export default apiConfigController;