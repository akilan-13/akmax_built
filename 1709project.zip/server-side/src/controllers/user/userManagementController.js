// src/controllers/user/userManagementController.js

import userManagementService, {
    UserManagementServiceError,
} from '../../services/user/userManagementService.js';


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getAuthenticatedUserId(
    req,
) {
    return (
        req?.user?.id ||
        req?.user?.userId ||
        req?.user?._id ||
        null
    );
}


function getQueryValue(
    value,
) {
    if (
        Array.isArray(
            value,
        )
    ) {
        return value[0];
    }

    return value;
}


function parseBoolean(
    value,
) {
    if (
        value ===
            undefined ||
        value === null ||
        value === ''
    ) {
        return undefined;
    }

    if (
        typeof value ===
        'boolean'
    ) {
        return value;
    }

    const normalized =
        String(
            value,
        )
            .trim()
            .toLowerCase();

    if (
        normalized ===
            'true' ||
        normalized ===
            '1'
    ) {
        return true;
    }

    if (
        normalized ===
            'false' ||
        normalized ===
            '0'
    ) {
        return false;
    }

    return undefined;
}


function parsePositiveInteger(
    value,
    fallback,
) {
    const parsed =
        Number.parseInt(
            String(
                value ?? '',
            ),
            10,
        );

    if (
        !Number.isFinite(
            parsed,
        ) ||
        parsed <= 0
    ) {
        return fallback;
    }

    return parsed;
}


function sendSuccess(
    res,
    {
        statusCode = 200,
        message =
            'Request completed successfully.',
        data = null,
    } = {},
) {
    return res
        .status(
            statusCode,
        )
        .json({
            success:
                true,

            message,

            data,
        });
}


function sendError(
    res,
    error,
) {
    if (
        error instanceof
        UserManagementServiceError
    ) {
        return res
            .status(
                error.statusCode ||
                    400,
            )
            .json({
                success:
                    false,

                message:
                    error.message,

                code:
                    error.code,

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }


    if (
        error?.code ===
        11000
    ) {
        return res
            .status(
                409,
            )
            .json({
                success:
                    false,

                message:
                    'A user with the supplied unique value already exists.',

                code:
                    'DUPLICATE_RECORD',
            });
    }


    if (
        error?.name ===
        'ValidationError'
    ) {
        const fields =
            {};

        for (
            const [
                field,
                detail,
            ] of Object.entries(
                error.errors ||
                    {},
            )
        ) {
            fields[field] =
                detail.message;
        }

        return res
            .status(
                422,
            )
            .json({
                success:
                    false,

                message:
                    'Validation failed.',

                code:
                    'VALIDATION_ERROR',

                details: {
                    fields,
                },
            });
    }


    if (
        error?.name ===
        'CastError'
    ) {
        return res
            .status(
                422,
            )
            .json({
                success:
                    false,

                message:
                    'One or more supplied identifiers are invalid.',

                code:
                    'INVALID_IDENTIFIER',
            });
    }


    console.error(
        '[UserManagementController]',
        error,
    );


    return res
        .status(
            500,
        )
        .json({
            success:
                false,

            message:
                'Unable to process the user management request.',

            code:
                'INTERNAL_SERVER_ERROR',
        });
}


/* -------------------------------------------------------------------------- */
/* GET /users                                                                 */
/* -------------------------------------------------------------------------- */

export const list =
    async (
        req,
        res,
    ) => {
        try {
            const query =
                req.query ||
                {};

            const result =
                await userManagementService.listUsers(
                    {
                        search:
                            getQueryValue(
                                query.search,
                            ) || '',

                        roleId:
                            getQueryValue(
                                query.roleId ??
                                    query.role_id,
                            ) || '',

                        status:
                            getQueryValue(
                                query.status,
                            ) || '',

                        userType:
                            getQueryValue(
                                query.userType ??
                                    query.user_type,
                            ) || '',

                        vendorId:
                            getQueryValue(
                                query.vendorId ??
                                    query.vendor_id,
                            ) || '',

                        page:
                            parsePositiveInteger(
                                getQueryValue(
                                    query.page,
                                ),
                                1,
                            ),

                        limit:
                            Math.min(
                                100,
                                parsePositiveInteger(
                                    getQueryValue(
                                        query.limit ??
                                            query.perPage ??
                                            query.per_page,
                                    ),
                                    25,
                                ),
                            ),
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'Users loaded successfully.',

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* GET /users/:id                                                              */
/* -------------------------------------------------------------------------- */

export const get =
    async (
        req,
        res,
    ) => {
        try {
            const userId =
                req.params?.id;

            const user =
                await userManagementService.getUser(
                    userId,
                );

            return sendSuccess(
                res,
                {
                    message:
                        'User loaded successfully.',

                    data:
                        user,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* POST /users                                                                 */
/* -------------------------------------------------------------------------- */

export const create =
    async (
        req,
        res,
    ) => {
        try {
            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const user =
                await userManagementService.createUser(
                    {
                        email:
                            body.email,

                        displayName:
                            body.displayName ??
                            body.name,

                        password:
                            body.password,

                        userType:
                            body.userType ??
                            body.user_type ??
                            'admin',

                        roleId:
                            body.roleId ??
                            body.role_id ??
                            body.role,

                        vendorId:
                            body.vendorId ??
                            body.vendor_id ??
                            null,

                        status:
                            body.status ??
                            'active',

                        createdBy:
                            actorId,
                    },
                );

            return sendSuccess(
                res,
                {
                    statusCode:
                        201,

                    message:
                        'User created successfully.',

                    data:
                        user,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* PATCH /users/:id                                                            */
/* -------------------------------------------------------------------------- */

export const update =
    async (
        req,
        res,
    ) => {
        try {
            const userId =
                req.params?.id;

            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const user =
                await userManagementService.updateUser(
                    {
                        userId,

                        email:
                            body.email,

                        displayName:
                            body.displayName ??
                            body.name,

                        password:
                            body.password,

                        userType:
                            body.userType ??
                            body.user_type,

                        roleId:
                            body.roleId ??
                            body.role_id ??
                            body.role,

                        vendorId:
                            body.vendorId ??
                            body.vendor_id,

                        status:
                            body.status,

                        updatedBy:
                            actorId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'User updated successfully.',

                    data:
                        user,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* PATCH /users/:id/status                                                    */
/* -------------------------------------------------------------------------- */

export const updateStatus =
    async (
        req,
        res,
    ) => {
        try {
            const userId =
                req.params?.id;

            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const status =
                String(
                    body.status ||
                        '',
                )
                    .trim()
                    .toLowerCase();

            if (
                status !==
                    'active' &&
                status !==
                    'inactive'
            ) {
                return res
                    .status(
                        422,
                    )
                    .json({
                        success:
                            false,

                        message:
                            'Status must be active or inactive.',

                        code:
                            'INVALID_USER_STATUS',
                    });
            }

            const user =
                status ===
                'active'
                    ? await userManagementService.activateUser(
                          {
                              userId,

                              updatedBy:
                                  actorId,
                          },
                      )
                    : await userManagementService.deactivateUser(
                          {
                              userId,

                              updatedBy:
                                  actorId,
                          },
                      );

            return sendSuccess(
                res,
                {
                    message:
                        `User ${status === 'active' ? 'activated' : 'deactivated'} successfully.`,

                    data:
                        user,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* PATCH /users/:id/password                                                   */
/* -------------------------------------------------------------------------- */

export const resetPassword =
    async (
        req,
        res,
    ) => {
        try {
            const userId =
                req.params?.id;

            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const result =
                await userManagementService.resetPassword(
                    {
                        userId,

                        password:
                            body.password ??
                            body.newPassword ??
                            body.new_password,

                        updatedBy:
                            actorId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'User password reset successfully.',

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* PATCH /users/:id/role                                                       */
/* -------------------------------------------------------------------------- */

export const assignRole =
    async (
        req,
        res,
    ) => {
        try {
            const userId =
                req.params?.id;

            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const roleId =
                body.roleId ??
                body.role_id ??
                body.role;

            if (
                !roleId
            ) {
                return res
                    .status(
                        422,
                    )
                    .json({
                        success:
                            false,

                        message:
                            'Role is required.',

                        code:
                            'ROLE_REQUIRED',
                    });
            }

            const user =
                await userManagementService.assignRole(
                    {
                        userId,

                        roleId,

                        updatedBy:
                            actorId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'User role assigned successfully.',

                    data:
                        user,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* GET /users/check-email                                                      */
/* -------------------------------------------------------------------------- */

export const checkEmail =
    async (
        req,
        res,
    ) => {
        try {
            const query =
                req.query ||
                {};

            const result =
                await userManagementService.checkEmailAvailability(
                    {
                        email:
                            getQueryValue(
                                query.email,
                            ),

                        excludeUserId:
                            getQueryValue(
                                query.excludeUserId ??
                                    query.exclude_user_id,
                            ) ||
                            null,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'Email availability checked successfully.',

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* PATCH /users/bulk-status                                                    */
/* -------------------------------------------------------------------------- */

export const bulkUpdateStatus =
    async (
        req,
        res,
    ) => {
        try {
            const body =
                req.body ||
                {};

            const actorId =
                getAuthenticatedUserId(
                    req,
                );

            const userIds =
                body.userIds ??
                body.user_ids ??
                body.ids ??
                [];

            const result =
                await userManagementService.bulkUpdateStatus(
                    {
                        userIds,

                        status:
                            body.status,

                        updatedBy:
                            actorId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        'User statuses updated successfully.',

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default {
    list,
    get,
    create,
    update,
    updateStatus,
    resetPassword,
    assignRole,
    checkEmail,
    bulkUpdateStatus,
};