// src/controllers/masterRate/rateHistoryController.js

import {
    getRateHistory,
    RateServiceError,
} from "../../services/masterRate/rateService.js";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getAuthenticatedUserId(
    req,
) {
    return (
        req.user?.id ||
        req.user?._id ||
        req.user?.userId ||
        null
    );
}

function requireAuthenticatedUser(
    req,
) {
    const userId =
        getAuthenticatedUserId(
            req,
        );

    if (!userId) {
        throw new RateServiceError(
            "Authentication is required.",
            {
                code:
                    "AUTHENTICATION_REQUIRED",
                statusCode: 401,
            },
        );
    }

    return userId;
}

function getQueryValue(
    value,
    fallback = "",
) {
    if (
        value === undefined ||
        value === null
    ) {
        return fallback;
    }

    if (
        Array.isArray(
            value,
        )
    ) {
        return String(
            value[0] ??
                fallback,
        ).trim();
    }

    return String(
        value,
    ).trim();
}

/*
|--------------------------------------------------------------------------
| Error Handling
|--------------------------------------------------------------------------
*/

function sendError(
    res,
    error,
) {
    if (
        error instanceof
        RateServiceError
    ) {
        return res
            .status(
                error.statusCode ||
                    400,
            )
            .json({
                success: false,

                message:
                    error.message,

                code:
                    error.code,

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    if (
        error?.name ===
            "CastError" &&
        error?.kind ===
            "ObjectId"
    ) {
        return res
            .status(400)
            .json({
                success: false,

                message:
                    "Invalid master rate ID.",

                code:
                    "INVALID_MASTER_RATE_ID",
            });
    }

    if (
        error?.name ===
        "ValidationError"
    ) {
        const fields = {};

        Object.entries(
            error.errors || {},
        ).forEach(
            ([
                field,
                fieldError,
            ]) => {
                fields[field] =
                    fieldError.message;
            },
        );

        return res
            .status(422)
            .json({
                success: false,

                message:
                    "Rate history validation failed.",

                code:
                    "VALIDATION_ERROR",

                fields,
            });
    }

    console.error(
        "[rateHistoryController]",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "An unexpected error occurred while retrieving rate history.",

            code:
                "INTERNAL_SERVER_ERROR",
        });
}

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
|
| GET /api/master-rates/:id/history
|
|--------------------------------------------------------------------------
|
| Returns:
|
| {
|   success: true,
|   data: [
|      {
|          rate,
|          effectiveDate,
|          updatedAt,
|          updatedBy
|      }
|   ],
|   rateId,
|   code
| }
|
|--------------------------------------------------------------------------
*/

export async function list(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const id =
            getQueryValue(
                req.params?.id,
            );

        const result =
            await getRateHistory(
                id,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate history retrieved successfully.",

                data:
                    result.history,

                rateId:
                    result.rateId,

                code:
                    result.code,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| GET
|--------------------------------------------------------------------------
|
| Alias kept for compatibility with the existing controller contract.
|
| GET /api/master-rates/:id/history
|
|--------------------------------------------------------------------------
*/

export async function get(
    req,
    res,
) {
    return list(
        req,
        res,
    );
}

/*
|--------------------------------------------------------------------------
| CREATE
|--------------------------------------------------------------------------
|
| Rate history should NOT be created independently by the frontend.
|
| History must be generated automatically by:
|
|   createRate()
|   updateRate()
|
| in rateService.js.
|
| This handler therefore intentionally rejects direct creation instead
| of allowing a caller to manufacture audit history.
|--------------------------------------------------------------------------
*/

export async function create(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        return res
            .status(405)
            .json({
                success: false,

                message:
                    "Rate history is generated automatically when a master rate is created or its effective rate changes.",

                code:
                    "RATE_HISTORY_DIRECT_CREATE_NOT_ALLOWED",
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
|
| Historical records are immutable.
|
|--------------------------------------------------------------------------
*/

export async function update(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        return res
            .status(405)
            .json({
                success: false,

                message:
                    "Rate history records are immutable and cannot be updated.",

                code:
                    "RATE_HISTORY_UPDATE_NOT_ALLOWED",
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| DELETE
|--------------------------------------------------------------------------
|
| Historical rate records must not be deleted independently because
| they provide the rate-change audit trail.
|
|--------------------------------------------------------------------------
*/

export async function remove(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        return res
            .status(405)
            .json({
                success: false,

                message:
                    "Rate history records are immutable and cannot be deleted independently.",

                code:
                    "RATE_HISTORY_DELETE_NOT_ALLOWED",
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

const rateHistoryController = {
    list,

    get,

    create,

    update,

    remove,
};

export default rateHistoryController;