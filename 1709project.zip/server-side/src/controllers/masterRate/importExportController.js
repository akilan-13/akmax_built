// src/controllers/masterRate/importExportController.js

import {
    importRates,
    exportRates,
    getImportTemplate,
} from "../../services/masterRate/importExportService.js";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getAuthenticatedUserId(req) {
    return (
        req.user?.id ||
        req.user?._id ||
        req.user?.userId ||
        null
    );
}

function requireAuthenticatedUser(req) {
    const userId =
        getAuthenticatedUserId(req);

    if (!userId) {
        const error =
            new Error(
                "Authentication is required.",
            );

        error.code =
            "AUTHENTICATION_REQUIRED";

        error.statusCode =
            401;

        throw error;
    }

    return userId;
}

function getAuthenticatedUserName(req) {
    return (
        req.user?.displayName ||
        req.user?.name ||
        req.user?.email ||
        ""
    );
}

function getQueryValue(
    value,
    fallback = "",
) {
    if (
        value === undefined ||
        value === null
    ) {
        return fallback;
    }

    if (
        Array.isArray(value)
    ) {
        return String(
            value[0] ??
                fallback,
        ).trim();
    }

    return String(
        value,
    ).trim();
}

/*
|--------------------------------------------------------------------------
| Error Handling
|--------------------------------------------------------------------------
*/

function sendError(
    res,
    error,
) {
    const statusCode =
        Number(
            error?.statusCode,
        ) || 500;

    if (
        statusCode >= 400 &&
        statusCode < 500
    ) {
        return res
            .status(statusCode)
            .json({
                success: false,

                message:
                    error.message ||
                    "Request could not be processed.",

                code:
                    error.code ||
                    "MASTER_RATE_IMPORT_EXPORT_ERROR",

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    console.error(
        "[importExportController]",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "An unexpected error occurred while processing the master rate import/export request.",

            code:
                "INTERNAL_SERVER_ERROR",
        });
}

/*
|--------------------------------------------------------------------------
| IMPORT
|--------------------------------------------------------------------------
|
| POST /api/master-rates/import
|
| The route must use multipart/form-data middleware and provide the
| uploaded file as req.file.
|
| The controller deliberately does not parse the CSV itself.
| Parsing, validation, duplicate detection, transaction handling,
| and persistence belong in importExportService.js.
|
|--------------------------------------------------------------------------
*/

export async function importRatesFile(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        if (!req.file) {
            return res
                .status(400)
                .json({
                    success: false,

                    message:
                        "CSV file is required.",

                    code:
                        "IMPORT_FILE_REQUIRED",
                });
        }

        const result =
            await importRates(
                {
                    file:
                        req.file,

                    userId,

                    userName:
                        getAuthenticatedUserName(
                            req,
                        ),

                    options: {
                        /*
                         * Optional request controls.
                         *
                         * The current UI does not send these yet,
                         * therefore safe defaults are used.
                         */
                        updateExisting:
                            getQueryValue(
                                req.body
                                    ?.updateExisting,
                                "false",
                            ) ===
                                "true" ||
                            req.body
                                ?.updateExisting ===
                                "1",

                        activateImported:
                            getQueryValue(
                                req.body
                                    ?.activateImported,
                                "true",
                            ) !==
                                "false",
                    },
                },
            );

        return res
            .status(
                result?.statusCode ||
                    200,
            )
            .json({
                success: true,

                message:
                    result?.message ||
                    "Master rates imported successfully.",

                data:
                    result?.data ||
                    result,

                ...(result?.summary
                    ? {
                          summary:
                              result.summary,
                      }
                    : {}),
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| EXPORT
|--------------------------------------------------------------------------
|
| GET /api/master-rates/export
|
| Export filtering intentionally mirrors the Master Rate listing
| filters already supported by rateService.js.
|
|--------------------------------------------------------------------------
*/

export async function exportRatesFile(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await exportRates(
                {
                    filters: {
                        search:
                            getQueryValue(
                                req.query
                                    ?.search,
                                "",
                            ),

                        categoryType:
                            getQueryValue(
                                req.query
                                    ?.categoryType,
                                "",
                            ),

                        category:
                            getQueryValue(
                                req.query
                                    ?.category,
                                "",
                            ),

                        subcategory:
                            getQueryValue(
                                req.query
                                    ?.subcategory,
                                "",
                            ),

                        unit:
                            getQueryValue(
                                req.query
                                    ?.unit,
                                "",
                            ),

                        status:
                            getQueryValue(
                                req.query
                                    ?.status,
                                "",
                            ),

                        effectiveDate:
                            getQueryValue(
                                req.query
                                    ?.effectiveDate,
                                "",
                            ),
                    },
                },
            );

        /*
         * Service may return a Buffer, path, stream, or structured
         * export result. Prefer the explicit buffer contract.
         */
        if (
            Buffer.isBuffer(
                result,
            )
        ) {
            res.setHeader(
                "Content-Type",
                "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                `attachment; filename="master-rates.csv"`,
            );

            return res
                .status(200)
                .send(result);
        }

        if (
            result?.buffer &&
            Buffer.isBuffer(
                result.buffer,
            )
        ) {
            res.setHeader(
                "Content-Type",
                result.contentType ||
                    "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                `attachment; filename="${result.filename || "master-rates.csv"}"`,
            );

            return res
                .status(200)
                .send(result.buffer);
        }

        /*
         * Streaming export.
         */
        if (
            result?.stream &&
            typeof result.stream.pipe ===
                "function"
        ) {
            res.setHeader(
                "Content-Type",
                result.contentType ||
                    "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                `attachment; filename="${result.filename || "master-rates.csv"}"`,
            );

            result.stream.pipe(
                res,
            );

            return;
        }

        /*
         * If the service returns CSV text instead of a Buffer.
         */
        if (
            typeof result ===
            "string" ||
            typeof result?.content ===
                "string"
        ) {
            const csv =
                typeof result ===
                "string"
                    ? result
                    : result.content;

            res.setHeader(
                "Content-Type",
                "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                `attachment; filename="${result?.filename || "master-rates.csv"}"`,
            );

            return res
                .status(200)
                .send(csv);
        }

        throw new Error(
            "Export service returned an unsupported response.",
        );
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| IMPORT TEMPLATE
|--------------------------------------------------------------------------
|
| GET /api/master-rates/import-template
|
| This endpoint is backend-ready for a future server-generated template.
| It does not change the current frontend behavior.
|
|--------------------------------------------------------------------------
*/

export async function importTemplate(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await getImportTemplate();

        if (
            Buffer.isBuffer(
                result,
            )
        ) {
            res.setHeader(
                "Content-Type",
                "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                'attachment; filename="master-rates-import-template.csv"',
            );

            return res
                .status(200)
                .send(result);
        }

        if (
            result?.buffer &&
            Buffer.isBuffer(
                result.buffer,
            )
        ) {
            res.setHeader(
                "Content-Type",
                result.contentType ||
                    "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                `attachment; filename="${result.filename || "master-rates-import-template.csv"}"`,
            );

            return res
                .status(200)
                .send(result.buffer);
        }

        if (
            typeof result ===
            "string"
        ) {
            res.setHeader(
                "Content-Type",
                "text/csv; charset=utf-8",
            );

            res.setHeader(
                "Content-Disposition",
                'attachment; filename="master-rates-import-template.csv"',
            );

            return res
                .status(200)
                .send(result);
        }

        throw new Error(
            "Import template service returned an unsupported response.",
        );
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Existing Generic Controller Contract
|--------------------------------------------------------------------------
|
| The original placeholder exposes:
|
|   list
|   get
|   create
|   update
|   remove
|
| Import/export has no meaningful generic CRUD operation of its own,
| so these aliases are mapped to safe endpoint behavior rather than
| inventing persistence semantics.
|--------------------------------------------------------------------------
*/

export async function list(
    req,
    res,
) {
    return exportRatesFile(
        req,
        res,
    );
}

export async function get(
    req,
    res,
) {
    return importTemplate(
        req,
        res,
    );
}

export async function create(
    req,
    res,
) {
    return importRatesFile(
        req,
        res,
    );
}

export async function update(
    req,
    res,
) {
    return res
        .status(405)
        .json({
            success: false,

            message:
                "Master rate import/update must be performed through the import endpoint.",

            code:
                "IMPORT_EXPORT_UPDATE_NOT_ALLOWED",
        });
}

export async function remove(
    req,
    res,
) {
    return res
        .status(405)
        .json({
            success: false,

            message:
                "Master rate export/import records are not independently deletable.",

            code:
                "IMPORT_EXPORT_DELETE_NOT_ALLOWED",
        });
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

const importExportController = {
    list,

    get,

    create,

    update,

    remove,

    importRatesFile,

    exportRatesFile,

    importTemplate,
};

export default importExportController;