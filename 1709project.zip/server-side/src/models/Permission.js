
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Permission Schema
|--------------------------------------------------------------------------
|
| One permission defines one application module/resource.
|
| Example:
|
| {
|   key: "company_settings",
|   name: "Company Settings",
|   description: "Access to company profile and branding settings",
|   actions: {
|     view: true,
|     add: true,
|     edit: true,
|     delete: true
|   }
| }
|
| Role-specific assignment is handled by RolePermission.
|--------------------------------------------------------------------------
*/

const permissionActionSchema =
    new Schema(
        {
            view: {
                type: Boolean,
                default: false,
            },

            add: {
                type: Boolean,
                default: false,
            },

            edit: {
                type: Boolean,
                default: false,
            },

            delete: {
                type: Boolean,
                default: false,
            },
        },
        {
            _id: false,
            id: false,
        },
    );

const permissionSchema =
    new Schema(
        {
            /*
             * Stable internal identifier used by API RBAC.
             *
             * Example:
             * company_settings
             * roles_permissions
             * api_configuration
             */
            key: {
                type: String,
                required: true,
                unique: true,
                index: true,
                trim: true,
                lowercase: true,
                minlength: 1,
                maxlength: 120,
                match: /^[a-z0-9_.-]+$/,
            },

            /*
             * Human-readable permission name.
             */
            name: {
                type: String,
                required: true,
                trim: true,
                maxlength: 200,
            },

            /*
             * Optional description shown in Roles & Permissions UI.
             */
            description: {
                type: String,
                default: "",
                trim: true,
                maxlength: 1000,
            },

            /*
             * CRUD capabilities available for this module.
             *
             * "ALL" is intentionally not stored as a separate boolean.
             * RBAC derives ALL when all four capabilities are enabled.
             */
            actions: {
                type: permissionActionSchema,
                required: true,
                default: () => ({
                    view: false,
                    add: false,
                    edit: false,
                    delete: false,
                }),
            },

            /*
             * Controls whether this permission can still be assigned.
             *
             * Existing permissions should normally be deactivated
             * rather than physically deleted.
             */
            active: {
                type: Boolean,
                default: true,
                index: true,
            },

            /*
             * Marks application-defined permissions that are part of
             * the ARGUS platform itself.
             *
             * System permissions should not be accidentally removed
             * through the normal Roles UI.
             */
            system: {
                type: Boolean,
                default: true,
                index: true,
            },

            /*
             * Display ordering for the Roles & Permissions screen.
             */
            sortOrder: {
                type: Number,
                default: 0,
                min: 0,
                index: true,
            },

            /*
             * Optional grouping for the Settings / Administration UI.
             */
            category: {
                type: String,
                default: "general",
                trim: true,
                lowercase: true,
                maxlength: 100,
                index: true,
            },

            /*
             * Audit identity.
             */
            createdBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },

            updatedBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },
        },
        {
            timestamps: true,
            strict: "throw",
            versionKey: false,
            minimize: false,
        },
    );

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

permissionSchema.index({
    active: 1,
    sortOrder: 1,
});

permissionSchema.index({
    category: 1,
    active: 1,
    sortOrder: 1,
});

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return the permission in the structure expected by RBAC.
 *
 * rbac.js accepts:
 *
 * {
 *   view,
 *   add,
 *   edit,
 *   delete,
 *   all
 * }
 */
permissionSchema.methods.toRBACPermission =
    function toRBACPermission() {
        const actions =
            this.actions || {};

        const all =
            actions.view === true &&
            actions.add === true &&
            actions.edit === true &&
            actions.delete === true;

        return {
            view:
                actions.view === true,

            add:
                actions.add === true,

            edit:
                actions.edit === true,

            delete:
                actions.delete === true,

            all,
        };
    };

/*
|--------------------------------------------------------------------------
| Query Helpers
|--------------------------------------------------------------------------
*/

permissionSchema.query.activeOnly =
    function activeOnly() {
        return this.where({
            active: true,
        });
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find an active permission by stable RBAC key.
 */
permissionSchema.statics.findByKey =
    function findByKey(key) {
        if (
            typeof key !== "string" ||
            !key.trim()
        ) {
            return null;
        }

        return this.findOne({
            key: key
                .trim()
                .toLowerCase(),
            active: true,
        });
    };

/**
 * Convert multiple permission documents to an RBAC map.
 *
 * Returns:
 *
 * Map is represented as a plain object:
 *
 * {
 *   company_settings: {
 *      view: true,
 *      add: false,
 *      edit: true,
 *      delete: false,
 *      all: false
 *   }
 * }
 */
permissionSchema.statics.toRBACMap =
    function toRBACMap(
        permissions,
    ) {
        const map = {};

        for (
            const permission of
                permissions || []
        ) {
            if (
                !permission ||
                !permission.key ||
                permission.active === false
            ) {
                continue;
            }

            const actions =
                permission.actions ||
                {};

            const all =
                actions.view === true &&
                actions.add === true &&
                actions.edit === true &&
                actions.delete === true;

            map[
                permission.key
                    .trim()
                    .toLowerCase()
            ] = {
                view:
                    actions.view === true,

                add:
                    actions.add === true,

                edit:
                    actions.edit === true,

                delete:
                    actions.delete === true,

                all,
            };
        }

        return map;
    };

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const Permission =
    models.Permission ||
    model(
        "Permission",
        permissionSchema,
    );

export default Permission;
export { Permission };