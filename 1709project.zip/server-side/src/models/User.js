
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| User Schema
|--------------------------------------------------------------------------
|
| ARGUS authentication identity.
|
| User
|   ├── Role
|   └── Vendor (vendor users only)
|
| Permission assignments are resolved through:
|
|   Role
|      ↓
|   RolePermission
|      ↓
|   Permission
|
|--------------------------------------------------------------------------
*/

const userSchema = new Schema(
    {
        /*
         * Login identity.
         */
        email: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
            lowercase: true,
            maxlength: 255,
            validate: {
                validator(value) {
                    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                        value,
                    );
                },

                message:
                    "A valid email address is required.",
            },
        },

        /*
         * bcrypt password hash.
         *
         * Never return this field through normal API responses.
         */
        passwordHash: {
            type: String,
            required: true,
            select: false,
        },

        /*
         * Display name shown in the application.
         */
        displayName: {
            type: String,
            default: "",
            trim: true,
            maxlength: 180,
        },

        /*
         * Existing ARGUS authentication supports:
         *
         * admin
         * internal
         * vendor
         */
        userType: {
            type: String,
            required: true,
            enum: [
                "admin",
                "internal",
                "vendor",
            ],
            index: true,
        },

        /*
         * Assigned authorization role.
         */
        roleId: {
            type: Schema.Types.ObjectId,
            ref: "Role",
            required: true,
            index: true,
        },

        /*
         * Vendor scope.
         *
         * Required for vendor users.
         * Must be null for internal/admin users.
         */
        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            default: null,
            index: true,
        },

        /*
         * User account lifecycle.
         */
        status: {
            type: String,
            enum: [
                "active",
                "inactive",
                "locked",
                "pending",
            ],
            default: "active",
            index: true,
        },

        /*
         * Last successful authentication time.
         */
        lastLoginAt: {
            type: Date,
            default: null,
        },

        /*
         * Failed-login protection.
         *
         * The values are server-side security state and are not
         * returned by normal user serializers.
         */
        failedLoginAttempts: {
            type: Number,
            default: 0,
            min: 0,
        },

        lockedUntil: {
            type: Date,
            default: null,
        },

        /*
         * Password lifecycle.
         */
        passwordChangedAt: {
            type: Date,
            default: null,
        },

        /*
         * Optional account verification state.
         */
        emailVerifiedAt: {
            type: Date,
            default: null,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
|
| The old SQL contract enforced:
|
| vendor user      -> vendorId required
| admin/internal   -> vendorId null
|
| Keep the same business rule in MongoDB.
|--------------------------------------------------------------------------
*/

userSchema.pre(
    "validate",
    function validateUserScope() {
        const isVendor =
            this.userType === "vendor";

        const isNonVendor =
            this.userType === "admin" ||
            this.userType === "internal";

        if (
            isVendor &&
            !this.vendorId
        ) {
            this.invalidate(
                "vendorId",
                "Vendor users must belong to a vendor.",
            );
        }

        if (
            isNonVendor &&
            this.vendorId
        ) {
            this.invalidate(
                "vendorId",
                "Admin and internal users cannot belong to a vendor.",
            );
        }
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

userSchema.index({
    userType: 1,
    status: 1,
});

userSchema.index({
    roleId: 1,
    status: 1,
});

userSchema.index({
    vendorId: 1,
    status: 1,
});

userSchema.index({
    status: 1,
    lastLoginAt: -1,
});

/*
|--------------------------------------------------------------------------
| Query Helpers
|--------------------------------------------------------------------------
*/

userSchema.query.activeOnly =
    function activeOnly() {
        return this.where({
            status: "active",
        });
    };

/*
|--------------------------------------------------------------------------
| Security Helpers
|--------------------------------------------------------------------------
*/

/**
 * Check whether the account is currently usable.
 */
userSchema.methods.isActive =
    function isActive() {
        return (
            this.status ===
            "active"
        );
    };

/**
 * Check whether the account is currently locked.
 */
userSchema.methods.isLocked =
    function isLocked() {
        if (
            this.status ===
            "locked"
        ) {
            return true;
        }

        if (
            !this.lockedUntil
        ) {
            return false;
        }

        return (
            this.lockedUntil.getTime() >
            Date.now()
        );
    };

/**
 * Clear failed-login state after a successful login.
 */
userSchema.methods.resetLoginFailures =
    function resetLoginFailures() {
        this.failedLoginAttempts = 0;
        this.lockedUntil = null;
    };

/**
 * Record a failed authentication attempt.
 *
 * The actual threshold and lock duration should come from env
 * configuration in the authentication service.
 */
userSchema.methods.recordLoginFailure =
    function recordLoginFailure({
        maxAttempts = 5,
        lockoutMinutes = 15,
    } = {}) {
        this.failedLoginAttempts =
            Number(
                this.failedLoginAttempts ||
                    0,
            ) + 1;

        if (
            this.failedLoginAttempts >=
            maxAttempts
        ) {
            this.status =
                "locked";

            this.lockedUntil =
                new Date(
                    Date.now() +
                        lockoutMinutes *
                            60 *
                            1000,
                );
        }
    };

/**
 * Mark the user as successfully authenticated.
 */
userSchema.methods.recordSuccessfulLogin =
    function recordSuccessfulLogin() {
        this.lastLoginAt =
            new Date();

        this.failedLoginAttempts =
            0;

        this.lockedUntil =
            null;

        /*
         * If the account was temporarily locked and the service
         * explicitly permits login again, return it to active.
         */
        if (
            this.status ===
            "locked"
        ) {
            this.status =
                "active";
        }
    };

/*
|--------------------------------------------------------------------------
| Authentication Context
|--------------------------------------------------------------------------
*/

/**
 * Return the minimal identity context needed for JWT creation.
 */
userSchema.methods.toAuthContext =
    function toAuthContext() {
        return {
            userId:
                String(
                    this._id,
                ),

            userType:
                this.userType,

            roleId:
                this.roleId
                    ? String(
                          this.roleId,
                      )
                    : null,

            vendorId:
                this.vendorId
                    ? String(
                          this.vendorId,
                      )
                    : null,
        };
    };

/*
|--------------------------------------------------------------------------
| Safe API Serialization
|--------------------------------------------------------------------------
|
| Password hashes and login security state are never exposed.
|--------------------------------------------------------------------------
*/

userSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                String(
                    this._id,
                ),

            email:
                this.email,

            displayName:
                this.displayName,

            userType:
                this.userType,

            roleId:
                this.roleId
                    ? String(
                          this.roleId,
                      )
                    : null,

            vendorId:
                this.vendorId
                    ? String(
                          this.vendorId,
                      )
                    : null,

            status:
                this.status,

            lastLoginAt:
                this.lastLoginAt,

            emailVerifiedAt:
                this.emailVerifiedAt,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find by normalized email.
 */
userSchema.statics.findByEmail =
    function findByEmail(
        email,
        {
            includePasswordHash = false,
        } = {},
    ) {
        if (
            typeof email !==
                "string" ||
            !email.trim()
        ) {
            return null;
        }

        const query =
            this.findOne({
                email: email
                    .trim()
                    .toLowerCase(),
            });

        if (
            includePasswordHash
        ) {
            query.select(
                "+passwordHash",
            );
        }

        return query;
    };

/**
 * Find an active internal/admin user by id.
 */
userSchema.statics.findActiveInternalUser =
    function findActiveInternalUser(
        userId,
    ) {
        return this.findOne({
            _id: userId,

            userType: {
                $in: [
                    "admin",
                    "internal",
                ],
            },

            status: "active",
        });
    };

/**
 * Find an active vendor user by id.
 */
userSchema.statics.findActiveVendorUser =
    function findActiveVendorUser(
        userId,
    ) {
        return this.findOne({
            _id: userId,
            userType: "vendor",
            status: "active",
        });
    };

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const User =
    models.User ||
    model(
        "User",
        userSchema,
    );

export default User;
export { User };