
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Role Permission Schema
|--------------------------------------------------------------------------
|
| Connects:
|
|   Role
|      ↓
|   RolePermission
|      ↓
|   Permission
|
| Example:
|
|   workspace_owner
|        +
|   company_settings
|        +
|   VIEW / ADD / EDIT / DELETE
|
|--------------------------------------------------------------------------
*/

const rolePermissionActionSchema =
    new Schema(
        {
            view: {
                type: Boolean,
                default: false,
            },

            add: {
                type: Boolean,
                default: false,
            },

            edit: {
                type: Boolean,
                default: false,
            },

            delete: {
                type: Boolean,
                default: false,
            },
        },
        {
            _id: false,
            id: false,
        },
    );

const rolePermissionSchema =
    new Schema(
        {
            /*
             * Role receiving the permission.
             */
            roleId: {
                type: Schema.Types.ObjectId,
                ref: "Role",
                required: true,
                index: true,
            },

            /*
             * Permission/module being granted.
             */
            permissionId: {
                type: Schema.Types.ObjectId,
                ref: "Permission",
                required: true,
                index: true,
            },

            /*
             * Actions granted to this role for this permission.
             *
             * This is intentionally stored separately from Permission.
             *
             * Permission describes what a module supports.
             * RolePermission describes what this role may perform.
             */
            actions: {
                type: rolePermissionActionSchema,
                required: true,
                default: () => ({
                    view: false,
                    add: false,
                    edit: false,
                    delete: false,
                }),
            },

            /*
             * Explicit assignment state.
             *
             * Disabling a role permission is preferable to physically
             * deleting the assignment because it preserves audit history
             * and allows safe reactivation.
             */
            active: {
                type: Boolean,
                default: true,
                index: true,
            },

            /*
             * Audit identity.
             */
            createdBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },

            updatedBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },
        },
        {
            timestamps: true,
            strict: "throw",
            versionKey: false,
            minimize: false,
        },
    );

/*
|--------------------------------------------------------------------------
| Unique Assignment
|--------------------------------------------------------------------------
|
| A role must have only one assignment row for a given permission.
|--------------------------------------------------------------------------
*/

rolePermissionSchema.index(
    {
        roleId: 1,
        permissionId: 1,
    },
    {
        unique: true,
    },
);

/*
|--------------------------------------------------------------------------
| Query Indexes
|--------------------------------------------------------------------------
*/

rolePermissionSchema.index({
    roleId: 1,
    active: 1,
});

rolePermissionSchema.index({
    permissionId: 1,
    active: 1,
});

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return true when at least one action is granted.
 */
rolePermissionSchema.methods.hasAnyAction =
    function hasAnyAction() {
        const actions =
            this.actions || {};

        return (
            actions.view === true ||
            actions.add === true ||
            actions.edit === true ||
            actions.delete === true
        );
    };

/**
 * Return whether the role has the requested action.
 *
 * Supported actions:
 *
 *   view
 *   add
 *   edit
 *   delete
 *   all
 */
rolePermissionSchema.methods.allows =
    function allows(
        action,
    ) {
        const normalizedAction =
            typeof action ===
            "string"
                ? action
                      .trim()
                      .toLowerCase()
                : "";

        const actions =
            this.actions || {};

        if (
            normalizedAction ===
            "all"
        ) {
            return (
                actions.view === true &&
                actions.add === true &&
                actions.edit === true &&
                actions.delete === true
            );
        }

        if (
            ![
                "view",
                "add",
                "edit",
                "delete",
            ].includes(
                normalizedAction,
            )
        ) {
            return false;
        }

        return (
            actions[
                normalizedAction
            ] === true
        );
    };

/**
 * Convert this assignment into the structure consumed by RBAC.
 */
rolePermissionSchema.methods.toRBACPermission =
    function toRBACPermission() {
        const actions =
            this.actions || {};

        const all =
            actions.view === true &&
            actions.add === true &&
            actions.edit === true &&
            actions.delete === true;

        return {
            view:
                actions.view === true,

            add:
                actions.add === true,

            edit:
                actions.edit === true,

            delete:
                actions.delete === true,

            all,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find an active role-permission assignment.
 */
rolePermissionSchema.statics.findAssignment =
    function findAssignment(
        roleId,
        permissionId,
    ) {
        if (
            !roleId ||
            !permissionId
        ) {
            return null;
        }

        return this.findOne({
            roleId,
            permissionId,
            active: true,
        });
    };

/**
 * Load all active permissions for a role.
 *
 * Permission documents are populated so the caller receives:
 *
 * {
 *   company_settings: {
 *      view: true,
 *      add: false,
 *      edit: true,
 *      delete: false,
 *      all: false
 *   }
 * }
 */
rolePermissionSchema.statics.getRBACMapForRole =
    async function getRBACMapForRole(
        roleId,
    ) {
        if (!roleId) {
            return {};
        }

        const assignments =
            await this.find({
                roleId,
                active: true,
            })
                .populate({
                    path: "permissionId",
                    select:
                        "key active",
                })
                .lean();

        const permissions =
            {};

        for (
            const assignment of
                assignments
        ) {
            const permission =
                assignment.permissionId;

            if (
                !permission ||
                permission.active === false ||
                !permission.key
            ) {
                continue;
            }

            const actions =
                assignment.actions ||
                {};

            const key =
                permission.key
                    .trim()
                    .toLowerCase();

            const all =
                actions.view === true &&
                actions.add === true &&
                actions.edit === true &&
                actions.delete === true;

            permissions[key] = {
                view:
                    actions.view === true,

                add:
                    actions.add === true,

                edit:
                    actions.edit === true,

                delete:
                    actions.delete === true,

                all,
            };
        }

        return permissions;
    };

/**
 * Replace all permissions for a role.
 *
 * This is intended for the Roles & Permissions service.
 *
 * Input:
 *
 * [
 *   {
 *     permissionId,
 *     actions: {
 *       view: true,
 *       add: false,
 *       edit: true,
 *       delete: false
 *     }
 *   }
 * ]
 *
 * Existing assignments are deactivated first, then the supplied
 * assignments are inserted/upserted.
 */
rolePermissionSchema.statics.replaceForRole =
    async function replaceForRole(
        roleId,
        assignments,
        auditUserId = null,
    ) {
        if (!roleId) {
            throw new Error(
                "roleId is required.",
            );
        }

        const normalizedAssignments =
            Array.isArray(
                assignments,
            )
                ? assignments
                : [];

        const session =
            this.db?.base?.startSession
                ? await this.db.base.startSession()
                : null;

        try {
            if (session) {
                session.startTransaction();
            }

            await this.updateMany(
                {
                    roleId,
                },
                {
                    $set: {
                        active: false,
                        updatedBy:
                            auditUserId,
                    },
                },
                session
                    ? {
                          session,
                      }
                    : undefined,
            );

            for (
                const item of
                    normalizedAssignments
            ) {
                if (
                    !item?.permissionId
                ) {
                    continue;
                }

                const sourceActions =
                    item.actions || {};

                const actions = {
                    view:
                        sourceActions.view ===
                        true,

                    add:
                        sourceActions.add ===
                        true,

                    edit:
                        sourceActions.edit ===
                        true,

                    delete:
                        sourceActions.delete ===
                        true,
                };

                const hasAction =
                    actions.view ||
                    actions.add ||
                    actions.edit ||
                    actions.delete;

                if (!hasAction) {
                    continue;
                }

                await this.updateOne(
                    {
                        roleId,
                        permissionId:
                            item.permissionId,
                    },
                    {
                        $set: {
                            actions,
                            active: true,
                            updatedBy:
                                auditUserId,
                        },
                        $setOnInsert: {
                            roleId,
                            permissionId:
                                item.permissionId,
                            createdBy:
                                auditUserId,
                        },
                    },
                    {
                        upsert: true,
                        ...(session
                            ? {
                                  session,
                              }
                            : {}),
                    },
                );
            }

            if (session) {
                await session.commitTransaction();
            }
        } catch (error) {
            if (session) {
                await session.abortTransaction();
            }

            throw error;
        } finally {
            if (session) {
                await session.endSession();
            }
        }

        return this.find({
            roleId,
            active: true,
        }).populate({
            path: "permissionId",
            select:
                "key name description active category sortOrder",
        });
    };

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const RolePermission =
    models.RolePermission ||
    model(
        "RolePermission",
        rolePermissionSchema,
    );

export default RolePermission;
export { RolePermission };