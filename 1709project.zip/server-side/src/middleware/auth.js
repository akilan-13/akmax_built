
// src/middleware/auth.js

import jwt from "jsonwebtoken";

import env from "../config/env.js";
import User from "../models/User.js";
import Role from "../models/Role.js";
import RolePermission from "../models/RolePermission.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const ACCESS_TOKEN_TYPE =
    "access";

const AUTH_HEADER_PREFIX =
    "Bearer";

const TOKEN_SOURCES =
    Object.freeze({
        HEADER:
            "header",

        COOKIE:
            "cookie",
    });

const USER_TYPES =
    Object.freeze({
        ADMIN:
            "admin",

        INTERNAL:
            "internal",

        VENDOR:
            "vendor",
    });

/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class AuthenticationError
    extends Error {
    constructor(
        message = "Authentication required.",
        {
            code =
                "AUTHENTICATION_REQUIRED",

            statusCode =
                401,
        } = {},
    ) {
        super(message);

        this.name =
            "AuthenticationError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        Error.captureStackTrace?.(
            this,
            AuthenticationError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Token extraction                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Extract Bearer token from Authorization header.
 */
function getBearerToken(
    req,
) {
    const authorization =
        req.get(
            "authorization",
        );

    if (
        !authorization
    ) {
        return null;
    }

    const parts =
        authorization
            .trim()
            .split(/\s+/);

    if (
        parts.length !== 2
    ) {
        throw new AuthenticationError(
            "Invalid Authorization header.",
            {
                code:
                    "INVALID_AUTHORIZATION_HEADER",
            },
        );
    }

    if (
        parts[0] !==
        AUTH_HEADER_PREFIX
    ) {
        throw new AuthenticationError(
            "Authorization header must use Bearer authentication.",
            {
                code:
                    "INVALID_AUTHORIZATION_SCHEME",
            },
        );
    }

    const token =
        parts[1].trim();

    if (
        !token
    ) {
        throw new AuthenticationError(
            "Authentication token is missing.",
            {
                code:
                    "AUTHENTICATION_TOKEN_MISSING",
            },
        );
    }

    return {
        token,

        source:
            TOKEN_SOURCES.HEADER,
    };
}

/**
 * Extract access token from secure cookie.
 */
function getCookieToken(
    req,
) {
    if (
        !req.cookies
    ) {
        return null;
    }

    const token =
        req.cookies
            .argus_access_token;

    if (
        !token ||
        typeof token !== "string"
    ) {
        return null;
    }

    const normalized =
        token.trim();

    if (
        !normalized
    ) {
        return null;
    }

    return {
        token:
            normalized,

        source:
            TOKEN_SOURCES.COOKIE,
    };
}

/**
 * Resolve token source.
 *
 * Authorization header takes precedence over cookie.
 */
function extractAccessToken(
    req,
) {
    const headerToken =
        getBearerToken(
            req,
        );

    if (
        headerToken
    ) {
        return headerToken;
    }

    const cookieToken =
        getCookieToken(
            req,
        );

    if (
        cookieToken
    ) {
        return cookieToken;
    }

    throw new AuthenticationError(
        "Authentication token is required.",
        {
            code:
                "AUTHENTICATION_TOKEN_REQUIRED",
        },
    );
}

/* -------------------------------------------------------------------------- */
/* JWT validation                                                             */
/* -------------------------------------------------------------------------- */

function verifyAccessToken(
    token,
) {
    try {
        const payload =
            jwt.verify(
                token,
                env.jwt.access
                    .secret,
                {
                    algorithms: [
                        "HS256",
                    ],

                    issuer:
                        env.jwt.issuer,

                    audience:
                        env.jwt.audience,

                    clockTolerance:
                        5,
                },
            );

        if (
            !payload ||
            typeof payload !==
                "object"
        ) {
            throw new AuthenticationError(
                "Invalid authentication token.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN",
                },
            );
        }

        if (
            payload.type !==
            ACCESS_TOKEN_TYPE
        ) {
            throw new AuthenticationError(
                "Invalid access token type.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN_TYPE",
                },
            );
        }

        if (
            !payload.sub
        ) {
            throw new AuthenticationError(
                "Authentication token does not identify a user.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN_SUBJECT",
                },
            );
        }

        if (
            !payload.userType
        ) {
            throw new AuthenticationError(
                "Authentication token does not contain a valid user type.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN_USER_TYPE",
                },
            );
        }

        if (
            !Object.values(
                USER_TYPES,
            ).includes(
                payload.userType,
            )
        ) {
            throw new AuthenticationError(
                "Authentication token contains an invalid user type.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN_USER_TYPE",
                },
            );
        }

        return payload;
    } catch (error) {
        if (
            error instanceof
            AuthenticationError
        ) {
            throw error;
        }

        if (
            error?.name ===
            "TokenExpiredError"
        ) {
            throw new AuthenticationError(
                "Your session has expired. Please sign in again.",
                {
                    code:
                        "ACCESS_TOKEN_EXPIRED",
                },
            );
        }

        if (
            error?.name ===
                "JsonWebTokenError" ||
            error?.name ===
                "NotBeforeError"
        ) {
            throw new AuthenticationError(
                "Invalid authentication token.",
                {
                    code:
                        "INVALID_ACCESS_TOKEN",
                },
            );
        }

        throw new AuthenticationError(
            "Authentication failed.",
            {
                code:
                    "AUTHENTICATION_FAILED",
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Database identity resolution                                               */
/* -------------------------------------------------------------------------- */

/**
 * Load the current user from MongoDB.
 *
 * We intentionally do not trust mutable authorization/account state from
 * the JWT forever. This allows:
 *
 * - account deactivation to take effect
 * - role changes to take effect
 * - vendor changes to take effect
 * - permission changes to take effect
 */
async function loadAuthenticatedIdentity(
    payload,
) {
    const user =
        await User.findById(
            payload.sub,
        ).lean();

    if (
        !user
    ) {
        throw new AuthenticationError(
            "Authentication account is no longer available.",
            {
                code:
                    "AUTHENTICATED_USER_NOT_FOUND",
            },
        );
    }

    if (
        user.status !==
        "active"
    ) {
        throw new AuthenticationError(
            "Your account is no longer active.",
            {
                code:
                    "ACCOUNT_INACTIVE",
                statusCode:
                    403,
            },
        );
    }

    const roleId =
        user.roleId;

    if (
        !roleId
    ) {
        throw new AuthenticationError(
            "Your account does not have a valid role.",
            {
                code:
                    "USER_ROLE_NOT_CONFIGURED",
                statusCode:
                    403,
            },
        );
    }

    const role =
        await Role.findOne({
            _id:
                roleId,

            active:
                true,
        }).lean();

    if (
        !role
    ) {
        throw new AuthenticationError(
            "Your assigned role is no longer active.",
            {
                code:
                    "USER_ROLE_INACTIVE",
                statusCode:
                    403,
            },
        );
    }

    /*
     * Ensure the role is still valid for the user's realm/user type.
     */
    const normalizedUserType =
        String(
            user.userType ||
                "",
        )
            .trim()
            .toLowerCase();

    const allowedUserTypes =
        Array.isArray(
            role.allowedUserTypes,
        )
            ? role.allowedUserTypes
            : [];

    if (
        allowedUserTypes.length > 0 &&
        !allowedUserTypes.includes(
            normalizedUserType,
        )
    ) {
        throw new AuthenticationError(
            "Your assigned role is not valid for this account type.",
            {
                code:
                    "ROLE_USER_TYPE_MISMATCH",
                statusCode:
                    403,
            },
        );
    }

    const realm =
        resolveRealm(
            normalizedUserType,
        );

    if (
        role.realm !== "both" &&
        role.realm !== realm
    ) {
        throw new AuthenticationError(
            "Your assigned role is not valid for this authentication realm.",
            {
                code:
                    "ROLE_REALM_MISMATCH",
                statusCode:
                    403,
            },
        );
    }

    /*
     * Load the effective permissions directly from MongoDB.
     *
     * This is intentionally done server-side on every authenticated
     * request for now. It keeps role/permission changes effective
     * immediately.
     *
     * A production cache can be added later without changing route
     * definitions or RBAC semantics.
     */
    const permissions =
        await RolePermission.getRBACMapForRole(
            role._id,
        );

    return {
        user,

        role,

        permissions,
    };
}

/* -------------------------------------------------------------------------- */
/* User context                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Build the trusted request user object.
 *
 * Permission data is included because the existing RBAC middleware
 * consumes req.user.permissions.
 *
 * The permission map contains authorization booleans only; it does not
 * contain internal database identifiers or secrets.
 */
function buildUserContext(
    payload,
    {
        tokenSource,
        identity,
    },
) {
    const {
        user,
        role,
        permissions,
    } = identity;

    const userContext = {
        id:
            String(
                user._id,
            ),

        userType:
            user.userType,

        roleId:
            role?._id
                ? String(
                      role._id,
                  )
                : null,

        role:
            role?.key ||
            null,

        roleName:
            role?.name ||
            null,

        ownerRole:
            role?.ownerRole === true,

        systemRole:
            role?.system === true,

        vendorId:
            user.vendorId
                ? String(
                      user.vendorId,
                  )
                : null,

        permissions,

        sessionId:
            payload.sessionId
                ? String(
                      payload.sessionId,
                  )
                : null,

        tokenType:
            payload.type,

        tokenSource,

        authenticatedAt:
            payload.iat
                ? new Date(
                      payload.iat *
                          1000,
                  )
                : null,

        expiresAt:
            payload.exp
                ? new Date(
                      payload.exp *
                          1000,
                  )
                : null,
    };

    return Object.freeze(
        userContext,
    );
}

/* -------------------------------------------------------------------------- */
/* Realm detection                                                            */
/* -------------------------------------------------------------------------- */

function resolveRealm(
    userType,
) {
    switch (
        userType
    ) {
        case USER_TYPES.ADMIN:
        case USER_TYPES.INTERNAL:
            return env.auth
                .realms.admin;

        case USER_TYPES.VENDOR:
            return env.auth
                .realms.vendor;

        default:
            throw new AuthenticationError(
                "Invalid authentication realm.",
                {
                    code:
                        "INVALID_AUTH_REALM",
                },
            );
    }
}

/* -------------------------------------------------------------------------- */
/* Main authentication middleware                                             */
/* -------------------------------------------------------------------------- */

export async function authenticate(
    req,
    res,
    next,
) {
    try {
        const tokenInfo =
            extractAccessToken(
                req,
            );

        const payload =
            verifyAccessToken(
                tokenInfo.token,
            );

        /*
         * Resolve current account + role + permissions from MongoDB.
         */
        const identity =
            await loadAuthenticatedIdentity(
                payload,
            );

        /*
         * Protect against stale JWT identity.
         *
         * The database is authoritative for:
         * - user type
         * - role
         * - vendor scope
         */
        if (
            payload.userType !==
            identity.user
                .userType
        ) {
            throw new AuthenticationError(
                "Authentication identity is no longer valid.",
                {
                    code:
                        "STALE_ACCESS_TOKEN",
                },
            );
        }

        if (
            payload.roleId &&
            String(
                payload.roleId,
            ) !==
                String(
                    identity.role._id,
                )
        ) {
            throw new AuthenticationError(
                "Your authorization role has changed. Please sign in again.",
                {
                    code:
                        "STALE_ACCESS_ROLE",
                },
            );
        }

        if (
            payload.vendorId !==
            (identity.user
                .vendorId
                ? String(
                      identity.user
                          .vendorId,
                  )
                : null)
        ) {
            throw new AuthenticationError(
                "Your account scope has changed. Please sign in again.",
                {
                    code:
                        "STALE_ACCESS_SCOPE",
                },
            );
        }

        const user =
            buildUserContext(
                payload,
                {
                    tokenSource:
                        tokenInfo.source,

                    identity,
                },
            );

        req.user =
            user;

        req.authRealm =
            resolveRealm(
                user.userType,
            );

        req.authenticated =
            true;

        /*
         * Optional convenience flags.
         */
        req.isWorkspaceOwner =
            user.ownerRole ===
            true;

        req.permissions =
            user.permissions;

        next();
    } catch (error) {
        return handleAuthenticationError(
            error,
            req,
            res,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Authentication error handler                                               */
/* -------------------------------------------------------------------------- */

function handleAuthenticationError(
    error,
    req,
    res,
) {
    if (
        error instanceof
        AuthenticationError
    ) {
        return res
            .status(
                error.statusCode ||
                    401,
            )
            .json({
                success:
                    false,

                message:
                    error.message,

                code:
                    error.code,

                requestId:
                    req.requestId,
            });
    }

    console.error(
        "[AUTH] Unexpected authentication middleware error:",
        error,
    );

    return res
        .status(500)
        .json({
            success:
                false,

            message:
                "Authentication service temporarily unavailable.",

            code:
                "AUTHENTICATION_INTERNAL_ERROR",

            requestId:
                req.requestId,
        });
}

/* -------------------------------------------------------------------------- */
/* Optional authentication                                                    */
/* -------------------------------------------------------------------------- */

export async function optionalAuthenticate(
    req,
    res,
    next,
) {
    try {
        let tokenInfo;

        try {
            tokenInfo =
                extractAccessToken(
                    req,
                );
        } catch {
            req.user =
                null;

            req.authenticated =
                false;

            req.permissions =
                {};

            return next();
        }

        const payload =
            verifyAccessToken(
                tokenInfo.token,
            );

        const identity =
            await loadAuthenticatedIdentity(
                payload,
            );

        const user =
            buildUserContext(
                payload,
                {
                    tokenSource:
                        tokenInfo.source,

                    identity,
                },
            );

        req.user =
            user;

        req.authRealm =
            resolveRealm(
                user.userType,
            );

        req.authenticated =
            true;

        req.isWorkspaceOwner =
            user.ownerRole ===
            true;

        req.permissions =
            user.permissions;

        next();
    } catch {
        /*
         * Invalid authentication on an optional route means
         * unauthenticated access.
         */
        req.user =
            null;

        req.authenticated =
            false;

        req.permissions =
            {};

        next();
    }
}

/* -------------------------------------------------------------------------- */
/* Realm middleware                                                           */
/* -------------------------------------------------------------------------- */

export function requireRealm(
    ...allowedRealms
) {
    const allowed =
        new Set(
            allowedRealms.map(
                (realm) =>
                    String(
                        realm,
                    )
                        .trim()
                        .toLowerCase(),
            ),
        );

    return (
        req,
        res,
        next,
    ) => {
        if (
            !req.authenticated ||
            !req.user
        ) {
            return res
                .status(401)
                .json({
                    success:
                        false,

                    message:
                        "Authentication is required.",

                    code:
                        "AUTHENTICATION_REQUIRED",

                    requestId:
                        req.requestId,
                });
        }

        if (
            !allowed.has(
                String(
                    req.authRealm ||
                        "",
                ).toLowerCase(),
            )
        ) {
            return res
                .status(403)
                .json({
                    success:
                        false,

                    message:
                        "You do not have access to this application area.",

                    code:
                        "AUTH_REALM_FORBIDDEN",

                    requestId:
                        req.requestId,
                });
        }

        next();
    };
}

/* -------------------------------------------------------------------------- */
/* User-type middleware                                                       */
/* -------------------------------------------------------------------------- */

export function requireUserType(
    ...allowedUserTypes
) {
    const allowed =
        new Set(
            allowedUserTypes.map(
                (type) =>
                    String(
                        type,
                    )
                        .trim()
                        .toLowerCase(),
            ),
        );

    return (
        req,
        res,
        next,
    ) => {
        if (
            !req.authenticated ||
            !req.user
        ) {
            return res
                .status(401)
                .json({
                    success:
                        false,

                    message:
                        "Authentication is required.",

                    code:
                        "AUTHENTICATION_REQUIRED",

                    requestId:
                        req.requestId,
                });
        }

        if (
            !allowed.has(
                String(
                    req.user
                        .userType ||
                        "",
                ).toLowerCase(),
            )
        ) {
            return res
                .status(403)
                .json({
                    success:
                        false,

                    message:
                        "Your account type cannot access this resource.",

                    code:
                        "USER_TYPE_FORBIDDEN",

                    requestId:
                        req.requestId,
                });
        }

        next();
    };
}

/* -------------------------------------------------------------------------- */
/* Admin/internal helpers                                                     */
/* -------------------------------------------------------------------------- */

export const requireInternalUser =
    requireRealm(
        env.auth.realms.admin,
    );

export const requireVendorUser =
    requireRealm(
        env.auth.realms.vendor,
    );

/* -------------------------------------------------------------------------- */
/* Authentication utilities                                                   */
/* -------------------------------------------------------------------------- */

export function getAuthenticatedUserId(
    req,
) {
    return (
        req.user?.id ||
        null
    );
}

export function getAuthenticatedVendorId(
    req,
) {
    return (
        req.user?.vendorId ||
        null
    );
}

export function isAuthenticated(
    req,
) {
    return (
        req.authenticated ===
            true &&
        Boolean(
            req.user,
        )
    );
}

export function isVendorUser(
    req,
) {
    return (
        req.user?.userType ===
        USER_TYPES.VENDOR
    );
}

export function isInternalUser(
    req,
) {
    return (
        req.user?.userType ===
            USER_TYPES.ADMIN ||
        req.user?.userType ===
            USER_TYPES.INTERNAL
    );
}

/**
 * Check whether the current authenticated account is the
 * bootstrap/application owner role.
 */
export function isWorkspaceOwner(
    req,
) {
    return (
        req.user?.ownerRole ===
            true ||
        req.user?.role ===
            "workspace_owner"
    );
}

/**
 * Return a specific effective permission from the current
 * authentication context.
 *
 * This is a convenience helper. Route authorization remains
 * controlled by rbac.js.
 */
export function getAuthenticatedPermission(
    req,
    module,
) {
    const normalizedModule =
        String(
            module || "",
        )
            .trim()
            .toLowerCase();

    if (
        !normalizedModule
    ) {
        return {
            view: false,
            add: false,
            edit: false,
            delete: false,
            all: false,
        };
    }

    return (
        req.user?.permissions?.[
            normalizedModule
        ] || {
            view: false,
            add: false,
            edit: false,
            delete: false,
            all: false,
        }
    );
}

/* -------------------------------------------------------------------------- */
/* Token utility                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Verify an access token without requiring an Express request.
 */
export function verifyToken(
    token,
) {
    return verifyAccessToken(
        token,
    );
}

/* -------------------------------------------------------------------------- */
/* Exports                                                                    */
/* -------------------------------------------------------------------------- */

export {
    USER_TYPES,
    TOKEN_SOURCES,
};

/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

export default authenticate;