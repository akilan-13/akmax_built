
// src/config/env.js

import 'dotenv/config';

/**
 * ARGUS Environment Configuration
 *
 * Central configuration layer for the entire backend.
 *
 * Responsibilities:
 * - Load environment variables
 * - Normalize configuration values
 * - Validate configuration
 * - Fail fast on invalid production settings
 * - Prevent unsafe production defaults
 * - Expose immutable configuration
 */

const NODE_ENV =
  process.env.NODE_ENV?.trim().toLowerCase() ||
  'development';

const SUPPORTED_ENVIRONMENTS = Object.freeze([
  'development',
  'test',
  'staging',
  'production',
]);

if (!SUPPORTED_ENVIRONMENTS.includes(NODE_ENV)) {
  throw new Error(
    `Invalid NODE_ENV "${NODE_ENV}". ` +
      `Allowed values: ${SUPPORTED_ENVIRONMENTS.join(', ')}`,
  );
}


/* -------------------------------------------------------------------------- */
/* Environment helpers                                                       */
/* -------------------------------------------------------------------------- */

function getString(name, defaultValue = undefined) {
  const value = process.env[name];

  if (
    value === undefined ||
    value === null ||
    value.trim() === ''
  ) {
    return defaultValue;
  }

  return value.trim();
}


function getRequiredString(name) {
  const value = getString(name);

  if (!value) {
    throw new Error(
      `Missing required environment variable: ${name}`,
    );
  }

  return value;
}


function getBoolean(name, defaultValue = false) {
  const value = process.env[name];

  if (
    value === undefined ||
    value === null ||
    value.trim() === ''
  ) {
    return defaultValue;
  }

  const normalized =
    value.trim().toLowerCase();

  if (
    ['true', '1', 'yes', 'on'].includes(
      normalized,
    )
  ) {
    return true;
  }

  if (
    ['false', '0', 'no', 'off'].includes(
      normalized,
    )
  ) {
    return false;
  }

  throw new Error(
    `Invalid boolean value for ${name}: "${value}". ` +
      'Use true or false.',
  );
}


function getInteger(
  name,
  defaultValue,
  options = {},
) {
  const {
    min = Number.MIN_SAFE_INTEGER,
    max = Number.MAX_SAFE_INTEGER,
  } = options;

  const rawValue = process.env[name];

  if (
    rawValue === undefined ||
    rawValue === null ||
    rawValue.trim() === ''
  ) {
    return defaultValue;
  }

  const value = Number(rawValue);

  if (!Number.isInteger(value)) {
    throw new Error(
      `Invalid integer value for ${name}: "${rawValue}".`,
    );
  }

  if (value < min || value > max) {
    throw new Error(
      `Invalid value for ${name}: ${value}. ` +
        `Expected range: ${min}-${max}.`,
    );
  }

  return value;
}


function getList(
  name,
  defaultValue = [],
) {
  const value = getString(name);

  if (!value) {
    return [...defaultValue];
  }

  return value
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}


function validateUrl(
  name,
  value,
  {
    allowHttp = true,
  } = {},
) {
  if (!value) {
    throw new Error(
      `Missing URL configuration: ${name}`,
    );
  }

  let parsedUrl;

  try {
    parsedUrl = new URL(value);
  } catch {
    throw new Error(
      `Invalid URL for ${name}: "${value}"`,
    );
  }

  if (
    !['http:', 'https:'].includes(
      parsedUrl.protocol,
    )
  ) {
    throw new Error(
      `Invalid protocol for ${name}: ` +
        `"${parsedUrl.protocol}"`,
    );
  }

  if (
    !allowHttp &&
    parsedUrl.protocol !== 'https:'
  ) {
    throw new Error(
      `${name} must use HTTPS.`,
    );
  }

  return parsedUrl.origin;
}


function validateSecret(
  name,
  value,
  minimumLength = 32,
) {
  if (!value) {
    throw new Error(
      `Missing required secret: ${name}`,
    );
  }

  if (value.length < minimumLength) {
    throw new Error(
      `${name} must contain at least ` +
        `${minimumLength} characters.`,
    );
  }

  return value;
}


function validateMongoUri(value) {
  if (!value) {
    throw new Error(
      'MONGO_URI is required.',
    );
  }

  if (
    !value.startsWith(
      'mongodb://',
    ) &&
    !value.startsWith(
      'mongodb+srv://',
    )
  ) {
    throw new Error(
      'MONGO_URI must start with mongodb:// or mongodb+srv://',
    );
  }

  return value;
}


function normalizePath(value) {
  if (!value) {
    return undefined;
  }

  return value
    .replace(/[\\/]+$/, '');
}


/* -------------------------------------------------------------------------- */
/* Environment flags                                                          */
/* -------------------------------------------------------------------------- */

const isProduction =
  NODE_ENV === 'production';

const isDevelopment =
  NODE_ENV === 'development';

const isTest =
  NODE_ENV === 'test';

const isStaging =
  NODE_ENV === 'staging';


/* -------------------------------------------------------------------------- */
/* Application                                                                */
/* -------------------------------------------------------------------------- */

const appName =
  getString('APP_NAME', 'ARGUS');

const appHost =
  getString('APP_HOST', '0.0.0.0');

const appPort =
  getInteger(
    'APP_PORT',
    3000,
    {
      min: 1,
      max: 65535,
    },
  );

const appUrl =
  getString(
    'APP_URL',
    'http://localhost:3000',
  );

const apiPrefix =
  getString(
    'API_PREFIX',
    '/api',
  );

const apiVersion =
  getString(
    'API_VERSION',
    'v1',
  );


/* -------------------------------------------------------------------------- */
/* Frontend / CORS                                                            */
/* -------------------------------------------------------------------------- */

const adminFrontendUrl =
  getString(
    'ADMIN_FRONTEND_URL',
    'http://localhost:5173',
  );

const vendorFrontendUrl =
  getString(
    'VENDOR_FRONTEND_URL',
    'http://localhost:5174',
  );

const corsAllowedOrigins =
  getList(
    'CORS_ALLOWED_ORIGINS',
    [
      adminFrontendUrl,
      vendorFrontendUrl,
    ],
  );


/* -------------------------------------------------------------------------- */
/* MongoDB                                                                    */
/* -------------------------------------------------------------------------- */

const mongoUri =
  getRequiredString(
    'MONGO_URI',
  );

const mongoDbName =
  getString(
    'MONGO_DB_NAME',
    'argus',
  );

const mongoServerSelectionTimeoutMs =
  getInteger(
    'MONGO_SERVER_SELECTION_TIMEOUT_MS',
    10000,
    {
      min: 1000,
      max: 120000,
    },
  );

const mongoSocketTimeoutMs =
  getInteger(
    'MONGO_SOCKET_TIMEOUT_MS',
    45000,
    {
      min: 1000,
      max: 300000,
    },
  );

const mongoMinPoolSize =
  getInteger(
    'MONGO_MIN_POOL_SIZE',
    2,
    {
      min: 0,
      max: 100,
    },
  );

const mongoMaxPoolSize =
  getInteger(
    'MONGO_MAX_POOL_SIZE',
    20,
    {
      min: 1,
      max: 500,
    },
  );

const mongoMaxIdleTimeMs =
  getInteger(
    'MONGO_MAX_IDLE_TIME_MS',
    30000,
    {
      min: 1000,
      max: 600000,
    },
  );

const mongoRetryWrites =
  getBoolean(
    'MONGO_RETRY_WRITES',
    true,
  );

if (
  mongoMinPoolSize >
  mongoMaxPoolSize
) {
  throw new Error(
    'MONGO_MIN_POOL_SIZE cannot be greater than MONGO_MAX_POOL_SIZE.',
  );
}


/* -------------------------------------------------------------------------- */
/* JWT                                                                        */
/* -------------------------------------------------------------------------- */

const jwtAccessSecret =
  getRequiredString(
    'JWT_ACCESS_SECRET',
  );

const jwtRefreshSecret =
  getRequiredString(
    'JWT_REFRESH_SECRET',
  );

const jwtAccessExpiresIn =
  getString(
    'JWT_ACCESS_EXPIRES_IN',
    '15m',
  );

const jwtRefreshExpiresIn =
  getString(
    'JWT_REFRESH_EXPIRES_IN',
    '7d',
  );

const jwtIssuer =
  getString(
    'JWT_ISSUER',
    'argus-api',
  );

const jwtAudience =
  getString(
    'JWT_AUDIENCE',
    'argus-client',
  );


/* -------------------------------------------------------------------------- */
/* Authentication                                                             */
/* -------------------------------------------------------------------------- */

const authMaxLoginAttempts =
  getInteger(
    'AUTH_MAX_LOGIN_ATTEMPTS',
    5,
    {
      min: 1,
      max: 20,
    },
  );

const authLockoutMinutes =
  getInteger(
    'AUTH_LOCKOUT_MINUTES',
    15,
    {
      min: 1,
      max: 1440,
    },
  );

const authPasswordMinLength =
  getInteger(
    'AUTH_PASSWORD_MIN_LENGTH',
    8,
    {
      min: 8,
      max: 128,
    },
  );

const authRefreshTokenRotation =
  getBoolean(
    'AUTH_REFRESH_TOKEN_ROTATION',
    true,
  );

const authRejectInactiveUsers =
  getBoolean(
    'AUTH_REJECT_INACTIVE_USERS',
    true,
  );

const adminAuthRealm =
  getString(
    'ADMIN_AUTH_REALM',
    'admin',
  );

const vendorAuthRealm =
  getString(
    'VENDOR_AUTH_REALM',
    'vendor',
  );

const bcryptSaltRounds =
  getInteger(
    'BCRYPT_SALT_ROUNDS',
    12,
    {
      min: 10,
      max: 15,
    },
  );


/* -------------------------------------------------------------------------- */
/* Local storage                                                              */
/* -------------------------------------------------------------------------- */

const storageDriver =
  getString(
    'STORAGE_DRIVER',
    'local',
  ).toLowerCase();

const storageRoot =
  normalizePath(
    getString(
      'STORAGE_ROOT',
      './storage',
    ),
  );

const storagePrivateRoot =
  normalizePath(
    getString(
      'STORAGE_PRIVATE_ROOT',
      './storage/private',
    ),
  );

const storageExportRoot =
  normalizePath(
    getString(
      'STORAGE_EXPORT_ROOT',
      './storage/exports',
    ),
  );

const storageTempRoot =
  normalizePath(
    getString(
      'STORAGE_TEMP_ROOT',
      './storage/tmp',
    ),
  );


const storageDirectories =
  Object.freeze({
    vendor:
      getString(
        'STORAGE_VENDOR_DIR',
        'vendors',
      ),

    quotation:
      getString(
        'STORAGE_QUOTATION_DIR',
        'quotations',
      ),

    task:
      getString(
        'STORAGE_TASK_DIR',
        'tasks',
      ),

    invoice:
      getString(
        'STORAGE_INVOICE_DIR',
        'invoices',
      ),

    payment:
      getString(
        'STORAGE_PAYMENT_DIR',
        'payments',
      ),

    project:
      getString(
        'STORAGE_PROJECT_DIR',
        'projects',
      ),

    survey:
      getString(
        'STORAGE_SURVEY_DIR',
        'surveys',
      ),

    company:
      getString(
        'STORAGE_COMPANY_DIR',
        'company',
      ),

    user:
      getString(
        'STORAGE_USER_DIR',
        'users',
      ),

    export:
      getString(
        'STORAGE_EXPORT_DIR',
        'exports',
      ),

    temp:
      getString(
        'STORAGE_TEMP_DIR',
        'tmp',
      ),
  });


/* -------------------------------------------------------------------------- */
/* Uploads                                                                    */
/* -------------------------------------------------------------------------- */

const maxFileSizeBytes =
  getInteger(
    'MAX_FILE_SIZE_BYTES',
    10 * 1024 * 1024,
    {
      min: 1024,
      max: 100 * 1024 * 1024,
    },
  );

const maxBodySize =
  getString(
    'MAX_BODY_SIZE',
    '2mb',
  );

const maxMultipartFields =
  getInteger(
    'MAX_MULTIPART_FIELDS',
    100,
    {
      min: 1,
      max: 1000,
    },
  );

const maxMultipartFiles =
  getInteger(
    'MAX_MULTIPART_FILES',
    10,
    {
      min: 1,
      max: 100,
    },
  );


const allowedDocumentMimeTypes =
  getList(
    'ALLOWED_DOCUMENT_MIMETYPES',
  );

const allowedSpreadsheetMimeTypes =
  getList(
    'ALLOWED_SPREADSHEET_MIMETYPES',
  );

const allowedImageMimeTypes =
  getList(
    'ALLOWED_IMAGE_MIMETYPES',
  );

const allowedAttachmentMimeTypes =
  getList(
    'ALLOWED_ATTACHMENT_MIMETYPES',
  );

const privateFileAccess =
  getBoolean(
    'PRIVATE_FILE_ACCESS',
    true,
  );

const fileDownloadTokenExpiresIn =
  getString(
    'FILE_DOWNLOAD_TOKEN_EXPIRES_IN',
    '5m',
  );


/* -------------------------------------------------------------------------- */
/* SMTP                                                                       */
/* -------------------------------------------------------------------------- */

const emailNotificationsEnabled =
  getBoolean(
    'EMAIL_NOTIFICATIONS_ENABLED',
    true,
  );

const smtpHost =
  getString('SMTP_HOST');

const smtpPort =
  getInteger(
    'SMTP_PORT',
    587,
    {
      min: 1,
      max: 65535,
    },
  );

const smtpSecure =
  getBoolean(
    'SMTP_SECURE',
    false,
  );

const smtpUser =
  getString('SMTP_USER');

const smtpPassword =
  getString('SMTP_PASSWORD');

const smtpFromName =
  getString(
    'SMTP_FROM_NAME',
    'ARGUS',
  );

const smtpFromEmail =
  getString(
    'SMTP_FROM_EMAIL',
  );

const emailQueueEnabled =
  getBoolean(
    'EMAIL_QUEUE_ENABLED',
    false,
  );

const emailMaxRetries =
  getInteger(
    'EMAIL_MAX_RETRIES',
    3,
    {
      min: 0,
      max: 10,
    },
  );


/* -------------------------------------------------------------------------- */
/* Rate limiting                                                              */
/* -------------------------------------------------------------------------- */

const rateLimitWindowMs =
  getInteger(
    'RATE_LIMIT_WINDOW_MS',
    15 * 60 * 1000,
    {
      min: 1000,
      max: 24 * 60 * 60 * 1000,
    },
  );

const rateLimitMaxRequests =
  getInteger(
    'RATE_LIMIT_MAX_REQUESTS',
    300,
    {
      min: 1,
      max: 100000,
    },
  );

const authRateLimitWindowMs =
  getInteger(
    'AUTH_RATE_LIMIT_WINDOW_MS',
    15 * 60 * 1000,
    {
      min: 1000,
      max: 24 * 60 * 60 * 1000,
    },
  );

const authRateLimitMaxRequests =
  getInteger(
    'AUTH_RATE_LIMIT_MAX_REQUESTS',
    20,
    {
      min: 1,
      max: 10000,
    },
  );


/* -------------------------------------------------------------------------- */
/* Logging                                                                    */
/* -------------------------------------------------------------------------- */

const logLevel =
  getString(
    'LOG_LEVEL',
    'info',
  ).toLowerCase();

const supportedLogLevels =
  Object.freeze([
    'fatal',
    'error',
    'warn',
    'info',
    'debug',
    'trace',
  ]);

if (
  !supportedLogLevels.includes(
    logLevel,
  )
) {
  throw new Error(
    `Invalid LOG_LEVEL "${logLevel}". ` +
      `Allowed values: ${supportedLogLevels.join(', ')}`,
  );
}

const logPretty =
  getBoolean(
    'LOG_PRETTY',
    !isProduction,
  );

const logRequestBody =
  getBoolean(
    'LOG_REQUEST_BODY',
    false,
  );

const logAuthHeaders =
  getBoolean(
    'LOG_AUTH_HEADERS',
    false,
  );


/* -------------------------------------------------------------------------- */
/* Audit                                                                      */
/* -------------------------------------------------------------------------- */

const audit =
  Object.freeze({
    enabled:
      getBoolean(
        'AUDIT_LOG_ENABLED',
        true,
      ),

    auth:
      getBoolean(
        'AUDIT_LOG_AUTH',
        true,
      ),

    vendor:
      getBoolean(
        'AUDIT_LOG_VENDOR',
        true,
      ),

    rfq:
      getBoolean(
        'AUDIT_LOG_RFQ',
        true,
      ),

    quotation:
      getBoolean(
        'AUDIT_LOG_QUOTATION',
        true,
      ),

    award:
      getBoolean(
        'AUDIT_LOG_AWARD',
        true,
      ),

    project:
      getBoolean(
        'AUDIT_LOG_PROJECT',
        true,
      ),

    invoice:
      getBoolean(
        'AUDIT_LOG_INVOICE',
        true,
      ),

    payment:
      getBoolean(
        'AUDIT_LOG_PAYMENT',
        true,
      ),

    user:
      getBoolean(
        'AUDIT_LOG_USER',
        true,
      ),

    settings:
      getBoolean(
        'AUDIT_LOG_SETTINGS',
        true,
      ),
  });


/* -------------------------------------------------------------------------- */
/* Notifications                                                              */
/* -------------------------------------------------------------------------- */

const notifications =
  Object.freeze({
    enabled:
      getBoolean(
        'NOTIFICATIONS_ENABLED',
        true,
      ),

    vendorApproval:
      getBoolean(
        'NOTIFICATION_VENDOR_APPROVAL',
        true,
      ),

    rfqIssued:
      getBoolean(
        'NOTIFICATION_RFQ_ISSUED',
        true,
      ),

    quotationSubmitted:
      getBoolean(
        'NOTIFICATION_QUOTATION_SUBMITTED',
        true,
      ),

    awardDecision:
      getBoolean(
        'NOTIFICATION_AWARD_DECISION',
        true,
      ),

    invoiceDecision:
      getBoolean(
        'NOTIFICATION_INVOICE_DECISION',
        true,
      ),

    paymentRecorded:
      getBoolean(
        'NOTIFICATION_PAYMENT_RECORDED',
        true,
      ),
  });


/* -------------------------------------------------------------------------- */
/* Business rules                                                             */
/* -------------------------------------------------------------------------- */

const budgetWarningPercentage =
  Number(
    getString(
      'BUDGET_WARNING_PERCENTAGE',
      '80',
    ),
  );

const budgetMaxPercentage =
  Number(
    getString(
      'BUDGET_MAX_PERCENTAGE',
      '100',
    ),
  );

const preventOverInvoicing =
  getBoolean(
    'PREVENT_OVER_INVOICING',
    true,
  );

const preventLateQuotation =
  getBoolean(
    'PREVENT_LATE_QUOTATION',
    true,
  );

const allowRfqDueDateExtension =
  getBoolean(
    'ALLOW_RFQ_DUE_DATE_EXTENSION',
    true,
  );

if (
  !Number.isFinite(
    budgetWarningPercentage,
  ) ||
  budgetWarningPercentage < 0 ||
  budgetWarningPercentage > 100
) {
  throw new Error(
    'BUDGET_WARNING_PERCENTAGE must be between 0 and 100.',
  );
}

if (
  !Number.isFinite(
    budgetMaxPercentage,
  ) ||
  budgetMaxPercentage <= 0
) {
  throw new Error(
    'BUDGET_MAX_PERCENTAGE must be greater than zero.',
  );
}

if (
  budgetWarningPercentage >
  budgetMaxPercentage
) {
  throw new Error(
    'BUDGET_WARNING_PERCENTAGE cannot exceed BUDGET_MAX_PERCENTAGE.',
  );
}


/* -------------------------------------------------------------------------- */
/* Pagination                                                                 */
/* -------------------------------------------------------------------------- */

const defaultPageSize =
  getInteger(
    'DEFAULT_PAGE_SIZE',
    25,
    {
      min: 1,
      max: 500,
    },
  );

const maxPageSize =
  getInteger(
    'MAX_PAGE_SIZE',
    100,
    {
      min: defaultPageSize,
      max: 1000,
    },
  );


/* -------------------------------------------------------------------------- */
/* Performance                                                                */
/* -------------------------------------------------------------------------- */

const slowRequestThresholdMs =
  getInteger(
    'SLOW_REQUEST_THRESHOLD_MS',
    1000,
    {
      min: 1,
      max: 300000,
    },
  );

const slowQueryThresholdMs =
  getInteger(
    'SLOW_QUERY_THRESHOLD_MS',
    500,
    {
      min: 1,
      max: 300000,
    },
  );


/* -------------------------------------------------------------------------- */
/* Scheduled jobs                                                             */
/* -------------------------------------------------------------------------- */

const jobs =
  Object.freeze({
    enabled:
      getBoolean(
        'JOBS_ENABLED',
        true,
      ),

    overdueTasks:
      getBoolean(
        'OVERDUE_TASK_JOB_ENABLED',
        true,
      ),

    budgetWarnings:
      getBoolean(
        'BUDGET_WARNING_JOB_ENABLED',
        true,
      ),

    notifications:
      getBoolean(
        'NOTIFICATION_JOB_ENABLED',
        true,
      ),
  });


/* -------------------------------------------------------------------------- */
/* Locale                                                                     */
/* -------------------------------------------------------------------------- */

const appTimezone =
  getString(
    'APP_TIMEZONE',
    'Asia/Kolkata',
  );

const appLocale =
  getString(
    'APP_LOCALE',
    'en-IN',
  );

const appCurrency =
  getString(
    'APP_CURRENCY',
    'INR',
  ).toUpperCase();


/* -------------------------------------------------------------------------- */
/* Reports                                                                    */
/* -------------------------------------------------------------------------- */

const reportExportEnabled =
  getBoolean(
    'REPORT_EXPORT_ENABLED',
    true,
  );

const reportExportMaxRows =
  getInteger(
    'REPORT_EXPORT_MAX_ROWS',
    50000,
    {
      min: 1,
      max: 1000000,
    },
  );

const exportRetentionDays =
  getInteger(
    'EXPORT_RETENTION_DAYS',
    7,
    {
      min: 1,
      max: 365,
    },
  );


/* -------------------------------------------------------------------------- */
/* API documentation                                                          */
/* -------------------------------------------------------------------------- */

const apiDocsEnabled =
  getBoolean(
    'API_DOCS_ENABLED',
    !isProduction,
  );

const apiDocsPath =
  getString(
    'API_DOCS_PATH',
    '/docs',
  );


/* -------------------------------------------------------------------------- */
/* Health                                                                     */
/* -------------------------------------------------------------------------- */

const health =
  Object.freeze({
    enabled:
      getBoolean(
        'HEALTHCHECK_ENABLED',
        true,
      ),

    path:
      getString(
        'HEALTHCHECK_PATH',
        '/health',
      ),

    readinessPath:
      getString(
        'READINESS_PATH',
        '/ready',
      ),
  });


/* -------------------------------------------------------------------------- */
/* Security                                                                   */
/* -------------------------------------------------------------------------- */

const securityHeadersEnabled =
  getBoolean(
    'SECURITY_HEADERS_ENABLED',
    true,
  );

const hstsEnabled =
  getBoolean(
    'HSTS_ENABLED',
    isProduction,
  );


/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

validateMongoUri(
  mongoUri,
);

validateUrl(
  'APP_URL',
  appUrl,
  {
    allowHttp:
      !isProduction,
  },
);

validateUrl(
  'ADMIN_FRONTEND_URL',
  adminFrontendUrl,
  {
    allowHttp:
      !isProduction,
  },
);

validateUrl(
  'VENDOR_FRONTEND_URL',
  vendorFrontendUrl,
  {
    allowHttp:
      !isProduction,
  },
);


for (
  const origin of corsAllowedOrigins
) {
  validateUrl(
    'CORS_ALLOWED_ORIGINS',
    origin,
    {
      allowHttp:
        !isProduction,
    },
  );
}


/* -------------------------------------------------------------------------- */
/* JWT secret validation                                                      */
/* -------------------------------------------------------------------------- */

validateSecret(
  'JWT_ACCESS_SECRET',
  jwtAccessSecret,
  32,
);

validateSecret(
  'JWT_REFRESH_SECRET',
  jwtRefreshSecret,
  32,
);

if (
  jwtAccessSecret ===
  jwtRefreshSecret
) {
  throw new Error(
    'JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be different.',
  );
}


/* -------------------------------------------------------------------------- */
/* Storage validation                                                         */
/* -------------------------------------------------------------------------- */

if (
  storageDriver !== 'local'
) {
  throw new Error(
    `Unsupported STORAGE_DRIVER "${storageDriver}". ` +
      'ARGUS currently supports only local storage.',
  );
}

if (!storageRoot) {
  throw new Error(
    'STORAGE_ROOT cannot be empty.',
  );
}

if (!storagePrivateRoot) {
  throw new Error(
    'STORAGE_PRIVATE_ROOT cannot be empty.',
  );
}

if (!storageExportRoot) {
  throw new Error(
    'STORAGE_EXPORT_ROOT cannot be empty.',
  );

}

if (!storageTempRoot) {
  throw new Error(
    'STORAGE_TEMP_ROOT cannot be empty.',
  );
}


/* -------------------------------------------------------------------------- */
/* Logging validation                                                         */
/* -------------------------------------------------------------------------- */

if (logAuthHeaders) {
  throw new Error(
    'LOG_AUTH_HEADERS must always be false.',
  );
}

if (
  isProduction &&
  logRequestBody
) {
  throw new Error(
    'LOG_REQUEST_BODY must be false in production.',
  );
}


/* -------------------------------------------------------------------------- */
/* Production HTTPS validation                                                */
/* -------------------------------------------------------------------------- */

if (isProduction) {
  if (
    !appUrl.startsWith(
      'https://',
    )
  ) {
    throw new Error(
      'APP_URL must use HTTPS in production.',
    );
  }

  if (
    !adminFrontendUrl.startsWith(
      'https://',
    )
  ) {
    throw new Error(
      'ADMIN_FRONTEND_URL must use HTTPS in production.',
    );
  }

  if (
    !vendorFrontendUrl.startsWith(
      'https://',
    )
  ) {
    throw new Error(
      'VENDOR_FRONTEND_URL must use HTTPS in production.',
    );
  }


  if (
    mongoUri.includes(
      '127.0.0.1',
    ) ||
    mongoUri.includes(
      'localhost',
    )
  ) {
    console.warn(
      '[CONFIG] MongoDB URI points to localhost while NODE_ENV=production.',
    );
  }


  if (
    privateFileAccess !== true
  ) {
    throw new Error(
      'PRIVATE_FILE_ACCESS must remain true in production.',
    );
  }


  if (
    !securityHeadersEnabled
  ) {
    throw new Error(
      'SECURITY_HEADERS_ENABLED must remain true in production.',
    );
  }


  if (!hstsEnabled) {
    throw new Error(
      'HSTS_ENABLED must be true in production.',
    );
  }


  if (
    jwtAccessSecret ===
    'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET'
  ) {
    throw new Error(
      'JWT_ACCESS_SECRET must be replaced in production.',
    );
  }


  if (
    jwtRefreshSecret ===
    'CHANGE_THIS_TO_ANOTHER_LONG_RANDOM_SECRET'
  ) {
    throw new Error(
      'JWT_REFRESH_SECRET must be replaced in production.',
    );
  }


  if (
    storageDriver !== 'local'
  ) {
    throw new Error(
      'Production storage must use local storage.',
    );
  }


  if (!audit.enabled) {
    throw new Error(
      'AUDIT_LOG_ENABLED must be true in production.',
    );
  }


  if (
    !authRejectInactiveUsers
  ) {
    throw new Error(
      'AUTH_REJECT_INACTIVE_USERS must be true in production.',
    );
  }
}


/* -------------------------------------------------------------------------- */
/* SMTP validation                                                            */
/* -------------------------------------------------------------------------- */

if (
  isProduction &&
  emailNotificationsEnabled
) {
  if (!smtpHost) {
    throw new Error(
      'SMTP_HOST is required when email notifications are enabled in production.',
    );
  }

  if (!smtpUser) {
    throw new Error(
      'SMTP_USER is required when email notifications are enabled in production.',
    );
  }

  if (!smtpPassword) {
    throw new Error(
      'SMTP_PASSWORD is required when email notifications are enabled in production.',
    );
  }

  if (!smtpFromEmail) {
    throw new Error(
      'SMTP_FROM_EMAIL is required when email notifications are enabled in production.',
    );
  }
}


/* -------------------------------------------------------------------------- */
/* API URL                                                                    */
/* -------------------------------------------------------------------------- */

const apiUrl =
  `${appUrl.replace(/\/+$/, '')}` +
  `${apiPrefix.startsWith('/') ? '' : '/'}` +
  `${apiPrefix}` +
  `${apiPrefix.endsWith('/') ? '' : '/'}` +
  `${apiVersion}`;


/* -------------------------------------------------------------------------- */
/* Frozen configuration                                                       */
/* -------------------------------------------------------------------------- */

const env =
  Object.freeze({
    nodeEnv:
      NODE_ENV,

    isProduction,
    isDevelopment,
    isTest,
    isStaging,


    /* ---------------------------------------------------------------------- */
    /* Application                                                            */
    /* ---------------------------------------------------------------------- */

    app:
      Object.freeze({
        name:
          appName,

        host:
          appHost,

        port:
          appPort,

        url:
          appUrl,

        apiPrefix:
          apiPrefix,

        apiVersion:
          apiVersion,

        apiUrl:
          apiUrl,

        timezone:
          appTimezone,

        locale:
          appLocale,

        currency:
          appCurrency,
      }),


    /* ---------------------------------------------------------------------- */
    /* CORS                                                                   */
    /* ---------------------------------------------------------------------- */

    cors:
      Object.freeze({
        adminFrontendUrl,

        vendorFrontendUrl,

        allowedOrigins:
          Object.freeze([
            ...corsAllowedOrigins,
          ]),
      }),


    /* ---------------------------------------------------------------------- */
    /* MongoDB                                                                */
    /* ---------------------------------------------------------------------- */

    database:
      Object.freeze({
        driver:
          'mongodb',

        uri:
          mongoUri,

        mongoUri:
          mongoUri,

        name:
          mongoDbName,

        serverSelectionTimeoutMs:
          mongoServerSelectionTimeoutMs,

        socketTimeoutMs:
          mongoSocketTimeoutMs,

        minPoolSize:
          mongoMinPoolSize,

        maxPoolSize:
          mongoMaxPoolSize,

        maxIdleTimeMs:
          mongoMaxIdleTimeMs,

        retryWrites:
          mongoRetryWrites,
      }),


    /* ---------------------------------------------------------------------- */
    /* JWT                                                                    */
    /* ---------------------------------------------------------------------- */

    jwt:
      Object.freeze({
        access:
          Object.freeze({
            secret:
              jwtAccessSecret,

            expiresIn:
              jwtAccessExpiresIn,
          }),

        refresh:
          Object.freeze({
            secret:
              jwtRefreshSecret,

            expiresIn:
              jwtRefreshExpiresIn,
          }),

        issuer:
          jwtIssuer,

        audience:
          jwtAudience,
      }),


    /* ---------------------------------------------------------------------- */
    /* Authentication                                                         */
    /* ---------------------------------------------------------------------- */

    auth:
      Object.freeze({
        maxLoginAttempts:
          authMaxLoginAttempts,

        lockoutMinutes:
          authLockoutMinutes,

        passwordMinLength:
          authPasswordMinLength,

        refreshTokenRotation:
          authRefreshTokenRotation,

        rejectInactiveUsers:
          authRejectInactiveUsers,

        realms:
          Object.freeze({
            admin:
              adminAuthRealm,

            vendor:
              vendorAuthRealm,
          }),

        bcryptSaltRounds:
          bcryptSaltRounds,
      }),


    /* ---------------------------------------------------------------------- */
    /* Storage                                                                */
    /* ---------------------------------------------------------------------- */

    storage:
      Object.freeze({
        driver:
          storageDriver,

        root:
          storageRoot,

        privateRoot:
          storagePrivateRoot,

        exportRoot:
          storageExportRoot,

        tempRoot:
          storageTempRoot,

        directories:
          storageDirectories,

        privateFileAccess:
          privateFileAccess,

        downloadTokenExpiresIn:
          fileDownloadTokenExpiresIn,
      }),


    /* ---------------------------------------------------------------------- */
    /* Uploads                                                                */
    /* ---------------------------------------------------------------------- */

    uploads:
      Object.freeze({
        maxFileSizeBytes,

        maxBodySize,

        maxMultipartFields,

        maxMultipartFiles,

        mimeTypes:
          Object.freeze({
            documents:
              Object.freeze([
                ...allowedDocumentMimeTypes,
              ]),

            spreadsheets:
              Object.freeze([
                ...allowedSpreadsheetMimeTypes,
              ]),

            images:
              Object.freeze([
                ...allowedImageMimeTypes,
              ]),

            attachments:
              Object.freeze([
                ...allowedAttachmentMimeTypes,
              ]),
          }),
      }),


    /* ---------------------------------------------------------------------- */
    /* Email                                                                  */
    /* ---------------------------------------------------------------------- */

    email:
      Object.freeze({
        enabled:
          emailNotificationsEnabled,

        smtp:
          Object.freeze({
            host:
              smtpHost,

            port:
              smtpPort,

            secure:
              smtpSecure,

            user:
              smtpUser,

            password:
              smtpPassword,
          }),

        from:
          Object.freeze({
            name:
              smtpFromName,

            email:
              smtpFromEmail,
          }),

        queueEnabled:
          emailQueueEnabled,

        maxRetries:
          emailMaxRetries,
      }),


    /* ---------------------------------------------------------------------- */
    /* Rate limit                                                             */
    /* ---------------------------------------------------------------------- */

    rateLimit:
      Object.freeze({
        general:
          Object.freeze({
            windowMs:
              rateLimitWindowMs,

            maxRequests:
              rateLimitMaxRequests,
          }),

        authentication:
          Object.freeze({
            windowMs:
              authRateLimitWindowMs,

            maxRequests:
              authRateLimitMaxRequests,
          }),
      }),


    /* ---------------------------------------------------------------------- */
    /* Logging                                                                */
    /* ---------------------------------------------------------------------- */

    logging:
      Object.freeze({
        level:
          logLevel,

        pretty:
          logPretty,

        requestBody:
          logRequestBody,

        authHeaders:
          logAuthHeaders,
      }),


    /* ---------------------------------------------------------------------- */
    /* Audit                                                                  */
    /* ---------------------------------------------------------------------- */

    audit:


      audit,


    /* ---------------------------------------------------------------------- */
    /* Notifications                                                          */
    /* ---------------------------------------------------------------------- */

    notifications:


      notifications,


    /* ---------------------------------------------------------------------- */
    /* Business rules                                                         */
    /* ---------------------------------------------------------------------- */

    business:
      Object.freeze({
        budgetWarningPercentage,

        budgetMaxPercentage,

        preventOverInvoicing,

        preventLateQuotation,

        allowRfqDueDateExtension,
      }),


    /* ---------------------------------------------------------------------- */
    /* Pagination                                                             */
    /* ---------------------------------------------------------------------- */

    pagination:
      Object.freeze({
        defaultPageSize,

        maxPageSize,
      }),


    /* ---------------------------------------------------------------------- */
    /* Performance                                                            */
    /* ---------------------------------------------------------------------- */

    performance:
      Object.freeze({
        slowRequestThresholdMs,

        slowQueryThresholdMs,
      }),


    /* ---------------------------------------------------------------------- */
    /* Jobs                                                                   */
    /* ---------------------------------------------------------------------- */

    jobs,


    /* ---------------------------------------------------------------------- */
    /* Reports                                                                */
    /* ---------------------------------------------------------------------- */

    reports:
      Object.freeze({
        exportEnabled:
          reportExportEnabled,

        exportMaxRows:
          reportExportMaxRows,

        exportRetentionDays:
          exportRetentionDays,
      }),


    /* ---------------------------------------------------------------------- */
    /* API docs                                                               */
    /* ---------------------------------------------------------------------- */

    apiDocs:
      Object.freeze({
        enabled:
          apiDocsEnabled,

        path:
          apiDocsPath,
      }),


    /* ---------------------------------------------------------------------- */
    /* Health                                                                 */
    /* ---------------------------------------------------------------------- */

    health,


    /* ---------------------------------------------------------------------- */
    /* Security                                                               */
    /* ---------------------------------------------------------------------- */

    security:
      Object.freeze({
        headersEnabled:
          securityHeadersEnabled,

        hstsEnabled:
          hstsEnabled,
      }),
  });


export default env;