// src/config/settingsTabs.ts
import { TabItem } from "../components/Tabs";
import { PERMISSIONS } from "./permissions";

// src/config/settingsTabs.ts
export const filterTabsByPermissions = (tabs: TabItem[], permissions: string[], isAdmin: boolean): TabItem[] => {
    if (isAdmin) return tabs; //  Admin sees all tabs

    //  Non-admin: Only return tabs that have permission
    return tabs.filter(tab => {
        if (!tab.permission) return true; // No permission required → show
        return permissions.includes(tab.permission); // Check if user has permission
    });
};
//  Helper to check if user has permission for a tab
export const hasTabPermission = (tab: TabItem, permissions: string[], isAdmin: boolean): boolean => {
    if (isAdmin) return true;
    if (!tab.permission) return true;
    return permissions.includes(tab.permission);
};

//  All your tab definitions with permissions
export const SETTINGS_TABS: TabItem[] = [
    { key: "general", label: "General Settings", path: "/general_settings", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "users", label: "User & Roles", path: "/manage_users", permission: PERMISSIONS.USER_ROLE },
    { key: "role", label: "Permissions", path: "/manage_role_permission", permission: PERMISSIONS.USER_ROLE },
    { key: "security", label: "Security", path: "/manage_security", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "notification", label: "Notification", path: "/manage_notification", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "audit", label: "Audit Log", path: "/manage_audit_log", permission: PERMISSIONS.AUDIT_LOG },
    { key: "profile", label: "Company Profile", path: "/manage_company_profile", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "department", label: "Departments", path: "/department_settings", permission: PERMISSIONS.DEPARTMENTS },
    { key: "talent", label: "Human Capital", path: "/manage_human_capital", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "gaap_group", label: "Financial Systems", path: "/financial_settings", permission: PERMISSIONS.PLATFORM_SETTINGS },
];

export const HUMAN_CAPITAL_TAB: TabItem[] = [
    { key: "talent_source", label: "Talent Source", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "pipeline_stage", label: "Pipeline Stage", permission: PERMISSIONS.PLATFORM_SETTINGS },
];

export const FINANCIAL_TABS: TabItem[] = [
    { key: "gaap_group", label: "GAAP Group", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "financial_year", label: "Financial Year", permission: PERMISSIONS.PLATFORM_SETTINGS },
];

export const CUSTOMER_SETTINGS_TABS: TabItem[] = [
    { key: "profile", label: "Profile Settings", path: "/customer_settings", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "organization", label: "Organization Settings", path: "/customer_organisation_settings", permission: PERMISSIONS.TENANT_MANAGEMENT },
];

export const PROFILE_TABS: TabItem[] = [
    { key: "profile", label: "My Profile", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "security", label: "Password & Security", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "notification", label: "Notifications", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "appearance", label: "Appearance & Local", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "devices", label: "Connected Devices", permission: PERMISSIONS.PLATFORM_SETTINGS },
];

export const ORGANIZATION_TABS: TabItem[] = [
    { key: "company_profile", label: "Company Profile", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "user_team", label: "Users & Team", permission: PERMISSIONS.USER_ROLE },
    { key: "role_security", label: "Roles & Security", permission: PERMISSIONS.USER_ROLE },
    { key: "billing_subscription", label: "Billing & Subscription", permission: PERMISSIONS.BILLING },
    { key: "integrations_hooks", label: "Integrations & Hooks", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "sso_auditlogs", label: "SSO & AuditLogs", permission: PERMISSIONS.AUDIT_LOG },
    { key: "masterdata_branch", label: "MasterData & Branches", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "strategic_reports", label: "Strategic & Reports", permission: PERMISSIONS.PLATFORM_SETTINGS },
];

export const ADMIN_SETTINGS_TABS: TabItem[] = [
    { key: "platform", label: "Platform Settings", path: "/platform_settings", permission: PERMISSIONS.PLATFORM_SETTINGS },
    { key: "tenant", label: "Tenant Management", path: "/tenant_management", permission: PERMISSIONS.TENANT_MANAGEMENT },
    { key: "subscription", label: "Subscription & Plans", path: "/manage_subscription", permission: PERMISSIONS.SUBSCRIPTION },
    { key: "payment_billing", label: "Payment & Billing", path: "/manage_billing", permission: PERMISSIONS.BILLING },
    { key: "audit", label: "Audit Log", path: "/audit_log", permission: PERMISSIONS.AUDIT_LOG },
    { key: "user_role", label: "Users & Role", path: "/user_role", permission: PERMISSIONS.USER_ROLE },
    { key: "enquiry", label: "Enquiries", path: "/enquiries", permission: PERMISSIONS.ENQUIRIES },
];

export const COMMON_SETTINGS_TABS: TabItem[] = [
    { key: "country", label: "Country Settings", path: "/country", permission: PERMISSIONS.COUNTRY },
    { key: "state", label: "State Settings", path: "/state", permission: PERMISSIONS.STATE },
    { key: "city", label: "City Settings", path: "/city", permission: PERMISSIONS.CITY },
    { key: "business_type", label: "Business Type", path: "/business_type", permission: PERMISSIONS.BUSINESS_TYPE },
    { key: "industry_type", label: "Industry Type", path: "/industry_type", permission: PERMISSIONS.INDUSTRY_TYPE },
    { key: "currency", label: "Currency Settings", path: "/currency", permission: PERMISSIONS.CURRENCY },
    { key: "time_zone", label: "Time Zone Settings", path: "/time_zone", permission: PERMISSIONS.TIME_ZONE },
    { key: "email_template", label: "Email Templates", path: "/email_template", permission: PERMISSIONS.EMAIL_TEMPLATE },
    { key: "api_config", label: "API Config", path: "/api_config", permission: PERMISSIONS.API_CONFIG },
    { key: "departments", label: "Department", path: "/departments", permission: PERMISSIONS.DEPARTMENTS },
];
