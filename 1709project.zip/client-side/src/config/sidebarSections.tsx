// src/config/sidebarSections.tsx
import { PERMISSIONS } from './permissions';
import IconLayoutGrid from '../components/Icon/IconLayoutGrid';
import IconTuning from '../components/Icon/IconTuning';
import IconSettings from '../components/Icon/IconSettings';

export type SectionKey = 'overview' | 'branch' | 'financial' | 'crm' | 'supply' | 'asset' | 'ticket' | 'hr' | 'admin';

export interface MatchPath {
    label: string;
    routePath: string;
}

export interface SubItem {
    label: string;
    to: string;
    icon: React.ReactNode;
    matchPaths?: MatchPath[];
    children?: { label: string; to: string }[];
    permission?: string;
}

export interface Section {
    key: SectionKey;
    label: string;
    items: SubItem[];
}

export const sections: Section[] = [
    {
        key: 'overview',
        label: 'Overview',
        items: [
            {
                label: 'Dashboard',
                to: '/admin_dashboard',
                icon: <IconLayoutGrid />,
                // ✅ Dashboard permission - you need to add this to your backend permissions
                permission: PERMISSIONS.DASHBOARD,
            },
        ],
    },
    {
        key: 'admin',
        label: 'Administration',
        items: [
            {
                label: 'Admin Settings',
                to: '/platform_settings',
                icon: <IconTuning />,
                permission: PERMISSIONS.PLATFORM_SETTINGS,
                matchPaths: [
                    { label: 'Platform Settings', routePath: '/platform_settings' },
                    { label: 'Tenant Management', routePath: '/tenant_management' },
                    { label: 'Subscription', routePath: '/manage_subscription' },
                    { label: 'Billing', routePath: '/manage_billing' },
                    { label: 'Audit Log', routePath: '/audit_log' },
                    { label: 'User & Role', routePath: '/user_role' },
                    { label: 'Enquiries', routePath: '/enquiries' },
                ],
            },
            {
                label: 'Common Settings',
                to: '/country',
                icon: <IconSettings />,
                permission: PERMISSIONS.COUNTRY,
                matchPaths: [
                    { label: 'Country', routePath: '/country' },
                    { label: 'State', routePath: '/state' },
                    { label: 'City', routePath: '/city' },
                    { label: 'Business Type', routePath: '/business_type' },
                    { label: 'Industry Type', routePath: '/industry_type' },
                    { label: 'Currency', routePath: '/currency' },
                    { label: 'Time Zone', routePath: '/time_zone' },
                    { label: 'Departments', routePath: '/departments' },
                    { label: 'Email Template', routePath: '/email_template' },
                    { label: 'API Config', routePath: '/api_config' },
                ],
            },
        ],
    },
];
