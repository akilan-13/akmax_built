import { TabItem } from "../components/Tabs";

export const LEDGER_TABS: TabItem[] = [
    { key: "journal_entries", label: "Journal Entries" },
    { key: "chart_account", label: "Chart of Accounts" },
    { key: "trail_balance", label: "Trail Balance" },
    { key: "financial_report", label: "Financial Reports" },
    { key: "period_close", label: "Period Close" },
];