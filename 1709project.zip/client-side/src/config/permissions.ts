// src/config/permissions.ts
export const PERMISSIONS = {
    DASHBOARD: 'dashboard',
    PLATFORM_SETTINGS: 'platform_settings',
    TENANT_MANAGEMENT: 'tenant_management',
    SUBSCRIPTION: 'subscription',
    BILLING: 'billing',
    AUDIT_LOG: 'audit_log',
    COUNTRY: 'country',
    STATE: 'state',
    CITY: 'city',
    CURRENCY: 'currency',
    TIME_ZONE: 'time_zone',
    BUSINESS_TYPE: 'business_type',
    INDUSTRY_TYPE: 'industry_type',
    DEPARTMENTS: 'departments',
    EMAIL_TEMPLATE: 'email_template',
    API_CONFIG: 'api_config',
    USER_ROLE: 'user_role',
    ENQUIRIES: 'enquiries',
} as const;

export type PermissionKey = keyof typeof PERMISSIONS;
export type PermissionValue = typeof PERMISSIONS[PermissionKey];
