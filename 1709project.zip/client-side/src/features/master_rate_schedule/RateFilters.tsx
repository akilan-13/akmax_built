import Select from "react-select";
import { MagnifyingGlassIcon, FunnelIcon } from "@phosphor-icons/react";
import { CATEGORIES } from "../../data/seedRateSchedule";
import { getSelectStyles } from "../../utils/selectStyles";

interface RateFiltersProps {
    search: string;
    onSearchChange: (value: string) => void;
    category: string;
    onCategoryChange: (value: string) => void;
    resultCount: number;
}
interface SelectOption {
    value: string;
    label: string;
}
const categoryOptions: SelectOption[] = [
    { value: "all", label: "All Categories" },
    ...CATEGORIES.map((c) => ({ value: c, label: c })),
];

export default function RateFilters({
    search,
    onSearchChange,
    category,
    onCategoryChange,
    resultCount,
}: RateFiltersProps) {
    const selected = categoryOptions.find((o) => o.value === category) ?? null;

    return (
        <div className="mb-4 flex items-center gap-3">
            <div className="relative flex-1">
                <MagnifyingGlassIcon
                    size={16}
                    className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                    value={search}
                    onChange={(e) => onSearchChange(e.target.value)}
                    placeholder="Search by code or description..."
                    className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
            </div>

            <div className="flex w-56 shrink-0 items-center gap-2">
                <FunnelIcon size={16} className="shrink-0 text-slate-400" />
                <div className="flex-1">
                    <Select
                        options={categoryOptions}
                        value={selected}
                        onChange={(opt: any) => onCategoryChange(opt ? opt.value : "all")}
                        placeholder="All Categories"
                        styles={getSelectStyles()}
                    />
                </div>
            </div>

            <span className="shrink-0 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Showing {resultCount} item{resultCount === 1 ? "" : "s"}
            </span>
        </div>
    );
}