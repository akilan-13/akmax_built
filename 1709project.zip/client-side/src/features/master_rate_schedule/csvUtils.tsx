import Papa from "papaparse";
import { RateItem } from "../../types/rateSchedule";
import { todayIso } from "../../data/seedRateSchedule";

export function exportRatesToCsv(
    rows: RateItem[],
    filename = `master-rate-schedule-${todayIso()}.csv`
) {
    const csvRows = rows.map((r) => ({
        Code: r.code,
        Module: r.module,
        "Category Type": r.categoryType,
        Category: r.category,
        Subcategory: r.subcategory,
        Description: r.description,
        "Unit of Measure": r.unit,
        "Standard Rate (JMD)": r.standardRate,
        Rate: r.rate,
        "Effective Date": r.effectiveDate,
        Status: r.status,
    }));

    const csv = Papa.unparse(csvRows);

    const blob = new Blob([csv], {
        type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");

    a.href = url;
    a.download = filename;

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);
}

export function parseRatesCsvFile(
    file: File
): Promise<RateItem[]> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onerror = () => {
            reject(reader.error);
        };

        reader.onload = () => {
            try {
                const parsed = Papa.parse<
                    Record<string, string>
                >(String(reader.result), {
                    header: true,
                    skipEmptyLines: true,
                });

                const imported: RateItem[] = parsed.data
                    .map((r): RateItem | null => {
                        const code =
                            r.Code ||
                            r.code ||
                            "";

                        if (!code) {
                            return null;
                        }

                        /*
                         * Read the rate from either:
                         * - Standard Rate (JMD)
                         * - Rate
                         * - standardRate
                         * - rate
                         */
                        const rateValue =
                            r["Standard Rate (JMD)"] ??
                            r.Rate ??
                            r.standardRate ??
                            r.rate ??
                            "0";

                        const rate =
                            Number(rateValue) || 0;

                        const effectiveDate =
                            r["Effective Date"] ||
                            r.effectiveDate ||
                            todayIso();

                        const categoryType =
                            r["Category Type"] ||
                            r.categoryType ||
                            "Materials";

                        const category =
                            r.Category ||
                            r.category ||
                            "Materials";

                        const subcategory =
                            r.Subcategory ||
                            r.subcategory ||
                            "";

                        const module =
                            r.Module ||
                            r.module ||
                            category;

                        const description =
                            r.Description ||
                            r.description ||
                            "";

                        const unit =
                            r["Unit of Measure"] ||
                            r.unit ||
                            "Each";

                        const statusValue =
                            r.Status ||
                            r.status ||
                            "active";

                        const status =
                            statusValue.toLowerCase() ===
                            "inactive"
                                ? "inactive"
                                : "active";

                        return {
                            id: `${code}-${Date.now()}-${Math.random()
                                .toString(36)
                                .slice(2, 6)}`,

                            code,

                            module,

                            categoryType,

                            category,

                            subcategory,

                            description,

                            unit,

                            /*
                             * Both properties are required
                             * by RateItem.
                             */
                            rate,

                            standardRate: rate,

                            effectiveDate,

                            status,

                            history: [
                                {
                                    rate,
                                    effectiveDate,
                                    updatedAt: todayIso(),
                                    updatedBy: "Bulk Import",
                                },
                            ],
                        };
                    })
                    .filter(
                        (
                            row
                        ): row is RateItem =>
                            row !== null
                    );

                resolve(imported);
            } catch (error) {
                reject(error);
            }
        };

        reader.readAsText(file);
    });
}
