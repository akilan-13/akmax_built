import type React from "react";

export type FormValue = string | number | undefined;

export type FieldType =
    | "text"
    | "number"
    | "radio"
    | "select"
    | "textarea"
    | "checkbox_group";

export type FieldOption = {
    id: string;
    label: string;
    value: string;
};

export type SurveyField = {
    id: string;
    name: string;
    label: string;
    type: FieldType;
    required?: boolean;
    placeholder?: string;
    unit?: string;
    options?: FieldOption[];
};

export type FieldRendererProps = {
    field: SurveyField;
    value: FormValue;
    onChange: (fieldId: string, value: string | number) => void;
};

export type FieldGroup = {
    id: string;
    title: string;
    repeatable?: boolean;
    fields: SurveyField;
};

export type ModuleSection = {
    id: string;
    title: string;
    fieldGroups: FieldGroup[];
};

export type SurveyModule = {
    id: string;
    code: string;
    zone: string;
    name: string;
    icon: React.ElementType;
    fields: number;
    repeatable: boolean;
    unitLabel?: string;
    hasConditional?: boolean;
    sections?: ModuleSection[];
    description?: string;
};