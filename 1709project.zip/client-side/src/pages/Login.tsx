import {
    ArrowRightIcon,
    EyeClosedIcon,
    EyeIcon,
    LockIcon,
    MailboxIcon,
    FolderSimpleIcon,
    TruckIcon,
    ReceiptIcon,
    CurrencyCircleDollarIcon,
    CheckSquareIcon,
    CheckCircleIcon,
} from "@phosphor-icons/react";
import React, { useState } from "react";
import logo from '../assets/img/logo.png';
import fav_icon from '../assets/img/favicon.png';
import { useNavigate } from "react-router-dom";

/**
 * ARGUS — Sign in
 * ----------------------------------------------------------------
 * Design concept: Argus is a project management system built around
 * five entities — Project, Vendor, Quotation, Invoice, Task — which is
 * exactly what the logo's connected-node strip already represents
 * (progress bars -> workflow nodes -> completion check). Rather than
 * an unrelated decorative motif, the left panel's signature element
 * is that same workflow strip, expanded and labeled, in the brand's
 * actual blue/red.
 *
 * Left  — navy brand panel: logo + workflow strip + value props
 * Right — light panel: the sign-in form
 *
 * NOTE: swap the <img src="/argus-logo.png" /> path below for wherever
 * your logo asset actually lives (e.g. import from "src/assets/...").
 * The logo is used on a white chip in both places since the source
 * file has a white background.
 * ---------------------------------------------------------------- */

const workflowSteps = [
    { label: "Project", icon: FolderSimpleIcon },
    { label: "Vendor", icon: TruckIcon },
    { label: "Quotation", icon: ReceiptIcon },
    { label: "Invoice", icon: CurrencyCircleDollarIcon },
    { label: "Task", icon: CheckSquareIcon },
];

const valueProps = [
    "Plan and track every project end-to-end",
    "Keep vendor details and quotations in one place",
    "Turn approved quotations into invoices instantly",
];

const Login = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [remember, setRemember] = useState(false);
    const [submitting, setSubmitting] = useState(false);

    // const handleSubmit = async (e: React.FormEvent) => {
    //     e.preventDefault();
    //     setSubmitting(true);
    //     try {
    //         await signIn(email, password); 
    //         navigate("/dashboard");
    //     } catch (err) {
    //     } finally {
    //         setSubmitting(false);
    //     }
    // };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        window.setTimeout(() => {
            navigate("/admin_dashboard");
        }, 1200);
    };

    return (
        <div className="min-h-screen w-full flex flex-col lg:flex-row bg-[#F5F7FA] font-[Inter,ui-sans-serif,system-ui]">
            <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
      `}</style>

            {/* ============ LEFT : NAVY BRAND PANEL ============ */}
            <div className="relative w-full lg:w-1/2 min-h-[320px] lg:min-h-screen overflow-hidden bg-gradient-to-br from-[#0A1730] via-[#0E2049] to-[#12285C] flex flex-col justify-between px-8 py-10 sm:px-14 sm:py-12">
                {/* subtle geometric backdrop, echoing the logo's angled "A" */}
                <div
                    className="pointer-events-none absolute -right-24 -top-20 h-[420px] w-[420px] opacity-[0.07]"
                    style={{
                        background:
                            "conic-gradient(from 220deg at 50% 50%, transparent 0deg, #ffffff 6deg, transparent 12deg)",
                    }}
                />
                <div className="pointer-events-none absolute bottom-0 left-0 h-64 w-64 rounded-full bg-blue-600/10 blur-3xl" />

                {/* logo */}
                <div className="relative z-10">
                    <div className="inline-flex items-center rounded-xl bg-white px-4 py-2.5 shadow-sm">
                        <img src={logo} alt="Argus — Project Management System" className="h-12 w-auto" />
                    </div>
                </div>

                {/* heading + workflow strip — the signature element */}
                <div className="relative z-10 flex-1 flex flex-col justify-center gap-10 py-10 lg:py-0">
                    <div>
                        <h1 className="text-2xl sm:text-[1.75rem] font-bold leading-tight text-white">
                            Every project, fully in view.
                        </h1>
                        <p className="mt-2 max-w-sm text-sm leading-relaxed text-blue-100/70">
                            Argus connects projects, vendors, quotations, invoices and tasks
                            into a single, traceable workflow.
                        </p>
                    </div>

                    {/* workflow strip: mirrors the logo's node-and-checkmark mark */}
                    <div className="flex items-start">
                        {workflowSteps.map((step, i) => {
                            const StepIcon = step.icon;
                            return (
                                <div key={step.label} className="flex items-center">
                                    <div className="flex flex-col items-center">
                                        <div className="flex h-11 w-11 items-center justify-center rounded-full border border-blue-300/30 bg-white/5 text-blue-100">
                                            <StepIcon className="h-5 w-5" weight="bold" />
                                        </div>
                                        <span className="mt-2 text-[11px] font-medium uppercase tracking-wide text-blue-100/60">
                                            {step.label}
                                        </span>
                                    </div>
                                    {i < workflowSteps.length - 1 && (
                                        <div className="mx-1.5 mt-[-18px] h-px w-6 sm:w-8 bg-blue-300/25" />
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* value props */}
                <div className="relative z-10 space-y-3 border-t border-white/10 pt-6">
                    {valueProps.map((item) => (
                        <div key={item} className="flex items-start gap-2.5">
                            <CheckCircleIcon className="mt-0.5 h-4 w-4 flex-shrink-0 text-red-400" weight="fill" />
                            <span className="text-sm text-blue-50/85">{item}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* ============ RIGHT : LIGHT FORM PANEL ============ */}
            <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-12 sm:px-12">
                <div className="w-full max-w-sm">
                    {/* mobile-only brand mark */}
                    <div className="mb-2 inline-flex items-center">
                        <img src={fav_icon} alt="Argus — Project Management System" className="h-20 w-auto" />
                    </div>

                    <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-slate-400">
                        <span className="h-px w-5 bg-red-500" />
                        Sign in
                        <span className="h-px w-5 bg-blue-700" />
                    </div>
                    <h2 className="mt-2 text-2xl font-bold text-[#0F1E3D]">Welcome</h2>
                    <p className="mt-1.5 text-sm text-slate-500">
                        Sign in to your Argus workspace.
                    </p>

                    <form onSubmit={handleSubmit} className="mt-8 space-y-5">
                        {/* Email */}
                        <div>
                            <label htmlFor="email" className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500">
                                Email
                            </label>
                            <div className="relative">
                                <MailboxIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                                <input
                                    id="email"
                                    type="email"
                                    required
                                    autoComplete="email"
                                    value={email}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
                                    placeholder="you@company.com"
                                    className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-3.5 text-sm text-[#0F1E3D] placeholder:text-slate-400 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                                />
                            </div>
                        </div>

                        {/* Password */}
                        <div>
                            <div className="mb-1.5">
                                <label htmlFor="password" className="block text-xs font-medium uppercase tracking-wide text-slate-500">
                                    Password
                                </label>
                            </div>
                            <div className="relative">
                                <LockIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                                <input
                                    id="password"
                                    type={showPassword ? "text" : "password"}
                                    required
                                    autoComplete="current-password"
                                    value={password}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                    className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-11 text-sm text-[#0F1E3D] placeholder:text-slate-400 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword((v) => !v)}
                                    aria-label={showPassword ? "Hide password" : "Show password"}
                                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0F1E3D]"
                                >
                                    {showPassword ? <EyeClosedIcon className="h-4 w-4" /> : <EyeIcon className="h-4 w-4" />}
                                </button>
                            </div>
                        </div>

                        {/* Remember me */}
                        <label className="flex select-none items-center gap-2.5 text-sm text-slate-600">
                            <input
                                type="checkbox"
                                checked={remember}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRemember(e.target.checked)}
                                className="h-4 w-4 rounded border-slate-300 text-blue-700 focus:ring-blue-600/25"
                            />
                            Keep me signed in
                        </label>

                        {/* Submit */}
                        <button
                            type="submit"
                            disabled={submitting}
                            className="group flex w-full items-center justify-center gap-2 rounded-xl bg-[#123A8F] py-3 text-sm font-semibold text-white transition hover:bg-[#0F2F73] disabled:opacity-60"
                        >
                            {submitting ? "Signing in…" : "Sign in"}
                            {!submitting && (
                                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                            )}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Login;