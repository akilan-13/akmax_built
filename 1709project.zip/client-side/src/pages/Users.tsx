import { useMemo, useState } from "react";
import DataTable, { DataTableColumn } from "../components/DataTable";
import DataCard from "../components/DataCard";
import OffCanvas from "../components/OffCanvas";
import AddMemberForm from "../offcanvas/users/AddMemberForm";
import Avatar from "../components/Avatar";
import Button from "../components/Button";
import { ALL_ROLES, TeamMember } from "../types/user"; 
import { MOCK_MEMBERS } from "../data/mockUsers";
import {
    ClockCounterClockwiseIcon,
    ContactlessPaymentIcon,
    LayoutIcon,
    ListIcon,
    MagnifyingGlassIcon,
    MailboxIcon,
    PenNibIcon,
    UserPlusIcon,
} from "@phosphor-icons/react";
import UserLog from "../offcanvas/users/User_log";
import IconDollarSign from "../components/Icon/IconDollarSign";

function StatusPill({
    status,
}: {
    status: "Active" | "Inactive";
}) {
    return (
        <span
            className={`inline-flex rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                status === "Active"
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-red-200 bg-red-50 text-red-600"
            }`}
        >
            {status}
        </span>
    );
}

function PrivilegePills({
    privileges,
}: {
    privileges: string[];
}) {
    return (
        <div className="flex max-w-md flex-wrap gap-1.5">
            {privileges.map((p) => (
                <span
                    key={p}
                    className="rounded-md bg-indigo-50 px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-indigo-600"
                >
                    {p}
                </span>
            ))}
        </div>
    );
}

export default function Users() {
    const [members, setMembers] =
        useState<TeamMember[]>(MOCK_MEMBERS);

    const [view, setView] =
        useState<"table" | "cards">("table");

    const [search, setSearch] = useState("");

    const [roleFilter, setRoleFilter] =
        useState<string>("All");

    const [statusFilter, setStatusFilter] =
        useState<"All" | "Active" | "Inactive">("All");

    /* Add/Edit User */
    const [isAddOpen, setIsAddOpen] = useState(false);

    const [selectedMember, setSelectedMember] =
        useState<TeamMember | null>(null);

    /* Activity Log */
    const [activityDrawerOpen, setActivityDrawerOpen] =
        useState(false);

    const [activityMember, setActivityMember] =
        useState<TeamMember | null>(null);

    const filteredMembers = useMemo(() => {
        const query = search.trim().toLowerCase();

        return members.filter((m) => {
            const matchesSearch =
                !query ||
                m.name.toLowerCase().includes(query) ||
                m.role.toLowerCase().includes(query);

            const matchesRole =
                roleFilter === "All" ||
                m.role === roleFilter;

            const matchesStatus =
                statusFilter === "All" ||
                m.status === statusFilter;

            return (
                matchesSearch &&
                matchesRole &&
                matchesStatus
            );
        });
    }, [
        members,
        search,
        roleFilter,
        statusFilter,
    ]);

    const activeCount = members.filter(
        (m) => m.status === "Active"
    ).length;

    const handleAddMember = (member: TeamMember) => {
        setMembers((prev) => [member, ...prev]);
        setSelectedMember(null);
        setIsAddOpen(false);
    };

    const handleUpdateMember = (
        updatedMember: TeamMember
    ) => {
        setMembers((prev) =>
            prev.map((member) =>
                member.id === updatedMember.id
                    ? updatedMember
                    : member
            )
        );

        setSelectedMember(null);
        setIsAddOpen(false);
    };

    const handleOpenAdd = () => {
        setSelectedMember(null);
        setIsAddOpen(true);
    };

    const handleOpenEdit = (member: TeamMember) => {
        setSelectedMember(member);
        setIsAddOpen(true);
    };

    const handleCloseForm = () => {
        setSelectedMember(null);
        setIsAddOpen(false);
    };

    /* Activity Log Handlers */
    const handleOpenActivityLog = (
        member: TeamMember
    ) => {
        setActivityMember(member);
        setActivityDrawerOpen(true);
    };

    const handleCloseActivityLog = () => {
        setActivityDrawerOpen(false);
        setActivityMember(null);
    };

    const columns: DataTableColumn<TeamMember>[] = [
    {
        key: "member",
        label: "Member",
        sortable: true,
        render: (row) => (
            <div className="flex items-center gap-3 ">
                <Avatar
                    name={row.name}
                    size={38}
                />

                <div className="min-w-0 ">
                    <p className="font-bold text-slate-900 group-hover:text-red-600">
                        {row.name}
                    </p>

                    <p className="text-xs text-slate-400">
                        {row.email}
                    </p>
                </div>
            </div>
        ),
    },

    {
        key: "role",
        label: "Role",
        sortable: true,
        render: (row) => (
            <p className="font-bold text-slate-800">
                {row.role}
            </p>
        ),
    },

    {
        key: "status",
        label: "Status",
        align: "center",
        render: (row) => (
            <div className="flex items-center justify-center">
                <StatusPill status={row.status} />
            </div>
        ),
    },

    {
        key: "hourlyrate",
        label: "Hourly Rate",
        align: "center",
        render: (row) => (
            <div className="flex items-center justify-center">
                <span className="font-semibold text-slate-800">
                    {row.hourlyrate}
                </span>
            </div>
        ),
    },

    {
        key: "menu",
        label: "Actions",
        align: "right",
        render: (row) => (
            <div className="flex items-center justify-end gap-1.5">
                <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleOpenActivityLog(row)}
                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                    title="View Log"
                >
                    <ClockCounterClockwiseIcon size={16} />
                </Button>

                <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleOpenEdit(row)}
                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                    title="Edit"
                >
                    <PenNibIcon size={16} />
                </Button>
            </div>
        ),
    },
];


    return (
        <>
            {/* Page Header */}
            <div className="mb-6 flex items-start justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        User Management
                    </h1>
                </div>

                <div className="flex items-start justify-end gap-2">

                    {/* View Toggle */}
                    <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 shadow-sm">

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("table")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view === "table"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <ListIcon size={14} />
                            Table
                        </Button>

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("cards")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view === "cards"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <LayoutIcon size={14} />
                            Cards
                        </Button>
                    </div>

                    {/* Add Member */}
                    <Button
                        type="button"
                        variant="primary"
                        onClick={handleOpenAdd}
                        className="!px-4 !py-2.5"
                    >
                        <UserPlusIcon size={16} />
                        Add Member
                    </Button>
                </div>
            </div>

            <div className="flex gap-6">

                {/* Sidebar */}
                <aside className="w-64 shrink-0 space-y-4">
                    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">

                        <span className="mb-2 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Search Directory
                        </span>

                        <div className="relative">
                            <MagnifyingGlassIcon
                                size={15}
                                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                            />

                            <input
                                type="text"
                                value={search}
                                onChange={(e) =>
                                    setSearch(
                                        e.target.value
                                    )
                                }
                                placeholder="Name or role..."
                                className="w-full rounded-lg border border-slate-200 py-2.5 pl-9 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                            />
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Role
                        </span>

                        <div className="space-y-1">
                            {[
                                "All",
                                ...ALL_ROLES,
                            ].map((role) => (
                                <Button
                                    key={role}
                                    type="button"
                                    variant="outline"
                                    onClick={() =>
                                        setRoleFilter(
                                            role
                                        )
                                    }
                                    className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                        roleFilter ===
                                        role
                                            ? "!bg-transparent !text-red-600"
                                            : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                    }`}
                                >
                                    {role}

                                    {roleFilter ===
                                        role && (
                                        <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                    )}
                                </Button>
                            ))}
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Status
                        </span>

                        <div className="space-y-1">
                            {(
                                [
                                    "All",
                                    "Active",
                                    "Inactive",
                                ] as const
                            ).map((status) => (
                                <Button
                                    key={status}
                                    type="button"
                                    variant="outline"
                                    onClick={() =>
                                        setStatusFilter(
                                            status
                                        )
                                    }
                                    className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                        statusFilter ===
                                        status
                                            ? "!bg-transparent !text-red-600"
                                            : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                    }`}
                                >
                                    <span className="flex items-center gap-2">
                                        {status !==
                                            "All" && (
                                            <span
                                                className={`h-2 w-2 rounded-full ${
                                                    status ===
                                                    "Active"
                                                        ? "bg-emerald-500"
                                                        : "bg-red-500"
                                                }`}
                                            />
                                        )}

                                        {status}
                                    </span>

                                    {statusFilter ===
                                        status && (
                                        <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                    )}
                                </Button>
                            ))}
                        </div>
                    </div>
                </aside>

                {/* Main Content */}
                <main className="min-w-0 flex-1 space-y-4">
                    {view === "table" ? (
                        <DataTable
                            columns={columns}
                            data={filteredMembers}
                            rowKey={(row) => row.id}
                        />
                    ) : (
                        <div className="grid grid-cols-1 items-stretch gap-5 sm:grid-cols-2 xl:grid-cols-2">
                            {filteredMembers.map(
                                (member) => (
                                    <div
                                        key={member.id}
                                        className="flex min-w-0"
                                    >
                                        <DataCard
                                            className="w-full min-w-0"
                                            title={
                                                member.name
                                            }
                                            subtitle={
                                                member.role
                                            }
                                            avatar={
                                                <Avatar
                                                    name={
                                                        member.name
                                                    }
                                                    size={
                                                        48
                                                    }
                                                    online={
                                                        member.status ===
                                                        "Active"
                                                    }
                                                />
                                            }
                                            badge={{
                                                text: member.status,
                                                color:
                                                    member.status ===
                                                    "Active"
                                                        ? "green"
                                                        : "red",
                                                position:
                                                    "top-right",
                                            }}
                                            actions={[
                                                {
                                                    id: "log",
                                                    label: (
                                                        <ClockCounterClockwiseIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenActivityLog(
                                                                member
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                                {
                                                    id: "edit",
                                                    label: (
                                                        <PenNibIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenEdit(
                                                                member
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                            ]}
                                            fields={[
                                                {
                                                    label: "Email",
                                                    fullWidth: true,
                                                    value: (
                                                        <div className="flex w-full min-w-0 items-start gap-2">
                                                            <MailboxIcon
                                                                size={
                                                                    13
                                                                }
                                                                className="mt-0.5 shrink-0 text-slate-400"
                                                            />

                                                            <span className="min-w-0 flex-1 break-all text-xs font-semibold leading-5 text-slate-600">
                                                                {
                                                                    member.email
                                                                }
                                                            </span>
                                                        </div>
                                                    ),
                                                },
                                            ]}
                                        />
                                    </div>
                                )
                            )}
                        </div>
                    )}
                </main>
            </div>

            {/* Activity Log Drawer */}
            <UserLog
                open={activityDrawerOpen}
                user={activityMember}
                onClose={
                    handleCloseActivityLog
                }
            />

            {/* Add / Edit User Off Canvas */}
            <OffCanvas
                isOpen={isAddOpen}
                onClose={handleCloseForm}
                title={
                    selectedMember
                        ? "Edit User"
                        : "Add User"
                }
                subtitle={
                    selectedMember
                        ? "Update user details and access"
                        : "Invite a user and configure their access"
                }
            >
                <AddMemberForm
                    member={selectedMember}
                    onSubmit={
                        selectedMember
                            ? handleUpdateMember
                            : handleAddMember
                    }
                    onCancel={handleCloseForm}
                />
            </OffCanvas>
        </>
    );
}