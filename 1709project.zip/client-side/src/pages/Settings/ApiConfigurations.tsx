import { useState } from "react";
import {
    EyeIcon,
    EyeSlashIcon,
    FloppyDiskBackIcon,
    KeyIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
    XIcon,
} from "@phosphor-icons/react";
import ConfirmModal from "../../components/ConfirmModal";
import Field from "../../components/Field";
import Button from "../../components/Button";

interface ApiConfig {
    id: number;
    label: string;
    key: string;
    description: string;
    active: boolean;
}

const INITIAL_API_CONFIGS: ApiConfig[] = [
    {
        id: 1,
        label: "Weather API",
        key: "sk-weather-xxxxxxxxxxxx",
        description: "Used to retrieve weather and environmental data.",
        active: true,
    },
    {
        id: 2,
        label: "Maps API",
        key: "sk-maps-xxxxxxxxxxxx",
        description: "Used for location and mapping services.",
        active: true,
    },
];

export default function ApiConfigurations() {
    const [apiConfigs, setApiConfigs] = useState<ApiConfig[]>(
        INITIAL_API_CONFIGS
    );

    const [showForm, setShowForm] = useState(false);

    const [editingId, setEditingId] = useState<number | null>(null);

    const [deleteId, setDeleteId] = useState<number | null>(null);

    const [visibleKeys, setVisibleKeys] = useState<number[]>([]);

    const [form, setForm] = useState({
        label: "",
        key: "",
        description: "",
    });

    // -----------------------------------
    // Form Update
    // -----------------------------------

    const updateForm = (
        key: keyof typeof form,
        value: string
    ) => {
        setForm((prev) => ({
            ...prev,
            [key]: value,
        }));
    };

    // -----------------------------------
    // Open Add Form
    // -----------------------------------

    const openAddForm = () => {
        setEditingId(null);

        setForm({
            label: "",
            key: "",
            description: "",
        });

        setShowForm(true);
    };

    // -----------------------------------
    // Open Edit Form
    // -----------------------------------

    const openEditForm = (api: ApiConfig) => {
        setEditingId(api.id);

        setForm({
            label: api.label,
            key: api.key,
            description: api.description,
        });

        setShowForm(true);
    };

    // -----------------------------------
    // Close Form
    // -----------------------------------

    const closeForm = () => {
        setShowForm(false);
        setEditingId(null);

        setForm({
            label: "",
            key: "",
            description: "",
        });
    };

    // -----------------------------------
    // Save API
    // -----------------------------------

    const handleSave = () => {
        if (!form.label.trim() || !form.key.trim()) {
            return;
        }

        if (editingId !== null) {
            // Update
            setApiConfigs((prev) =>
                prev.map((api) =>
                    api.id === editingId
                        ? {
                            ...api,
                            label: form.label,
                            key: form.key,
                            description: form.description,
                        }
                        : api
                )
            );
        } else {
            // Add
            const newApi: ApiConfig = {
                id: Date.now(),
                label: form.label,
                key: form.key,
                description: form.description,
                active: true,
            };

            setApiConfigs((prev) => [...prev, newApi]);
        }

        closeForm();
    };

    // -----------------------------------
    // Delete
    // -----------------------------------

    const openDeleteModal = (id: number) => {
        setDeleteId(id);
    };

    const closeDeleteModal = () => {
        setDeleteId(null);
    };

    const confirmDelete = () => {
        if (deleteId === null) {
            return;
        }

        setApiConfigs((prev) =>
            prev.filter((item) => item.id !== deleteId)
        );

        setDeleteId(null);
    };

    // -----------------------------------
    // Toggle Active
    // -----------------------------------

    const toggleStatus = (id: number) => {
        setApiConfigs((prev) =>
            prev.map((api) =>
                api.id === id
                    ? {
                        ...api,
                        active: !api.active,
                    }
                    : api
            )
        );
    };

    // -----------------------------------
    // Show / Hide API Key
    // -----------------------------------

    const toggleKeyVisibility = (id: number) => {
        setVisibleKeys((prev) =>
            prev.includes(id)
                ? prev.filter((item) => item !== id)
                : [...prev, id]
        );
    };

    return (
        <>
            <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-start gap-4">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                            <KeyIcon size={20} />
                        </div>

                        <div>
                            <h2 className="text-lg font-bold text-slate-900">
                                API Configurations
                            </h2>
                        </div>
                    </div>

                    <Button onClick={openAddForm}>
                        <PlusIcon size={17} />
                        Add API
                    </Button>
                </div>

                {/* Add / Edit Form */}
                {showForm && (
                    <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
                        <div className="mb-5 flex items-center justify-between">
                            <div>
                                <h3 className="text-sm font-bold text-slate-800">
                                    {editingId
                                        ? "Edit API Configuration"
                                        : "Add API Configuration"}
                                </h3>

                                <p className="mt-1 text-xs text-slate-500">
                                    Enter the API details below.
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={closeForm}
                                className="text-slate-400 transition-colors hover:text-slate-700"
                            >
                                <XIcon size={18} />
                            </button>
                        </div>

                        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                            <Field
                                label="API Label"
                                placeholder="e.g. Weather API"
                                value={form.label}
                                onChange={(e) =>
                                    updateForm(
                                        "label",
                                        e.target.value
                                    )
                                }
                            />

                            <Field
                                label="API Key"
                                type="password"
                                placeholder="Enter API key"
                                value={form.key}
                                onChange={(e) =>
                                    updateForm(
                                        "key",
                                        e.target.value
                                    )
                                }
                            />

                            <div className="md:col-span-2">
                                <Field
                                    label="Description"
                                    type="textarea"
                                    rows={3}
                                    placeholder="Describe what this API is used for"
                                    value={form.description}
                                    onChange={(e) =>
                                        updateForm(
                                            "description",
                                            e.target.value
                                        )
                                    }
                                />
                            </div>
                        </div>

                        <div className="mt-5 flex justify-end gap-3">
                            <Button
                                variant="outline"
                                onClick={closeForm}
                            >
                                Cancel
                            </Button>

                            <Button onClick={handleSave}>
                                <FloppyDiskBackIcon size={16} />

                                {editingId
                                    ? "Update API"
                                    : "Save API"}
                            </Button>
                        </div>
                    </div>
                )}

                {/* API List */}
                <div className="mt-6 space-y-3">
                    {apiConfigs.length === 0 ? (
                        <div className="rounded-xl border border-dashed border-slate-300 px-6 py-10 text-center">
                            <KeyIcon
                                size={28}
                                className="mx-auto text-slate-300"
                            />

                            <p className="mt-3 text-sm font-semibold text-slate-600">
                                No API configurations
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Add an API configuration to get started.
                            </p>
                        </div>
                    ) : (
                        apiConfigs.map((api) => {
                            const keyVisible = visibleKeys.includes(api.id);

                            return (
                                <div
                                    key={api.id}
                                    className="rounded-xl border border-slate-200 px-5 py-4"
                                >
                                    <div className="flex items-start justify-between gap-5">
                                        {/* API Information */}
                                        <div className="flex min-w-0 items-start gap-4">
                                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                                                <KeyIcon size={18} />
                                            </div>

                                            <div className="min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <p className="text-sm font-semibold text-slate-800">
                                                        {api.label}
                                                    </p>

                                                    <span
                                                        className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${api.active
                                                            ? "bg-green-50 text-green-600"
                                                            : "bg-slate-100 text-slate-500"
                                                            }`}
                                                    >
                                                        {api.active
                                                            ? "Active"
                                                            : "Inactive"}
                                                    </span>
                                                </div>

                                                <p className="mt-1 text-sm text-slate-500">
                                                    {api.description}
                                                </p>

                                                {/* API Key */}
                                                <div className="mt-3 flex items-center gap-2">
                                                    <code className="rounded-md bg-slate-100 px-2.5 py-1 text-xs text-slate-600">
                                                        {keyVisible
                                                            ? api.key
                                                            : "••••••••••••••••••••"}
                                                    </code>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            toggleKeyVisibility(
                                                                api.id
                                                            )
                                                        }
                                                        className="text-slate-400 hover:text-slate-700"
                                                        title={
                                                            keyVisible
                                                                ? "Hide API key"
                                                                : "Show API key"
                                                        }
                                                    >
                                                        {keyVisible ? (
                                                            <EyeSlashIcon
                                                                size={16}
                                                            />
                                                        ) : (
                                                            <EyeIcon
                                                                size={16}
                                                            />
                                                        )}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Actions */}
                                        <div className="flex shrink-0 items-center gap-2">
                                            {/* Status */}
                                            <Button
                                                variant={api.active ? "outline" : "primary"}
                                                onClick={() => toggleStatus(api.id)}
                                            >
                                                {api.active ? "Disable" : "Enable"}
                                            </Button>

                                            {/* Edit */}
                                            <Button
                                                variant="outline"
                                                onClick={() =>
                                                    openEditForm(api)
                                                }
                                            >
                                                <PencilSimpleIcon
                                                    size={16}
                                                />
                                            </Button>

                                            <Button
                                                variant="outline"
                                                onClick={() => openDeleteModal(api.id)}
                                            >
                                                <TrashIcon size={16} />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            </div>

            <ConfirmModal
                open={deleteId !== null}
                title="Delete API Configuration"
                message={
                    deleteId !== null
                        ? `Are you sure you want to delete "${apiConfigs.find((api) => api.id === deleteId)?.label
                        }"? This action cannot be undone.`
                        : ""
                }
                confirmText="Delete API"
                onConfirm={confirmDelete}
                onCancel={closeDeleteModal}
            />

        </>
    );
}