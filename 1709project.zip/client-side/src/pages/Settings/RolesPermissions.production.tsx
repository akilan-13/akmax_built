import {
    useCallback,
    useEffect,
    useMemo,
    useState,
} from "react";
import {
    CheckIcon,
    FloppyDiskBackIcon,
    PlusIcon,
    ShieldIcon,
    TrashIcon,
    XIcon,
    PencilSimpleIcon,
    ArrowClockwiseIcon,
} from "@phosphor-icons/react";

import ConfirmModal from "../../components/ConfirmModal";
import Button from "../../components/Button";
import Field from "../../components/Field";
import api, { getApiErrorMessage } from "../../api/axios";

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

type PermissionAction = "view" | "add" | "edit" | "delete";

type PermissionActions = Record<PermissionAction, boolean>;

interface Role {
    id: string;
    key: string;
    name: string;
    description: string;
    active: boolean;
    system: boolean;
    ownerRole: boolean;
    realm: "internal" | "vendor" | "both";
    allowedUserTypes: string[];
    sortOrder: number;
    members: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface PermissionDefinition {
    id: string;
    key: string;
    name: string;
    description: string;
    category: string;
    system: boolean;
    active: boolean;
    sortOrder: number;
    supportedActions: PermissionActions;
}

interface PermissionMatrixRow extends PermissionDefinition {
    actions: PermissionActions;
    all: boolean;
}

interface RoleListResponse {
    data: Role[];
    pagination?: {
        page: number;
        limit: number;
        total: number;
        pages: number;
    };
}

interface MatrixResponse {
    role: Role;
    permissions: PermissionMatrixRow[];
}

interface RoleFormState {
    name: string;
    description: string;
}

type ToastState = {
    type: "success" | "error" | "warning" | null;
    message: string;
};

const ACTIONS: PermissionAction[] = [
    "view",
    "add",
    "edit",
    "delete",
];

const ACTION_LABELS: Record<PermissionAction, string> = {
    view: "VIEW",
    add: "ADD",
    edit: "EDIT",
    delete: "DELETE",
};

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function extractPayload<T>(response: any): T {
    const payload = response?.data;

    if (
        payload &&
        typeof payload === "object" &&
        Object.prototype.hasOwnProperty.call(payload, "data")
    ) {
        return payload.data as T;
    }

    return payload as T;
}

function emptyActions(): PermissionActions {
    return {
        view: false,
        add: false,
        edit: false,
        delete: false,
    };
}

function normalizeActions(
    actions?: Partial<PermissionActions> | null,
): PermissionActions {
    return {
        view: actions?.view === true,
        add: actions?.add === true,
        edit: actions?.edit === true,
        delete: actions?.delete === true,
    };
}

function allSelected(actions: PermissionActions): boolean {
    return ACTIONS.every((action) => actions[action] === true);
}

function hasAnyAction(actions: PermissionActions): boolean {
    return ACTIONS.some((action) => actions[action] === true);
}

function sortPermissions(
    permissions: PermissionMatrixRow[],
): PermissionMatrixRow[] {
    return [...permissions].sort((a, b) => {
        const categoryCompare = a.category.localeCompare(b.category);

        if (categoryCompare !== 0) {
            return categoryCompare;
        }

        if (a.sortOrder !== b.sortOrder) {
            return a.sortOrder - b.sortOrder;
        }

        return a.name.localeCompare(b.name);
    });
}

function getPermissionCount(
    permissions: PermissionMatrixRow[],
): { enabled: number; total: number } {
    return {
        enabled: permissions.filter((permission) =>
            hasAnyAction(permission.actions),
        ).length,
        total: permissions.length,
    };
}

function getRoleDisplayName(role: Role): string {
    return role.name || role.key || "Unnamed Role";
}

/* -------------------------------------------------------------------------- */
/* Component                                                                  */
/* -------------------------------------------------------------------------- */

export default function RolesPermissions() {
    const [roles, setRoles] = useState<Role[]>([]);
    const [permissions, setPermissions] = useState<PermissionMatrixRow[]>([]);
    const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);

    const [loadingRoles, setLoadingRoles] = useState(true);
    const [loadingPermissions, setLoadingPermissions] = useState(false);
    const [savingPermissions, setSavingPermissions] = useState(false);
    const [savingRole, setSavingRole] = useState(false);
    const [deletingRole, setDeletingRole] = useState(false);

    const [showRoleForm, setShowRoleForm] = useState(false);
    const [editingRole, setEditingRole] = useState<Role | null>(null);
    const [deleteRole, setDeleteRole] = useState<Role | null>(null);

    const [search, setSearch] = useState("");
    const [roleForm, setRoleForm] = useState<RoleFormState>({
        name: "",
        description: "",
    });

    const [toast, setToast] = useState<ToastState>({
        type: null,
        message: "",
    });

    const selectedRole = useMemo(
        () => roles.find((role) => role.id === selectedRoleId) ?? null,
        [roles, selectedRoleId],
    );

    const filteredRoles = useMemo(() => {
        const normalized = search.trim().toLowerCase();

        if (!normalized) {
            return roles;
        }

        return roles.filter((role) =>
            [role.name, role.key, role.description]
                .filter(Boolean)
                .some((value) => value.toLowerCase().includes(normalized)),
        );
    }, [roles, search]);

    const permissionCount = useMemo(
        () => getPermissionCount(permissions),
        [permissions],
    );

    const groupedPermissions = useMemo(() => {
        const groups = new Map<string, PermissionMatrixRow[]>();

        sortPermissions(permissions).forEach((permission) => {
            const category = permission.category || "general";
            const group = groups.get(category) ?? [];
            group.push(permission);
            groups.set(category, group);
        });

        return Array.from(groups.entries());
    }, [permissions]);

    const showToast = useCallback(
        (
            type: ToastState["type"],
            message: string,
        ) => {
            setToast({ type, message });

            window.setTimeout(() => {
                setToast({ type: null, message: "" });
            }, 4500);
        },
        [],
    );

    const loadRoles = useCallback(
        async (preferredRoleId?: string | null) => {
            setLoadingRoles(true);

            try {
                const response = await api.get<RoleListResponse>(
                    "/settings/roles",
                    {
                        params: {
                            active: true,
                            page: 1,
                            limit: 100,
                        },
                    },
                );

                const result = extractPayload<RoleListResponse>(response);
                const nextRoles = Array.isArray(result?.data)
                    ? result.data
                    : [];

                setRoles(nextRoles);

                setSelectedRoleId((current) => {
                    const preferred = preferredRoleId ?? current;

                    if (
                        preferred &&
                        nextRoles.some((role) => role.id === preferred)
                    ) {
                        return preferred;
                    }

                    return nextRoles[0]?.id ?? null;
                });
            } catch (error) {
                showToast(
                    "error",
                    getApiErrorMessage(
                        error,
                        "Unable to load roles.",
                    ),
                );
                setRoles([]);
                setSelectedRoleId(null);
            } finally {
                setLoadingRoles(false);
            }
        },
        [showToast],
    );

    const loadRolePermissions = useCallback(
        async (roleId: string) => {
            setLoadingPermissions(true);

            try {
                const response = await api.get<MatrixResponse>(
                    `/settings/roles/${roleId}/permissions`,
                );

                const result = extractPayload<MatrixResponse>(response);
                const nextPermissions = Array.isArray(result?.permissions)
                    ? result.permissions.map((permission) => ({
                          ...permission,
                          actions: normalizeActions(permission.actions),
                          all:
                              allSelected(
                                  normalizeActions(permission.actions),
                              ),
                      }))
                    : [];

                setPermissions(nextPermissions);

                if (result?.role) {
                    setRoles((currentRoles) =>
                        currentRoles.map((role) =>
                            role.id === result.role.id
                                ? result.role
                                : role,
                        ),
                    );
                }
            } catch (error) {
                showToast(
                    "error",
                    getApiErrorMessage(
                        error,
                        "Unable to load role permissions.",
                    ),
                );
                setPermissions([]);
            } finally {
                setLoadingPermissions(false);
            }
        },
        [showToast],
    );

    useEffect(() => {
        void loadRoles();
    }, [loadRoles]);

    useEffect(() => {
        if (!selectedRoleId) {
            setPermissions([]);
            return;
        }

        void loadRolePermissions(selectedRoleId);
    }, [loadRolePermissions, selectedRoleId]);

    const resetRoleForm = useCallback(() => {
        setRoleForm({
            name: "",
            description: "",
        });
        setEditingRole(null);
        setShowRoleForm(false);
    }, []);

    const openCreateRole = () => {
        setEditingRole(null);
        setRoleForm({
            name: "",
            description: "",
        });
        setShowRoleForm(true);
    };

    const openEditRole = () => {
        if (!selectedRole || selectedRole.system) {
            return;
        }

        setEditingRole(selectedRole);
        setRoleForm({
            name: selectedRole.name,
            description: selectedRole.description,
        });
        setShowRoleForm(true);
    };

    const handleRoleSubmit = async () => {
        const name = roleForm.name.trim();
        const description = roleForm.description.trim();

        if (!name) {
            showToast("warning", "Role name is required.");
            return;
        }

        if (name.length > 150) {
            showToast("warning", "Role name cannot exceed 150 characters.");
            return;
        }

        if (description.length > 2000) {
            showToast(
                "warning",
                "Role description cannot exceed 2000 characters.",
            );
            return;
        }

        setSavingRole(true);

        try {
            if (editingRole) {
                const response = await api.patch(
                    `/settings/roles/${editingRole.id}`,
                    {
                        name,
                        description,
                    },
                );

                const updatedRole = extractPayload<Role>(response);

                if (updatedRole?.id) {
                    setRoles((currentRoles) =>
                        currentRoles.map((role) =>
                            role.id === updatedRole.id
                                ? updatedRole
                                : role,
                        ),
                    );
                }

                showToast("success", "Role updated successfully.");
                resetRoleForm();
                return;
            }

            const response = await api.post(
                "/settings/roles",
                {
                    name,
                    description,
                    realm: "internal",
                    allowedUserTypes: ["internal"],
                },
            );

            const createdRole = extractPayload<Role>(response);

            if (!createdRole?.id) {
                throw new Error("The server did not return the created role.");
            }

            setRoles((currentRoles) => [...currentRoles, createdRole]);
            setSelectedRoleId(createdRole.id);
            showToast("success", "Role created successfully.");
            resetRoleForm();
        } catch (error) {
            showToast(
                "error",
                getApiErrorMessage(
                    error,
                    editingRole
                        ? "Unable to update the role."
                        : "Unable to create the role.",
                ),
            );
        } finally {
            setSavingRole(false);
        }
    };

    const updatePermission = (
        permissionId: string,
        action: PermissionAction,
    ) => {
        if (selectedRole?.ownerRole) {
            return;
        }

        setPermissions((currentPermissions) =>
            currentPermissions.map((permission) => {
                if (permission.id !== permissionId) {
                    return permission;
                }

                if (!permission.supportedActions[action]) {
                    return permission;
                }

                const nextActions = {
                    ...permission.actions,
                    [action]: !permission.actions[action],
                };

                return {
                    ...permission,
                    actions: nextActions,
                    all: allSelected(nextActions),
                };
            }),
        );
    };

    const togglePermissionAll = (permissionId: string) => {
        if (selectedRole?.ownerRole) {
            return;
        }

        setPermissions((currentPermissions) =>
            currentPermissions.map((permission) => {
                if (permission.id !== permissionId) {
                    return permission;
                }

                const nextAll = !allSelected(permission.actions);
                const nextActions = ACTIONS.reduce(
                    (actions, action) => {
                        actions[action] = permission.supportedActions[action]
                            ? nextAll
                            : false;
                        return actions;
                    },
                    emptyActions(),
                );

                return {
                    ...permission,
                    actions: nextActions,
                    all: allSelected(nextActions),
                };
            }),
        );
    };

    const savePermissions = async () => {
        if (!selectedRoleId || !selectedRole || selectedRole.ownerRole) {
            return;
        }

        setSavingPermissions(true);

        try {
            const assignments = permissions
                .filter((permission) => hasAnyAction(permission.actions))
                .map((permission) => ({
                    permissionId: permission.id,
                    actions: normalizeActions(permission.actions),
                }));

            const response = await api.put(
                `/settings/roles/${selectedRoleId}/permissions`,
                {
                    assignments,
                },
            );

            const result = extractPayload<MatrixResponse>(response);
            const nextPermissions = Array.isArray(result?.permissions)
                ? result.permissions.map((permission) => ({
                      ...permission,
                      actions: normalizeActions(permission.actions),
                      all:
                          allSelected(
                              normalizeActions(permission.actions),
                          ),
                  }))
                : [];

            setPermissions(nextPermissions);
            showToast("success", "Role permissions saved successfully.");
        } catch (error) {
            showToast(
                "error",
                getApiErrorMessage(
                    error,
                    "Unable to save role permissions.",
                ),
            );
        } finally {
            setSavingPermissions(false);
        }
    };

    const confirmDelete = async () => {
        if (!deleteRole || deleteRole.system || deleteRole.ownerRole) {
            return;
        }

        setDeletingRole(true);

        try {
            await api.delete(`/settings/roles/${deleteRole.id}`);

            const deletedId = deleteRole.id;
            const nextRoles = roles.filter((role) => role.id !== deletedId);

            setRoles(nextRoles);
            setSelectedRoleId((current) =>
                current === deletedId
                    ? nextRoles[0]?.id ?? null
                    : current,
            );

            setDeleteRole(null);
            showToast("success", "Role removed successfully.");
        } catch (error) {
            showToast(
                "error",
                getApiErrorMessage(
                    error,
                    "Unable to remove the role.",
                ),
            );
        } finally {
            setDeletingRole(false);
        }
    };

    const canManageSelectedRole = Boolean(
        selectedRole &&
            !selectedRole.ownerRole &&
            !selectedRole.system,
    );

    return (
        <div className="relative">
            {toast.type && (
                <div
                    className={`mb-4 rounded-xl border px-4 py-3 text-sm font-medium ${
                        toast.type === "success"
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : toast.type === "warning"
                              ? "border-amber-200 bg-amber-50 text-amber-700"
                              : "border-red-200 bg-red-50 text-red-700"
                    }`}
                >
                    {toast.message}
                </div>
            )}

            {/* Header */}
            <div className="flex flex-col gap-4 border-b border-slate-100 pb-4 md:flex-row md:items-start md:justify-between">
                <div className="flex items-start gap-4">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                        <ShieldIcon size={20} />
                    </div>

                    <div>
                        <h2 className="text-lg font-bold text-slate-900">
                            Roles & Permissions
                        </h2>
                        <p className="mt-1 text-sm text-slate-500">
                            Manage workspace roles and control access to each
                            ARGUS module.
                        </p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => void loadRoles(selectedRoleId)}
                        disabled={loadingRoles || loadingPermissions}
                    >
                        <ArrowClockwiseIcon
                            size={16}
                            className={
                                loadingRoles || loadingPermissions
                                    ? "animate-spin"
                                    : ""
                            }
                        />
                        Refresh
                    </Button>

                    <Button
                        type="button"
                        onClick={openCreateRole}
                    >
                        <PlusIcon size={17} />
                        Add Role
                    </Button>
                </div>
            </div>

            {/* Role Form */}
            {showRoleForm && (
                <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-4 flex items-center justify-between gap-3">
                        <div>
                            <h3 className="text-sm font-bold text-slate-800">
                                {editingRole ? "Edit Role" : "Add New Role"}
                            </h3>
                            <p className="mt-1 text-xs text-slate-500">
                                {editingRole
                                    ? "Update the role metadata without changing its permission matrix."
                                    : "Create a role. Permissions can be configured immediately after creation."}
                            </p>
                        </div>

                        <button
                            type="button"
                            onClick={savingRole ? undefined : resetRoleForm}
                            className="text-slate-400 transition hover:text-slate-700 disabled:cursor-not-allowed"
                            disabled={savingRole}
                            aria-label="Close role form"
                        >
                            <XIcon size={18} />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        <Field
                            label="Role Name"
                            required
                            name="role-name"
                            placeholder="e.g. Project Manager"
                            value={roleForm.name}
                            onChange={(event) =>
                                setRoleForm((current) => ({
                                    ...current,
                                    name: event.target.value,
                                }))
                            }
                            disabled={savingRole}
                        />

                        <Field
                            label="Description"
                            name="role-description"
                            placeholder="Describe this role"
                            value={roleForm.description}
                            onChange={(event) =>
                                setRoleForm((current) => ({
                                    ...current,
                                    description: event.target.value,
                                }))
                            }
                            disabled={savingRole}
                        />
                    </div>

                    <div className="mt-5 flex justify-end gap-3">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={resetRoleForm}
                            disabled={savingRole}
                        >
                            Cancel
                        </Button>

                        <Button
                            type="button"
                            onClick={() => void handleRoleSubmit()}
                            loading={savingRole}
                        >
                            <CheckIcon size={16} />
                            {editingRole ? "Update Role" : "Create Role"}
                        </Button>
                    </div>
                </div>
            )}

            <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">
                {/* Role List */}
                <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                    <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
                        <div className="flex items-center justify-between gap-3">
                            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                                Roles
                            </h3>

                            <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-slate-500 ring-1 ring-slate-200">
                                {roles.length}
                            </span>
                        </div>

                        <input
                            type="search"
                            value={search}
                            onChange={(event) => setSearch(event.target.value)}
                            placeholder="Search roles..."
                            className="mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                            aria-label="Search roles"
                        />
                    </div>

                    {loadingRoles ? (
                        <div className="space-y-2 p-4">
                            {[1, 2, 3].map((item) => (
                                <div
                                    key={item}
                                    className="animate-pulse rounded-lg border border-slate-100 p-4"
                                >
                                    <div className="h-4 w-2/3 rounded bg-slate-100" />
                                    <div className="mt-2 h-3 w-full rounded bg-slate-100" />
                                    <div className="mt-2 h-3 w-1/3 rounded bg-slate-100" />
                                </div>
                            ))}
                        </div>
                    ) : filteredRoles.length === 0 ? (
                        <div className="px-4 py-12 text-center">
                            <ShieldIcon
                                size={26}
                                className="mx-auto text-slate-300"
                            />
                            <p className="mt-3 text-sm font-semibold text-slate-600">
                                No roles found
                            </p>
                            <p className="mt-1 text-xs text-slate-400">
                                {search
                                    ? "Try another search."
                                    : "Create your first custom role."}
                            </p>
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-100">
                            {filteredRoles.map((role) => (
                                <button
                                    key={role.id}
                                    type="button"
                                    onClick={() => setSelectedRoleId(role.id)}
                                    className={`w-full px-4 py-4 text-left transition-colors ${
                                        selectedRoleId === role.id
                                            ? "bg-red-50"
                                            : "hover:bg-slate-50"
                                    }`}
                                >
                                    <div className="flex items-start justify-between gap-2">
                                        <div className="min-w-0">
                                            <div className="flex min-w-0 items-center gap-2">
                                                <p
                                                    className={`truncate text-sm font-semibold ${
                                                        selectedRoleId === role.id
                                                            ? "text-red-600"
                                                            : "text-slate-800"
                                                    }`}
                                                >
                                                    {getRoleDisplayName(role)}
                                                </p>

                                                {role.ownerRole && (
                                                    <span className="shrink-0 rounded-full bg-slate-900 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white">
                                                        Owner
                                                    </span>
                                                )}
                                            </div>

                                            <p className="mt-1 line-clamp-2 text-xs text-slate-400">
                                                {role.description || "No description"}
                                            </p>

                                            <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                                                <span>
                                                    {role.members} {role.members === 1 ? "member" : "members"}
                                                </span>
                                                <span className="text-slate-300">•</span>
                                                <span className="capitalize">
                                                    {role.realm}
                                                </span>
                                                {!role.active && (
                                                    <>
                                                        <span className="text-slate-300">•</span>
                                                        <span className="text-red-500">
                                                            Inactive
                                                        </span>
                                                    </>
                                                )}
                                            </div>
                                        </div>

                                        {selectedRoleId === role.id && (
                                            <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-red-600" />
                                        )}
                                    </div>
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                {/* Permissions */}
                <div className="min-w-0">
                    {!selectedRole ? (
                        <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-6 py-14 text-center">
                            <ShieldIcon
                                size={30}
                                className="mx-auto text-slate-300"
                            />
                            <p className="mt-3 text-sm font-semibold text-slate-600">
                                Select a role
                            </p>
                            <p className="mt-1 text-xs text-slate-400">
                                Choose a role from the left to manage access.
                            </p>
                        </div>
                    ) : (
                        <>
                            <div className="mb-4 flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 md:flex-row md:items-center md:justify-between">
                                <div className="min-w-0">
                                    <div className="flex flex-wrap items-center gap-2">
                                        <h3 className="text-base font-bold text-slate-900">
                                            {selectedRole.name}
                                        </h3>

                                        {selectedRole.system && (
                                            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
                                                System Role
                                            </span>
                                        )}
                                    </div>

                                    <p className="mt-1 text-sm text-slate-500">
                                        {selectedRole.description ||
                                            "Configure module access for this role."}
                                    </p>

                                    <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                                        <span className="rounded-full bg-slate-50 px-2.5 py-1 font-semibold ring-1 ring-slate-200">
                                            {permissionCount.enabled} enabled
                                        </span>
                                        <span className="rounded-full bg-slate-50 px-2.5 py-1 font-semibold ring-1 ring-slate-200">
                                            {permissionCount.total} modules
                                        </span>
                                        <span className="rounded-full bg-slate-50 px-2.5 py-1 font-semibold capitalize ring-1 ring-slate-200">
                                            {selectedRole.realm}
                                        </span>
                                    </div>
                                </div>

                                <div className="flex shrink-0 flex-wrap items-center gap-2">
                                    {!selectedRole.system && (
                                        <>
                                            <Button
                                                type="button"
                                                variant="outline"
                                                onClick={openEditRole}
                                                disabled={savingRole || deletingRole}
                                                className="!px-3"
                                            >
                                                <PencilSimpleIcon size={16} />
                                                Edit
                                            </Button>

                                            <Button
                                                type="button"
                                                variant="outline"
                                                onClick={() => setDeleteRole(selectedRole)}
                                                disabled={
                                                    selectedRole.ownerRole ||
                                                    savingRole ||
                                                    deletingRole
                                                }
                                                className="!border-red-200 !text-red-600 hover:!bg-red-50"
                                            >
                                                <TrashIcon size={16} />
                                                Remove
                                            </Button>
                                        </>
                                    )}

                                    <Button
                                        type="button"
                                        onClick={() => void savePermissions()}
                                        disabled={!canManageSelectedRole || loadingPermissions}
                                        loading={savingPermissions}
                                        className="!px-3"
                                    >
                                        <FloppyDiskBackIcon size={16} />
                                        Save Permissions
                                    </Button>
                                </div>
                            </div>

                            {selectedRole.ownerRole && (
                                <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                                    Workspace Owner permissions are protected by the backend and cannot be modified here.
                                </div>
                            )}

                            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                                {loadingPermissions ? (
                                    <div className="space-y-3 p-5">
                                        {[1, 2, 3, 4, 5].map((item) => (
                                            <div
                                                key={item}
                                                className="animate-pulse rounded-lg border border-slate-100 p-4"
                                            >
                                                <div className="h-4 w-1/3 rounded bg-slate-100" />
                                                <div className="mt-2 h-3 w-2/3 rounded bg-slate-100" />
                                            </div>
                                        ))}
                                    </div>
                                ) : permissions.length === 0 ? (
                                    <div className="px-6 py-14 text-center">
                                        <ShieldIcon
                                            size={28}
                                            className="mx-auto text-slate-300"
                                        />
                                        <p className="mt-3 text-sm font-semibold text-slate-600">
                                            No active permissions found
                                        </p>
                                        <p className="mt-1 text-xs text-slate-400">
                                            Permission definitions must be seeded before the matrix can be configured.
                                        </p>
                                    </div>
                                ) : (
                                    <div className="divide-y divide-slate-100">
                                        {groupedPermissions.map(
                                            ([category, categoryPermissions]) => (
                                                <div key={category}>
                                                    <div className="border-b border-slate-100 bg-slate-50 px-4 py-3">
                                                        <p className="text-xs font-bold uppercase tracking-wide text-slate-500">
                                                            {category}
                                                        </p>
                                                    </div>

                                                    <div className="overflow-x-auto">
                                                        <table className="w-full min-w-[760px] border-collapse">
                                                            <thead>
                                                                <tr className="border-b border-slate-100">
                                                                    <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-wider text-slate-400">
                                                                        Permission
                                                                    </th>
                                                                    {ACTIONS.map((action) => (
                                                                        <th
                                                                            key={action}
                                                                            className="w-20 px-2 py-3 text-center text-[10px] font-black uppercase tracking-wider text-slate-400"
                                                                        >
                                                                            {ACTION_LABELS[action]}
                                                                        </th>
                                                                    ))}
                                                                    <th className="w-20 px-2 py-3 text-center text-[10px] font-black uppercase tracking-wider text-slate-400">
                                                                        ALL
                                                                    </th>
                                                                </tr>
                                                            </thead>

                                                            <tbody>
                                                                {categoryPermissions.map(
                                                                    (permission) => (
                                                                        <tr
                                                                            key={permission.id}
                                                                            className="border-b border-slate-50 last:border-b-0 hover:bg-slate-50/60"
                                                                        >
                                                                            <td className="px-4 py-4 align-middle">
                                                                                <div className="min-w-0">
                                                                                    <div className="flex items-center gap-2">
                                                                                        <p className="truncate text-sm font-semibold text-slate-800">
                                                                                            {permission.name}
                                                                                        </p>
                                                                                        {permission.system && (
                                                                                            <span className="shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[9px] font-bold uppercase text-slate-400">
                                                                                                System
                                                                                            </span>
                                                                                        )}
                                                                                    </div>
                                                                                    <p className="mt-1 text-xs text-slate-400">
                                                                                        {permission.description || permission.key}
                                                                                    </p>
                                                                                </div>
                                                                            </td>

                                                                            {ACTIONS.map((action) => {
                                                                                const supported =
                                                                                    permission.supportedActions[action];
                                                                                const checked = permission.actions[action];
                                                                                const disabled =
                                                                                    !supported ||
                                                                                    selectedRole.ownerRole;

                                                                                return (
                                                                                    <td
                                                                                        key={action}
                                                                                        className="px-2 py-4 text-center align-middle"
                                                                                    >
                                                                                        <button
                                                                                            type="button"
                                                                                            onClick={() =>
                                                                                                updatePermission(
                                                                                                    permission.id,
                                                                                                    action,
                                                                                                )
                                                                                            }
                                                                                            disabled={disabled}
                                                                                            aria-label={`${ACTION_LABELS[action]} ${permission.name}`}
                                                                                            aria-pressed={checked}
                                                                                            className={`mx-auto flex h-8 w-8 items-center justify-center rounded-lg border transition ${
                                                                                                checked
                                                                                                    ? "border-red-600 bg-red-600 text-white"
                                                                                                    : "border-slate-200 bg-white text-transparent"
                                                                                            } ${
                                                                                                disabled
                                                                                                    ? "cursor-not-allowed opacity-40"
                                                                                                    : "hover:border-red-300 hover:bg-red-50"
                                                                                            }`}
                                                                                        >
                                                                                            {checked && (
                                                                                                <CheckIcon
                                                                                                    size={16}
                                                                                                    weight="bold"
                                                                                                />
                                                                                            )}
                                                                                        </button>
                                                                                    </td>
                                                                                );
                                                                            })}

                                                                            <td className="px-2 py-4 text-center align-middle">
                                                                                <button
                                                                                    type="button"
                                                                                    onClick={() =>
                                                                                        togglePermissionAll(
                                                                                            permission.id,
                                                                                        )
                                                                                    }
                                                                                    disabled={
                                                                                        selectedRole.ownerRole ||
                                                                                        ACTIONS.every(
                                                                                            (action) =>
                                                                                                !permission.supportedActions[
                                                                                                    action
                                                                                                ],
                                                                                        )
                                                                                    }
                                                                                    aria-label={`Toggle all permissions for ${permission.name}`}
                                                                                    aria-pressed={permission.all}
                                                                                    className={`mx-auto flex h-8 w-8 items-center justify-center rounded-lg border transition ${
                                                                                        permission.all
                                                                                            ? "border-slate-900 bg-slate-900 text-white"
                                                                                            : "border-slate-200 bg-white text-slate-300"
                                                                                    } disabled:cursor-not-allowed disabled:opacity-40`}
                                                                                >
                                                                                    <CheckIcon
                                                                                        size={15}
                                                                                        weight="bold"
                                                                                    />
                                                                                </button>
                                                                            </td>
                                                                        </tr>
                                                                    ),
                                                                )}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            ),
                                        )}
                                    </div>
                                )}
                            </div>
                        </>
                    )}
                </div>
            </div>

            <ConfirmModal
                open={Boolean(deleteRole)}
                title="Remove Role"
                message={
                    deleteRole
                        ? `Remove “${deleteRole.name}”? The role is soft-deactivated by the backend. Existing user assignments should be reviewed before removing it.`
                        : ""
                }
                confirmText="Remove Role"
                onConfirm={() => void confirmDelete()}
                onCancel={() =>
                    deletingRole ? undefined : setDeleteRole(null)
                }
                loading={deletingRole}
            />
        </div>
    );
}
