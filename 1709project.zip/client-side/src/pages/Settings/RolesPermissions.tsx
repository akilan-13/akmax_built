import { useState } from "react";
import {
  CheckIcon,
  FloppyDiskBackIcon,
  PlusIcon,
  ShieldIcon,
  TrashIcon,
  XIcon,
} from "@phosphor-icons/react";
import ConfirmModal from "../../components/ConfirmModal";
import Button from "../../components/Button";
import Field from "../../components/Field";

type Permission = {
  view: boolean;
  add: boolean;
  edit: boolean;
  delete: boolean;
};

interface Role {
  id: number;
  name: string;
  description: string;
  members: number;
  permissions: Record<string, Permission>;
}

const MODULES = [
  "Dashboard",
  "Projects",
  "Vendor",
  "Quotation",
  "Invoices",
  "Tasks",
  "User Management",
  "Master Rate Schedule",
  "Settings",
];

const createPermissions = (
  defaultValue = false
): Record<string, Permission> => {
  return MODULES.reduce(
    (acc, module) => {
      acc[module] = {
        view: defaultValue,
        add: defaultValue,
        edit: defaultValue,
        delete: defaultValue,
      };

      return acc;
    },
    {} as Record<string, Permission>
  );
};

const INITIAL_ROLES: Role[] = [
  {
    id: 1,
    name: "Workspace Owner",
    description: "Full access to the entire workspace.",
    members: 1,
    permissions: createPermissions(true),
  },
  {
    id: 2,
    name: "Network Administrator",
    description: "Manages projects, vendors and network operations.",
    members: 4,
    permissions: createPermissions(true),
  },
  {
    id: 3,
    name: "Field Technician",
    description: "Handles field operations and assigned tasks.",
    members: 12,
    permissions: createPermissions(false),
  },
  {
    id: 4,
    name: "Billing Manager",
    description: "Manages invoices and billing operations.",
    members: 3,
    permissions: createPermissions(false),
  },
];

export default function RolesPermissions() {
  const [roles, setRoles] = useState<Role[]>(INITIAL_ROLES);

  const [selectedRoleId, setSelectedRoleId] = useState<number>(
    INITIAL_ROLES[0].id
  );

  const [showRoleForm, setShowRoleForm] = useState(false);
  const [deleteRole, setDeleteRole] = useState<Role | null>(null);
  const [roleForm, setRoleForm] = useState({
    name: "",
    description: "",
  });

  const selectedRole = roles.find(
    (role) => role.id === selectedRoleId
  );

  // --------------------------------
  // Permission Update
  // --------------------------------

  const updatePermission = (
    module: string,
    permission: keyof Permission
  ) => {
    setRoles((prev) =>
      prev.map((role) => {
        if (role.id !== selectedRoleId) {
          return role;
        }

        return {
          ...role,
          permissions: {
            ...role.permissions,
            [module]: {
              ...role.permissions[module],
              [permission]:
                !role.permissions[module][permission],
            },
          },
        };
      })
    );
  };

  // --------------------------------
  // Select / Deselect All
  // --------------------------------

  const toggleModulePermissions = (module: string) => {
    setRoles((prev) =>
      prev.map((role) => {
        if (role.id !== selectedRoleId) {
          return role;
        }

        const permission = role.permissions[module];

        const allSelected =
          permission.view &&
          permission.add &&
          permission.edit &&
          permission.delete;

        return {
          ...role,
          permissions: {
            ...role.permissions,
            [module]: {
              view: !allSelected,
              add: !allSelected,
              edit: !allSelected,
              delete: !allSelected,
            },
          },
        };
      })
    );
  };

  // --------------------------------
  // Add Role
  // --------------------------------

  const addRole = () => {
    if (!roleForm.name.trim()) {
      return;
    }

    const newRole: Role = {
      id: Date.now(),
      name: roleForm.name,
      description: roleForm.description,
      members: 0,
      permissions: createPermissions(false),
    };

    setRoles((prev) => [...prev, newRole]);

    setSelectedRoleId(newRole.id);

    setRoleForm({
      name: "",
      description: "",
    });

    setShowRoleForm(false);
  };

  // --------------------------------
  // Delete Role
  // --------------------------------

  const updateAccess = (
    index: number,
    access: Role["permissions"]
  ) => {
    setRoles((prev) =>
      prev.map((r, i) =>
        i === index ? { ...r, access } : r
      )
    );
  };

  const openDeleteModal = (role: Role) => {
    setDeleteRole(role);
  };

  const closeDeleteModal = () => {
    setDeleteRole(null);
  };

  const confirmDelete = () => {
    if (!deleteRole) {
      return;
    }

    setRoles((prev) =>
      prev.filter((role) => role.name !== deleteRole.name)
    );

    setDeleteRole(null);
  };

  // --------------------------------
  // Save
  // --------------------------------

  const handleSave = () => {
    console.log("Roles:", roles);

    // API call here
    // axios.post('/api/roles', roles)
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="flex items-start gap-4">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
            <ShieldIcon size={20} />
          </div>

          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Roles & Permissions
            </h2>
          </div>
        </div>

        <Button
          onClick={() => setShowRoleForm(true)}
        >
          <PlusIcon size={17} />
          Add Role
        </Button>
      </div>

      {/* Add Role Form */}
      {showRoleForm && (
        <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                Add New Role
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                Create a role and configure its permissions.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowRoleForm(false)}
              className="text-slate-400 hover:text-slate-700"
            >
              <XIcon size={18} />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field
              label="Role Name"
              placeholder="e.g. Project Manager"
              value={roleForm.name}
              onChange={(e) =>
                setRoleForm((prev) => ({
                  ...prev,
                  name: e.target.value,
                }))
              }
            />

            <Field
              label="Description"
              placeholder="Describe this role"
              value={roleForm.description}
              onChange={(e) =>
                setRoleForm((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
            />
          </div>

          <div className="mt-5 flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setShowRoleForm(false)}
            >
              Cancel
            </Button>

            <Button onClick={addRole}>
              <PlusIcon size={16} />
              Create Role
            </Button>
          </div>
        </div>
      )}

      {/* Roles */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">

        {/* Role List */}
        <div className="overflow-hidden rounded-xl border border-slate-200">
          <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Roles
            </h3>
          </div>

          <div className="divide-y divide-slate-100">
            {roles.map((role) => (
              <button
                key={role.id}
                type="button"
                onClick={() =>
                  setSelectedRoleId(role.id)
                }
                className={`w-full px-4 py-4 text-left transition-colors ${selectedRoleId === role.id
                  ? "bg-red-50"
                  : "hover:bg-slate-50"
                  }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p
                      className={`truncate text-sm font-semibold ${selectedRoleId === role.id
                        ? "text-red-600"
                        : "text-slate-800"
                        }`}
                    >
                      {role.name}
                    </p>

                    <p className="mt-1 line-clamp-2 text-xs text-slate-400">
                      {role.description}
                    </p>

                    <p className="mt-2 text-xs text-slate-500">
                      {role.members}{" "}
                      {role.members === 1
                        ? "member"
                        : "members"}
                    </p>
                  </div>

                  {selectedRoleId === role.id && (
                    <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-red-600" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Permissions */}
        {selectedRole && (
          <div className="min-w-0">
            <div className="mb-4">
              <h3 className="text-base font-bold text-slate-900">
                {selectedRole.name}
              </h3>

              <p className="mt-1 text-sm text-slate-500">
                {selectedRole.description}
              </p>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full min-w-[650px] text-left text-sm">
                <thead>
                  <tr className="bg-slate-50 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    <th className="px-4 py-3">
                      Module
                    </th>

                    <th className="px-4 py-3 text-center">
                      View
                    </th>

                    <th className="px-4 py-3 text-center">
                      Add
                    </th>

                    <th className="px-4 py-3 text-center">
                      Edit
                    </th>

                    <th className="px-4 py-3 text-center">
                      Delete
                    </th>

                    <th className="px-4 py-3 text-center">
                      All
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {MODULES.map((module) => {
                    const permission =
                      selectedRole.permissions[module];

                    const allSelected =
                      permission.view &&
                      permission.add &&
                      permission.edit &&
                      permission.delete;

                    return (
                      <tr key={module}>
                        <td className="px-4 py-3.5 font-medium text-slate-800">
                          {module}
                        </td>

                        {(
                          [
                            "view",
                            "add",
                            "edit",
                            "delete",
                          ] as const
                        ).map((action) => (
                          <td
                            key={action}
                            className="px-4 py-3.5 text-center"
                          >
                            <button
                              type="button"
                              onClick={() =>
                                updatePermission(
                                  module,
                                  action
                                )
                              }
                              className={`mx-auto flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${permission[
                                action
                              ]
                                ? "border-red-600 bg-red-600 text-white"
                                : "border-slate-300 bg-white text-transparent hover:border-red-400"
                                }`}
                            >
                              <CheckIcon
                                size={14}
                                weight="bold"
                              />
                            </button>
                          </td>
                        ))}

                        <td className="px-4 py-3.5 text-center">
                          <button
                            type="button"
                            onClick={() =>
                              toggleModulePermissions(
                                module
                              )
                            }
                            className={`mx-auto flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${allSelected
                              ? "border-red-600 bg-red-600 text-white"
                              : "border-slate-300 bg-white text-transparent hover:border-red-400"
                              }`}
                          >
                            <CheckIcon
                              size={14}
                              weight="bold"
                            />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Delete Role */}
            {selectedRole.name !== "Workspace Owner" && (
              <div className="mt-4 flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => openDeleteModal(selectedRole)}
                >
                  <TrashIcon size={16} className="text-red-600" />
                  Delete Role
                </Button>
                <Button onClick={handleSave}>
                  <FloppyDiskBackIcon size={16} />
                  Save Changes
                </Button>
              </div>
            )}
          </div>
        )}
      </div>


    </div>
  );
}