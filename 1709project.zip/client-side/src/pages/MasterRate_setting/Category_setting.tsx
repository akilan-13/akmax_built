import { useState } from "react";
import {
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
    TagIcon,
} from "@phosphor-icons/react";

import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, {
    DataTableColumn,
} from "../../components/DataTable";

export interface Category {
    id: string;
    categoryType: string;
    category: string;
    description: string;
    status: boolean;
}

const INITIAL_CATEGORIES: Category[] = [
    {
        id: "CAT-001",
        categoryType: "Material",
        category: "Fiber Optic",
        description:
            "Materials and components used for fiber optic network installations.",
        status: true,
    },
    {
        id: "CAT-002",
        categoryType: "Material",
        category: "Civil Works",
        description:
            "Materials required for civil construction and infrastructure works.",
        status: true,
    },
    {
        id: "CAT-003",
        categoryType: "Service",
        category: "Installation",
        description:
            "Services related to installation, deployment, and commissioning.",
        status: true,
    },
    {
        id: "CAT-004",
        categoryType: "Service",
        category: "Splicing & Testing",
        description:
            "Fiber splicing, testing, inspection, and certification services.",
        status: true,
    },
    {
        id: "CAT-005",
        categoryType: "Equipment",
        category: "Network Equipment",
        description:
            "Equipment used for network deployment, connectivity, and infrastructure.",
        status: true,
    },
];

interface CategoryFormData {
    categoryType: string;
    category: string;
    description: string;
}

const CATEGORY_TYPES = [
    "Material",
    "Service",
    "Equipment",
];

const emptyForm: CategoryFormData = {
    categoryType: "",
    category: "",
    description: "",
};

export default function CategorySetting() {
    const [categories, setCategories] =
        useState<Category[]>(INITIAL_CATEGORIES);

    const [showForm, setShowForm] =
        useState(false);

    const [editingCategory, setEditingCategory] =
        useState<Category | null>(null);

    const [formData, setFormData] =
        useState<CategoryFormData>(emptyForm);

    const [deleteCategory, setDeleteCategory] =
        useState<Category | null>(null);

    const [errors, setErrors] = useState<{
        categoryType?: string;
        category?: string;
        description?: string;
    }>({});

    const openAddForm = () => {
        setEditingCategory(null);
        setFormData(emptyForm);
        setErrors({});
        setShowForm(true);
    };

    const openEditForm = (category: Category) => {
        setEditingCategory(category);

        setFormData({
            categoryType: category.categoryType,
            category: category.category,
            description: category.description,
        });

        setErrors({});
        setShowForm(true);
    };

    const closeForm = () => {
        setShowForm(false);
        setEditingCategory(null);
        setFormData(emptyForm);
        setErrors({});
    };

    const validateForm = () => {
        const nextErrors: {
            categoryType?: string;
            category?: string;
            description?: string;
        } = {};

        if (!formData.categoryType.trim()) {
            nextErrors.categoryType =
                "Category type is required.";
        }

        if (!formData.category.trim()) {
            nextErrors.category =
                "Category is required.";
        }

        if (!formData.description.trim()) {
            nextErrors.description =
                "Description is required.";
        }

        const duplicateCategory = categories.some(
            (item) =>
                item.categoryType
                    .trim()
                    .toLowerCase() ===
                    formData.categoryType
                        .trim()
                        .toLowerCase() &&
                item.category
                    .trim()
                    .toLowerCase() ===
                    formData.category
                        .trim()
                        .toLowerCase() &&
                item.id !== editingCategory?.id
        );

        if (duplicateCategory) {
            nextErrors.category =
                "This category already exists under the selected category type.";
        }

        setErrors(nextErrors);

        return (
            Object.keys(nextErrors).length === 0
        );
    };

    const generateCategoryId = () => {
        const highestNumber = categories.reduce(
            (highest, item) => {
                const match = item.id.match(
                    /CAT-(\d+)/
                );

                if (!match) {
                    return highest;
                }

                return Math.max(
                    highest,
                    Number(match[1])
                );
            },
            0
        );

        return `CAT-${String(
            highestNumber + 1
        ).padStart(3, "0")}`;
    };

    const handleSave = () => {
        if (!validateForm()) {
            return;
        }

        if (editingCategory) {
            setCategories((previous) =>
                previous.map((item) =>
                    item.id === editingCategory.id
                        ? {
                              ...item,
                              categoryType:
                                  formData.categoryType.trim(),
                              category:
                                  formData.category.trim(),
                              description:
                                  formData.description.trim(),
                          }
                        : item
                )
            );
        } else {
            const newCategory: Category = {
                id: generateCategoryId(),
                categoryType:
                    formData.categoryType.trim(),
                category:
                    formData.category.trim(),
                description:
                    formData.description.trim(),
                status: true,
            };

            setCategories((previous) => [
                ...previous,
                newCategory,
            ]);
        }

        closeForm();
    };

    const handleToggle = (
        category: Category,
        checked: boolean
    ) => {
        setCategories((previous) =>
            previous.map((item) =>
                item.id === category.id
                    ? {
                          ...item,
                          status: checked,
                      }
                    : item
            )
        );
    };

    const handleDelete = () => {
        if (!deleteCategory) {
            return;
        }

        setCategories((previous) =>
            previous.filter(
                (item) =>
                    item.id !== deleteCategory.id
            )
        );

        setDeleteCategory(null);
    };

    const columns: DataTableColumn<Category>[] = [
         {
            key: "category",
            label: "Category",
            sortable: true,
            width: "20%",
            render: (row) => (
                <span className="text-xs font-bold text-slate-700">
                    {row.category}
                </span>
            ),
        },
        {
            key: "categoryType",
            label: "Category Type",
            sortable: true,
            width: "20%",
            render: (row) => (
                <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                        <TagIcon
                            size={17}
                            weight="duotone"
                        />
                    </div>

                    <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-800">
                            {row.categoryType}
                        </p>

                        <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                            {row.id}
                        </p>
                    </div>
                </div>
            ),
        },

        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "40%",
            render: (row) => (
                <span className="text-xs leading-5 text-slate-500">
                    {row.description}
                </span>
            ),
        },
        // Status - Separate Column
    {
        key: "status",
        label: "Status",
        sortable: true,
        align: "center",
        width: "12%",
        render: (row) => (
            <div className="flex items-center justify-center">
                <ToggleSwitch
                    checked={row.status}
                    onChange={(checked) =>
                        handleToggle(row, checked)
                    }
                    srLabel={`Toggle ${row.category} status`}
                />
            </div>
        ),
    },

    // Actions - Only Edit and Delete
    {
        key: "actions",
        label: "Actions",
        align: "center",
        width: "13%",
        render: (row) => (
            <div className="flex items-center justify-center gap-1">
                <button
                    type="button"
                    onClick={() =>
                        openEditForm(row)
                    }
                    title={`Edit ${row.category}`}
                    aria-label={`Edit ${row.category}`}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                >
                    <PencilSimpleIcon
                        size={16}
                        weight="duotone"
                    />
                </button>

                <button
                    type="button"
                    onClick={() =>
                        setDeleteCategory(row)
                    }
                    title={`Delete ${row.category}`}
                    aria-label={`Delete ${row.category}`}
                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                >
                    <TrashIcon
                        size={16}
                        weight="duotone"
                    />
                </button>
            </div>
        ),
    },
    ];

    return (
        <div className="space-y-5">
            {/* Header */}
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Categories
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage categories used across
                        the master rate configuration.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={openAddForm}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                >
                    <PlusIcon
                        size={16}
                        weight="bold"
                    />

                    Add Category
                </button>
            </div>

            {/* Add / Edit Form */}
            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingCategory
                                ? "Edit Category"
                                : "Add Category"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingCategory
                                ? "Update the category information."
                                : "Create a new master rate category."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {/* Category ID */}
                        {editingCategory && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Category ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingCategory.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        {/* Category Type */}
                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Category Type
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <select
                                value={
                                    formData.categoryType
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            categoryType:
                                                event
                                                    .target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.categoryType
                                    ) {
                                        setErrors(
                                            (
                                                previous
                                            ) => ({
                                                ...previous,
                                                categoryType:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition ${
                                    errors.categoryType
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            >
                                <option value="">
                                    Select category type
                                </option>

                                {CATEGORY_TYPES.map(
                                    (type) => (
                                        <option
                                            key={type}
                                            value={type}
                                        >
                                            {type}
                                        </option>
                                    )
                                )}
                            </select>

                            {errors.categoryType && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.categoryType
                                    }
                                </p>
                            )}
                        </div>

                        {/* Category */}
                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Category
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={
                                    formData.category
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            category:
                                                event
                                                    .target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.category
                                    ) {
                                        setErrors(
                                            (
                                                previous
                                            ) => ({
                                                ...previous,
                                                category:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="e.g. Fiber Optic"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.category
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.category && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.category}
                                </p>
                            )}
                        </div>

                        {/* Description */}
                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={
                                    formData.description
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            description:
                                                event
                                                    .target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (
                                                previous
                                            ) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="Enter a description for this category..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.description
                                    }
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Form Actions */}
                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={closeForm}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                        >
                            {editingCategory
                                ? "Save Changes"
                                : "Add Category"}
                        </button>
                    </div>
                </div>
            )}

            {/* Categories Table */}
            <DataTable<Category>
                columns={columns}
                data={categories}
                rowKey={(row) => row.id}
                minWidth="900px"
                emptyMessage="No categories found. Click Add Category to create one."
            />

            {/* Delete Confirmation */}
            {deleteCategory && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={19}
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete Category
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are you sure you
                                        want to delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteCategory.category
                                            }
                                        </span>
                                        ? This action
                                        cannot be undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={() =>
                                    setDeleteCategory(
                                        null
                                    )
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleDelete}
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                            >
                                Delete Category
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
