import { useState } from "react";
import RichTextEditor from "../../components/RichTextEditor";

const TermsCondition = () => {
    const [title, setTitle] = useState(
        "Default Terms & Conditions"
    );

    const [content, setContent] = useState(`
        <h2>Terms & Conditions</h2>

<p>
    These Terms & Conditions apply to all quotations, proposals, commercial
    offers and vendor offers issued through the company. By accepting a
    quotation, purchase order or service proposal, the customer or vendor
    agrees to comply with these Terms & Conditions together with any
    applicable contract, service agreement or SLA.
</p>

<h3>1. Quotation Validity</h3>

<p>
    All quotations are valid only for the period specified in the quotation.
    After the expiry of the validity period, prices, availability, delivery
    schedules and other commercial terms may be subject to change.
</p>

<h3>2. Pricing and Taxes</h3>

<p>
    All prices stated in the quotation are based on the information and
    requirements available at the time of preparation. Applicable taxes,
    duties, government charges, regulatory fees, shipping, installation and
    other additional charges will be applied as required unless specifically
    stated otherwise in the quotation.
</p>

<h3>3. Product and Service Availability</h3>

<p>
    All equipment, materials, connectivity services and other telecom
    services are subject to availability. Product specifications, models,
    manufacturers and delivery schedules may be subject to change due to
    supplier availability, manufacturing constraints or other circumstances
    beyond the company's reasonable control.
</p>
   `);

    const [error, setError] = useState("");

    const handleSave = () => {
        // Remove HTML tags to check whether editor has content
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = content;

        const plainText =
            tempDiv.textContent?.trim() || "";

        if (!title.trim()) {
            setError(
                "Terms & Conditions title is required."
            );
            return;
        }

        if (!plainText) {
            setError(
                "Terms & Conditions content is required."
            );
            return;
        }

        setError("");

        const termsConditionData = {
            title: title.trim(),
            content: content,
        };

        console.log(
            "Terms & Conditions:",
            termsConditionData
        );

        // Later:
        // await api.saveTermsCondition(termsConditionData);
    };

    const handleClear = () => {
        setContent("");
        setError("");
    };

    return (
        <div className="space-y-4">

            {/* ================================= */}
            {/* Header */}
            {/* ================================= */}

            <div className="flex flex-col gap-2 border-b border-slate-200 pb-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Terms & Conditions
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage the terms and conditions
                        available for quotations and
                        vendor offers.
                    </p>
                </div>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                {/* Card Header */}
                {/* <div className="mb-5">
                    <h3 className="text-sm font-bold text-slate-900">
                        Terms & Conditions
                    </h3>

                    <p className="mt-1 text-xs text-slate-500">
                        Enter and format your terms and
                        conditions below.
                    </p>
                </div> */}
                <div className="mb-5">
                    <label
                        htmlFor="terms-title"
                        className="mb-1.5 block text-xs font-semibold text-slate-700"
                    >
                        Title
                        <span className="ml-1 text-red-500">
                            *
                        </span>
                    </label>

                    <input
                        id="terms-title"
                        type="text"
                        value={title}
                        onChange={(event) => {
                            setTitle(
                                event.target.value
                            );

                            if (error) {
                                setError("");
                            }
                        }}
                        placeholder="e.g. Standard Terms & Conditions"
                        className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                            error && !title.trim()
                                ? "border-red-300 focus:border-red-400"
                                : "border-slate-200 focus:border-red-300"
                        }`}
                    />
                </div>

                {/* ================================= */}
                {/* Quill Editor */}
                {/* ================================= */}

                <div>
                    <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                        Terms & Conditions
                        <span className="ml-1 text-red-500">
                            *
                        </span>
                    </label>

                    <RichTextEditor
                        value={content}
                        onChange={(value) => {
                            setContent(value);

                            if (error) {
                                setError("");
                            }
                        }}
                    />

                    {error && (
                        <p className="mt-1.5 text-[10px] font-medium text-red-500">
                            {error}
                        </p>
                    )}
                </div>

                {/* ================================= */}
                {/* Actions */}
                {/* ================================= */}

                <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">

                    <button
                        type="button"
                        onClick={handleClear}
                        className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                    >
                        Clear
                    </button>

                    <button
                        type="button"
                        onClick={handleSave}
                        className="rounded-lg bg-red-600 px-5 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                    >
                        Save Terms & Conditions
                    </button>

                </div>
            </div>
        </div>
    );
};

export default TermsCondition;
