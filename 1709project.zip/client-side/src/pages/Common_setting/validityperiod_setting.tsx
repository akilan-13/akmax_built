import { useState } from "react";
import {
    CalendarBlankIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
} from "@phosphor-icons/react";

import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, {
    DataTableColumn,
} from "../../components/DataTable";

export interface ValidityPeriod {
    id: string;
    name: string;
    description: string;
    status: boolean;
}

const INITIAL_VALIDITY_PERIODS: ValidityPeriod[] = [
    {
        id: "VP-001",
        name: "15 Calendar Days",
        description:
            "Quotation or offer remains valid for 15 calendar days from the date of issue.",
        status: true,
    },
    {
        id: "VP-002",
        name: "30 Calendar Days",
        description:
            "Quotation or offer remains valid for 30 calendar days from the date of issue.",
        status: true,
    },
    {
        id: "VP-003",
        name: "60 Calendar Days",
        description:
            "Quotation or offer remains valid for 60 calendar days from the date of issue.",
        status: true,
    },
    {
        id: "VP-004",
        name: "90 Calendar Days",
        description:
            "Quotation or offer remains valid for 90 calendar days from the date of issue.",
        status: true,
    },
];

interface ValidityPeriodFormData {
    name: string;
    description: string;
}

const emptyForm: ValidityPeriodFormData = {
    name: "",
    description: "",
};

export default function ValidityPeriodSetting() {
    const [validityPeriods, setValidityPeriods] =
        useState<ValidityPeriod[]>(
            INITIAL_VALIDITY_PERIODS
        );

    const [showForm, setShowForm] =
        useState(false);

    const [editingValidityPeriod, setEditingValidityPeriod] =
        useState<ValidityPeriod | null>(null);

    const [formData, setFormData] =
        useState<ValidityPeriodFormData>(emptyForm);

    const [deleteValidityPeriod, setDeleteValidityPeriod] =
        useState<ValidityPeriod | null>(null);

    const [errors, setErrors] = useState<{
        name?: string;
        description?: string;
    }>({});

    // Open Add Form
    const openAddForm = () => {
        setEditingValidityPeriod(null);
        setFormData(emptyForm);
        setErrors({});
        setShowForm(true);
    };

    // Open Edit Form
    const openEditForm = (
        validityPeriod: ValidityPeriod
    ) => {
        setEditingValidityPeriod(validityPeriod);

        setFormData({
            name: validityPeriod.name,
            description: validityPeriod.description,
        });

        setErrors({});
        setShowForm(true);
    };

    // Close Add/Edit Form
    const closeForm = () => {
        setShowForm(false);
        setEditingValidityPeriod(null);
        setFormData(emptyForm);
        setErrors({});
    };

    // Validate Form
    const validateForm = () => {
        const nextErrors: {
            name?: string;
            description?: string;
        } = {};

        if (!formData.name.trim()) {
            nextErrors.name =
                "Validity period is required.";
        }

        if (!formData.description.trim()) {
            nextErrors.description =
                "Description is required.";
        }

        const duplicateValidityPeriod =
            validityPeriods.some(
                (period) =>
                    period.name.trim().toLowerCase() ===
                        formData.name
                            .trim()
                            .toLowerCase() &&
                    period.id !==
                        editingValidityPeriod?.id
            );

        if (duplicateValidityPeriod) {
            nextErrors.name =
                "A validity period with this name already exists.";
        }

        setErrors(nextErrors);

        return (
            Object.keys(nextErrors).length === 0
        );
    };

    // Generate Validity Period ID
    const generateValidityPeriodId = () => {
        const highestNumber =
            validityPeriods.reduce(
                (highest, period) => {
                    const match =
                        period.id.match(
                            /VP-(\d+)/
                        );

                    if (!match) {
                        return highest;
                    }

                    return Math.max(
                        highest,
                        Number(match[1])
                    );
                },
                0
            );

        return `VP-${String(
            highestNumber + 1
        ).padStart(3, "0")}`;
    };

    // Save Validity Period
    const handleSave = () => {
        if (!validateForm()) {
            return;
        }

        if (editingValidityPeriod) {
            // Update existing validity period
            setValidityPeriods((previous) =>
                previous.map((period) =>
                    period.id ===
                    editingValidityPeriod.id
                        ? {
                              ...period,
                              name: formData.name.trim(),
                              description:
                                  formData.description.trim(),
                          }
                        : period
                )
            );
        } else {
            // Add new validity period
            const newValidityPeriod: ValidityPeriod = {
                id: generateValidityPeriodId(),
                name: formData.name.trim(),
                description:
                    formData.description.trim(),
                status: true,
            };

            setValidityPeriods((previous) => [
                ...previous,
                newValidityPeriod,
            ]);
        }

        closeForm();
    };

    // Toggle Status
    const handleToggle = (
        validityPeriod: ValidityPeriod,
        checked: boolean
    ) => {
        setValidityPeriods((previous) =>
            previous.map((item) =>
                item.id === validityPeriod.id
                    ? {
                          ...item,
                          status: checked,
                      }
                    : item
            )
        );
    };

    // Delete Validity Period
    const handleDelete = () => {
        if (!deleteValidityPeriod) {
            return;
        }

        setValidityPeriods((previous) =>
            previous.filter(
                (period) =>
                    period.id !==
                    deleteValidityPeriod.id
            )
        );

        setDeleteValidityPeriod(null);
    };

    // Table Columns
    const columns: DataTableColumn<ValidityPeriod>[] =
        [
            {
                key: "name",
                label: "Validity Period",
                sortable: true,
                width: "30%",
                render: (row) => (
                    <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                            <CalendarBlankIcon
                                size={17}
                                weight="duotone"
                            />
                        </div>

                        <div className="min-w-0">
                            <p className="truncate text-xs font-bold text-slate-800">
                                {row.name}
                            </p>

                            <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                                {row.id}
                            </p>
                        </div>
                    </div>
                ),
            },

            {
                key: "description",
                label: "Description",
                sortable: true,
                width: "45%",
                render: (row) => (
                    <span className="text-xs leading-5 text-slate-500">
                        {row.description}
                    </span>
                ),
            },

            {
                key: "status",
                label: "Status",
                sortable: true,
                align: "center",
                width: "15%",
                render: (row) => (
                    <div className="flex items-center justify-center">
                        <ToggleSwitch
                            checked={row.status}
                            onChange={(checked) =>
                                handleToggle(
                                    row,
                                    checked
                                )
                            }
                            srLabel={`Toggle ${row.name} status`}
                        />
                    </div>
                ),
            },

            {
                key: "actions",
                label: "Actions",
                align: "center",
                width: "10%",
                render: (row) => (
                    <div className="flex items-center justify-center gap-1">
                        {/* Edit */}
                        <button
                            type="button"
                            onClick={() =>
                                openEditForm(row)
                            }
                            title={`Edit ${row.name}`}
                            aria-label={`Edit ${row.name}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                        >
                            <PencilSimpleIcon
                                size={16}
                                weight="duotone"
                            />
                        </button>

                        {/* Delete */}
                        <button
                            type="button"
                            onClick={() =>
                                setDeleteValidityPeriod(
                                    row
                                )
                            }
                            title={`Delete ${row.name}`}
                            aria-label={`Delete ${row.name}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                        >
                            <TrashIcon
                                size={16}
                                weight="duotone"
                            />
                        </button>
                    </div>
                ),
            },
        ];

    return (
        <div className="space-y-5">

            {/* -------------------------------- */}
            {/* Header */}
            {/* -------------------------------- */}

            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Validity Periods
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage the validity periods
                        available for quotations and
                        vendor offers.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={openAddForm}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                >
                    <PlusIcon
                        size={16}
                        weight="bold"
                    />

                    Add Validity Period
                </button>
            </div>

            {/* -------------------------------- */}
            {/* Inline Add / Edit Form */}
            {/* -------------------------------- */}

            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">

                    {/* Form Header */}

                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingValidityPeriod
                                ? "Edit Validity Period"
                                : "Add Validity Period"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingValidityPeriod
                                ? "Update the validity period information."
                                : "Create a new quotation validity period."}
                        </p>
                    </div>

                    {/* Form Fields */}

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

                        {/* Validity Period ID */}

                        {editingValidityPeriod && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Validity Period ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingValidityPeriod.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        {/* Validity Period Name */}

                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Validity Period
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={
                                    formData.name
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            name: event
                                                .target
                                                .value,
                                        })
                                    );

                                    if (errors.name) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                name: undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="e.g. 30 Calendar Days"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.name
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.name && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        {/* Description */}

                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={
                                    formData.description
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            description:
                                                event.target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="Enter a description for this validity period..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.description
                                    }
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Form Buttons */}

                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">

                        <button
                            type="button"
                            onClick={closeForm}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={handleSave}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                        >
                            {editingValidityPeriod
                                ? "Save Changes"
                                : "Add Validity Period"}
                        </button>
                    </div>
                </div>
            )}

            {/* -------------------------------- */}
            {/* Validity Period Table */}
            {/* -------------------------------- */}

            <DataTable<ValidityPeriod>
                columns={columns}
                data={validityPeriods}
                rowKey={(row) => row.id}
                minWidth="760px"
                emptyMessage="No validity periods found. Click Add Validity Period to create one."
            />

            {/* -------------------------------- */}
            {/* Delete Confirmation */}
            {/* -------------------------------- */}

            {deleteValidityPeriod && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">

                        <div className="p-5">
                            <div className="flex items-start gap-3">

                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={19}
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete Validity Period
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are you sure you
                                        want to delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteValidityPeriod.name
                                            }
                                        </span>
                                        ? This action
                                        cannot be undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">

                            <button
                                type="button"
                                onClick={() =>
                                    setDeleteValidityPeriod(
                                        null
                                    )
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={
                                    handleDelete
                                }
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                            >
                                Delete Validity Period
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
