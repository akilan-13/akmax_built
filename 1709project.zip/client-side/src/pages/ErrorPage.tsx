
import React from "react";
import {
    ArrowLeftIcon,
    ArrowCounterClockwiseIcon,
    LockKeyIcon,
    MagnifyingGlassIcon,
    WarningCircleIcon,
    WifiSlashIcon,
} from "@phosphor-icons/react";

export type ErrorPageType =
    | 401
    | 403
    | 404
    | 422
    | 429
    | 500
    | 503;

interface ErrorPageProps {
    status?: ErrorPageType;
    title?: string;
    message?: string;
    requestId?: string | null;
    onRetry?: (() => void) | null;
    onBack?: (() => void) | null;
    onGoHome?: (() => void) | null;
}

interface ErrorContent {
    title: string;
    message: string;
    icon: React.ReactNode;
    iconClassName: string;
    badgeClassName: string;
    defaultAction: string;
}

/*
|--------------------------------------------------------------------------
| Error definitions
|--------------------------------------------------------------------------
*/

const ERROR_CONTENT: Record<
    ErrorPageType,
    ErrorContent
> = {
    401: {
        title: "Session expired",
        message:
            "Your session is no longer valid. Please sign in again to continue.",
        icon: (
            <LockKeyIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-amber-50 text-amber-600",
        badgeClassName:
            "bg-amber-50 text-amber-700",
        defaultAction:
            "Sign in again",
    },

    403: {
        title: "Access denied",
        message:
            "Your account is authenticated, but you do not have permission to access this resource.",
        icon: (
            <LockKeyIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-red-50 text-red-600",
        badgeClassName:
            "bg-red-50 text-red-700",
        defaultAction:
            "Back",
    },

    404: {
        title: "Page not found",
        message:
            "The page or resource you requested could not be found.",
        icon: (
            <MagnifyingGlassIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-slate-100 text-slate-600",
        badgeClassName:
            "bg-slate-100 text-slate-700",
        defaultAction:
            "Go to dashboard",
    },

    422: {
        title: "Unable to process request",
        message:
            "Some of the submitted information could not be processed. Review the form and try again.",
        icon: (
            <WarningCircleIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-amber-50 text-amber-600",
        badgeClassName:
            "bg-amber-50 text-amber-700",
        defaultAction:
            "Back",
    },

    429: {
        title: "Too many requests",
        message:
            "Too many requests were received from your session. Please wait a moment and try again.",
        icon: (
            <WarningCircleIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-amber-50 text-amber-600",
        badgeClassName:
            "bg-amber-50 text-amber-700",
        defaultAction:
            "Try again",
    },

    500: {
        title: "Something went wrong",
        message:
            "The server encountered an unexpected error while processing your request.",
        icon: (
            <WarningCircleIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-red-50 text-red-600",
        badgeClassName:
            "bg-red-50 text-red-700",
        defaultAction:
            "Try again",
    },

    503: {
        title: "Service unavailable",
        message:
            "ARGUS is temporarily unable to process this request. Please try again shortly.",
        icon: (
            <WifiSlashIcon
                size={42}
                weight="duotone"
            />
        ),
        iconClassName:
            "bg-slate-100 text-slate-600",
        badgeClassName:
            "bg-slate-100 text-slate-700",
        defaultAction:
            "Try again",
    },
};

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function ErrorPage({
    status = 500,
    title,
    message,
    requestId = null,
    onRetry = null,
    onBack = null,
    onGoHome = null,
}: ErrorPageProps) {
    const content =
        ERROR_CONTENT[status] ||
        ERROR_CONTENT[500];

    const resolvedTitle =
        title ||
        content.title;

    const resolvedMessage =
        message ||
        content.message;

    const handleDefaultAction =
        () => {
            if (
                status === 401
            ) {
                if (
                    typeof window !==
                    "undefined"
                ) {
                    window.location.assign(
                        "/login",
                    );
                }

                return;
            }

            if (
                status === 404
            ) {
                if (
                    onGoHome
                ) {
                    onGoHome();
                    return;
                }

                if (
                    typeof window !==
                    "undefined"
                ) {
                    window.location.assign(
                        "/",
                    );
                }

                return;
            }

            if (
                onRetry
            ) {
                onRetry();
                return;
            }

            if (
                onBack
            ) {
                onBack();
                return;
            }

            if (
                typeof window !==
                "undefined" &&
                window.history.length >
                    1
            ) {
                window.history.back();
            }
        };

    return (
        <div className="flex min-h-[70vh] items-center justify-center px-4 py-12">
            <div className="w-full max-w-lg">
                <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm sm:p-10">
                    <div className="flex flex-col items-center text-center">
                        {/* Status */}
                        <div
                            className={[
                                "inline-flex items-center rounded-full px-3 py-1 text-[11px] font-bold tracking-wider",
                                content.badgeClassName,
                            ].join(
                                " ",
                            )}
                        >
                            HTTP{" "}
                            {status}
                        </div>

                        {/* Icon */}
                        <div
                            className={[
                                "mt-6 flex h-20 w-20 items-center justify-center rounded-2xl",
                                content.iconClassName,
                            ].join(
                                " ",
                            )}
                        >
                            {
                                content.icon
                            }
                        </div>

                        {/* Heading */}
                        <h1 className="mt-6 text-2xl font-bold text-slate-900">
                            {
                                resolvedTitle
                            }
                        </h1>

                        <p className="mt-3 max-w-md text-sm leading-6 text-slate-500">
                            {
                                resolvedMessage
                            }
                        </p>

                        {/* Request ID */}
                        {requestId ? (
                            <div className="mt-5 rounded-xl border border-slate-100 bg-slate-50 px-4 py-3">
                                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                                    Request ID
                                </p>

                                <p className="mt-1 break-all font-mono text-xs text-slate-600">
                                    {
                                        requestId
                                    }
                                </p>
                            </div>
                        ) : null}

                        {/* Actions */}
                        <div className="mt-8 flex w-full flex-col gap-3 sm:flex-row sm:justify-center">
                            {onRetry ? (
                                <button
                                    type="button"
                                    onClick={
                                        onRetry
                                    }
                                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
                                >
                                    <ArrowCounterClockwiseIcon
                                        size={
                                            17
                                        }
                                    />

                                    Try again
                                </button>
                            ) : null}

                            {onBack ? (
                                <button
                                    type="button"
                                    onClick={
                                        onBack
                                    }
                                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                                >
                                    <ArrowLeftIcon
                                        size={
                                            17
                                        }
                                    />

                                    Back
                                </button>
                            ) : null}

                            {!onRetry &&
                            !onBack ? (
                                <button
                                    type="button"
                                    onClick={
                                        handleDefaultAction
                                    }
                                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
                                >
                                    {status ===
                                    401 ? (
                                        "Sign in again"
                                    ) : status ===
                                      404 ? (
                                        "Go to dashboard"
                                    ) : (
                                        content.defaultAction
                                    )}
                                </button>
                            ) : null}
                        </div>
                    </div>
                </div>

                <p className="mt-4 text-center text-[11px] text-slate-400">
                    ARGUS Procurement &
                    Project Management
                </p>
            </div>
        </div>
    );
}