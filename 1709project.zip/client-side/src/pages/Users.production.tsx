import { useCallback, useEffect, useMemo, useState } from "react";
import DataTable, { DataTableColumn } from "../components/DataTable";
import DataCard from "../components/DataCard";
import OffCanvas from "../components/OffCanvas";
import AddMemberForm from "../offcanvas/users/AddMemberForm";
import Avatar from "../components/Avatar";
import Button from "../components/Button";
import { TeamMember } from "../types/user";
import {
    ClockCounterClockwiseIcon,
    LayoutIcon,
    ListIcon,
    MagnifyingGlassIcon,
    MailboxIcon,
    PenNibIcon,
    UserPlusIcon,
} from "@phosphor-icons/react";
import UserLog from "../offcanvas/users/User_log";
import api, { getApiErrorMessage } from "../api/axios";

type ApiRole = {
    id?: string;
    _id?: string;
    key?: string;
    code?: string;
    name?: string;
    userType?: string;
    realm?: string;
    status?: string;
    active?: boolean;
    isSystem?: boolean;
    system?: boolean;
};

type ApiUser = {
    id: string;
    email: string;
    name?: string;
    displayName?: string;
    userType?: "admin" | "vendor";
    role?: ApiRole | string | null;
    roleId?: string | null;
    vendor?: unknown;
    vendorId?: string | null;
    status?: "active" | "inactive";
    lastLoginAt?: string | null;
    createdAt?: string | null;
    updatedAt?: string | null;
};

type UsersListResponse = {
    data?: ApiUser[];
    pagination?: {
        page?: number;
        limit?: number;
        total?: number;
        pages?: number;
    };
    summary?: {
        active?: number;
        inactive?: number;
        total?: number;
    };
};

type RolesResponse = {
    data?: ApiRole[];
};

const ACTIVE_STATUSES = ["All", "Active", "Inactive"] as const;

function toUiStatus(
    status?: string,
): "Active" | "Inactive" {
    return status === "inactive"
        ? "Inactive"
        : "Active";
}

function toBackendStatus(
    status: "Active" | "Inactive",
): "active" | "inactive" {
    return status === "Inactive"
        ? "inactive"
        : "active";
}

function roleName(
    role: ApiRole | string | null | undefined,
): string {
    if (!role) {
        return "Unassigned";
    }

    if (typeof role === "string") {
        return role;
    }

    return (
        role.name ||
        role.key ||
        role.code ||
        "Unassigned"
    );
}

function mapUserToMember(
    user: ApiUser,
): TeamMember {
    return {
        id: user.id,
        name:
            user.displayName ||
            user.name ||
            "",
        email: user.email,
        password: "",
        role: roleName(user.role) as TeamMember["role"],
        hourlyrate: "",
        status: toUiStatus(user.status),
        department: "",
        location: "",
        privileges: [],
    };
}

function mapMemberPayload(
    member: TeamMember,
    roleId: string | null,
) {
    const payload: Record<string, unknown> = {
        email: member.email.trim(),
        displayName: member.name.trim(),
        userType: "admin",
        roleId: roleId || undefined,
        status: toBackendStatus(member.status),
    };

    if (member.password.trim()) {
        payload.password =
            member.password.trim();
    }

    return payload;
}

function StatusPill({
    status,
}: {
    status: "Active" | "Inactive";
}) {
    return (
        <span
            className={`inline-flex rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                status === "Active"
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-red-200 bg-red-50 text-red-600"
            }`}
        >
            {status}
        </span>
    );
}

export default function Users() {
    const [members, setMembers] =
        useState<TeamMember[]>([]);

    const [roles, setRoles] =
        useState<ApiRole[]>([]);

    const [view, setView] =
        useState<"table" | "cards">("table");

    const [search, setSearch] =
        useState("");

    const [roleFilter, setRoleFilter] =
        useState<string>("All");

    const [statusFilter, setStatusFilter] =
        useState<
            (typeof ACTIVE_STATUSES)[number]
        >("All");

    const [loading, setLoading] =
        useState(true);

    const [saving, setSaving] =
        useState(false);

    const [error, setError] =
        useState("");

    const [notice, setNotice] =
        useState("");

    const [isAddOpen, setIsAddOpen] =
        useState(false);

    const [selectedMember, setSelectedMember] =
        useState<TeamMember | null>(null);

    const [activityDrawerOpen, setActivityDrawerOpen] =
        useState(false);

    const [activityMember, setActivityMember] =
        useState<TeamMember | null>(null);

    const loadRoles = useCallback(
        async () => {
            const response =
                await api.get<RolesResponse>(
                    "/settings/roles",
                );

            const list =
                Array.isArray(response.data?.data)
                    ? response.data.data
                    : [];

            setRoles(
                list.filter(
                    (role) =>
                        String(
                            role.status ||
                                "",
                        ).toLowerCase() !==
                            "inactive" &&
                        role.active !== false,
                ),
            );
        },
        [],
    );

    const loadUsers =
        useCallback(
            async () => {
                const response =
                    await api.get(
                        "/users",
                        {
                            params: {
                                page: 1,
                                limit: 100,
                                userType:
                                    "admin",
                            },
                        },
                    );

                const result =
                    (response.data
                        ?.data ||
                        {}) as UsersListResponse;

                const users =
                    Array.isArray(
                        result.data,
                    )
                        ? result.data
                        : [];

                setMembers(
                    users.map(
                        mapUserToMember,
                    ),
                );
            },
            [],
        );

    const loadDirectory =
        useCallback(
            async () => {
                setLoading(true);
                setError("");

                try {
                    await Promise.all([
                        loadRoles(),
                        loadUsers(),
                    ]);
                } catch (err) {
                    setError(
                        getApiErrorMessage(
                            err,
                            "Unable to load users.",
                        ),
                    );
                } finally {
                    setLoading(false);
                }
            },
            [
                loadRoles,
                loadUsers,
            ],
        );

    useEffect(() => {
        void loadDirectory();
    }, [loadDirectory]);

    useEffect(() => {
        if (!notice) {
            return;
        }

        const timer =
            window.setTimeout(
                () => setNotice(""),
                3500,
            );

        return () =>
            window.clearTimeout(
                timer,
            );
    }, [notice]);

    const roleOptions =
        useMemo(
            () =>
                roles
                    .map(
                        (role) =>
                            role.name ||
                            role.key ||
                            role.code ||
                            "",
                    )
                    .filter(Boolean)
                    .sort(
                        (
                            a,
                            b,
                        ) =>
                            a.localeCompare(
                                b,
                            ),
                    ),
            [roles],
        );

    const roleIdByName =
        useMemo(() => {
            const map =
                new Map<
                    string,
                    string
                >();

            roles.forEach(
                (role) => {
                    const id =
                        role.id ||
                        role._id;

                    const name =
                        role.name ||
                        role.key ||
                        role.code;

                    if (
                        id &&
                        name
                    ) {
                        map.set(
                            name,
                            id,
                        );
                    }
                },
            );

            return map;
        }, [roles]);

    const filteredMembers =
        useMemo(() => {
            const query =
                search
                    .trim()
                    .toLowerCase();

            return members.filter(
                (member) => {
                    const matchesSearch =
                        !query ||
                        member.name
                            .toLowerCase()
                            .includes(query) ||
                        member.email
                            .toLowerCase()
                            .includes(query) ||
                        member.role
                            .toLowerCase()
                            .includes(query);

                    const matchesRole =
                        roleFilter === "All" ||
                        member.role ===
                            roleFilter;

                    const matchesStatus =
                        statusFilter ===
                            "All" ||
                        member.status ===
                            statusFilter;

                    return (
                        matchesSearch &&
                        matchesRole &&
                        matchesStatus
                    );
                },
            );
        }, [
            members,
            search,
            roleFilter,
            statusFilter,
        ]);

    const activeCount =
        members.filter(
            (member) =>
                member.status ===
                "Active",
        ).length;

    const handleSaveMember =
        async (
            member: TeamMember,
        ) => {
            setSaving(true);
            setError("");

            try {
                const roleId =
                    roleIdByName.get(
                        member.role,
                    ) || null;

                if (
                    !roleId
                ) {
                    throw new Error(
                        "Please select a valid active role.",
                    );
                }

                const payload =
                    mapMemberPayload(
                        member,
                        roleId,
                    );

                if (
                    selectedMember
                ) {
                    const response =
                        await api.patch(
                            `/users/${encodeURIComponent(
                                member.id,
                            )}`,
                            payload,
                        );

                    const updated =
                        response.data
                            ?.data as ApiUser | undefined;

                    if (updated) {
                        setMembers(
                            (
                                current,
                            ) =>
                                current.map(
                                    (
                                        item,
                                    ) =>
                                        item.id ===
                                        member.id
                                            ? mapUserToMember(
                                                  updated,
                                              )
                                            : item,
                                ),
                        );
                    } else {
                        await loadUsers();
                    }

                    setNotice(
                        "User updated successfully.",
                    );
                } else {
                    const response =
                        await api.post(
                            "/users",
                            {
                                ...payload,
                                password:
                                    member.password.trim(),
                            },
                        );

                    const created =
                        response.data
                            ?.data as ApiUser | undefined;

                    if (created) {
                        setMembers(
                            (
                                current,
                            ) => [
                                mapUserToMember(
                                    created,
                                ),
                                ...current,
                            ],
                        );
                    } else {
                        await loadUsers();
                    }

                    setNotice(
                        "User created successfully.",
                    );
                }

                setSelectedMember(null);
                setIsAddOpen(false);
            } catch (err) {
                setError(
                    getApiErrorMessage(
                        err,
                        "Unable to save the user.",
                    ),
                );
            } finally {
                setSaving(false);
            }
        };

    const handleOpenAdd = () => {
        setSelectedMember(null);
        setIsAddOpen(true);
        setError("");
    };

    const handleOpenEdit = (
        member: TeamMember,
    ) => {
        setSelectedMember(member);
        setIsAddOpen(true);
        setError("");
    };

    const handleCloseForm = () => {
        if (saving) {
            return;
        }

        setSelectedMember(null);
        setIsAddOpen(false);
    };

    const handleOpenActivityLog = (
        member: TeamMember,
    ) => {
        setActivityMember(member);
        setActivityDrawerOpen(true);
    };

    const handleCloseActivityLog = () => {
        setActivityDrawerOpen(false);
        setActivityMember(null);
    };

    const columns: DataTableColumn<TeamMember>[] =
        [
            {
                key: "member",
                label: "Member",
                sortable: true,
                render: (row) => (
                    <div className="flex items-center gap-3">
                        <Avatar
                            name={row.name}
                            size={38}
                        />

                        <div className="min-w-0">
                            <p className="font-bold text-slate-900 group-hover:text-red-600">
                                {row.name}
                            </p>

                            <p className="text-xs text-slate-400">
                                {row.email}
                            </p>
                        </div>
                    </div>
                ),
            },

            {
                key: "role",
                label: "Role",
                sortable: true,
                render: (row) => (
                    <p className="font-bold text-slate-800">
                        {row.role}
                    </p>
                ),
            },

            {
                key: "status",
                label: "Status",
                align: "center",
                render: (row) => (
                    <div className="flex items-center justify-center">
                        <StatusPill
                            status={
                                row.status
                            }
                        />
                    </div>
                ),
            },

            {
                key: "hourlyrate",
                label: "Hourly Rate",
                align: "center",
                render: (row) => (
                    <div className="flex items-center justify-center">
                        <span className="font-semibold text-slate-800">
                            {row.hourlyrate ||
                                "—"}
                        </span>
                    </div>
                ),
            },

            {
                key: "menu",
                label: "Actions",
                align: "right",
                render: (row) => (
                    <div className="flex items-center justify-end gap-1.5">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                handleOpenActivityLog(
                                    row,
                                )
                            }
                            className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                            title="View Log"
                        >
                            <ClockCounterClockwiseIcon
                                size={16}
                            />
                        </Button>

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                handleOpenEdit(
                                    row,
                                )
                            }
                            className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                            title="Edit"
                        >
                            <PenNibIcon
                                size={16}
                            />
                        </Button>
                    </div>
                ),
            },
        ];

    return (
        <>
            <div className="mb-6 flex items-start justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        User Management
                    </h1>

                    <p className="mt-1 text-xs text-slate-400">
                        {loading
                            ? "Loading directory..."
                            : `${members.length} users · ${activeCount} active`}
                    </p>
                </div>

                <div className="flex items-start justify-end gap-2">
                    <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 shadow-sm">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("table")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view ===
                                "table"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <ListIcon size={14} />
                            Table
                        </Button>

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("cards")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view ===
                                "cards"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <LayoutIcon size={14} />
                            Cards
                        </Button>
                    </div>

                    <Button
                        type="button"
                        variant="primary"
                        onClick={handleOpenAdd}
                        className="!px-4 !py-2.5"
                        disabled={
                            loading ||
                            saving
                        }
                    >
                        <UserPlusIcon size={16} />
                        Add Member
                    </Button>
                </div>
            </div>

            {error && (
                <div className="mb-4 flex items-start justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    <span>
                        {error}
                    </span>

                    <button
                        type="button"
                        onClick={() =>
                            setError("")
                        }
                        className="font-bold text-red-500 hover:text-red-700"
                    >
                        ×
                    </button>
                </div>
            )}

            {notice && (
                <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
                    {notice}
                </div>
            )}

            <div className="flex gap-6">
                <aside className="w-64 shrink-0 space-y-4">
                    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                        <span className="mb-2 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Search Directory
                        </span>

                        <div className="relative">
                            <MagnifyingGlassIcon
                                size={15}
                                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                            />

                            <input
                                type="text"
                                value={search}
                                onChange={(event) =>
                                    setSearch(
                                        event.target.value,
                                    )
                                }
                                placeholder="Name or role..."
                                className="w-full rounded-lg border border-slate-200 py-2.5 pl-9 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                            />
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Role
                        </span>

                        <div className="space-y-1">
                            {[
                                "All",
                                ...roleOptions,
                            ].map(
                                (role) => (
                                    <Button
                                        key={role}
                                        type="button"
                                        variant="outline"
                                        onClick={() =>
                                            setRoleFilter(
                                                role,
                                            )
                                        }
                                        className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                            roleFilter ===
                                            role
                                                ? "!bg-transparent !text-red-600"
                                                : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                        }`}
                                    >
                                        {role}

                                        {roleFilter ===
                                            role && (
                                            <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                        )}
                                    </Button>
                                ),
                            )}

                            {!loading &&
                                roleOptions.length ===
                                    0 && (
                                    <p className="px-3 py-2 text-xs text-slate-400">
                                        No active roles found.
                                    </p>
                                )}
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Status
                        </span>

                        <div className="space-y-1">
                            {ACTIVE_STATUSES.map(
                                (status) => (
                                    <Button
                                        key={status}
                                        type="button"
                                        variant="outline"
                                        onClick={() =>
                                            setStatusFilter(
                                                status,
                                            )
                                        }
                                        className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                            statusFilter ===
                                            status
                                                ? "!bg-transparent !text-red-600"
                                                : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                        }`}
                                    >
                                        <span className="flex items-center gap-2">
                                            {status !==
                                                "All" && (
                                                <span
                                                    className={`h-2 w-2 rounded-full ${
                                                        status ===
                                                        "Active"
                                                            ? "bg-emerald-500"
                                                            : "bg-red-500"
                                                    }`}
                                                />
                                            )}

                                            {status}
                                        </span>

                                        {statusFilter ===
                                            status && (
                                            <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                        )}
                                    </Button>
                                ),
                            )}
                        </div>
                    </div>
                </aside>

                <main className="min-w-0 flex-1 space-y-4">
                    {loading ? (
                        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-400 shadow-sm">
                            Loading users...
                        </div>
                    ) : filteredMembers.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm">
                            <p className="text-sm font-semibold text-slate-700">
                                No users found
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Try another search or filter.
                            </p>
                        </div>
                    ) : view === "table" ? (
                        <DataTable
                            columns={
                                columns
                            }
                            data={
                                filteredMembers
                            }
                            rowKey={(
                                row,
                            ) =>
                                row.id
                            }
                        />
                    ) : (
                        <div className="grid grid-cols-1 items-stretch gap-5 sm:grid-cols-2 xl:grid-cols-2">
                            {filteredMembers.map(
                                (
                                    member,
                                ) => (
                                    <div
                                        key={
                                            member.id
                                        }
                                        className="flex min-w-0"
                                    >
                                        <DataCard
                                            className="w-full min-w-0"
                                            title={
                                                member.name
                                            }
                                            subtitle={
                                                member.role
                                            }
                                            avatar={
                                                <Avatar
                                                    name={
                                                        member.name
                                                    }
                                                    size={
                                                        48
                                                    }
                                                    online={
                                                        member.status ===
                                                        "Active"
                                                    }
                                                />
                                            }
                                            badge={{
                                                text:
                                                    member.status,
                                                color:
                                                    member.status ===
                                                    "Active"
                                                        ? "green"
                                                        : "red",
                                                position:
                                                    "top-right",
                                            }}
                                            actions={[
                                                {
                                                    id: "log",
                                                    label: (
                                                        <ClockCounterClockwiseIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenActivityLog(
                                                                member,
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                                {
                                                    id: "edit",
                                                    label: (
                                                        <PenNibIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenEdit(
                                                                member,
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                            ]}
                                            fields={[
                                                {
                                                    label: "Email",
                                                    fullWidth: true,
                                                    value: (
                                                        <div className="flex w-full min-w-0 items-start gap-2">
                                                            <MailboxIcon
                                                                size={
                                                                    13
                                                                }
                                                                className="mt-0.5 shrink-0 text-slate-400"
                                                            />

                                                            <span className="min-w-0 flex-1 break-all text-xs font-semibold leading-5 text-slate-600">
                                                                {
                                                                    member.email
                                                                }
                                                            </span>
                                                        </div>
                                                    ),
                                                },
                                            ]}
                                        />
                                    </div>
                                ),
                            )}
                        </div>
                    )}
                </main>
            </div>

            <UserLog
                open={
                    activityDrawerOpen
                }
                user={
                    activityMember
                }
                onClose={
                    handleCloseActivityLog
                }
            />

            <OffCanvas
                isOpen={
                    isAddOpen
                }
                onClose={
                    handleCloseForm
                }
                title={
                    selectedMember
                        ? "Edit User"
                        : "Add User"
                }
                subtitle={
                    selectedMember
                        ? "Update user details and access"
                        : "Invite a user and configure their access"
                }
            >
                <AddMemberForm
                    member={
                        selectedMember
                    }
                    onSubmit={
                        handleSaveMember
                    }
                    onCancel={
                        handleCloseForm
                    }
                />
            </OffCanvas>
        </>
    );
}
