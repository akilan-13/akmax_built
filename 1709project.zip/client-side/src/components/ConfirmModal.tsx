import {
    TrashIcon,
    XIcon,
} from "@phosphor-icons/react";
import { ReactNode } from "react";
import Button from "./Button";

interface ConfirmModalProps {
    open: boolean;
    title?: string;
    message?: string;
    confirmText?: string;
    cancelText?: string;
    onConfirm: () => void;
    onCancel: () => void;
    loading?: boolean;
    children?: ReactNode;
}

export default function ConfirmModal({
    open,
    title = "Confirm Delete",
    message = "Are you sure you want to delete this item?",
    confirmText = "Delete",
    cancelText = "Cancel",
    onConfirm,
    onCancel,
    loading = false,
    children,
}: ConfirmModalProps) {
    if (!open) {
        return null;
    }

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center px-4">
            {/* Overlay */}
            <div
                className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
                onClick={loading ? undefined : onCancel}
            />

            {/* Modal */}
            <div className="relative z-10 w-full max-w-md rounded-2xl bg-white shadow-2xl">
                {/* Header */}
                <div className="flex items-start justify-between border-b border-slate-100 px-6 py-5">
                    <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                            <TrashIcon
                                size={20}
                                weight="duotone"
                            />
                        </div>

                        <div>
                            <h3 className="text-base font-bold text-slate-900">
                                {title}
                            </h3>

                            <p className="mt-1 text-sm text-slate-500">
                                {message}
                            </p>
                        </div>
                    </div>

                </div>

                {/* Optional Content */}
                {children && (
                    <div className="px-6 py-4">
                        {children}
                    </div>
                )}

                {/* Footer */}
                <div className="flex justify-end gap-3 border-t border-slate-100 px-6 py-4">
                    <Button
                        variant="outline"
                        onClick={onCancel}
                        disabled={loading}
                    >
                        {cancelText}
                    </Button>

                    <Button
                        variant="danger"
                        onClick={onConfirm}
                        disabled={loading}
                    >
                        {loading ? (
                            <>
                                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                                Deleting...
                            </>
                        ) : (
                            <>
                                <TrashIcon size={16} />
                                {confirmText}
                            </>
                        )}
                    </Button>
                </div>
            </div>
        </div>
    );
}