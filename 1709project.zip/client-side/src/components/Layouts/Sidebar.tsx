import PerfectScrollbar from 'react-perfect-scrollbar';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { NavLink, useLocation } from 'react-router-dom';
import { toggleSidebar } from '../../store/themeConfigSlice';
import { IRootState } from '../../store';
import { useEffect } from 'react';
import { BuildingOfficeIcon, CaretDoubleLeftIcon, ClipboardTextIcon, CurrencyCircleDollarIcon, FileTextIcon, FolderIcon, GearSixIcon, HouseSimpleIcon, ListChecksIcon, TrendUpIcon, UsersIcon } from '@phosphor-icons/react';
import { favIcon } from '../../assets/image';

interface MenuItem {
    label: string;
    icon: React.ElementType;
    url: string;
    matchPaths?: string[];
}

const Sidebar = () => {
    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const semidark = useSelector((state: IRootState) => state.themeConfig.semidark);
    const location = useLocation();
    const dispatch = useDispatch();
    const { t } = useTranslation();

    const menuItems: MenuItem[] = [
        { label: 'Admin Dashboard', icon: HouseSimpleIcon, url: '/admin_dashboard' },
        { label: 'Vendor Dashboard', icon: HouseSimpleIcon, url: '/vendor_dashboard' },
        { label: 'Vendors', icon: BuildingOfficeIcon, url: '/vendor' },
        { label: 'Quotation', icon: FileTextIcon, url: '/quotation' },
        { label: 'Projects', icon: FolderIcon, url: '/projects' },
        { label: 'Invoices', icon: CurrencyCircleDollarIcon, url: '/invoices' },
        { label: 'My Tasks', icon: ListChecksIcon, url: '/tasks' },
        { label: 'Survey Report',icon: ClipboardTextIcon,url: '/survey_report',},
        { label: 'User Management', icon: UsersIcon, url: '/user_management' },
        { label: 'Master Rate Schedule', icon: TrendUpIcon, url: '/master_rate_schedule' },
        {
            label: 'Settings',
            icon: GearSixIcon,
            url: '/settings/general_settings',
            matchPaths: ['/settings/general_settings',
                '/settings/roles_permissions',
                '/settings/api_configuration',
                '/settings/vendors',
                '/settings/common_setting',
                '/settings/master_rate'
            ],
        },
    ];

    const isItemActive = (item: MenuItem) => {
        const candidates = item.matchPaths?.length ? item.matchPaths : [item.url];
        return candidates.some((path) => location.pathname === path || location.pathname.startsWith(`${path}/`));
    };

    useEffect(() => {
        if (window.innerWidth < 1024 && themeConfig.sidebar) {
            dispatch(toggleSidebar());
        }
    }, [location]);

    return (
        <div className={semidark ? 'dark' : ''}>
            <nav
                className={`sidebar fixed min-h-screen h-full top-0 bottom-0 w-[260px] shadow-[5px_0_25px_0_rgba(94,92,154,0.1)] z-50 transition-all duration-300 ${semidark ? 'text-white-dark' : ''}`}
            >
                <div className="bg-secondary dark:bg-black h-full">
                    <div className="flex justify-between items-center px-4 py-3">
                        <NavLink to="/" className="main-logo flex items-center shrink-0 bg-white rounded-xl px-4 py-1">
                            <img className="w-8 ml-[5px] flex-none " src={favIcon} alt="logo" />
                            <span className="text-2xl ltr:ml-1.5 rtl:mr-1.5 font-bold align-middle text-primary lg:inline dark:text-white-light">{t('ARGUS')}</span>
                        </NavLink>

                        <button
                            type="button"
                            className="collapse-icon w-5 h-5 text-white rounded-full flex items-center hover:bg-gray-500/10 dark:hover:bg-dark-light/10 dark:text-white-light transition duration-300 rtl:rotate-180"
                            onClick={() => dispatch(toggleSidebar())}
                        >
                            <CaretDoubleLeftIcon size={20} className="m-auto" />
                        </button>
                    </div>
                    <PerfectScrollbar className="h-[calc(100vh-80px)] relative">
                        <ul className="relative font-semibold space-y-0.5 p-4 py-0">
                            {menuItems.map((item) => {
                                const { label, icon: Icon, url } = item;
                                const active = isItemActive(item);
                                return (
                                    <li className="nav-item" key={url}>
                                        <NavLink to={url} className={`nav-link group w-full ${active ? 'active' : ''}`}>
                                            <div className="flex items-center">
                                                <Icon className="group-hover:!text-white shrink-0" />
                                                <span className="ltr:pl-3 rtl:pr-3 text-slate-400 group-hover:text-white dark:text-[#506690] dark:group-hover:text-white-dark">
                                                    {label}
                                                </span>
                                            </div>
                                        </NavLink>
                                    </li>
                                );
                            })}
                        </ul>
                    </PerfectScrollbar>
                </div>
            </nav>
        </div>
    );
};

export default Sidebar;
