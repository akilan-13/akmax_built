import { NavLink, Outlet } from "react-router-dom";
import {
    TagIcon,
    CurrencyDollarIcon,
    CreditCardIcon,
    CalendarBlankIcon,
    FactoryIcon,
    CheckCircleIcon,
} from "@phosphor-icons/react";

interface VendorSettingNavItem {
    label: string;
    path: string;
    icon: React.ElementType;
}

const VENDOR_SETTING_NAV_ITEMS: VendorSettingNavItem[] = [
    {label: "Vendor Category", path: "/settings/vendors/vendor_category", icon: TagIcon, },
    {label: "Currency Format", path: "/settings/vendors/currency_format", icon: CurrencyDollarIcon,},
    {label: "Payment Terms", path: "/settings/vendors/payment_terms", icon: CreditCardIcon,},
    // {label: "Quotation Validity Period",path: "/settings/vendor_settings/validity_period",icon: CalendarBlankIcon,},
    {label: "Industry Sector",path: "/settings/vendors/industry_sector",icon: FactoryIcon,},
    {label: "Status",path: "/settings/vendors/status",icon: CheckCircleIcon,},
];

export default function VendorSettings() {
    return (
        <div className="min-w-0">
            {/* Page Header */}
            <div className="mb-5">
                <h1 className="text-2xl font-bold text-slate-900">
                    Vendor Settings
                </h1>

                <p className="mt-1 text-sm text-slate-500">
                    Configure vendor categories, currencies, payment
                    terms, validity periods and industry sectors.
                </p>
            </div>

            {/* Vendor Settings Panel */}
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                {/* Navigation */}
                <div className="border-b border-slate-200">
                    <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-transparent">
                        <nav
                            className="flex min-w-max items-center gap-1 px-4 py-3"
                            aria-label="Vendor settings navigation"
                        >
                            {VENDOR_SETTING_NAV_ITEMS.map(
                                ({ label, path, icon: Icon }) => (
                                    <NavLink
                                        key={path}
                                        to={path}
                                        className={({ isActive }) =>
                                            ["group flex shrink-0 items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all",
                                                isActive ? "bg-red-600 text-white shadow-sm shadow-red-600/20"  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900",
                                            ].join(" ")}>
                                        {({ isActive }) => (
                                            <>
                                                <Icon size={17} weight={isActive ? "fill" : "duotone"}/>
                                                <span>{label}</span>
                                            </>
                                        )}
                                    </NavLink>
                                )
                            )}
                        </nav>
                    </div>
                </div>

                {/* Child Page Content */}
                <main className="min-w-0 p-6 md:p-5">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
