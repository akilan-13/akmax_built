import { useMemo, useState } from 'react';


import type {
  
    TaskPriority,
    TaskStatus,
} from './List';
import IconSearch from '../Icon/IconSearch';
import IconRefresh from '../Icon/IconRefresh';
import IconPencil from '../Icon/IconPencil';
import { Trash } from '@phosphor-icons/react/dist/ssr';
import IconCalendar from '../Icon/IconCalendar';
import { Task } from '../../offcanvas/mytask/edit';

interface KanbanProps {
    tasks: Task[];
    onUpdateTask: (task: Task) => void;
    onEditTask: (task: Task) => void;
    onDeleteTask: (id: number) => void;
    onOpenTask: (task: Task) => void;
}

const Kanban = ({
    tasks,
    onUpdateTask,
    onEditTask,
    onDeleteTask,
    onOpenTask,
}: KanbanProps) => {
    const columns: TaskStatus[] = [
        'Pending',
        'In Progress',
        'On Hold',
        'Due Date',
        'Completed',
    ];

    const [search, setSearch] = useState('');

    const [statusFilter, setStatusFilter] =
        useState<'All' | TaskStatus>('All');

    const [priorityFilter, setPriorityFilter] =
        useState<'All' | TaskPriority>('All');

    const [draggedTaskId, setDraggedTaskId] =
        useState<number | null>(null);

    const [dragOverColumn, setDragOverColumn] =
        useState<TaskStatus | null>(null);

    const filteredTasks = useMemo(() => {
        return tasks.filter((task) => {
            const searchText = search
                .trim()
                .toLowerCase();

            const matchesSearch =
                task.title
                    .toLowerCase()
                    .includes(searchText) ||
                task.description
                    .toLowerCase()
                    .includes(searchText) ||
                task.project
                    .toLowerCase()
                    .includes(searchText) ||
               task.Assignstaff.some((staff) =>
                    staff.name.toLowerCase().includes(searchText)
                );

            const matchesStatus =
                statusFilter === 'All' ||
                task.status === statusFilter;

            const matchesPriority =
                priorityFilter === 'All' ||
                task.priority === priorityFilter;

            return (
                matchesSearch &&
                matchesStatus &&
                matchesPriority
            );
        });
    }, [
        tasks,
        search,
        statusFilter,
        priorityFilter,
    ]);

    const moveTask = (
        task: Task,
        newStatus: TaskStatus
    ) => {
        let newProgress = task.progress;

        if (newStatus === 'Completed') {
            newProgress = 100;
        } else if (
            newStatus === 'Pending' &&
            task.progress === 100
        ) {
            newProgress = 0;
        } else if (
            newStatus === 'In Progress' &&
            task.progress === 0
        ) {
            newProgress = 10;
        }

        onUpdateTask({
            ...task,
            status: newStatus,
            progress: newProgress,
        });
    };

    const canDragTask = (task: Task) => {
        return (
            task.status === 'Pending' ||
            task.status === 'In Progress'
        );
    };

    const handleDragStart = (
        e: React.DragEvent<HTMLDivElement>,
        task: Task
    ) => {
        if (!canDragTask(task)) {
            e.preventDefault();
            return;
        }

        setDraggedTaskId(task.id);

        e.dataTransfer.effectAllowed = 'move';

        e.dataTransfer.setData(
            'text/plain',
            String(task.id)
        );
    };

    const handleDragEnd = () => {
        setDraggedTaskId(null);
        setDragOverColumn(null);
    };

    const handleDragOver = (
        e: React.DragEvent<HTMLDivElement>,
        status: TaskStatus
    ) => {
        e.preventDefault();

        e.dataTransfer.dropEffect = 'move';

        setDragOverColumn(status);
    };

    const handleDragLeave = (
        e: React.DragEvent<HTMLDivElement>
    ) => {
        if (
            !e.currentTarget.contains(
                e.relatedTarget as Node
            )
        ) {
            setDragOverColumn(null);
        }
    };

    const handleDrop = (
        e: React.DragEvent<HTMLDivElement>,
        newStatus: TaskStatus
    ) => {
        e.preventDefault();

        const taskId = Number(
            e.dataTransfer.getData('text/plain')
        );

        const task = tasks.find(
            (item) => item.id === taskId
        );

        if (!task) {
            handleDragEnd();
            return;
        }

        if (!canDragTask(task)) {
            handleDragEnd();
            return;
        }

        if (task.status !== newStatus) {
            moveTask(task, newStatus);
        }

        handleDragEnd();
    };

    const handleRefresh = () => {
        setSearch('');
        setStatusFilter('All');
        setPriorityFilter('All');
        setDraggedTaskId(null);
        setDragOverColumn(null);
    };

    const priorityClass = (
        priority: TaskPriority
    ) => {
        switch (priority) {
            case 'Urgent':
                return 'bg-red-100 text-red-700';

            case 'High':
                return 'bg-orange-100 text-orange-700';

            case 'Medium':
                return 'bg-yellow-100 text-yellow-700';

            default:
                return 'bg-green-100 text-green-700';
        }
    };

    const columnClass = (
        status: TaskStatus
    ) => {
        switch (status) {
            case 'Pending':
                return 'border-slate-200 bg-slate-50';

            case 'In Progress':
                return 'border-blue-200 bg-blue-50/40';

            case 'On Hold':
                return 'border-orange-200 bg-orange-50/40';

            case 'Due Date':
                return 'border-red-200 bg-red-50/40';

            case 'Completed':
                return 'border-green-200 bg-green-50/40';

            default:
                return 'border-slate-200 bg-slate-50';
        }
    };

    const headerClass = (
        status: TaskStatus
    ) => {
        switch (status) {
            case 'Pending':
                return 'bg-slate-100 text-slate-700';

            case 'In Progress':
                return 'bg-blue-100 text-blue-700';

            case 'On Hold':
                return 'bg-orange-100 text-orange-700';

            case 'Due Date':
                return 'bg-red-100 text-red-700';

            case 'Completed':
                return 'bg-green-100 text-green-700';

            default:
                return 'bg-slate-100 text-slate-700';
        }
    };

    const formatDate = (date: string) => {
        if (!date) {
            return '-';
        }

        return new Date(
            `${date}T00:00:00`
        ).toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
        });
    };

    return (
        <div className="w-full">
            <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                <div className="flex flex-col gap-3 xl:flex-row">
                    <div className="relative flex-1">
                        <IconSearch
                            
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                        />

                        <input
                            type="text"
                            value={search}
                            onChange={(e) =>
                                setSearch(
                                    e.target.value
                                )
                            }
                            placeholder="Search tasks, projects or team members..."
                            className="w-full rounded-lg border border-slate-200 py-2.5 pl-10 pr-4 text-sm outline-none focus:border-primary"
                        />
                    </div>

                    <select
                        value={statusFilter}
                        onChange={(e) =>
                            setStatusFilter(
                                e.target.value as
                                    | 'All'
                                    | TaskStatus
                            )
                        }
                        className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary"
                    >
                        <option value="All">
                            All Status
                        </option>

                        <option value="Pending">
                            Pending
                        </option>

                        <option value="In Progress">
                            In Progress
                        </option>

                        <option value="On Hold">
                            On Hold
                        </option>

                        <option value="Due Date">
                            Due Date
                        </option>

                        <option value="Completed">
                            Completed
                        </option>
                    </select>

                    <select
                        value={priorityFilter}
                        onChange={(e) =>
                            setPriorityFilter(
                                e.target.value as
                                    | 'All'
                                    | TaskPriority
                            )
                        }
                        className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary"
                    >
                        <option value="All">
                            All Priority
                        </option>

                        <option value="Urgent">
                            Urgent
                        </option>

                        <option value="High">
                            High
                        </option>

                        <option value="Medium">
                            Medium
                        </option>

                        <option value="Low">
                            Low
                        </option>
                    </select>

                    <button
                        type="button"
                        onClick={handleRefresh}
                        className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50"
                    >
                        <IconRefresh  />
                        Refresh
                    </button>
                </div>
            </div>

            <div className="w-full overflow-x-auto pb-4">
                <div className="grid min-w-[1500px] grid-cols-5 gap-4">
                    {columns.map((status) => {
                        const columnTasks =
                            filteredTasks.filter(
                                (task) =>
                                    task.status ===
                                    status
                            );

                        const isDragOver =
                            dragOverColumn === status;

                        return (
                            <div
                                key={status}
                                onDragOver={(e) =>
                                    handleDragOver(
                                        e,
                                        status
                                    )
                                }
                                onDragLeave={
                                    handleDragLeave
                                }
                                onDrop={(e) =>
                                    handleDrop(
                                        e,
                                        status
                                    )
                                }
                                className={`flex h-[680px] min-h-0 flex-col overflow-hidden rounded-xl border transition-all ${columnClass(
                                    status
                                )} ${
                                    isDragOver
                                        ? 'border-primary bg-primary/10 ring-2 ring-primary/20'
                                        : ''
                                }`}
                            >
                                <div
                                    className={`flex shrink-0 items-center justify-between rounded-t-xl px-4 py-4 ${headerClass(
                                        status
                                    )}`}
                                >
                                    <div>
                                        <h3 className="font-bold">
                                            {status}
                                        </h3>

                                        <p className="mt-0.5 text-xs opacity-70">
                                            {
                                                columnTasks.length
                                            }{' '}
                                            {columnTasks.length ===
                                            1
                                                ? 'Task'
                                                : 'Tasks'}
                                        </p>
                                    </div>

                                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-sm font-bold shadow-sm">
                                        {
                                            columnTasks.length
                                        }
                                    </span>
                                </div>

                                <div className="min-h-0 flex-1 overflow-y-scroll p-3">
                                    <div className="space-y-3">
                                        {columnTasks.length ===
                                        0 ? (
                                            <div
                                                className={`flex min-h-[150px] items-center justify-center rounded-lg border border-dashed p-8 text-center text-sm transition ${
                                                    isDragOver
                                                        ? 'border-primary bg-white text-primary'
                                                        : 'border-slate-300 bg-white/70 text-slate-400'
                                                }`}
                                            >
                                                {isDragOver
                                                    ? 'Drop task here'
                                                    : 'No tasks'}
                                            </div>
                                        ) : (
                                            <>
                                                {columnTasks.map(
                                                    (
                                                        task
                                                    ) => (
                                                        <TaskCard
                                                            key={
                                                                task.id
                                                            }
                                                            task={
                                                                task
                                                            }
                                                            priorityClass={priorityClass(
                                                                task.priority
                                                            )}
                                                            formatDate={
                                                                formatDate
                                                            }
                                                            onEdit={() =>
                                                                onEditTask(
                                                                    task
                                                                )
                                                            }
                                                            onDelete={() =>
                                                                onDeleteTask(
                                                                    task.id
                                                                )
                                                            }
                                                            onOpen={() =>
                                                                onOpenTask(
                                                                    task
                                                                )
                                                            }
                                                            onDragStart={(
                                                                e
                                                            ) =>
                                                                handleDragStart(
                                                                    e,
                                                                    task
                                                                )
                                                            }
                                                            onDragEnd={
                                                                handleDragEnd
                                                            }
                                                            isDragging={
                                                                draggedTaskId ===
                                                                task.id
                                                            }
                                                            canDrag={canDragTask(
                                                                task
                                                            )}
                                                        />
                                                    )
                                                )}

                                                {isDragOver && (
                                                    <div className="flex min-h-[100px] items-center justify-center rounded-lg border-2 border-dashed border-primary bg-primary/5 text-sm font-medium text-primary">
                                                        Drop task here
                                                    </div>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

interface TaskCardProps {
    task: Task;
    priorityClass: string;
    formatDate: (date: string) => string;
    onEdit: () => void;
    onDelete: () => void;
    onOpen: () => void;
    onDragStart: (
        e: React.DragEvent<HTMLDivElement>
    ) => void;
    onDragEnd: () => void;
    isDragging: boolean;
    canDrag: boolean;
}

const TaskCard = ({
    task,
    priorityClass,
    formatDate,
    onEdit,
    onDelete,
    onOpen,
    onDragStart,
    onDragEnd,
    isDragging,
    canDrag,
}: TaskCardProps) => {
    return (
        <div
            draggable={canDrag}
            onClick={onOpen}
            onDragStart={
                canDrag ? onDragStart : undefined
            }
            onDragEnd={
                canDrag ? onDragEnd : undefined
            }
            className={`rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-all ${
                canDrag
                    ? 'cursor-grab hover:-translate-y-0.5 hover:shadow-md active:cursor-grabbing'
                    : 'cursor-default'
            } ${
                isDragging
                    ? 'scale-[0.98] opacity-50'
                    : ''
            }`}
        >
            <div className="flex items-start justify-between gap-2">
                <h4 className="text-sm font-bold leading-5 text-slate-800">
                    {task.title}
                </h4>

                <div
                    className="flex items-center gap-1"
                    onMouseDown={(e) =>
                        e.stopPropagation()
                    }
                    onClick={(e) =>
                        e.stopPropagation()
                    }
                >
                    <button
                        type="button"
                        onClick={onEdit}
                        title="Edit"
                        className="rounded-md p-1.5 text-blue-600 hover:bg-blue-50"
                    >
                        <IconPencil  />
                    </button>

                    <button
                        type="button"
                        onClick={onDelete}
                        title="Delete"
                        className="rounded-md p-1.5 text-red-600 hover:bg-red-50"
                    >
                        <Trash size={15} />
                    </button>
                </div>
            </div>

            <p className="mt-2 line-clamp-2 text-xs leading-5 text-slate-500">
                {task.description}
            </p>

            <button
                type="button"
                onClick={(e) => {
                    e.stopPropagation();
                    onOpen();
                }}
                onMouseDown={(e) =>
                    e.stopPropagation()
                }
                className="mt-3 w-full rounded-lg text-left transition hover:bg-slate-50"
            >
                <div className="grid grid-cols-2 gap-2 px-1 py-1">
                    <div className="min-w-0">
                        <p className="text-[11px] uppercase tracking-wide text-slate-400">
                            Project
                        </p>

                        <p className="mt-1 truncate text-xs font-semibold text-slate-700 hover:text-primary">
                            {task.project}
                        </p>
                    </div>

                    <div className="min-w-0">
                        <p className="text-[11px] uppercase tracking-wide text-slate-400">
                            Phase
                        </p>

                        <p className="mt-1 truncate text-xs font-medium text-slate-600">
                            {task.phase}
                        </p>
                    </div>
                </div>
            </button>

            <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="min-w-0">
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">
                        Assign Staff
                    </p>

                    <p className="mt-1 truncate text-xs font-medium text-slate-600">
                        {task.Assignstaff.length > 0
                            ? task.Assignstaff.join(', ')
                            : 'Not assigned'}
                    </p>
                </div>

                <div className="min-w-0">
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">
                        Priority
                    </p>

                    <div className="mt-1">
                        <span
                            className={`inline-flex whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-semibold ${priorityClass}`}
                        >
                            {task.priority}
                        </span>
                    </div>
                </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2">
                <div>
                    <p className="text-[11px] text-slate-400">
                        Start Date
                    </p>

                    <p className="mt-1 flex items-center gap-1 text-xs font-medium text-slate-600">
                        <IconCalendar  />

                        {formatDate(
                            task.startDate
                        )}
                    </p>
                </div>

                <div>
                    <p className="text-[11px] text-slate-400">
                        Due Date
                    </p>

                    <p className="mt-1 flex items-center gap-1 text-xs font-medium text-slate-600">
                        <IconCalendar  />

                        {formatDate(
                            task.dueDate
                        )}
                    </p>
                </div>
            </div>

            <div className="mt-4">
                <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-500">
                        Progress
                    </span>

                    <span className="text-xs font-bold text-slate-700">
                        {task.progress}%
                    </span>
                </div>

                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                    <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{
                            width: `${Math.min(
                                100,
                                Math.max(
                                    0,
                                    task.progress
                                )
                            )}%`,
                        }}
                    />
                </div>
            </div>
        </div>
    );
};

export default Kanban;
