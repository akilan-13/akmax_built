import {
    ArrowLeftIcon,
    UserIcon,
    BuildingsIcon,
    UserCircleIcon,
    EnvelopeSimpleIcon,
    CheckIcon,
    TrashIcon,
    PencilSimpleIcon,
    XIcon,
    PencilSimple,
    CaretDownIcon,
    CaretRightIcon,
    CaretLeftIcon,
    CaretRight,
    PlusIcon,
    FloppyDiskIcon,
} from '@phosphor-icons/react';
import Select, { SingleValue, StylesConfig } from 'react-select';
import { useNavigate, useOutletContext, useParams } from 'react-router-dom';
import { Fragment, useState } from 'react';
import { ProjectsContextType } from './project';
import ADDTASK, { AddTaskForm } from '../../offcanvas/project/addtask';
import Edit, { Task } from '../../offcanvas/mytask/edit';
import ProjectFinancialSummary from './ProjectFinancialSummary';

type ProjectTab = 'Project Overview' | 'Project Scope' | 'Project Task' | 'Financial Summary';

interface StatusOption {
    value: 'Planned' | 'In Progress' | 'On Hold' | 'Completed' | 'Closed';
    label: string;
}

interface Deliverable {
    id: string;
    projectId: string;
    name: string;
    dueDate: string;
    completed: boolean;
}

interface ScopeItem {
    id: string;
    text: string;
    completed?: boolean;
}

interface Phase {
    id: string;
    name: string;
    description: string;
    estimatedHours: number;
    tasks: PhaseTask[];
}

type TaskStatus = 'Pending' | 'In Progress' | 'On Hold' | 'Due Date' | 'Completed';

type ProjectTaskStatus = 'active' | 'pending' | 'inprogress' | 'onhold' | 'completed';
type ScopeType = 'inScope' | 'outOfScope';


export interface AssignedStaff {
    name: string;
    rate: number;
    hours: number;
    amount: number;
}
type PhaseTask = {
    id: string;
    title: string;
    name: string;
    description: string;
    estimatedHours: number;
    actualHours?: number;       // new — hours actually logged
    hourlyRate?: number;        // new — per-task rate override
    materialCost?: number;      // new
    otherExpenses?: number;     // new

    status: TaskStatus;
    project: string; 
    phase: string;
    assignStaff: string;
    startDate: string;
    dueDate: string;
    priority: TaskPriority;
    progress: string;
    Task: string;
    Assignstaff: AssignedStaff[];
    rate:AssignedStaff[];
};

const STATUS_OPTIONS: StatusOption[] = [
    {
        value: 'Planned',
        label: 'Planned',
    },
    {
        value: 'In Progress',
        label: 'In Progress',
    },
    {
        value: 'On Hold',
        label: 'On Hold',
    },
    {
        value: 'Completed',
        label: 'Completed',
    },
    {
        value: 'Closed',
        label: 'Closed',
    },
];

interface ProjectTask {
    id: string;
    title: string;
    name: string;
    description: string;
    assignedTo: string;
    startDate: string;
    endDate: string;
    duration: number;
    priority: 'low' | 'medium' | 'high' | 'urgent';
    status: ProjectTaskStatus;
    project?: string;
    phase?: string;
    Assignstaff?: AssignedStaff[];
    progress?: number;
}

type TaskPriority = 'Low' | 'Medium' | 'High' | 'Urgent';

interface Project {
    id: string;
    projectName: string;
    name: string;
    status: string;
    managerName: string;
    managerEmail: string;
    progress: number;
    projectValue: number;
    budget: number;
    contractor: string;
    surveyRef: string;
    startDate: string;
    endDate: string;
    version: string;
    versionDate: string;
    location: string;
    vendorName: string;
}

interface ActivityLog {
    id: string;
    projectId: string;
    entity: string;
    entityId: string;
    action: 'ADD' | 'MODIFY' | 'DELETE';
    description: string;
    createdAt: Date;
}

// ProjectTask.status and PhaseTask.status (TaskStatus) use two different
// string-literal vocabularies for the same underlying concept. These lookup
// tables convert safely between the two instead of relying on `as` casts,
// which previously allowed a value from one enum to silently be treated as a
// value from the other.
const PROJECT_TO_PHASE_STATUS: Record<ProjectTask['status'], TaskStatus> = {
    pending: 'Pending',
    inprogress: 'In Progress',
    onhold: 'On Hold',
    completed: 'Completed',
    active: 'Pending',
};

const PHASE_TO_PROJECT_STATUS: Record<TaskStatus, ProjectTask['status']> = {
    Pending: 'pending',
    'In Progress': 'inprogress',
    'On Hold': 'onhold',
    'Due Date': 'pending',
    Completed: 'completed',
};

type ModuleItem = {
    id: number;
    name: string;
    rate: number;
};
type ProjectInstallment = {
    id: number;
    name: string;
    days: number;
    dueDate: string;
    netTotalAmount: number;
    status: 'Paid' | 'Pending';
    moduleItems: ModuleItem[];
};

const INSTALLMENTS: ProjectInstallment[] = [
    {
        id: 1,
        name: 'Installment 1',
        days: 15,
        dueDate: '15 Sep 2026',
        netTotalAmount: 12500,
        status: 'Paid',
        moduleItems: [
            {
                id: 101,
                name: 'Pole Installation',
                rate: 5000,
            },
            {
                id: 102,
                name: 'Fiber Splicing',
                rate: 3500,
            },
            {
                id: 103,
                name: 'Fiber Cable Installation',
                rate: 4000,
            },
        ],
    },
    {
        id: 2,
        name: 'Installment 2',
        days: 20,
        dueDate: '05 Oct 2026',
        netTotalAmount: 15800,
        status: 'Pending',
        moduleItems: [
            {
                id: 201,
                name: 'Pole Installation',
                rate: 6200,
            },
            {
                id: 202,
                name: 'Fiber Splicing',
                rate: 4200,
            },
            {
                id: 203,
                name: 'Fiber Cable Installation',
                rate: 5400,
            },
        ],
    },
];

export default function ProjectOverview() {
    const navigate = useNavigate();
    const { projectId } = useParams<{ projectId: string }>();

    const { projects, updateProject, activityLogs, addActivityLog } = useOutletContext<ProjectsContextType>();
    const [taskView, setTaskView] = useState<'tree' | 'timeline' | 'board'>('tree');

    const [deliverables, setDeliverables] = useState<Deliverable[]>([]);
    const [showDeliverableModal, setShowDeliverableModal] = useState(false);
    const [deliverableName, setDeliverableName] = useState('');
    const [deliverableDueDate, setDeliverableDueDate] = useState('');
    const [scopeType, setScopeType] = useState<ScopeType>('inScope');
    const [showScopeForm, setShowScopeForm] = useState(false);

    const [editingScopeId, setEditingScopeId] = useState<string | null>(null);
    const [editingScopeType, setEditingScopeType] = useState<ScopeType | null>(null);
    const [showManagerProfile, setShowManagerProfile] = useState(false);

    const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({});
    const [expandedPhases, setExpandedPhases] = useState<Record<string, boolean>>({ 'phase-1': true });

    const [selectedPhaseId, setSelectedPhaseId] = useState<string | null>(null);
    const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);
    const [scopeText, setScopeText] = useState('');

    const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
    const [dragOverStatus, setDragOverStatus] = useState<ProjectTask['status'] | null>(null);

    const [isEditTaskOpen, setIsEditTaskOpen] = useState(false);
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);

    const [currentMonth, setCurrentMonth] = useState(new Date());
    const [expandedInstallments, setExpandedInstallments] = useState<number[]>([INSTALLMENTS[0].id]);

    const [installments, setInstallments] = useState(INSTALLMENTS);



    const [showAddTaskModal, setShowAddTaskModal] =
        useState(false);


    const getDaysInMonth = (date: Date) => {
        return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    };

    const formatMonthYear = (date: Date) => {
        return date.toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric',
        });
    };

    const goToPreviousMonth = () => {
        setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
    };

    const goToNextMonth = () => {
        setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
    };

    const goToCurrentMonth = () => {
        setCurrentMonth(new Date());
    };

    // PhaseTask and the imported Task type share the same field names
    // (id, status, progress, Assignstaff, etc.), so this maps one onto the
    // other explicitly at a single, localized boundary rather than assigning
    // a PhaseTask straight into Task-typed state.
    const phaseTaskToTask = (task: PhaseTask): Task =>
        ({
            ...task,
        }) as unknown as Task;

    const handleTaskClick = (task: PhaseTask) => {
        setSelectedTask(phaseTaskToTask(task));
        setIsEditTaskOpen(true);
    };

    const [activeTab, setActiveTab] = useState<ProjectTab>('Project Overview');

    const project = projects.find((item) => item.id === projectId);

    const tabs: ProjectTab[] = ['Project Overview', 'Project Scope', 'Project Task', 'Financial Summary'];

    const canDragTask = (task: ProjectTask) => {
        return true;
    };

    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, task: ProjectTask) => {
        if (!canDragTask(task)) {
            e.preventDefault();
            return;
        }

        setDraggedTaskId(task.id);

        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', String(task.id));
    };

    const handleDragEnd = () => {
        setDraggedTaskId(null);
        setDragOverStatus(null);
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>, status: ProjectTask['status']) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        setDragOverStatus(status);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) {
            setDragOverStatus(null);
        }
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>, newStatus: ProjectTask['status']) => {
        e.preventDefault();

        const taskId = e.dataTransfer.getData('text/plain');

        if (!taskId) {
            handleDragEnd();
            return;
        }

        const task = tasks.find((item) => String(item.id) === String(taskId));

        if (!task) {
            handleDragEnd();
            return;
        }

        if (task.status === newStatus) {
            handleDragEnd();
            return;
        }

        const updatedTask: ProjectTask = {
            ...task,
            status: newStatus,
        };

        updateTask(updatedTask);
        handleDragEnd();
    };

    const updateTask = (updatedTask: ProjectTask) => {
        setTasks((currentTasks) =>
            currentTasks.map((task) =>
                String(task.id) === String(updatedTask.id)
                    ? {
                        ...task,
                        ...updatedTask,
                    }
                    : task,
            ),
        );

        setPhases((prevPhases) =>
            prevPhases.map((phase) => ({
                ...phase,
                tasks: phase.tasks.map((task) =>
                    String(task.id) === String(updatedTask.id)
                        ? {
                            ...task,
                            status: PROJECT_TO_PHASE_STATUS[updatedTask.status],
                            progress: String(updatedTask.progress ?? 0),
                        }
                        : task,
                ),
            })),
        );
    };

    const [newTask, setNewTask] = useState({
        name: '',
        description: '',
        estimatedHours: '',
        actualHours: '',
        hourlyRate: '',
        materialCost: '',
        otherExpenses: '',
        project: '',
        phase: '',
        assignStaff: '',
        startDate: '',
        dueDate: '',
        priority: 'Medium' as 'Low' | 'Medium' | 'High' | 'Urgent',
    });

    const teamMembers = ['David Wilson', 'Emily Davis', 'John Smith', 'Sarah Johnson'];

const handleOpenAddTask = (phaseId: string) => {
    setEditingTaskId(null);
    setSelectedPhaseId(phaseId);

    setAddTaskForm({
        name: '',
        description: '',
        estimatedHours: '',
        actualHours: '',
        hourlyRate: '',
        materialCost: '',
        otherExpenses: '',
        project: project?.id ?? '',
        phase: phaseId,
        assignStaff: [],
        startDate: '',
        dueDate: '',
        priority: 'Medium',
    });

    setExpandedPhases((prev) => ({
        ...prev,
        [phaseId]: true,
    }));

    setShowAddTaskModal(true);   // 👈 CHANGED from setIsAddTaskOpen(true)
};

    const handleUpdateTask = () => {
        if (!editingTaskId) return;

        const taskName = newTask.name.trim();
        const description = newTask.description.trim();

        if (!taskName || !newTask.project || !newTask.phase || !newTask.assignStaff || !newTask.startDate || !newTask.dueDate || !description) {
            return;
        }

        const estimatedHours = Number(newTask.estimatedHours) || 0;

        setPhases((prevPhases) =>
            prevPhases.map((phase) => ({
                ...phase,
                tasks: phase.tasks.map((task) =>
                    task.id === editingTaskId
                        ? {
                            ...task,
                            name: taskName,
                            title: taskName,
                            description,
                            estimatedHours,
                            project: newTask.project,
                            phase: newTask.phase,
                            assignStaff: newTask.assignStaff,
                            startDate: newTask.startDate,
                            dueDate: newTask.dueDate,
                            priority: newTask.priority,
                        }
                        : task,
                ),
                estimatedHours: phase.tasks.reduce((total, task) => (task.id === editingTaskId ? total + estimatedHours : total + task.estimatedHours), 0),
            })),
        );

        setTasks((prev) =>
            prev.map((task) =>
                String(task.id) === String(editingTaskId)
                    ? {
                        ...task,
                        title: taskName,
                        name: taskName,
                        description,
                        assignedTo: newTask.assignStaff,
                        startDate: newTask.startDate,
                        endDate: newTask.dueDate,
                        duration: estimatedHours,
                        priority: newTask.priority.toLowerCase() as 'low' | 'medium' | 'high' | 'urgent',
                        project: newTask.project,
                        phase: newTask.phase,
                    }
                    : task,
            ),
        );

        setIsAddTaskOpen(false);
        setEditingTaskId(null);
        setNewTask({
            name: '',
            description: '',
            estimatedHours: '',
            actualHours: '',
            hourlyRate: '',
            materialCost: '',
            otherExpenses: '',
            project: '',
            phase: '',
            assignStaff: '',
            startDate: '',
            dueDate: '',
            priority: 'Medium',
        });
        setSelectedPhaseId(null);
    };

    const [inScopeItems, setInScopeItems] = useState<ScopeItem[]>([
        {
            id: 'scope-1',
            text: 'Route verification and engineering validation',
            completed: false,
        },
        {
            id: 'scope-2',
            text: 'Fiber cable installation (aerial and underground)',
            completed: false,
        },
        {
            id: 'scope-3',
            text: 'Pole attachment and hardware installation',
            completed: false,
        },
        {
            id: 'scope-4',
            text: 'Fiber lashing and messenger installation',
            completed: false,
        },
        {
            id: 'scope-5',
            text: 'Fiber splicing (backbone, distribution, and mid-span)',
            completed: false,
        },
    ]);

    const [outOfScopeItems, setOutOfScopeItems] = useState<ScopeItem[]>([
        {
            id: 'outscope-1',
            text: 'Customer premises drops and in-home installation (activation-ready handoff only)',
        },
        {
            id: 'outscope-2',
            text: 'Active electronics provisioning (OLT/ONT configuration) beyond physical ODF readiness',
        },
        {
            id: 'outscope-3',
            text: 'Pole replacement programs owned by the utility, except where specified in the engineering package',
        },
    ]);

    const toggleInScopeItem = (id: string) => {
        setInScopeItems((current) =>
            current.map((item) =>
                item.id === id
                    ? {
                        ...item,
                        completed: !item.completed,
                    }
                    : item,
            ),
        );
    };

    const handleEditScopeItem = (item: ScopeItem, type: ScopeType) => {
        setEditingScopeId(item.id);
        setEditingScopeType(type);
        setScopeType(type);
        setScopeText(item.text);
        setShowScopeForm(true);
    };

    const handleDeleteScopeItem = (id: string, type: ScopeType) => {
        if (type === 'inScope') {
            setInScopeItems((current) => current.filter((item) => item.id !== id));
        } else {
            setOutOfScopeItems((current) => current.filter((item) => item.id !== id));
        }

        if (editingScopeId === id) {
            setEditingScopeId(null);
            setEditingScopeType(null);
            setScopeText('');
            setShowScopeForm(false);
        }
    };

    const handleSaveScopeItem = () => {
        if (!scopeText.trim()) {
            return;
        }

        const trimmedText = scopeText.trim();

        if (editingScopeId && editingScopeType) {
            if (editingScopeType === 'inScope') {
                setInScopeItems((current) =>
                    current.map((item) =>
                        item.id === editingScopeId
                            ? {
                                ...item,
                                text: trimmedText,
                            }
                            : item,
                    ),
                );
            } else {
                setOutOfScopeItems((current) =>
                    current.map((item) =>
                        item.id === editingScopeId
                            ? {
                                ...item,
                                text: trimmedText,
                            }
                            : item,
                    ),
                );
            }
        } else {
            const newItem: ScopeItem = {
                id: crypto.randomUUID(),
                text: trimmedText,
                completed: false,
            };

            if (scopeType === 'inScope') {
                setInScopeItems((current) => [...current, newItem]);
            } else {
                setOutOfScopeItems((current) => [...current, newItem]);
            }
        }

        setScopeText('');
        setShowScopeForm(false);
        setEditingScopeId(null);
        setEditingScopeType(null);
    };

    const [phases, setPhases] = useState<Phase[]>([
        {
            id: 'phase-1',
            name: 'Phase 1',
            description: 'Initial project phase',
            estimatedHours: 18,
            tasks: [
             {
                 id: 'site-visit',
                 name: 'Site Visit',
                 title: 'Site Visit',
                 description: 'Physical inspection of the deployment area.',
                 estimatedHours: 4,
                 actualHours: 4,
                 hourlyRate: 120,
                 materialCost: 150,
                 otherExpenses: 50,
                 project: projectId ?? '',
                 phase: 'phase-1',
                 assignStaff: 'David Wilson',
                 startDate: '',
                 dueDate: '',
                 priority: 'Medium',
                 status: 'Pending',
                 progress: '',
                 Task: '',

                 Assignstaff: [
                     {
                         name: 'David Wilson',
                         rate: 120,
                         hours: 4,
                         amount: 480,
                     },
                     {
                         name: 'David Wilson',
                         rate: 120,
                         hours: 4,
                         amount: 480,
                     },
                 ],
                 rate: []
             },

               {
                   id: 'pole-inspection',
                   name: 'Pole Inspection',
                   title: 'Pole Inspection',
                   description: 'Checking integrity of existing utility poles.',
                   estimatedHours: 6,
                   actualHours: 6,
                   hourlyRate: 100,
                   materialCost: 200,
                   otherExpenses: 30,
                   project: projectId ?? '',
                   phase: 'phase-1',
                   assignStaff: 'Emily Davis, David Wilson',
                   startDate: '',
                   dueDate: '',
                   priority: 'Medium',
                   status: 'Pending',
                   progress: '',
                   Task: '',

                   Assignstaff: [
                       {
                           name: 'Emily Davis',
                           rate: 100,
                           hours: 3,
                           amount: 300,
                       },
                       {
                           name: 'David Wilson',
                           rate: 100,
                           hours: 3,
                           amount: 300,
                       },
                   ],
                   rate: []
               },

                {
                    id: 'gps-mapping',
                    name: 'GPS Mapping',
                    title: 'GPS Mapping',
                    description: 'Digital mapping of all installation points.',
                    estimatedHours: 8,
                    actualHours: 8,
                    hourlyRate: 110,
                    materialCost: 0,
                    otherExpenses: 20,
                    project: projectId ?? '',
                    phase: 'phase-1',
                    assignStaff: 'John Smith, Emily Davis',
                    startDate: '',
                    dueDate: '',
                    priority: 'Medium',
                    status: 'Pending',
                    progress: '',
                    Task: '',

                    Assignstaff: [
                        {
                            name: 'John Smith',
                            rate: 110,
                            hours: 4,
                            amount: 440,
                        },
                    ],
                    rate: []
                },

            ],
        },
    ]);

    const [isAddPhaseOpen, setIsAddPhaseOpen] = useState(false);

    const [newPhase, setNewPhase] = useState({
        name: '',
        description: '',
        estimatedHours: '',
    });

    const handleAddTask = () => {
        const taskName = newTask.name.trim();
        const description = newTask.description.trim();

        if (!selectedPhaseId || !taskName || !newTask.project || !newTask.phase || !newTask.assignStaff || !newTask.startDate || !newTask.dueDate || !description) {
            return;
        }

        const estimatedHours = Number(newTask.estimatedHours) || 0;
        const actualHours = Number(newTask.actualHours) || 0;
        const hourlyRate = newTask.hourlyRate ? Number(newTask.hourlyRate) : undefined;
        const materialCost = Number(newTask.materialCost) || 0;
        const otherExpenses = Number(newTask.otherExpenses) || 0;

        const task: PhaseTask = {
            id: crypto.randomUUID(),
            name: taskName,
            title: taskName,
            description,
            estimatedHours,
            actualHours,
            hourlyRate,
            materialCost,
            otherExpenses,
            project: newTask.project,
            phase: newTask.phase,
            assignStaff: newTask.assignStaff,
            startDate: newTask.startDate,
            dueDate: newTask.dueDate,
            priority: newTask.priority,
            status: 'In Progress',
            progress: '0',
            Task: '',
            Assignstaff: [],
            rate: []
        };

        setPhases((prevPhases) =>
            prevPhases.map((phase) =>
                phase.id === selectedPhaseId
                    ? { ...phase, tasks: [...phase.tasks, task], estimatedHours: phase.estimatedHours + estimatedHours }
                    : phase,
            ),
        );

        setTasks((prev) => [
            ...prev,
            {
                id: task.id,
                title: taskName,
                name: taskName,
                description,
                assignedTo: newTask.assignStaff,
                startDate: newTask.startDate,
                endDate: newTask.dueDate,
                duration: estimatedHours,
                priority: newTask.priority.toLowerCase() as 'low' | 'medium' | 'high' | 'urgent',
                status: 'inprogress',
                project: newTask.project,
                phase: newTask.phase,
                Assignstaff: [],
                progress: 0,
            },
        ]);

        setNewTask({
            name: '',
            description: '',
            estimatedHours: '',
            actualHours: '',
            hourlyRate: '',
            materialCost: '',
            otherExpenses: '',
            project: project?.id ?? '',
            phase: '',
            assignStaff: '',
            startDate: '',
            dueDate: '',
            priority: 'Medium',
        });
        setSelectedPhaseId(null);
        setIsAddTaskOpen(false);
    };

const handleUpdateTaskFromDrawer = (updatedTask: Task) => {
    const drawerStatus = updatedTask.status as unknown as TaskStatus;

    setPhases((prevPhases) =>
        prevPhases.map((phase) => ({
            ...phase,
            tasks: phase.tasks.map((task): PhaseTask => {
                if (String(task.id) !== String(updatedTask.id)) {
                    return task;
                }

                return {
                    ...task,
                    status: drawerStatus,
                    progress: String(updatedTask.progress),
                    Assignstaff:
                        updatedTask.Assignstaff as unknown as AssignedStaff[],
                };
            }),
        }))
    );

    setTasks((prev) =>
        prev.map((task) =>
            String(task.id) === String(updatedTask.id)
                ? {
                      ...task,
                      status: PHASE_TO_PROJECT_STATUS[drawerStatus],
                      Assignstaff:
                          updatedTask.Assignstaff as unknown as AssignedStaff[],
                      progress: Number(updatedTask.progress) || 0,
                  }
                : task
        )
    );

    setSelectedTask(updatedTask);
};

    const handleCancelAddTask = () => {
        setNewTask({
            name: '',
            description: '',
            estimatedHours: '',
            actualHours: '',
            hourlyRate: '',
            materialCost: '',
            otherExpenses: '',
            project: project?.id ?? '',
            phase: '',
            assignStaff: '',
            startDate: '',
            dueDate: '',
            priority: 'Medium',
        });
        setSelectedPhaseId(null);
        setEditingTaskId(null);
        setIsAddTaskOpen(false);
    };

    const handleAddPhase = () => {
        if (!newPhase.name.trim()) {
            return;
        }

        const phase: Phase = {
            id: crypto.randomUUID(),
            name: newPhase.name.trim(),
            description: newPhase.description.trim(),
            estimatedHours: Number(newPhase.estimatedHours) || 0,
            tasks: [],
        };

        setPhases((prev) => [...prev, phase]);

        setExpandedPhases((prev) => ({
            ...prev,
            [phase.id]: true,
        }));

        setNewPhase({
            name: '',
            description: '',
            estimatedHours: '',
        });

        setIsAddPhaseOpen(false);
    };

    const handleAddScopeItem = () => {
        if (!scopeText.trim()) {
            return;
        }

        const newItem: ScopeItem = {
            id: crypto.randomUUID(),
            text: scopeText.trim(),
            completed: false,
        };

        if (scopeType === 'inScope') {
            setInScopeItems((current) => [...current, newItem]);
        } else {
            setOutOfScopeItems((current) => [...current, newItem]);
        }

        setScopeText('');
        setShowScopeForm(false);
    };

    const statusStyles: Record<Project['status'], string> = {
        Planned: 'bg-emerald-50 text-emerald-700',
        Completed: 'bg-blue-50 text-blue-700',
        'On Hold': 'bg-amber-50 text-amber-700',
        'In Progress': 'bg-slate-100 text-slate-600',
        Closed: 'bg-red-50 text-red-700',
    };

    const toggleDeliverable = (id: string) => {
        const deliverable = deliverables.find((item) => item.id === id);

        if (!deliverable || !project) return;

        const newCompletedStatus = !deliverable.completed;

        setDeliverables((prev) =>
            prev.map((item) =>
                item.id === id
                    ? {
                        ...item,
                        completed: newCompletedStatus,
                    }
                    : item,
            ),
        );

        addActivityLog({
            projectId: project.id,
            entity: 'DELIVERABLE',
            entityId: deliverable.id,
            action: 'MODIFY',
            description: newCompletedStatus ? `Marked deliverable "${deliverable.name}" as completed` : `Marked deliverable "${deliverable.name}" as incomplete`,
        });
    };
    const toggleInstallment = (installmentId: number) => {
        setExpandedInstallments((prev) => (prev.includes(installmentId) ? prev.filter((id) => id !== installmentId) : [...prev, installmentId]));
    };

    const handleAddDeliverable = () => {
        if (!project) return;

        const newDeliverable: Deliverable = {
            id: Date.now().toString(),
            projectId: project.id,
            name: deliverableName,
            dueDate: deliverableDueDate,
            completed: false,
        };

        setDeliverables((prev) => [...prev, newDeliverable]);

        addActivityLog({
            projectId: project.id,
            entity: 'DELIVERABLE',
            entityId: newDeliverable.id,
            action: 'ADD',
            description: `Added deliverable "${newDeliverable.name}"`,
        });

        setShowDeliverableModal(false);
        setDeliverableName('');
        setDeliverableDueDate('');
    };

    const formatCurrency = (value: number) => {
        return `$${value.toLocaleString()}`;
    };

    const getStatusSelectStyles = (): StylesConfig<StatusOption, false> => ({
        control: (base, state) => ({
            ...base,
            minHeight: '32px',
            height: '32px',
            borderRadius: '9999px',
            borderColor: state.isFocused ? '#ef4444' : '#e2e8f0',
            backgroundColor: '#f8fafc',
            boxShadow: state.isFocused ? '0 0 0 2px rgba(239, 68, 68, 0.1)' : 'none',
            '&:hover': {
                borderColor: '#cbd5e1',
            },
            cursor: 'pointer',
            fontSize: '11px',
            fontWeight: 700,
        }),
        valueContainer: (base) => ({
            ...base,
            padding: '0 10px',
        }),
        singleValue: (base) => ({
            ...base,
            color: '#475569',
            fontSize: '11px',
            fontWeight: 700,
            margin: 0,
        }),
        placeholder: (base) => ({
            ...base,
            color: '#94a3b8',
            fontSize: '11px',
            fontWeight: 600,
        }),
        indicatorSeparator: () => ({
            display: 'none',
        }),
        dropdownIndicator: (base) => ({
            ...base,
            padding: '0 8px 0 0',
            color: '#94a3b8',
            '&:hover': {
                color: '#64748b',
            },
        }),
        menu: (base) => ({
            ...base,
            borderRadius: '8px',
            overflow: 'hidden',
            marginTop: '4px',
            boxShadow: '0 10px 25px rgba(15, 23, 42, 0.12)',
            border: '1px solid #e2e8f0',
            zIndex: 50,
        }),
        menuList: (base) => ({
            ...base,
            padding: '4px',
        }),
        option: (base, state) => ({
            ...base,
            borderRadius: '6px',
            padding: '8px 10px',
            fontSize: '11px',
            fontWeight: 600,
            color: state.isSelected ? '#dc2626' : '#475569',
            backgroundColor: state.isSelected ? '#fef2f2' : state.isFocused ? '#f8fafc' : '#ffffff',
            cursor: 'pointer',
            '&:active': {
                backgroundColor: '#fef2f2',
            },
        }),
    });

    const removeDeliverable = (id: string) => {
        const deliverable = deliverables.find((item) => item.id === id);

        if (!deliverable || !project) return;

        setDeliverables((prev) => prev.filter((item) => item.id !== id));

        addActivityLog({
            projectId: project.id,
            entity: 'DELIVERABLE',
            entityId: deliverable.id,
            action: 'DELETE',
            description: `Deleted deliverable "${deliverable.name}"`,
        });
    };

    const selectedPhase = phases.find((phase) => phase.id === selectedPhaseId);

    const togglePhase = (phaseId: string) => {
        setExpandedPhases((prev) => ({
            ...prev,
            [phaseId]: !prev[phaseId],
        }));
    };

    if (!project) {
        return (
            <div className="flex min-h-[400px] w-full items-center justify-center">
                <div className="text-center">
                    <p className="text-sm font-semibold text-slate-700">Project not found.</p>
                    <button type="button" onClick={() => navigate('/projects')} className="mt-3 text-sm font-semibold text-red-600 transition hover:text-red-700">
                        Back to Projects
                    </button>
                </div>
            </div>
        );
    }

    const toggleTask = (taskId: string) => {
        setTasks((current) =>
            current.map((task): ProjectTask => {
                if (task.id !== taskId) {
                    return task;
                }
                return {
                    ...task,
                    status: task.status === 'completed' ? 'pending' : 'completed',
                };
            }),
        );
    };

    const handleSaveInstallment = (installment: ProjectInstallment) => {
        if (!installment.dueDate) {
            alert('Please select a due date.');
            return;
        }

        setInstallments((prev) =>
            prev.map((item) =>
                item.id === installment.id
                    ? {
                        ...item,
                        dueDate: installment.dueDate,
                    }
                    : item,
            ),
        );

        console.log('Saved installment:', installment);
    };

    const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

    const [addTaskForm, setAddTaskForm] =
    useState<AddTaskForm>({
        name: "",
        description: "",
        estimatedHours: "",
        actualHours: "",
        hourlyRate: "",
        materialCost: "",
        otherExpenses: "",
        project: "",
        phase: "",

        assignStaff: [],

        startDate: "",
        dueDate: "",
        priority: "Medium",
    });


const handleSaveTask = () => {
    if (editingTaskId) {
        // =================================================
        // UPDATE TASK
        // =================================================
        setPhases((prevPhases) =>
            prevPhases.map((phase) => ({
                ...phase,
                tasks: phase.tasks.map((task) => {
                    if (String(task.id) !== String(editingTaskId)) {
                        return task;
                    }

                    return {
                        ...task,

                        name: addTaskForm.name,
                        title: addTaskForm.name,
                        description: addTaskForm.description,

                        estimatedHours:
                            Number(addTaskForm.estimatedHours) || 0,
                        actualHours:
                            Number(addTaskForm.actualHours) || 0,
                        hourlyRate:
                            Number(addTaskForm.hourlyRate) || 0,
                        materialCost:
                            Number(addTaskForm.materialCost) || 0,
                        otherExpenses:
                            Number(addTaskForm.otherExpenses) || 0,

                        project: addTaskForm.project,
                        phase: addTaskForm.phase,

                        Assignstaff: addTaskForm.assignStaff.map(
                            (staffName) => {
                                const existingStaff =
                                    task.Assignstaff?.find(
                                        (staff) =>
                                            staff.name === staffName
                                    );

                                return (
                                    existingStaff ?? {
                                        name: staffName,
                                        rate:
                                            Number(
                                                addTaskForm.hourlyRate
                                            ) || 0,
                                        hours:
                                            Number(
                                                addTaskForm.estimatedHours
                                            ) || 0,
                                        amount:
                                            (Number(
                                                addTaskForm.hourlyRate
                                            ) || 0) *
                                            (Number(
                                                addTaskForm.estimatedHours
                                            ) || 0),
                                    }
                                );
                            }
                        ),

                        assignStaff:
                            addTaskForm.assignStaff.join(", "),

                        startDate: addTaskForm.startDate,
                        dueDate: addTaskForm.dueDate,
                        priority: addTaskForm.priority,
                    };
                }),
            }))
        );

        // Also update the flat `tasks` list so timeline/board views stay in sync
        setTasks((prev) =>
            prev.map((task) =>
                String(task.id) === String(editingTaskId)
                    ? {
                          ...task,
                          title: addTaskForm.name,
                          name: addTaskForm.name,
                          description: addTaskForm.description,
                          assignedTo:
                              addTaskForm.assignStaff.join(", "),
                          startDate: addTaskForm.startDate,
                          endDate: addTaskForm.dueDate,
                          duration:
                              Number(addTaskForm.estimatedHours) || 0,
                          priority: addTaskForm.priority.toLowerCase() as
                              | 'low'
                              | 'medium'
                              | 'high'
                              | 'urgent',
                          project: addTaskForm.project,
                          phase: addTaskForm.phase,
                          Assignstaff: addTaskForm.assignStaff.map(
                              (staffName) => ({
                                  name: staffName,
                                  rate:
                                      Number(addTaskForm.hourlyRate) || 0,
                                  hours:
                                      Number(addTaskForm.estimatedHours) || 0,
                                  amount:
                                      (Number(addTaskForm.hourlyRate) || 0) *
                                      (Number(addTaskForm.estimatedHours) || 0),
                              })
                          ),
                      }
                    : task
            )
        );
    } else {
        // =================================================
        // ADD TASK
        // =================================================
        setPhases((prevPhases) =>
            prevPhases.map((phase) => {
                if (String(phase.id) !== String(addTaskForm.phase)) {
                    return phase;
                }

                const newTask: PhaseTask = {
                    id: crypto.randomUUID(),

                    name: addTaskForm.name,
                    title: addTaskForm.name,
                    description: addTaskForm.description,

                    estimatedHours:
                        Number(addTaskForm.estimatedHours) || 0,
                    actualHours:
                        Number(addTaskForm.actualHours) || 0,
                    hourlyRate:
                        Number(addTaskForm.hourlyRate) || 0,
                    materialCost:
                        Number(addTaskForm.materialCost) || 0,
                    otherExpenses:
                        Number(addTaskForm.otherExpenses) || 0,

                    project: addTaskForm.project,
                    phase: addTaskForm.phase,

                    Assignstaff: addTaskForm.assignStaff.map(
                        (staffName) => ({
                            name: staffName,
                            rate: Number(addTaskForm.hourlyRate) || 0,
                            hours:
                                Number(addTaskForm.estimatedHours) || 0,
                            amount:
                                (Number(addTaskForm.hourlyRate) || 0) *
                                (Number(addTaskForm.estimatedHours) || 0),
                        })
                    ),

                    assignStaff: addTaskForm.assignStaff.join(", "),

                    startDate: addTaskForm.startDate,
                    dueDate: addTaskForm.dueDate,
                    priority: addTaskForm.priority,

                    status: 'Pending',
                    progress: '',
                    Task: '',
                    rate: [],
                };

                return {
                    ...phase,
                    tasks: [...phase.tasks, newTask],
                };
            })
        );

        // Also append to the flat `tasks` list
        setTasks((prev) => [
            ...prev,
            {
                id: crypto.randomUUID(),
                title: addTaskForm.name,
                name: addTaskForm.name,
                description: addTaskForm.description,
                assignedTo: addTaskForm.assignStaff.join(", "),
                startDate: addTaskForm.startDate,
                endDate: addTaskForm.dueDate,
                duration: Number(addTaskForm.estimatedHours) || 0,
                priority: addTaskForm.priority.toLowerCase() as
                    | 'low'
                    | 'medium'
                    | 'high'
                    | 'urgent',
                status: 'pending',
                project: addTaskForm.project,
                phase: addTaskForm.phase,
                Assignstaff: addTaskForm.assignStaff.map(
                    (staffName) => ({
                        name: staffName,
                        rate: Number(addTaskForm.hourlyRate) || 0,
                        hours: Number(addTaskForm.estimatedHours) || 0,
                        amount:
                            (Number(addTaskForm.hourlyRate) || 0) *
                            (Number(addTaskForm.estimatedHours) || 0),
                    })
                ),
                progress: 0,
            },
        ]);
    }

    // Reset and close
    setShowAddTaskModal(false);
    setEditingTaskId(null);
    setAddTaskForm({
        name: "",
        description: "",
        estimatedHours: "",
        actualHours: "",
        hourlyRate: "",
        materialCost: "",
        otherExpenses: "",
        project: "",
        phase: "",
        assignStaff: [],
        startDate: "",
        dueDate: "",
        priority: "Medium",
    });
};

const startEditTask = (task: PhaseTask) => {
    setEditingTaskId(String(task.id));

    setAddTaskForm({
        name: task.name ?? task.title ?? "",
        description: task.description ?? "",

        estimatedHours: String(task.estimatedHours ?? ""),
        actualHours: String(task.actualHours ?? ""),

        hourlyRate: String(
            task.hourlyRate ?? task.rate ?? ""
        ),

        materialCost: String(task.materialCost ?? ""),
        otherExpenses: String(task.otherExpenses ?? ""),

        project: String(task.project ?? ""),
        phase: String(task.phase ?? ""),

        assignStaff:
            task.Assignstaff?.map(
                (staff) => staff.name
            ) ?? [],

        startDate: task.startDate ?? "",
        dueDate: task.dueDate ?? "",

        priority: task.priority ?? "Medium",
    });

    setShowAddTaskModal(true);
};


    const deleteTask = (taskId: string) => {
        setPhases((prevPhases) =>
            prevPhases.map((phase) => ({
                ...phase,
                tasks: phase.tasks.filter((task) => task.id !== taskId),
            })),
        );

        setTasks((prev) => prev.filter((task) => task.id !== taskId));

        if (editingTaskId === taskId) {
            setEditingTaskId(null);
            setIsAddTaskOpen(false);
            setSelectedPhaseId(null);
            setNewTask({
                name: '',
                description: '',
                estimatedHours: '',
                actualHours: '',
                hourlyRate: '',
                materialCost: '',
                otherExpenses: '',
                project: project?.id ?? '',
                phase: '',
                assignStaff: '',
                startDate: '',
                dueDate: '',
                priority: 'Medium',
            });
        }

        setCompletedTasks((prev) => {
            const updated = { ...prev };
            delete updated[taskId];
            return updated;
        });
    };

    const [tasks, setTasks] = useState<ProjectTask[]>([
        {
            id: 'TASK-008',
            title: 'Network Deployment',
            name: 'Network Deployment',
            description: 'Deploy network infrastructure',
            assignedTo: 'David Wilson',
            startDate: '2026-08-25',
            endDate: '2026-09-08',
            duration: 80,
            priority: 'high',
            status: 'inprogress',
        },
        {
            id: 'TASK-009',
            title: 'Commissioning',
            name: 'Commissioning',
            description: 'Final commissioning activities',
            assignedTo: 'Emily Davis',
            startDate: '2026-09-28',
            endDate: '2026-10-08',
            duration: 64,
            priority: 'medium',
            status: 'pending',
        },
    ]);

    const handleCancelInstallment = (installment: ProjectInstallment) => {
        setInstallments((prev) =>
            prev.map((item) =>
                item.id === installment.id
                    ? {
                        ...item,
                        dueDate: '',
                    }
                    : item,
            ),
        );
    };

    return (
        <div className="w-full">
            <div className="rounded-xl bg-white">
                <div className="flex items-start justify-between gap-8 px-6 py-5">
                    <div className="min-w-0 flex-1">
                        <button type="button" onClick={() => navigate('/projects')} className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-slate-500 transition hover:text-red-600">
                            <ArrowLeftIcon size={17} />
                            Back to Projects
                        </button>

                        <div className="flex items-center gap-3">
                            <h1 className="text-2xl font-bold tracking-tight text-slate-900">{project.projectName}</h1>

                            <Select<StatusOption, false>
                                options={STATUS_OPTIONS}
                                value={STATUS_OPTIONS.find((option) => option.value === project.status) ?? null}
                                onChange={(selectedOption: SingleValue<StatusOption>) => {
                                    if (!selectedOption) {
                                        return;
                                    }
                                    updateProject(project.id, {
                                        status: selectedOption.value,
                                    });
                                }}
                                placeholder="Select Status"
                                styles={getStatusSelectStyles()}
                                isSearchable={false}
                                isMulti={false}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                            />
                        </div>

                        <div className="mt-2 flex flex-wrap items-center gap-6">
                            <div className="flex items-center gap-2">
                                <BuildingsIcon size={16} className="text-slate-400" />
                                <div>
                                    <p className="text-[8px] font-semibold uppercase tracking-wide text-slate-400">Vendor</p>
                                    <p className="text-sm font-semibold text-slate-700">{project.vendorName}</p>
                                </div>
                            </div>

                            <div className="h-8 w-px bg-slate-200" />

                            <div className="flex items-center gap-2">
                                <UserIcon size={17} className="text-slate-400" />
                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Manager</p>
                                    <p className="text-sm font-semibold text-slate-700">{project.managerName}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="shrink-0 rounded-xl p-2">
                        <div className="flex items-center gap-1">
                            {tabs.map((tab) => {
                                const isActive = activeTab === tab;
                                return (
                                    <button
                                        key={tab}
                                        type="button"
                                        onClick={() => setActiveTab(tab)}
                                        className={`relative whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold transition ${isActive ? 'text-red-600' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                                            }`}
                                    >
                                        {tab}
                                        {isActive && <span className="absolute bottom-0 left-3 right-3 h-0.5 rounded-full bg-red-600" />}
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-6">
                {activeTab === 'Project Overview' && (
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
                        <div className="lg:col-span-2 space-y-5">
                            <div className="rounded-xl border border-slate-200 bg-white">
                                <div className="px-5 py-5">
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Description</p>
                                        <p className="mt-2 text-sm font-medium leading-6 text-slate-700">
                                            Expansion of a high-speed fiber network across the northern metropolitan area, designed to improve connectivity, increase network capacity, and provide
                                            reliable broadband services to residential and commercial customers. The project includes fiber deployment, infrastructure upgrades, testing, commissioning,
                                            and final network integration.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Deliverables / Installments Section */}
                            <div className="rounded-xl border border-slate-200 bg-slate-50/50">
                                {/* Section Header */}
                                <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                                    <div>
                                        <p className="text-sm font-semibold text-slate-800">Deliverables</p>

                                        <p className="mt-0.5 text-xs text-slate-400">Key outputs for this project</p>
                                    </div>

                                    <button
                                        type="button"
                                        onClick={() => setShowDeliverableModal(true)}
                                        className="inline-flex items-center rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-red-700"
                                    >
                                        Add Deliverable
                                    </button>
                                </div>

                                {/* Deliverables */}
                                <div className="px-4 py-4">
                                    {/* No Deliverables */}
                                    {/* {deliverables.length === 0 && (
                                            <div className="flex flex-col items-center justify-center py-10 text-center">
                                                <p className="text-sm font-semibold text-slate-600">
                                                    No deliverables added yet
                                                </p>

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        setShowDeliverableModal(true)
                                                    }
                                                    className="mt-2 text-xs font-semibold text-red-600 transition hover:text-red-700"
                                                >
                                                    Create your first deliverable
                                                </button>
                                            </div>
                                        )} */}

                                    {/* Added Deliverables */}
                                    {deliverables.length > 0 && (
                                        <div className="space-y-2">
                                            {deliverables.map((deliverable, index) => (
                                                <div key={deliverable.id} className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-3">
                                                    <div className="flex min-w-0 items-center gap-3">
                                                        {/* Number */}
                                                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-100 text-xs font-bold text-slate-500">{index + 1}</div>

                                                        {/* Deliverable Details */}
                                                        <div className="min-w-0">
                                                            <p className="truncate text-xs font-semibold text-slate-700">{deliverable.name}</p>

                                                            <p className="mt-0.5 text-[10px] text-slate-400">
                                                                Due Date: <span className="font-medium text-slate-600">{deliverable.dueDate}</span>
                                                            </p>
                                                        </div>
                                                    </div>

                                                    {/* Status */}
                                                    {/* <div className="ml-3 shrink-0">
                                                            <span className="rounded-full bg-amber-100 px-2 py-1 text-[9px] font-bold uppercase tracking-wide text-amber-700">
                                                                Pending
                                                            </span>
                                                        </div> */}
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    {/* ===================================================== */}
                                    {/* EXISTING INSTALLMENTS - NOT CHANGED                   */}
                                    {/* ===================================================== */}

                                    <div className="mt-5 space-y-3">
                                        {installments.map((installment) => {
                                            const isExpanded = expandedInstallments.includes(installment.id);

                                            return (
                                                <div key={installment.id} className="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                                    {/* Installment Header */}
                                                    <div className="flex items-center justify-between px-4 py-3">
                                                        <div className="flex min-w-0 items-center gap-3">
                                                            {/* Checkbox */}
                                                            {/* <div
                                                                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                                                                        installment.status === "Paid"
                                                                            ? "border-red-600 bg-red-600 text-white"
                                                                            : "border-slate-300 bg-white"
                                                                    }`}
                                                                >
                                                                    {installment.status === "Paid" && (
                                                                        <CheckIcon
                                                                            size={13}
                                                                            weight="bold"
                                                                        />
                                                                    )}
                                                                </div> */}

                                                            {/* Installment Name + Count */}
                                                            <div className="min-w-0">
                                                                <div className="flex items-center gap-2">
                                                                    <p className="truncate text-sm font-semibold text-slate-800">{installment.name}</p>

                                                                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-500">
                                                                        {installment.moduleItems.length} Items
                                                                    </span>
                                                                </div>

                                                                {/* Due Date */}
                                                                <div className="mt-1.5 flex items-center gap-2">
                                                                    <label className="text-xs text-slate-500">Due Date:</label>

                                                                    <input
                                                                        type="date"
                                                                        value={installment.dueDate}
                                                                        // disabled={installment.status === "Paid"}
                                                                        onChange={(e) => {
                                                                            const newDate = e.target.value;

                                                                            setInstallments((prev) =>
                                                                                prev.map((item) =>
                                                                                    item.id === installment.id
                                                                                        ? {
                                                                                            ...item,
                                                                                            dueDate: newDate,
                                                                                        }
                                                                                        : item,
                                                                                ),
                                                                            );
                                                                        }}
                                                                        className={`rounded-md border px-2 py-1 text-xs font-medium outline-none transition ${installment.status === 'Paid'
                                                                            ? ' border-slate-200 '
                                                                            : 'border-slate-200 bg-white text-slate-700 focus:border-red-400 focus:ring-1 focus:ring-red-100'
                                                                            }`}
                                                                    />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        {/* Right Side */}
                                                        <div className="ml-3 flex shrink-0 items-center gap-3">
                                                            {/* Status */}
                                                            {/* <span
                                                                    className={`rounded-full px-2 py-1 text-[9px] font-bold uppercase tracking-wide ${
                                                                        installment.status === "Paid"
                                                                            ? "bg-emerald-100 text-emerald-700"
                                                                            : "bg-amber-100 text-amber-700"
                                                                    }`}
                                                                >
                                                                    {installment.status}
                                                                </span> */}

                                                            {/* Save Button - Pending only */}
                                                            {/* {installment.status === "Pending" && ( */}
                                                            <div className="flex items-center gap-1.5">
                                                                {/* Confirm */}
                                                                <button
                                                                    type="button"
                                                                    onClick={() => handleSaveInstallment(installment)}
                                                                    aria-label={`Save ${installment.name}`}
                                                                    title="Save"
                                                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-emerald-600 transition-colors hover:bg-emerald-50"
                                                                >
                                                                    <CheckIcon size={17} weight="bold" />
                                                                </button>

                                                                {/* Cancel */}
                                                                <button
                                                                    type="button"
                                                                    onClick={() => handleCancelInstallment(installment)}
                                                                    aria-label={`Cancel ${installment.name}`}
                                                                    title="Cancel"
                                                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-600 transition-colors hover:bg-red-50"
                                                                >
                                                                    <XIcon size={17} weight="bold" />
                                                                </button>
                                                            </div>
                                                            {/* )} */}

                                                            {/* Expand Button */}
                                                            {/* Expand Button */}
                                                            <button
                                                                type="button"
                                                                // disabled={installment.status === "Paid"}
                                                                onClick={() => toggleInstallment(installment.id)}
                                                                aria-label={isExpanded ? `Collapse ${installment.name}` : `Expand ${installment.name}`}
                                                                className={`flex h-8 w-8 items-center justify-center rounded-lg transition ${installment.status === 'Paid' ? ' text-slate-300' : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                                                                    }`}
                                                            >
                                                                {isExpanded ? <CaretDownIcon size={17} weight="bold" /> : <CaretRightIcon size={17} weight="bold" />}
                                                            </button>
                                                        </div>
                                                    </div>

                                                    {/* Module Details */}
                                                    {isExpanded && (
                                                        <div className="border-t border-slate-100 bg-slate-50/50 px-4 py-4">
                                                            <div className="mb-3 flex items-center justify-between">
                                                                <p className="text-xs font-semibold text-slate-700">Module Items</p>

                                                                <p className="text-[11px] text-slate-400">{installment.moduleItems.length} Items</p>
                                                            </div>

                                                            <div className="space-y-2">
                                                                {installment.moduleItems.map((item) => (
                                                                    <div key={item.id} className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-3">
                                                                        <div className="flex min-w-0 items-center gap-3">
                                                                            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-100 text-xs font-bold text-slate-500">
                                                                                {item.id}
                                                                            </div>

                                                                            <div className="min-w-0">
                                                                                <p className="truncate text-xs font-semibold text-slate-700">{item.name}</p>

                                                                                <p className="mt-0.5 text-[10px] text-slate-400">Module Item</p>
                                                                            </div>
                                                                        </div>

                                                                        <div className="ml-3 shrink-0 text-right">
                                                                            <p className="text-xs font-bold text-red-600">USD {formatCurrency(item.rate)}</p>
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>

                            <div className="mt-6 rounded-xl border border-slate-200 bg-white">
                                <div className="border-b border-slate-200 px-5 py-4">
                                    <div>
                                        <h2 className="text-sm font-bold text-slate-900">Activity Log</h2>
                                        <p className="mt-1 text-xs text-slate-400">Track changes made to project deliverables</p>
                                    </div>
                                </div>
                                <div className="px-5 py-5">
                                    {activityLogs.filter((activity) => activity.projectId === project.id).length === 0 ? (
                                        <div className="flex flex-col items-center justify-center py-8 text-center">
                                            <p className="text-sm font-semibold text-slate-600">No activity yet</p>
                                            <p className="mt-1 text-xs text-slate-400">Deliverable changes will appear here</p>
                                        </div>
                                    ) : (
                                        <div className="relative">
                                            <div className="absolute left-[7px] top-2 bottom-2 w-px bg-slate-200" />
                                            <div className="space-y-6">
                                                {activityLogs
                                                    .filter((activity) => activity.projectId === project.id)
                                                    .map((activity) => (
                                                        <div key={activity.id} className="relative flex gap-4">
                                                            <div
                                                                className={`relative z-10 mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border-2 border-white ${activity.action === 'ADD' ? 'bg-emerald-500' : activity.action === 'DELETE' ? 'bg-red-500' : 'bg-blue-500'
                                                                    }`}
                                                            />
                                                            <div className="min-w-0 flex-1">
                                                                <div className="flex items-start justify-between gap-4">
                                                                    <div>
                                                                        <div className="flex items-center gap-2">
                                                                            <span
                                                                                className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide ${activity.action === 'ADD'
                                                                                    ? 'bg-emerald-100 text-emerald-700'
                                                                                    : activity.action === 'DELETE'
                                                                                        ? 'bg-red-100 text-red-700'
                                                                                        : 'bg-blue-100 text-blue-700'
                                                                                    }`}
                                                                            >
                                                                                {activity.action}
                                                                            </span>
                                                                            <span className="text-[9px] font-bold uppercase tracking-wide text-slate-400">{activity.entity}</span>
                                                                        </div>
                                                                        <p className="mt-1.5 text-xs font-medium text-slate-700">{activity.description}</p>
                                                                    </div>
                                                                    <span className="shrink-0 text-[10px] text-slate-400">{new Date(activity.createdAt).toLocaleString()}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="rounded-xl border border-slate-200 bg-white">
                            <div className="border-b border-slate-200 px-5 py-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-sm font-bold text-slate-900">Project Profile</h2>
                                        <p className="mt-1 text-xs text-slate-400">Key project information</p>
                                    </div>
                                    <span className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-bold ${statusStyles[project.status]}`}>{project.status}</span>
                                </div>
                            </div>
                            <div className="space-y-5 px-5 py-5">
                                <button
                                    type="button"
                                    onClick={() => setShowManagerProfile(true)}
                                    className="flex w-full items-start gap-3 rounded-xl border bg-slate-100 p-2 text-left transition hover:bg-red-50"
                                >
                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500">
                                        <UserCircleIcon size={25} weight="regular" />
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Manager</p>
                                        <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                                            <UserIcon size={14} weight="regular" className="text-slate-400" />
                                            {project.managerName}
                                        </p>
                                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500">
                                            <EnvelopeSimpleIcon size={13} weight="regular" className="text-slate-400" />
                                            {project.managerEmail}
                                        </p>
                                    </div>
                                </button>

                                <div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Overall Progress</p>
                                        <span className="text-xs font-bold text-slate-700">{project.progress}%</span>
                                    </div>
                                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                                        <div
                                            className="h-full rounded-full bg-red-600 transition-all"
                                            style={{
                                                width: `${project.progress}%`,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Value</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.projectValue.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Budget</p>
                                    <p className="mt-1 text-sm font-semibold leading-5 text-slate-800">{project.budget.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Survey Ref</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.surveyRef}</p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Start Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.startDate}</p>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">End Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.endDate}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'Project Scope' && (
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
                        <div className="rounded-xl border border-slate-200 bg-white lg:col-span-2">
                            <div className="border-b border-slate-200 px-5 py-4">
                                <h2 className="text-sm font-bold text-slate-900">Project Scope</h2>
                                <p className="mt-1 text-xs text-slate-400">Define and manage the scope of this project.</p>
                            </div>
                            <div className="grid grid-cols-1 divide-y divide-slate-200 lg:grid-cols-2 lg:divide-x lg:divide-y-0">
                                <div className="p-5">
                                    <div className="flex items-center justify-between gap-4">
                                        <div>
                                            <h2 className="text-sm font-bold text-slate-900">In Scope</h2>
                                            <p className="mt-1 text-xs text-slate-400">Items included in the project scope.</p>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setScopeType('inScope');
                                                setShowScopeForm(true);
                                            }}
                                            className="inline-flex shrink-0 items-center rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-red-700"
                                        >
                                            Add Item
                                        </button>
                                    </div>

                                    {showScopeForm && scopeType === 'inScope' && (
                                        <div className="mt-5 rounded-xl border border-red-100 bg-red-50/40 p-4">
                                            <p className="text-xs font-bold text-slate-700">{editingScopeId ? 'Edit In Scope' : 'Add to In Scope'}</p>
                                            <textarea
                                                value={scopeText}
                                                onChange={(event) => setScopeText(event.target.value)}
                                                placeholder="Enter scope details..."
                                                rows={3}
                                                className="mt-3 w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                            />
                                            <div className="mt-3 flex justify-end gap-2">
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        setShowScopeForm(false);
                                                        setScopeText('');
                                                    }}
                                                    className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                                                >
                                                    Cancel
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={handleAddScopeItem}
                                                    disabled={!scopeText.trim()}
                                                    className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                                                >
                                                    Save Changes
                                                </button>
                                            </div>
                                        </div>
                                    )}

                                    <div className="mt-5 space-y-3">
                                        {inScopeItems.map((item) => (
                                            <div
                                                key={item.id}
                                                className="group flex items-start justify-between gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-3 transition hover:border-slate-200 hover:bg-white"
                                            >
                                                <label className="flex min-w-0 flex-1 cursor-pointer items-start gap-3">
                                                    <input
                                                        type="checkbox"
                                                        checked={item.completed ?? false}
                                                        onChange={() => toggleInScopeItem(item.id)}
                                                        className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer accent-red-600"
                                                    />

                                                    <span
                                                        className={`text-sm leading-5 ${
                                                            item.completed
                                                                ? 'text-slate-400 line-through'
                                                                : 'font-medium text-slate-700'
                                                        }`}
                                                    >
                                                        {item.text}
                                                    </span>
                                                </label>

                                                {!item.completed && (
                                                    <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                handleEditScopeItem(item, 'inScope')
                                                            }
                                                            aria-label={`Edit ${item.text}`}
                                                            title="Edit"
                                                            className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
                                                        >
                                                            <PencilSimpleIcon
                                                                size={15}
                                                                weight="bold"
                                                            />
                                                        </button>

                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                handleDeleteScopeItem(
                                                                    item.id,
                                                                    'inScope'
                                                                )
                                                            }
                                                            aria-label={`Delete ${item.text}`}
                                                            title="Delete"
                                                            className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                                                        >
                                                            <TrashIcon
                                                                size={15}
                                                                weight="bold"
                                                            />
                                                        </button>
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>

                                </div>

                                <div className="p-5">
                                    <div className="flex items-center justify-between gap-4">
                                        <div>
                                            <h2 className="text-sm font-bold text-slate-900">Out of Scope (Assumed)</h2>
                                            <p className="mt-1 text-xs text-slate-400">Items excluded from the current project scope.</p>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setScopeType('outOfScope');
                                                setShowScopeForm(true);
                                            }}
                                            className="inline-flex shrink-0 items-center rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-red-700"
                                        >
                                            Add Item
                                        </button>
                                    </div>

                                    {showScopeForm && scopeType === 'outOfScope' && (
                                        <div className="mt-5 rounded-xl border border-red-100 bg-red-50/40 p-4">
                                            <p className="text-xs font-bold text-slate-700">Add to Out of Scope</p>
                                            <textarea
                                                value={scopeText}
                                                onChange={(event) => setScopeText(event.target.value)}
                                                placeholder="Enter scope details..."
                                                rows={3}
                                                className="mt-3 w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                            />
                                            <div className="mt-3 flex justify-end gap-2">
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        setShowScopeForm(false);
                                                        setScopeText('');
                                                    }}
                                                    className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                                                >
                                                    Cancel
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={handleAddScopeItem}
                                                    disabled={!scopeText.trim()}
                                                    className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                                                >
                                                    Save Changes
                                                </button>
                                            </div>
                                        </div>
                                    )}

                                    <div className="mt-5 space-y-3">
                                        {outOfScopeItems.map((item) => (
                                            <div
                                                key={item.id}
                                                className="group flex items-start justify-between gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-3 transition hover:border-slate-200 hover:bg-white"
                                            >
                                                <p className="min-w-0 flex-1 text-sm font-medium leading-5 text-slate-700">{item.text}</p>
                                                <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                                                    <button
                                                        type="button"
                                                        onClick={() => handleEditScopeItem(item, 'outOfScope')}
                                                        aria-label={`Edit ${item.text}`}
                                                        title="Edit"
                                                        className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
                                                    >
                                                        <PencilSimpleIcon size={15} weight="bold" />
                                                    </button>
                                                    <button
                                                        type="button"
                                                        onClick={() => handleDeleteScopeItem(item.id, 'outOfScope')}
                                                        aria-label={`Delete ${item.text}`}
                                                        title="Delete"
                                                        className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                                                    >
                                                        <TrashIcon size={15} weight="bold" />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>

                                    <div className="mt-5 rounded-lg border border-amber-100 bg-amber-50 px-3 py-3">
                                        <p className="text-xs font-medium leading-5 text-amber-700">Any change to scope must follow the change management process (see Risks &amp; Change sheet).</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="rounded-xl border border-slate-200 bg-white">
                            <div className="border-b border-slate-200 px-5 py-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-sm font-bold text-slate-900">Project Profile</h2>
                                        <p className="mt-1 text-xs text-slate-400">Key project information</p>
                                    </div>
                                    <span className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-bold ${statusStyles[project.status]}`}>{project.status}</span>
                                </div>
                            </div>
                            <div className="space-y-5 px-5 py-5">
                                <div className="flex items-start gap-3 rounded-xl border bg-slate-100 p-2 hover:bg-red-50">
                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500">
                                        <UserCircleIcon size={25} weight="regular" />
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Manager</p>
                                        <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                                            <UserIcon size={14} weight="regular" className="text-slate-400" />
                                            {project.managerName}
                                        </p>
                                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500">
                                            <EnvelopeSimpleIcon size={13} weight="regular" className="text-slate-400" />
                                            {project.managerEmail}
                                        </p>
                                    </div>
                                </div>

                                <div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Overall Progress</p>
                                        <span className="text-xs font-bold text-slate-700">{project.progress}%</span>
                                    </div>
                                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                                        <div
                                            className="h-full rounded-full bg-red-600 transition-all"
                                            style={{
                                                width: `${project.progress}%`,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Value</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.projectValue.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Budget</p>
                                    <p className="mt-1 text-sm font-semibold leading-5 text-slate-800">{project.budget.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Survey Ref</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.surveyRef}</p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Start Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.startDate}</p>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">End Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.endDate}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'Project Task' && (
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
                        <div className="rounded-xl border border-slate-200 bg-white lg:col-span-2">
                            <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
                                <div className="min-w-0">
                                    <h2 className="text-sm font-bold text-slate-900">Project Tasks</h2>
                                    <p className="mt-1 text-xs text-slate-400">Manage tasks associated with this project.</p>
                                </div>
                                <div className="shrink-0">
                                    <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                                        <button
                                            type="button"
                                            onClick={() => setTaskView('tree')}
                                            className={`rounded-md px-3 py-2 text-xs font-semibold transition ${taskView === 'tree' ? 'bg-white text-primary shadow-sm' : 'text-slate-500 hover:text-slate-700'
                                                }`}
                                        >
                                            Tree View
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => setTaskView('timeline')}
                                            className={`rounded-md px-3 py-2 text-xs font-semibold transition ${taskView === 'timeline' ? 'bg-white text-primary shadow-sm' : 'text-slate-500 hover:text-slate-700'
                                                }`}
                                        >
                                            Timeline View
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => setTaskView('board')}
                                            className={`rounded-md px-3 py-2 text-xs font-semibold transition ${taskView === 'board' ? 'bg-white text-primary shadow-sm' : 'text-slate-500 hover:text-slate-700'
                                                }`}
                                        >
                                            Board View
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="p-5">
                                {taskView === 'tree' && (
                                    <div>
                                        <div className="mb-4 flex items-center justify-between">
                                            <div>
                                                <h3 className="text-sm font-bold text-slate-800">Task Tree</h3>
                                                <p className="mt-1 text-xs text-slate-400">View project tasks in a hierarchical structure.</p>
                                            </div>
                                            <button
                                                type="button"
                                                onClick={() => setIsAddPhaseOpen(true)}
                                                className="inline-flex items-center gap-1.5 rounded-md bg-red-600 px-3 py-1.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                                            >
                                                <PlusIcon size={16} weight="bold" />
                                                Add Phase
                                            </button>
                                        </div>

                                        <div className="space-y-3">
                                            {phases.map((phase) => {
                                                const isExpanded = !!expandedPhases[phase.id];
                                                return (
                                                    <div key={phase.id} className="overflow-hidden rounded-lg border border-slate-200 bg-white">
                                                        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3">
                                                            <div className="flex min-w-0 items-center gap-2">
                                                                <button
                                                                    type="button"
                                                                    onClick={() => togglePhase(phase.id)}
                                                                    className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md text-red-500 transition-colors hover:bg-slate-200 hover:text-slate-700"
                                                                >
                                                                    {isExpanded ? <CaretDownIcon size={16} weight="bold" /> : <CaretRightIcon size={16} weight="bold" />}
                                                                </button>
                                                                <div className="min-w-0">
                                                                    <h4 className="text-sm font-bold text-slate-800">{phase.name}</h4>
                                                                    <div className="mt-0.5 flex items-center gap-2">
                                                                        <p className="text-xs text-slate-400">
                                                                            {phase.tasks.length} {phase.tasks.length === 1 ? 'task' : 'tasks'}
                                                                        </p>
                                                                        <span className="text-slate-300">•</span>
                                                                        <p className="text-xs font-semibold text-slate-500">
                                                                            Estimated Hours: <span className="text-slate-700">{phase.estimatedHours ?? 0} hrs</span>
                                                                        </p>
                                                                    </div>
                                                                    {phase.description && <p className="mt-1 text-xs text-slate-400">{phase.description}</p>}
                                                                </div>
                                                            </div>
                                                            <button
                                                                type="button"
                                                                onClick={() => handleOpenAddTask(phase.id)}
                                                                className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-red-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-red-700"
                                                            >
                                                                <PlusIcon size={14} weight="bold" />
                                                                Add Task
                                                            </button>
                                                        </div>

                                                        {isExpanded && (
                                                            <div className="relative">
                                                                {phase.tasks.length > 0 && <div className="absolute bottom-0 left-[28px] top-0 w-px bg-slate-200" />}
                                                                {phase.tasks.length === 0 ? (
                                                                    <div className="px-6 py-8 text-center">
                                                                        <p className="text-xs text-slate-400">No tasks added to this phase yet.</p>
                                                                        <button
                                                                            type="button"
                                                                            onClick={() => handleOpenAddTask(phase.id)}
                                                                            className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-red-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-red-700"
                                                                        >
                                                                            <PlusIcon size={14} weight="bold" />
                                                                            Add Task
                                                                        </button>
                                                                    </div>
                                                                ) : (
                                                                    <div className="space-y-1 py-1">
                                                                        {phase.tasks.map((task) => {
                                                                            const isCompleted = task.status === 'Completed';
                                                                            const isEditing = editingTaskId === task.id;
                                                                            return (
                                                                                <div
                                                                                    key={task.id}
                                                                                    onClick={() => handleTaskClick(task)}
                                                                                    className={`group relative mx-2 cursor-pointer rounded-lg border transition-all duration-200 ${isCompleted
                                                                                        ? 'border-emerald-100 bg-emerald-50/30'
                                                                                        : 'border-transparent bg-white hover:border-red-300 hover:bg-red-50/30 hover:shadow-sm'
                                                                                        }`}
                                                                                >
                                                                                    <div
                                                                                        className={`absolute left-[28px] top-[25px] h-px w-4 ${isCompleted ? 'bg-emerald-200' : 'bg-slate-200 group-hover:bg-red-300'
                                                                                            }`}
                                                                                    />
                                                                                    <div className="flex items-start gap-3 px-4 py-4 pl-8">
                                                                                        <button
                                                                                            type="button"
                                                                                            onClick={() => toggleTask(task.id)}
                                                                                            disabled={isEditing}
                                                                                            className={`relative z-10 mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded border transition-all ${isCompleted
                                                                                                ? 'border-emerald-500 bg-emerald-500 text-white'
                                                                                                : 'border-slate-300 bg-white text-transparent hover:border-red-500 hover:bg-red-50'
                                                                                                }`}
                                                                                        >
                                                                                            {isCompleted && <CheckIcon size={13} weight="bold" />}
                                                                                        </button>
                                                                                        <div className="min-w-0 flex-1">
                                                                                            {isEditing ? (
                                                                                                <div className="space-y-3"></div>
                                                                                            ) : (
                                                                                                <div>
                                                                                                <div className="flex items-start justify-between gap-4">
                                                                                                    <div className="min-w-0 flex-1">
                                                                                                        <h5
                                                                                                            className={`truncate text-sm font-semibold ${
                                                                                                                isCompleted
                                                                                                                    ? 'text-slate-400 line-through'
                                                                                                                    : 'text-slate-800 group-hover:text-red-600'
                                                                                                            }`}
                                                                                                        >
                                                                                                            {task.name}
                                                                                                        </h5>

                                                                                                        <p
                                                                                                            className={`mt-1 text-xs leading-5 ${
                                                                                                                isCompleted
                                                                                                                    ? 'text-slate-300 line-through'
                                                                                                                    : 'text-slate-500'
                                                                                                            }`}
                                                                                                        >
                                                                                                            {task.description}
                                                                                                        </p>

                                                                                                        {/* Estimated Hours */}
                                                                                                        <div className="mt-2 flex items-center gap-1.5">
                                                                                                            <span className="text-[10px] font-semibold text-slate-400">
                                                                                                                Estimated Hours:
                                                                                                            </span>

                                                                                                            <span className="text-[10px] font-bold text-slate-600">
                                                                                                                {task.estimatedHours ?? 0} hrs
                                                                                                            </span>
                                                                                                        </div>

                                                                                                        {/* Assigned Staff */}
                                                                                                        <div className="mt-2 flex items-start gap-1.5">
                                                                                                            <span className="shrink-0 text-[10px] font-semibold text-slate-400">
                                                                                                                Assigned Staff:
                                                                                                            </span>

                                                                                                            <div className="flex flex-wrap gap-1">
                                                                                                                {task.Assignstaff?.length > 0 ? (
                                                                                                                    task.Assignstaff.map((staff, index) => (
                                                                                                                        <span
                                                                                                                            key={`${task.id}-staff-${index}`}
                                                                                                                            className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600"
                                                                                                                        >
                                                                                                                            {staff.name}
                                                                                                                        </span>
                                                                                                                    ))
                                                                                                                ) : (
                                                                                                                    <span className="text-[10px] text-slate-400">
                                                                                                                        Unassigned
                                                                                                                    </span>
                                                                                                                )}
                                                                                                            </div>
                                                                                                        </div>

                                                                                                    </div>

                                                                                                    <div className="flex shrink-0 flex-col items-end">
                                                                                                        <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                                                                                                            {/* Edit Icon */}
                                                                                                            {(!task.status ||
                                                                                                                task.status === 'Pending' ||
                                                                                                                task.status === 'Due Date' ||
                                                                                                                task.status === 'On Hold') && (
                                                                                                                <button
                                                                                                                    type="button"
                                                                                                                    onClick={(e) => {
                                                                                                                        e.stopPropagation();
                                                                                                                        startEditTask(task);
                                                                                                                    }}
                                                                                                                    className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                                                                                                                    title="Edit task"
                                                                                                                >
                                                                                                                    <PencilSimpleIcon size={15} />
                                                                                                                </button>
                                                                                                            )}

                                                                                                            {/* Delete Icon */}
                                                                                                            <button
                                                                                                                type="button"
                                                                                                                onClick={(e) => {
                                                                                                                    e.stopPropagation();
                                                                                                                    deleteTask(task.id);
                                                                                                                }}
                                                                                                                className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                                                                                                                title="Delete task"
                                                                                                            >
                                                                                                                <TrashIcon size={15} />
                                                                                                            </button>
                                                                                                        </div>

                                                                                                        {/* Status */}
                                                                                                        <span
                                                                                                            className={`mt-1 inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                                                                                                                task.status === 'Completed'
                                                                                                                    ? 'bg-emerald-100 text-emerald-700'
                                                                                                                    : task.status === 'In Progress'
                                                                                                                    ? 'bg-blue-100 text-blue-700'
                                                                                                                    : task.status === 'On Hold'
                                                                                                                        ? 'bg-amber-100 text-amber-700'
                                                                                                                        : task.status === 'Due Date'
                                                                                                                        ? 'bg-red-100 text-red-700'
                                                                                                                        : 'bg-slate-100 text-slate-600'
                                                                                                            }`}
                                                                                                        >
                                                                                                            {task.status || 'Pending'}
                                                                                                        </span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>

                                                                                            )}
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            );
                                                                        })}
                                                                    </div>
                                                                )}
                                                                {selectedTask && (
                                                                    <Edit
                                                                        task={selectedTask}
                                                                        onClose={() => {
                                                                            setIsEditTaskOpen(false);
                                                                            setSelectedTask(null);
                                                                        }}
                                                                        onUpdateTask={handleUpdateTaskFromDrawer}
                                                                    />
                                                                )}
                                                               <ADDTASK
                                                                    showModal={showAddTaskModal}
                                                                    form={addTaskForm}
                                                                    setForm={setAddTaskForm}
                                                                    projects={projects}
                                                                    phases={phases}
                                                                    teamMembers={teamMembers}
                                                                    editingTaskId={editingTaskId}
                                                                    onClose={() => {
                                                                        setShowAddTaskModal(false);
                                                                        setEditingTaskId(null);
                                                                    }}
                                                                    onSave={handleSaveTask}
                                                                />

                                                            </div>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                            {phases.length === 0 && (
                                                <div className="rounded-lg border border-dashed border-slate-200 px-4 py-10 text-center">
                                                    <p className="text-sm font-medium text-slate-500">No phases have been added yet.</p>
                                                    <button
                                                        type="button"
                                                        onClick={() => setIsAddPhaseOpen(true)}
                                                        className="inline-flex items-center gap-1.5 rounded-md bg-red-600 px-3 py-1.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                                                    >
                                                        <PlusIcon size={16} weight="bold" />
                                                        Add Phase
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )}

                                {taskView === 'timeline' && (
                                    <div>
                                        <div className="mb-4 flex items-center justify-between">
                                            <div>
                                                <h3 className="text-sm font-bold text-slate-800">Timeline View</h3>
                                                <p className="mt-1 text-xs text-slate-400">View project tasks according to their timeline.</p>
                                            </div>
                                            <div className="flex items-center gap-3 text-[10px] text-slate-500">
                                                <div className="flex items-center gap-1.5">
                                                    <span className="h-2.5 w-2.5 rounded-full bg-blue-500" />
                                                    Active
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />
                                                    In Progress
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <span className="h-2.5 w-2.5 rounded-full bg-green-500" />
                                                    Completed
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <span className="h-2.5 w-2.5 rounded-full bg-gray-400" />
                                                    On Hold
                                                </div>
                                            </div>
                                        </div>

                                        <div className="mb-4 flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-3">
                                            <button
                                                type="button"
                                                onClick={goToPreviousMonth}
                                                className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition hover:bg-slate-50 hover:text-slate-800"
                                                title="Previous month"
                                            >
                                                <CaretLeftIcon size={16} weight="bold" />
                                            </button>
                                            <div className="flex items-center gap-3">
                                                <h4 className="text-sm font-bold text-slate-800">{formatMonthYear(currentMonth)}</h4>
                                                <button
                                                    type="button"
                                                    onClick={goToCurrentMonth}
                                                    className="rounded-md bg-slate-100 px-2.5 py-1 text-[10px] font-semibold text-slate-600 transition hover:bg-slate-200"
                                                >
                                                    Today
                                                </button>
                                            </div>
                                            <button
                                                type="button"
                                                onClick={goToNextMonth}
                                                className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition hover:bg-slate-50 hover:text-slate-800"
                                                title="Next month"
                                            >
                                                <CaretLeftIcon size={16} weight="bold" className="rotate-180" />
                                            </button>
                                        </div>

                                        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
                                            <div
                                                className="min-w-[1200px]"
                                                style={{
                                                    display: 'grid',
                                                    gridTemplateColumns: `260px repeat(${getDaysInMonth(currentMonth)}, minmax(35px, 1fr))`,
                                                }}
                                            >
                                                <div className="sticky left-0 z-20 border-b border-r border-slate-200 bg-slate-50 px-4 py-3">
                                                    <p className="text-xs font-bold text-slate-700">Task / Project</p>
                                                </div>

                                                {Array.from(
                                                    {
                                                        length: getDaysInMonth(currentMonth),
                                                    },
                                                    (_, index) => {
                                                        const day = index + 1;
                                                        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                                                        const isToday = date.toDateString() === new Date().toDateString();
                                                        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                                                        return (
                                                            <div
                                                                key={day}
                                                                className={`border-b border-r border-slate-200 px-1 py-2 text-center ${isToday ? 'bg-red-50' : isWeekend ? 'bg-slate-50' : 'bg-white'}`}
                                                            >
                                                                <p className={`text-[9px] font-medium ${isToday ? 'text-red-500' : 'text-slate-400'}`}>
                                                                    {date.toLocaleDateString('en-US', {
                                                                        weekday: 'short',
                                                                    })}
                                                                </p>
                                                                <p className={`mt-0.5 text-xs font-bold ${isToday ? 'text-red-600' : 'text-slate-700'}`}>{day}</p>
                                                            </div>
                                                        );
                                                    },
                                                )}

                                                <div className="sticky left-0 z-10 border-b border-r border-slate-200 bg-slate-50/80 px-4 py-3">
                                                    <p className="truncate text-xs font-bold text-slate-800">{project?.projectName || 'Project'}</p>
                                                    <p className="mt-0.5 text-[10px] text-slate-400">Project Timeline</p>
                                                </div>

                                                {Array.from(
                                                    {
                                                        length: getDaysInMonth(currentMonth),
                                                    },
                                                    (_, index) => {
                                                        const day = index + 1;
                                                        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                                                        const isToday = date.toDateString() === new Date().toDateString();
                                                        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                                                        return (
                                                            <div
                                                                key={`project-${day}`}
                                                                className={`border-b border-r border-slate-200 ${isToday ? 'bg-red-50/50' : isWeekend ? 'bg-slate-50/50' : 'bg-white'}`}
                                                            />
                                                        );
                                                    },
                                                )}

                                                {tasks && tasks.length > 0 ? (
                                                    tasks.map((task: any, index: number) => {
                                                        const monthStart = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
                                                        const monthEnd = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
                                                        const taskStart = task.startDate ? new Date(task.startDate) : task.endDate ? new Date(task.endDate) : monthStart;
                                                        const taskEnd = task.endDate ? new Date(task.endDate) : taskStart;
                                                        const taskIsOutside = taskEnd < monthStart || taskStart > monthEnd;
                                                        if (taskIsOutside) {
                                                            return (
                                                                <Fragment key={task.id || `${task.title}-${index}`}>
                                                                    <div className="sticky left-0 z-10 border-b border-r border-slate-200 bg-white px-4 py-3">
                                                                        <p className="truncate text-xs font-semibold text-slate-400">{task.title || task.name}</p>
                                                                        <p className="mt-1 text-[10px] text-slate-400">Outside selected month</p>
                                                                    </div>
                                                                    {Array.from(
                                                                        {
                                                                            length: getDaysInMonth(currentMonth),
                                                                        },
                                                                        (_, dayIndex) => (
                                                                            <div key={`outside-${dayIndex}`} className="border-b border-r border-slate-200 bg-slate-50/30" />
                                                                        ),
                                                                    )}
                                                                </Fragment>
                                                            );
                                                        }
                                                        const visibleStart = taskStart < monthStart ? monthStart : taskStart;
                                                        const visibleEnd = taskEnd > monthEnd ? monthEnd : taskEnd;
                                                        const startDay = visibleStart.getDate();
                                                        const endDay = visibleEnd.getDate();
                                                        const taskSpan = endDay - startDay + 1;
                                                        const statusColor =
                                                            task.status === 'completed'
                                                                ? 'bg-green-500'
                                                                : task.status === 'inprogress'
                                                                    ? 'bg-yellow-500'
                                                                    : task.status === 'onhold'
                                                                        ? 'bg-gray-400'
                                                                        : 'bg-blue-500';
                                                        return (
                                                            <Fragment key={task.id || `${task.title}-${index}`}>
                                                                <div className="sticky left-0 z-10 border-b border-r border-slate-200 bg-white px-4 py-3">
                                                                    <p className="truncate text-xs font-semibold text-slate-700">{task.title || task.name}</p>
                                                                    <div className="mt-1 flex items-center gap-2">
                                                                        {task.duration && <span className="text-[10px] text-slate-400">{task.duration} hrs</span>}
                                                                        {task.priority && (
                                                                            <>
                                                                                <span className="text-slate-300">•</span>
                                                                                <span className="text-[10px] capitalize text-slate-400">{task.priority}</span>
                                                                            </>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                                {Array.from(
                                                                    {
                                                                        length: startDay - 1,
                                                                    },
                                                                    (_, dayIndex) => {
                                                                        const day = dayIndex + 1;
                                                                        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                                                                        const isToday = date.toDateString() === new Date().toDateString();
                                                                        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                                                                        return (
                                                                            <div
                                                                                key={`before-${day}`}
                                                                                className={`border-b border-r border-slate-200 ${isToday ? 'bg-red-50/50' : isWeekend ? 'bg-slate-50/50' : 'bg-white'}`}
                                                                            />
                                                                        );
                                                                    },
                                                                )}
                                                                <div
                                                                    style={{
                                                                        gridColumn: `span ${taskSpan}`,
                                                                    }}
                                                                    className="border-b border-r border-slate-200 p-1.5"
                                                                >
                                                                    <div
                                                                        className={`${statusColor} flex h-8 items-center justify-center rounded-md px-2 text-[10px] font-semibold text-white shadow-sm`}
                                                                        title={`${task.title || task.name} | ${taskStart.toLocaleDateString()} - ${taskEnd.toLocaleDateString()}`}
                                                                    >
                                                                        <span className="truncate">{task.title || task.name}</span>
                                                                    </div>
                                                                </div>
                                                                {Array.from(
                                                                    {
                                                                        length: getDaysInMonth(currentMonth) - endDay,
                                                                    },
                                                                    (_, dayIndex) => {
                                                                        const day = endDay + dayIndex + 1;
                                                                        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                                                                        const isToday = date.toDateString() === new Date().toDateString();
                                                                        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                                                                        return (
                                                                            <div
                                                                                key={`after-${day}`}
                                                                                className={`border-b border-r border-slate-200 ${isToday ? 'bg-red-50/50' : isWeekend ? 'bg-slate-50/50' : 'bg-white'}`}
                                                                            />
                                                                        );
                                                                    },
                                                                )}
                                                            </Fragment>
                                                        );
                                                    })
                                                ) : (
                                                    <div
                                                        style={{
                                                            gridColumn: `1 / span ${getDaysInMonth(currentMonth) + 1}`,
                                                        }}
                                                        className="px-4 py-12 text-center"
                                                    >
                                                        <p className="text-sm font-semibold text-slate-500">No tasks available</p>
                                                        <p className="mt-1 text-xs text-slate-400">Add tasks to display them on the timeline.</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {taskView === 'board' && (
                                    <div>
                                        <div className="mb-4">
                                            <h3 className="text-sm font-bold text-slate-800">Board View</h3>
                                            <p className="mt-1 text-xs text-slate-400">Drag and drop tasks between statuses to update their progress.</p>
                                        </div>

                                        <div className="w-full overflow-x-auto pb-4">
                                            <div className="grid min-w-[1400px] grid-cols-4 gap-4">
                                                {[
                                                    {
                                                        key: 'active' as ProjectTaskStatus,
                                                        label: 'Active',
                                                        columnClass: 'border-blue-200 bg-blue-50/40',
                                                        headerClass: 'bg-blue-100 text-blue-700',
                                                    },
                                                    {
                                                        key: 'inprogress' as ProjectTaskStatus,
                                                        label: 'In Progress',
                                                        columnClass: 'border-yellow-200 bg-yellow-50/40',
                                                        headerClass: 'bg-yellow-100 text-yellow-700',
                                                    },
                                                    {
                                                        key: 'completed' as ProjectTaskStatus,
                                                        label: 'Completed',
                                                        columnClass: 'border-green-200 bg-green-50/40',
                                                        headerClass: 'bg-green-100 text-green-700',
                                                    },
                                                    {
                                                        key: 'onhold' as ProjectTaskStatus,
                                                        label: 'On Hold',
                                                        columnClass: 'border-gray-200 bg-gray-50',
                                                        headerClass: 'bg-gray-100 text-gray-700',
                                                    },
                                                ].map((column) => {
                                                    const columnTasks = (tasks || []).filter((task: any) => task.status === column.key);
                                                    const isDragOver = dragOverStatus === column.key;
                                                    return (
                                                        <div
                                                            key={column.key}
                                                            onDragOver={(e) => handleDragOver(e, column.key)}
                                                            onDragLeave={handleDragLeave}
                                                            onDrop={(e) => handleDrop(e, column.key)}
                                                            className={`
                                                                flex
                                                                h-[680px]
                                                                min-h-0
                                                                flex-col
                                                                overflow-hidden
                                                                rounded-xl
                                                                border
                                                                transition-all
                                                                ${column.columnClass}
                                                                ${isDragOver ? 'border-primary bg-primary/10 ring-2 ring-primary/20' : ''}
                                                            `}
                                                        >
                                                            <div
                                                                className={`
                                                                flex
                                                                shrink-0
                                                                items-center
                                                                justify-between
                                                                rounded-t-xl
                                                                px-4
                                                                py-4
                                                                ${column.headerClass}
                                                            `}
                                                            >
                                                                <div>
                                                                    <h4 className="text-sm font-bold">{column.label}</h4>
                                                                    <p className="mt-0.5 text-xs opacity-70">
                                                                        {columnTasks.length} {columnTasks.length === 1 ? 'Task' : 'Tasks'}
                                                                    </p>
                                                                </div>
                                                                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-xs font-bold shadow-sm">{columnTasks.length}</span>
                                                            </div>

                                                            <div className="min-h-0 flex-1 overflow-y-auto p-3">
                                                                <div className="space-y-3">
                                                                    {columnTasks.length === 0 ? (
                                                                        <div
                                                                            className={`
                                                                            flex
                                                                            min-h-[150px]
                                                                            items-center
                                                                            justify-center
                                                                            rounded-lg
                                                                            border
                                                                            border-dashed
                                                                            px-4
                                                                            text-center
                                                                            transition
                                                                            ${isDragOver ? 'border-primary bg-white text-primary' : 'border-slate-300 bg-white/70 text-slate-400'}
                                                                        `}
                                                                        >
                                                                            <p className="text-xs">{isDragOver ? 'Drop task here' : 'No tasks'}</p>
                                                                        </div>
                                                                    ) : (
                                                                        <>
                                                                            {columnTasks.map((task: any) => {
                                                                                const isDragging = draggedTaskId === task.id;
                                                                                const priorityClass =
                                                                                    task.priority === 'urgent'
                                                                                        ? 'bg-red-100 text-red-700'
                                                                                        : task.priority === 'high'
                                                                                            ? 'bg-orange-100 text-orange-700'
                                                                                            : task.priority === 'medium'
                                                                                                ? 'bg-yellow-100 text-yellow-700'
                                                                                                : 'bg-green-100 text-green-700';
                                                                                const progress = Math.min(100, Math.max(0, Number(task.progress || 0)));
                                                                                return (
                                                                                    <div
                                                                                        key={task.id}
                                                                                        draggable
                                                                                        onDragStart={(e) => handleDragStart(e, task)}
                                                                                        onDragEnd={handleDragEnd}
                                                                                        className={`
                                                                                            cursor-grab
                                                                                            rounded-xl
                                                                                            border 
                                                                                            border-slate-200
                                                                                            bg-white
                                                                                            p-4
                                                                                            shadow-sm
                                                                                            transition-all
                                                                                            hover:-translate-y-0.5
                                                                                            hover:shadow-md
                                                                                            active:cursor-grabbing
                                                                                            ${isDragging ? 'scale-[0.98] opacity-40' : ''}
                                                                                        `}
                                                                                    >
                                                                                        <div className="mb-3 flex items-center gap-1">
                                                                                            <span className="h-1 w-1 rounded-full bg-slate-300" />
                                                                                            <span className="h-1 w-1 rounded-full bg-slate-300" />
                                                                                            <span className="h-1 w-1 rounded-full bg-slate-300" />
                                                                                            <span className="ml-1 text-[9px] text-slate-400">Drag to move</span>
                                                                                        </div>

                                                                                        <div className="flex items-start justify-between gap-2">
                                                                                            <div className="min-w-0">
                                                                                                <p className="mb-1 text-[10px] font-medium text-slate-400">{task.id}</p>
                                                                                                <h4 className="truncate text-sm font-bold text-slate-800">{task.title || task.name}</h4>
                                                                                            </div>
                                                                                            <span
                                                                                                className={`
                                                                                                    shrink-0
                                                                                                    rounded-full
                                                                                                    px-2.5
                                                                                                    py-1
                                                                                                    text-[10px]
                                                                                                    font-semibold
                                                                                                    capitalize
                                                                                                    ${priorityClass}
                                                                                                `}
                                                                                            >
                                                                                                {task.priority || 'low'}
                                                                                            </span>
                                                                                        </div>

                                                                                        <p className="mt-2 line-clamp-2 text-xs leading-5 text-slate-500">{task.description}</p>

                                                                                        <div className="mt-4 grid grid-cols-2 gap-3">
                                                                                            <div className="min-w-0">
                                                                                                <p className="text-[10px] uppercase tracking-wide text-slate-400">Project</p>
                                                                                                <p className="mt-1 truncate text-xs font-semibold text-slate-700">
                                                                                                    {task.project || project?.projectName || 'Project'}
                                                                                                </p>
                                                                                            </div>
                                                                                            <div className="min-w-0">
                                                                                                <p className="text-[10px] uppercase tracking-wide text-slate-400">Phase</p>
                                                                                                <p className="mt-1 truncate text-xs font-medium text-slate-600">{task.phase || 'Not assigned'}</p>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div className="mt-3">
                                                                                            <p className="text-[10px] uppercase tracking-wide text-slate-400">Assigned Staff</p>
                                                                                            <p className="mt-1 truncate text-xs font-medium text-slate-600">
                                                                                                {task.Assignstaff?.length > 0 ? task.Assignstaff.join(', ') : task.assignedTo || 'Not assigned'}
                                                                                            </p>
                                                                                        </div>

                                                                                        <div className="mt-4 grid grid-cols-2 gap-3">
                                                                                            <div>
                                                                                                <p className="text-[10px] text-slate-400">Start Date</p>
                                                                                                <p className="mt-1 text-xs font-medium text-slate-600">
                                                                                                    {task.startDate
                                                                                                        ? new Date(`${task.startDate}T00:00:00`).toLocaleDateString('en-IN', {
                                                                                                            day: '2-digit',
                                                                                                            month: 'short',
                                                                                                        })
                                                                                                        : '-'}
                                                                                                </p>
                                                                                            </div>
                                                                                            <div>
                                                                                                <p className="text-[10px] text-slate-400">End Date</p>
                                                                                                <p className="mt-1 text-xs font-medium text-slate-600">
                                                                                                    {task.endDate
                                                                                                        ? new Date(`${task.endDate}T00:00:00`).toLocaleDateString('en-IN', {
                                                                                                            day: '2-digit',
                                                                                                            month: 'short',
                                                                                                        })
                                                                                                        : '-'}
                                                                                                </p>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div className="mt-3 flex items-center justify-between">
                                                                                            <span className="text-[10px] text-slate-400">Duration</span>
                                                                                            <span className="text-xs font-semibold text-slate-600">{task.duration || 0} hrs</span>
                                                                                        </div>

                                                                                        <div className="mt-4">
                                                                                            <div className="mb-1.5 flex items-center justify-between">
                                                                                                <span className="text-xs font-medium text-slate-500">Progress</span>
                                                                                                <span className="text-xs font-bold text-slate-700">{progress}%</span>
                                                                                            </div>
                                                                                            <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                                                                                                <div
                                                                                                    className={`
                                                                                                        h-full
                                                                                                        rounded-full
                                                                                                        transition-all
                                                                                                        ${column.key === 'completed'
                                                                                                            ? 'bg-green-500'
                                                                                                            : column.key === 'inprogress'
                                                                                                                ? 'bg-yellow-500'
                                                                                                                : column.key === 'onhold'
                                                                                                                    ? 'bg-gray-400'
                                                                                                                    : 'bg-blue-500'
                                                                                                        }
                                                                                                    `}
                                                                                                    style={{
                                                                                                        width: `${progress}%`,
                                                                                                    }}
                                                                                                />
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                );
                                                                            })}
                                                                            {isDragOver && (
                                                                                <div className="flex min-h-[100px] items-center justify-center rounded-xl border-2 border-dashed border-primary bg-primary/5">
                                                                                    <p className="text-xs font-semibold text-primary">Drop task here</p>
                                                                                </div>
                                                                            )}
                                                                        </>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="rounded-xl border border-slate-200 bg-white lg:col-span-1">
                            <div className="border-b border-slate-200 px-5 py-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-sm font-bold text-slate-900">Project Profile</h2>
                                        <p className="mt-1 text-xs text-slate-400">Key project information</p>
                                    </div>
                                    <span className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-bold ${statusStyles[project.status]}`}>{project.status}</span>
                                </div>
                            </div>
                            <div className="space-y-5 px-5 py-5">
                                <div className="flex items-start gap-3 rounded-xl border bg-slate-100 p-2 hover:bg-red-50">
                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500">
                                        <UserCircleIcon size={25} weight="regular" />
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Manager</p>
                                        <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                                            <UserIcon size={14} weight="regular" className="text-slate-400" />
                                            {project.managerName}
                                        </p>
                                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500">
                                            <EnvelopeSimpleIcon size={13} weight="regular" className="text-slate-400" />
                                            {project.managerEmail}
                                        </p>
                                    </div>
                                </div>

                                <div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Overall Progress</p>
                                        <span className="text-xs font-bold text-slate-700">{project.progress}%</span>
                                    </div>
                                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                                        <div
                                            className="h-full rounded-full bg-red-600 transition-all"
                                            style={{
                                                width: `${project.progress}%`,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Value</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.projectValue.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Project Budget</p>
                                    <p className="mt-1 text-sm font-semibold leading-5 text-slate-800">{project.budget.toLocaleString()}</p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Survey Ref</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-800">{project.surveyRef}</p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Start Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.startDate}</p>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">End Date</p>
                                        <p className="mt-1 text-sm font-semibold text-slate-800">{project.endDate}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === "Financial Summary" && (
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
                        <ProjectFinancialSummary
                            project={project}
                            phases={phases}
                        />
                        <div className="rounded-xl border border-slate-200 bg-white">
                            <div className="border-b border-slate-200 px-5 py-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h2 className="text-sm font-bold text-slate-900">
                                            Project Profile
                                        </h2>

                                        <p className="mt-1 text-xs text-slate-400">
                                            Key project information
                                        </p>
                                    </div>

                                    <span
                                        className={`inline-flex rounded-full border px-2.5 py-1 text-[10px] font-bold ${statusStyles[project.status]}`}
                                    >
                                        {project.status}
                                    </span>
                                </div>
                            </div>

                            <div className="space-y-5 px-5 py-5">
                                <button
                                    type="button"
                                    onClick={() => setShowManagerProfile(true)}
                                    className="flex w-full items-start gap-3 rounded-xl border bg-slate-100 p-2 text-left transition hover:bg-red-50"
                                >
                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500">
                                        <UserCircleIcon size={25} weight="regular" />
                                    </div>

                                    <div className="min-w-0">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                            Project Manager
                                        </p>

                                        <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                                            <UserIcon size={14} weight="regular" className="text-slate-400" />
                                            {project.managerName}
                                        </p>

                                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500">
                                            <EnvelopeSimpleIcon size={13} weight="regular" className="text-slate-400" />
                                            {project.managerEmail}
                                        </p>
                                    </div>
                                </button>


                                <div>
                                    <div className="flex items-center justify-between">
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                            Overall Progress
                                        </p>

                                        <span className="text-xs font-bold text-slate-700">
                                            {project.progress}%
                                        </span>
                                    </div>

                                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
                                        <div
                                            className="h-full rounded-full bg-red-600 transition-all"
                                            style={{
                                                width: `${project.progress}%`,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Project Value
                                    </p>

                                    <p className="mt-1 text-sm font-semibold text-slate-800">
                                        {project.projectValue.toLocaleString()}
                                    </p>
                                </div>


                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Project Budget
                                    </p>

                                    <p className="mt-1 text-sm font-semibold leading-5 text-slate-800">
                                        {project.budget.toLocaleString()}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Survey Ref
                                    </p>

                                    <p className="mt-1 text-sm font-semibold text-slate-800">
                                        {project.surveyRef}
                                    </p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                            Start Date
                                        </p>

                                        <p className="mt-1 text-sm font-semibold text-slate-800">
                                            {project.startDate}
                                        </p>
                                    </div>

                                    <div>
                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                            End Date
                                        </p>

                                        <p className="mt-1 text-sm font-semibold text-slate-800">
                                            {project.endDate}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {showDeliverableModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 px-4">
                    <div className="w-full max-w-md rounded-xl bg-white shadow-xl">
                        <div className="border-b border-slate-200 px-5 py-4">
                            <h2 className="text-sm font-bold text-slate-900">Add Deliverable</h2>
                            <p className="mt-1 text-xs text-slate-400">Add a key output for this project.</p>
                        </div>
                        <div className="space-y-4 px-5 py-5">
                            <div>
                                <label className="text-xs font-semibold text-slate-700">Deliverable Name</label>
                                <input
                                    type="text"
                                    value={deliverableName}
                                    onChange={(event) => setDeliverableName(event.target.value)}
                                    placeholder="e.g. Final Site Survey Report"
                                    className="mt-1.5 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-slate-700">Due Date</label>
                                <input
                                    type="date"
                                    value={deliverableDueDate}
                                    onChange={(event) => setDeliverableDueDate(event.target.value)}
                                    className="mt-1.5 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-700 outline-none transition focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                />
                            </div>
                        </div>
                        <div className="flex justify-end gap-2 border-t border-slate-200 px-5 py-4">
                            <button
                                type="button"
                                onClick={() => {
                                    setShowDeliverableModal(false);
                                    setDeliverableName('');
                                    setDeliverableDueDate('');
                                }}
                                className="rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={handleAddDeliverable}
                                disabled={!deliverableName.trim() || !deliverableDueDate}
                                className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                Add Deliverable
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {showManagerProfile && (
                <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-900/50 p-4">
                    <div className="absolute inset-0" onClick={() => setShowManagerProfile(false)} />
                    <div className="relative z-10 w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl">
                        <div className="border-b border-slate-200 px-6 py-5">
                            <div className="flex items-start justify-between gap-4">
                                <div className="flex items-center gap-4">
                                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-bold text-white">SJ</div>
                                    <div>
                                        <h2 className="text-base font-bold text-slate-900">Sarah Johnson</h2>
                                        <p className="mt-0.5 text-sm font-medium text-slate-500">Sarah Johnson</p>
                                        <span className="mt-2 inline-flex rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-bold text-primary">Super Admin</span>
                                    </div>
                                </div>
                                <button type="button" onClick={() => setShowManagerProfile(false)} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600">
                                    <XIcon size={18} />
                                </button>
                            </div>
                        </div>
                        <div className="max-h-[70vh] overflow-y-auto px-6 py-5">
                            <div>
                                <h3 className="text-sm font-bold text-slate-800">About</h3>
                                <p className="mt-2 text-sm leading-6 text-slate-600">
                                    Veteran Project Manager with 10+ years of experience in telecommunications and network deployments. Expert in OSP engineering and contract management.
                                </p>
                            </div>
                            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Email</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-700">sarah.j@projectflow.com</p>
                                </div>
                                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Phone</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-700">+1 (555) 123-4567</p>
                                </div>
                                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Location</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-700">Spalding, UK</p>
                                </div>
                                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Department</p>
                                    <p className="mt-1 text-sm font-semibold text-slate-700">Operations</p>
                                </div>
                            </div>
                            <div className="mt-6 border-t border-slate-200 pt-5">
                                <h3 className="text-sm font-bold text-slate-800">Task Overview</h3>
                                <div className="mt-4 grid grid-cols-3 gap-3">
                                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-center">
                                        <p className="text-xl font-bold text-slate-800">7</p>
                                        <p className="mt-1 text-[10px] font-semibold text-slate-400">Assigned Tasks</p>
                                    </div>
                                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-center">
                                        <p className="text-xl font-bold text-green-600">1</p>
                                        <p className="mt-1 text-[10px] font-semibold text-slate-400">Completed</p>
                                    </div>
                                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-center">
                                        <p className="text-xl font-bold text-primary">6</p>
                                        <p className="mt-1 text-[10px] font-semibold text-slate-400">Active Tasks</p>
                                    </div>
                                </div>
                                <div className="mt-4 space-y-3">
                                    <div className="rounded-xl border border-slate-200 p-4">
                                        <div className="flex items-start justify-between gap-3">
                                            <div>
                                                <p className="text-sm font-bold text-slate-800">GPS Mapping</p>
                                                <p className="mt-1 text-xs text-slate-400">2024-02-28</p>
                                            </div>
                                            <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold text-blue-600">In Progress</span>
                                        </div>
                                    </div>
                                    <div className="rounded-xl border border-slate-200 p-4">
                                        <div className="flex items-start justify-between gap-3">
                                            <div>
                                                <p className="text-sm font-bold text-slate-800">Cable Installation</p>
                                                <p className="mt-1 text-xs text-slate-400">2024-03-15</p>
                                            </div>
                                            <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-600">To Do</span>
                                        </div>
                                    </div>
                                    <div className="rounded-xl border border-slate-200 p-4">
                                        <div className="flex items-start justify-between gap-3">
                                            <div>
                                                <p className="text-sm font-bold text-slate-800">Joint Closure</p>
                                            </div>
                                            <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-600">To Do</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex justify-end border-t border-slate-200 px-6 py-4">
                            <button
                                type="button"
                                onClick={() => setShowManagerProfile(false)}
                                className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isAddPhaseOpen && (
                <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-900/50 p-4">
                    <div className="absolute inset-0" onClick={() => setIsAddPhaseOpen(false)} />
                    <div className="relative z-10 w-full max-w-lg rounded-xl bg-white shadow-2xl">
                        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                            <h2 className="text-lg font-bold text-slate-800">Add Phase</h2>
                            <button
                                type="button"
                                onClick={() => setIsAddPhaseOpen(false)}
                                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                            >
                                <XIcon size={18} />
                            </button>
                        </div>
                        <div className="space-y-4 p-5">
                            <div>
                                <label className="mb-1.5 block text-sm font-semibold text-slate-700">Name</label>
                                <input
                                    type="text"
                                    value={newPhase.name}
                                    onChange={(e) =>
                                        setNewPhase((prev) => ({
                                            ...prev,
                                            name: e.target.value,
                                        }))
                                    }
                                    placeholder="Enter phase name"
                                    className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                                />
                            </div>
                            <div>
                                <label className="mb-1.5 block text-sm font-semibold text-slate-700">Description</label>
                                <textarea
                                    value={newPhase.description}
                                    onChange={(e) =>
                                        setNewPhase((prev) => ({
                                            ...prev,
                                            description: e.target.value,
                                        }))
                                    }
                                    placeholder="Enter phase description"
                                    rows={4}
                                    className="w-full resize-none rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                                />
                            </div>
                            <div>
                                <label className="mb-1.5 block text-sm font-semibold text-slate-700">Estimated Hours</label>
                                <input
                                    type="number"
                                    min="0"
                                    value={newPhase.estimatedHours}
                                    onChange={(e) =>
                                        setNewPhase((prev) => ({
                                            ...prev,
                                            estimatedHours: e.target.value,
                                        }))
                                    }
                                    placeholder="Enter estimated hours"
                                    className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                                />
                            </div>
                        </div>
                        <div className="flex justify-end gap-2 border-t border-slate-200 px-5 py-4">
                            <button
                                type="button"
                                onClick={() => setIsAddPhaseOpen(false)}
                                className="rounded-md border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                disabled={!newPhase.name.trim()}
                                onClick={handleAddPhase}
                                className="rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                Add Phase
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* {isAddTaskOpen && selectedPhase && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
                    <div className="w-full max-w-lg overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl">
                        <div className="flex items-start justify-between border-b border-slate-200 px-5 py-4">
                            <div>
                                <h5 className="text-base font-bold text-slate-800">Add Task</h5>
                                <p className="mt-1 text-xs text-slate-400">
                                    Add a new task to <span className="font-semibold text-slate-600">{selectedPhase.name}</span>
                                </p>
                            </div>
                            <button type="button" onClick={handleCancelAddTask} className="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600">
                                <XIcon size={18} />
                            </button>
                        </div>
                        <div className="space-y-4 px-5 py-5">
                            <div>
                                <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-500">Task Name</label>
                                <input
                                    type="text"
                                    value={newTask.name}
                                    onChange={(e) =>
                                        setNewTask((prev) => ({
                                            ...prev,
                                            name: e.target.value,
                                        }))
                                    }
                                    placeholder="Enter task name"
                                    autoFocus
                                    className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm font-medium text-slate-800 outline-none transition placeholder:text-slate-300 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                />
                            </div>
                            <div>
                                <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-500">Description</label>
                                <textarea
                                    rows={4}
                                    value={newTask.description}
                                    onChange={(e) =>
                                        setNewTask((prev) => ({
                                            ...prev,
                                            description: e.target.value,
                                        }))
                                    }
                                    placeholder="Enter task description"
                                    className="w-full resize-none rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-300 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                />
                            </div>
                            <div>
                                <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-500">Estimated Hours</label>
                                <input
                                    type="number"
                                    min={0}
                                    value={newTask.estimatedHours}
                                    onChange={(e) =>
                                        setNewTask((prev) => ({
                                            ...prev,
                                            estimatedHours: e.target.value,
                                        }))
                                    }
                                    placeholder="0"
                                    className="w-full rounded-md border border-slate-300 bg-white px-3 py-2.5 text-sm font-medium text-slate-700 outline-none transition placeholder:text-slate-300 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                />
                            </div>
                        </div>
                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-3">
                            <button
                                type="button"
                                onClick={handleCancelAddTask}
                                className="rounded-md border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition hover:bg-slate-100"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                disabled={!newTask.name.trim()}
                                onClick={handleAddTask}
                                className="inline-flex items-center gap-1.5 rounded-md bg-red-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                                <CheckIcon size={14} weight="bold" />
                                Add Task
                            </button>
                        </div>
                    </div>
                </div>
            )} */}
        </div>
    );
}
