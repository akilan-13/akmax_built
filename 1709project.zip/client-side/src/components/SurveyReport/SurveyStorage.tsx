import { ElementType } from "react";
import { SurveyTemplate } from "./SurveyList";

export type SurveyFieldOption = {
    id: string;
    label: string;
    value: string;
};

export type SurveyField = {
    id: string;
    name: string;
    label: string;
    type:
        | "text"
        | "number"
        | "radio"
        | "select"
        | "textarea"
        | "checkbox_group";
    required: boolean;
    placeholder?: string;
    helpText?: string;
    unit?: string;
    options?: SurveyFieldOption[];
};

export type SurveyFieldGroup = {
    id: string;
    title: string;
    fields: SurveyField[];
};

export type SurveySection = {
    id: string;
    title: string;
    number?: string;
    fieldGroups: SurveyFieldGroup[];
};

export type StoredSurveyModule = {
    id: string;
    code: string;
    zone: string;
    name: string;
    description?: string;
    fields: number;
    repeatable: boolean;
    unitLabel?: string;
    hasConditional?: boolean;
    // icon?: unknown;
    sections?: SurveySection[];
    templateNames?: string[];
};

export type StoredSurveyTemplate = SurveyTemplate & {
    moduleId?: string;
};

const TEMPLATE_STORAGE_KEY = "survey_templates";
const MODULE_STORAGE_KEY = "survey_modules";

export const getStoredTemplates = (): SurveyTemplate[] => {
    const data = localStorage.getItem(TEMPLATE_STORAGE_KEY);

    if (!data) {
        return [];
    }

    try {
        return JSON.parse(data);
    } catch {
        return [];
    }
};

export const saveStoredTemplates = (
    templates: SurveyTemplate[]
) => {
    localStorage.setItem(
        TEMPLATE_STORAGE_KEY,
        JSON.stringify(templates)
    );
};

export const getStoredModules = (): StoredSurveyModule[] => {
    const data = localStorage.getItem(MODULE_STORAGE_KEY);

    if (!data) {
        return [];
    }

    try {
        return JSON.parse(data);
    } catch {
        return [];
    }
};

export const saveStoredModules = (
    modules: StoredSurveyModule[]
) => {
    localStorage.setItem(
        MODULE_STORAGE_KEY,
        JSON.stringify(modules)
    );
};

export const findModuleForTemplate = (
    template: SurveyTemplate
): StoredSurveyModule | undefined => {
    const modules = getStoredModules();

    return modules.find(
        (module) =>
            module.name.trim().toLowerCase() ===
            template.name.trim().toLowerCase()
    );
};

export const updateStoredModule = (
    updatedModule: StoredSurveyModule
) => {
    const modules = getStoredModules();

    const nextModules = modules.map((module) =>
        module.id === updatedModule.id
            ? updatedModule
            : module
    );

    saveStoredModules(nextModules);
};

export const addStoredModule = (
    module: StoredSurveyModule
) => {
    const modules = getStoredModules();

    saveStoredModules([
        ...modules,
        module,
    ]);
};

export type SurveyModule = StoredSurveyModule & {
    icon: ElementType;
};