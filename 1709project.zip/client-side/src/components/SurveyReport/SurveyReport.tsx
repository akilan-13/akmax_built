import React, { useEffect, useMemo, useState } from "react";
import {
  HardHat,
  MapPin,
  Buildings,
  ListChecks,
  CaretDown,
  CaretRight,
  Plus,
  Minus,
  Check,
  FloppyDisk,
  Users,
  Radio,
  Warning,
  ArrowsClockwise,
  Eye,
  ArrowLeft,

} from "@phosphor-icons/react";
import IconSafari from "../Icon/IconSafari";
import AddModule from "../../offcanvas/surveyform/addmodule";
import { INITIAL_TEMPLATES, SurveyTemplate } from "./SurveyList";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
    getStoredModules,
    getStoredTemplates,
    saveStoredModules,
    StoredSurveyModule,
    SurveyModule,
    SurveyField,
    SurveyFieldGroup,
    SurveyFieldOption,
    SurveySection,
} from "./SurveyStorage";
import { FieldOption, FieldRendererProps, FieldType, FormValue } from "../../types/survey";

export const INITIAL_MODULES: SurveyModule[] = [
    {
        id: "mod1",
        code: "MOD-01",
        zone: "CO",
        name: "Central Office / Headend Check",
        icon: Buildings,
        fields: 14,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH OSP Network Survey",
            "FTTH Network & Drop Survey",
        ],

        sections: [
            {
                id: "mod1-sec1",
                title: "General Facility & Environmental Checks",

                fieldGroups: [
                    {
                        id: "co-access-security",
                        title: "CO Facility Access & Security",

                        fields: [
                            {
                                id: "co-access-status",
                                name: "status",
                                label: "Status",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Pass",
                                        value: "pass",
                                        id: "",
                                    },
                                    {
                                        label: "Fail",
                                        value: "fail",
                                        id: "",
                                    },
                                ],
                            },
                            {
                                id: "co-access-security-method",
                                name: "securityMethod",
                                label: "Keypad / padlock / security guard",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Yes",
                                        value: "yes",
                                        id: "",
                                    },
                                    {
                                        label: "No",
                                        value: "no",
                                        id: "",
                                    },
                                ],
                            },
                        ],
                    },
                    {
                        id: "rack-space-availability",
                        title: "Rack Space Availability (OLT/ODF)",

                        fields: [
                            {
                                id: "rack-space-status",
                                name: "rackSpaceStatus",
                                label: "Status",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Pass",
                                        value: "pass",
                                        id: "",
                                    },
                                    {
                                        label: "Fail",
                                        value: "fail",
                                        id: "",
                                    },
                                ],
                            },
                            {
                                id: "usable-rack-units",
                                name: "usableRackUnits",
                                label: "Usable rack units",
                                type: "number",
                                required: true,
                                unit: "RU",
                            },
                            {
                                id: "rack-space-action",
                                name: "rackSpaceAction",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Yes",
                                        value: "yes",
                                        id: "",
                                    },
                                    {
                                        label: "No",
                                        value: "no",
                                        id: "",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod2",
        code: "MOD-02",
        zone: "OSP",
        name: "OSP Pole / Structure Survey",
        icon: Radio,
        fields: 22,
        repeatable: true,
        unitLabel: "Pole / Structure Record",
        templateNames: [
          
            "FTTH OSP Network Survey",
            
        ],

        sections: [
            {
                id: "mod2-sec1",
                title: "Pole / Structure Identification",
                fieldGroups: [
                    {
                        id: "osp-structure-identification",
                        title: "Structure Identification",
                        fields: [
                            {
                                id: "osp-structure-id",
                                name: "structureId",
                                label: "Structure / Pole ID",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "osp-structure-type",
                                name: "structureType",
                                label: "Structure Type",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Wooden Pole",
                                        value: "wooden_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Concrete Pole",
                                        value: "concrete_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Steel Pole",
                                        value: "steel_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Other",
                                        value: "other",
                                    },
                                ],
                            },
                            {
                                id: "osp-location-reference",
                                name: "locationReference",
                                label: "Location / Landmark",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "osp-gps-latitude",
                                name: "gpsLatitude",
                                label: "GPS Latitude",
                                type: "number",
                                required: true,
                            },
                            {
                                id: "osp-gps-longitude",
                                name: "gpsLongitude",
                                label: "GPS Longitude",
                                type: "number",
                                required: true,
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec2",
                title: "Pole Condition & Structural Assessment",
                fieldGroups: [
                    {
                        id: "osp-pole-condition",
                        title: "Pole Condition",
                        fields: [
                            {
                                id: "osp-pole-condition-status",
                                name: "poleConditionStatus",
                                label: "Overall Pole Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Pass",
                                        value: "pass",
                                    },
                                    {
                                        id: "",
                                        label: "Fail",
                                        value: "fail",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-damage",
                                name: "poleDamage",
                                label: "Visible Damage",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "None",
                                        value: "none",
                                    },
                                    {
                                        id: "",
                                        label: "Minor",
                                        value: "minor",
                                    },
                                    {
                                        id: "",
                                        label: "Major",
                                        value: "major",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-tilt",
                                name: "poleTilt",
                                label: "Pole Tilt / Lean",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Acceptable",
                                        value: "acceptable",
                                    },
                                    {
                                        id: "",
                                        label: "Requires Attention",
                                        value: "requires_attention",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-height",
                                name: "poleHeight",
                                label: "Approximate Pole Height",
                                type: "number",
                                required: true,
                                unit: "m",
                            },
                            {
                                id: "osp-foundation-condition",
                                name: "foundationCondition",
                                label: "Foundation / Ground Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Needs Repair",
                                        value: "needs_repair",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec3",
                title: "Cable & Attachment Assessment",
                fieldGroups: [
                    {
                        id: "osp-cable-attachments",
                        title: "Cable / Hardware Attachments",
                        fields: [
                            {
                                id: "osp-existing-cables",
                                name: "existingCables",
                                label: "Existing Cable Attachments",
                                type: "number",
                                required: true,
                            },
                            {
                                id: "osp-cable-clearance",
                                name: "cableClearance",
                                label: "Cable Clearance",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Compliant",
                                        value: "compliant",
                                    },
                                    {
                                        id: "",
                                        label: "Non-compliant",
                                        value: "non_compliant",
                                    },
                                ],
                            },
                            {
                                id: "osp-hardware-condition",
                                name: "hardwareCondition",
                                label: "Attachment Hardware Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Damaged",
                                        value: "damaged",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "osp-new-attachment-required",
                                name: "newAttachmentRequired",
                                label: "New Attachment Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec4",
                title: "Safety & Survey Notes",
                fieldGroups: [
                    {
                        id: "osp-safety-notes",
                        title: "Safety & Action Required",
                        fields: [
                            {
                                id: "osp-safety-status",
                                name: "safetyStatus",
                                label: "Safety Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Safe",
                                        value: "safe",
                                    },
                                    {
                                        id: "",
                                        label: "Unsafe",
                                        value: "unsafe",
                                    },
                                ],
                            },
                            {
                                id: "osp-action-required",
                                name: "actionRequired",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                            {
                                id: "osp-survey-notes",
                                name: "surveyNotes",
                                label: "Survey Notes",
                                type: "textarea",
                                required: false,
                                placeholder: "Enter additional observations...",
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod3",
        code: "MOD-03",
        zone: "NAP",
        name: "NAP Station Inspection",
        icon: IconSafari,
        fields: 18,
        repeatable: true,
        unitLabel: "NAP Station",
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH OSP Network Survey",
            "FTTH Network & Drop Survey",
        ],

        sections: [
            {
                id: "mod3-sec1",
                title: "NAP Station Identification",
                fieldGroups: [
                    {
                        id: "nap-station-identification",
                        title: "Station Details",
                        fields: [
                            {
                                id: "nap-station-id",
                                name: "stationId",
                                label: "NAP Station ID",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "nap-station-type",
                                name: "stationType",
                                label: "NAP Type",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Wall Mounted",
                                        value: "wall_mounted",
                                    },
                                    {
                                        id: "",
                                        label: "Pole Mounted",
                                        value: "pole_mounted",
                                    },
                                    {
                                        id: "",
                                        label: "Cabinet",
                                        value: "cabinet",
                                    },
                                ],
                            },
                            {
                                id: "nap-location",
                                name: "location",
                                label: "Location / Landmark",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "nap-port-count",
                                name: "portCount",
                                label: "Total Port Count",
                                type: "number",
                                required: true,
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec2",
                title: "NAP Enclosure Condition",
                fieldGroups: [
                    {
                        id: "nap-enclosure-condition",
                        title: "Enclosure & Physical Condition",
                        fields: [
                            {
                                id: "nap-enclosure-status",
                                name: "enclosureStatus",
                                label: "Enclosure Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Pass",
                                        value: "pass",
                                    },
                                    {
                                        id: "",
                                        label: "Fail",
                                        value: "fail",
                                    },
                                ],
                            },
                            {
                                id: "nap-door-condition",
                                name: "doorCondition",
                                label: "Door / Cover Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Damaged",
                                        value: "damaged",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "nap-lock-condition",
                                name: "lockCondition",
                                label: "Lock / Security Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Secure",
                                        value: "secure",
                                    },
                                    {
                                        id: "",
                                        label: "Not Secure",
                                        value: "not_secure",
                                    },
                                ],
                            },
                            {
                                id: "nap-water-ingress",
                                name: "waterIngress",
                                label: "Water / Moisture Ingress",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec3",
                title: "Fiber & Port Inspection",
                fieldGroups: [
                    {
                        id: "nap-fiber-port-inspection",
                        title: "Fiber / Port Condition",
                        fields: [
                            {
                                id: "nap-port-status",
                                name: "portStatus",
                                label: "Port Availability",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Available",
                                        value: "available",
                                    },
                                    {
                                        id: "",
                                        label: "Occupied",
                                        value: "occupied",
                                    },
                                    {
                                        id: "",
                                        label: "Faulty",
                                        value: "faulty",
                                    },
                                ],
                            },
                            {
                                id: "nap-splice-condition",
                                name: "spliceCondition",
                                label: "Splice / Fiber Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Needs Attention",
                                        value: "needs_attention",
                                    },
                                ],
                            },
                            {
                                id: "nap-labeling-status",
                                name: "labelingStatus",
                                label: "Fiber Labeling",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Correct",
                                        value: "correct",
                                    },
                                    {
                                        id: "",
                                        label: "Incorrect",
                                        value: "incorrect",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "nap-slack-storage",
                                name: "slackStorage",
                                label: "Slack Fiber Storage",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Adequate",
                                        value: "adequate",
                                    },
                                    {
                                        id: "",
                                        label: "Inadequate",
                                        value: "inadequate",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec4",
                title: "NAP Safety & Actions",
                fieldGroups: [
                    {
                        id: "nap-safety-actions",
                        title: "Safety & Action Required",
                        fields: [
                            {
                                id: "nap-safety-status",
                                name: "safetyStatus",
                                label: "Safety Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Safe",
                                        value: "safe",
                                    },
                                    {
                                        id: "",
                                        label: "Unsafe",
                                        value: "unsafe",
                                    },
                                ],
                            },
                            {
                                id: "nap-action-required",
                                name: "actionRequired",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                            {
                                id: "nap-inspection-notes",
                                name: "inspectionNotes",
                                label: "Inspection Notes",
                                type: "textarea",
                                required: false,
                                placeholder: "Enter additional observations...",
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod4",
        code: "MOD-04",
        zone: "DROP",
        name: "Residential Drop & Premises",
        icon: MapPin,
        fields: 16,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH Network & Drop Survey",
        ],
    },

    {
        id: "mod5",
        code: "MOD-05",
        zone: "QC",
        name: "Defect / Punch-list",
        icon: ListChecks,
        fields: 9,
        repeatable: true,
        unitLabel: "Defect",
        hasConditional: true,
        templateNames: [
            "Full FTTH Field Survey",
        ],
    },

    {
        id: "mod6",
        code: "MOD-06",
        zone: "SAFETY",
        name: "PPE & Tool Checklist",
        icon: HardHat,
        fields: 12,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
        ],
    },
];

const VENDOR_TYPES = [
  {
    id: "osp",
    label: "TeleCommunications",
    modules: ["mod2", "mod6"],
  },
  {
    id: "splice",
    label: "Construction",
    modules: ["mod1", "mod3", "mod6"],
  },
  {
    id: "resi",
    label: "Technology",
    modules: ["mod4", "mod6"],
  },
  {
    id: "remedial",
    label: "Utilities",
    modules: ["mod5", "mod6"],
  },
  {
    id: "full",
    label: "Professional Services",
    modules: ["mod1", "mod2", "mod3", "mod4", "mod5", "mod6"],
  },
];

const ZONE_COLOR: Record<string, string> = {
  CO: "text-[#4FB6A8] border-[#4FB6A8]/40 bg-[#4FB6A8]/10",
  OSP: "text-[#E8A33D] border-[#E8A33D]/40 bg-[#E8A33D]/10",
  NAP: "text-[#7FA8D9] border-[#7FA8D9]/40 bg-[#7FA8D9]/10",
  DROP: "text-[#C48FD9] border-[#C48FD9]/40 bg-[#C48FD9]/10",
  QC: "text-[#D6614A] border-[#D6614A]/40 bg-[#D6614A]/10",
  SAFETY: "text-[#E8D23D] border-[#E8D23D]/40 bg-[#E8D23D]/10",
};



type CanvasItem = {
  moduleId: string;
  repeatCount: number;
  allowFieldAdd: boolean;
};

type SurveyReportProps = {
    open: boolean;
    onClose: () => void;
    template?: SurveyTemplate | null;
};

export default function SurveyReport() {
const [canvas, setCanvas] = useState<CanvasItem[]>([
    { moduleId: "mod2", repeatCount: 4, allowFieldAdd: true },
    { moduleId: "mod3", repeatCount: 3, allowFieldAdd: true },
    { moduleId: "mod5", repeatCount: 3, allowFieldAdd: true },
    { moduleId: "mod6", repeatCount: 1, allowFieldAdd: false },
]);

    const [expanded, setExpanded] = useState<string | null>("mod5");
    const [activeVendor, setActiveVendor] = useState("full");
    const [formValues, setFormValues] = useState<Record<string, FormValue>>({});
    const [label, setLabel] = useState("");
    const [type, setType] = useState<FieldType>("text");
    const [required, setRequired] = useState(false);
    const [unit, setUnit] = useState("");
    const [options, setOptions] = useState<FieldOption[]>([]);

    const [editingTemplate, setEditingTemplate] = useState<SurveyTemplate | null>(null);
    const [selectedFields, setSelectedFields] = useState<string[]>([]);

    

const getModuleIcon = (
    module: Partial<SurveyModule>
): React.ElementType => {
    switch (module.code) {
        case "MOD-01":
            return Buildings;
        case "MOD-02":
            return Radio;
        case "MOD-03":
            return IconSafari;
        case "MOD-04":
            return MapPin;
        case "MOD-05":
            return ListChecks;
        case "MOD-06":
            return HardHat;
        default:
            return Buildings;
    }
};
const [modules, setModules] = useState<SurveyModule[]>(() => {
    const stored = getStoredModules();

    if (stored.length > 0) {
        return INITIAL_MODULES.map((initialModule) => {
            const storedModule = stored.find(
                (module) => module.id === initialModule.id
            );

            return {
                ...(storedModule || initialModule),
                icon: getModuleIcon(
                    storedModule || initialModule
                ),
            };
        });
    }

    saveStoredModules(
        INITIAL_MODULES.map(({ icon, ...module }) => module)
    );

    return INITIAL_MODULES;
});

    // fetching existing data starts
    const [addModuleOpen, setAddModuleOpen] = useState(false);
    const [searchParams] = useSearchParams();
    const editId = searchParams.get("editId");
    const [editingModule, setEditingModule] = useState<SurveyModule | null>(null);

    const selectedTemplate = useMemo(() => {
    if (!editId) {
        return null;
    }

    return (
        INITIAL_TEMPLATES.find(
            (template) =>
                template.id === Number(editId)
        ) ?? null
    );
}, [editId]);



useEffect(() => {
    if (!selectedTemplate || modules.length === 0) {
        return;
    }

    const nextCanvas: CanvasItem[] =
        selectedTemplate.modules
            .map((moduleCode) => {
                const module = modules.find(
                    (item) =>
                        item.code === moduleCode
                );

                if (!module) {
                    return null;
                }

                return {
                    moduleId: module.id,
                    repeatCount:
                        module.repeatable
                            ? module.id === "mod2"
                                ? 4
                                : 3
                            : 1,
                    allowFieldAdd:
                        !!module.repeatable,
                };
            })
            .filter(
                (
                    item
                ): item is CanvasItem =>
                    item !== null
            );

    setCanvas(nextCanvas);

    if (nextCanvas.length > 0) {
        setExpanded(nextCanvas[0].moduleId);
    }
}, [selectedTemplate, modules]);
    
useEffect(() => {
    if (!editId) {
        return;
    }

    const templates = getStoredTemplates();

    const template = templates.find(
        (item) => item.id === Number(editId)    
    );

    if (!template) {
        return;
    }

    const matchingModule = modules.find(
        (module) =>
            module.name.trim().toLowerCase() ===
            template.name.trim().toLowerCase()
    );

    if (!matchingModule) {
        return;
    }

    setEditingModule({
        ...matchingModule,
        sections: matchingModule.sections?.map((section) => ({
            ...section,
            fieldGroups: section.fieldGroups?.map((group) => ({
                ...group,
                fields: group.fields?.map((field) => ({
                    ...field,
                    options: field.options
                        ? field.options.map((option) => ({
                              ...option,
                          }))
                        : [],
                })),
            })),
        })),
    });

    setAddModuleOpen(true);
}, [editId, modules]);

    // Fetching existing data ends
    const isEditMode = Boolean(editId);

  const [mapping, setMapping] = useState<Record<string, string[]>>(
    Object.fromEntries(
      VENDOR_TYPES.map((vendor) => [vendor.id, vendor.modules])
    )
  );

  const getAllFieldIds = () => {
    return canvas.flatMap((item) => {
        const module = modules.find(
            (mod) => mod.id === item.moduleId
        );

        if (!module) {
            return [];
        }

        return (
            module.sections?.flatMap((section) =>
                section.fieldGroups?.flatMap((group) =>
                    group.fields?.map((field) => field.id) ?? []
                ) ?? []
            ) ?? []
        );
    });
};

const handleSelectAllFields = () => {
    const allFieldIds = getAllFieldIds();

    if (selectedFields.length === allFieldIds.length) {
        setSelectedFields([]);
    } else {
        setSelectedFields(allFieldIds);
    }
};

//   const handleAddField = () => {
//     const newField: SurveyField = {
//         id: crypto.randomUUID(),
//         name: label
//             .toLowerCase()
//             .replace(/\s+/g, "_"),
//         label,
//         type,
//         required,
//         unit: type === "number" ? unit : undefined,
//         options:
//             type === "radio" || type === "select"
//                 ? options
//                 : undefined,
//     };

//     onAddField(newField);
// };

const handleCreateModule = (newModule: SurveyModule) => {
    setModules((current) => {
        const nextModules = [...current, newModule];

        saveStoredModules(
            nextModules.map(({ icon, ...module }) => module)
        );

        return nextModules;
    });

    setCanvas((current) => [
        ...current,
        {
            moduleId: newModule.id,
            repeatCount: 1,
            allowFieldAdd: false,
        },
    ]);

    setAddModuleOpen(false);
};

const handleUpdateModule = (updatedModule: SurveyModule) => {
    setModules((current) => {
        const nextModules = current.map((module) =>
            module.id === updatedModule.id ? updatedModule : module
        );

        saveStoredModules(
            nextModules.map(({ icon, ...module }) => module)
        );

        return nextModules;
    });

    setCanvas((current) =>
        current.map((item) =>
            item.moduleId === updatedModule.id
                ? { ...item, moduleId: updatedModule.id }
                : item
        )
    );

    setEditingModule(null);
    setAddModuleOpen(false);
};
    
  const [otherChecked, setOtherChecked] = useState(true);
  const [savedFlash, setSavedFlash] = useState(false);



  const inCanvas = (id: string) =>
    canvas.some((item) => item.moduleId === id);

  const toggleModule = (id: string) => {
    setCanvas((prev) => {
      if (prev.some((item) => item.moduleId === id)) {
        return prev.filter((item) => item.moduleId !== id);
      }

      const module = modules.find((item) => item.id === id);

      if (!module) return prev;

      return [
        ...prev,
        {
          moduleId: id,
          repeatCount: 1,
          allowFieldAdd: !!module.repeatable,
        },
      ];
    });

    setExpanded(id);
  };

  const setRepeat = (id: string, delta: number) => {
    setCanvas((prev) =>
      prev.map((item) =>
        item.moduleId === id
          ? {
              ...item,
              repeatCount: Math.max(1, item.repeatCount + delta),
            }
          : item
      )
    );
  };

  const totalFields = canvas.reduce((total, item) => {
    const module = modules.find(
        (mod) => mod.id === item.moduleId
    );

    return total + (module?.fields ?? 0);
}, 0);

  const toggleAllowAdd = (id: string) => {
    setCanvas((prev) =>
      prev.map((item) =>
        item.moduleId === id
          ? { ...item, allowFieldAdd: !item.allowFieldAdd }
          : item
      )
    );
  };

  const toggleVendorModule = (vendorId: string, moduleId: string) => {
    setMapping((prev) => {
      const current = prev[vendorId] || [];

      const next = current.includes(moduleId)
        ? current.filter((id) => id !== moduleId)
        : [...current, moduleId];

      return { ...prev, [vendorId]: next };
    });
  };

  const applyVendorDefaultToCanvas = (vendorId: string) => {
    const ids = mapping[vendorId] || [];

    setCanvas(
      ids.map((id) => {
        const module = modules.find((item) => item.id === id);

        if (!module) {
          return {
            moduleId: id,
            repeatCount: 1,
            allowFieldAdd: false,
          };
        }

        const existing = canvas.find((item) => item.moduleId === id);

        return (
          existing || {
            moduleId: id,
            repeatCount: module.repeatable
              ? module.id === "mod2"
                ? 4
                : 3
              : 1,
            allowFieldAdd: !!module.repeatable,
          }
        );
      })
    );

    setActiveVendor(vendorId);
  };

//   const totalFields = useMemo(
//     () =>
//       canvas.reduce((sum, item) => {
//         const module = modules.find((mod) => mod.id === item.moduleId);
//         return sum + (module?.fields || 0) * item.repeatCount;
//       }, 0),
//     [canvas]
//   );
 

function FieldRenderer({
    field,
    value,
    onChange,
}: FieldRendererProps) {
    switch (field.type) {
        case "text":
            return (
                <input
                    type="text"
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                />
            );

        case "number":
            return (
                <div className="flex items-center gap-2">
                    <input
                        type="number"
                        value={value ?? ""}
                        onChange={(e) =>
                            onChange(field.id, e.target.value)
                        }
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                    />

                    {field.unit && (
                        <span className="text-xs text-slate-500">
                            {field.unit}
                        </span>
                    )}
                </div>
            );

        case "radio":
            return (
                <div className="flex flex-wrap gap-4">
                    {field.options?.map((option) => (
                        <label
                            key={option.value}
                            className="flex cursor-pointer items-center gap-2 text-sm text-slate-600"
                        >
                            <input
                                type="radio"
                                name={field.id}
                                value={option.value}
                                checked={value === option.value}
                                onChange={() =>
                                    onChange(
                                        field.id,
                                        option.value
                                    )
                                }
                            />

                            {option.label}
                        </label>
                    ))}
                </div>
            );

        case "select":
            return (
                <select
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-amber-400"
                >
                    <option value="">
                        Select...
                    </option>

                    {field.options?.map((option) => (
                        <option
                            key={option.value}
                            value={option.value}
                        >
                            {option.label}
                        </option>
                    ))}
                </select>
            );

        case "textarea":
            return (
                <textarea
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    rows={4}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                />
            );

        default:
            return null;
    }
}

const handleSaveTemplate = () => {
    setSavedFlash(true);

    setTimeout(() => {
        navigate("/survey_report");
    }, 1000);
};
const handleFieldChange = (
    fieldId: string,
    value: string | number
) => {
    setFormValues((prev) => ({
        ...prev,
        [fieldId]: value,
    }));
};

const navigate = useNavigate();
return (
 <div className="min-h-screen w-full bg-slate-50 font-['IBM_Plex_Sans',sans-serif] text-slate-900">
    <div className="p-3 sm:p-4 md:p-3">

        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-3">
                <button
                    type="button"
                    onClick={() => navigate("/survey_report")}
                    className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
                    aria-label="Back to survey templates"
                    title="Back to survey templates"
                >
                    <ArrowLeft
                        size={18}
                        weight="bold"
                    />
                </button>

                <div className="min-w-0">
                    <h1 className="text-2xl font-bold text-slate-900">
                        FTTH Field Engineering Survey
                    </h1>

                    <p className="mt-1 max-w-3xl text-sm leading-relaxed text-slate-500">
                        Configure survey modules, repeat counts,
                        conditional fields, and vendor-specific
                        defaults for field engineering teams.
                    </p>
                </div>
            </div>


           <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                    <div className="text-xs text-slate-500 sm:text-right">
                        {canvas.length} modules selected · {totalFields} fields assembled
                    </div>

                    <div className="flex items-center gap-2">
                        {/* Add Module */}
                        {/* <button
                            type="button"
                            onClick={() => setAddModuleOpen(true)}
                            className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-amber-400 hover:bg-amber-50 hover:text-amber-700"
                        > 
                            <Plus size={15} />
                            Add Module
                        </button> */}

                        {/* Save Template */}
                        <button
                            type="button"
                            onClick={handleSaveTemplate}
                            className="inline-flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
                        >
                            <FloppyDisk size={15} />

                            {savedFlash
                                ? "Template saved"
                                : "Save template"}
                        </button>
                    </div>
                </div>

            </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">

            <aside className="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white lg:col-span-3">
                <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-4 py-4">
                    <div className="min-w-0">
                        <h2 className="text-sm font-semibold text-slate-900">
                            Module Library
                        </h2>

                        <p className="mt-1 text-xs leading-relaxed text-slate-500">
                            Select modules to add them to the assembled survey
                            template.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() => setAddModuleOpen(true)}
                        title="Add Module"
                        aria-label="Add Module"
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-600 text-white transition hover:bg-red-700"
                    >
                        <Plus size={16} weight="bold" />
                    </button>
                </div>


                <div className="space-y-2 p-3">
                    {modules.map((module) => {
                        const Icon = module.icon;
                        const active = inCanvas(module.id);

                        return (
                            <button
                                key={module.id}
                                type="button"
                                onClick={() => toggleModule(module.id)}
                                className={`w-full rounded-lg border p-3 text-left transition-colors ${
                                    active
                                        ? "border-amber-300 bg-amber-50"
                                        : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                                }`}
                            >
                                <div className="flex items-start gap-2.5">
                                    <div
                                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${ZONE_COLOR[module.zone]}`}
                                    >
                                        <Icon size={15} />
                                    </div> 

                                    <div className="min-w-0 flex-1">
                                        <div className="flex flex-wrap items-center gap-2">
                                            <span className="font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                                {module.code}
                                            </span>

                                            {module.repeatable && (
                                                <span className="inline-flex items-center gap-1 text-[10px] text-slate-400">
                                                    <ArrowsClockwise size={10} />
                                                    repeatable
                                                </span>
                                            )}
                                        </div>

                                        <div className="mt-0.5 text-[13px] font-medium leading-snug text-slate-900">
                                            {module.name}
                                        </div>

                                        <div className="mt-1 text-[11px] text-slate-500">
                                            {module.fields} fields
                                            {module.hasConditional &&
                                                " · conditional logic"}
                                        </div>
                                    </div>

                                    <div
                                        className={`mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                                            active
                                                ? "border-amber-500 text-amber-600"
                                                : "border-slate-300"
                                        }`}
                                    >
                                        {active && <Check size={11} />}
                                    </div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </aside>

            <main className="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white lg:col-span-6">
               <div className="border-b border-slate-200 px-4 py-4">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 className="text-sm font-semibold text-slate-900">
                Assembled Template
            </h2>

            <p className="mt-1 text-xs leading-relaxed text-slate-500">
                Configure the selected modules and their repeat counts.
            </p>
        </div>

        <button
            type="button"
            onClick={handleSelectAllFields}
            className="w-fit rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
        >
            {selectedFields.length === getAllFieldIds().length &&
            getAllFieldIds().length > 0
                ? "Deselect All"
                : "Select All"}
        </button>
    </div>
</div>


                <div className="space-y-3 p-4 sm:p-5">
                    {canvas.length === 0 && (
                        <div className="rounded-lg border border-dashed border-slate-300 py-12 text-center text-sm text-slate-500">
                            No modules selected.
                        </div>
                    )}

                    {canvas.map((item, index) => {
                        const module = modules.find(
                            (mod) => mod.id === item.moduleId
                        );

                        if (!module) return null;

                        const Icon = module.icon;
                        const isOpen = expanded === module.id;

                        return (
                            <div
                                key={module.id}
                                className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm"
                            >
                                <button
                                    type="button"
                                    onClick={() =>
                                        setExpanded(
                                            isOpen ? null : module.id
                                        )
                                    }
                                    className={`flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-slate-50 ${
                                        isOpen
                                            ? "border-b border-slate-200"
                                            : ""
                                    }`}
                                >
                                   <div className="flex min-w-0 items-center gap-3">
                                        <span className="w-5 shrink-0 text-center font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                            {String(index + 1).padStart(2, "0")}
                                        </span>
                                        <div
                                            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${ZONE_COLOR[module.zone]}`}
                                        >
                                            <Icon size={15} />
                                        </div>

                                        <div className="min-w-0 flex-1">
                                            <div className="truncate text-sm font-medium text-slate-900">
                                                {module.name}
                                            </div>

                                            <div className="mt-0.5 font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                                {module.code}

                                                {module.repeatable &&
                                                    ` · ${item.repeatCount}× ${module.unitLabel}`}
                                            </div>
                                        </div>
                                    </div>
                                    

                                    {isOpen ? (
                                        <CaretDown
                                            size={16}
                                            className="shrink-0 text-slate-400"
                                        />
                                    ) : (
                                        <CaretRight
                                            size={16}
                                            className="shrink-0 text-slate-400"
                                        />
                                    )}
                                </button>

                               {isOpen && (
                                    
                            <div className="space-y-5 px-4 pb-4 pt-4">
                                {module.sections?.map((section) => {
                                    const sectionFieldIds =
                                        section.fieldGroups?.flatMap(
                                            (group) =>
                                                group.fields?.map((field) => field.id) ?? []
                                        ) ?? [];

                                    const allSectionFieldsSelected =
                                        sectionFieldIds.length > 0 &&
                                        sectionFieldIds.every((id) =>
                                            selectedFields.includes(id)
                                        );

                                    const handleSectionSelect = () => {
                                        setSelectedFields((prev) => {
                                            if (allSectionFieldsSelected) {
                                                return prev.filter(
                                                    (id) => !sectionFieldIds.includes(id)
                                                );
                                            }

                                            return Array.from(
                                                new Set([...prev, ...sectionFieldIds])
                                            );
                                        });
                                    };

                                    return (
                                        <div key={section.id}>
                                            <div className="mb-3 flex flex-wrap items-center gap-2">
                                                <input
                                                    type="checkbox"
                                                    checked={allSectionFieldsSelected}
                                                    onChange={handleSectionSelect}
                                                    className="h-4 w-4 shrink-0 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                                />

                                                <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                                                    {section.title}
                                                </h3>

                                                
                                            </div>

                                            <div className="space-y-4">
                                                {section.fieldGroups?.map((group) => (
                                                    <div
                                                        key={group.id}
                                                        className="rounded-lg border border-slate-200 p-4"
                                                    >
                                                        <div className="mb-4 text-sm font-medium text-slate-900">
                                                            {group.title}
                                                        </div>

                                                        <div className="space-y-4">
                                                            {group.fields?.map((field) => (
                                                                <div
                                                                    key={field.id}
                                                                    className="flex items-start gap-3"
                                                                >
                                                                    <input
                                                                        type="checkbox"
                                                                        checked={selectedFields.includes(
                                                                            field.id
                                                                        )}
                                                                        onChange={(event) => {
                                                                            setSelectedFields(
                                                                                (prev) =>
                                                                                    event.target
                                                                                        .checked
                                                                                        ? [
                                                                                            ...prev,
                                                                                            field.id,
                                                                                        ]
                                                                                        : prev.filter(
                                                                                            (
                                                                                                id
                                                                                            ) =>
                                                                                                id !==
                                                                                                field.id
                                                                                        )
                                                                            );
                                                                        }}
                                                                        className="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                                                    />

                                                                    <div className="min-w-0 flex-1">
                                                                        <label className="mb-2 block text-xs font-medium text-slate-700">
                                                                            {field.label}

                                                                            {field.required && (
                                                                                <span className="ml-1 text-red-500">
                                                                                    *
                                                                                </span>
                                                                            )}
                                                                        </label>

                                                                        <FieldRenderer
                                                                            field={field}
                                                                            value={
                                                                                formValues[
                                                                                    field.id
                                                                                ]
                                                                            }
                                                                            onChange={
                                                                                handleFieldChange
                                                                            }
                                                                        />
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>


                                )}

                            </div>
                        );
                    })}
                </div>
            </main>

            <aside className="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white lg:col-span-3">
                <div className="border-b border-slate-200 px-4 py-4">
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-slate-900">
                        <Users size={14} />
                        Vendor Mapping
                    </div>

                    <p className="mt-1 text-xs leading-relaxed text-slate-500">
                        Configure default modules for each crew type.
                    </p>
                </div>

                <div className="space-y-2 p-3">
                    {VENDOR_TYPES.map((vendor) => {
                        const isActive = activeVendor === vendor.id;

                        return (
                            <div
                                key={vendor.id}
                                className={`rounded-lg border bg-white transition-colors ${
                                    isActive
                                        ? "border-emerald-300"
                                        : "border-slate-200"
                                }`}
                            >
                                <div className="flex items-center justify-between gap-2 px-3 py-3">
                                    <span className="min-w-0 text-xs font-medium text-slate-800">
                                        {vendor.label}
                                    </span>

                                    <button
                                        type="button"
                                        onClick={() =>
                                            applyVendorDefaultToCanvas(
                                                vendor.id
                                            )
                                        }
                                        className={`inline-flex shrink-0 items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[10px] font-semibold transition-colors ${
                                            isActive
                                                ? "border-emerald-500 text-emerald-600"
                                                : "border-slate-300 text-slate-500 hover:border-emerald-400 hover:text-emerald-600"
                                        }`}
                                    >
                                        <Eye size={10} />
                                        {isActive ? "Applied" : "Apply"}
                                    </button>
                                </div>

                                <div className="flex flex-wrap gap-1.5 px-3 pb-3">
                                    {modules.map((module) => {
                                        const checked = (
                                            mapping[vendor.id] || []
                                        ).includes(module.id);

                                        return (
                                            <button
                                                key={module.id}
                                                type="button"
                                                onClick={() =>
                                                    toggleVendorModule(
                                                        vendor.id,
                                                        module.id
                                                    )
                                                }
                                                className={`rounded border px-1.5 py-0.5 font-['IBM_Plex_Mono',monospace] text-[9px] transition-colors ${
                                                    checked
                                                        ? ZONE_COLOR[
                                                              module.zone
                                                          ]
                                                        : "border-slate-200 text-slate-400 hover:border-slate-300 hover:text-slate-600"
                                                }`}
                                            >
                                                {module.code}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                        );
                    })}
                </div>

                <div className="mx-3 mb-4 border-t border-slate-200 px-1 pt-4">
                    <div className="mb-3 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                        Canvas Summary
                    </div>

                    <div className="space-y-2">
                        {canvas.map((item) => {
                            const module = modules.find(
                                (mod) => mod.id === item.moduleId
                            );

                            if (!module) return null;

                            return (
                                <div
                                    key={module.id}
                                    className="flex items-center justify-between text-xs"
                                >
                                    <span className="text-slate-600">
                                        {module.code}
                                    </span>

                                    <span className="font-['IBM_Plex_Mono',monospace] text-slate-500">
                                        {module.repeatable
                                            ? `×${item.repeatCount}`
                                            : "×1"}
                                    </span>
                                </div>
                            );
                        })}

                        {canvas.length === 0 && (
                            <div className="text-xs text-slate-400">
                                Canvas empty
                            </div>
                        )}
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-slate-200 pt-3 text-xs">
                        <span className="text-slate-600">
                            Total fields
                        </span>

                        <span className="font-['IBM_Plex_Mono',monospace] font-semibold text-amber-600">
                            {totalFields}
                        </span>
                    </div>
                </div>
            </aside>
        </div>
    </div>
<AddModule
    open={addModuleOpen}
    onClose={() => {
        setAddModuleOpen(false);
        setEditingModule(null);
    }}
    onCreate={handleCreateModule}
    onUpdate={handleUpdateModule}
    editingModule={editingModule}
    templateName={editingTemplate?.name ?? ""}
    modules={modules}
/>
</div>
);
}