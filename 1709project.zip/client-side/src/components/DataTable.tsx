import {
    ArrowDownIcon,
    ArrowUpIcon,
    ArrowUpLeftIcon,
} from "@phosphor-icons/react";
import { useMemo, useState } from "react";

export interface DataTableColumn<T> {
    key: string;
    label: string;
    render?: (
        row: T,
        index: number
    ) => React.ReactNode;

    align?: "left" | "center" | "right";
    sortable?: boolean;

    /**
     * Fixed width, e.g. "120px"
     */
    width?: string;
}

export interface DataTableAction<T> {
    label: string;
    onClick: (row: T) => void;
    variant?: "primary" | "secondary" | "danger";
     icon?: React.ReactNode;
}

interface DataTableProps<T> {
    columns: DataTableColumn<T>[];
    data: T[];
    actions?: DataTableAction<T>[];
    rowKey?: (
        row: T
    ) => string | number;
    emptyMessage?: string;
    className?: string;
    minWidth?: string;
    footer?: React.ReactNode;
}

const ACTION_STYLES: Record<
    string,
    string
> = {
    primary:
        "bg-red-600 text-white hover:bg-red-700",
    secondary:
        "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
    danger:
        "text-red-600 hover:text-red-700",
};

export default function DataTable<T>({
    columns,
    data,
    actions = [],
    rowKey,
    emptyMessage = "No records found.",
    className = "",
    minWidth,
    footer,
}: DataTableProps<T>) {
    const [sortKey, setSortKey] =
        useState<string | null>(null);

    const [sortDir, setSortDir] =
        useState<"asc" | "desc">("asc");

    const toggleSort = (
        col: DataTableColumn<T>
    ) => {
        if (!col.sortable) return;

        if (sortKey !== col.key) {
            setSortKey(col.key);
            setSortDir("asc");
        } else {
            setSortDir((direction) =>
                direction === "asc"
                    ? "desc"
                    : "asc"
            );
        }
    };

    const sortedData = useMemo(() => {
        if (!sortKey) {
            return data;
        }

        return [...data].sort(
            (a: any, b: any) => {
                const av = a[sortKey];
                const bv = b[sortKey];

                if (av < bv) {
                    return sortDir === "asc"
                        ? -1
                        : 1;
                }

                if (av > bv) {
                    return sortDir === "asc"
                        ? 1
                        : -1;
                }

                return 0;
            }
        );
    }, [
        data,
        sortKey,
        sortDir,
    ]);

    const alignClass = (
        align?:
            | "left"
            | "center"
            | "right"
    ) => {
        if (align === "right") {
            return "text-right";
        }

        if (align === "center") {
            return "text-center";
        }

        return "text-left";
    };

    return (
        <div
            className={`overflow-hidden rounded-lg border border-slate-200 bg-white ${className}`}
        >
            <div className="overflow-x-auto">
                <table
                    className="w-full table-fixed text-left text-sm"
                    style={{
                        minWidth:
                            minWidth ?? "100%",
                    }}
                >
                    <colgroup>
                        {columns.map(
                            (column) => (
                                <col
                                    key={
                                        column.key
                                    }
                                    style={{
                                        width:
                                            column.width,
                                    }}
                                />
                            )
                        )}

                        {actions.length >
                            0 && (
                            <col
                                style={{
                                    width: "100px",
                                }}
                            />
                        )}
                    </colgroup>

                    <thead>
                        <tr className="border-b border-slate-200 bg-slate-50">
                            {columns.map(
                                (col) => (
                                    <th
                                        key={
                                            col.key
                                        }
                                        onClick={() =>
                                            toggleSort(
                                                col
                                            )
                                        }
                                        className={`px-2.5 py-2.5 text-[9px] font-bold uppercase tracking-wide text-slate-500 ${alignClass(
                                            col.align
                                        )} ${
                                            col.sortable
                                                ? "cursor-pointer select-none hover:text-slate-700"
                                                : ""
                                        }`}
                                    >
                                        <span
                                            className={`inline-flex items-center gap-1 ${
                                                col.align ===
                                                "right"
                                                    ? "justify-end"
                                                    : col.align ===
                                                        "center"
                                                      ? "justify-center"
                                                      : ""
                                            }`}
                                        >
                                            {
                                                col.label
                                            }

                                            {col.sortable &&
                                                (sortKey !==
                                                col.key ? (
                                                    <ArrowUpLeftIcon
                                                        size={
                                                            10
                                                        }
                                                        className="text-slate-300"
                                                    />
                                                ) : sortDir ===
                                                  "asc" ? (
                                                    <ArrowUpIcon
                                                        size={
                                                            10
                                                        }
                                                        className="text-red-600"
                                                    />
                                                ) : (
                                                    <ArrowDownIcon
                                                        size={
                                                            10
                                                        }
                                                        className="text-red-600"
                                                    />
                                                ))}
                                        </span>
                                    </th>
                                )
                            )}

                            {actions.length >
                                0 && (
                                <th className="px-2.5 py-2.5 text-right text-[9px] font-bold uppercase tracking-wide text-slate-500">
                                    Actions
                                </th>
                            )}
                        </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-100">
                        {sortedData.length ===
                        0 ? (
                            <tr>
                                <td
                                    colSpan={
                                        columns.length +
                                        (actions.length >
                                        0
                                            ? 1
                                            : 0)
                                    }
                                    className="px-4 py-8 text-center text-xs text-slate-400"
                                >
                                    {
                                        emptyMessage
                                    }
                                </td>
                            </tr>
                        ) : (
                            sortedData.map(
                                (
                                    row,
                                    index
                                ) => (
                                    <tr
                                            key={
                                                rowKey
                                                    ? rowKey(row)
                                                    : index
                                            }
                                            className="group transition-colors hover:bg-red-50/30"
                                        >
                                        {columns.map(
                                            (
                                                col,colIndex
                                            ) => (
                                                <td
                                                    key={col.key}
                                                    className={`
                                                        px-2.5 py-2.5 align-middle text-slate-700
                                                        ${alignClass(col.align)}
                                                        ${
                                                            colIndex === 0
                                                                ? "border-l-2 border-transparent transition-colors group-hover:border-red-600 group-hover:text-red-600"
                                                                : ""

                                                        }
                                                    `}
                                                >
                                                    {col.render
                                                        ? col.render(row, index)
                                                        : String(
                                                            (row as any)[col.key] ?? ""
                                                        )}
                                                </td>
                                            )
                                        )}

                                        {actions.length >
                                            0 && (
                                            <td className="px-2.5 py-2.5 align-middle">
                                                <div className="flex items-center justify-end gap-2">
                                                    {actions.map(
                                                        (
                                                            action
                                                        ) => (
                                                            <button
                                                                key={
                                                                    action.label
                                                                }
                                                                type="button"
                                                                onClick={() =>
                                                                    action.onClick(
                                                                        row
                                                                    )
                                                                }
                                                                className={`rounded-md px-2.5 py-1.5 text-[10px] font-bold transition-colors ${
                                                                    ACTION_STYLES[
                                                                        action
                                                                            .variant ??
                                                                            "secondary"
                                                                    ]
                                                                }`}
                                                            >
                                                                {
                                                                    action.label
                                                                }
                                                            </button>
                                                        )
                                                    )}
                                                </div>
                                            </td>
                                        )}
                                    </tr>
                                )
                            )
                        )}
                    </tbody>
                     {footer && (
                        <tfoot>
                            {footer}
                        </tfoot>
                    )}
                </table>
            </div>
        </div>
    );
}
