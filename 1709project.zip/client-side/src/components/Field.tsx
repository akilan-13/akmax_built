
import React from "react";
import IconInfoHexagon from "../components/Icon/IconInfoHexagon";

interface FieldProps {
  label: string;
  required?: boolean;
  error?: string;
  touched?: boolean;
  hint?: string;

  type?:
    | "text"
    | "email"
    | "number"
    | "password"
    | "tel"
    | "textarea"
    | "date";

  className?: string;
  name?: string;
  rows?: number;

  value?: string | number;
  placeholder?: string;

  onChange?: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;

  onBlur?: (
    e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;

  disabled?: boolean;
  readOnly?: boolean;
  min?: number;
  max?: number;
  autoComplete?: string;
}

export default function Field({
  label,
  required = false,
  error,
  touched = false,
  hint,
  type = "text",
  className = "",
  name,
  rows = 4,
  value = "",
  placeholder,
  onChange,
  onBlur,
  disabled = false,
  readOnly = false,
  min,
  max,
  autoComplete,
}: FieldProps) {
  const showError = Boolean(touched && error);

  const baseClassName =
    "w-full rounded-lg border px-3.5 py-2.5 text-sm text-slate-800 " +
    "placeholder:text-slate-400 focus:outline-none focus:ring-2 transition " +
    "disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400";

  const stateClassName = showError
    ? "border-red-400 focus:border-red-500 focus:ring-red-500/20"
    : "border-slate-300 focus:border-red-500 focus:ring-red-500/20";

  const fieldClassName = `${baseClassName} ${stateClassName} ${className}`;

  const errorId = name ? `${name}-error` : undefined;
  const hintId = name ? `${name}-hint` : undefined;

  const describedBy = showError
    ? errorId
    : hint
      ? hintId
      : undefined;

  return (
    <div className="w-full">
      <label
        htmlFor={name}
        className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400"
      >
        {label}
        {required && (
          <span className="ml-0.5 text-red-500" aria-hidden="true">
            *
          </span>
        )}
      </label>

      {type === "textarea" ? (
        <textarea
          id={name}
          name={name}
          value={value}
          placeholder={placeholder}
          rows={rows}
          onChange={onChange}
          onBlur={onBlur}
          disabled={disabled}
          readOnly={readOnly}
          required={required}
          aria-invalid={showError}
          aria-describedby={describedBy}
          className={fieldClassName}
        />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          value={value}
          placeholder={placeholder}
          onChange={onChange}
          onBlur={onBlur}
          disabled={disabled}
          readOnly={readOnly}
          required={required}
          min={min}
          max={max}
          autoComplete={autoComplete}
          aria-invalid={showError}
          aria-describedby={describedBy}
          className={fieldClassName}
        />
      )}

      {showError ? (
        <p
          id={errorId}
          className="mt-1 flex items-center gap-1 text-[11px] text-red-500"
        >
          <IconInfoHexagon className="text-[9px]" />
          {error}
        </p>
      ) : hint ? (
        <p
          id={hintId}
          className="mt-1 text-[11px] text-slate-400"
        >
          {hint}
        </p>
      ) : null}
    </div>
  );
}