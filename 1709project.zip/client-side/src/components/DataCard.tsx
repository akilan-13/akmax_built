import { useState } from "react";
import { DotsThreeVerticalIcon } from "@phosphor-icons/react";

export interface DataCardField {
    label: string;
    value: React.ReactNode;
    fullWidth?: boolean;
}

export interface DataCardBadge {
    text: string;
    color?: "green" | "amber" | "red" | "slate" | "indigo";
    position?: "top-right" | "top-left" | "bottom-left" | "bottom-right";
}

export interface DataCardAction {
    id?: string;
    label: React.ReactNode;
    onClick: () => void;
    variant?: "primary" | "secondary" | "link";
}

export interface DataCardMenuAction {
    id?: string;
    label: React.ReactNode;
    onClick: () => void;
    danger?: boolean;
}

interface DataCardProps {
    title: string;
    subtitle?: React.ReactNode;
    avatar?: React.ReactNode;
    children?: React.ReactNode;

    badge?: DataCardBadge;

    tags?: string[];
    tagColor?: "green" | "amber" | "red" | "slate" | "indigo";

    fields?: DataCardField[];

    actions?: DataCardAction[];

    menuActions?: DataCardMenuAction[];

    className?: string;

    // Enables red title + red shadow on card hover
    hoverTitle?: boolean;
}

const BADGE_STYLES: Record<string, string> = {
    green: "bg-emerald-50 text-emerald-700 border-emerald-200",
    amber: "bg-amber-50 text-amber-700 border-amber-200",
    red: "bg-red-50 text-red-700 border-red-200",
    slate: "bg-slate-100 text-slate-500 border-slate-200",
    indigo: "bg-indigo-50 text-indigo-700 border-indigo-200",
};

const BADGE_POSITION_STYLES: Record<
    NonNullable<DataCardBadge["position"]>,
    string
> = {
    "top-left": "top-5 left-5",
    "top-right": "top-5 right-5",
    "bottom-left": "bottom-5 left-5",
    "bottom-right": "bottom-5 right-5",
};

const ACTION_STYLES: Record<string, string> = {
    primary:
        "bg-red-600 text-white hover:bg-red-700 px-3.5 py-2 rounded-lg shadow-sm shadow-red-600/20",

    secondary:
        "border border-slate-200 text-slate-700 hover:bg-slate-50 px-3.5 py-2 rounded-lg",

    link: "text-red-600 hover:text-red-700",
};

export default function DataCard({
    title,
    subtitle,
    avatar,
    badge,
    tags = [],
    fields = [],
    actions = [],
    menuActions = [],
    className = "",
    hoverTitle = false,
}: DataCardProps) {
    const [menuOpen, setMenuOpen] = useState(false);

    const badgeColor = badge?.color ?? "slate";
    const badgePosition = badge?.position ?? "top-right";

    const badgeElement = badge ? (
        <span
            className={`shrink-0 rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                BADGE_STYLES[badgeColor]
            }`}
        >
            {badge.text}
        </span>
    ) : null;

    return (
        <div
            className={` group relative flex h-full w-full min-w-0 flex-col rounded-2xl border border-slate-200
                bg-white p-5 shadow-sm transition-all duration-200 ease-in-out hover:border-red-200 hover:shadow-[0_8px_25px_rgba(239,68,68,0.15)]
                ${className}
            `}
        >
            {/* =========================================================
                HEADER
            ========================================================= */}
            <div className="flex min-h-[52px] items-start justify-between gap-3">
                <div className="flex min-w-0 flex-1 items-start gap-3">
                    {avatar && (
                        <div
                            className="
                                flex
                                h-11
                                w-11
                                shrink-0
                                items-center
                                justify-center
                                rounded-xl
                                bg-red-50
                                text-lg
                                font-black
                                text-red-600
                            "
                        >
                            {avatar}
                        </div>
                    )}

                    <div className="min-w-0 flex-1">
                        {badge &&
                            badgePosition === "top-left" && (
                                <div className="mb-1">
                                    {badgeElement}
                                </div>
                            )}

                        <div className="min-w-0 flex-1 pr-24">
                            <h3
                                className={`
                                    w-full
                                    min-w-0
                                    whitespace-normal
                                    break-words
                                    text-sm
                                    font-bold
                                    leading-5
                                    transition-colors
                                    duration-200
                                    sm:text-base
                                    ${
                                        hoverTitle
                                            ? "text-slate-900 group-hover:text-red-600"
                                            : "text-slate-900"
                                    }
                                `}
                            >
                                {title}
                            </h3>

                            {subtitle && (
                                <p
                                    className="
                                        mt-0.5
                                        w-full
                                        min-w-0
                                        whitespace-normal
                                        break-words
                                        text-xs
                                        leading-4
                                        text-slate-400
                                    "
                                >
                                    {subtitle}
                                </p>
                            )}
                        </div>

                        {badge &&
                            badgePosition !== "top-right" &&
                            badgePosition !== "top-left" && (
                                <span
                                    className={`
                                        absolute
                                        ${BADGE_POSITION_STYLES[badgePosition]}
                                        shrink-0
                                        rounded-full
                                        border
                                        px-2.5
                                        py-0.5
                                        text-[10px]
                                        font-bold
                                        uppercase
                                        tracking-wide
                                        ${
                                            BADGE_STYLES[
                                                badge.color ??
                                                    "slate"
                                            ]
                                        }
                                    `}
                                >
                                    {badge.text}
                                </span>
                            )}
                    </div>
                </div>

                {badge &&
                    badgePosition === "top-right" && (
                        <div className="shrink-0">
                            {badgeElement}
                        </div>
                    )}
            </div>

            {/* =========================================================
                TAGS
            ========================================================= */}
            {tags.length > 0 && (
                <div className="mt-4 flex min-h-[30px] flex-wrap content-start gap-2">
                    {tags.map((tag) => (
                        <span
                            key={tag}
                            className="
                                max-w-full
                                break-words
                                rounded-lg
                                border
                                border-slate-200
                                bg-slate-50
                                px-2.5
                                py-1
                                text-[11px]
                                font-semibold
                                text-slate-600
                            "
                        >
                            {tag}
                        </span>
                    ))}
                </div>
            )}

            {/* =========================================================
                FIELDS
            ========================================================= */}
            {fields.length > 0 && (
                <div
                    className="
                        mt-4
                        grid
                        flex-1
                        grid-cols-2
                        content-start
                        gap-x-4
                        gap-y-4
                        border-t
                        border-slate-100
                        pt-4
                    "
                >
                    {fields.map((field, index) => (
                        <div
                            key={field.label || index}
                            className={`
                                min-w-0
                                ${
                                    field.fullWidth
                                        ? "col-span-2"
                                        : "col-span-1"
                                }
                            `}
                        >
                            <span
                                className="
                                    block
                                    text-[10px]
                                    font-black
                                    uppercase
                                    tracking-wide
                                    text-slate-400
                                "
                            >
                                {field.label}
                            </span>

                            <div
                                className="
                                    mt-1
                                    min-w-0
                                    text-sm
                                    font-bold
                                    text-slate-800
                                "
                            >
                                {field.value}
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* =========================================================
                ACTIONS
            ========================================================= */}
            {(actions.length > 0 ||
                menuActions.length > 0) && (
                <div
                    className="
                        mt-auto
                        flex
                        min-h-[46px]
                        items-center
                        justify-between
                        gap-3
                        border-t
                        border-slate-100
                        pt-3
                    "
                >
                    {/* PRIMARY ACTION */}
                    <div className="min-w-0">
                        {actions
                            .filter(
                                (action) =>
                                    action.variant ===
                                    "primary"
                            )
                            .map((action, index) => (
                                <button
                                    key={
                                        action.id ??
                                        index
                                    }
                                    type="button"
                                    onClick={
                                        action.onClick
                                    }
                                    className={`
                                        inline-flex
                                        items-center
                                        gap-1.5
                                        text-xs
                                        font-bold
                                        ${ACTION_STYLES.primary}
                                    `}
                                >
                                    {action.label}
                                </button>
                            ))}
                    </div>

                    {/* SECONDARY / LINK / MENU */}
                    <div className="flex shrink-0 items-center gap-2">
                        {actions
                            .filter(
                                (action) =>
                                    action.variant !==
                                    "primary"
                            )
                            .map((action, index) => (
                                <button
                                    key={
                                        action.id ??
                                        index
                                    }
                                    type="button"
                                    onClick={
                                        action.onClick
                                    }
                                    className={`
                                        inline-flex
                                        items-center
                                        gap-1.5
                                        text-xs
                                        font-bold
                                        ${
                                            ACTION_STYLES[
                                                action.variant ??
                                                    "link"
                                            ]
                                        }
                                    `}
                                >
                                    {action.label}
                                </button>
                            ))}

                        {menuActions.length > 0 && (
                            <div className="relative">
                                <button
                                    type="button"
                                    aria-label="More options"
                                    aria-expanded={
                                        menuOpen
                                    }
                                    onClick={() =>
                                        setMenuOpen(
                                            (
                                                previous
                                            ) =>
                                                !previous
                                        )
                                    }
                                    className="
                                        flex
                                        h-9
                                        w-9
                                        items-center
                                        justify-center
                                        rounded-lg
                                        border
                                        border-slate-200
                                        bg-white
                                        text-slate-400
                                        transition-colors
                                        hover:bg-slate-50
                                        hover:text-slate-700
                                    "
                                >
                                    <DotsThreeVerticalIcon
                                        size={20}
                                        weight="bold"
                                    />
                                </button>

                                {menuOpen && (
                                    <>
                                        <button
                                            type="button"
                                            aria-label="Close menu"
                                            className="
                                                fixed
                                                inset-0
                                                z-40
                                                h-full
                                                w-full
                                                cursor-default
                                            "
                                            onClick={() =>
                                                setMenuOpen(
                                                    false
                                                )
                                            }
                                        />

                                        <div
                                            className="
                                                absolute
                                                bottom-11
                                                right-0
                                                z-50
                                                w-48
                                                overflow-hidden
                                                rounded-xl
                                                border
                                                border-slate-200
                                                bg-white
                                                py-1
                                                shadow-xl
                                            "
                                        >
                                            {menuActions.map(
                                                (
                                                    menuAction,
                                                    index
                                                ) => (
                                                    <button
                                                        key={
                                                            menuAction.id ??
                                                            index
                                                        }
                                                        type="button"
                                                        onClick={() => {
                                                            setMenuOpen(
                                                                false
                                                            );
                                                            menuAction.onClick();
                                                        }}
                                                        className={`
                                                            flex
                                                            w-full
                                                            items-center
                                                            px-4
                                                            py-2.5
                                                            text-left
                                                            text-sm
                                                            font-medium
                                                            transition-colors
                                                            ${
                                                                menuAction.danger
                                                                    ? "text-red-600 hover:bg-red-50"
                                                                    : "text-slate-700 hover:bg-slate-50"
                                                            }
                                                        `}
                                                    >
                                                        {
                                                            menuAction.label
                                                        }
                                                    </button>
                                                )
                                            )}
                                        </div>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
