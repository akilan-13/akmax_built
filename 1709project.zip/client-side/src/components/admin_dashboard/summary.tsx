import {
    FolderSimpleIcon,
    LightningIcon,
    ListChecks,
    CheckCircle,
    ArrowRightIcon,
    CalendarBlankIcon,
    WarningIcon,
    UserCircleIcon,
    ChatCircleTextIcon,
    CheckCircleIcon,
    PlayCircleIcon,
    PlusCircleIcon,
    ClockIcon,
    DotsThreeVerticalIcon,
} from '@phosphor-icons/react';
import StatCard from '../StatCard';
import { useNavigate } from 'react-router-dom';

export default function Summary() {
    const activeProjects = [
        {
            id: "PRJ-001",
            initial: 'S',
            name: 'Al Noor Commercial Tower',
            client: 'Seiretsu JA Ltd',
            progress: 45,
            status: 'In Progress',
        },
        {
            id: "PRJ-002",
            initial: 'S',
            name: 'Regional Operations Center',
            client: 'City Council',
            progress: 10,
            status: 'Started',
        },
    ];

    const upcomingDeadlines = [
        {
            id: 1,
            task: 'GPS Mapping',
            date: '2024-02-28',
            priority: 'High',
        },
        {
            id: 2,
            task: 'Requirement Gathering',
            date: '2024-03-01',
            priority: 'High',
        },
        {
            id: 3,
            task: 'Cable Installation',
            date: '2024-03-15',
            priority: 'Urgent',
        },
        {
            id: 4,
            task: 'Joint Closure',
            date: '2024-04-01',
            priority: 'Medium',
        },
    ];

    const activities = [
        {
            id: 1,
            name: 'Michael Chen',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael',
            time: '2 mins ago',
            action: 'commented on',
            task: 'GPS Mapping',
            project: 'Spalding Fiber FTTx',
            icon: ChatCircleTextIcon,
            description:
                'Finished mapping the northern sector. The terrain is rougher than expected.',
        },
        {
            id: 2,
            name: 'Jessica Williams',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica',
            time: '45 mins ago',
            action: 'completed task',
            task: 'Pole Inspection',
            project: 'Spalding Fiber FTTx',
            icon: CheckCircleIcon,
        },
        {
            id: 3,
            name: 'Sarah Johnson',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
            time: '2 hours ago',
            action: 'started phase',
            task: 'Phase 2 - Construction',
            project: 'Spalding Fiber FTTx',
            icon: PlayCircleIcon,
        },
        {
            id: 4,
            name: 'Sarah Johnson',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
            time: '3 hours ago',
            action: 'created task',
            task: 'Cable Installation',
            project: 'Spalding Fiber FTTx',
            icon: PlusCircleIcon,
        },
        {
            id: 5,
            name: 'Sarah Johnson',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
            time: '5 hours ago',
            action: 'updated',
            task: 'Smart City Infrastructure',
            project: 'Smart City Infrastructure',
            icon: ClockIcon,
            description:
                'Updated project timeline and resource allocation.',
        },
    ];

    const navigate = useNavigate();
    return (
        <div className="min-h-screen w-full bg-slate-50 font-['IBM_Plex_Sans',sans-serif] text-slate-900">
            <div className="p-3 sm:p-4 md:p-3">
                <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0">
                        <h1 className="text-2xl font-bold text-slate-900">
                            ARGUS Project Management System
                        </h1>

                        <p className="mt-1 max-w-3xl text-[12px] leading-relaxed text-slate-500 sm:text-[13px]">
                            Enterprise-wide supervision of fiber routes,
                            multi-stage commercial approvals, and billing
                            control audits.
                        </p>
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-4">
                    <StatCard
                        label="Total Projects"
                        value={3}
                        icon={FolderSimpleIcon}
                        tone="amber"
                        delta="+12%"
                        deltaLabel="from last month"
                    />

                    <StatCard
                        label="Active Projects"
                        value={3}
                        icon={LightningIcon}
                        tone="green"
                        delta="+12%"
                        deltaLabel="from last month"
                    />

                    <StatCard
                        label="Pending Tasks"
                        value={6}
                        icon={ListChecks}
                        tone="red"
                        delta="+12%"
                        deltaLabel="from last month"
                    />

                    <StatCard
                        label="Completed Tasks"
                        value={2}
                        icon={CheckCircle}
                        tone="blue"
                        delta="+12%"
                        deltaLabel="from last month"
                    />
                </div>

                <div className="mt-6 grid grid-cols-1 gap-5 xl:grid-cols-2">
                    <div className="space-y-5">
                        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                            <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <h2 className="text-base font-bold text-slate-900">
                                        Active Projects
                                    </h2>
                                    <p className="mt-0.5 text-xs text-slate-500">
                                        Current projects and their progress
                                    </p>
                                </div>

                               
                            </div>

                           <div className="divide-y divide-slate-100">
                                {activeProjects.map((project) => (
                                    <div
                                        key={project.id}
                                        onClick={() =>
                                            navigate(`/projects/project_details/${project.id}`)
                                        }
                                        className="group cursor-pointer px-4 py-4 transition-colors duration-200 hover:bg-slate-50"
                                    >
                                        <div className="flex items-start gap-3">
                                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-bold text-slate-700 group-hover:bg-red-600 group-hover:text-white">
                                                {project.initial}
                                            </div>

                                            <div className="min-w-0 flex-1">
                                                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                                    <div className="min-w-0 flex-1">
                                                        <div className="flex items-start gap-2">
                                                            <h3 className="text-sm font-bold leading-snug text-slate-900">
                                                                {project.name}
                                                            </h3>
                                                        </div>

                                                        <p className="mt-1 text-xs text-slate-500">
                                                            {project.client}
                                                        </p>
                                                    </div>

                                                    <span className="w-fit shrink-0 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                                                        {project.status}
                                                    </span>
                                                </div>

                                                <div className="mt-4">
                                                    <div className="mb-1.5 flex items-center justify-between text-[11px]">
                                                        <span className="font-medium text-slate-500">
                                                            Progress
                                                        </span>

                                                        <span className="font-bold text-slate-700">
                                                            {project.progress}%
                                                        </span>
                                                    </div>

                                                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                                                        <div
                                                            className="h-full rounded-full bg-red-600 transition-all"
                                                            style={{
                                                                width: `${project.progress}%`,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                            </div>
                        </div>

                        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                            <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                                <div className="flex items-center gap-2.5">
                                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                                        <CalendarBlankIcon
                                            size={19}
                                            weight="bold"
                                        />
                                    </div>

                                    <div>
                                        <h2 className="text-base font-bold text-slate-900">
                                            Upcoming Deadlines
                                        </h2>

                                        <p className="mt-0.5 text-xs text-slate-500">
                                            Important tasks requiring attention
                                        </p>
                                    </div>
                                </div>
                            </div>

                          <div className="divide-y divide-slate-100 hover:border-red-500">
                            {upcomingDeadlines.map((deadline) => (
                                <div
                                    key={deadline.id}
                                    className="group flex items-center gap-3 border border-transparent px-4 py-3.5 transition-all duration-200  hover:bg-red-50 hover:cursor-pointer"
                                >
                                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                        <ClockIcon
                                            size={17}
                                            weight="bold"
                                        />
                                    </div>

                                    <div className="min-w-0 flex-1">
                                        <h3 className="truncate text-sm font-semibold text-slate-800">
                                            {deadline.task}
                                        </h3>

                                        <p className="mt-0.5 text-[11px] text-slate-500">
                                            {deadline.date}
                                        </p>
                                    </div>

                                    <span
                                        className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${
                                            deadline.priority === 'Urgent'
                                                ? 'bg-red-50 text-red-600'
                                                : deadline.priority === 'High'
                                                ? 'bg-amber-50 text-amber-600'
                                                : 'bg-blue-50 text-blue-600'
                                        }`}
                                    >
                                        {deadline.priority}
                                    </span>
                                </div>
                            ))}
                        </div>

                            <div className="border-t border-slate-100 px-4 py-3">
                               <button
                                    type="button"
                                    onClick={() => navigate("/tasks")}
                                    className="flex items-center gap-1.5 text-xs font-semibold text-red-600 transition hover:text-red-700"
                                >
                                    View Full Task Calendar
                                    <ArrowRightIcon size={15} weight="bold" />
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="h-fit rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <h2 className="text-base font-bold text-slate-900">
                                    Activity Log
                                </h2>

                                <p className="mt-0.5 text-xs text-slate-500">
                                    Recent project activity
                                </p>
                            </div>

                            <span className="flex w-fit items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                                Real-time
                            </span>
                        </div>

                        <div className="divide-y divide-slate-100">
                            {activities.map((activity) => {
                                const ActivityIcon = activity.icon;

                                return (
                                    <div
                                        key={activity.id}
                                        className="px-4 py-4"
                                    >
                                        <div className="flex gap-3">
                                            <img
                                                src={activity.avatar}
                                                alt={activity.name}
                                                className="h-9 w-9 shrink-0 rounded-full bg-slate-100 object-cover"
                                            />

                                            <div className="min-w-0 flex-1">
                                                <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                                                    <span className="text-sm font-bold text-slate-900">
                                                        {activity.name}
                                                    </span>

                                                    <span className="text-[11px] text-slate-400">
                                                        {activity.time}
                                                    </span>
                                                </div>

                                                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                                    {activity.action}{' '}
                                                    <span className="font-semibold text-slate-800">
                                                        {activity.task}
                                                    </span>{' '}
                                                    in{' '}
                                                    <span className="font-semibold text-slate-800">
                                                        {activity.project}
                                                    </span>
                                                </p>

                                                {activity.description && (
                                                    <div className="mt-2 rounded-lg bg-slate-50 px-3 py-2.5 text-xs italic leading-relaxed text-slate-600">
                                                        "{activity.description}"
                                                    </div>
                                                )}
                                            </div>

                                            <div className="hidden shrink-0 text-slate-400 sm:block">
                                                <ActivityIcon
                                                    size={17}
                                                    weight="bold"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}